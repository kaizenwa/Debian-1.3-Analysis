# LaTeX2HTML 95.1 (Fri Jan 20 1995)
# Associate symbolic labels with physical files.

$external_labels{"traceback"} ="$URL/node21.html"; 
$external_labels{"literals"} ="$URL/node14.html"; 
$external_labels{"lambda"} ="$URL/node50.html"; 
$external_labels{"execframes"} ="$URL/node29.html"; 
$external_labels{"dict"} ="$URL/node38.html"; 
$external_labels{"exec"} ="$URL/node66.html"; 
$external_labels{"function"} ="$URL/node72.html"; 
$external_labels{"primaries"} ="$URL/node40.html"; 
$external_labels{"print"} ="$URL/node58.html"; 
$external_labels{"calls"} ="$URL/node44.html"; 
$external_labels{"global"} ="$URL/node64.html"; 
$external_labels{"access"} ="$URL/node65.html"; 
$external_labels{"Booleans"} ="$URL/node50.html"; 
$external_labels{"types"} ="$URL/node21.html"; 
$external_labels{"specialnames"} ="$URL/node22.html"; 
$external_labels{"class"} ="$URL/node73.html"; 
$external_labels{"import"} ="$URL/node63.html"; 
$external_labels{"try"} ="$URL/node71.html"; 

1;

