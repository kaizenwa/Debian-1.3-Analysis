# LaTeX2HTML 95.1 (Fri Jan 20 1995)
# Associate image original text (scrambled) with physical files.

$key = q/{tabular}|l|l|l|l|hlineCodeblocktype;SPM_amp;Globalnamespace;SPM_amp;Localnamespace;SPM_amp;NoteshlineModule;SPM_amp;n.s.forthismodule;SPM_amp;sameasglobal;SPM_amp;Script;SPM_amp;n.s.for<verb_mark>190<verb_mark>;SPM_amp;sameasglobal;SPM_amp;Interactivecommand;SPM_amp;n.s.for<verb_mark>191<verb_mark>;SPM_amp;sameasglobal;SPM_amp;Classdefinition;SPM_amp;globaln.s.ofcontainingblock;SPM_amp;newn.s.;SPM_amp;Functionbody;SPM_amp;globaln.s.ofcontainingblock;SPM_amp;newn.s.;SPM_amp;Stringpassedto<verb_mark>192<verb_mark>statement;SPM_amp;globaln.s.ofcobtainingblock;SPM_amp;localn.s.ofcontainingblock;SPM_amp;(1)Stringpassedto<verb_mark>193<verb_mark>;SPM_amp;globaln.s.ofcaller;SPM_amp;localn.s.ofcaller;SPM_amp;(1)Filereadby<verb_mark>194<verb_mark>;SPM_amp;globaln.s.ofcaller;SPM_amp;localn.s.ofcaller;SPM_amp;(1)Expressionreadby<verb_mark>195<verb_mark>;SPM_amp;globaln.s.ofcaller;SPM_amp;localn.s.ofcaller;SPM_amp;hline{tabular}/;
$cached_env_img{$key} ='<IMG  ALIGN=BOTTOM ALT="" SRC="img2.gif">'; 
$key = q/{tabular}|l|l|hline<verb_mark>17<verb_mark>emnewline;SPM_amp;Ignored<verb_mark>18<verb_mark>;SPM_amp;Backslash(<verb_mark>19<verb_mark>)<verb_mark>20<verb_mark>;SPM_amp;Singlequote(<verb_mark>21<verb_mark>)<verb_mark>22<verb_mark>;SPM_amp;Doublequote(<verb_mark>23<verb_mark>)<verb_mark>24<verb_mark>;SPM_amp;ASCIIBell(BEL)<verb_mark>25<verb_mark>;SPM_amp;ASCIIBackspace(BS)%<verb_mark>27<verb_mark>;SPM_amp;ASCIIFormfeed(FF)<verb_mark>28<verb_mark>;SPM_amp;ASCIILinefeed(LF)<verb_mark>29<verb_mark>;SPM_amp;ASCIICarriageReturn(CR)<verb_mark>30<verb_mark>;SPM_amp;ASCIIHorizontalTab(TAB)<verb_mark>31<verb_mark>;SPM_amp;ASCIIVerticalTab(VT)<verb_mark>32<verb_mark>emooo;SPM_amp;ASCIIcharacterwithoctalvalueemooo<verb_mark>33<verb_mark>emxx...;SPM_amp;ASCIIcharacterwithhexvalueemxx...hline{tabular}/;
$cached_env_img{$key} ='<IMG  ALIGN=BOTTOM ALT="" SRC="img1.gif">'; 

1;

