# Print names that are at least 14 chars long, sorted by ascending length

import glob

f0 = glob.glob("*")
f1 = filter(lambda x: len(x) >= 14, f0)
f2 = map(lambda x: (len(x), x), f1)
f2.sort()
for item in f2: print "%3d %s" % item
