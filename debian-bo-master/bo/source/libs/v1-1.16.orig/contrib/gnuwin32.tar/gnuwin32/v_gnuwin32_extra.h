#ifndef V_GNUWIN32_EXTRA_H
#define V_GNUWIN32_EXTRA_H

#include <windows.h>

#define MDIS_ALLCHILDSTYLES	0x1
#define WM_CTLCOLOR		0x19

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

HWND WINAPI GetActiveWindow( void );

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // !V_GNUWIN32_EXTRA_H
