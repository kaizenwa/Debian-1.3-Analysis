All you should have to do is copy makefile and the h file into your
v\srcwin directory and run make.

If it doesn't work, let me know.

~Evangelo Prodromou
evangelo@endcontsw.com