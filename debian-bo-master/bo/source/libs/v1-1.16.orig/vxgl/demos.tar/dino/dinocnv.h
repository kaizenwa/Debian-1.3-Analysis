//	dinocnv.h:	Header for DinoCanvasPane class
//=======================================================================

#ifndef DinoCNV_H
#define DinoCNV_H

#include "../vbglcnv.h"

    class DinoCanvasPane : public vBaseGLCanvasPane
      {
      public:		//---------------------------------------- public
	DinoCanvasPane(unsigned int vGLmode = vGL_Default);
	virtual ~DinoCanvasPane();

	virtual void graphicsInit(void);

	void Spin();

	// Scrolling
	virtual void HPage(int, int);
	virtual void VPage(int, int);

	virtual void HScroll(int);
	virtual void VScroll(int);

	// Events
	virtual void MouseDown(int, int, int);
	virtual void MouseUp(int, int, int);
	virtual void MouseMove(int, int, int);

	virtual void Redraw(int, int, int, int); // Expose/redraw event
	virtual void Resize(int, int);		// Resize event

      protected:	//--------------------------------------- protected

      private:		//--------------------------------------- private
	int _what;
      };
#endif
