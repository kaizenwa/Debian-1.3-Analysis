#include "message.h"

String const &Message::getprogname () const
{
    return (pname);
}
