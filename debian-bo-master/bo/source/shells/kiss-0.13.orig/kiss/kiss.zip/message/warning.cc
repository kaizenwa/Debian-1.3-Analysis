#include "message.h"
#include <stdio.h>
#include <stdarg.h>

void Message::warning (char const *fmt, ...) const
{
    va_list
	args;

    va_start (args, fmt);
    fflush (stdout);
    fflush (stderr);

    fprintf (stderr, "%s: ", pname.get ());
    vfprintf (stderr, fmt, args);
    fputc ('\n', stderr);
    
    fflush (stderr);
}
