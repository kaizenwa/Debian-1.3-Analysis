#ifndef _MESSAGE_H_
#define _MESSAGE_H_

#include "../string/string.h"

class Message
{
    public:
	void setprogname (String const &progname);
	String const &getprogname () const;

	void debugmsg (char const *fmt, ...) const;
	void debugmsg (int ch) const;
	void error (char const *fmt, ...) const;
	void print (char const *fmt, ...) const;
	void warning (char const *fmt, ...) const;

    private:
	static String pname;
};

#endif
