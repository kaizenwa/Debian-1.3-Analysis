#include "message.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h> 

void Message::error (char const *fmt, ...) const
{
    va_list
	args;

    va_start (args, fmt);
    fflush (stdout);

    fprintf (stderr, "%s: ", pname.get ());
    vfprintf (stderr, fmt, args);
    fputc ('\n', stderr);
    
    exit (1);
}
