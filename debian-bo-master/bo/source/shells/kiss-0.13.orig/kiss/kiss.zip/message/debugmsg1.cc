#include "message.h"

void Message::debugmsg (int ch) const
{
    static char
	str [2];

    str [0] = (char) ch;
    debugmsg (str);
}
