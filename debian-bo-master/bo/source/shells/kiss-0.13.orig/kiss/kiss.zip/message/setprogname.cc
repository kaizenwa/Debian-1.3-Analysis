#include "message.h"
#include "../config.h" 
#include <string.h> 

void Message::setprogname (String const &p)
{
    register char
	*cp;
    char
	progname [LINELEN];

    strcpy (progname, p.get ());
    if ( (cp = strrchr (progname, '/')) && *(cp + 1) )
	cp++;
    else
	cp = progname;
    
    pname.set (cp);
}
