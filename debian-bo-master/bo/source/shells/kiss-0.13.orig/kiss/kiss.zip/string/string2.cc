#include "string.h"

String::String (String const &other)
{
    copy (other);
}
