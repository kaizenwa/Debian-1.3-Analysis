#include "string.h"
#include <string.h> 

int String::operator== (String const &other) const
{
    return (! strcmp (data, other.data));
}
