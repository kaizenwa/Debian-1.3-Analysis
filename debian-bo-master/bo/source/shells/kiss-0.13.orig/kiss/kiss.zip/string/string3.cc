#include "string.h"

String::String (char const *s)
{
    data = 0;
    set (s);
}
