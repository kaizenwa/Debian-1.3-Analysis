#include "string.h"

String const &String::operator= (String const &other)
{
    if (this != &other)
    {
	destroy ();
	copy (other);
    }
    return (*this);
}
