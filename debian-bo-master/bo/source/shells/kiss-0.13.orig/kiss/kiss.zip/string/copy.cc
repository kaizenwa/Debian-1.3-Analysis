#include "string.h"
#include <string.h> 

void String::copy (String const &other)
{
    data = other.data ? strdup (other.data) : 0;
}
