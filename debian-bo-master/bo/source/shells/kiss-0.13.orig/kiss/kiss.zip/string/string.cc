#include "string.h"

String::~String ()
{
    destroy ();
}
