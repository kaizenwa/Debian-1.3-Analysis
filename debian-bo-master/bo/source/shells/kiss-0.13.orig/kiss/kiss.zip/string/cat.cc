#include "string.h"
#include <string.h>
#include <malloc.h>

void String::cat (String const &other)
{
    data = (char *) realloc (data, strlen (data) + strlen (other.data) + 1);
    strcat (data, other.data);
}
		    
