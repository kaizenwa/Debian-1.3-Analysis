#include "string.h"
#include <string.h>

void String::set (char const *s)
{
    destroy ();
    data = strdup (s);
}
