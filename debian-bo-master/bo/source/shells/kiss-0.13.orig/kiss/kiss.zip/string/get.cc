#include "string.h"

char const *String::get () const
{
    return (data);
}
