#include "string.h"

String::String ()
{
    data = 0;
}
