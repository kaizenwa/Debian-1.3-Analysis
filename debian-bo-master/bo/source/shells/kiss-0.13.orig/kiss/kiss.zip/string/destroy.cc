#include "string.h"

void String::destroy ()
{
    delete data;
    data = 0;
}
