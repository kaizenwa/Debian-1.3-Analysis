#include "string.h"

Storable *String::dup () const
{
    return (new String (*this));
}
