#include "string.h"

void String::cat (int ch)
{
    static char
	buf [2];

    buf [0] = (char) ch;
    cat ( (String) buf);
}
