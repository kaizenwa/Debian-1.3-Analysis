#include "inpterm.h"

Inpterm const &Inpterm::operator= (Inpterm const &other)
{
    if (this != &other)
    {
	destroy ();
	copy (other);
    }
    return (*this);
}
