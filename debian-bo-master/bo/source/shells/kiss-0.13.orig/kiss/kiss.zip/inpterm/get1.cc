#include "inpterm.h"

String Inpterm::get () const
{
    String
	ret;

    for (register int i = 0; i < elem->nstored (); i++)
    {
	register String const
	    *s;
	s = (String const *) elem->get (i);
	ret.cat (*s);
	if (i < elem->nstored () - 1)
	    ret.cat (' ');
    }

    return (ret);
}
