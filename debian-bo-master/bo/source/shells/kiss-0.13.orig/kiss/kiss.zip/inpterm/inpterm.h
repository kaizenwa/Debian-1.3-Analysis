#ifndef _INPTERM_H_
#define _INPTERM_H_

#include "../message/message.h"
#include "../storable/storable.h"
#include "../string/string.h" 
#include "../storage/storage.h"

class Inpterm: public Message, public Storable
{
    public:
	~Inpterm ();
	Inpterm ();
	Inpterm (Inpterm const &other);

	Inpterm const &operator= (Inpterm const &other);

	Storable *dup () const;

	void set (String const &s);
	int nelem () const;
    
	String const &get (int index) const;
	String get () const;

    private:
	void copy (Inpterm const &other);
	void destroy ();

	Storage *elem;
};

#endif
