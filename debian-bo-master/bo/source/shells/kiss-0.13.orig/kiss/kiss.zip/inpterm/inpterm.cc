#include "inpterm.h"

Inpterm::~Inpterm ()
{
    destroy ();
}
