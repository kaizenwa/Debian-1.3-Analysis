#include "inpterm.h"

void Inpterm::destroy ()
{
    delete elem;
}
