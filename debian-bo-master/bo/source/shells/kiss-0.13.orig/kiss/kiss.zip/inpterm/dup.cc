#include "inpterm.h"

Storable *Inpterm::dup () const
{
    return (new Inpterm (*this));
}
