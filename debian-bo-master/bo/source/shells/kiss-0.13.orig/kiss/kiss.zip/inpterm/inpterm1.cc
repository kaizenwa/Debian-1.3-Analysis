#include "inpterm.h"

Inpterm::Inpterm ()
{
    elem = new Storage;
}
