#include "inpterm.h"
#include <string.h>

void Inpterm::copy (Inpterm const &other)
{
    *elem = *other.elem;
}
