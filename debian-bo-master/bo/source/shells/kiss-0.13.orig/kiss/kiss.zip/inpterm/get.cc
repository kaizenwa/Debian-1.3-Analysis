#include "inpterm.h"

String const &Inpterm::get (int index) const
{
    if (index < 0 || index >= elem->nstored ())
	return ("");
    return ( (String const &) *elem->get (index));
}
