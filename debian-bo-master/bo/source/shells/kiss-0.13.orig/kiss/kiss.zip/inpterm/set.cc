#include "inpterm.h"
#include "../config.h"

#include <ctype.h> 
#include <string.h>

void Inpterm::set (String const &s)
{
    char
	buf [LINELEN];
    register char
	*start,
	*end;

    start = (char *) s.get ();
    while (isspace (*start))
	start++;
    if (! *start)
	return;
    
    strcpy (buf, start);
    
    if ( (start = strchr (buf, '#')) )
    {
	if (start == buf || *(start - 1) != '\\')
	{
	    *start = '\0';
	    if (! buf [0])
		return;
	}
    }
    
    for (start = buf, end = buf; *end; end++)
    {
	if (*end == ' ')
	{
	    String
		*nstr = new String;
	    
	    *end = '\0';
	    nstr->set (start);
	    *end = ' ';
	    start = end + 1;
	    elem->add (nstr);
	    delete nstr;
	}
    }
}
