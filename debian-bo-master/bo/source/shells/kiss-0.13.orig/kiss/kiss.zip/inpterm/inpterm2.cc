#include "inpterm.h"

Inpterm::Inpterm (Inpterm const &other)
{
    elem = new Storage;
    copy (other);
}
