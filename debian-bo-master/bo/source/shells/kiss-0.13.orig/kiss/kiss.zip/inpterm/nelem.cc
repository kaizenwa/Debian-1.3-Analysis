#include "inpterm.h"

int Inpterm::nelem () const
{
    return (elem->nstored ());
}
