#ifndef _CONFIG_H_
#define _CONFIG_H_

// max name of a file, exclusive the directory spec
#define MAXNAMELEN	256
// max name of a file, inclusive directory spec
#define MAXPATH		1024
// max length of an input line
#define LINELEN		10240

// the device that represents standard input when stdin is redirected
#define TTYLINE		"/dev/tty"

// max # of arguments to any command
#define MAXARGC		1024

// default buffer length in file I/O
#define BUFLEN		512

// # of lines on terminal.. for more command
#define TERMLINES	24

// max nesting depth of shell
#define MAXDEPTH	20

#endif
