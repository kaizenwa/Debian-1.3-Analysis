#include "any.h"

void Any::usage () const
{
}
