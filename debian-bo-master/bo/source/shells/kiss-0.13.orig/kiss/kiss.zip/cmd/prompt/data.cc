#include "prompt.h"

char *Prompt::promptstring;
