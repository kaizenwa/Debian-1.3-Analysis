#include "more.h"

void More::usage () const
{
    warning ("usage: more [file(s)]");
}
