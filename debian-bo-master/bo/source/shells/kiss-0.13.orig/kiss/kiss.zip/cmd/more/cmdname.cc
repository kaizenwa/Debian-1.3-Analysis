#include "more.h"

String More::cmdname () const
{
    return ("more");
}
