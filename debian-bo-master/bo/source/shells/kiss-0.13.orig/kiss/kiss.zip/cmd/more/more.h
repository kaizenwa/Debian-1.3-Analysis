#ifndef _MORE_H_
#define _MORE_H_

#include "../cmd.h"
#include <stdio.h>

class More: public Cmd
{
    public:
	String cmdname () const;
	void usage () const;
	int run () const;

    private:
	void domore (FILE *inf) const;
};

#endif
