#include "prompt.h"

void Prompt::usage () const
{
    warning ("usage: prompt promptstring, where substrings mean:\n"
	     "    %%/ - current working directory\n"
	     "    \\n - newline character");
}
