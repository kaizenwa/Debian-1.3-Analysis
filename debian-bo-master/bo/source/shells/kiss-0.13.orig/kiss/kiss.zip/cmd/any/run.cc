#include "any.h"
#include <unistd.h>

int Any::run () const
{
    execvp (getargv (0).get (), getargv ());
    warning ("%s: command not found", getargv (0).get ());
    return (1);
}
