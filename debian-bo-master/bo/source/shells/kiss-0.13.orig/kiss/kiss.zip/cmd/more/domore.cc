#include "more.h"
#include "../../config.h" 
#include <stdio.h>
#include <string.h> 

void More::domore (FILE *inf) const
{
    register int
	lines = 0;
    char
	buf [BUFLEN];

    while (fgets (buf, BUFLEN - 1, inf))
    {
	print ("%s", buf);
	if (strchr (buf, '\n'))
	{
	    lines++;
	    if (lines == TERMLINES)
	    {
		lines = 0;
		print ("--more--");
		fgets (buf, BUFLEN - 1, inputfile ());
		if (buf [0] == 'q')
		    return;
	    }
	}
    }
}
