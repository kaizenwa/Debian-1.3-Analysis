#include "more.h"

int More::run () const
{
    register int
	ret = 0;
	
    if (getargc () == 1)
    {
	if (! redirected ())
	{
	    warning ("more: cannot take both input and info from same stdin");
	    return (1);
	}
	domore (stdin);
    }
    else
    {
	for (register int i = 1; i < getargc (); i++)
	{
	    register FILE
		*inf = fopen (getargv (i).get (), "r");

	    if (! inf)
		ret++;
	    else
	    {
		domore (inf);
		fclose (inf);
	    }
	}
    }

    return (ret);
}
