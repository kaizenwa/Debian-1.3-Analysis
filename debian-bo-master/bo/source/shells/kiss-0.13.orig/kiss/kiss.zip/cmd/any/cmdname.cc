#include "any.h"

String Any::cmdname () const
{
    return ("any non-builtin command");
}
