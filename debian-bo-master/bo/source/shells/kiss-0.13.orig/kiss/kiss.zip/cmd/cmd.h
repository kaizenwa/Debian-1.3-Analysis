#ifndef _CMD_H_
#define _CMD_H_

#include "../config.h" 
#include "../program/program.h"
#include "../string/string.h" 

class Cmd: public Program
{
    public:
	virtual ~Cmd ();

	virtual String cmdname () const = 0;
	virtual void usage () const = 0;
	virtual int run () const = 0;
};

#endif
