#ifndef _PROMPT_H_
#define _PROMPT_H_

#include "../cmd.h"
#include <stdio.h>

class Prompt: public Cmd
{
    public:
	String cmdname () const;
	void usage () const;
	int run () const;

	void showprompt () const;
    
    private:
	static char *promptstring;
};

#endif
