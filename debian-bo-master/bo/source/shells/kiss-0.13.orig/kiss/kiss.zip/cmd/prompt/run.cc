#include "prompt.h"
#include <string.h>

int Prompt::run () const
{
    if (getargc () != 2)
    {
	usage ();
	return (1);
    }
    
    if (promptstring)
	delete (promptstring);
    
    promptstring = strdup (getargv (1).get ());
    return (0);
}
