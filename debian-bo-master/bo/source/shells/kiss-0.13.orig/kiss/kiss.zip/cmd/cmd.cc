#include "cmd.h"

Cmd::~Cmd ()
{
}
