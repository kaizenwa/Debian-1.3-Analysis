#include "prompt.h"

String Prompt::cmdname () const
{
    return ("prompt");
}
