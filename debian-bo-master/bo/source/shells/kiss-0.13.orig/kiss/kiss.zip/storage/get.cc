#include "storage.h"

Storable *Storage::get (int index)
{
    if (index < 0 || index >= nstore)
	return (0);
    return (store [index]);
}
