#include "storage.h"

int Storage::nstored () const
{
    return (nstore);
}
