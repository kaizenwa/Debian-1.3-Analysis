#include "storage.h"

void Storage::copy (Storage const &other)
{
    nstore = other.nstore;
    store = new Storable* [nstore];

    for (register int i = 0; i < nstore; i++)
	store [i] = other.store [i]->dup ();
}
