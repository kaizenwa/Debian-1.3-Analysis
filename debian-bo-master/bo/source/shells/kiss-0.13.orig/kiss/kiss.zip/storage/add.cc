#include "storage.h"
#include <malloc.h>

void Storage::add (Storable const *s)
{
    store = (Storable **) realloc (store,
				   (nstore + 1) * sizeof (Storable *));
    store [nstore++] = s->dup ();
}
