#include "storage.h"

Storage::~Storage ()
{
    destroy ();
}
