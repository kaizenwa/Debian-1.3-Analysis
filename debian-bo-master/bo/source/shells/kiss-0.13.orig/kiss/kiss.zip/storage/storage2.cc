#include "storage.h"

Storage::Storage (Storage const &other)
{
    copy (other);
}
