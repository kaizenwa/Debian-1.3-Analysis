#ifndef _STORAGE_H_
#define _STORAGE_H_

#include "../storable/storable.h" 

class Storage: public Storable
{
    public:
	~Storage ();
	Storage ();
	Storage (Storage const &other);

	Storable *dup () const;

	void add (Storable const *s);
	Storable *get (int index);
	int nstored () const;

    private:
	void copy (Storage const &other);
	void destroy ();
    
	Storable **store;
	int nstore;
};
#endif
