#include "storage.h"

Storable *Storage::dup () const
{
    return (new Storage (*this));
}
