#include "storage.h"

void Storage::destroy ()
{
    for (register int i = 0; i < nstore; i++)
	delete store [i];
    delete store;
    store = 0;
    nstore = 0;
}
