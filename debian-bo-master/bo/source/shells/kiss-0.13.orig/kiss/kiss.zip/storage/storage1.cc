#include "storage.h"

Storage::Storage ()
{
    store = 0;
    nstore = 0;
}
