#include "input.h"

char Input::buf [LINELEN];
char *Input::bufp;

Input::Input ()
{
    if (! bufp)
	bufp = buf;
}
