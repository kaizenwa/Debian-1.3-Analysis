#include "input.h"
#include "../cmd/prompt/prompt.h"
#include <stdio.h>

void Input::read ()
{
    static Prompt
	prompt;

    prompt.showprompt ();
    gets (buf);
}
