#ifndef _INPUT_H_
#define _INPUT_H_

#include "../program/program.h" 
#include "../config.h"

class Input: public Program
{
    public:
	Input ();

	void read ();

    private:
	static char buf [LINELEN];
	static char *bufp;
};

#endif
