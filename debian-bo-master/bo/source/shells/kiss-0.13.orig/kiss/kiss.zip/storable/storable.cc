#include "storable.h"

Storable::~Storable ()
{
}
