#ifndef _STORABLE_H_
#define _STORABLE_H_

class Storable
{
    public:
	virtual ~Storable ();
	virtual Storable *dup () const = 0;
};

#endif
