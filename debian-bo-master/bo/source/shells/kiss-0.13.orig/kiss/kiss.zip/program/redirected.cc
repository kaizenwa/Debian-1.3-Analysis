#include "program.h"
#include <unistd.h>

int Program::redirected () const
{
    return (! isatty (fileno (stdin)));
}
