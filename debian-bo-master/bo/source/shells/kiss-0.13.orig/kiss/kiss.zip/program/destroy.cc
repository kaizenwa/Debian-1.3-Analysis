#include "program.h"

void Program::destroy ()
{
    delete av;
}
