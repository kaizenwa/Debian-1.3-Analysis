#include "program.h"

String const &Program::getargv (int index) const
{
    String
	*tmp;
    
    if (index < 0 || index >= av->nstored ())
	return ("");
    tmp = (String *) av->get (index);
    return (*tmp);
}
