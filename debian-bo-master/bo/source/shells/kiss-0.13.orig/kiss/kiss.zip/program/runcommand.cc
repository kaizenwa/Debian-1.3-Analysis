#include "program.h"
#include "../cmdtab/cmdtab.h"

int Program::runcommand () const
{
    register Cmd
	*cmdp;
    static Cmdtab
	tab;
    
    debugmsg ("KISS command: ");
    for (register int i = 0; i < av.nstored (); i++)
    {
	String
	    *sp = (String *) av->get (i);
	debugmsg (sp->get ());
	debugmsg (' ');
    }
    debugmsg ('\n');

    cmdp = tab.find (* ((String *) av->get (0)) );
    return (cmdp->run ());
}
