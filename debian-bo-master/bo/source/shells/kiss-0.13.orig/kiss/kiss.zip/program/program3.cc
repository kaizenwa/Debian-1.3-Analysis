#include "program.h"

Program::Program (Program const &other)
{
    copy (other);
}
