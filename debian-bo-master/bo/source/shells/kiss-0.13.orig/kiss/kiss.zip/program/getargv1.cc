#include "program.h"
#include "../config.h"

char const *const *Program::getargv () const
{
    static char const
	*base [MAXARGC];

    for (register int i = 0; i < av.nstored (); i++)
    {
	String
	    *sp = (String *) av.get (i);
	base [i] = sp->get ();
    }
    base [i] = 0;

    return (base);
}
