#include "program.h"
#include "../version.h" 
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

static char
    *msg [] =
    {
	"Keep It Simple Stupid!",
	"Karel's Incredibly Simple Shell",
	"Karel's Interactive Simple Shell",
	"Karel's Idiotic or Sophisticated Shell?",
    };

void Program::banner () const
{
    register char
	*m;

    srand ( (unsigned) time (0) );
    m = msg [rand () % (sizeof (msg) / sizeof (char *))];

    printf ("\n"
	    "%s V" VER "\n"
	    "Copyright (c) 1994 ICCE / Karel Kubat. All rights reserved.\n"
	    "Permission granted to distribute and / or modify this program, "
						    "if the \n"
	    "copyright notice remains intact.\n"
	    "\n"
	    "%s by Karel Kubat (karel@icce.rug.nl).\n"
	    "\n"
	    , m, getprogname ().get ());
}
