#include "program.h"
#include "../config.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <unistd.h> 

void Program::setlevel () const
{
    static char
	id [] = "KISSDEPTH";
    register char
	*cp;
    register int
	depth;
    static char
	buf [BUFLEN];

    if (! (cp = getenv (id)) )
	cp = "0";

    debugmsg ("%s = %s\n", id, cp);
    
    if ( (depth = atoi (cp)) >= MAXDEPTH )
	error ("max nesting level exceeded");
    
    sprintf (buf, "%s=%d", id, depth + 1);
    putenv (buf);
}

    
