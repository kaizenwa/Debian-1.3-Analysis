#include "program.h"
#include <string.h>

int Program::isshell () const
{
    return (getprogname () == "kiss");
}
