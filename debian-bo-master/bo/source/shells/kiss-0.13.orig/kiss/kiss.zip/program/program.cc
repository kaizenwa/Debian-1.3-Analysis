#include "program.h"

Program::~Program ()
{
    destroy ();
}
