#include "program.h"

int Program::getargc () const
{
    return (av->nstored ());
}
