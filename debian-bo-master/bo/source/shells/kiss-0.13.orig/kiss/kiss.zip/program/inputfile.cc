#include "program.h"
#include "../config.h"

FILE *Program::inputfile () const
{
    static FILE
	*inf;

    if (! inf)
    {
	if (redirected ())
	{
	    if ( (inf = fopen (TTYLINE, "r")) )
		return (inf);
	}
	inf = stdin;
    }
    return (inf);
}
