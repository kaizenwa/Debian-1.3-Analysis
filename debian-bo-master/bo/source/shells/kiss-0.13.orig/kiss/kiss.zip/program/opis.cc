#include "program.h"

Program const &Program::operator= (Program const &other)
{
    if (&other != this)
    {
	destroy ();
	copy (other);
    }
    return (*this);
}
