#include "program.h"

Program::Program ()
{
    av = new Storage;
}
