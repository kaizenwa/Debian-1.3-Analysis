#include "program.h"
#include <string.h>

void Program::arglist (int argc, char const *const *argv)
{
    String
	tmp;
    
    delete av;
    av = new Storage;

    for (register int i = 0; i < argc; i++)
    {
	tmp.set (argv [i]);
	av->add (&tmp);
    }
}
    
