#include "program.h"
#include <string.h>

void Program::copy (Program const &other)
{
    av = new Storage (*other.av);
}
