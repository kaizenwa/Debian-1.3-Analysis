#include "program.h"

Program::Program (int argc, char const *const *argv)
{
    av = new Storage;
    arglist (argc, argv);
}
