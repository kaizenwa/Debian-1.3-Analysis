#include "cmdtab.h"

#include "../cmd/any/any.h" 
#include "../cmd/more/more.h"
#include "../cmd/prompt/prompt.h" 

Cmd *Cmdtab::find (String const &name)
{
    static More
	more_cmd;
    static Prompt
	prompt_cmd;
    static Any
	any_cmd;
    static Cmd
	*cmds [] =
	{
	    &more_cmd,
	    &prompt_cmd,
	};

    for (register int i = 0; i < sizeof (cmds) / sizeof (Cmd *); i++)
	if (name == cmds [i]->cmdname ())
	    return (cmds [i]);

    return (&any_cmd);
}
