#ifndef _CMDTAB_H_
#define _CMDTAB_H_

#include "../cmd/cmd.h"
#include "../string/string.h" 

class Cmdtab
{
    public:
	Cmd *find (String const &name);
};

#endif
