#include "linux.h"

#define LD_SWITCH_SYSTEM -Bstatic
