/* Synched up with: FSF 19.31. */

