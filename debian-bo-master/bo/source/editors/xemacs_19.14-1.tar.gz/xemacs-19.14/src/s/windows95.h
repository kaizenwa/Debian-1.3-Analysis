/* Synched up with: FSF 19.31. */

/* System description file for Windows 95.  */

#include "windowsnt.h"

#define WINDOWS95
