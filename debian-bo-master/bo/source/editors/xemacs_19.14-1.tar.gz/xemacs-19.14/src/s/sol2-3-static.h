/* Synched up with: Not in FSF. */

#include "sol2-3.h"

#define DONT_INCLUDE_SOL2_H
#include "sol2-static.h"

