/* Synched up with: FSF 19.31. */

#include "sunos4-1.h"
/* #undef SYSTEM_MALLOC */
