/* Synched up with: Not in FSF. */

#include "decosf3-1.h"
