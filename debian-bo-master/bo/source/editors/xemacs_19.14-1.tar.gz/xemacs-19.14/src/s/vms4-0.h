/* Synched up with: FSF 19.31. */

#include "vms.h"
#define VMS4_0
