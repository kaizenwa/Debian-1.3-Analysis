/* Fake unistd.h: config.h already provides most of the relevant things. */
