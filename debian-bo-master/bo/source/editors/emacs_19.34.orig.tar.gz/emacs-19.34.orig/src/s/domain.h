#include "bsd4-3.h"

/* Inhibit using -X, which is the default.  */
#define LD_SWITCH_SYSTEM
