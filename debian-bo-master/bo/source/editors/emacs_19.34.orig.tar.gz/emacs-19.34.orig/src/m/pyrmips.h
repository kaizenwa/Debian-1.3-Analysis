/* Configuration file for the Pyramid machine that uses the MIPS cpu.  */
/* This does not fully work.  */

#include "m-pyramid.h"

#define SYSTEM_MALLOC
#define HAVE_ALLOCA
#define CANNOT_DUMP

