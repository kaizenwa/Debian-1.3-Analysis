#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/in.h>
#include <linux/route.h>
#include <netdb.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <asm/bitops.h>
#include <linux/netlink.h>

int flag_rtcache=0;
int flag_rtlocal=0;
int flag_rtrules=0;

#define _PATH_PROCNET_ROUTE	"/proc/net/route"
#define _PATH_PROCNET_RTCACHE	"/proc/net/rt_cache"
#define _PATH_PROCNET_RTLOCAL	"/proc/net/rt_local"
#define _PATH_PROCNET_RTRULES	"/proc/net/rt_rules"

int scan_number(char *arg, long *val)
{
	char * ptr;
	if (!arg || !*arg)
		return -1;
	*val = strtol(arg, &ptr, 0);
	if (!ptr || ptr == arg || *ptr)
		return -1;
	return 0;
}

int scan_class(char *arg, long *val)
{
	if (!strcmp(arg, "local")) {
		*val = RT_CLASS_LOCAL;
		return 0;
	}
	if (!strcmp(arg, "main")) {
		*val = RT_CLASS_MAIN;
		return 0;
	}
	if (!strcmp(arg, "default")) {
		*val = RT_CLASS_DEFAULT;
		return 0;
	}
	if (!strcmp(arg, "any") || !strcmp(arg, "unspec")) {
		*val = RT_CLASS_UNSPEC;
		return 0;
	}
	return scan_number(arg, val);
}



static __inline__ unsigned rt_mask(int logmask)
{
	if (logmask == 0)
		return 0;
	return htonl(~((1<<(32-logmask))-1));
}


int resolve(char *name, long *addr)
{
	int acc;
	char *cp;
	unsigned char *ap = (unsigned char*)addr;
	int i;

	*addr = 0;
	for (cp=name, i=0; *cp; cp++) {
		if (*cp <= '9' && *cp >= '0') {
			ap[i] = 10*ap[i] + (*cp-'0');
			continue;
		}
		if (*cp == '.') {
			if (++i > 3)
				return -1;
			continue;
		}
	}
	return 0;
}

static __inline__ int rt_logmask(unsigned mask)
{
	if (!(mask = ntohl(mask)))
		return 0;
	return 32 - ffz(~mask);
}

void print_prefix(char *name, unsigned addr, unsigned mask)
{
	unsigned char *ad = (unsigned char*)&addr;
	int	masklen = rt_logmask(mask);

	if (masklen < 0 || masklen >= 32)
		sprintf(name, "%d.%d.%d.%d", ad[0], ad[1], ad[2], ad[3]);
	else if (masklen == 0)
		sprintf(name, "default");
	else if (masklen <= 8)
		sprintf(name, "%d/%d", ad[0], masklen);
	else if (masklen <= 16)
		sprintf(name, "%d.%d/%d", ad[0], ad[1], masklen);
	else if (masklen <= 24)
		sprintf(name, "%d.%d.%d/%d", ad[0], ad[1], ad[2], masklen);
	else
		sprintf(name, "%d.%d.%d.%d/%d", ad[0], ad[1], ad[2], ad[3], masklen);
}

void print_gw(char *name, unsigned addr)
{
	unsigned char *ad = (unsigned char*)&addr;

	if (addr)
		sprintf(name, "%d.%d.%d.%d", ad[0], ad[1], ad[2], ad[3]);
	else
		strcpy(name, "*");
}

void reserror(char *text)
{
	fprintf(stderr, "Invalid IP address: %s\n", text);
}


int             skfd = -1;


static void usage(void)
{
	fprintf(stderr,
"Usage:\tiproute [ -c | -r | -l ]\n"
"\tiproute [ add | del ] [ PREFIX | NET mask MASK ] [ tos TOS ]\n"
"\t        [ nat NET ] [ class CLASS ] INFO\n"
"\tiproute [ addrule | delrule ] [ from PREFIX ] [ to PREFIX ] [ tos TOS ]\n"
"\t        [ dev DEVICE ] [ masq | drop | reject | prohibit | nat NET ]\n"
"\t        [ pref PREFERENCE ] [ class CLASS | INFO ]\n"
"\n"
"PREFIX := NET[/PREFIXLEN]\n"
"INFO := [ gw GATEWAY ] [ dev DEVICE ] [ metric METRIC ]\n"
"        [ mtu MTU ] [ irtt RTT ] [ window WINDOW ] FLAGS\n"
"FLAGS := [ static ] [ reject | throw ] [ noptmudisc ]\n"
"         [ noforward ] [ local ] [ interface | broadcast ]\n"
		);
	exit(-1);
}


static void rt_print(char * proc_table)
{
	char            buff[128], iface[16];
	char            flags[16];
	char		gate_addr[16], net_addr[32];
	unsigned	net, gate, mask;
	FILE           *fp;
	unsigned	iflags;
	int             refcnt, use, metric;
	int		mtu, window;
	int		tos, class;
	int		irtt;

	printf("Kernel routing table\n");
	printf("Prefix            TOS Cl  Gateway         "
	       "Flags MTU    Window IRTT   Iface\n");

	if ((fp = fopen(proc_table, "r")) == NULL) {
		perror(proc_table);
		return;
	}
	fread(buff, 128, 1, fp);
	while (fread(buff, 128, 1, fp) == 1) {
		mtu = window = irtt = tos = class = 0;
		sscanf(buff, "%s %X %X %X %d %d %d %X %d %d %d %x %x",
		       iface, &net, &gate,
		       &iflags, &refcnt, &use, &metric, &mask,
		       &mtu, &window, &irtt, &tos, &class);

		print_prefix(net_addr, net, mask);
		print_gw(gate_addr, gate);

		/* Decode the flags. */

		flags[0] = '\0';
		if (iflags & RTF_MAGIC)
			strcat(flags, "-");
		if (iflags & RTF_REJECT)
			strcat(flags, "!");
		if (iflags & RTF_THROW)
			strcat(flags, "~");

		if (iflags & RTF_GATEWAY)
			strcat(flags, "G");
		if (iflags & RTF_DYNAMIC)
			strcat(flags, "D");
		if (iflags & RTF_MODIFIED)
			strcat(flags, "M");

		if (iflags & RTF_LOCAL)
			strcat(flags, "L");
		if (iflags & RTF_NAT)
			strcat(flags, "N");
		if (iflags & RTF_BROADCAST)
			strcat(flags, "B");
		if (iflags & RTF_MULTICAST)
			strcat(flags, "m");
		if (iflags & RTF_INTERFACE)
			strcat(flags, "I");
		if (iflags & RTF_STATIC)
			strcat(flags, "S");
		if (iflags & RTF_NOPMTUDISC)
			strcat(flags, "p");
		if (iflags & RTF_NOFORWARD)
			strcat(flags, "f");

		if (iflags & RTF_XRESOLVE)
			strcat(flags, "X");
		if (iflags & RTF_REINSTATE)
			strcat(flags, "R");

		/* Print the info. */
		printf("%-18s %02X %-3d %-15s %-5s %-6d %-6d %-6d %s\n",
		       net_addr, tos, class, gate_addr, flags,
		       mtu, window, irtt, iface);
	}

	(void) fclose(fp);
}


static void rt_print_rules(void)
{
	char            buff[128], iface[16];
	char		snet_addr[32];
	char		dnet_addr[32];
	unsigned	snet, smask;
	unsigned	dnet, dmask;
	unsigned	srcmap;
	unsigned	flags;
	unsigned	action;
	FILE           *fp;
	int		tos, class;
	int		pref;

	printf("Kernel routing policy rules\n");
	printf("Pref Source             Destination        TOS Iface   Cl\n");

	if ((fp = fopen(_PATH_PROCNET_RTRULES, "r")) == NULL) {
		perror(_PATH_PROCNET_RTRULES);
		return;
	}
	fread(buff, 128, 1, fp);
	while (fread(buff, 128, 1, fp) == 1) {
		sscanf(buff, "%d %X %X %X %X %s %02x %02x %X %X %X",
		       &pref, &snet, &smask, &dnet, &dmask, iface,
		       &tos, &class, &flags, &action, &srcmap);

		print_prefix(snet_addr, snet, smask);
		print_prefix(dnet_addr, dnet, dmask);

		/* Print the info. */
		printf("%4d %-18s %-18s %02X  %-7s %3d",
		       pref, snet_addr, dnet_addr, tos, iface, class);
		switch (action) {
		case RTP_DROP:
			printf(" drop");
			break;
		case RTP_UNREACHABLE:
			printf(" unreach");
			break;
		case RTP_PROHIBIT:
			printf(" prohibit");
			break;
		case RTP_MASQUERADE:
			printf(" masquerade");
			break;
		case RTP_NAT:
		{
			char smap[32];
			print_prefix(smap, srcmap, smask);
			printf(" nat %s", smap);
			break;
		}
		case RTP_GO:
			break;
		default:
			printf(" ?%d", action);
		}
		if (flags & RTRF_LOG)
			printf(" log");
		printf("\n");
	}

	(void) fclose(fp);
}



static void rt_print_cache(void)
{
	char            buff[128], iface[16];
	char            flags[16];
	char		gate_addr[16], net_addr[16], src_addr[16];
	unsigned	net, gate, src;
	FILE           *fp;
	unsigned	iflags;
	int             refcnt, use, metric;
	int		mtu, window;
	int		tos, hh_ref, hh_uptodate;
	int		irtt;

	printf("Kernel routing cache\n");
	printf("Destination     Source        TOS Gateway        "
	       "Flg MTU    Ref Usage   HH Iface\n");

	if ((fp = fopen(_PATH_PROCNET_RTCACHE, "r")) == NULL) {
		perror(_PATH_PROCNET_RTCACHE);
		return;
	}
	fread(buff, 128, 1, fp);
	while (fread(buff, 128, 1, fp) == 1) {
		mtu = window = irtt = tos = hh_ref = hh_uptodate = 0;
		sscanf(buff, "%s %X %X %X %d %d %d %X %d %d %d %02x %d %d",
		       iface, &net, &gate,
		       &iflags, &refcnt, &use, &metric, &src,
		       &mtu, &window, &irtt, &tos, &hh_ref, &hh_uptodate);

		print_gw(net_addr, net);
		print_gw(src_addr, src);
		if (gate == net)
			gate = 0;
		print_gw(gate_addr, gate);

		/* Decode the flags. */

		flags[0] = '\0';
		if (iflags & RTF_DYNAMIC)
			strcat(flags, "D");
		if (iflags & RTF_REJECT)
			strcat(flags, "!");
		if (iflags & RTF_LOCAL)
			strcat(flags, "L");
		if (iflags & RTF_NAT)
			strcat(flags, "N");
		if (iflags & RTF_BROADCAST)
			strcat(flags, "B");
		if (iflags & RTF_MULTICAST)
			strcat(flags, "m");
		if (iflags & RTF_INTERFACE)
			strcat(flags, "I");
		if (iflags & RTCF_DOREDIRECT)
			strcat(flags, "r");
		if (iflags & RTCF_NAT)
			strcat(flags, "n");
		if (iflags & RTCF_MASQ)
			strcat(flags, ">");
		if (iflags & RTCF_DIRECTSRC)
			strcat(flags, "d");
		if (iflags & RTF_NOPMTUDISC)
			strcat(flags, "p");
		if (iflags & RTF_NOFORWARD)
			strcat(flags, "f");

		/* Print the info. */
		printf("%-15s %-14s %02X %-14s %-3s %-6d %-3d %-7d%c%-2d %s\n",
		       net_addr, src_addr, tos, gate_addr, flags,
		       mtu, refcnt, use, hh_uptodate?'*':' ', hh_ref, iface);
	}

	(void) fclose(fp);
}


int scan_prefix(char *target, long *prefix, long *prefixlen)
{
	char *p;

	p = strchr(target, '/');
	if (p) {
		*p++ = 0;
		if (scan_number(p, prefixlen))
			usage();
	} else
		*prefixlen = -1;
	
	if (!strcmp(target, "default")) {
		*prefix = 0;
		*prefixlen = 0;
	} else if (resolve(target, prefix) < 0) {
		reserror(target);
		return (-1);
	}
	return 0;
}

int get_ifindex(char *ifname)
{
	struct ifreq ifr;
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
	if (ioctl(skfd, SIOGIFINDEX, (void*)&ifr) < 0) {
		perror("ioctl(SIOGIFINDEX)");
		exit(-1);
	}
	return ifr.ifr_ifindex;
}

int rt_make(char **args, struct nlmsghdr *nlh, struct in_rtmsg *r)
{
	int prefix_ok = 0;
	long masklen = -1;
	long val;

	if (*args == NULL)
		usage();

	memset((char *)r, 0, sizeof(*r));
	nlh->nlmsg_len = sizeof(*r) + sizeof(*nlh);

	r->rtmsg_flags = RTF_UP;

	while (*args) {
		if (!strcmp(*args, "add") || !strcmp(*args, "del") ||
		    !strcmp(*args, "delete")) {
			long val1;
			if (prefix_ok)
				usage();
			args++;
			if (scan_prefix(*args, &val, &val1))
				usage();
			r->rtmsg_prefix.s_addr = val;
			if (masklen >= 0 && val1 >= 0)
				usage();
			masklen = val1;
			prefix_ok = 1;
			args++;
		}
		if (!strcmp(*args, "metric")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtmsg_metric = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "ifindex")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtmsg_ifindex = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "class")) {
			args++;
			if (scan_class(*args, &val))
				usage();
			r->rtmsg_class = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "tos")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtmsg_tos = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "masklen")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			if (masklen >= 0 && masklen != val) {
				fprintf(stderr, "route: duplicate netmask specification\n");
				return -1;
			}
			masklen = val;
			args++;
			continue;
		}
		if (!strcmp(*args,"mask") || !strcmp(*args,"netmask") ||
		    !strcmp(*args, "genmask")) {
			long mask;
			args++;
			if (!*args)
				usage();
			if (resolve(*args, &mask) < 0) {
				reserror(*args);
				return (-1);
			}
			val = rt_logmask(mask);
			if (masklen >= 0 && masklen != val) {
				fprintf(stderr, "route: duplicate netmask specification\n");
				return -1;
			}
			mask = ntohl(~mask);
			if (mask & (mask+1)) {
				fprintf(stderr, "Not-contiguous netmask %s\n", *args);
				return -1;
			}
			masklen = val;
			args++;
			continue;
		}
		if (!strcmp(*args,"gw") || !strcmp(*args,"gateway") ||
		    !strcmp(*args, "via")) {
			char gateway[128];
			args++;
			if (!*args)
				usage();
			if (r->rtmsg_flags & RTF_GATEWAY)
				usage();
			strcpy(gateway, *args);
			if (resolve(gateway, (long*)&r->rtmsg_gateway.s_addr) < 0) {
				reserror(gateway);
				return (-1);
			}
			r->rtmsg_flags |= RTF_GATEWAY;
			args++;
			continue;
		}
		if (!strcmp(*args,"mtu")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			args++;
			if (val<68 || val>32768)
			{
				fprintf(stderr, "Invalid MTU.\n");
				return -1;
			}
			r->rtmsg_flags |= RTF_MTU;
			r->rtmsg_mtu = val;
			continue;
		}
		if (!strcmp(*args,"window")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			args++;
			if (val<128 || val>32768)
			{
				fprintf(stderr, "Invalid window.\n");
				return -1;
			}
			r->rtmsg_flags |= RTF_WINDOW;
			r->rtmsg_window = val;
			continue;
		}
		if (!strcmp(*args,"irtt")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			args++;
			r->rtmsg_flags |= RTF_IRTT;
			r->rtmsg_rtt = val;
			continue;
		}
		if (!strcmp(*args,"reject")) {
			args++;
			r->rtmsg_flags |= RTF_REJECT;
			continue;
		}
		if (!strcmp(*args,"throw")) {
			args++;
			r->rtmsg_flags |= RTF_THROW;
			continue;
		}
		if (!strcmp(*args,"nopmtudisc")) {
			args++;
			r->rtmsg_flags |= RTF_NOPMTUDISC;
			continue;
		}
		if (!strcmp(*args,"local")) {
			args++;
			r->rtmsg_flags |= RTF_LOCAL;
			continue;
		}
		if (!strcmp(*args,"interface")) {
			args++;
			r->rtmsg_flags |= RTF_INTERFACE;
			continue;
		}
		if (!strcmp(*args,"broadcast")) {
			args++;
			r->rtmsg_flags |= RTF_BROADCAST;
			continue;
		}
		if (!strcmp(*args,"nat")) {
			char dstmap[128];
			args++;
			if (!*args)
				usage();
			if (r->rtmsg_flags & RTF_NAT)
				usage();
			strcpy(dstmap, *args);
			if (resolve(dstmap, (long*)&r->rtmsg_gateway.s_addr) < 0) {
				reserror(dstmap);
				return (-1);
			}
			r->rtmsg_flags |= RTF_NAT;
			args++;
			continue;
		}
		if (!strcmp(*args,"noforward")) {
			args++;
			r->rtmsg_flags |= RTF_NOFORWARD;
			continue;
		}
		if (!strcmp(*args, "static")) {
			args++;
			r->rtmsg_flags |= RTF_STATIC;
			continue;
		}
		if (!strcmp(*args, "ifindex")) {
			args++;
			r->rtmsg_flags |= RTF_STATIC;
			continue;
		}
		if (!strcmp(*args,"device") || !strcmp(*args,"dev")) {
			args++;
			if (!*args)
				usage();
		} else if (args[1])
			usage();
		if (r->rtmsg_ifindex)
			usage();
		r->rtmsg_ifindex = get_ifindex(*args);
		args++;
	}

	if (masklen < 0)
		masklen = 32;

	r->rtmsg_prefixlen = masklen;

	return (0);
}


int rt_make_short(char **args, struct in_rtmsg *r)
{
	long val;
	memset((char *)r, 0, sizeof(*r));

	r->rtmsg_flags = RTF_UP;

	while (*args) {
		if (!strcmp(*args, "ifindex")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtmsg_ifindex = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "metric")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtmsg_metric = val;
			args++;
			continue;
		}
		if (!strcmp(*args,"gw") || !strcmp(*args,"gateway") ||
		    !strcmp(*args, "via")) {
			char gateway[128];
			args++;
			if (!*args)
				usage();
			if (r->rtmsg_flags & RTF_GATEWAY)
				usage();
			strcpy(gateway, *args);
			if (resolve(gateway, (long*)&r->rtmsg_gateway.s_addr) < 0) {
				reserror(gateway);
				return (-1);
			}
			r->rtmsg_flags |= RTF_GATEWAY;
			args++;
			continue;
		}
		if (!strcmp(*args,"mtu")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			args++;
			if (val<68 || val>32768)
			{
				fprintf(stderr, "Invalid MTU.\n");
				return -1;
			}
			r->rtmsg_flags |= RTF_MTU;
			r->rtmsg_mtu = val;
			continue;
		}
		if (!strcmp(*args,"window")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			args++;
			if (val<128 || val>32768)
			{
				fprintf(stderr, "Invalid window.\n");
				return -1;
			}
			r->rtmsg_flags |= RTF_WINDOW;
			r->rtmsg_window = val;
			continue;
		}
		if (!strcmp(*args,"irtt")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			args++;
			r->rtmsg_flags |= RTF_IRTT;
			r->rtmsg_rtt = val;
			continue;
		}
		if (!strcmp(*args,"reject")) {
			args++;
			r->rtmsg_flags |= RTF_REJECT;
			continue;
		}
		if (!strcmp(*args,"throw")) {
			args++;
			r->rtmsg_flags |= RTF_THROW;
			continue;
		}
		if (!strcmp(*args,"nopmtudisc")) {
			args++;
			r->rtmsg_flags |= RTF_NOPMTUDISC;
			continue;
		}
		if (!strcmp(*args,"local")) {
			args++;
			r->rtmsg_flags |= RTF_LOCAL;
			continue;
		}
		if (!strcmp(*args,"interface")) {
			args++;
			r->rtmsg_flags |= RTF_INTERFACE;
			continue;
		}
		if (!strcmp(*args,"broadcast")) {
			args++;
			r->rtmsg_flags |= RTF_BROADCAST;
			continue;
		}
		if (!strcmp(*args,"nat")) {
			char dstmap[128];
			args++;
			if (!*args)
				usage();
			if (r->rtmsg_flags & RTF_NAT)
				usage();
			strcpy(dstmap, *args);
			if (resolve(dstmap, (long*)&r->rtmsg_gateway.s_addr) < 0) {
				reserror(dstmap);
				return (-1);
			}
			r->rtmsg_flags |= RTF_NAT;
			args++;
			continue;
		}
		if (!strcmp(*args,"noforward")) {
			args++;
			r->rtmsg_flags |= RTF_NOFORWARD;
			continue;
		}
		if (!strcmp(*args, "static")) {
			args++;
			r->rtmsg_flags |= RTF_STATIC;
			continue;
		}
		if (!r->rtmsg_ifindex &&
		    (!strcmp(*args,"device") || !strcmp(*args,"dev"))) {
			args++;
			if (!*args)
				usage();
			r->rtmsg_ifindex = get_ifindex(*args);
			args++;
			continue;
		}
		usage();
	}

	return (0);
}


int rtr_make(char **args, struct nlmsghdr *nlh, struct in_rtrulemsg *r)
{
	long val;
	int src_ok=0;
	int dst_ok=0;
	int class_ok=0;

	if (*args == NULL)
		usage();

	memset((char *)r, 0, sizeof(*r));
	nlh->nlmsg_len = sizeof(*r) + sizeof(*nlh);

	while (*args) {
		if (!strcmp(*args, "src") || !strcmp(*args, "from") ||
		    !strcmp(*args, "source")) {
			long val1;
			if (src_ok)
				usage();
			args++;
			if (scan_prefix(*args, &val, &val1))
				usage();
			r->rtrmsg_src.s_addr = val;
			r->rtrmsg_srclen = val1 >=0 ? val1 : 32;
			args++;
			src_ok = 1;
			continue;
		}
		if (!strcmp(*args, "dst") || !strcmp(*args, "to") ||
		    !strcmp(*args, "destination")) {
			long val1;
			if (dst_ok)
				usage();
			args++;
			if (scan_prefix(*args, &val, &val1))
				usage();
			r->rtrmsg_dst.s_addr = val;
			r->rtrmsg_dstlen = val1 >= 0 ? val1 : 32;
			args++;
			dst_ok = 1;
			continue;
		}
		if (!strcmp(*args, "preference") || !strcmp(*args, "pref")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtrmsg_preference = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "class")) {
			args++;
			if (class_ok)
				usage();
			if (scan_class(*args, &val))
				usage();
			r->rtrmsg_class = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "tos")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtrmsg_tos = val;
			args++;
			continue;
		}
		if (!strcmp(*args, "ifindex")) {
			args++;
			if (scan_number(*args, &val))
				usage();
			r->rtrmsg_ifindex = val;
			args++;
			continue;
		}
		if (!r->rtrmsg_ifindex &&
		    (!strcmp(*args,"device") || !strcmp(*args,"dev"))) {
			args++;
			if (!*args)
				usage();
			r->rtrmsg_ifindex = get_ifindex(*args);
			args++;
			continue;
		}
		if (!strcmp(*args, "drop")) {
			args++;
			r->rtrmsg_action = RTP_DROP;
			continue;
		} else if (!strcmp(*args, "unreachable")) {
			args++;
			r->rtrmsg_action = RTP_UNREACHABLE;
			continue;
		} else if (!strcmp(*args, "prohibit")) {
			args++;
			r->rtrmsg_action = RTP_PROHIBIT;
			continue;
		} else if (!strcmp(*args, "masquearade") || !strcmp(*args, "masq")) {
			args++;
			r->rtrmsg_action = RTP_MASQUERADE;
			continue;
		} else if (!strcmp(*args,"nat")) {
			char srcmap[128];
			args++;
			if (!*args)
				usage();
			strcpy(srcmap, *args);
			if (resolve(srcmap, (long*)&r->rtrmsg_srcmap.s_addr) < 0) {
				reserror(srcmap);
				return (-1);
			}
			r->rtrmsg_action = RTP_NAT;
			args++;
			continue;
		}
		if (!strcmp(*args, "log")) {
			args++;
			r->rtrmsg_flags |= RTRF_LOG;
			continue;
		}
		if (!strcmp(*args, "route")) {
			args++;
			rt_make_short(args, r->rtrmsg_rtmsg);
			r->rtrmsg_rtmsgs = 1;
			r->rtrmsg_rtmsg->rtmsg_prefix = r->rtrmsg_dst;
			r->rtrmsg_rtmsg->rtmsg_prefixlen = r->rtrmsg_dstlen;
			r->rtrmsg_rtmsg->rtmsg_tos = r->rtrmsg_tos;
			break;
		}
		usage();
	}

	return (0);
}


int main(int argc, char **argv)
{
	struct {
		struct nlmsghdr nlh;
		union {
			struct in_rtmsg  rtm;
			struct in_rtrulemsg rtrm;
		} u;
	} r;
	int i;
	char *s;

	argv++;
	while ((s = *argv) != NULL) {
		if (*s != '-')
			break;
		while (*++s != '\0')
			switch (*s) {
			case 'c':
				flag_rtcache = 1;
				break;
			case 'r':
				flag_rtrules = 1;
				break;
			case 'l':
				flag_rtlocal = 1;
				break;
			default:
				usage();
			}
		argv++;
	}

	if (*argv == NULL) {
		if (flag_rtcache)
			rt_print_cache();
		else if (flag_rtrules)
			rt_print_rules();
		else
			rt_print(!flag_rtlocal ? _PATH_PROCNET_ROUTE : _PATH_PROCNET_RTLOCAL);
		exit(0);
	}

	if ((skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror("socket");
		exit(-1);
	}

	i = 0;
	memset(&r, 0, sizeof(r));
	if (!strcmp(*argv, "add")) {
		r.nlh.nlmsg_type = RTMSG_NEWROUTE;
		i = rt_make(argv, &r.nlh, &r.u.rtm);
	} else if (!strcmp(*argv, "del")) {
		r.nlh.nlmsg_type = RTMSG_DELROUTE;
		i = rt_make(argv, &r.nlh, &r.u.rtm);
	} else if (!strcmp(*argv, "addrule")) {
		r.nlh.nlmsg_type = RTMSG_NEWRULE;
		i = rtr_make(++argv, &r.nlh, &r.u.rtrm);
	} else if (!strcmp(*argv, "delrule")) {
		r.nlh.nlmsg_type = RTMSG_DELRULE;
		i = rtr_make(++argv, &r.nlh, &r.u.rtrm);
	} else
		usage();

	if (i)
		exit(i);

	if (ioctl(skfd, SIOCRTMSG, (void*)&r) < 0) {
		fprintf(stderr, "ioctl: %s\n", strerror(errno));
		exit(-1);
	}
	exit(0);
}

/*
 * Local Variables:
 * compile-command: "gcc -O2 -m386 -fomit-frame-pointer iproute.c -o iproute"
 * End:
 */
