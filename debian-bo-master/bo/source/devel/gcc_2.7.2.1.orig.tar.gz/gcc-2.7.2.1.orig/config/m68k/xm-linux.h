/* Configuration for GCC for Motorola m68k running Linux. */

#include <m68k/xm-m68k.h>
#include <xm-linux.h>
