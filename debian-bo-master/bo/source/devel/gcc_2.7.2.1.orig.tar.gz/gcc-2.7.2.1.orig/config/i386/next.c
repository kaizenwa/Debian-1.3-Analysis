/* next.c:  Functions for NeXT as target machine for GNU C compiler.  */

/* Note that the include below means that we can't debug routines in
   i386.c when running on a COFF system.  */

#include "i386/i386.c"
#include "nextstep.c"
