#include "i860/bsd.h"

#undef ASCII_DATA_ASM_OP
#define ASCII_DATA_ASM_OP ".ascii"
