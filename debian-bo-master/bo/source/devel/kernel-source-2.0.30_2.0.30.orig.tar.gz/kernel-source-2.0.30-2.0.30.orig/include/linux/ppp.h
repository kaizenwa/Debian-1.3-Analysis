/*
 *	Back compatibility for a while.
 */
#include <linux/if_ppp.h>
