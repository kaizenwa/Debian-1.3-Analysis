/*
** Automatically generated from `value_number.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__value_number__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__value_number__all_empty_lists__ua0_1_0);
Declare_label(mercury__value_number__all_empty_lists__ua0_1_0_i1003);
Declare_label(mercury__value_number__all_empty_lists__ua0_1_0_i1004);
Define_extern_entry(mercury__value_number__main_4_0);
Declare_label(mercury__value_number__main_4_0_i2);
Declare_label(mercury__value_number__main_4_0_i3);
Declare_label(mercury__value_number__main_4_0_i4);
Declare_label(mercury__value_number__main_4_0_i5);
Declare_label(mercury__value_number__main_4_0_i6);
Declare_label(mercury__value_number__main_4_0_i9);
Declare_label(mercury__value_number__main_4_0_i10);
Declare_label(mercury__value_number__main_4_0_i11);
Declare_label(mercury__value_number__main_4_0_i12);
Declare_label(mercury__value_number__main_4_0_i16);
Declare_label(mercury__value_number__main_4_0_i13);
Declare_label(mercury__value_number__main_4_0_i17);
Declare_label(mercury__value_number__main_4_0_i18);
Declare_label(mercury__value_number__main_4_0_i19);
Declare_label(mercury__value_number__main_4_0_i20);
Declare_label(mercury__value_number__main_4_0_i21);
Declare_label(mercury__value_number__main_4_0_i22);
Declare_label(mercury__value_number__main_4_0_i23);
Declare_label(mercury__value_number__main_4_0_i24);
Declare_label(mercury__value_number__main_4_0_i25);
Declare_label(mercury__value_number__main_4_0_i26);
Declare_label(mercury__value_number__main_4_0_i27);
Declare_label(mercury__value_number__main_4_0_i28);
Declare_label(mercury__value_number__main_4_0_i29);
Declare_label(mercury__value_number__main_4_0_i35);
Declare_label(mercury__value_number__main_4_0_i36);
Declare_label(mercury__value_number__main_4_0_i38);
Declare_label(mercury__value_number__main_4_0_i40);
Declare_label(mercury__value_number__main_4_0_i41);
Declare_label(mercury__value_number__main_4_0_i42);
Declare_label(mercury__value_number__main_4_0_i43);
Declare_label(mercury__value_number__main_4_0_i44);
Declare_label(mercury__value_number__main_4_0_i45);
Declare_label(mercury__value_number__main_4_0_i34);
Declare_label(mercury__value_number__main_4_0_i46);
Declare_label(mercury__value_number__main_4_0_i30);
Declare_label(mercury__value_number__main_4_0_i48);
Declare_label(mercury__value_number__main_4_0_i49);
Declare_label(mercury__value_number__main_4_0_i8);
Define_extern_entry(mercury__value_number__post_main_2_0);
Declare_static(mercury__value_number__prepare_for_vn_8_0);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i1002);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i11);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i12);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i13);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i16);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i14);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i1001);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i25);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i26);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i22);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i27);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i19);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i36);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i35);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i32);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i31);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i44);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i45);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i46);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i29);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i1000);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i51);
Declare_label(mercury__value_number__prepare_for_vn_8_0_i52);
Declare_static(mercury__value_number__breakup_complex_if_8_0);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i6);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i7);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i8);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i1000);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i2);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i13);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i14);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i9);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i16);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i23);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i22);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i27);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i29);
Declare_label(mercury__value_number__breakup_complex_if_8_0_i26);
Declare_static(mercury__value_number__optimize_blocks_9_0);
Declare_label(mercury__value_number__optimize_blocks_9_0_i4);
Declare_label(mercury__value_number__optimize_blocks_9_0_i5);
Declare_label(mercury__value_number__optimize_blocks_9_0_i1002);
Declare_static(mercury__value_number__optimize_block_11_0);
Declare_label(mercury__value_number__optimize_block_11_0_i4);
Declare_label(mercury__value_number__optimize_block_11_0_i6);
Declare_label(mercury__value_number__optimize_block_11_0_i3);
Declare_label(mercury__value_number__optimize_block_11_0_i7);
Declare_label(mercury__value_number__optimize_block_11_0_i8);
Declare_static(mercury__value_number__optimize_fragment_9_0);
Declare_label(mercury__value_number__optimize_fragment_9_0_i2);
Declare_label(mercury__value_number__optimize_fragment_9_0_i6);
Declare_label(mercury__value_number__optimize_fragment_9_0_i7);
Declare_label(mercury__value_number__optimize_fragment_9_0_i8);
Declare_label(mercury__value_number__optimize_fragment_9_0_i9);
Declare_label(mercury__value_number__optimize_fragment_9_0_i4);
Declare_label(mercury__value_number__optimize_fragment_9_0_i3);
Declare_static(mercury__value_number__optimize_fragment_2_9_0);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i5);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i2);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i6);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i7);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i8);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i9);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i10);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i16);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i13);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i17);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i18);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i19);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i20);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i12);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i21);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i22);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i23);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i24);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i25);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i26);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i27);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i28);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i29);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i30);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i31);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i34);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i33);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i36);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i37);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i38);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i39);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i40);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i41);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i44);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i48);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i49);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i50);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i47);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i45);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i52);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i53);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i54);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i55);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i43);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i59);
Declare_label(mercury__value_number__optimize_fragment_2_9_0_i60);
Declare_static(mercury__value_number__try_again_9_0);
Declare_label(mercury__value_number__try_again_9_0_i7);
Declare_label(mercury__value_number__try_again_9_0_i12);
Declare_label(mercury__value_number__try_again_9_0_i9);
Declare_label(mercury__value_number__try_again_9_0_i13);
Declare_label(mercury__value_number__try_again_9_0_i14);
Declare_label(mercury__value_number__try_again_9_0_i15);
Declare_label(mercury__value_number__try_again_9_0_i16);
Declare_label(mercury__value_number__try_again_9_0_i17);
Declare_label(mercury__value_number__try_again_9_0_i18);
Declare_label(mercury__value_number__try_again_9_0_i19);
Declare_label(mercury__value_number__try_again_9_0_i5);
Declare_label(mercury__value_number__try_again_9_0_i1001);
Declare_label(mercury__value_number__try_again_9_0_i4);
Declare_label(mercury__value_number__try_again_9_0_i1000);
Declare_label(mercury__value_number__try_again_9_0_i23);
Declare_static(mercury__value_number__last_ditch_7_0);
Declare_label(mercury__value_number__last_ditch_7_0_i1024);
Declare_label(mercury__value_number__last_ditch_7_0_i1015);
Declare_label(mercury__value_number__last_ditch_7_0_i9);
Declare_label(mercury__value_number__last_ditch_7_0_i12);
Declare_label(mercury__value_number__last_ditch_7_0_i13);
Declare_label(mercury__value_number__last_ditch_7_0_i1006);
Declare_label(mercury__value_number__last_ditch_7_0_i4);
Declare_label(mercury__value_number__last_ditch_7_0_i14);
Declare_label(mercury__value_number__last_ditch_7_0_i1004);
Declare_static(mercury__value_number__process_parallel_tuples_7_0);
Declare_label(mercury__value_number__process_parallel_tuples_7_0_i2);
Declare_label(mercury__value_number__process_parallel_tuples_7_0_i3);
Declare_label(mercury__value_number__process_parallel_tuples_7_0_i6);
Declare_label(mercury__value_number__process_parallel_tuples_7_0_i7);
Declare_label(mercury__value_number__process_parallel_tuples_7_0_i4);
Declare_label(mercury__value_number__process_parallel_tuples_7_0_i8);
Declare_static(mercury__value_number__insert_new_blocks_3_0);
Declare_label(mercury__value_number__insert_new_blocks_3_0_i4);
Declare_label(mercury__value_number__insert_new_blocks_3_0_i5);
Declare_label(mercury__value_number__insert_new_blocks_3_0_i1006);
Declare_static(mercury__value_number__process_parallel_tuples_2_9_0);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i1007);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i7);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i8);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i11);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i14);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i13);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i16);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i10);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i9);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i18);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i19);
Declare_label(mercury__value_number__process_parallel_tuples_2_9_0_i1005);
Declare_static(mercury__value_number__process_parallel_nodes_9_0);
Declare_label(mercury__value_number__process_parallel_nodes_9_0_i4);
Declare_label(mercury__value_number__process_parallel_nodes_9_0_i5);
Declare_label(mercury__value_number__process_parallel_nodes_9_0_i6);
Declare_label(mercury__value_number__process_parallel_nodes_9_0_i7);
Declare_label(mercury__value_number__process_parallel_nodes_9_0_i8);
Declare_label(mercury__value_number__process_parallel_nodes_9_0_i1005);
Declare_static(mercury__value_number__process_parallels_9_0);
Declare_label(mercury__value_number__process_parallels_9_0_i1005);
Declare_label(mercury__value_number__process_parallels_9_0_i15);
Declare_label(mercury__value_number__process_parallels_9_0_i17);
Declare_label(mercury__value_number__process_parallels_9_0_i14);
Declare_label(mercury__value_number__process_parallels_9_0_i9);
Declare_label(mercury__value_number__process_parallels_9_0_i5);
Declare_label(mercury__value_number__process_parallels_9_0_i32);
Declare_label(mercury__value_number__process_parallels_9_0_i34);
Declare_label(mercury__value_number__process_parallels_9_0_i31);
Declare_label(mercury__value_number__process_parallels_9_0_i26);
Declare_label(mercury__value_number__process_parallels_9_0_i22);
Declare_label(mercury__value_number__process_parallels_9_0_i42);
Declare_label(mercury__value_number__process_parallels_9_0_i43);
Declare_label(mercury__value_number__process_parallels_9_0_i44);
Declare_label(mercury__value_number__process_parallels_9_0_i39);
Declare_static(mercury__value_number__pair_labels_pars_3_0);
Declare_label(mercury__value_number__pair_labels_pars_3_0_i6);
Declare_label(mercury__value_number__pair_labels_pars_3_0_i5);
Declare_label(mercury__value_number__pair_labels_pars_3_0_i8);
Declare_label(mercury__value_number__pair_labels_pars_3_0_i9);
Declare_label(mercury__value_number__pair_labels_pars_3_0_i3);
Declare_label(mercury__value_number__pair_labels_pars_3_0_i14);
Declare_static(mercury__value_number__find_parallel_for_label_4_0);
Declare_label(mercury__value_number__find_parallel_for_label_4_0_i5);
Declare_label(mercury__value_number__find_parallel_for_label_4_0_i4);
Declare_label(mercury__value_number__find_parallel_for_label_4_0_i7);
Declare_label(mercury__value_number__find_parallel_for_label_4_0_i1004);
Declare_label(mercury__value_number__find_parallel_for_label_4_0_i1);
Declare_static(mercury__value_number__process_parallel_list_8_0);
Declare_label(mercury__value_number__process_parallel_list_8_0_i9);
Declare_label(mercury__value_number__process_parallel_list_8_0_i8);
Declare_label(mercury__value_number__process_parallel_list_8_0_i11);
Declare_label(mercury__value_number__process_parallel_list_8_0_i12);
Declare_label(mercury__value_number__process_parallel_list_8_0_i13);
Declare_label(mercury__value_number__process_parallel_list_8_0_i14);
Declare_label(mercury__value_number__process_parallel_list_8_0_i15);
Declare_label(mercury__value_number__process_parallel_list_8_0_i4);
Declare_label(mercury__value_number__process_parallel_list_8_0_i16);
Declare_label(mercury__value_number__process_parallel_list_8_0_i1005);
Declare_static(mercury__value_number__process_parallel_8_0);
Declare_label(mercury__value_number__process_parallel_8_0_i2);
Declare_label(mercury__value_number__process_parallel_8_0_i3);
Declare_label(mercury__value_number__process_parallel_8_0_i4);
Declare_label(mercury__value_number__process_parallel_8_0_i5);
Declare_label(mercury__value_number__process_parallel_8_0_i6);
Declare_label(mercury__value_number__process_parallel_8_0_i13);
Declare_label(mercury__value_number__process_parallel_8_0_i15);
Declare_label(mercury__value_number__process_parallel_8_0_i10);
Declare_label(mercury__value_number__process_parallel_8_0_i9);
Declare_label(mercury__value_number__process_parallel_8_0_i16);
Declare_label(mercury__value_number__process_parallel_8_0_i7);
Declare_static(mercury__value_number__find_block_by_label_5_0);
Declare_label(mercury__value_number__find_block_by_label_5_0_i10);
Declare_label(mercury__value_number__find_block_by_label_5_0_i8);
Declare_label(mercury__value_number__find_block_by_label_5_0_i1011);
Declare_label(mercury__value_number__find_block_by_label_5_0_i7);
Declare_label(mercury__value_number__find_block_by_label_5_0_i12);
Declare_label(mercury__value_number__find_block_by_label_5_0_i1010);
Declare_label(mercury__value_number__find_block_by_label_5_0_i16);
Declare_label(mercury__value_number__find_block_by_label_5_0_i17);
Declare_label(mercury__value_number__find_block_by_label_5_0_i1008);
Declare_static(mercury__value_number__convert_back_modframe_2_0);
Declare_label(mercury__value_number__convert_back_modframe_2_0_i12);
Declare_label(mercury__value_number__convert_back_modframe_2_0_i13);
Declare_label(mercury__value_number__convert_back_modframe_2_0_i3);
Declare_label(mercury__value_number__convert_back_modframe_2_0_i11);
Declare_label(mercury__value_number__convert_back_modframe_2_0_i1);
Declare_static(mercury__value_number__push_decr_sp_back_2_0);
Declare_label(mercury__value_number__push_decr_sp_back_2_0_i1006);
Declare_label(mercury__value_number__push_decr_sp_back_2_0_i8);
Declare_label(mercury__value_number__push_decr_sp_back_2_0_i1004);
Declare_static(mercury__value_number__push_decr_sp_back_2_3_0);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i4);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i7);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i6);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i8);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i10);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i11);
Declare_label(mercury__value_number__push_decr_sp_back_2_3_0_i1015);
Declare_static(mercury__value_number__push_incr_sp_forw_2_0);
Declare_label(mercury__value_number__push_incr_sp_forw_2_0_i2);
Declare_label(mercury__value_number__push_incr_sp_forw_2_0_i3);
Declare_label(mercury__value_number__push_incr_sp_forw_2_0_i6);
Declare_label(mercury__value_number__push_incr_sp_forw_2_0_i5);
Declare_static(mercury__value_number__push_incr_sp_forw_rev_3_0);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i7);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i1007);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i4);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i8);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i1005);
Declare_static(mercury__value_number__push_incr_sp_forw_rev_2_4_0);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i4);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i7);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i6);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i8);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i10);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i11);
Declare_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i1015);
Declare_static(mercury__value_number__push_save_succip_forw_rev_3_0);
Declare_label(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
Declare_label(mercury__value_number__push_save_succip_forw_rev_3_0_i11);
Declare_label(mercury__value_number__push_save_succip_forw_rev_3_0_i1009);
Declare_static(mercury__value_number__push_save_succip_forw_rev_2_3_0);
Declare_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1011);
Declare_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i4);
Declare_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i7);
Declare_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1010);
Declare_static(mercury__value_number__push_livevals_back_2_0);
Declare_label(mercury__value_number__push_livevals_back_2_0_i1005);
Declare_label(mercury__value_number__push_livevals_back_2_0_i8);
Declare_label(mercury__value_number__push_livevals_back_2_0_i1003);
Declare_static(mercury__value_number__push_livevals_back_2_3_0);
Declare_label(mercury__value_number__push_livevals_back_2_3_0_i4);
Declare_label(mercury__value_number__push_livevals_back_2_3_0_i5);
Declare_label(mercury__value_number__push_livevals_back_2_3_0_i10);
Declare_label(mercury__value_number__push_livevals_back_2_3_0_i6);
Declare_label(mercury__value_number__push_livevals_back_2_3_0_i11);
Declare_label(mercury__value_number__push_livevals_back_2_3_0_i1013);
Declare_static(mercury__value_number__boundary_instr_2_0);
Declare_label(mercury__value_number__boundary_instr_2_0_i5);
Declare_label(mercury__value_number__boundary_instr_2_0_i7);
Declare_label(mercury__value_number__boundary_instr_2_0_i4);
Declare_label(mercury__value_number__boundary_instr_2_0_i23);
Declare_label(mercury__value_number__boundary_instr_2_0_i24);
Declare_static(mercury__value_number__has_no_backward_branches_2_2_0);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i7);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i1008);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i4);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i8);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i9);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i1005);
Declare_label(mercury__value_number__has_no_backward_branches_2_2_0_i1);
Declare_static(mercury__value_number__no_old_labels_2_0);
Declare_label(mercury__value_number__no_old_labels_2_0_i6);
Declare_label(mercury__value_number__no_old_labels_2_0_i1003);
Declare_label(mercury__value_number__no_old_labels_2_0_i1);
Declare_static(mercury__value_number__post_main_2_5_0);
Declare_label(mercury__value_number__post_main_2_5_0_i4);
Declare_label(mercury__value_number__post_main_2_5_0_i8);
Declare_label(mercury__value_number__post_main_2_5_0_i7);
Declare_label(mercury__value_number__post_main_2_5_0_i12);
Declare_label(mercury__value_number__post_main_2_5_0_i13);
Declare_label(mercury__value_number__post_main_2_5_0_i14);
Declare_label(mercury__value_number__post_main_2_5_0_i11);
Declare_label(mercury__value_number__post_main_2_5_0_i18);
Declare_label(mercury__value_number__post_main_2_5_0_i19);
Declare_label(mercury__value_number__post_main_2_5_0_i15);
Declare_label(mercury__value_number__post_main_2_5_0_i5);
Declare_label(mercury__value_number__post_main_2_5_0_i23);
Declare_label(mercury__value_number__post_main_2_5_0_i3);
Declare_label(mercury__value_number__post_main_2_5_0_i25);
Declare_label(mercury__value_number__post_main_2_5_0_i31);
Declare_label(mercury__value_number__post_main_2_5_0_i36);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_value_number__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data_vn_type__base_type_info_vn_ctrl_tuple_0[];
Word * mercury_data_value_number__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vn_ctrl_tuple_0
};

Word mercury_data_value_number__common_2[] = {
	((Integer) 0)
};

Word mercury_data_value_number__common_3[] = {
	((Integer) 1)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_value_number__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0)
};

extern Word * mercury_data_vn_type__base_type_info_parallel_0[];
Word * mercury_data_value_number__common_5[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_parallel_0
};

extern Word * mercury_data_llds__base_type_info_label_0[];
Word * mercury_data_value_number__common_6[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_label_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_4)
};

Word mercury_data_value_number__common_7[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

BEGIN_MODULE(mercury__value_number_module0)
	init_entry(mercury__value_number__all_empty_lists__ua0_1_0);
	init_label(mercury__value_number__all_empty_lists__ua0_1_0_i1003);
	init_label(mercury__value_number__all_empty_lists__ua0_1_0_i1004);
BEGIN_CODE

/* code for predicate 'value_number__all_empty_lists__ua0'/1 in mode 0 */
Define_static(mercury__value_number__all_empty_lists__ua0_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__all_empty_lists__ua0_1_0_i1003);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__all_empty_lists__ua0_1_0_i1004);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localtailcall(mercury__value_number__all_empty_lists__ua0_1_0,
		STATIC(mercury__value_number__all_empty_lists__ua0_1_0));
Define_label(mercury__value_number__all_empty_lists__ua0_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__value_number__all_empty_lists__ua0_1_0_i1004);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module1)
	init_entry(mercury__value_number__main_4_0);
	init_label(mercury__value_number__main_4_0_i2);
	init_label(mercury__value_number__main_4_0_i3);
	init_label(mercury__value_number__main_4_0_i4);
	init_label(mercury__value_number__main_4_0_i5);
	init_label(mercury__value_number__main_4_0_i6);
	init_label(mercury__value_number__main_4_0_i9);
	init_label(mercury__value_number__main_4_0_i10);
	init_label(mercury__value_number__main_4_0_i11);
	init_label(mercury__value_number__main_4_0_i12);
	init_label(mercury__value_number__main_4_0_i16);
	init_label(mercury__value_number__main_4_0_i13);
	init_label(mercury__value_number__main_4_0_i17);
	init_label(mercury__value_number__main_4_0_i18);
	init_label(mercury__value_number__main_4_0_i19);
	init_label(mercury__value_number__main_4_0_i20);
	init_label(mercury__value_number__main_4_0_i21);
	init_label(mercury__value_number__main_4_0_i22);
	init_label(mercury__value_number__main_4_0_i23);
	init_label(mercury__value_number__main_4_0_i24);
	init_label(mercury__value_number__main_4_0_i25);
	init_label(mercury__value_number__main_4_0_i26);
	init_label(mercury__value_number__main_4_0_i27);
	init_label(mercury__value_number__main_4_0_i28);
	init_label(mercury__value_number__main_4_0_i29);
	init_label(mercury__value_number__main_4_0_i35);
	init_label(mercury__value_number__main_4_0_i36);
	init_label(mercury__value_number__main_4_0_i38);
	init_label(mercury__value_number__main_4_0_i40);
	init_label(mercury__value_number__main_4_0_i41);
	init_label(mercury__value_number__main_4_0_i42);
	init_label(mercury__value_number__main_4_0_i43);
	init_label(mercury__value_number__main_4_0_i44);
	init_label(mercury__value_number__main_4_0_i45);
	init_label(mercury__value_number__main_4_0_i34);
	init_label(mercury__value_number__main_4_0_i46);
	init_label(mercury__value_number__main_4_0_i30);
	init_label(mercury__value_number__main_4_0_i48);
	init_label(mercury__value_number__main_4_0_i49);
	init_label(mercury__value_number__main_4_0_i8);
BEGIN_CODE

/* code for predicate 'value_number__main'/4 in mode 0 */
Define_entry(mercury__value_number__main_4_0);
	incr_sp_push_msg(12, "value_number__main");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__get_prologue_4_0);
	call_localret(ENTRY(mercury__opt_util__get_prologue_4_0),
		mercury__value_number__main_4_0_i2,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i2);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	r1 = (Integer) r3;
	r2 = ((Integer) 1000);
	{
	Declare_entry(mercury__opt_util__new_label_no_3_0);
	call_localret(ENTRY(mercury__opt_util__new_label_no_3_0),
		mercury__value_number__main_4_0_i3,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i3);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__value_number__prepare_for_vn_8_0),
		mercury__value_number__main_4_0_i4,
		ENTRY(mercury__value_number__main_4_0));
Define_label(mercury__value_number__main_4_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__labelopt__build_useset_2_0);
	call_localret(ENTRY(mercury__labelopt__build_useset_2_0),
		mercury__value_number__main_4_0_i5,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__livemap__build_2_0);
	call_localret(ENTRY(mercury__livemap__build_2_0),
		mercury__value_number__main_4_0_i6,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__main_4_0_i8);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__vn_debug__livemap_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__livemap_msg_3_0),
		mercury__value_number__main_4_0_i9,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i9);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	{
	Declare_entry(mercury__globals__io_get_globals_3_0);
	call_localret(ENTRY(mercury__globals__io_get_globals_3_0),
		mercury__value_number__main_4_0_i10,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i10);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__opt_util__gather_comments_3_0);
	call_localret(ENTRY(mercury__opt_util__gather_comments_3_0),
		mercury__value_number__main_4_0_i11,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__globals__get_gc_method_2_0);
	call_localret(ENTRY(mercury__globals__get_gc_method_2_0),
		mercury__value_number__main_4_0_i12,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i12);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__main_4_0_i13);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__value_number__main_4_0_i16,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r4 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r2 = (Integer) r1;
	r11 = (Integer) detstackvar(11);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	GOTO_LABEL(mercury__value_number__main_4_0_i17);
Define_label(mercury__value_number__main_4_0_i13);
	r4 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(11);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
Define_label(mercury__value_number__main_4_0_i17);
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(1) = (Integer) r7;
	detstackvar(2) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__value_number__main_4_0_i18,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i18);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = string_const("procedure before value numbering", 32);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__main_4_0_i19,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i19);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__vn_debug__dump_instrs_3_0);
	call_localret(ENTRY(mercury__vn_debug__dump_instrs_3_0),
		mercury__value_number__main_4_0_i20,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i20);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_block__divide_into_blocks_3_0);
	call_localret(ENTRY(mercury__vn_block__divide_into_blocks_3_0),
		mercury__value_number__main_4_0_i21,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i21);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__globals__get_options_2_0);
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__value_number__main_4_0_i22,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i22);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	{
	Declare_entry(mercury__vn_type__init_params_2_0);
	call_localret(ENTRY(mercury__vn_type__init_params_2_0),
		mercury__value_number__main_4_0_i23,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i23);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__value_number__optimize_blocks_9_0),
		mercury__value_number__main_4_0_i24,
		ENTRY(mercury__value_number__main_4_0));
Define_label(mercury__value_number__main_4_0_i24);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(6) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	detstackvar(5) = (Integer) r1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	detstackvar(10) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__value_number__main_4_0_i25,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i25);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__opt_util__propagate_livevals_2_0);
	call_localret(ENTRY(mercury__opt_util__propagate_livevals_2_0),
		mercury__value_number__main_4_0_i26,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i26);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) detstackvar(10);
	detstackvar(10) = (Integer) r1;
	r1 = string_const("procedure after non-pred value numbering", 40);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__main_4_0_i27,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i27);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__vn_debug__dump_instrs_3_0);
	call_localret(ENTRY(mercury__vn_debug__dump_instrs_3_0),
		mercury__value_number__main_4_0_i28,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i28);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 127);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__value_number__main_4_0_i29,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i29);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__main_4_0_i30);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__value_number__main_4_0_i35,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i35);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__value_number__has_no_backward_branches_2_2_0),
		mercury__value_number__main_4_0_i36,
		ENTRY(mercury__value_number__main_4_0));
Define_label(mercury__value_number__main_4_0_i36);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__main_4_0_i34);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__value_number__main_4_0_i38,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i38);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__main_4_0_i34);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__main_4_0_i40,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i40);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__value_number__process_parallel_tuples_7_0),
		mercury__value_number__main_4_0_i41,
		ENTRY(mercury__value_number__main_4_0));
Define_label(mercury__value_number__main_4_0_i41);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	detstackvar(1) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__value_number__main_4_0_i42,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i42);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	{
	Declare_entry(mercury__opt_util__propagate_livevals_2_0);
	call_localret(ENTRY(mercury__opt_util__propagate_livevals_2_0),
		mercury__value_number__main_4_0_i43,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i43);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("procedure after parallels", 25);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__main_4_0_i44,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i44);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_debug__dump_instrs_3_0);
	call_localret(ENTRY(mercury__vn_debug__dump_instrs_3_0),
		mercury__value_number__main_4_0_i45,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i45);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r4 = (Integer) r1;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	GOTO_LABEL(mercury__value_number__main_4_0_i48);
Define_label(mercury__value_number__main_4_0_i34);
	r1 = string_const("parallels do not apply", 22);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__main_4_0_i46,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i46);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r4 = (Integer) r1;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	GOTO_LABEL(mercury__value_number__main_4_0_i48);
Define_label(mercury__value_number__main_4_0_i30);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
Define_label(mercury__value_number__main_4_0_i48);
	detstackvar(1) = (Integer) r4;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__main_4_0_i49,
		ENTRY(mercury__value_number__main_4_0));
	}
Define_label(mercury__value_number__main_4_0_i49);
	update_prof_current_proc(LABEL(mercury__value_number__main_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__value_number__main_4_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module2)
	init_entry(mercury__value_number__post_main_2_0);
BEGIN_CODE

/* code for predicate 'value_number__post_main'/2 in mode 0 */
Define_entry(mercury__value_number__post_main_2_0);
	r2 = ((Integer) 0);
	r3 = ((Integer) 0);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__value_number__post_main_2_5_0),
		ENTRY(mercury__value_number__post_main_2_0));
END_MODULE

BEGIN_MODULE(mercury__value_number_module3)
	init_entry(mercury__value_number__prepare_for_vn_8_0);
	init_label(mercury__value_number__prepare_for_vn_8_0_i1002);
	init_label(mercury__value_number__prepare_for_vn_8_0_i11);
	init_label(mercury__value_number__prepare_for_vn_8_0_i12);
	init_label(mercury__value_number__prepare_for_vn_8_0_i13);
	init_label(mercury__value_number__prepare_for_vn_8_0_i16);
	init_label(mercury__value_number__prepare_for_vn_8_0_i14);
	init_label(mercury__value_number__prepare_for_vn_8_0_i1001);
	init_label(mercury__value_number__prepare_for_vn_8_0_i25);
	init_label(mercury__value_number__prepare_for_vn_8_0_i26);
	init_label(mercury__value_number__prepare_for_vn_8_0_i22);
	init_label(mercury__value_number__prepare_for_vn_8_0_i27);
	init_label(mercury__value_number__prepare_for_vn_8_0_i19);
	init_label(mercury__value_number__prepare_for_vn_8_0_i36);
	init_label(mercury__value_number__prepare_for_vn_8_0_i35);
	init_label(mercury__value_number__prepare_for_vn_8_0_i32);
	init_label(mercury__value_number__prepare_for_vn_8_0_i31);
	init_label(mercury__value_number__prepare_for_vn_8_0_i44);
	init_label(mercury__value_number__prepare_for_vn_8_0_i45);
	init_label(mercury__value_number__prepare_for_vn_8_0_i46);
	init_label(mercury__value_number__prepare_for_vn_8_0_i29);
	init_label(mercury__value_number__prepare_for_vn_8_0_i1000);
	init_label(mercury__value_number__prepare_for_vn_8_0_i51);
	init_label(mercury__value_number__prepare_for_vn_8_0_i52);
BEGIN_CODE

/* code for predicate 'value_number__prepare_for_vn'/8 in mode 0 */
Define_static(mercury__value_number__prepare_for_vn_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i1000);
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i1001);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i1001);
	r7 = (Integer) field(mktag(3), (Integer) r5, ((Integer) 2));
	r8 = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	if (((Integer) r6 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i1002);
	r9 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r6, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r9) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i1002);
	if (((Integer) field(mktag(3), (Integer) r9, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i1002);
	r9 = (Integer) field(mktag(3), (Integer) r9, ((Integer) 1));
	r1 = (Integer) r8;
	r5 = (Integer) r2;
	r2 = (Integer) r7;
	r8 = (Integer) r6;
	r6 = (Integer) r4;
	r7 = (Integer) r4;
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r9;
	incr_sp_push_msg(8, "value_number__prepare_for_vn");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i11);
Define_label(mercury__value_number__prepare_for_vn_8_0_i1002);
	incr_sp_push_msg(8, "value_number__prepare_for_vn");
	detstackvar(8) = (Integer) succip;
	r1 = (Integer) r8;
	r5 = (Integer) r2;
	r2 = (Integer) r7;
	r7 = (Integer) r4;
	r8 = (Integer) r6;
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = (Integer) r4;
	r13 = (Integer) r4;
	r14 = (Integer) r9;
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r14;
	r6 = ((Integer) r13 + ((Integer) 1));
Define_label(mercury__value_number__prepare_for_vn_8_0_i11);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	detstackvar(5) = (Integer) r9;
	detstackvar(6) = (Integer) r6;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__value_number__breakup_complex_if_8_0),
		mercury__value_number__prepare_for_vn_8_0_i12,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
Define_label(mercury__value_number__prepare_for_vn_8_0_i12);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	localcall(mercury__value_number__prepare_for_vn_8_0,
		LABEL(mercury__value_number__prepare_for_vn_8_0_i13),
		STATIC(mercury__value_number__prepare_for_vn_8_0));
Define_label(mercury__value_number__prepare_for_vn_8_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	if (((Integer) detstackvar(6) != (Integer) detstackvar(3)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i14);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__prepare_for_vn_8_0_i16,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__value_number__prepare_for_vn_8_0_i14);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	detstackvar(3) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("vn false label", 14);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__prepare_for_vn_8_0_i16,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i1001);
	incr_sp_push_msg(8, "value_number__prepare_for_vn");
	detstackvar(8) = (Integer) succip;
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i19);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 10)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i19);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i22);
	detstackvar(4) = (Integer) r7;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r1 = (Integer) r6;
	r3 = ((Integer) 0);
	r4 = ((Integer) r4 + ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	localcall(mercury__value_number__prepare_for_vn_8_0,
		LABEL(mercury__value_number__prepare_for_vn_8_0_i25),
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i25);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(1);
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__value_number__prepare_for_vn_8_0_i26,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i26);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("vn incr divide label", 20);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i22);
	detstackvar(4) = (Integer) r7;
	r1 = (Integer) r6;
	r3 = ((Integer) 0);
	localcall(mercury__value_number__prepare_for_vn_8_0,
		LABEL(mercury__value_number__prepare_for_vn_8_0_i27),
		STATIC(mercury__value_number__prepare_for_vn_8_0));
Define_label(mercury__value_number__prepare_for_vn_8_0_i27);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r5 = (Integer) r4;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__value_number__prepare_for_vn_8_0_i19);
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i32);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i32);
	r1 = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i35);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i36) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i36) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i36) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i36) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29));
Define_label(mercury__value_number__prepare_for_vn_8_0_i36);
	r5 = (Integer) r7;
	r1 = (Integer) r6;
	GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i31);
Define_label(mercury__value_number__prepare_for_vn_8_0_i35);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i29);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i36) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i36) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29) AND
		LABEL(mercury__value_number__prepare_for_vn_8_0_i29));
Define_label(mercury__value_number__prepare_for_vn_8_0_i32);
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i29);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__value_number__prepare_for_vn_8_0_i29);
	r5 = (Integer) r7;
	r1 = (Integer) r6;
Define_label(mercury__value_number__prepare_for_vn_8_0_i31);
	detstackvar(4) = (Integer) r5;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r3;
	tag_incr_hp(detstackvar(2), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) detstackvar(2), ((Integer) 1)) = string_const("vn stack ctrl before label", 26);
	field(mktag(0), (Integer) detstackvar(2), ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(detstackvar(5), mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) detstackvar(5), ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) detstackvar(5), ((Integer) 1)) = ((Integer) r4 + ((Integer) 1));
	r6 = (Integer) detstackvar(5);
	tag_incr_hp(detstackvar(6), mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) detstackvar(6), ((Integer) 0)) = (Integer) tempr1;
	r3 = ((Integer) 0);
	r4 = ((Integer) r4 + ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) detstackvar(6), ((Integer) 1)) = string_const("vn stack ctrl after label", 25);
	localcall(mercury__value_number__prepare_for_vn_8_0,
		LABEL(mercury__value_number__prepare_for_vn_8_0_i44),
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i44);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	detstackvar(7) = (Integer) r4;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__value_number__prepare_for_vn_8_0_i45,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i45);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__value_number__prepare_for_vn_8_0_i46,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i46);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i29);
	detstackvar(4) = (Integer) r7;
	r1 = (Integer) r6;
	localcall(mercury__value_number__prepare_for_vn_8_0,
		LABEL(mercury__value_number__prepare_for_vn_8_0_i27),
		STATIC(mercury__value_number__prepare_for_vn_8_0));
Define_label(mercury__value_number__prepare_for_vn_8_0_i1000);
	incr_sp_push_msg(8, "value_number__prepare_for_vn");
	detstackvar(8) = (Integer) succip;
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__value_number__prepare_for_vn_8_0_i51,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i51);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__value_number__prepare_for_vn_8_0_i52,
		STATIC(mercury__value_number__prepare_for_vn_8_0));
	}
Define_label(mercury__value_number__prepare_for_vn_8_0_i52);
	update_prof_current_proc(LABEL(mercury__value_number__prepare_for_vn_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module4)
	init_entry(mercury__value_number__breakup_complex_if_8_0);
	init_label(mercury__value_number__breakup_complex_if_8_0_i6);
	init_label(mercury__value_number__breakup_complex_if_8_0_i7);
	init_label(mercury__value_number__breakup_complex_if_8_0_i8);
	init_label(mercury__value_number__breakup_complex_if_8_0_i1000);
	init_label(mercury__value_number__breakup_complex_if_8_0_i2);
	init_label(mercury__value_number__breakup_complex_if_8_0_i13);
	init_label(mercury__value_number__breakup_complex_if_8_0_i14);
	init_label(mercury__value_number__breakup_complex_if_8_0_i9);
	init_label(mercury__value_number__breakup_complex_if_8_0_i16);
	init_label(mercury__value_number__breakup_complex_if_8_0_i23);
	init_label(mercury__value_number__breakup_complex_if_8_0_i22);
	init_label(mercury__value_number__breakup_complex_if_8_0_i27);
	init_label(mercury__value_number__breakup_complex_if_8_0_i29);
	init_label(mercury__value_number__breakup_complex_if_8_0_i26);
BEGIN_CODE

/* code for predicate 'value_number__breakup_complex_if'/8 in mode 0 */
Define_static(mercury__value_number__breakup_complex_if_8_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i1000);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i1000);
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	incr_sp_push_msg(7, "value_number__breakup_complex_if");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r7 != ((Integer) 10)))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i2);
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 1)) = (Integer) r6;
	detstackvar(1) = (Integer) r5;
	detstackvar(6) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r9;
	r4 = (Integer) r2;
	r6 = ((Integer) r6 + ((Integer) 1));
	localcall(mercury__value_number__breakup_complex_if_8_0,
		LABEL(mercury__value_number__breakup_complex_if_8_0_i6),
		STATIC(mercury__value_number__breakup_complex_if_8_0));
Define_label(mercury__value_number__breakup_complex_if_8_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	localcall(mercury__value_number__breakup_complex_if_8_0,
		LABEL(mercury__value_number__breakup_complex_if_8_0_i7),
		STATIC(mercury__value_number__breakup_complex_if_8_0));
Define_label(mercury__value_number__breakup_complex_if_8_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__breakup_complex_if_8_0_i8,
		STATIC(mercury__value_number__breakup_complex_if_8_0));
	}
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__value_number__breakup_complex_if_8_0_i1000);
	incr_sp_push_msg(7, "value_number__breakup_complex_if");
	detstackvar(7) = (Integer) succip;
Define_label(mercury__value_number__breakup_complex_if_8_0_i2);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i9);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i9);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 11)))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i9);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 1)) = (Integer) r6;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) r5;
	detstackvar(5) = (Integer) r9;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r9;
	r4 = (Integer) r3;
	r6 = ((Integer) r6 + ((Integer) 1));
	localcall(mercury__value_number__breakup_complex_if_8_0,
		LABEL(mercury__value_number__breakup_complex_if_8_0_i13),
		STATIC(mercury__value_number__breakup_complex_if_8_0));
Define_label(mercury__value_number__breakup_complex_if_8_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	localcall(mercury__value_number__breakup_complex_if_8_0,
		LABEL(mercury__value_number__breakup_complex_if_8_0_i14),
		STATIC(mercury__value_number__breakup_complex_if_8_0));
Define_label(mercury__value_number__breakup_complex_if_8_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__breakup_complex_if_8_0_i8,
		STATIC(mercury__value_number__breakup_complex_if_8_0));
	}
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i9);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i16);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i16);
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r7 != ((Integer) 9)))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i16);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__value_number__breakup_complex_if_8_0,
		STATIC(mercury__value_number__breakup_complex_if_8_0));
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i16);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	r1 = (Integer) r4;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	call_localret(ENTRY(mercury____Unify___llds__code_addr_0_0),
		mercury__value_number__breakup_complex_if_8_0_i23,
		STATIC(mercury__value_number__breakup_complex_if_8_0));
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i23);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i22);
	r1 = (Integer) detstackvar(5);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i22);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	call_localret(ENTRY(mercury____Unify___llds__code_addr_0_0),
		mercury__value_number__breakup_complex_if_8_0_i27,
		STATIC(mercury__value_number__breakup_complex_if_8_0));
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i27);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__breakup_complex_if_8_0_i26);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_util__neg_rval_2_0);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__value_number__breakup_complex_if_8_0_i29,
		STATIC(mercury__value_number__breakup_complex_if_8_0));
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i29);
	update_prof_current_proc(LABEL(mercury__value_number__breakup_complex_if_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__value_number__breakup_complex_if_8_0_i26);
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module5)
	init_entry(mercury__value_number__optimize_blocks_9_0);
	init_label(mercury__value_number__optimize_blocks_9_0_i4);
	init_label(mercury__value_number__optimize_blocks_9_0_i5);
	init_label(mercury__value_number__optimize_blocks_9_0_i1002);
BEGIN_CODE

/* code for predicate 'value_number__optimize_blocks'/9 in mode 0 */
Define_static(mercury__value_number__optimize_blocks_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__optimize_blocks_9_0_i1002);
	incr_sp_push_msg(4, "value_number__optimize_blocks");
	detstackvar(4) = (Integer) succip;
	r7 = (Integer) r6;
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__value_number__optimize_block_11_0),
		mercury__value_number__optimize_blocks_9_0_i4,
		STATIC(mercury__value_number__optimize_blocks_9_0));
Define_label(mercury__value_number__optimize_blocks_9_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_blocks_9_0));
	r6 = (Integer) r4;
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r4 = (Integer) r1;
	r5 = (Integer) r3;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__value_number__optimize_blocks_9_0,
		LABEL(mercury__value_number__optimize_blocks_9_0_i5),
		STATIC(mercury__value_number__optimize_blocks_9_0));
	}
Define_label(mercury__value_number__optimize_blocks_9_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_blocks_9_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__value_number__optimize_blocks_9_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	r3 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module6)
	init_entry(mercury__value_number__optimize_block_11_0);
	init_label(mercury__value_number__optimize_block_11_0_i4);
	init_label(mercury__value_number__optimize_block_11_0_i6);
	init_label(mercury__value_number__optimize_block_11_0_i3);
	init_label(mercury__value_number__optimize_block_11_0_i7);
	init_label(mercury__value_number__optimize_block_11_0_i8);
BEGIN_CODE

/* code for predicate 'value_number__optimize_block'/11 in mode 0 */
Define_static(mercury__value_number__optimize_block_11_0);
	incr_sp_push_msg(8, "value_number__optimize_block");
	detstackvar(8) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__optimize_block_11_0_i4,
		STATIC(mercury__value_number__optimize_block_11_0));
	}
Define_label(mercury__value_number__optimize_block_11_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_block_11_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__optimize_block_11_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	{
	Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__value_number__optimize_block_11_0_i6,
		STATIC(mercury__value_number__optimize_block_11_0));
	}
Define_label(mercury__value_number__optimize_block_11_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_block_11_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__value_number__optimize_block_11_0_i3);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__value_number__optimize_block_11_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__value_number__optimize_fragment_9_0),
		mercury__value_number__optimize_block_11_0_i7,
		STATIC(mercury__value_number__optimize_block_11_0));
Define_label(mercury__value_number__optimize_block_11_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_block_11_0));
	r4 = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__vn_debug__tuple_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__tuple_msg_5_0),
		mercury__value_number__optimize_block_11_0_i8,
		STATIC(mercury__value_number__optimize_block_11_0));
	}
Define_label(mercury__value_number__optimize_block_11_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_block_11_0));
	r4 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 3));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module7)
	init_entry(mercury__value_number__optimize_fragment_9_0);
	init_label(mercury__value_number__optimize_fragment_9_0_i2);
	init_label(mercury__value_number__optimize_fragment_9_0_i6);
	init_label(mercury__value_number__optimize_fragment_9_0_i7);
	init_label(mercury__value_number__optimize_fragment_9_0_i8);
	init_label(mercury__value_number__optimize_fragment_9_0_i9);
	init_label(mercury__value_number__optimize_fragment_9_0_i4);
	init_label(mercury__value_number__optimize_fragment_9_0_i3);
BEGIN_CODE

/* code for predicate 'value_number__optimize_fragment'/9 in mode 0 */
Define_static(mercury__value_number__optimize_fragment_9_0);
	incr_sp_push_msg(8, "value_number__optimize_fragment");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) r6;
	{
	Declare_entry(mercury__globals__io_get_gc_method_3_0);
	call_localret(ENTRY(mercury__globals__io_get_gc_method_3_0),
		mercury__value_number__optimize_fragment_9_0_i2,
		STATIC(mercury__value_number__optimize_fragment_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_9_0_i2);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_9_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__optimize_fragment_9_0_i3);
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_util__count_incr_hp_2_0);
	call_localret(ENTRY(mercury__opt_util__count_incr_hp_2_0),
		mercury__value_number__optimize_fragment_9_0_i6,
		STATIC(mercury__value_number__optimize_fragment_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_9_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_9_0));
	if (((Integer) r1 < ((Integer) 2)))
		GOTO_LABEL(mercury__value_number__optimize_fragment_9_0_i4);
	r1 = string_const("fragment with the error", 23);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__optimize_fragment_9_0_i7,
		STATIC(mercury__value_number__optimize_fragment_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_9_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_debug__dump_instrs_3_0);
	call_localret(ENTRY(mercury__vn_debug__dump_instrs_3_0),
		mercury__value_number__optimize_fragment_9_0_i8,
		STATIC(mercury__value_number__optimize_fragment_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_9_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = string_const("instruction sequence with several incr_hps in value_number__optimize_fragment", 77);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__optimize_fragment_9_0_i9,
		STATIC(mercury__value_number__optimize_fragment_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_9_0_i9);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_9_0));
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__value_number__optimize_fragment_9_0_i4);
	r2 = (Integer) detstackvar(7);
Define_label(mercury__value_number__optimize_fragment_9_0_i3);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__value_number__optimize_fragment_2_9_0),
		STATIC(mercury__value_number__optimize_fragment_9_0));
END_MODULE

BEGIN_MODULE(mercury__value_number_module8)
	init_entry(mercury__value_number__optimize_fragment_2_9_0);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i5);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i2);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i6);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i7);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i8);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i9);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i10);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i16);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i13);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i17);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i18);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i19);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i20);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i12);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i21);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i22);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i23);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i24);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i25);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i26);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i27);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i28);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i29);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i30);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i31);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i34);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i33);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i36);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i37);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i38);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i39);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i40);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i41);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i44);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i48);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i49);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i50);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i47);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i45);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i52);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i53);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i54);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i55);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i43);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i59);
	init_label(mercury__value_number__optimize_fragment_2_9_0_i60);
BEGIN_CODE

/* code for predicate 'value_number__optimize_fragment_2'/9 in mode 0 */
Define_static(mercury__value_number__optimize_fragment_2_9_0);
	incr_sp_push_msg(19, "value_number__optimize_fragment_2");
	detstackvar(19) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(8) = (Integer) r1;
	r2 = (Integer) r6;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__vn_debug__fragment_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__fragment_msg_3_0),
		mercury__value_number__optimize_fragment_2_9_0_i5,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i7);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = string_const("empty instruction sequence in value_number__optimize_fragment", 61);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__optimize_fragment_2_9_0_i6,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(15);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(15) = (Integer) r7;
	{
	Declare_entry(mercury__vn_block__build_block_info_9_0);
	call_localret(ENTRY(mercury__vn_block__build_block_info_9_0),
		mercury__value_number__optimize_fragment_2_9_0_i8,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(11) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	detstackvar(10) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 3));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	detstackvar(7) = (Integer) r2;
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	detstackvar(12) = (Integer) r4;
	{
	Declare_entry(mercury__vn_util__build_uses_4_0);
	call_localret(ENTRY(mercury__vn_util__build_uses_4_0),
		mercury__value_number__optimize_fragment_2_9_0_i9,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i9);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(13);
	r7 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__vn_order__order_9_0);
	call_localret(ENTRY(mercury__vn_order__order_9_0),
		mercury__value_number__optimize_fragment_2_9_0_i10,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i10);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i12);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i13);
	r3 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(14);
	call_localret(STATIC(mercury__value_number__try_again_9_0),
		mercury__value_number__optimize_fragment_2_9_0_i16,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
Define_label(mercury__value_number__optimize_fragment_2_9_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i18);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i13);
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(14);
	call_localret(STATIC(mercury__value_number__last_ditch_7_0),
		mercury__value_number__optimize_fragment_2_9_0_i17,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
Define_label(mercury__value_number__optimize_fragment_2_9_0_i17);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i18);
	detstackvar(7) = (Integer) r1;
	detstackvar(1) = (Integer) r6;
	{
	Declare_entry(mercury__vn_block__build_block_info_9_0);
	call_localret(ENTRY(mercury__vn_block__build_block_info_9_0),
		mercury__value_number__optimize_fragment_2_9_0_i19,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i19);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r3 = (Integer) r4;
	detstackvar(6) = (Integer) r4;
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_value_number__common_2);
	r2 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_debug__tuple_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__tuple_msg_5_0),
		mercury__value_number__optimize_fragment_2_9_0_i20,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i20);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__value_number__optimize_fragment_2_9_0_i12);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) r3;
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(14) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__vn_temploc__init_templocs_4_0);
	call_localret(ENTRY(mercury__vn_temploc__init_templocs_4_0),
		mercury__value_number__optimize_fragment_2_9_0_i21,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i21);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__vn_flush__nodelist_8_0);
	call_localret(ENTRY(mercury__vn_flush__nodelist_8_0),
		mercury__value_number__optimize_fragment_2_9_0_i22,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i22);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(7) = (Integer) r2;
	call_localret(STATIC(mercury__value_number__push_decr_sp_back_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i23,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
Define_label(mercury__value_number__optimize_fragment_2_9_0_i23);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	call_localret(STATIC(mercury__value_number__push_incr_sp_forw_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i24,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
Define_label(mercury__value_number__optimize_fragment_2_9_0_i24);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	call_localret(STATIC(mercury__value_number__push_livevals_back_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i25,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
Define_label(mercury__value_number__optimize_fragment_2_9_0_i25);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	call_localret(STATIC(mercury__value_number__convert_back_modframe_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i26,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
Define_label(mercury__value_number__optimize_fragment_2_9_0_i26);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(13) = (Integer) r1;
	{
	Declare_entry(mercury__vn_filter__block_2_0);
	call_localret(ENTRY(mercury__vn_filter__block_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i27,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i27);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__value_number__optimize_fragment_2_9_0_i28,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i28);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = ((Integer) 1);
	{
	Declare_entry(mercury__peephole__optimize_5_0);
	call_localret(ENTRY(mercury__peephole__optimize_5_0),
		mercury__value_number__optimize_fragment_2_9_0_i29,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i29);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(14) = (Integer) r1;
	r1 = string_const("original code sequence", 22);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__optimize_fragment_2_9_0_i30,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i30);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__vn_cost__block_cost_6_0);
	call_localret(ENTRY(mercury__vn_cost__block_cost_6_0),
		mercury__value_number__optimize_fragment_2_9_0_i31,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i31);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(15) = (Integer) r1;
	detstackvar(17) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__value_number__optimize_fragment_2_9_0_i34,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i34);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i33);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(14);
	r14 = (Integer) detstackvar(15);
	r2 = (Integer) detstackvar(17);
	r1 = string_const("new code sequence", 17);
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i38);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i33);
	r1 = string_const("unfiltered code sequence", 24);
	r2 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__optimize_fragment_2_9_0_i36,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i36);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__vn_cost__block_cost_6_0);
	call_localret(ENTRY(mercury__vn_cost__block_cost_6_0),
		mercury__value_number__optimize_fragment_2_9_0_i37,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i37);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r1 = string_const("new code sequence", 17);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(14);
	r14 = (Integer) detstackvar(15);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i38);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(14) = (Integer) r13;
	detstackvar(15) = (Integer) r14;
	{
	Declare_entry(mercury__vn_debug__cost_header_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__cost_header_msg_3_0),
		mercury__value_number__optimize_fragment_2_9_0_i39,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i39);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__vn_cost__block_cost_6_0);
	call_localret(ENTRY(mercury__vn_cost__block_cost_6_0),
		mercury__value_number__optimize_fragment_2_9_0_i40,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i40);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(16) = (Integer) r1;
	r1 = ((Integer) 128);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__value_number__optimize_fragment_2_9_0_i41,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i41);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	if (((Integer) detstackvar(16) < (Integer) detstackvar(15)))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i44);
	detstackvar(18) = (Integer) r2;
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i43);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i44);
	detstackvar(6) = (Integer) r1;
	detstackvar(18) = (Integer) r2;
	r1 = (Integer) mercury_data_llds__base_type_info_instr_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__assoc_list__keys_2_0);
	call_localret(ENTRY(mercury__assoc_list__keys_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i48,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i48);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_instr_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__assoc_list__keys_2_0);
	call_localret(ENTRY(mercury__assoc_list__keys_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i49,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i49);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_instr_0;
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__list__sublist_2_0);
	call_localret(ENTRY(mercury__list__sublist_2_0),
		mercury__value_number__optimize_fragment_2_9_0_i50,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i50);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i47);
	r1 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(15);
	r3 = (Integer) detstackvar(16);
	r4 = (Integer) detstackvar(18);
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i45);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i47);
	if ((((Integer) detstackvar(16) * ((Integer) 1000)) >= ((Integer) detstackvar(15) * (Integer) detstackvar(6))))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i43);
	r3 = (Integer) detstackvar(16);
	r2 = (Integer) detstackvar(15);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(18);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(14);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i45);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	r1 = ((Integer) 0);
	{
	Declare_entry(mercury__vn_debug__cost_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__cost_msg_5_0),
		mercury__value_number__optimize_fragment_2_9_0_i52,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i52);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_block__build_block_info_9_0);
	call_localret(ENTRY(mercury__vn_block__build_block_info_9_0),
		mercury__value_number__optimize_fragment_2_9_0_i53,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i53);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r9 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r4;
	r4 = (Integer) r3;
	r6 = (Integer) r2;
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__vn_verify__ok_11_0);
	call_localret(ENTRY(mercury__vn_verify__ok_11_0),
		mercury__value_number__optimize_fragment_2_9_0_i54,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i54);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i55);
	r4 = (Integer) r2;
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_value_number__common_3);
	r2 = (Integer) detstackvar(14);
	r3 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i60);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i55);
	r4 = (Integer) r2;
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_value_number__common_3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__value_number__optimize_fragment_2_9_0_i60);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i43);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(15);
	r3 = (Integer) detstackvar(16);
	r4 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__vn_debug__cost_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__cost_msg_5_0),
		mercury__value_number__optimize_fragment_2_9_0_i59,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
Define_label(mercury__value_number__optimize_fragment_2_9_0_i59);
	update_prof_current_proc(LABEL(mercury__value_number__optimize_fragment_2_9_0));
	r3 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_value_number__common_3);
Define_label(mercury__value_number__optimize_fragment_2_9_0_i60);
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__vn_debug__tuple_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__tuple_msg_5_0),
		mercury__value_number__optimize_fragment_2_9_0_i20,
		STATIC(mercury__value_number__optimize_fragment_2_9_0));
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module9)
	init_entry(mercury__value_number__try_again_9_0);
	init_label(mercury__value_number__try_again_9_0_i7);
	init_label(mercury__value_number__try_again_9_0_i12);
	init_label(mercury__value_number__try_again_9_0_i9);
	init_label(mercury__value_number__try_again_9_0_i13);
	init_label(mercury__value_number__try_again_9_0_i14);
	init_label(mercury__value_number__try_again_9_0_i15);
	init_label(mercury__value_number__try_again_9_0_i16);
	init_label(mercury__value_number__try_again_9_0_i17);
	init_label(mercury__value_number__try_again_9_0_i18);
	init_label(mercury__value_number__try_again_9_0_i19);
	init_label(mercury__value_number__try_again_9_0_i5);
	init_label(mercury__value_number__try_again_9_0_i1001);
	init_label(mercury__value_number__try_again_9_0_i4);
	init_label(mercury__value_number__try_again_9_0_i1000);
	init_label(mercury__value_number__try_again_9_0_i23);
BEGIN_CODE

/* code for predicate 'value_number__try_again'/9 in mode 0 */
Define_static(mercury__value_number__try_again_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__try_again_9_0_i1000);
	r8 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r9 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r10 = (Integer) field(mktag(0), (Integer) r9, ((Integer) 0));
	if ((tag((Integer) r10) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__try_again_9_0_i1001);
	incr_sp_push_msg(11, "value_number__try_again");
	detstackvar(11) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r10, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__value_number__try_again_9_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r8;
	r1 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r10, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__try_again_9_0_i7,
		STATIC(mercury__value_number__try_again_9_0));
	}
Define_label(mercury__value_number__try_again_9_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__try_again_9_0_i5);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__try_again_9_0_i9);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__value_number__last_ditch_7_0),
		mercury__value_number__try_again_9_0_i12,
		STATIC(mercury__value_number__try_again_9_0));
Define_label(mercury__value_number__try_again_9_0_i12);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__value_number__try_again_9_0_i9);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__vn_debug__divide_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__divide_msg_3_0),
		mercury__value_number__try_again_9_0_i13,
		STATIC(mercury__value_number__try_again_9_0));
	}
Define_label(mercury__value_number__try_again_9_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__try_again_9_0_i14,
		STATIC(mercury__value_number__try_again_9_0));
	}
	}
Define_label(mercury__value_number__try_again_9_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__value_number__optimize_fragment_9_0),
		mercury__value_number__try_again_9_0_i15,
		STATIC(mercury__value_number__try_again_9_0));
Define_label(mercury__value_number__try_again_9_0_i15);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r6 = (Integer) r3;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__value_number__optimize_fragment_9_0),
		mercury__value_number__try_again_9_0_i16,
		STATIC(mercury__value_number__try_again_9_0));
Define_label(mercury__value_number__try_again_9_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	detstackvar(7) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__try_again_9_0_i17,
		STATIC(mercury__value_number__try_again_9_0));
	}
Define_label(mercury__value_number__try_again_9_0_i17);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__value_number__try_again_9_0_i18,
		STATIC(mercury__value_number__try_again_9_0));
	}
Define_label(mercury__value_number__try_again_9_0_i18);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = ((Integer) 1);
	{
	Declare_entry(mercury__peephole__optimize_5_0);
	call_localret(ENTRY(mercury__peephole__optimize_5_0),
		mercury__value_number__try_again_9_0_i19,
		STATIC(mercury__value_number__try_again_9_0));
	}
Define_label(mercury__value_number__try_again_9_0_i19);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r2 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__value_number__try_again_9_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__value_number__try_again_9_0_i4);
Define_label(mercury__value_number__try_again_9_0_i1001);
	incr_sp_push_msg(11, "value_number__try_again");
	detstackvar(11) = (Integer) succip;
Define_label(mercury__value_number__try_again_9_0_i4);
	r1 = (Integer) r8;
	r8 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__value_number__try_again_9_0,
		STATIC(mercury__value_number__try_again_9_0));
Define_label(mercury__value_number__try_again_9_0_i1000);
	incr_sp_push_msg(11, "value_number__try_again");
	detstackvar(11) = (Integer) succip;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__try_again_9_0_i23,
		STATIC(mercury__value_number__try_again_9_0));
	}
Define_label(mercury__value_number__try_again_9_0_i23);
	update_prof_current_proc(LABEL(mercury__value_number__try_again_9_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	tailcall(STATIC(mercury__value_number__last_ditch_7_0),
		STATIC(mercury__value_number__try_again_9_0));
END_MODULE

BEGIN_MODULE(mercury__value_number_module10)
	init_entry(mercury__value_number__last_ditch_7_0);
	init_label(mercury__value_number__last_ditch_7_0_i1024);
	init_label(mercury__value_number__last_ditch_7_0_i1015);
	init_label(mercury__value_number__last_ditch_7_0_i9);
	init_label(mercury__value_number__last_ditch_7_0_i12);
	init_label(mercury__value_number__last_ditch_7_0_i13);
	init_label(mercury__value_number__last_ditch_7_0_i1006);
	init_label(mercury__value_number__last_ditch_7_0_i4);
	init_label(mercury__value_number__last_ditch_7_0_i14);
	init_label(mercury__value_number__last_ditch_7_0_i1004);
BEGIN_CODE

/* code for predicate 'value_number__last_ditch'/7 in mode 0 */
Define_static(mercury__value_number__last_ditch_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__last_ditch_7_0_i1004);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r8 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 0));
	if ((tag((Integer) r8) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__last_ditch_7_0_i1006);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r8, ((Integer) 0)),
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1015) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1015) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1015) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024) AND
		LABEL(mercury__value_number__last_ditch_7_0_i1024));
Define_label(mercury__value_number__last_ditch_7_0_i1024);
	incr_sp_push_msg(6, "value_number__last_ditch");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__value_number__last_ditch_7_0_i4);
Define_label(mercury__value_number__last_ditch_7_0_i1015);
	incr_sp_push_msg(6, "value_number__last_ditch");
	detstackvar(6) = (Integer) succip;
Define_label(mercury__value_number__last_ditch_7_0_i9);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) r7;
	r2 = (Integer) r5;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__vn_debug__restart_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__restart_msg_3_0),
		mercury__value_number__last_ditch_7_0_i12,
		STATIC(mercury__value_number__last_ditch_7_0));
	}
Define_label(mercury__value_number__last_ditch_7_0_i12);
	update_prof_current_proc(LABEL(mercury__value_number__last_ditch_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__value_number__optimize_fragment_9_0),
		mercury__value_number__last_ditch_7_0_i13,
		STATIC(mercury__value_number__last_ditch_7_0));
Define_label(mercury__value_number__last_ditch_7_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__last_ditch_7_0));
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__value_number__last_ditch_7_0_i1006);
	incr_sp_push_msg(6, "value_number__last_ditch");
	detstackvar(6) = (Integer) succip;
Define_label(mercury__value_number__last_ditch_7_0_i4);
	detstackvar(4) = (Integer) r7;
	r1 = (Integer) r6;
	localcall(mercury__value_number__last_ditch_7_0,
		LABEL(mercury__value_number__last_ditch_7_0_i14),
		STATIC(mercury__value_number__last_ditch_7_0));
Define_label(mercury__value_number__last_ditch_7_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__last_ditch_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__value_number__last_ditch_7_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module11)
	init_entry(mercury__value_number__process_parallel_tuples_7_0);
	init_label(mercury__value_number__process_parallel_tuples_7_0_i2);
	init_label(mercury__value_number__process_parallel_tuples_7_0_i3);
	init_label(mercury__value_number__process_parallel_tuples_7_0_i6);
	init_label(mercury__value_number__process_parallel_tuples_7_0_i7);
	init_label(mercury__value_number__process_parallel_tuples_7_0_i4);
	init_label(mercury__value_number__process_parallel_tuples_7_0_i8);
BEGIN_CODE

/* code for predicate 'value_number__process_parallel_tuples'/7 in mode 0 */
Define_static(mercury__value_number__process_parallel_tuples_7_0);
	incr_sp_push_msg(7, "value_number__process_parallel_tuples");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_1);
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__value_number__process_parallel_tuples_7_0_i2,
		STATIC(mercury__value_number__process_parallel_tuples_7_0));
	}
Define_label(mercury__value_number__process_parallel_tuples_7_0_i2);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_4);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__value_number__process_parallel_tuples_7_0_i3,
		STATIC(mercury__value_number__process_parallel_tuples_7_0));
	}
Define_label(mercury__value_number__process_parallel_tuples_7_0_i3);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_7_0));
	if (((Integer) detstackvar(6) != (Integer) r1))
		GOTO_LABEL(mercury__value_number__process_parallel_tuples_7_0_i4);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) r1;
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__value_number__process_parallel_tuples_2_9_0),
		mercury__value_number__process_parallel_tuples_7_0_i6,
		STATIC(mercury__value_number__process_parallel_tuples_7_0));
Define_label(mercury__value_number__process_parallel_tuples_7_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__value_number__insert_new_blocks_3_0),
		mercury__value_number__process_parallel_tuples_7_0_i7,
		STATIC(mercury__value_number__process_parallel_tuples_7_0));
	}
Define_label(mercury__value_number__process_parallel_tuples_7_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_7_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__value_number__process_parallel_tuples_7_0_i4);
	r1 = string_const("number of tuples and blocks differ", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__process_parallel_tuples_7_0_i8,
		STATIC(mercury__value_number__process_parallel_tuples_7_0));
	}
Define_label(mercury__value_number__process_parallel_tuples_7_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_7_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module12)
	init_entry(mercury__value_number__insert_new_blocks_3_0);
	init_label(mercury__value_number__insert_new_blocks_3_0_i4);
	init_label(mercury__value_number__insert_new_blocks_3_0_i5);
	init_label(mercury__value_number__insert_new_blocks_3_0_i1006);
BEGIN_CODE

/* code for predicate 'value_number__insert_new_blocks'/3 in mode 0 */
Define_static(mercury__value_number__insert_new_blocks_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__insert_new_blocks_3_0_i1006);
	incr_sp_push_msg(3, "value_number__insert_new_blocks");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__value_number__find_block_by_label_5_0),
		mercury__value_number__insert_new_blocks_3_0_i4,
		STATIC(mercury__value_number__insert_new_blocks_3_0));
Define_label(mercury__value_number__insert_new_blocks_3_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__insert_new_blocks_3_0));
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_4);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__value_number__insert_new_blocks_3_0_i5,
		STATIC(mercury__value_number__insert_new_blocks_3_0));
	}
	}
Define_label(mercury__value_number__insert_new_blocks_3_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__insert_new_blocks_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__value_number__insert_new_blocks_3_0,
		STATIC(mercury__value_number__insert_new_blocks_3_0));
Define_label(mercury__value_number__insert_new_blocks_3_0_i1006);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module13)
	init_entry(mercury__value_number__process_parallel_tuples_2_9_0);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i1007);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i7);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i8);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i11);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i14);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i13);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i16);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i10);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i9);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i18);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i19);
	init_label(mercury__value_number__process_parallel_tuples_2_9_0_i1005);
BEGIN_CODE

/* code for predicate 'value_number__process_parallel_tuples_2'/9 in mode 0 */
Define_static(mercury__value_number__process_parallel_tuples_2_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i1005);
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i1007);
	r7 = (Integer) r8;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	incr_sp_push_msg(11, "value_number__process_parallel_tuples_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i8);
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i1007);
	incr_sp_push_msg(11, "value_number__process_parallel_tuples_2");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r7;
	r1 = string_const("tuples and blocks not in sync", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__process_parallel_tuples_2_9_0_i7,
		STATIC(mercury__value_number__process_parallel_tuples_2_9_0));
	}
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_2_9_0));
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i8);
	if (((Integer) r8 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i10);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_5);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r8, ((Integer) 0)), ((Integer) 4));
	{
	Declare_entry(mercury__map__values_2_0);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__value_number__process_parallel_tuples_2_9_0_i11,
		STATIC(mercury__value_number__process_parallel_tuples_2_9_0));
	}
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_2_9_0));
	detstackvar(10) = (Integer) r1;
	call_localret(STATIC(mercury__value_number__all_empty_lists__ua0_1_0),
		mercury__value_number__process_parallel_tuples_2_9_0_i14,
		STATIC(mercury__value_number__process_parallel_tuples_2_9_0));
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_2_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i13);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(9);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i9);
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i13);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__value_number__process_parallel_nodes_9_0),
		mercury__value_number__process_parallel_tuples_2_9_0_i16,
		STATIC(mercury__value_number__process_parallel_tuples_2_9_0));
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_2_9_0));
	r6 = (Integer) r3;
	r7 = (Integer) r1;
	r8 = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i9);
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i10);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i9);
	detstackvar(4) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	localcall(mercury__value_number__process_parallel_tuples_2_9_0,
		LABEL(mercury__value_number__process_parallel_tuples_2_9_0_i18),
		STATIC(mercury__value_number__process_parallel_tuples_2_9_0));
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i18);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_2_9_0));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	tempr2 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r3;
	r3 = (Integer) tempr2;
	detstackvar(4) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__process_parallel_tuples_2_9_0_i19,
		STATIC(mercury__value_number__process_parallel_tuples_2_9_0));
	}
	}
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i19);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_tuples_2_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__value_number__process_parallel_tuples_2_9_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module14)
	init_entry(mercury__value_number__process_parallel_nodes_9_0);
	init_label(mercury__value_number__process_parallel_nodes_9_0_i4);
	init_label(mercury__value_number__process_parallel_nodes_9_0_i5);
	init_label(mercury__value_number__process_parallel_nodes_9_0_i6);
	init_label(mercury__value_number__process_parallel_nodes_9_0_i7);
	init_label(mercury__value_number__process_parallel_nodes_9_0_i8);
	init_label(mercury__value_number__process_parallel_nodes_9_0_i1005);
BEGIN_CODE

/* code for predicate 'value_number__process_parallel_nodes'/9 in mode 0 */
Define_static(mercury__value_number__process_parallel_nodes_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_nodes_9_0_i1005);
	incr_sp_push_msg(7, "value_number__process_parallel_nodes");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__vn_block__split_at_next_ctrl_instr_4_0);
	call_localret(ENTRY(mercury__vn_block__split_at_next_ctrl_instr_4_0),
		mercury__value_number__process_parallel_nodes_9_0_i4,
		STATIC(mercury__value_number__process_parallel_nodes_9_0));
	}
Define_label(mercury__value_number__process_parallel_nodes_9_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_nodes_9_0));
	r6 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__value_number__process_parallels_9_0),
		mercury__value_number__process_parallel_nodes_9_0_i5,
		STATIC(mercury__value_number__process_parallel_nodes_9_0));
Define_label(mercury__value_number__process_parallel_nodes_9_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_nodes_9_0));
	r5 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	localcall(mercury__value_number__process_parallel_nodes_9_0,
		LABEL(mercury__value_number__process_parallel_nodes_9_0_i6),
		STATIC(mercury__value_number__process_parallel_nodes_9_0));
Define_label(mercury__value_number__process_parallel_nodes_9_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_nodes_9_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r2 = (Integer) tempr1;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__value_number__process_parallel_nodes_9_0_i7,
		STATIC(mercury__value_number__process_parallel_nodes_9_0));
	}
	}
Define_label(mercury__value_number__process_parallel_nodes_9_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_nodes_9_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_6);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__process_parallel_nodes_9_0_i8,
		STATIC(mercury__value_number__process_parallel_nodes_9_0));
	}
Define_label(mercury__value_number__process_parallel_nodes_9_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_nodes_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__value_number__process_parallel_nodes_9_0_i1005);
	r1 = (Integer) r4;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module15)
	init_entry(mercury__value_number__process_parallels_9_0);
	init_label(mercury__value_number__process_parallels_9_0_i1005);
	init_label(mercury__value_number__process_parallels_9_0_i15);
	init_label(mercury__value_number__process_parallels_9_0_i17);
	init_label(mercury__value_number__process_parallels_9_0_i14);
	init_label(mercury__value_number__process_parallels_9_0_i9);
	init_label(mercury__value_number__process_parallels_9_0_i5);
	init_label(mercury__value_number__process_parallels_9_0_i32);
	init_label(mercury__value_number__process_parallels_9_0_i34);
	init_label(mercury__value_number__process_parallels_9_0_i31);
	init_label(mercury__value_number__process_parallels_9_0_i26);
	init_label(mercury__value_number__process_parallels_9_0_i22);
	init_label(mercury__value_number__process_parallels_9_0_i42);
	init_label(mercury__value_number__process_parallels_9_0_i43);
	init_label(mercury__value_number__process_parallels_9_0_i44);
	init_label(mercury__value_number__process_parallels_9_0_i39);
BEGIN_CODE

/* code for predicate 'value_number__process_parallels'/9 in mode 0 */
Define_static(mercury__value_number__process_parallels_9_0);
	r7 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	r8 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i1005);
	r1 = (Integer) r4;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r6;
	proceed();
Define_label(mercury__value_number__process_parallels_9_0_i1005);
	incr_sp_push_msg(9, "value_number__process_parallels");
	detstackvar(9) = (Integer) succip;
	if ((tag((Integer) r8) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i5);
	if (((Integer) field(mktag(3), (Integer) r8, ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i5);
	r9 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 2));
	if ((tag((Integer) r9) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i5);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i9);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i9);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r2;
	detstackvar(7) = (Integer) tempr2;
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r9, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__process_parallels_9_0_i15,
		STATIC(mercury__value_number__process_parallels_9_0));
	}
	}
Define_label(mercury__value_number__process_parallels_9_0_i15);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i14);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__value_number__process_parallel_8_0),
		mercury__value_number__process_parallels_9_0_i17,
		STATIC(mercury__value_number__process_parallels_9_0));
Define_label(mercury__value_number__process_parallels_9_0_i17);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__value_number__process_parallels_9_0_i14);
	r1 = string_const("wrong label in parallel for if_val", 34);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__process_parallels_9_0));
	}
Define_label(mercury__value_number__process_parallels_9_0_i9);
	r1 = string_const("more than one parallel for if_val", 33);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__process_parallels_9_0));
	}
Define_label(mercury__value_number__process_parallels_9_0_i5);
	if ((tag((Integer) r8) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i22);
	if (((Integer) field(mktag(3), (Integer) r8, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i22);
	r9 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 1));
	if ((tag((Integer) r9) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i22);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i26);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i26);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) tempr2;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r9, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__process_parallels_9_0_i32,
		STATIC(mercury__value_number__process_parallels_9_0));
	}
	}
Define_label(mercury__value_number__process_parallels_9_0_i32);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i31);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__value_number__process_parallel_8_0),
		mercury__value_number__process_parallels_9_0_i34,
		STATIC(mercury__value_number__process_parallels_9_0));
Define_label(mercury__value_number__process_parallels_9_0_i34);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__value_number__process_parallels_9_0_i31);
	r1 = string_const("wrong label in parallel for goto", 32);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__process_parallels_9_0));
	}
Define_label(mercury__value_number__process_parallels_9_0_i26);
	r1 = string_const("more than one parallel for goto", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__process_parallels_9_0));
	}
Define_label(mercury__value_number__process_parallels_9_0_i22);
	if ((tag((Integer) r8) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i39);
	if (((Integer) field(mktag(3), (Integer) r8, ((Integer) 0)) != ((Integer) 7)))
		GOTO_LABEL(mercury__value_number__process_parallels_9_0_i39);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	call_localret(STATIC(mercury__value_number__pair_labels_pars_3_0),
		mercury__value_number__process_parallels_9_0_i42,
		STATIC(mercury__value_number__process_parallels_9_0));
Define_label(mercury__value_number__process_parallels_9_0_i42);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_debug__computed_goto_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__computed_goto_msg_5_0),
		mercury__value_number__process_parallels_9_0_i43,
		STATIC(mercury__value_number__process_parallels_9_0));
	}
Define_label(mercury__value_number__process_parallels_9_0_i43);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__value_number__process_parallel_list_8_0),
		mercury__value_number__process_parallels_9_0_i44,
		STATIC(mercury__value_number__process_parallels_9_0));
Define_label(mercury__value_number__process_parallels_9_0_i44);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallels_9_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__value_number__process_parallels_9_0_i39);
	r1 = (Integer) r4;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r6;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module16)
	init_entry(mercury__value_number__pair_labels_pars_3_0);
	init_label(mercury__value_number__pair_labels_pars_3_0_i6);
	init_label(mercury__value_number__pair_labels_pars_3_0_i5);
	init_label(mercury__value_number__pair_labels_pars_3_0_i8);
	init_label(mercury__value_number__pair_labels_pars_3_0_i9);
	init_label(mercury__value_number__pair_labels_pars_3_0_i3);
	init_label(mercury__value_number__pair_labels_pars_3_0_i14);
BEGIN_CODE

/* code for predicate 'value_number__pair_labels_pars'/3 in mode 0 */
Define_static(mercury__value_number__pair_labels_pars_3_0);
	incr_sp_push_msg(5, "value_number__pair_labels_pars");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__pair_labels_pars_3_0_i3);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__value_number__find_parallel_for_label_4_0),
		mercury__value_number__pair_labels_pars_3_0_i6,
		STATIC(mercury__value_number__pair_labels_pars_3_0));
Define_label(mercury__value_number__pair_labels_pars_3_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__pair_labels_pars_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__pair_labels_pars_3_0_i5);
	r4 = (Integer) r2;
	r2 = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	r1 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__value_number__pair_labels_pars_3_0_i8);
	}
Define_label(mercury__value_number__pair_labels_pars_3_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__value_number__pair_labels_pars_3_0_i8);
	detstackvar(4) = (Integer) r3;
	localcall(mercury__value_number__pair_labels_pars_3_0,
		LABEL(mercury__value_number__pair_labels_pars_3_0_i9),
		STATIC(mercury__value_number__pair_labels_pars_3_0));
Define_label(mercury__value_number__pair_labels_pars_3_0_i9);
	update_prof_current_proc(LABEL(mercury__value_number__pair_labels_pars_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__value_number__pair_labels_pars_3_0_i3);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__pair_labels_pars_3_0_i14);
	r1 = string_const("parallel without corresponding label", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__pair_labels_pars_3_0_i14,
		STATIC(mercury__value_number__pair_labels_pars_3_0));
	}
Define_label(mercury__value_number__pair_labels_pars_3_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__pair_labels_pars_3_0));
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module17)
	init_entry(mercury__value_number__find_parallel_for_label_4_0);
	init_label(mercury__value_number__find_parallel_for_label_4_0_i5);
	init_label(mercury__value_number__find_parallel_for_label_4_0_i4);
	init_label(mercury__value_number__find_parallel_for_label_4_0_i7);
	init_label(mercury__value_number__find_parallel_for_label_4_0_i1004);
	init_label(mercury__value_number__find_parallel_for_label_4_0_i1);
BEGIN_CODE

/* code for predicate 'value_number__find_parallel_for_label'/4 in mode 0 */
Define_static(mercury__value_number__find_parallel_for_label_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__find_parallel_for_label_4_0_i1004);
	incr_sp_push_msg(4, "value_number__find_parallel_for_label");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__find_parallel_for_label_4_0_i5,
		STATIC(mercury__value_number__find_parallel_for_label_4_0));
	}
Define_label(mercury__value_number__find_parallel_for_label_4_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__find_parallel_for_label_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__find_parallel_for_label_4_0_i4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__value_number__find_parallel_for_label_4_0_i4);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__value_number__find_parallel_for_label_4_0,
		LABEL(mercury__value_number__find_parallel_for_label_4_0_i7),
		STATIC(mercury__value_number__find_parallel_for_label_4_0));
Define_label(mercury__value_number__find_parallel_for_label_4_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__find_parallel_for_label_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__find_parallel_for_label_4_0_i1);
	r1 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__value_number__find_parallel_for_label_4_0_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__value_number__find_parallel_for_label_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module18)
	init_entry(mercury__value_number__process_parallel_list_8_0);
	init_label(mercury__value_number__process_parallel_list_8_0_i9);
	init_label(mercury__value_number__process_parallel_list_8_0_i8);
	init_label(mercury__value_number__process_parallel_list_8_0_i11);
	init_label(mercury__value_number__process_parallel_list_8_0_i12);
	init_label(mercury__value_number__process_parallel_list_8_0_i13);
	init_label(mercury__value_number__process_parallel_list_8_0_i14);
	init_label(mercury__value_number__process_parallel_list_8_0_i15);
	init_label(mercury__value_number__process_parallel_list_8_0_i4);
	init_label(mercury__value_number__process_parallel_list_8_0_i16);
	init_label(mercury__value_number__process_parallel_list_8_0_i1005);
BEGIN_CODE

/* code for predicate 'value_number__process_parallel_list'/8 in mode 0 */
Define_static(mercury__value_number__process_parallel_list_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_list_8_0_i1005);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	incr_sp_push_msg(9, "value_number__process_parallel_list");
	detstackvar(9) = (Integer) succip;
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_list_8_0_i4);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(8) = (Integer) tempr1;
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) r7;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__process_parallel_list_8_0_i9,
		STATIC(mercury__value_number__process_parallel_list_8_0));
	}
	}
Define_label(mercury__value_number__process_parallel_list_8_0_i9);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_list_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__process_parallel_list_8_0_i8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__value_number__process_parallel_list_8_0_i12);
Define_label(mercury__value_number__process_parallel_list_8_0_i8);
	r1 = string_const("wrong label in parallel for computed_goto", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__process_parallel_list_8_0_i11,
		STATIC(mercury__value_number__process_parallel_list_8_0));
	}
Define_label(mercury__value_number__process_parallel_list_8_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_list_8_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
Define_label(mercury__value_number__process_parallel_list_8_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	call_localret(STATIC(mercury__value_number__process_parallel_8_0),
		mercury__value_number__process_parallel_list_8_0_i13,
		STATIC(mercury__value_number__process_parallel_list_8_0));
Define_label(mercury__value_number__process_parallel_list_8_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_list_8_0));
	r5 = (Integer) r3;
	detstackvar(4) = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__value_number__process_parallel_list_8_0,
		LABEL(mercury__value_number__process_parallel_list_8_0_i14),
		STATIC(mercury__value_number__process_parallel_list_8_0));
Define_label(mercury__value_number__process_parallel_list_8_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_list_8_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__value_number__process_parallel_list_8_0_i15,
		STATIC(mercury__value_number__process_parallel_list_8_0));
	}
	}
Define_label(mercury__value_number__process_parallel_list_8_0_i15);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_list_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__value_number__process_parallel_list_8_0_i4);
	detstackvar(1) = (Integer) r7;
	r1 = (Integer) r6;
	localcall(mercury__value_number__process_parallel_list_8_0,
		LABEL(mercury__value_number__process_parallel_list_8_0_i16),
		STATIC(mercury__value_number__process_parallel_list_8_0));
Define_label(mercury__value_number__process_parallel_list_8_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_list_8_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__value_number__process_parallel_list_8_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module19)
	init_entry(mercury__value_number__process_parallel_8_0);
	init_label(mercury__value_number__process_parallel_8_0_i2);
	init_label(mercury__value_number__process_parallel_8_0_i3);
	init_label(mercury__value_number__process_parallel_8_0_i4);
	init_label(mercury__value_number__process_parallel_8_0_i5);
	init_label(mercury__value_number__process_parallel_8_0_i6);
	init_label(mercury__value_number__process_parallel_8_0_i13);
	init_label(mercury__value_number__process_parallel_8_0_i15);
	init_label(mercury__value_number__process_parallel_8_0_i10);
	init_label(mercury__value_number__process_parallel_8_0_i9);
	init_label(mercury__value_number__process_parallel_8_0_i16);
	init_label(mercury__value_number__process_parallel_8_0_i7);
BEGIN_CODE

/* code for predicate 'value_number__process_parallel'/8 in mode 0 */
Define_static(mercury__value_number__process_parallel_8_0);
	incr_sp_push_msg(7, "value_number__process_parallel");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__vn_debug__parallel_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__parallel_msg_3_0),
		mercury__value_number__process_parallel_8_0_i2,
		STATIC(mercury__value_number__process_parallel_8_0));
	}
Define_label(mercury__value_number__process_parallel_8_0_i2);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	detstackvar(6) = (Integer) r1;
	r3 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	call_localret(STATIC(mercury__value_number__find_block_by_label_5_0),
		mercury__value_number__process_parallel_8_0_i3,
		STATIC(mercury__value_number__process_parallel_8_0));
Define_label(mercury__value_number__process_parallel_8_0_i3);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	r4 = (Integer) detstackvar(1);
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = ((Integer) 2000);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r7 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__value_number__optimize_block_11_0),
		mercury__value_number__process_parallel_8_0_i4,
		STATIC(mercury__value_number__process_parallel_8_0));
Define_label(mercury__value_number__process_parallel_8_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	{
	Declare_entry(mercury__vn_cost__block_cost_6_0);
	call_localret(ENTRY(mercury__vn_cost__block_cost_6_0),
		mercury__value_number__process_parallel_8_0_i5,
		STATIC(mercury__value_number__process_parallel_8_0));
	}
Define_label(mercury__value_number__process_parallel_8_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	{
	Declare_entry(mercury__vn_cost__block_cost_6_0);
	call_localret(ENTRY(mercury__vn_cost__block_cost_6_0),
		mercury__value_number__process_parallel_8_0_i6,
		STATIC(mercury__value_number__process_parallel_8_0));
	}
Define_label(mercury__value_number__process_parallel_8_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	if (((Integer) r1 >= (Integer) detstackvar(2)))
		GOTO_LABEL(mercury__value_number__process_parallel_8_0_i7);
	r1 = (Integer) detstackvar(5);
	if (((Integer) detstackvar(1) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__process_parallel_8_0_i9);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__process_parallel_8_0_i9);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__value_number__process_parallel_8_0_i9);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__process_parallel_8_0_i13,
		STATIC(mercury__value_number__process_parallel_8_0));
	}
	}
Define_label(mercury__value_number__process_parallel_8_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__process_parallel_8_0_i10);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__opt_util__filter_out_labels_2_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_labels_2_0),
		mercury__value_number__process_parallel_8_0_i15,
		STATIC(mercury__value_number__process_parallel_8_0));
	}
Define_label(mercury__value_number__process_parallel_8_0_i15);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__value_number__process_parallel_8_0_i10);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
Define_label(mercury__value_number__process_parallel_8_0_i9);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = string_const("block starts with wrong label", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__process_parallel_8_0_i16,
		STATIC(mercury__value_number__process_parallel_8_0));
	}
Define_label(mercury__value_number__process_parallel_8_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__process_parallel_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__value_number__process_parallel_8_0_i7);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module20)
	init_entry(mercury__value_number__find_block_by_label_5_0);
	init_label(mercury__value_number__find_block_by_label_5_0_i10);
	init_label(mercury__value_number__find_block_by_label_5_0_i8);
	init_label(mercury__value_number__find_block_by_label_5_0_i1011);
	init_label(mercury__value_number__find_block_by_label_5_0_i7);
	init_label(mercury__value_number__find_block_by_label_5_0_i12);
	init_label(mercury__value_number__find_block_by_label_5_0_i1010);
	init_label(mercury__value_number__find_block_by_label_5_0_i16);
	init_label(mercury__value_number__find_block_by_label_5_0_i17);
	init_label(mercury__value_number__find_block_by_label_5_0_i1008);
BEGIN_CODE

/* code for predicate 'value_number__find_block_by_label'/5 in mode 0 */
Define_static(mercury__value_number__find_block_by_label_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__find_block_by_label_5_0_i1010);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__find_block_by_label_5_0_i1008);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r4, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__find_block_by_label_5_0_i1011);
	incr_sp_push_msg(4, "value_number__find_block_by_label");
	detstackvar(4) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__value_number__find_block_by_label_5_0_i7);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__value_number__find_block_by_label_5_0_i10,
		STATIC(mercury__value_number__find_block_by_label_5_0));
	}
Define_label(mercury__value_number__find_block_by_label_5_0_i10);
	update_prof_current_proc(LABEL(mercury__value_number__find_block_by_label_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__find_block_by_label_5_0_i8);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__value_number__find_block_by_label_5_0_i8);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__value_number__find_block_by_label_5_0_i7);
Define_label(mercury__value_number__find_block_by_label_5_0_i1011);
	incr_sp_push_msg(4, "value_number__find_block_by_label");
	detstackvar(4) = (Integer) succip;
Define_label(mercury__value_number__find_block_by_label_5_0_i7);
	detstackvar(2) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__value_number__find_block_by_label_5_0,
		LABEL(mercury__value_number__find_block_by_label_5_0_i12),
		STATIC(mercury__value_number__find_block_by_label_5_0));
Define_label(mercury__value_number__find_block_by_label_5_0_i12);
	update_prof_current_proc(LABEL(mercury__value_number__find_block_by_label_5_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__value_number__find_block_by_label_5_0_i1010);
	incr_sp_push_msg(4, "value_number__find_block_by_label");
	detstackvar(4) = (Integer) succip;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_label_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__value_number__find_block_by_label_5_0_i16,
		STATIC(mercury__value_number__find_block_by_label_5_0));
	}
Define_label(mercury__value_number__find_block_by_label_5_0_i16);
	update_prof_current_proc(LABEL(mercury__value_number__find_block_by_label_5_0));
	r2 = (Integer) r1;
	r1 = string_const("Cannot find block with label ", 29);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__value_number__find_block_by_label_5_0_i17,
		STATIC(mercury__value_number__find_block_by_label_5_0));
	}
Define_label(mercury__value_number__find_block_by_label_5_0_i17);
	update_prof_current_proc(LABEL(mercury__value_number__find_block_by_label_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__find_block_by_label_5_0));
	}
Define_label(mercury__value_number__find_block_by_label_5_0_i1008);
	r1 = string_const("found empty block", 17);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__find_block_by_label_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module21)
	init_entry(mercury__value_number__convert_back_modframe_2_0);
	init_label(mercury__value_number__convert_back_modframe_2_0_i12);
	init_label(mercury__value_number__convert_back_modframe_2_0_i13);
	init_label(mercury__value_number__convert_back_modframe_2_0_i3);
	init_label(mercury__value_number__convert_back_modframe_2_0_i11);
	init_label(mercury__value_number__convert_back_modframe_2_0_i1);
BEGIN_CODE

/* code for predicate 'value_number__convert_back_modframe'/2 in mode 0 */
Define_static(mercury__value_number__convert_back_modframe_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i1);
	r6 = (Integer) sp;
Define_label(mercury__value_number__convert_back_modframe_2_0_i12);
	while (1) {
	incr_sp_push_msg(1, "value_number__convert_back_modframe");
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__value_number__convert_back_modframe_2_0_i13);
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 1)), ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 1)), ((Integer) 1))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if (((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 1)), ((Integer) 1)), ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 2))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 2)), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 2)), ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 2)), ((Integer) 1)), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 2)), ((Integer) 1)), ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("recovered modframe", 18);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i11);
	}
Define_label(mercury__value_number__convert_back_modframe_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__value_number__convert_back_modframe_2_0_i11);
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r6))
		GOTO_LABEL(mercury__value_number__convert_back_modframe_2_0_i13);
	proceed();
Define_label(mercury__value_number__convert_back_modframe_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module22)
	init_entry(mercury__value_number__push_decr_sp_back_2_0);
	init_label(mercury__value_number__push_decr_sp_back_2_0_i1006);
	init_label(mercury__value_number__push_decr_sp_back_2_0_i8);
	init_label(mercury__value_number__push_decr_sp_back_2_0_i1004);
BEGIN_CODE

/* code for predicate 'value_number__push_decr_sp_back'/2 in mode 0 */
Define_static(mercury__value_number__push_decr_sp_back_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_decr_sp_back_2_0_i1004);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__push_decr_sp_back_2_0_i1006);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 16)))
		GOTO_LABEL(mercury__value_number__push_decr_sp_back_2_0_i1006);
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	tailcall(STATIC(mercury__value_number__push_decr_sp_back_2_3_0),
		STATIC(mercury__value_number__push_decr_sp_back_2_0));
Define_label(mercury__value_number__push_decr_sp_back_2_0_i1006);
	incr_sp_push_msg(2, "value_number__push_decr_sp_back");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__value_number__push_decr_sp_back_2_0,
		LABEL(mercury__value_number__push_decr_sp_back_2_0_i8),
		STATIC(mercury__value_number__push_decr_sp_back_2_0));
Define_label(mercury__value_number__push_decr_sp_back_2_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__push_decr_sp_back_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__value_number__push_decr_sp_back_2_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module23)
	init_entry(mercury__value_number__push_decr_sp_back_2_3_0);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i4);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i7);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i6);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i8);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i10);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i11);
	init_label(mercury__value_number__push_decr_sp_back_2_3_0_i1015);
BEGIN_CODE

/* code for predicate 'value_number__push_decr_sp_back_2'/3 in mode 0 */
Define_static(mercury__value_number__push_decr_sp_back_2_3_0);
	incr_sp_push_msg(5, "value_number__push_decr_sp_back_2");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_decr_sp_back_2_3_0_i1015);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__value_number__boundary_instr_2_0),
		mercury__value_number__push_decr_sp_back_2_3_0_i4,
		STATIC(mercury__value_number__push_decr_sp_back_2_3_0));
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__push_decr_sp_back_2_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_decr_sp_back_2_3_0_i6);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	localcall(mercury__value_number__push_decr_sp_back_2_3_0,
		LABEL(mercury__value_number__push_decr_sp_back_2_3_0_i7),
		STATIC(mercury__value_number__push_decr_sp_back_2_3_0));
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__push_decr_sp_back_2_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i6);
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	tempr2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) tempr2, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = string_const("", 0);
	r3 = (Integer) tempr2;
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__value_number__push_decr_sp_back_2_3_0_i8,
		STATIC(mercury__value_number__push_decr_sp_back_2_3_0));
	}
	}
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__push_decr_sp_back_2_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_decr_sp_back_2_3_0_i10);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i10);
	r1 = string_const("cannot push decr_sp back enough", 31);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__push_decr_sp_back_2_3_0_i11,
		STATIC(mercury__value_number__push_decr_sp_back_2_3_0));
	}
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__push_decr_sp_back_2_3_0));
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__value_number__push_decr_sp_back_2_3_0_i1015);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module24)
	init_entry(mercury__value_number__push_incr_sp_forw_2_0);
	init_label(mercury__value_number__push_incr_sp_forw_2_0_i2);
	init_label(mercury__value_number__push_incr_sp_forw_2_0_i3);
	init_label(mercury__value_number__push_incr_sp_forw_2_0_i6);
	init_label(mercury__value_number__push_incr_sp_forw_2_0_i5);
BEGIN_CODE

/* code for predicate 'value_number__push_incr_sp_forw'/2 in mode 0 */
Define_static(mercury__value_number__push_incr_sp_forw_2_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	incr_sp_push_msg(1, "value_number__push_incr_sp_forw");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__push_incr_sp_forw_2_0_i2,
		STATIC(mercury__value_number__push_incr_sp_forw_2_0));
	}
Define_label(mercury__value_number__push_incr_sp_forw_2_0_i2);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_2_0));
	call_localret(STATIC(mercury__value_number__push_incr_sp_forw_rev_3_0),
		mercury__value_number__push_incr_sp_forw_2_0_i3,
		STATIC(mercury__value_number__push_incr_sp_forw_2_0));
Define_label(mercury__value_number__push_incr_sp_forw_2_0_i3);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_2_0_i5);
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__value_number__push_save_succip_forw_rev_3_0),
		mercury__value_number__push_incr_sp_forw_2_0_i6,
		STATIC(mercury__value_number__push_incr_sp_forw_2_0));
Define_label(mercury__value_number__push_incr_sp_forw_2_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__value_number__push_incr_sp_forw_2_0));
	}
Define_label(mercury__value_number__push_incr_sp_forw_2_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__value_number__push_incr_sp_forw_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module25)
	init_entry(mercury__value_number__push_incr_sp_forw_rev_3_0);
	init_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i7);
	init_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i1007);
	init_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i4);
	init_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i8);
	init_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i1005);
BEGIN_CODE

/* code for predicate 'value_number__push_incr_sp_forw_rev'/3 in mode 0 */
Define_static(mercury__value_number__push_incr_sp_forw_rev_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_rev_3_0_i1005);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_rev_3_0_i1007);
	incr_sp_push_msg(2, "value_number__push_incr_sp_forw_rev");
	detstackvar(2) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 15)))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_rev_3_0_i4);
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__value_number__push_incr_sp_forw_rev_2_4_0),
		mercury__value_number__push_incr_sp_forw_rev_3_0_i7,
		STATIC(mercury__value_number__push_incr_sp_forw_rev_3_0));
Define_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_rev_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i1007);
	incr_sp_push_msg(2, "value_number__push_incr_sp_forw_rev");
	detstackvar(2) = (Integer) succip;
Define_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__value_number__push_incr_sp_forw_rev_3_0,
		LABEL(mercury__value_number__push_incr_sp_forw_rev_3_0_i8),
		STATIC(mercury__value_number__push_incr_sp_forw_rev_3_0));
Define_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_rev_3_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__value_number__push_incr_sp_forw_rev_3_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module26)
	init_entry(mercury__value_number__push_incr_sp_forw_rev_2_4_0);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i4);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i7);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i6);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i8);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i10);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i11);
	init_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i1015);
BEGIN_CODE

/* code for predicate 'value_number__push_incr_sp_forw_rev_2'/4 in mode 0 */
Define_static(mercury__value_number__push_incr_sp_forw_rev_2_4_0);
	incr_sp_push_msg(6, "value_number__push_incr_sp_forw_rev_2");
	detstackvar(6) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i1015);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) tempr1;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	call_localret(STATIC(mercury__value_number__boundary_instr_2_0),
		mercury__value_number__push_incr_sp_forw_rev_2_4_0_i4,
		STATIC(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	}
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i6);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	localcall(mercury__value_number__push_incr_sp_forw_rev_2_4_0,
		LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i7),
		STATIC(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i6);
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	tempr2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) tempr2, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = string_const("", 0);
	r3 = (Integer) tempr2;
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__value_number__push_incr_sp_forw_rev_2_4_0_i8,
		STATIC(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	}
	}
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i10);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i10);
	r1 = string_const("cannot push incr_sp forward enough", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__push_incr_sp_forw_rev_2_4_0_i11,
		STATIC(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	}
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__push_incr_sp_forw_rev_2_4_0));
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__value_number__push_incr_sp_forw_rev_2_4_0_i1015);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module27)
	init_entry(mercury__value_number__push_save_succip_forw_rev_3_0);
	init_label(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	init_label(mercury__value_number__push_save_succip_forw_rev_3_0_i11);
	init_label(mercury__value_number__push_save_succip_forw_rev_3_0_i1009);
BEGIN_CODE

/* code for predicate 'value_number__push_save_succip_forw_rev'/3 in mode 0 */
Define_static(mercury__value_number__push_save_succip_forw_rev_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1009);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	if ((tag((Integer) field(mktag(3), (Integer) r5, ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r5, ((Integer) 1)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	if (((Integer) r2 != (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r5, ((Integer) 1)), ((Integer) 1))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	if ((tag((Integer) field(mktag(3), (Integer) r5, ((Integer) 2))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	if (((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r5, ((Integer) 2)), ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	r1 = (Integer) r3;
	tailcall(STATIC(mercury__value_number__push_save_succip_forw_rev_2_3_0),
		STATIC(mercury__value_number__push_save_succip_forw_rev_3_0));
Define_label(mercury__value_number__push_save_succip_forw_rev_3_0_i1011);
	incr_sp_push_msg(2, "value_number__push_save_succip_forw_rev");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__value_number__push_save_succip_forw_rev_3_0,
		LABEL(mercury__value_number__push_save_succip_forw_rev_3_0_i11),
		STATIC(mercury__value_number__push_save_succip_forw_rev_3_0));
Define_label(mercury__value_number__push_save_succip_forw_rev_3_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__push_save_succip_forw_rev_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__value_number__push_save_succip_forw_rev_3_0_i1009);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module28)
	init_entry(mercury__value_number__push_save_succip_forw_rev_2_3_0);
	init_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1011);
	init_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i4);
	init_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i7);
	init_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1010);
BEGIN_CODE

/* code for predicate 'value_number__push_save_succip_forw_rev_2'/3 in mode 0 */
Define_static(mercury__value_number__push_save_succip_forw_rev_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1010);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1011);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 15)))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1011);
	incr_sp_push_msg(2, "value_number__push_save_succip_forw_rev_2");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != (Integer) field(mktag(3), (Integer) r5, ((Integer) 1))))
		GOTO_LABEL(mercury__value_number__push_save_succip_forw_rev_2_3_0_i4);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_7);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1011);
	incr_sp_push_msg(2, "value_number__push_save_succip_forw_rev_2");
	detstackvar(2) = (Integer) succip;
Define_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i4);
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__value_number__push_save_succip_forw_rev_2_3_0,
		LABEL(mercury__value_number__push_save_succip_forw_rev_2_3_0_i7),
		STATIC(mercury__value_number__push_save_succip_forw_rev_2_3_0));
Define_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__push_save_succip_forw_rev_2_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__value_number__push_save_succip_forw_rev_2_3_0_i1010);
	r1 = string_const("succip save without incr_sp", 27);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__value_number__push_save_succip_forw_rev_2_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module29)
	init_entry(mercury__value_number__push_livevals_back_2_0);
	init_label(mercury__value_number__push_livevals_back_2_0_i1005);
	init_label(mercury__value_number__push_livevals_back_2_0_i8);
	init_label(mercury__value_number__push_livevals_back_2_0_i1003);
BEGIN_CODE

/* code for predicate 'value_number__push_livevals_back'/2 in mode 0 */
Define_static(mercury__value_number__push_livevals_back_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_livevals_back_2_0_i1003);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__value_number__push_livevals_back_2_0_i1005);
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(2), (Integer) r4, ((Integer) 0));
	tailcall(STATIC(mercury__value_number__push_livevals_back_2_3_0),
		STATIC(mercury__value_number__push_livevals_back_2_0));
Define_label(mercury__value_number__push_livevals_back_2_0_i1005);
	incr_sp_push_msg(2, "value_number__push_livevals_back");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__value_number__push_livevals_back_2_0,
		LABEL(mercury__value_number__push_livevals_back_2_0_i8),
		STATIC(mercury__value_number__push_livevals_back_2_0));
Define_label(mercury__value_number__push_livevals_back_2_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__push_livevals_back_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__value_number__push_livevals_back_2_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module30)
	init_entry(mercury__value_number__push_livevals_back_2_3_0);
	init_label(mercury__value_number__push_livevals_back_2_3_0_i4);
	init_label(mercury__value_number__push_livevals_back_2_3_0_i5);
	init_label(mercury__value_number__push_livevals_back_2_3_0_i10);
	init_label(mercury__value_number__push_livevals_back_2_3_0_i6);
	init_label(mercury__value_number__push_livevals_back_2_3_0_i11);
	init_label(mercury__value_number__push_livevals_back_2_3_0_i1013);
BEGIN_CODE

/* code for predicate 'value_number__push_livevals_back_2'/3 in mode 0 */
Define_static(mercury__value_number__push_livevals_back_2_3_0);
	incr_sp_push_msg(6, "value_number__push_livevals_back_2");
	detstackvar(6) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__push_livevals_back_2_3_0_i1013);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__value_number__boundary_instr_2_0),
		mercury__value_number__push_livevals_back_2_3_0_i4,
		STATIC(mercury__value_number__push_livevals_back_2_3_0));
Define_label(mercury__value_number__push_livevals_back_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__push_livevals_back_2_3_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(3), ((Integer) 0));
	{
	Declare_entry(mercury__opt_util__can_instr_branch_away_2_0);
	call_localret(ENTRY(mercury__opt_util__can_instr_branch_away_2_0),
		mercury__value_number__push_livevals_back_2_3_0_i5,
		STATIC(mercury__value_number__push_livevals_back_2_3_0));
	}
Define_label(mercury__value_number__push_livevals_back_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__value_number__push_livevals_back_2_3_0));
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_livevals_back_2_3_0_i6);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__push_livevals_back_2_3_0_i6);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__value_number__push_livevals_back_2_0),
		mercury__value_number__push_livevals_back_2_3_0_i10,
		STATIC(mercury__value_number__push_livevals_back_2_3_0));
Define_label(mercury__value_number__push_livevals_back_2_3_0_i10);
	update_prof_current_proc(LABEL(mercury__value_number__push_livevals_back_2_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__value_number__push_livevals_back_2_3_0_i6);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	localcall(mercury__value_number__push_livevals_back_2_3_0,
		LABEL(mercury__value_number__push_livevals_back_2_3_0_i11),
		STATIC(mercury__value_number__push_livevals_back_2_3_0));
Define_label(mercury__value_number__push_livevals_back_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__value_number__push_livevals_back_2_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__value_number__push_livevals_back_2_3_0_i1013);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__value_number_module31)
	init_entry(mercury__value_number__boundary_instr_2_0);
	init_label(mercury__value_number__boundary_instr_2_0_i5);
	init_label(mercury__value_number__boundary_instr_2_0_i7);
	init_label(mercury__value_number__boundary_instr_2_0_i4);
	init_label(mercury__value_number__boundary_instr_2_0_i23);
	init_label(mercury__value_number__boundary_instr_2_0_i24);
BEGIN_CODE

/* code for predicate 'value_number__boundary_instr'/2 in mode 0 */
Define_static(mercury__value_number__boundary_instr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__boundary_instr_2_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__value_number__boundary_instr_2_0_i5) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i5) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i5) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i5) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i5) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7) AND
		LABEL(mercury__value_number__boundary_instr_2_0_i7));
Define_label(mercury__value_number__boundary_instr_2_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__value_number__boundary_instr_2_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__value_number__boundary_instr_2_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__value_number__boundary_instr_2_0_i23);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__value_number__boundary_instr_2_0_i23);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__value_number__boundary_instr_2_0_i24);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__value_number__boundary_instr_2_0_i24);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module32)
	init_entry(mercury__value_number__has_no_backward_branches_2_2_0);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i7);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i1008);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i4);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i8);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i9);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i1005);
	init_label(mercury__value_number__has_no_backward_branches_2_2_0_i1);
BEGIN_CODE

/* code for predicate 'value_number__has_no_backward_branches_2'/2 in mode 0 */
Define_static(mercury__value_number__has_no_backward_branches_2_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__has_no_backward_branches_2_2_0_i1005);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__has_no_backward_branches_2_2_0_i1008);
	incr_sp_push_msg(3, "value_number__has_no_backward_branches_2");
	detstackvar(3) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__value_number__has_no_backward_branches_2_2_0_i4);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__value_number__has_no_backward_branches_2_2_0_i7,
		STATIC(mercury__value_number__has_no_backward_branches_2_2_0));
	}
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i7);
	update_prof_current_proc(LABEL(mercury__value_number__has_no_backward_branches_2_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__value_number__has_no_backward_branches_2_2_0,
		STATIC(mercury__value_number__has_no_backward_branches_2_2_0));
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i1008);
	incr_sp_push_msg(3, "value_number__has_no_backward_branches_2");
	detstackvar(3) = (Integer) succip;
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__opt_util__instr_labels_3_0);
	call_localret(ENTRY(mercury__opt_util__instr_labels_3_0),
		mercury__value_number__has_no_backward_branches_2_2_0_i8,
		STATIC(mercury__value_number__has_no_backward_branches_2_2_0));
	}
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i8);
	update_prof_current_proc(LABEL(mercury__value_number__has_no_backward_branches_2_2_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__value_number__no_old_labels_2_0),
		mercury__value_number__has_no_backward_branches_2_2_0_i9,
		STATIC(mercury__value_number__has_no_backward_branches_2_2_0));
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i9);
	update_prof_current_proc(LABEL(mercury__value_number__has_no_backward_branches_2_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__value_number__has_no_backward_branches_2_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__value_number__has_no_backward_branches_2_2_0,
		STATIC(mercury__value_number__has_no_backward_branches_2_2_0));
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury__value_number__has_no_backward_branches_2_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module33)
	init_entry(mercury__value_number__no_old_labels_2_0);
	init_label(mercury__value_number__no_old_labels_2_0_i6);
	init_label(mercury__value_number__no_old_labels_2_0_i1003);
	init_label(mercury__value_number__no_old_labels_2_0_i1);
BEGIN_CODE

/* code for predicate 'value_number__no_old_labels'/2 in mode 0 */
Define_static(mercury__value_number__no_old_labels_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__no_old_labels_2_0_i1003);
	incr_sp_push_msg(3, "value_number__no_old_labels");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__value_number__no_old_labels_2_0_i6,
		STATIC(mercury__value_number__no_old_labels_2_0));
	}
Define_label(mercury__value_number__no_old_labels_2_0_i6);
	update_prof_current_proc(LABEL(mercury__value_number__no_old_labels_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__value_number__no_old_labels_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__value_number__no_old_labels_2_0,
		STATIC(mercury__value_number__no_old_labels_2_0));
Define_label(mercury__value_number__no_old_labels_2_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__value_number__no_old_labels_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__value_number_module34)
	init_entry(mercury__value_number__post_main_2_5_0);
	init_label(mercury__value_number__post_main_2_5_0_i4);
	init_label(mercury__value_number__post_main_2_5_0_i8);
	init_label(mercury__value_number__post_main_2_5_0_i7);
	init_label(mercury__value_number__post_main_2_5_0_i12);
	init_label(mercury__value_number__post_main_2_5_0_i13);
	init_label(mercury__value_number__post_main_2_5_0_i14);
	init_label(mercury__value_number__post_main_2_5_0_i11);
	init_label(mercury__value_number__post_main_2_5_0_i18);
	init_label(mercury__value_number__post_main_2_5_0_i19);
	init_label(mercury__value_number__post_main_2_5_0_i15);
	init_label(mercury__value_number__post_main_2_5_0_i5);
	init_label(mercury__value_number__post_main_2_5_0_i23);
	init_label(mercury__value_number__post_main_2_5_0_i3);
	init_label(mercury__value_number__post_main_2_5_0_i25);
	init_label(mercury__value_number__post_main_2_5_0_i31);
	init_label(mercury__value_number__post_main_2_5_0_i36);
BEGIN_CODE

/* code for predicate 'value_number__post_main_2'/5 in mode 0 */
Define_static(mercury__value_number__post_main_2_5_0);
	incr_sp_push_msg(8, "value_number__post_main_2");
	detstackvar(8) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) tempr1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r4;
	{
	Declare_entry(mercury__opt_util__count_temps_instr_5_0);
	call_localret(ENTRY(mercury__opt_util__count_temps_instr_5_0),
		mercury__value_number__post_main_2_5_0_i4,
		STATIC(mercury__value_number__post_main_2_5_0));
	}
	}
Define_label(mercury__value_number__post_main_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	if (((Integer) r1 <= ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i8);
	r5 = (Integer) r1;
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__value_number__post_main_2_5_0_i7);
Define_label(mercury__value_number__post_main_2_5_0_i8);
	if (((Integer) r2 <= ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i5);
	r5 = (Integer) r1;
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
Define_label(mercury__value_number__post_main_2_5_0_i7);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__value_number__post_main_2_5_0_i12,
		STATIC(mercury__value_number__post_main_2_5_0));
	}
Define_label(mercury__value_number__post_main_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i11);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__post_main_2_5_0_i13,
		STATIC(mercury__value_number__post_main_2_5_0));
	}
Define_label(mercury__value_number__post_main_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 0);
	r3 = ((Integer) 0);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__value_number__post_main_2_5_0,
		LABEL(mercury__value_number__post_main_2_5_0_i14),
		STATIC(mercury__value_number__post_main_2_5_0));
Define_label(mercury__value_number__post_main_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__value_number__post_main_2_5_0_i11);
	r3 = (Integer) detstackvar(4);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i15);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i15);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_value_number__common_0);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__value_number__post_main_2_5_0_i18,
		STATIC(mercury__value_number__post_main_2_5_0));
	}
Define_label(mercury__value_number__post_main_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 0);
	r3 = ((Integer) 0);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__value_number__post_main_2_5_0,
		LABEL(mercury__value_number__post_main_2_5_0_i19),
		STATIC(mercury__value_number__post_main_2_5_0));
Define_label(mercury__value_number__post_main_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__value_number__post_main_2_5_0_i15);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__value_number__post_main_2_5_0,
		STATIC(mercury__value_number__post_main_2_5_0));
Define_label(mercury__value_number__post_main_2_5_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 0);
	r3 = ((Integer) 0);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__value_number__post_main_2_5_0,
		LABEL(mercury__value_number__post_main_2_5_0_i23),
		STATIC(mercury__value_number__post_main_2_5_0));
Define_label(mercury__value_number__post_main_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__value_number__post_main_2_5_0_i3);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i25);
	r1 = string_const("procedure ends with fallthrough", 31);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__post_main_2_5_0_i36,
		STATIC(mercury__value_number__post_main_2_5_0));
	}
Define_label(mercury__value_number__post_main_2_5_0_i25);
	if (((Integer) r2 > ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i31);
	if (((Integer) r3 <= ((Integer) 0)))
		GOTO_LABEL(mercury__value_number__post_main_2_5_0_i36);
Define_label(mercury__value_number__post_main_2_5_0_i31);
	r1 = string_const("procedure ends without closing block", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__value_number__post_main_2_5_0_i36,
		STATIC(mercury__value_number__post_main_2_5_0));
	}
Define_label(mercury__value_number__post_main_2_5_0_i36);
	update_prof_current_proc(LABEL(mercury__value_number__post_main_2_5_0));
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__value_number_bunch_0(void)
{
	mercury__value_number_module0();
	mercury__value_number_module1();
	mercury__value_number_module2();
	mercury__value_number_module3();
	mercury__value_number_module4();
	mercury__value_number_module5();
	mercury__value_number_module6();
	mercury__value_number_module7();
	mercury__value_number_module8();
	mercury__value_number_module9();
	mercury__value_number_module10();
	mercury__value_number_module11();
	mercury__value_number_module12();
	mercury__value_number_module13();
	mercury__value_number_module14();
	mercury__value_number_module15();
	mercury__value_number_module16();
	mercury__value_number_module17();
	mercury__value_number_module18();
	mercury__value_number_module19();
	mercury__value_number_module20();
	mercury__value_number_module21();
	mercury__value_number_module22();
	mercury__value_number_module23();
	mercury__value_number_module24();
	mercury__value_number_module25();
	mercury__value_number_module26();
	mercury__value_number_module27();
	mercury__value_number_module28();
	mercury__value_number_module29();
	mercury__value_number_module30();
	mercury__value_number_module31();
	mercury__value_number_module32();
	mercury__value_number_module33();
	mercury__value_number_module34();
}

#endif

void mercury__value_number__init(void); /* suppress gcc warning */
void mercury__value_number__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__value_number_bunch_0();
#endif
}
