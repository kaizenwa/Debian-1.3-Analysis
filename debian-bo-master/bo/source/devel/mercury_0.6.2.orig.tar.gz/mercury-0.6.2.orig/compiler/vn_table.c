/*
** Automatically generated from `vn_table.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_table__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___vn_table_vn_tables_0__ua10000_2_0);
Define_extern_entry(mercury__vn_table__init_tables_1_0);
Declare_label(mercury__vn_table__init_tables_1_0_i2);
Declare_label(mercury__vn_table__init_tables_1_0_i3);
Declare_label(mercury__vn_table__init_tables_1_0_i4);
Declare_label(mercury__vn_table__init_tables_1_0_i5);
Declare_label(mercury__vn_table__init_tables_1_0_i6);
Declare_label(mercury__vn_table__init_tables_1_0_i7);
Define_extern_entry(mercury__vn_table__get_next_vn_2_0);
Define_extern_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
Define_extern_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
Define_extern_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
Define_extern_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
Define_extern_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
Define_extern_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
Define_extern_entry(mercury__vn_table__lookup_desired_value_4_0);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i2);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i5);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i4);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i7);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i8);
Define_extern_entry(mercury__vn_table__lookup_assigned_vn_4_0);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i2);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i5);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i4);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i7);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i8);
Define_extern_entry(mercury__vn_table__lookup_defn_4_0);
Declare_label(mercury__vn_table__lookup_defn_4_0_i2);
Declare_label(mercury__vn_table__lookup_defn_4_0_i5);
Declare_label(mercury__vn_table__lookup_defn_4_0_i4);
Declare_label(mercury__vn_table__lookup_defn_4_0_i7);
Declare_label(mercury__vn_table__lookup_defn_4_0_i8);
Define_extern_entry(mercury__vn_table__lookup_uses_4_0);
Declare_label(mercury__vn_table__lookup_uses_4_0_i2);
Declare_label(mercury__vn_table__lookup_uses_4_0_i5);
Declare_label(mercury__vn_table__lookup_uses_4_0_i4);
Declare_label(mercury__vn_table__lookup_uses_4_0_i7);
Declare_label(mercury__vn_table__lookup_uses_4_0_i8);
Define_extern_entry(mercury__vn_table__lookup_current_locs_4_0);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i2);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i5);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i4);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i7);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i8);
Define_extern_entry(mercury__vn_table__lookup_current_value_4_0);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i2);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i5);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i4);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i7);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i8);
Define_extern_entry(mercury__vn_table__search_desired_value_3_0);
Declare_label(mercury__vn_table__search_desired_value_3_0_i2);
Declare_label(mercury__vn_table__search_desired_value_3_0_i3);
Declare_label(mercury__vn_table__search_desired_value_3_0_i1000);
Define_extern_entry(mercury__vn_table__search_assigned_vn_3_0);
Declare_label(mercury__vn_table__search_assigned_vn_3_0_i2);
Declare_label(mercury__vn_table__search_assigned_vn_3_0_i3);
Declare_label(mercury__vn_table__search_assigned_vn_3_0_i1000);
Define_extern_entry(mercury__vn_table__search_defn_3_0);
Declare_label(mercury__vn_table__search_defn_3_0_i2);
Declare_label(mercury__vn_table__search_defn_3_0_i3);
Declare_label(mercury__vn_table__search_defn_3_0_i1000);
Define_extern_entry(mercury__vn_table__search_uses_3_0);
Declare_label(mercury__vn_table__search_uses_3_0_i2);
Declare_label(mercury__vn_table__search_uses_3_0_i3);
Declare_label(mercury__vn_table__search_uses_3_0_i1000);
Define_extern_entry(mercury__vn_table__search_current_locs_3_0);
Declare_label(mercury__vn_table__search_current_locs_3_0_i2);
Declare_label(mercury__vn_table__search_current_locs_3_0_i3);
Declare_label(mercury__vn_table__search_current_locs_3_0_i1000);
Define_extern_entry(mercury__vn_table__search_current_value_3_0);
Declare_label(mercury__vn_table__search_current_value_3_0_i2);
Declare_label(mercury__vn_table__search_current_value_3_0_i3);
Declare_label(mercury__vn_table__search_current_value_3_0_i1000);
Define_extern_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
Declare_label(mercury__vn_table__get_vnlval_vn_list_2_0_i2);
Define_extern_entry(mercury__vn_table__add_new_use_4_0);
Declare_label(mercury__vn_table__add_new_use_4_0_i4);
Declare_label(mercury__vn_table__add_new_use_4_0_i3);
Declare_label(mercury__vn_table__add_new_use_4_0_i6);
Declare_label(mercury__vn_table__add_new_use_4_0_i7);
Declare_label(mercury__vn_table__add_new_use_4_0_i10);
Declare_label(mercury__vn_table__add_new_use_4_0_i15);
Declare_label(mercury__vn_table__add_new_use_4_0_i17);
Declare_label(mercury__vn_table__add_new_use_4_0_i20);
Declare_label(mercury__vn_table__add_new_use_4_0_i21);
Declare_label(mercury__vn_table__add_new_use_4_0_i22);
Declare_label(mercury__vn_table__add_new_use_4_0_i14);
Declare_label(mercury__vn_table__add_new_use_4_0_i12);
Declare_label(mercury__vn_table__add_new_use_4_0_i24);
Declare_label(mercury__vn_table__add_new_use_4_0_i25);
Declare_label(mercury__vn_table__add_new_use_4_0_i26);
Declare_label(mercury__vn_table__add_new_use_4_0_i27);
Declare_label(mercury__vn_table__add_new_use_4_0_i28);
Declare_label(mercury__vn_table__add_new_use_4_0_i1019);
Declare_label(mercury__vn_table__add_new_use_4_0_i9);
Declare_label(mercury__vn_table__add_new_use_4_0_i1036);
Declare_label(mercury__vn_table__add_new_use_4_0_i29);
Declare_label(mercury__vn_table__add_new_use_4_0_i30);
Define_extern_entry(mercury__vn_table__del_old_use_4_0);
Declare_label(mercury__vn_table__del_old_use_4_0_i4);
Declare_label(mercury__vn_table__del_old_use_4_0_i3);
Declare_label(mercury__vn_table__del_old_use_4_0_i6);
Declare_label(mercury__vn_table__del_old_use_4_0_i7);
Declare_label(mercury__vn_table__del_old_use_4_0_i10);
Declare_label(mercury__vn_table__del_old_use_4_0_i9);
Declare_label(mercury__vn_table__del_old_use_4_0_i12);
Declare_label(mercury__vn_table__del_old_use_4_0_i13);
Define_extern_entry(mercury__vn_table__del_old_uses_4_0);
Declare_label(mercury__vn_table__del_old_uses_4_0_i4);
Declare_label(mercury__vn_table__del_old_uses_4_0_i1002);
Define_extern_entry(mercury__vn_table__record_first_vnrval_4_0);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i2);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i3);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i4);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i5);
Define_extern_entry(mercury__vn_table__record_first_vnlval_4_0);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i2);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i3);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i4);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i5);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i6);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i7);
Define_extern_entry(mercury__vn_table__set_desired_value_4_0);
Declare_label(mercury__vn_table__set_desired_value_4_0_i4);
Declare_label(mercury__vn_table__set_desired_value_4_0_i6);
Declare_label(mercury__vn_table__set_desired_value_4_0_i3);
Declare_label(mercury__vn_table__set_desired_value_4_0_i7);
Declare_label(mercury__vn_table__set_desired_value_4_0_i8);
Define_extern_entry(mercury__vn_table__set_current_value_4_0);
Declare_label(mercury__vn_table__set_current_value_4_0_i4);
Declare_label(mercury__vn_table__set_current_value_4_0_i6);
Declare_label(mercury__vn_table__set_current_value_4_0_i7);
Declare_label(mercury__vn_table__set_current_value_4_0_i8);
Declare_label(mercury__vn_table__set_current_value_4_0_i9);
Declare_label(mercury__vn_table__set_current_value_4_0_i10);
Declare_label(mercury__vn_table__set_current_value_4_0_i11);
Declare_label(mercury__vn_table__set_current_value_4_0_i12);
Declare_label(mercury__vn_table__set_current_value_4_0_i3);
Declare_label(mercury__vn_table__set_current_value_4_0_i13);
Declare_label(mercury__vn_table__set_current_value_4_0_i14);
Declare_label(mercury__vn_table__set_current_value_4_0_i15);
Declare_label(mercury__vn_table__set_current_value_4_0_i16);
Define_extern_entry(mercury__vn_table__set_parallel_value_4_0);
Declare_label(mercury__vn_table__set_parallel_value_4_0_i2);
Define_extern_entry(mercury__vn_table__get_all_vnrvals_2_0);
Define_extern_entry(mercury____Unify___vn_table__vn_tables_0_0);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i2);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i4);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i6);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i8);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i10);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i1007);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i1);
Define_extern_entry(mercury____Index___vn_table__vn_tables_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_tables_0_0);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i4);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i5);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i3);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i10);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i16);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i22);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i28);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i34);
Define_extern_entry(mercury____Unify___vn_table__lval_to_vn_table_0_0);
Define_extern_entry(mercury____Index___vn_table__lval_to_vn_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__lval_to_vn_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__rval_to_vn_table_0_0);
Define_extern_entry(mercury____Index___vn_table__rval_to_vn_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__rval_to_vn_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__vn_to_rval_table_0_0);
Define_extern_entry(mercury____Index___vn_table__vn_to_rval_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_to_rval_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__vn_to_uses_table_0_0);
Define_extern_entry(mercury____Index___vn_table__vn_to_uses_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_to_uses_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__vn_to_locs_table_0_0);
Define_extern_entry(mercury____Index___vn_table__vn_to_locs_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_to_locs_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__loc_to_vn_table_0_0);
Define_extern_entry(mercury____Index___vn_table__loc_to_vn_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__loc_to_vn_table_0_0);

extern Word * mercury_data_vn_table__base_type_layout_loc_to_vn_table_0[];
Word * mercury_data_vn_table__base_type_info_loc_to_vn_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__loc_to_vn_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__loc_to_vn_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__loc_to_vn_table_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_loc_to_vn_table_0
};

extern Word * mercury_data_vn_table__base_type_layout_lval_to_vn_table_0[];
Word * mercury_data_vn_table__base_type_info_lval_to_vn_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__lval_to_vn_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__lval_to_vn_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__lval_to_vn_table_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_lval_to_vn_table_0
};

extern Word * mercury_data_vn_table__base_type_layout_rval_to_vn_table_0[];
Word * mercury_data_vn_table__base_type_info_rval_to_vn_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__rval_to_vn_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__rval_to_vn_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__rval_to_vn_table_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_rval_to_vn_table_0
};

extern Word * mercury_data_vn_table__base_type_layout_vn_tables_0[];
Word * mercury_data_vn_table__base_type_info_vn_tables_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__vn_tables_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__vn_tables_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__vn_tables_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_vn_tables_0
};

extern Word * mercury_data_vn_table__base_type_layout_vn_to_locs_table_0[];
Word * mercury_data_vn_table__base_type_info_vn_to_locs_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__vn_to_locs_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__vn_to_locs_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__vn_to_locs_table_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_vn_to_locs_table_0
};

extern Word * mercury_data_vn_table__base_type_layout_vn_to_rval_table_0[];
Word * mercury_data_vn_table__base_type_info_vn_to_rval_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__vn_to_rval_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__vn_to_rval_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__vn_to_rval_table_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_vn_to_rval_table_0
};

extern Word * mercury_data_vn_table__base_type_layout_vn_to_uses_table_0[];
Word * mercury_data_vn_table__base_type_info_vn_to_uses_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_table__vn_to_uses_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_table__vn_to_uses_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_table__vn_to_uses_table_0_0),
	(Word *) (Integer) mercury_data_vn_table__base_type_layout_vn_to_uses_table_0
};

extern Word * mercury_data_vn_table__common_5[];
Word * mercury_data_vn_table__base_type_layout_vn_to_uses_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_5)
};

extern Word * mercury_data_vn_table__common_7[];
Word * mercury_data_vn_table__base_type_layout_vn_to_rval_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_7)
};

extern Word * mercury_data_vn_table__common_9[];
Word * mercury_data_vn_table__base_type_layout_vn_to_locs_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_9)
};

extern Word * mercury_data_vn_table__common_13[];
Word * mercury_data_vn_table__base_type_layout_vn_tables_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_table__common_13),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_vn_table__common_14[];
Word * mercury_data_vn_table__base_type_layout_rval_to_vn_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_14)
};

extern Word * mercury_data_vn_table__common_15[];
Word * mercury_data_vn_table__base_type_layout_lval_to_vn_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15)
};

Word * mercury_data_vn_table__base_type_layout_loc_to_vn_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_table__common_15)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
Word * mercury_data_vn_table__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vn_src_0
};

extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
Word * mercury_data_vn_table__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0
};

Word * mercury_data_vn_table__common_2[] = {
	(Word *) string_const("new use already known", 21),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_vn_table__common_3[] = {
	(Word *) string_const("\n", 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_table__common_2)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_vn_table__common_4[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0)
};

Word * mercury_data_vn_table__common_5[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_4)
};

extern Word * mercury_data_vn_type__base_type_info_vnrval_0[];
Word * mercury_data_vn_table__common_6[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnrval_0
};

Word * mercury_data_vn_table__common_7[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_6)
};

Word * mercury_data_vn_table__common_8[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1)
};

Word * mercury_data_vn_table__common_9[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_8)
};

Word * mercury_data_vn_table__common_10[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_vn_table__common_11[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_vn_table__common_12[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnrval_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_vn_table__common_13[] = {
	(Word *) ((Integer) 7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_11),
	(Word *) string_const("vn_tables", 9)
};

Word * mercury_data_vn_table__common_14[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_12)
};

Word * mercury_data_vn_table__common_15[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_11)
};

BEGIN_MODULE(mercury__vn_table_module0)
	init_entry(mercury____Index___vn_table_vn_tables_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_table_vn_tables_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___vn_table_vn_tables_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module1)
	init_entry(mercury__vn_table__init_tables_1_0);
	init_label(mercury__vn_table__init_tables_1_0_i2);
	init_label(mercury__vn_table__init_tables_1_0_i3);
	init_label(mercury__vn_table__init_tables_1_0_i4);
	init_label(mercury__vn_table__init_tables_1_0_i5);
	init_label(mercury__vn_table__init_tables_1_0_i6);
	init_label(mercury__vn_table__init_tables_1_0_i7);
BEGIN_CODE

/* code for predicate 'vn_table__init_tables'/1 in mode 0 */
Define_entry(mercury__vn_table__init_tables_1_0);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(6, "vn_table__init_tables");
	detstackvar(6) = (Integer) succip;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i2,
		ENTRY(mercury__vn_table__init_tables_1_0));
	}
Define_label(mercury__vn_table__init_tables_1_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i3,
		ENTRY(mercury__vn_table__init_tables_1_0));
	}
Define_label(mercury__vn_table__init_tables_1_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i4,
		ENTRY(mercury__vn_table__init_tables_1_0));
	}
Define_label(mercury__vn_table__init_tables_1_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i5,
		ENTRY(mercury__vn_table__init_tables_1_0));
	}
Define_label(mercury__vn_table__init_tables_1_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i6,
		ENTRY(mercury__vn_table__init_tables_1_0));
	}
Define_label(mercury__vn_table__init_tables_1_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i7,
		ENTRY(mercury__vn_table__init_tables_1_0));
	}
Define_label(mercury__vn_table__init_tables_1_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module2)
	init_entry(mercury__vn_table__get_next_vn_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_next_vn'/2 in mode 0 */
Define_entry(mercury__vn_table__get_next_vn_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module3)
	init_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_lval_to_vn_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module4)
	init_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_rval_to_vn_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module5)
	init_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_vn_to_rval_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module6)
	init_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_vn_to_uses_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module7)
	init_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_vn_to_locs_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module8)
	init_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_loc_to_vn_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module9)
	init_entry(mercury__vn_table__lookup_desired_value_4_0);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i2);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i5);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i4);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i7);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__lookup_desired_value'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_desired_value_4_0);
	incr_sp_push_msg(3, "vn_table__lookup_desired_value");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_table__get_lval_to_vn_table_2_0),
		mercury__vn_table__lookup_desired_value_4_0_i2,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
	}
Define_label(mercury__vn_table__lookup_desired_value_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_desired_value_4_0_i5,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
	}
Define_label(mercury__vn_table__lookup_desired_value_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__lookup_desired_value_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_desired_value_4_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vnlval_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_table__lookup_desired_value_4_0_i7,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
	}
Define_label(mercury__vn_table__lookup_desired_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(": cannot find desired value for ", 32);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_desired_value_4_0_i8,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
	}
	}
Define_label(mercury__vn_table__lookup_desired_value_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module10)
	init_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i2);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i5);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i4);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i7);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__lookup_assigned_vn'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	incr_sp_push_msg(3, "vn_table__lookup_assigned_vn");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_table__get_rval_to_vn_table_2_0),
		mercury__vn_table__lookup_assigned_vn_4_0_i2,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
	}
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_assigned_vn_4_0_i5,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
	}
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__lookup_assigned_vn_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vnrval_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vnrval_2_0),
		mercury__vn_table__lookup_assigned_vn_4_0_i7,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
	}
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(": cannot find assigned vn for ", 30);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_assigned_vn_4_0_i8,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
	}
	}
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module11)
	init_entry(mercury__vn_table__lookup_defn_4_0);
	init_label(mercury__vn_table__lookup_defn_4_0_i2);
	init_label(mercury__vn_table__lookup_defn_4_0_i5);
	init_label(mercury__vn_table__lookup_defn_4_0_i4);
	init_label(mercury__vn_table__lookup_defn_4_0_i7);
	init_label(mercury__vn_table__lookup_defn_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__lookup_defn'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_defn_4_0);
	incr_sp_push_msg(3, "vn_table__lookup_defn");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_table__get_vn_to_rval_table_2_0),
		mercury__vn_table__lookup_defn_4_0_i2,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
	}
Define_label(mercury__vn_table__lookup_defn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_defn_4_0_i5,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
	}
Define_label(mercury__vn_table__lookup_defn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__lookup_defn_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_defn_4_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vn_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__lookup_defn_4_0_i7,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
	}
Define_label(mercury__vn_table__lookup_defn_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(": cannot find definition for ", 29);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_defn_4_0_i8,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
	}
	}
Define_label(mercury__vn_table__lookup_defn_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_defn_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module12)
	init_entry(mercury__vn_table__lookup_uses_4_0);
	init_label(mercury__vn_table__lookup_uses_4_0_i2);
	init_label(mercury__vn_table__lookup_uses_4_0_i5);
	init_label(mercury__vn_table__lookup_uses_4_0_i4);
	init_label(mercury__vn_table__lookup_uses_4_0_i7);
	init_label(mercury__vn_table__lookup_uses_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__lookup_uses'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_uses_4_0);
	incr_sp_push_msg(3, "vn_table__lookup_uses");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_table__get_vn_to_uses_table_2_0),
		mercury__vn_table__lookup_uses_4_0_i2,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
	}
Define_label(mercury__vn_table__lookup_uses_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_uses_4_0_i5,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
	}
Define_label(mercury__vn_table__lookup_uses_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__lookup_uses_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_uses_4_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vn_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__lookup_uses_4_0_i7,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
	}
Define_label(mercury__vn_table__lookup_uses_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(": cannot find uses for ", 23);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_uses_4_0_i8,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
	}
	}
Define_label(mercury__vn_table__lookup_uses_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_uses_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module13)
	init_entry(mercury__vn_table__lookup_current_locs_4_0);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i2);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i5);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i4);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i7);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__lookup_current_locs'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_current_locs_4_0);
	incr_sp_push_msg(3, "vn_table__lookup_current_locs");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_table__get_vn_to_locs_table_2_0),
		mercury__vn_table__lookup_current_locs_4_0_i2,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
	}
Define_label(mercury__vn_table__lookup_current_locs_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_current_locs_4_0_i5,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
	}
Define_label(mercury__vn_table__lookup_current_locs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__lookup_current_locs_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_current_locs_4_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vn_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__lookup_current_locs_4_0_i7,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
	}
Define_label(mercury__vn_table__lookup_current_locs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(": cannot find current locs for ", 31);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_current_locs_4_0_i8,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
	}
	}
Define_label(mercury__vn_table__lookup_current_locs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module14)
	init_entry(mercury__vn_table__lookup_current_value_4_0);
	init_label(mercury__vn_table__lookup_current_value_4_0_i2);
	init_label(mercury__vn_table__lookup_current_value_4_0_i5);
	init_label(mercury__vn_table__lookup_current_value_4_0_i4);
	init_label(mercury__vn_table__lookup_current_value_4_0_i7);
	init_label(mercury__vn_table__lookup_current_value_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__lookup_current_value'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_current_value_4_0);
	incr_sp_push_msg(3, "vn_table__lookup_current_value");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_table__get_loc_to_vn_table_2_0),
		mercury__vn_table__lookup_current_value_4_0_i2,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
	}
Define_label(mercury__vn_table__lookup_current_value_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_current_value_4_0_i5,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
	}
Define_label(mercury__vn_table__lookup_current_value_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__lookup_current_value_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_current_value_4_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vnlval_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_table__lookup_current_value_4_0_i7,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
	}
Define_label(mercury__vn_table__lookup_current_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(": cannot find current value for ", 32);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_current_value_4_0_i8,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
	}
	}
Define_label(mercury__vn_table__lookup_current_value_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module15)
	init_entry(mercury__vn_table__search_desired_value_3_0);
	init_label(mercury__vn_table__search_desired_value_3_0_i2);
	init_label(mercury__vn_table__search_desired_value_3_0_i3);
	init_label(mercury__vn_table__search_desired_value_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_table__search_desired_value'/3 in mode 0 */
Define_entry(mercury__vn_table__search_desired_value_3_0);
	incr_sp_push_msg(2, "vn_table__search_desired_value");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__get_lval_to_vn_table_2_0),
		mercury__vn_table__search_desired_value_3_0_i2,
		ENTRY(mercury__vn_table__search_desired_value_3_0));
	}
Define_label(mercury__vn_table__search_desired_value_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__search_desired_value_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__search_desired_value_3_0_i3,
		ENTRY(mercury__vn_table__search_desired_value_3_0));
	}
Define_label(mercury__vn_table__search_desired_value_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__search_desired_value_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__search_desired_value_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_table__search_desired_value_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module16)
	init_entry(mercury__vn_table__search_assigned_vn_3_0);
	init_label(mercury__vn_table__search_assigned_vn_3_0_i2);
	init_label(mercury__vn_table__search_assigned_vn_3_0_i3);
	init_label(mercury__vn_table__search_assigned_vn_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_table__search_assigned_vn'/3 in mode 0 */
Define_entry(mercury__vn_table__search_assigned_vn_3_0);
	incr_sp_push_msg(2, "vn_table__search_assigned_vn");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__get_rval_to_vn_table_2_0),
		mercury__vn_table__search_assigned_vn_3_0_i2,
		ENTRY(mercury__vn_table__search_assigned_vn_3_0));
	}
Define_label(mercury__vn_table__search_assigned_vn_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__search_assigned_vn_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__search_assigned_vn_3_0_i3,
		ENTRY(mercury__vn_table__search_assigned_vn_3_0));
	}
Define_label(mercury__vn_table__search_assigned_vn_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__search_assigned_vn_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__search_assigned_vn_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_table__search_assigned_vn_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module17)
	init_entry(mercury__vn_table__search_defn_3_0);
	init_label(mercury__vn_table__search_defn_3_0_i2);
	init_label(mercury__vn_table__search_defn_3_0_i3);
	init_label(mercury__vn_table__search_defn_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_table__search_defn'/3 in mode 0 */
Define_entry(mercury__vn_table__search_defn_3_0);
	incr_sp_push_msg(2, "vn_table__search_defn");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__get_vn_to_rval_table_2_0),
		mercury__vn_table__search_defn_3_0_i2,
		ENTRY(mercury__vn_table__search_defn_3_0));
	}
Define_label(mercury__vn_table__search_defn_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__search_defn_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__search_defn_3_0_i3,
		ENTRY(mercury__vn_table__search_defn_3_0));
	}
Define_label(mercury__vn_table__search_defn_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__search_defn_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__search_defn_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_table__search_defn_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module18)
	init_entry(mercury__vn_table__search_uses_3_0);
	init_label(mercury__vn_table__search_uses_3_0_i2);
	init_label(mercury__vn_table__search_uses_3_0_i3);
	init_label(mercury__vn_table__search_uses_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_table__search_uses'/3 in mode 0 */
Define_entry(mercury__vn_table__search_uses_3_0);
	incr_sp_push_msg(2, "vn_table__search_uses");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__get_vn_to_uses_table_2_0),
		mercury__vn_table__search_uses_3_0_i2,
		ENTRY(mercury__vn_table__search_uses_3_0));
	}
Define_label(mercury__vn_table__search_uses_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__search_uses_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__search_uses_3_0_i3,
		ENTRY(mercury__vn_table__search_uses_3_0));
	}
Define_label(mercury__vn_table__search_uses_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__search_uses_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__search_uses_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_table__search_uses_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module19)
	init_entry(mercury__vn_table__search_current_locs_3_0);
	init_label(mercury__vn_table__search_current_locs_3_0_i2);
	init_label(mercury__vn_table__search_current_locs_3_0_i3);
	init_label(mercury__vn_table__search_current_locs_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_table__search_current_locs'/3 in mode 0 */
Define_entry(mercury__vn_table__search_current_locs_3_0);
	incr_sp_push_msg(2, "vn_table__search_current_locs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__get_vn_to_locs_table_2_0),
		mercury__vn_table__search_current_locs_3_0_i2,
		ENTRY(mercury__vn_table__search_current_locs_3_0));
	}
Define_label(mercury__vn_table__search_current_locs_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__search_current_locs_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__search_current_locs_3_0_i3,
		ENTRY(mercury__vn_table__search_current_locs_3_0));
	}
Define_label(mercury__vn_table__search_current_locs_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__search_current_locs_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__search_current_locs_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_table__search_current_locs_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module20)
	init_entry(mercury__vn_table__search_current_value_3_0);
	init_label(mercury__vn_table__search_current_value_3_0_i2);
	init_label(mercury__vn_table__search_current_value_3_0_i3);
	init_label(mercury__vn_table__search_current_value_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_table__search_current_value'/3 in mode 0 */
Define_entry(mercury__vn_table__search_current_value_3_0);
	incr_sp_push_msg(2, "vn_table__search_current_value");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__get_loc_to_vn_table_2_0),
		mercury__vn_table__search_current_value_3_0_i2,
		ENTRY(mercury__vn_table__search_current_value_3_0));
	}
Define_label(mercury__vn_table__search_current_value_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__search_current_value_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__search_current_value_3_0_i3,
		ENTRY(mercury__vn_table__search_current_value_3_0));
	}
Define_label(mercury__vn_table__search_current_value_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__search_current_value_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__search_current_value_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_table__search_current_value_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module21)
	init_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
	init_label(mercury__vn_table__get_vnlval_vn_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'vn_table__get_vnlval_vn_list'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
	incr_sp_push_msg(1, "vn_table__get_vnlval_vn_list");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__vn_table__get_lval_to_vn_table_2_0),
		mercury__vn_table__get_vnlval_vn_list_2_0_i2,
		ENTRY(mercury__vn_table__get_vnlval_vn_list_2_0));
	}
Define_label(mercury__vn_table__get_vnlval_vn_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__get_vnlval_vn_list_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		ENTRY(mercury__vn_table__get_vnlval_vn_list_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module22)
	init_entry(mercury__vn_table__add_new_use_4_0);
	init_label(mercury__vn_table__add_new_use_4_0_i4);
	init_label(mercury__vn_table__add_new_use_4_0_i3);
	init_label(mercury__vn_table__add_new_use_4_0_i6);
	init_label(mercury__vn_table__add_new_use_4_0_i7);
	init_label(mercury__vn_table__add_new_use_4_0_i10);
	init_label(mercury__vn_table__add_new_use_4_0_i15);
	init_label(mercury__vn_table__add_new_use_4_0_i17);
	init_label(mercury__vn_table__add_new_use_4_0_i20);
	init_label(mercury__vn_table__add_new_use_4_0_i21);
	init_label(mercury__vn_table__add_new_use_4_0_i22);
	init_label(mercury__vn_table__add_new_use_4_0_i14);
	init_label(mercury__vn_table__add_new_use_4_0_i12);
	init_label(mercury__vn_table__add_new_use_4_0_i24);
	init_label(mercury__vn_table__add_new_use_4_0_i25);
	init_label(mercury__vn_table__add_new_use_4_0_i26);
	init_label(mercury__vn_table__add_new_use_4_0_i27);
	init_label(mercury__vn_table__add_new_use_4_0_i28);
	init_label(mercury__vn_table__add_new_use_4_0_i1019);
	init_label(mercury__vn_table__add_new_use_4_0_i9);
	init_label(mercury__vn_table__add_new_use_4_0_i1036);
	init_label(mercury__vn_table__add_new_use_4_0_i29);
	init_label(mercury__vn_table__add_new_use_4_0_i30);
BEGIN_CODE

/* code for predicate 'vn_table__add_new_use'/4 in mode 0 */
Define_entry(mercury__vn_table__add_new_use_4_0);
	incr_sp_push_msg(14, "vn_table__add_new_use");
	detstackvar(14) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(8) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__add_new_use_4_0_i4,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i3);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i7);
Define_label(mercury__vn_table__add_new_use_4_0_i3);
	r1 = string_const("cannot find old use set in add_new_use", 38);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_table__add_new_use_4_0_i6,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(11);
Define_label(mercury__vn_table__add_new_use_4_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r3;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_table__add_new_use_4_0_i10,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i9);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i15);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i14);
Define_label(mercury__vn_table__add_new_use_4_0_i15);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i12);
	r4 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_table__add_new_use_4_0_i17,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
	}
Define_label(mercury__vn_table__add_new_use_4_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i12);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i12);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i20);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i14);
Define_label(mercury__vn_table__add_new_use_4_0_i20);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i21);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i14);
Define_label(mercury__vn_table__add_new_use_4_0_i21);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i22);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i14);
Define_label(mercury__vn_table__add_new_use_4_0_i22);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 27)))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i12);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
Define_label(mercury__vn_table__add_new_use_4_0_i14);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i1019);
Define_label(mercury__vn_table__add_new_use_4_0_i12);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__opt_debug__dump_tables_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_tables_2_0),
		mercury__vn_table__add_new_use_4_0_i24,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_vn_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__add_new_use_4_0_i25,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_use_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_use_2_0),
		mercury__vn_table__add_new_use_4_0_i26,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("new use for vn ", 15);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(13);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(" = ", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_table__common_3);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__add_new_use_4_0_i27,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
	}
Define_label(mercury__vn_table__add_new_use_4_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_table__add_new_use_4_0_i28,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i29);
Define_label(mercury__vn_table__add_new_use_4_0_i1019);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) r2;
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i1036);
Define_label(mercury__vn_table__add_new_use_4_0_i9);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
Define_label(mercury__vn_table__add_new_use_4_0_i1036);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(11);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
Define_label(mercury__vn_table__add_new_use_4_0_i29);
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__add_new_use_4_0_i30,
		ENTRY(mercury__vn_table__add_new_use_4_0));
	}
Define_label(mercury__vn_table__add_new_use_4_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module23)
	init_entry(mercury__vn_table__del_old_use_4_0);
	init_label(mercury__vn_table__del_old_use_4_0_i4);
	init_label(mercury__vn_table__del_old_use_4_0_i3);
	init_label(mercury__vn_table__del_old_use_4_0_i6);
	init_label(mercury__vn_table__del_old_use_4_0_i7);
	init_label(mercury__vn_table__del_old_use_4_0_i10);
	init_label(mercury__vn_table__del_old_use_4_0_i9);
	init_label(mercury__vn_table__del_old_use_4_0_i12);
	init_label(mercury__vn_table__del_old_use_4_0_i13);
BEGIN_CODE

/* code for predicate 'vn_table__del_old_use'/4 in mode 0 */
Define_entry(mercury__vn_table__del_old_use_4_0);
	incr_sp_push_msg(11, "vn_table__del_old_use");
	detstackvar(11) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(7) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__del_old_use_4_0_i4,
		ENTRY(mercury__vn_table__del_old_use_4_0));
	}
Define_label(mercury__vn_table__del_old_use_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i3);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i7);
Define_label(mercury__vn_table__del_old_use_4_0_i3);
	r1 = string_const("cannot find old use set in add_new_use", 38);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_table__del_old_use_4_0_i6,
		ENTRY(mercury__vn_table__del_old_use_4_0));
	}
Define_label(mercury__vn_table__del_old_use_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(10);
Define_label(mercury__vn_table__del_old_use_4_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_table__del_old_use_4_0_i10,
		ENTRY(mercury__vn_table__del_old_use_4_0));
	}
Define_label(mercury__vn_table__del_old_use_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i9);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(9);
	r5 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i12);
Define_label(mercury__vn_table__del_old_use_4_0_i9);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(10);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
Define_label(mercury__vn_table__del_old_use_4_0_i12);
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	detstackvar(6) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r11;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__del_old_use_4_0_i13,
		ENTRY(mercury__vn_table__del_old_use_4_0));
	}
Define_label(mercury__vn_table__del_old_use_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module24)
	init_entry(mercury__vn_table__del_old_uses_4_0);
	init_label(mercury__vn_table__del_old_uses_4_0_i4);
	init_label(mercury__vn_table__del_old_uses_4_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_table__del_old_uses'/4 in mode 0 */
Define_entry(mercury__vn_table__del_old_uses_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_table__del_old_uses_4_0_i1002);
	incr_sp_push_msg(3, "vn_table__del_old_uses");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__vn_table__del_old_use_4_0),
		mercury__vn_table__del_old_uses_4_0_i4,
		ENTRY(mercury__vn_table__del_old_uses_4_0));
	}
Define_label(mercury__vn_table__del_old_uses_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_uses_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_table__del_old_uses_4_0,
		ENTRY(mercury__vn_table__del_old_uses_4_0));
Define_label(mercury__vn_table__del_old_uses_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module25)
	init_entry(mercury__vn_table__record_first_vnrval_4_0);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i2);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i3);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i4);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i5);
BEGIN_CODE

/* code for predicate 'vn_table__record_first_vnrval'/4 in mode 0 */
Define_entry(mercury__vn_table__record_first_vnrval_4_0);
	r5 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r4 = (Integer) r1;
	incr_sp_push_msg(9, "vn_table__record_first_vnrval");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(8) = ((Integer) r5 + ((Integer) 1));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i2,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnrval_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	r5 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i3,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnrval_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i4,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnrval_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i5,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnrval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module26)
	init_entry(mercury__vn_table__record_first_vnlval_4_0);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i2);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i3);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i4);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i5);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i6);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i7);
BEGIN_CODE

/* code for predicate 'vn_table__record_first_vnlval'/4 in mode 0 */
Define_entry(mercury__vn_table__record_first_vnlval_4_0);
	r5 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r4 = (Integer) r1;
	incr_sp_push_msg(10, "vn_table__record_first_vnlval");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(8) = ((Integer) r5 + ((Integer) 1));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i2,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnlval_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	detstackvar(9) = (Integer) r4;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r5 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i3,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnlval_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i4,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnlval_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i5,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnlval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i6,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnlval_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i7,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
	}
Define_label(mercury__vn_table__record_first_vnlval_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module27)
	init_entry(mercury__vn_table__set_desired_value_4_0);
	init_label(mercury__vn_table__set_desired_value_4_0_i4);
	init_label(mercury__vn_table__set_desired_value_4_0_i6);
	init_label(mercury__vn_table__set_desired_value_4_0_i3);
	init_label(mercury__vn_table__set_desired_value_4_0_i7);
	init_label(mercury__vn_table__set_desired_value_4_0_i8);
BEGIN_CODE

/* code for predicate 'vn_table__set_desired_value'/4 in mode 0 */
Define_entry(mercury__vn_table__set_desired_value_4_0);
	incr_sp_push_msg(11, "vn_table__set_desired_value");
	detstackvar(11) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	detstackvar(10) = (Integer) r3;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__set_desired_value_4_0_i4,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
	}
Define_label(mercury__vn_table__set_desired_value_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__set_desired_value_4_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_desired_value_4_0_i6,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
	}
Define_label(mercury__vn_table__set_desired_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__vn_table__set_desired_value_4_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__vn_table__record_first_vnlval_4_0),
		mercury__vn_table__set_desired_value_4_0_i7,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
	}
Define_label(mercury__vn_table__set_desired_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_desired_value_4_0_i8,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
	}
Define_label(mercury__vn_table__set_desired_value_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module28)
	init_entry(mercury__vn_table__set_current_value_4_0);
	init_label(mercury__vn_table__set_current_value_4_0_i4);
	init_label(mercury__vn_table__set_current_value_4_0_i6);
	init_label(mercury__vn_table__set_current_value_4_0_i7);
	init_label(mercury__vn_table__set_current_value_4_0_i8);
	init_label(mercury__vn_table__set_current_value_4_0_i9);
	init_label(mercury__vn_table__set_current_value_4_0_i10);
	init_label(mercury__vn_table__set_current_value_4_0_i11);
	init_label(mercury__vn_table__set_current_value_4_0_i12);
	init_label(mercury__vn_table__set_current_value_4_0_i3);
	init_label(mercury__vn_table__set_current_value_4_0_i13);
	init_label(mercury__vn_table__set_current_value_4_0_i14);
	init_label(mercury__vn_table__set_current_value_4_0_i15);
	init_label(mercury__vn_table__set_current_value_4_0_i16);
BEGIN_CODE

/* code for predicate 'vn_table__set_current_value'/4 in mode 0 */
Define_entry(mercury__vn_table__set_current_value_4_0);
	incr_sp_push_msg(12, "vn_table__set_current_value");
	detstackvar(12) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	detstackvar(9) = (Integer) r3;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__set_current_value_4_0_i4,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_table__set_current_value_4_0_i3);
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_current_value_4_0_i6,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_table__set_current_value_4_0_i7,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_table__set_current_value_4_0_i8,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_current_value_4_0_i9,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_table__set_current_value_4_0_i10,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_table__set_current_value_4_0_i11,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_current_value_4_0_i12,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__vn_table__set_current_value_4_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_current_value_4_0_i13,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_table__set_current_value_4_0_i14,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_table__set_current_value_4_0_i15,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_current_value_4_0_i16,
		ENTRY(mercury__vn_table__set_current_value_4_0));
	}
Define_label(mercury__vn_table__set_current_value_4_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module29)
	init_entry(mercury__vn_table__set_parallel_value_4_0);
	init_label(mercury__vn_table__set_parallel_value_4_0_i2);
BEGIN_CODE

/* code for predicate 'vn_table__set_parallel_value'/4 in mode 0 */
Define_entry(mercury__vn_table__set_parallel_value_4_0);
	incr_sp_push_msg(3, "vn_table__set_parallel_value");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_table__set_desired_value_4_0),
		mercury__vn_table__set_parallel_value_4_0_i2,
		ENTRY(mercury__vn_table__set_parallel_value_4_0));
	}
Define_label(mercury__vn_table__set_parallel_value_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__set_parallel_value_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__vn_table__set_current_value_4_0),
		ENTRY(mercury__vn_table__set_parallel_value_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module30)
	init_entry(mercury__vn_table__get_all_vnrvals_2_0);
BEGIN_CODE

/* code for predicate 'vn_table__get_all_vnrvals'/2 in mode 0 */
Define_entry(mercury__vn_table__get_all_vnrvals_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__keys_2_0);
	tailcall(ENTRY(mercury__map__keys_2_0),
		ENTRY(mercury__vn_table__get_all_vnrvals_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module31)
	init_entry(mercury____Unify___vn_table__vn_tables_0_0);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i2);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i4);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i6);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i8);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i10);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i1007);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_tables_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1007);
	incr_sp_push_msg(11, "__Unify__");
	detstackvar(11) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i2,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i4,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i6,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i8,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i10,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i1007);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_table_module32)
	init_entry(mercury____Index___vn_table__vn_tables_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_tables_0_0);
	tailcall(STATIC(mercury____Index___vn_table_vn_tables_0__ua10000_2_0),
		ENTRY(mercury____Index___vn_table__vn_tables_0_0));
END_MODULE

BEGIN_MODULE(mercury__vn_table_module33)
	init_entry(mercury____Compare___vn_table__vn_tables_0_0);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i4);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i5);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i3);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i10);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i16);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i22);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i28);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i34);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_tables_0_0);
	incr_sp_push_msg(13, "__Compare__");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_table__vn_tables_0_0_i4,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i3);
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i10,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i5);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i16,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i22,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i28,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i34,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i5);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module34)
	init_entry(mercury____Unify___vn_table__lval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__lval_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__lval_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module35)
	init_entry(mercury____Index___vn_table__lval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__lval_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__lval_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module36)
	init_entry(mercury____Compare___vn_table__lval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__lval_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__lval_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module37)
	init_entry(mercury____Unify___vn_table__rval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__rval_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__rval_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module38)
	init_entry(mercury____Index___vn_table__rval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__rval_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__rval_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module39)
	init_entry(mercury____Compare___vn_table__rval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__rval_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__rval_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module40)
	init_entry(mercury____Unify___vn_table__vn_to_rval_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_to_rval_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_to_rval_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module41)
	init_entry(mercury____Index___vn_table__vn_to_rval_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_to_rval_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__vn_to_rval_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module42)
	init_entry(mercury____Compare___vn_table__vn_to_rval_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_to_rval_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_to_rval_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module43)
	init_entry(mercury____Unify___vn_table__vn_to_uses_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_to_uses_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_to_uses_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module44)
	init_entry(mercury____Index___vn_table__vn_to_uses_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_to_uses_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__vn_to_uses_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module45)
	init_entry(mercury____Compare___vn_table__vn_to_uses_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_to_uses_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_0);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_to_uses_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module46)
	init_entry(mercury____Unify___vn_table__vn_to_locs_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_to_locs_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_to_locs_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module47)
	init_entry(mercury____Index___vn_table__vn_to_locs_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_to_locs_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__vn_to_locs_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module48)
	init_entry(mercury____Compare___vn_table__vn_to_locs_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_to_locs_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_table__common_1);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_to_locs_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module49)
	init_entry(mercury____Unify___vn_table__loc_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__loc_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__loc_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module50)
	init_entry(mercury____Index___vn_table__loc_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__loc_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__loc_to_vn_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_table_module51)
	init_entry(mercury____Compare___vn_table__loc_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__loc_to_vn_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__loc_to_vn_table_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_table_bunch_0(void)
{
	mercury__vn_table_module0();
	mercury__vn_table_module1();
	mercury__vn_table_module2();
	mercury__vn_table_module3();
	mercury__vn_table_module4();
	mercury__vn_table_module5();
	mercury__vn_table_module6();
	mercury__vn_table_module7();
	mercury__vn_table_module8();
	mercury__vn_table_module9();
	mercury__vn_table_module10();
	mercury__vn_table_module11();
	mercury__vn_table_module12();
	mercury__vn_table_module13();
	mercury__vn_table_module14();
	mercury__vn_table_module15();
	mercury__vn_table_module16();
	mercury__vn_table_module17();
	mercury__vn_table_module18();
	mercury__vn_table_module19();
	mercury__vn_table_module20();
	mercury__vn_table_module21();
	mercury__vn_table_module22();
	mercury__vn_table_module23();
	mercury__vn_table_module24();
	mercury__vn_table_module25();
	mercury__vn_table_module26();
	mercury__vn_table_module27();
	mercury__vn_table_module28();
	mercury__vn_table_module29();
	mercury__vn_table_module30();
	mercury__vn_table_module31();
	mercury__vn_table_module32();
	mercury__vn_table_module33();
	mercury__vn_table_module34();
	mercury__vn_table_module35();
	mercury__vn_table_module36();
	mercury__vn_table_module37();
	mercury__vn_table_module38();
	mercury__vn_table_module39();
	mercury__vn_table_module40();
}

static void mercury__vn_table_bunch_1(void)
{
	mercury__vn_table_module41();
	mercury__vn_table_module42();
	mercury__vn_table_module43();
	mercury__vn_table_module44();
	mercury__vn_table_module45();
	mercury__vn_table_module46();
	mercury__vn_table_module47();
	mercury__vn_table_module48();
	mercury__vn_table_module49();
	mercury__vn_table_module50();
	mercury__vn_table_module51();
}

#endif

void mercury__vn_table__init(void); /* suppress gcc warning */
void mercury__vn_table__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_table_bunch_0();
	mercury__vn_table_bunch_1();
#endif
}
