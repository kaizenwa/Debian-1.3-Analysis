/*
** Automatically generated from `hlds_data.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__hlds_data__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___hlds_data_hlds__mode_body_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_hlds__mode_defn_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_mode_table_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_hlds__inst_defn_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_unify_inst_pair_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_user_inst_table_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_inst_table_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_hlds__type_defn_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_data_hlds__cons_defn_0__ua10000_2_0);
Declare_static(mercury__hlds_data__make_cons_id__ua10000_4_0);
Declare_label(mercury__hlds_data__make_cons_id__ua10000_4_0_i2);
Define_extern_entry(mercury__hlds_data__cons_id_to_const_3_0);
Declare_label(mercury__hlds_data__cons_id_to_const_3_0_i4);
Declare_label(mercury__hlds_data__cons_id_to_const_3_0_i6);
Declare_label(mercury__hlds_data__cons_id_to_const_3_0_i8);
Declare_label(mercury__hlds_data__cons_id_to_const_3_0_i1);
Define_extern_entry(mercury__hlds_data__make_functor_cons_id_3_0);
Declare_label(mercury__hlds_data__make_functor_cons_id_3_0_i4);
Declare_label(mercury__hlds_data__make_functor_cons_id_3_0_i5);
Declare_label(mercury__hlds_data__make_functor_cons_id_3_0_i6);
Define_extern_entry(mercury__hlds_data__make_cons_id_4_0);
Define_extern_entry(mercury__hlds_data__set_type_defn_6_0);
Define_extern_entry(mercury__hlds_data__get_type_defn_tvarset_2_0);
Define_extern_entry(mercury__hlds_data__get_type_defn_tparams_2_0);
Define_extern_entry(mercury__hlds_data__get_type_defn_body_2_0);
Define_extern_entry(mercury__hlds_data__get_type_defn_status_2_0);
Define_extern_entry(mercury__hlds_data__get_type_defn_context_2_0);
Define_extern_entry(mercury__hlds_data__set_type_defn_status_3_0);
Define_extern_entry(mercury__hlds_data__inst_table_init_1_0);
Declare_label(mercury__hlds_data__inst_table_init_1_0_i2);
Declare_label(mercury__hlds_data__inst_table_init_1_0_i3);
Declare_label(mercury__hlds_data__inst_table_init_1_0_i4);
Declare_label(mercury__hlds_data__inst_table_init_1_0_i5);
Declare_label(mercury__hlds_data__inst_table_init_1_0_i6);
Declare_label(mercury__hlds_data__inst_table_init_1_0_i7);
Define_extern_entry(mercury__hlds_data__inst_table_get_user_insts_2_0);
Define_extern_entry(mercury__hlds_data__inst_table_get_unify_insts_2_0);
Define_extern_entry(mercury__hlds_data__inst_table_get_merge_insts_2_0);
Define_extern_entry(mercury__hlds_data__inst_table_get_ground_insts_2_0);
Define_extern_entry(mercury__hlds_data__inst_table_get_shared_insts_2_0);
Define_extern_entry(mercury__hlds_data__inst_table_get_mostly_uniq_insts_2_0);
Define_extern_entry(mercury__hlds_data__inst_table_set_user_insts_3_0);
Define_extern_entry(mercury__hlds_data__inst_table_set_unify_insts_3_0);
Define_extern_entry(mercury__hlds_data__inst_table_set_merge_insts_3_0);
Define_extern_entry(mercury__hlds_data__inst_table_set_ground_insts_3_0);
Define_extern_entry(mercury__hlds_data__inst_table_set_shared_insts_3_0);
Define_extern_entry(mercury__hlds_data__inst_table_set_mostly_uniq_insts_3_0);
Define_extern_entry(mercury__hlds_data__user_inst_table_get_inst_defns_2_0);
Define_extern_entry(mercury__hlds_data__user_inst_table_get_inst_ids_2_0);
Define_extern_entry(mercury__hlds_data__user_inst_table_insert_4_0);
Declare_label(mercury__hlds_data__user_inst_table_insert_4_0_i2);
Declare_label(mercury__hlds_data__user_inst_table_insert_4_0_i1);
Define_extern_entry(mercury__hlds_data__user_inst_table_optimize_2_0);
Declare_label(mercury__hlds_data__user_inst_table_optimize_2_0_i2);
Declare_label(mercury__hlds_data__user_inst_table_optimize_2_0_i3);
Define_extern_entry(mercury__hlds_data__mode_table_get_mode_defns_2_0);
Define_extern_entry(mercury__hlds_data__mode_table_get_mode_ids_2_0);
Define_extern_entry(mercury__hlds_data__mode_table_insert_4_0);
Declare_label(mercury__hlds_data__mode_table_insert_4_0_i2);
Declare_label(mercury__hlds_data__mode_table_insert_4_0_i1);
Define_extern_entry(mercury__hlds_data__mode_table_init_1_0);
Declare_label(mercury__hlds_data__mode_table_init_1_0_i2);
Define_extern_entry(mercury__hlds_data__mode_table_optimize_2_0);
Declare_label(mercury__hlds_data__mode_table_optimize_2_0_i2);
Declare_label(mercury__hlds_data__mode_table_optimize_2_0_i3);
Define_extern_entry(mercury__hlds_data__determinism_components_3_0);
Define_extern_entry(mercury__hlds_data__determinism_components_3_1);
Declare_label(mercury__hlds_data__determinism_components_3_1_i3);
Define_extern_entry(mercury__hlds_data__determinism_to_code_model_2_0);
Define_extern_entry(mercury____Unify___hlds_data__cons_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__cons_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__cons_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i1036);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i7);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i9);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i1035);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i14);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i12);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i16);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i1032);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i1);
Declare_label(mercury____Unify___hlds_data__cons_id_0_0_i1034);
Define_extern_entry(mercury____Index___hlds_data__cons_id_0_0);
Declare_label(mercury____Index___hlds_data__cons_id_0_0_i5);
Declare_label(mercury____Index___hlds_data__cons_id_0_0_i6);
Declare_label(mercury____Index___hlds_data__cons_id_0_0_i7);
Declare_label(mercury____Index___hlds_data__cons_id_0_0_i4);
Declare_label(mercury____Index___hlds_data__cons_id_0_0_i8);
Declare_label(mercury____Index___hlds_data__cons_id_0_0_i9);
Define_extern_entry(mercury____Compare___hlds_data__cons_id_0_0);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i2);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i3);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i4);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i6);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i13);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i20);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i21);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i19);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i16);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i30);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i26);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i39);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i45);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i12);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i56);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i52);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i62);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i9);
Declare_label(mercury____Compare___hlds_data__cons_id_0_0_i1001);
Define_extern_entry(mercury____Unify___hlds_data__hlds__cons_defn_0_0);
Declare_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i2);
Declare_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i4);
Declare_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__hlds__cons_defn_0_0);
Define_extern_entry(mercury____Compare___hlds_data__hlds__cons_defn_0_0);
Declare_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i4);
Declare_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i5);
Declare_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i3);
Declare_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i10);
Define_extern_entry(mercury____Unify___hlds_data__type_id_0_0);
Define_extern_entry(mercury____Index___hlds_data__type_id_0_0);
Define_extern_entry(mercury____Compare___hlds_data__type_id_0_0);
Define_extern_entry(mercury____Unify___hlds_data__type_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__type_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__type_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__hlds__type_defn_0_0);
Declare_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i2);
Declare_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i4);
Declare_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i6);
Declare_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__hlds__type_defn_0_0);
Define_extern_entry(mercury____Compare___hlds_data__hlds__type_defn_0_0);
Declare_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i4);
Declare_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i5);
Declare_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i3);
Declare_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i10);
Declare_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i16);
Declare_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i22);
Define_extern_entry(mercury____Unify___hlds_data__hlds__type_body_0_0);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1015);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i8);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i10);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i6);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i12);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1012);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
Declare_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1014);
Define_extern_entry(mercury____Index___hlds_data__hlds__type_body_0_0);
Declare_label(mercury____Index___hlds_data__hlds__type_body_0_0_i4);
Declare_label(mercury____Index___hlds_data__hlds__type_body_0_0_i5);
Declare_label(mercury____Index___hlds_data__hlds__type_body_0_0_i6);
Define_extern_entry(mercury____Compare___hlds_data__hlds__type_body_0_0);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i2);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i3);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i4);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i6);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i12);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i18);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i19);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i17);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i24);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i14);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i31);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i9);
Declare_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i1001);
Define_extern_entry(mercury____Unify___hlds_data__cons_tag_values_0_0);
Define_extern_entry(mercury____Index___hlds_data__cons_tag_values_0_0);
Define_extern_entry(mercury____Compare___hlds_data__cons_tag_values_0_0);
Define_extern_entry(mercury____Unify___hlds_data__cons_tag_0_0);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i5);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i7);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i9);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i11);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i13);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i15);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i17);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i4);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i19);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i21);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i2);
Declare_label(mercury____Unify___hlds_data__cons_tag_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__cons_tag_0_0);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i5);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i6);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i7);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i8);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i9);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i10);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i11);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i4);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i12);
Declare_label(mercury____Index___hlds_data__cons_tag_0_0_i13);
Define_extern_entry(mercury____Compare___hlds_data__cons_tag_0_0);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i2);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i3);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i4);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i6);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i13);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i16);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i20);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i21);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i19);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i26);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i30);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i36);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i40);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i46);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i53);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i56);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i60);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i66);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i70);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i12);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i76);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i78);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i9);
Declare_label(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
Define_extern_entry(mercury____Unify___hlds_data__tag_bits_0_0);
Declare_label(mercury____Unify___hlds_data__tag_bits_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__tag_bits_0_0);
Define_extern_entry(mercury____Compare___hlds_data__tag_bits_0_0);
Define_extern_entry(mercury____Unify___hlds_data__inst_id_0_0);
Define_extern_entry(mercury____Index___hlds_data__inst_id_0_0);
Define_extern_entry(mercury____Compare___hlds_data__inst_id_0_0);
Define_extern_entry(mercury____Unify___hlds_data__inst_table_0_0);
Declare_label(mercury____Unify___hlds_data__inst_table_0_0_i2);
Declare_label(mercury____Unify___hlds_data__inst_table_0_0_i4);
Declare_label(mercury____Unify___hlds_data__inst_table_0_0_i6);
Declare_label(mercury____Unify___hlds_data__inst_table_0_0_i8);
Declare_label(mercury____Unify___hlds_data__inst_table_0_0_i10);
Declare_label(mercury____Unify___hlds_data__inst_table_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__inst_table_0_0);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i4);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i5);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i3);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i10);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i16);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i22);
Declare_label(mercury____Compare___hlds_data__inst_table_0_0_i28);
Define_extern_entry(mercury____Unify___hlds_data__user_inst_table_0_0);
Declare_label(mercury____Unify___hlds_data__user_inst_table_0_0_i2);
Declare_label(mercury____Unify___hlds_data__user_inst_table_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__user_inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__user_inst_table_0_0);
Declare_label(mercury____Compare___hlds_data__user_inst_table_0_0_i4);
Declare_label(mercury____Compare___hlds_data__user_inst_table_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_data__user_inst_defns_0_0);
Define_extern_entry(mercury____Index___hlds_data__user_inst_defns_0_0);
Define_extern_entry(mercury____Compare___hlds_data__user_inst_defns_0_0);
Define_extern_entry(mercury____Unify___hlds_data__unify_inst_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__unify_inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__unify_inst_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__unify_inst_pair_0_0);
Declare_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i2);
Declare_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i4);
Declare_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1005);
Declare_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__unify_inst_pair_0_0);
Define_extern_entry(mercury____Compare___hlds_data__unify_inst_pair_0_0);
Declare_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i4);
Declare_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i5);
Declare_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i3);
Declare_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i10);
Declare_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i16);
Define_extern_entry(mercury____Unify___hlds_data__merge_inst_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__merge_inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__merge_inst_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__ground_inst_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__ground_inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__ground_inst_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__shared_inst_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__shared_inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__shared_inst_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__mostly_uniq_inst_table_0_0);
Define_extern_entry(mercury____Index___hlds_data__mostly_uniq_inst_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__mostly_uniq_inst_table_0_0);
Define_extern_entry(mercury____Unify___hlds_data__maybe_inst_0_0);
Declare_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1008);
Declare_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1005);
Declare_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1007);
Define_extern_entry(mercury____Index___hlds_data__maybe_inst_0_0);
Declare_label(mercury____Index___hlds_data__maybe_inst_0_0_i3);
Define_extern_entry(mercury____Compare___hlds_data__maybe_inst_0_0);
Declare_label(mercury____Compare___hlds_data__maybe_inst_0_0_i2);
Declare_label(mercury____Compare___hlds_data__maybe_inst_0_0_i3);
Declare_label(mercury____Compare___hlds_data__maybe_inst_0_0_i4);
Declare_label(mercury____Compare___hlds_data__maybe_inst_0_0_i6);
Declare_label(mercury____Compare___hlds_data__maybe_inst_0_0_i11);
Declare_label(mercury____Compare___hlds_data__maybe_inst_0_0_i9);
Define_extern_entry(mercury____Unify___hlds_data__maybe_inst_det_0_0);
Declare_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1009);
Declare_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i6);
Declare_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1006);
Declare_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__maybe_inst_det_0_0);
Declare_label(mercury____Index___hlds_data__maybe_inst_det_0_0_i3);
Define_extern_entry(mercury____Compare___hlds_data__maybe_inst_det_0_0);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i2);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i3);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i4);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i6);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i11);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i16);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i15);
Declare_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i9);
Define_extern_entry(mercury____Unify___hlds_data__hlds__inst_defn_0_0);
Declare_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i2);
Declare_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i4);
Declare_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i6);
Declare_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i8);
Declare_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i10);
Declare_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__hlds__inst_defn_0_0);
Define_extern_entry(mercury____Compare___hlds_data__hlds__inst_defn_0_0);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i4);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i3);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i10);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i16);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i22);
Declare_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i28);
Define_extern_entry(mercury____Unify___hlds_data__hlds__inst_body_0_0);
Declare_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1008);
Declare_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1005);
Declare_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1007);
Define_extern_entry(mercury____Index___hlds_data__hlds__inst_body_0_0);
Declare_label(mercury____Index___hlds_data__hlds__inst_body_0_0_i3);
Define_extern_entry(mercury____Compare___hlds_data__hlds__inst_body_0_0);
Declare_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i2);
Declare_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i3);
Declare_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i4);
Declare_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i6);
Declare_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i11);
Declare_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i9);
Define_extern_entry(mercury____Unify___hlds_data__mode_id_0_0);
Define_extern_entry(mercury____Index___hlds_data__mode_id_0_0);
Define_extern_entry(mercury____Compare___hlds_data__mode_id_0_0);
Define_extern_entry(mercury____Unify___hlds_data__mode_table_0_0);
Declare_label(mercury____Unify___hlds_data__mode_table_0_0_i2);
Declare_label(mercury____Unify___hlds_data__mode_table_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__mode_table_0_0);
Define_extern_entry(mercury____Compare___hlds_data__mode_table_0_0);
Declare_label(mercury____Compare___hlds_data__mode_table_0_0_i4);
Declare_label(mercury____Compare___hlds_data__mode_table_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_data__mode_defns_0_0);
Define_extern_entry(mercury____Index___hlds_data__mode_defns_0_0);
Define_extern_entry(mercury____Compare___hlds_data__mode_defns_0_0);
Define_extern_entry(mercury____Unify___hlds_data__hlds__mode_defn_0_0);
Declare_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i2);
Declare_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i4);
Declare_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i6);
Declare_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i8);
Declare_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i10);
Declare_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__hlds__mode_defn_0_0);
Define_extern_entry(mercury____Compare___hlds_data__hlds__mode_defn_0_0);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i4);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i3);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i10);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i16);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i22);
Declare_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i28);
Define_extern_entry(mercury____Unify___hlds_data__hlds__mode_body_0_0);
Define_extern_entry(mercury____Index___hlds_data__hlds__mode_body_0_0);
Define_extern_entry(mercury____Compare___hlds_data__hlds__mode_body_0_0);
Define_extern_entry(mercury____Unify___hlds_data__determinism_0_0);
Declare_label(mercury____Unify___hlds_data__determinism_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__determinism_0_0);
Define_extern_entry(mercury____Compare___hlds_data__determinism_0_0);
Define_extern_entry(mercury____Unify___hlds_data__can_fail_0_0);
Declare_label(mercury____Unify___hlds_data__can_fail_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__can_fail_0_0);
Define_extern_entry(mercury____Compare___hlds_data__can_fail_0_0);
Define_extern_entry(mercury____Unify___hlds_data__soln_count_0_0);
Declare_label(mercury____Unify___hlds_data__soln_count_0_0_i1);
Define_extern_entry(mercury____Index___hlds_data__soln_count_0_0);
Define_extern_entry(mercury____Compare___hlds_data__soln_count_0_0);

extern Word * mercury_data_hlds_data__base_type_layout_can_fail_0[];
Word * mercury_data_hlds_data__base_type_info_can_fail_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__can_fail_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__can_fail_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__can_fail_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_can_fail_0
};

extern Word * mercury_data_hlds_data__base_type_layout_cons_id_0[];
Word * mercury_data_hlds_data__base_type_info_cons_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__cons_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_cons_id_0
};

extern Word * mercury_data_hlds_data__base_type_layout_cons_table_0[];
Word * mercury_data_hlds_data__base_type_info_cons_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__cons_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__cons_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__cons_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_cons_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_cons_tag_0[];
Word * mercury_data_hlds_data__base_type_info_cons_tag_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__cons_tag_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__cons_tag_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__cons_tag_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_cons_tag_0
};

extern Word * mercury_data_hlds_data__base_type_layout_cons_tag_values_0[];
Word * mercury_data_hlds_data__base_type_info_cons_tag_values_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__cons_tag_values_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__cons_tag_values_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__cons_tag_values_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_cons_tag_values_0
};

extern Word * mercury_data_hlds_data__base_type_layout_determinism_0[];
Word * mercury_data_hlds_data__base_type_info_determinism_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__determinism_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__determinism_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__determinism_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_determinism_0
};

extern Word * mercury_data_hlds_data__base_type_layout_ground_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_ground_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__ground_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__ground_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__ground_inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_ground_inst_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__cons_defn_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__cons_defn_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__cons_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__cons_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__cons_defn_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__cons_defn_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__inst_body_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__inst_body_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__inst_body_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__inst_body_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__inst_body_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__inst_body_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__inst_defn_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__inst_defn_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__inst_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__inst_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__inst_defn_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__mode_body_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__mode_body_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__mode_body_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__mode_body_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__mode_body_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__mode_body_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__mode_defn_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__mode_defn_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__mode_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__mode_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__mode_defn_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__type_body_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__type_body_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__type_body_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__type_body_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__type_body_0
};

extern Word * mercury_data_hlds_data__base_type_layout_hlds__type_defn_0[];
Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__hlds__type_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__hlds__type_defn_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__hlds__type_defn_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_hlds__type_defn_0
};

extern Word * mercury_data_hlds_data__base_type_layout_inst_id_0[];
Word * mercury_data_hlds_data__base_type_info_inst_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__inst_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__inst_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__inst_id_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_inst_id_0
};

extern Word * mercury_data_hlds_data__base_type_layout_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_inst_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_maybe_inst_0[];
Word * mercury_data_hlds_data__base_type_info_maybe_inst_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__maybe_inst_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__maybe_inst_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__maybe_inst_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_maybe_inst_0
};

extern Word * mercury_data_hlds_data__base_type_layout_maybe_inst_det_0[];
Word * mercury_data_hlds_data__base_type_info_maybe_inst_det_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__maybe_inst_det_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__maybe_inst_det_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__maybe_inst_det_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_maybe_inst_det_0
};

extern Word * mercury_data_hlds_data__base_type_layout_merge_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_merge_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__merge_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__merge_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__merge_inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_merge_inst_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_mode_defns_0[];
Word * mercury_data_hlds_data__base_type_info_mode_defns_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__mode_defns_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__mode_defns_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__mode_defns_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_mode_defns_0
};

extern Word * mercury_data_hlds_data__base_type_layout_mode_id_0[];
Word * mercury_data_hlds_data__base_type_info_mode_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__mode_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__mode_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__mode_id_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_mode_id_0
};

extern Word * mercury_data_hlds_data__base_type_layout_mode_table_0[];
Word * mercury_data_hlds_data__base_type_info_mode_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__mode_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__mode_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__mode_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_mode_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_mostly_uniq_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_mostly_uniq_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__mostly_uniq_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__mostly_uniq_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__mostly_uniq_inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_mostly_uniq_inst_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_shared_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_shared_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__shared_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__shared_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__shared_inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_shared_inst_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_soln_count_0[];
Word * mercury_data_hlds_data__base_type_info_soln_count_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__soln_count_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__soln_count_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__soln_count_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_soln_count_0
};

extern Word * mercury_data_hlds_data__base_type_layout_tag_bits_0[];
Word * mercury_data_hlds_data__base_type_info_tag_bits_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__tag_bits_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__tag_bits_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__tag_bits_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_tag_bits_0
};

extern Word * mercury_data_hlds_data__base_type_layout_type_id_0[];
Word * mercury_data_hlds_data__base_type_info_type_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__type_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__type_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__type_id_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_type_id_0
};

extern Word * mercury_data_hlds_data__base_type_layout_type_table_0[];
Word * mercury_data_hlds_data__base_type_info_type_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__type_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__type_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__type_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_type_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_unify_inst_pair_0[];
Word * mercury_data_hlds_data__base_type_info_unify_inst_pair_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__unify_inst_pair_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__unify_inst_pair_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__unify_inst_pair_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_unify_inst_pair_0
};

extern Word * mercury_data_hlds_data__base_type_layout_unify_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_unify_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__unify_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__unify_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__unify_inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_unify_inst_table_0
};

extern Word * mercury_data_hlds_data__base_type_layout_user_inst_defns_0[];
Word * mercury_data_hlds_data__base_type_info_user_inst_defns_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__user_inst_defns_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__user_inst_defns_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__user_inst_defns_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_user_inst_defns_0
};

extern Word * mercury_data_hlds_data__base_type_layout_user_inst_table_0[];
Word * mercury_data_hlds_data__base_type_info_user_inst_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_data__user_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_data__user_inst_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_data__user_inst_table_0_0),
	(Word *) (Integer) mercury_data_hlds_data__base_type_layout_user_inst_table_0
};

extern Word * mercury_data_hlds_data__common_8[];
Word * mercury_data_hlds_data__base_type_layout_user_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_8),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_9[];
Word * mercury_data_hlds_data__base_type_layout_user_inst_defns_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_9)
};

extern Word * mercury_data_hlds_data__common_11[];
Word * mercury_data_hlds_data__base_type_layout_unify_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_11),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_11),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_11),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_11)
};

extern Word * mercury_data_hlds_data__common_15[];
Word * mercury_data_hlds_data__base_type_layout_unify_inst_pair_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_15),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_17[];
Word * mercury_data_hlds_data__base_type_layout_type_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_17),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_17),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_17),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_17)
};

extern Word * mercury_data_hlds_data__common_18[];
Word * mercury_data_hlds_data__base_type_layout_type_id_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18)
};

extern Word * mercury_data_hlds_data__common_20[];
Word * mercury_data_hlds_data__base_type_layout_tag_bits_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_20),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_20),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_20),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_20)
};

extern Word * mercury_data_hlds_data__common_21[];
Word * mercury_data_hlds_data__base_type_layout_soln_count_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_21),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_21),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_21),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_21)
};

extern Word * mercury_data_hlds_data__common_23[];
Word * mercury_data_hlds_data__base_type_layout_shared_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23)
};

Word * mercury_data_hlds_data__base_type_layout_mostly_uniq_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23)
};

extern Word * mercury_data_hlds_data__common_25[];
Word * mercury_data_hlds_data__base_type_layout_mode_table_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_25),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_hlds_data__base_type_layout_mode_id_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18)
};

extern Word * mercury_data_hlds_data__common_26[];
Word * mercury_data_hlds_data__base_type_layout_mode_defns_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_26),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_26),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_26),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_26)
};

extern Word * mercury_data_hlds_data__common_28[];
Word * mercury_data_hlds_data__base_type_layout_merge_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_28),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_28),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_28),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_28)
};

extern Word * mercury_data_hlds_data__common_29[];
extern Word * mercury_data_hlds_data__common_31[];
Word * mercury_data_hlds_data__base_type_layout_maybe_inst_det_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_29),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_31),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_32[];
Word * mercury_data_hlds_data__base_type_layout_maybe_inst_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_29),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_32),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_34[];
Word * mercury_data_hlds_data__base_type_layout_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_34),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_hlds_data__base_type_layout_inst_id_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_18)
};

extern Word * mercury_data_hlds_data__common_40[];
Word * mercury_data_hlds_data__base_type_layout_hlds__type_defn_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_40),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_41[];
extern Word * mercury_data_hlds_data__common_45[];
extern Word * mercury_data_hlds_data__common_46[];
extern Word * mercury_data_hlds_data__common_48[];
Word * mercury_data_hlds_data__base_type_layout_hlds__type_body_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_41),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_45),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_46),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_48)
};

extern Word * mercury_data_hlds_data__common_51[];
Word * mercury_data_hlds_data__base_type_layout_hlds__mode_defn_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_51),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_53[];
Word * mercury_data_hlds_data__base_type_layout_hlds__mode_body_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_53),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_53),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_53),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_53)
};

extern Word * mercury_data_hlds_data__common_55[];
Word * mercury_data_hlds_data__base_type_layout_hlds__inst_defn_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_55),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_56[];
extern Word * mercury_data_hlds_data__common_57[];
Word * mercury_data_hlds_data__base_type_layout_hlds__inst_body_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_56),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_57),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_data__common_58[];
Word * mercury_data_hlds_data__base_type_layout_hlds__cons_defn_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_58),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_hlds_data__base_type_layout_ground_inst_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_23)
};

extern Word * mercury_data_hlds_data__common_59[];
Word * mercury_data_hlds_data__base_type_layout_determinism_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_59),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_59),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_59),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_59)
};

extern Word * mercury_data_hlds_data__common_60[];
Word * mercury_data_hlds_data__base_type_layout_cons_tag_values_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_60),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_60),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_60),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_60)
};

extern Word * mercury_data_hlds_data__common_61[];
extern Word * mercury_data_hlds_data__common_63[];
extern Word * mercury_data_hlds_data__common_65[];
extern Word * mercury_data_hlds_data__common_73[];
Word * mercury_data_hlds_data__base_type_layout_cons_tag_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_61),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_63),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_65),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_hlds_data__common_73)
};

extern Word * mercury_data_hlds_data__common_75[];
Word * mercury_data_hlds_data__base_type_layout_cons_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_75),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_75),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_75),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_data__common_75)
};

extern Word * mercury_data_hlds_data__common_77[];
extern Word * mercury_data_hlds_data__common_78[];
extern Word * mercury_data_hlds_data__common_79[];
extern Word * mercury_data_hlds_data__common_84[];
Word * mercury_data_hlds_data__base_type_layout_cons_id_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_77),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_78),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_79),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_hlds_data__common_84)
};

extern Word * mercury_data_hlds_data__common_85[];
Word * mercury_data_hlds_data__base_type_layout_can_fail_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_85),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_85),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_85),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_85)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data___base_type_info_string_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_hlds_data__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_hlds_data__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_prog_data__base_type_info_inst_0[];
Word * mercury_data_hlds_data__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_hlds_data__common_3[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__cons_defn_0
};

Word * mercury_data_hlds_data__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_0)
};

Word * mercury_data_hlds_data__common_5[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_4)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_hlds_data__common_6[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1),
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0
};

Word * mercury_data_hlds_data__common_7[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1)
};

Word * mercury_data_hlds_data__common_8[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_7),
	(Word *) string_const("user_inst_table", 15)
};

Word * mercury_data_hlds_data__common_9[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_6)
};

extern Word * mercury_data_prog_data__base_type_info_inst_name_0[];
Word * mercury_data_hlds_data__common_10[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_name_0,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0
};

Word * mercury_data_hlds_data__common_11[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_10)
};

extern Word * mercury_data_prog_data__base_type_info_is_live_0[];
Word * mercury_data_hlds_data__common_12[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_is_live_0
};

Word * mercury_data_hlds_data__common_13[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0
};

extern Word * mercury_data_prog_data__base_type_info_unify_is_real_0[];
Word * mercury_data_hlds_data__common_14[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_unify_is_real_0
};

Word * mercury_data_hlds_data__common_15[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_14),
	(Word *) string_const("unify_inst_pair", 15)
};

Word * mercury_data_hlds_data__common_16[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1),
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0
};

Word * mercury_data_hlds_data__common_17[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_16)
};

Word * mercury_data_hlds_data__common_18[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1)
};

Word * mercury_data_hlds_data__common_19[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_hlds_data__common_20[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19)
};

Word * mercury_data_hlds_data__common_21[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 4),
	(Word *) string_const("at_most_zero", 12),
	(Word *) string_const("at_most_one", 11),
	(Word *) string_const("at_most_many_cc", 15),
	(Word *) string_const("at_most_many", 12)
};

Word * mercury_data_hlds_data__common_22[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_name_0,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0
};

Word * mercury_data_hlds_data__common_23[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_22)
};

Word * mercury_data_hlds_data__common_24[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1),
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0
};

Word * mercury_data_hlds_data__common_25[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_24),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_7),
	(Word *) string_const("mode_table", 10)
};

Word * mercury_data_hlds_data__common_26[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_24)
};

Word * mercury_data_hlds_data__common_27[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2),
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0
};

Word * mercury_data_hlds_data__common_28[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_27)
};

Word * mercury_data_hlds_data__common_29[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("unknown", 7)
};

Word * mercury_data_hlds_data__common_30[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_determinism_0
};

Word * mercury_data_hlds_data__common_31[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_30),
	(Word *) string_const("known", 5)
};

Word * mercury_data_hlds_data__common_32[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_13),
	(Word *) string_const("known", 5)
};

Word * mercury_data_hlds_data__common_33[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_user_inst_table_0
};

Word * mercury_data_hlds_data__common_34[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_33),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_27),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_22),
	(Word *) string_const("inst_table", 10)
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_hlds_data__common_35[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

Word * mercury_data_hlds_data__common_36[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_hlds_data__common_37[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__type_body_0
};

extern Word * mercury_data_hlds_pred__base_type_info_import_status_0[];
Word * mercury_data_hlds_data__common_38[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_import_status_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_hlds_data__common_39[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

Word * mercury_data_hlds_data__common_40[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_35),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_36),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_37),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_39),
	(Word *) string_const("hlds__type_defn", 15)
};

Word * mercury_data_hlds_data__common_41[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("abstract_type", 13)
};

Word * mercury_data_hlds_data__common_42[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_5)
};

Word * mercury_data_hlds_data__common_43[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_hlds_data__common_44[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_hlds_data__common_45[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_42),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_43),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_44),
	(Word *) string_const("du_type", 7)
};

Word * mercury_data_hlds_data__common_46[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_36),
	(Word *) string_const("uu_type", 7)
};

Word * mercury_data_hlds_data__common_47[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_hlds_data__common_48[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_47),
	(Word *) string_const("eqv_type", 8)
};

Word * mercury_data_hlds_data__common_49[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_body_0
};

extern Word * mercury_data_prog_data__base_type_info_condition_0[];
Word * mercury_data_hlds_data__common_50[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_condition_0
};

Word * mercury_data_hlds_data__common_51[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_35),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_36),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_49),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_50),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_39),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_38),
	(Word *) string_const("hlds__mode_defn", 15)
};

extern Word * mercury_data_prog_data__base_type_info_mode_0[];
Word * mercury_data_hlds_data__common_52[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_mode_0
};

Word * mercury_data_hlds_data__common_53[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_52),
	(Word *) string_const("eqv_mode", 8)
};

Word * mercury_data_hlds_data__common_54[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_body_0
};

Word * mercury_data_hlds_data__common_55[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_35),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_36),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_54),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_50),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_39),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_38),
	(Word *) string_const("hlds__inst_defn", 15)
};

Word * mercury_data_hlds_data__common_56[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("abstract_inst", 13)
};

Word * mercury_data_hlds_data__common_57[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_13),
	(Word *) string_const("eqv_inst", 8)
};

Word * mercury_data_hlds_data__common_58[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_36),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_39),
	(Word *) string_const("hlds__cons_defn", 15)
};

Word * mercury_data_hlds_data__common_59[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 8),
	(Word *) string_const("det", 3),
	(Word *) string_const("semidet", 7),
	(Word *) string_const("nondet", 6),
	(Word *) string_const("multidet", 8),
	(Word *) string_const("cc_nondet", 9),
	(Word *) string_const("cc_multidet", 11),
	(Word *) string_const("erroneous", 9),
	(Word *) string_const("failure", 7)
};

Word * mercury_data_hlds_data__common_60[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_43)
};

Word * mercury_data_hlds_data__common_61[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("no_tag", 6)
};

Word * mercury_data_hlds_data__common_62[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_hlds_data__common_63[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_62),
	(Word *) string_const("string_constant", 15)
};

extern Word * mercury_data___base_type_info_float_0[];
Word * mercury_data_hlds_data__common_64[] = {
	(Word *) (Integer) mercury_data___base_type_info_float_0
};

Word * mercury_data_hlds_data__common_65[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_64),
	(Word *) string_const("float_constant", 14)
};

Word * mercury_data_hlds_data__common_66[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("int_constant", 12)
};

Word * mercury_data_hlds_data__common_67[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("pred_closure_tag", 16)
};

Word * mercury_data_hlds_data__common_68[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("code_addr_constant", 18)
};

Word * mercury_data_hlds_data__common_69[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_62),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_62),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("base_type_info_constant", 23)
};

Word * mercury_data_hlds_data__common_70[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("simple_tag", 10)
};

Word * mercury_data_hlds_data__common_71[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("complicated_tag", 15)
};

Word * mercury_data_hlds_data__common_72[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("complicated_constant_tag", 24)
};

Word * mercury_data_hlds_data__common_73[] = {
	(Word *) ((Integer) 7),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_66),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_67),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_68),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_69),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_70),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_71),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_72)
};

Word * mercury_data_hlds_data__common_74[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_3)
};

Word * mercury_data_hlds_data__common_75[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_74)
};

Word * mercury_data_hlds_data__common_76[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0
};

Word * mercury_data_hlds_data__common_77[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_76),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("cons", 4)
};

Word * mercury_data_hlds_data__common_78[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("int_const", 9)
};

Word * mercury_data_hlds_data__common_79[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_62),
	(Word *) string_const("string_const", 12)
};

Word * mercury_data_hlds_data__common_80[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_64),
	(Word *) string_const("float_const", 11)
};

Word * mercury_data_hlds_data__common_81[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("pred_const", 10)
};

Word * mercury_data_hlds_data__common_82[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("code_addr_const", 15)
};

Word * mercury_data_hlds_data__common_83[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_62),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_62),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_19),
	(Word *) string_const("base_type_info_const", 20)
};

Word * mercury_data_hlds_data__common_84[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_80),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_81),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_82),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_data__common_83)
};

Word * mercury_data_hlds_data__common_85[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("can_fail", 8),
	(Word *) string_const("cannot_fail", 11)
};

BEGIN_MODULE(mercury__hlds_data_module0)
	init_entry(mercury____Index___hlds_data_hlds__mode_body_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_hlds__mode_body_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_hlds__mode_body_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module1)
	init_entry(mercury____Index___hlds_data_hlds__mode_defn_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_hlds__mode_defn_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_hlds__mode_defn_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module2)
	init_entry(mercury____Index___hlds_data_mode_table_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_mode_table_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_mode_table_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module3)
	init_entry(mercury____Index___hlds_data_hlds__inst_defn_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_hlds__inst_defn_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_hlds__inst_defn_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module4)
	init_entry(mercury____Index___hlds_data_unify_inst_pair_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_unify_inst_pair_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_unify_inst_pair_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module5)
	init_entry(mercury____Index___hlds_data_user_inst_table_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_user_inst_table_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_user_inst_table_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module6)
	init_entry(mercury____Index___hlds_data_inst_table_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_inst_table_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_inst_table_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module7)
	init_entry(mercury____Index___hlds_data_hlds__type_defn_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_hlds__type_defn_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_hlds__type_defn_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module8)
	init_entry(mercury____Index___hlds_data_hlds__cons_defn_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_data_hlds__cons_defn_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_data_hlds__cons_defn_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module9)
	init_entry(mercury__hlds_data__make_cons_id__ua10000_4_0);
	init_label(mercury__hlds_data__make_cons_id__ua10000_4_0_i2);
BEGIN_CODE

/* code for predicate 'make_cons_id__ua10000'/4 in mode 0 */
Define_static(mercury__hlds_data__make_cons_id__ua10000_4_0);
	incr_sp_push_msg(2, "make_cons_id__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_0);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__hlds_data__make_cons_id__ua10000_4_0_i2,
		STATIC(mercury__hlds_data__make_cons_id__ua10000_4_0));
	}
Define_label(mercury__hlds_data__make_cons_id__ua10000_4_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__make_cons_id__ua10000_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module10)
	init_entry(mercury__hlds_data__cons_id_to_const_3_0);
	init_label(mercury__hlds_data__cons_id_to_const_3_0_i4);
	init_label(mercury__hlds_data__cons_id_to_const_3_0_i6);
	init_label(mercury__hlds_data__cons_id_to_const_3_0_i8);
	init_label(mercury__hlds_data__cons_id_to_const_3_0_i1);
BEGIN_CODE

/* code for predicate 'cons_id_to_const'/3 in mode 0 */
Define_entry(mercury__hlds_data__cons_id_to_const_3_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__hlds_data__cons_id_to_const_3_0_i4);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_data__cons_id_to_const_3_0_i1);
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_data__cons_id_to_const_3_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__hlds_data__cons_id_to_const_3_0_i6);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__hlds_data__cons_id_to_const_3_0_i1);
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_data__cons_id_to_const_3_0_i6);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__hlds_data__cons_id_to_const_3_0_i8);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_data__cons_id_to_const_3_0_i8);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__hlds_data__cons_id_to_const_3_0_i1);
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r3 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_data__cons_id_to_const_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module11)
	init_entry(mercury__hlds_data__make_functor_cons_id_3_0);
	init_label(mercury__hlds_data__make_functor_cons_id_3_0_i4);
	init_label(mercury__hlds_data__make_functor_cons_id_3_0_i5);
	init_label(mercury__hlds_data__make_functor_cons_id_3_0_i6);
BEGIN_CODE

/* code for predicate 'make_functor_cons_id'/3 in mode 0 */
Define_entry(mercury__hlds_data__make_functor_cons_id_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__hlds_data__make_functor_cons_id_3_0_i4);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
Define_label(mercury__hlds_data__make_functor_cons_id_3_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__hlds_data__make_functor_cons_id_3_0_i5);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	proceed();
Define_label(mercury__hlds_data__make_functor_cons_id_3_0_i5);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__hlds_data__make_functor_cons_id_3_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	proceed();
Define_label(mercury__hlds_data__make_functor_cons_id_3_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module12)
	init_entry(mercury__hlds_data__make_cons_id_4_0);
BEGIN_CODE

/* code for predicate 'make_cons_id'/4 in mode 0 */
Define_entry(mercury__hlds_data__make_cons_id_4_0);
	tailcall(STATIC(mercury__hlds_data__make_cons_id__ua10000_4_0),
		ENTRY(mercury__hlds_data__make_cons_id_4_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module13)
	init_entry(mercury__hlds_data__set_type_defn_6_0);
BEGIN_CODE

/* code for predicate 'hlds_data__set_type_defn'/6 in mode 0 */
Define_entry(mercury__hlds_data__set_type_defn_6_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module14)
	init_entry(mercury__hlds_data__get_type_defn_tvarset_2_0);
BEGIN_CODE

/* code for predicate 'hlds_data__get_type_defn_tvarset'/2 in mode 0 */
Define_entry(mercury__hlds_data__get_type_defn_tvarset_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module15)
	init_entry(mercury__hlds_data__get_type_defn_tparams_2_0);
BEGIN_CODE

/* code for predicate 'hlds_data__get_type_defn_tparams'/2 in mode 0 */
Define_entry(mercury__hlds_data__get_type_defn_tparams_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module16)
	init_entry(mercury__hlds_data__get_type_defn_body_2_0);
BEGIN_CODE

/* code for predicate 'hlds_data__get_type_defn_body'/2 in mode 0 */
Define_entry(mercury__hlds_data__get_type_defn_body_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module17)
	init_entry(mercury__hlds_data__get_type_defn_status_2_0);
BEGIN_CODE

/* code for predicate 'hlds_data__get_type_defn_status'/2 in mode 0 */
Define_entry(mercury__hlds_data__get_type_defn_status_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module18)
	init_entry(mercury__hlds_data__get_type_defn_context_2_0);
BEGIN_CODE

/* code for predicate 'hlds_data__get_type_defn_context'/2 in mode 0 */
Define_entry(mercury__hlds_data__get_type_defn_context_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module19)
	init_entry(mercury__hlds_data__set_type_defn_status_3_0);
BEGIN_CODE

/* code for predicate 'hlds_data__set_type_defn_status'/3 in mode 0 */
Define_entry(mercury__hlds_data__set_type_defn_status_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module20)
	init_entry(mercury__hlds_data__inst_table_init_1_0);
	init_label(mercury__hlds_data__inst_table_init_1_0_i2);
	init_label(mercury__hlds_data__inst_table_init_1_0_i3);
	init_label(mercury__hlds_data__inst_table_init_1_0_i4);
	init_label(mercury__hlds_data__inst_table_init_1_0_i5);
	init_label(mercury__hlds_data__inst_table_init_1_0_i6);
	init_label(mercury__hlds_data__inst_table_init_1_0_i7);
BEGIN_CODE

/* code for predicate 'inst_table_init'/1 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_init_1_0);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	incr_sp_push_msg(6, "inst_table_init");
	detstackvar(6) = (Integer) succip;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__inst_table_init_1_0_i2,
		ENTRY(mercury__hlds_data__inst_table_init_1_0));
	}
Define_label(mercury__hlds_data__inst_table_init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__inst_table_init_1_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__inst_table_init_1_0_i3,
		ENTRY(mercury__hlds_data__inst_table_init_1_0));
	}
Define_label(mercury__hlds_data__inst_table_init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_data__inst_table_init_1_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__inst_table_init_1_0_i4,
		ENTRY(mercury__hlds_data__inst_table_init_1_0));
	}
Define_label(mercury__hlds_data__inst_table_init_1_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_data__inst_table_init_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__inst_table_init_1_0_i5,
		ENTRY(mercury__hlds_data__inst_table_init_1_0));
	}
Define_label(mercury__hlds_data__inst_table_init_1_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_data__inst_table_init_1_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__inst_table_init_1_0_i6,
		ENTRY(mercury__hlds_data__inst_table_init_1_0));
	}
Define_label(mercury__hlds_data__inst_table_init_1_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_data__inst_table_init_1_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__inst_table_init_1_0_i7,
		ENTRY(mercury__hlds_data__inst_table_init_1_0));
	}
Define_label(mercury__hlds_data__inst_table_init_1_0_i7);
	update_prof_current_proc(LABEL(mercury__hlds_data__inst_table_init_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module21)
	init_entry(mercury__hlds_data__inst_table_get_user_insts_2_0);
BEGIN_CODE

/* code for predicate 'inst_table_get_user_insts'/2 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_get_user_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module22)
	init_entry(mercury__hlds_data__inst_table_get_unify_insts_2_0);
BEGIN_CODE

/* code for predicate 'inst_table_get_unify_insts'/2 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_get_unify_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module23)
	init_entry(mercury__hlds_data__inst_table_get_merge_insts_2_0);
BEGIN_CODE

/* code for predicate 'inst_table_get_merge_insts'/2 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_get_merge_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module24)
	init_entry(mercury__hlds_data__inst_table_get_ground_insts_2_0);
BEGIN_CODE

/* code for predicate 'inst_table_get_ground_insts'/2 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_get_ground_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module25)
	init_entry(mercury__hlds_data__inst_table_get_shared_insts_2_0);
BEGIN_CODE

/* code for predicate 'inst_table_get_shared_insts'/2 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_get_shared_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module26)
	init_entry(mercury__hlds_data__inst_table_get_mostly_uniq_insts_2_0);
BEGIN_CODE

/* code for predicate 'inst_table_get_mostly_uniq_insts'/2 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_get_mostly_uniq_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module27)
	init_entry(mercury__hlds_data__inst_table_set_user_insts_3_0);
BEGIN_CODE

/* code for predicate 'inst_table_set_user_insts'/3 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_set_user_insts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module28)
	init_entry(mercury__hlds_data__inst_table_set_unify_insts_3_0);
BEGIN_CODE

/* code for predicate 'inst_table_set_unify_insts'/3 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_set_unify_insts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module29)
	init_entry(mercury__hlds_data__inst_table_set_merge_insts_3_0);
BEGIN_CODE

/* code for predicate 'inst_table_set_merge_insts'/3 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_set_merge_insts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module30)
	init_entry(mercury__hlds_data__inst_table_set_ground_insts_3_0);
BEGIN_CODE

/* code for predicate 'inst_table_set_ground_insts'/3 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_set_ground_insts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module31)
	init_entry(mercury__hlds_data__inst_table_set_shared_insts_3_0);
BEGIN_CODE

/* code for predicate 'inst_table_set_shared_insts'/3 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_set_shared_insts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module32)
	init_entry(mercury__hlds_data__inst_table_set_mostly_uniq_insts_3_0);
BEGIN_CODE

/* code for predicate 'inst_table_set_mostly_uniq_insts'/3 in mode 0 */
Define_entry(mercury__hlds_data__inst_table_set_mostly_uniq_insts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module33)
	init_entry(mercury__hlds_data__user_inst_table_get_inst_defns_2_0);
BEGIN_CODE

/* code for predicate 'user_inst_table_get_inst_defns'/2 in mode 0 */
Define_entry(mercury__hlds_data__user_inst_table_get_inst_defns_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module34)
	init_entry(mercury__hlds_data__user_inst_table_get_inst_ids_2_0);
BEGIN_CODE

/* code for predicate 'user_inst_table_get_inst_ids'/2 in mode 0 */
Define_entry(mercury__hlds_data__user_inst_table_get_inst_ids_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module35)
	init_entry(mercury__hlds_data__user_inst_table_insert_4_0);
	init_label(mercury__hlds_data__user_inst_table_insert_4_0_i2);
	init_label(mercury__hlds_data__user_inst_table_insert_4_0_i1);
BEGIN_CODE

/* code for predicate 'user_inst_table_insert'/4 in mode 0 */
Define_entry(mercury__hlds_data__user_inst_table_insert_4_0);
	r5 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	incr_sp_push_msg(3, "user_inst_table_insert");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury__map__insert_4_0);
	call_localret(ENTRY(mercury__map__insert_4_0),
		mercury__hlds_data__user_inst_table_insert_4_0_i2,
		ENTRY(mercury__hlds_data__user_inst_table_insert_4_0));
	}
Define_label(mercury__hlds_data__user_inst_table_insert_4_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__user_inst_table_insert_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__hlds_data__user_inst_table_insert_4_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__hlds_data__user_inst_table_insert_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module36)
	init_entry(mercury__hlds_data__user_inst_table_optimize_2_0);
	init_label(mercury__hlds_data__user_inst_table_optimize_2_0_i2);
	init_label(mercury__hlds_data__user_inst_table_optimize_2_0_i3);
BEGIN_CODE

/* code for predicate 'user_inst_table_optimize'/2 in mode 0 */
Define_entry(mercury__hlds_data__user_inst_table_optimize_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(2, "user_inst_table_optimize");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury__map__optimize_2_0);
	call_localret(ENTRY(mercury__map__optimize_2_0),
		mercury__hlds_data__user_inst_table_optimize_2_0_i2,
		ENTRY(mercury__hlds_data__user_inst_table_optimize_2_0));
	}
Define_label(mercury__hlds_data__user_inst_table_optimize_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__user_inst_table_optimize_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	{
	Declare_entry(mercury__list__sort_2_0);
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__hlds_data__user_inst_table_optimize_2_0_i3,
		ENTRY(mercury__hlds_data__user_inst_table_optimize_2_0));
	}
Define_label(mercury__hlds_data__user_inst_table_optimize_2_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_data__user_inst_table_optimize_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module37)
	init_entry(mercury__hlds_data__mode_table_get_mode_defns_2_0);
BEGIN_CODE

/* code for predicate 'mode_table_get_mode_defns'/2 in mode 0 */
Define_entry(mercury__hlds_data__mode_table_get_mode_defns_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module38)
	init_entry(mercury__hlds_data__mode_table_get_mode_ids_2_0);
BEGIN_CODE

/* code for predicate 'mode_table_get_mode_ids'/2 in mode 0 */
Define_entry(mercury__hlds_data__mode_table_get_mode_ids_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module39)
	init_entry(mercury__hlds_data__mode_table_insert_4_0);
	init_label(mercury__hlds_data__mode_table_insert_4_0_i2);
	init_label(mercury__hlds_data__mode_table_insert_4_0_i1);
BEGIN_CODE

/* code for predicate 'mode_table_insert'/4 in mode 0 */
Define_entry(mercury__hlds_data__mode_table_insert_4_0);
	r5 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	incr_sp_push_msg(3, "mode_table_insert");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury__map__insert_4_0);
	call_localret(ENTRY(mercury__map__insert_4_0),
		mercury__hlds_data__mode_table_insert_4_0_i2,
		ENTRY(mercury__hlds_data__mode_table_insert_4_0));
	}
Define_label(mercury__hlds_data__mode_table_insert_4_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__mode_table_insert_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__hlds_data__mode_table_insert_4_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__hlds_data__mode_table_insert_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module40)
	init_entry(mercury__hlds_data__mode_table_init_1_0);
	init_label(mercury__hlds_data__mode_table_init_1_0_i2);
BEGIN_CODE

/* code for predicate 'mode_table_init'/1 in mode 0 */
Define_entry(mercury__hlds_data__mode_table_init_1_0);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	incr_sp_push_msg(1, "mode_table_init");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_data__mode_table_init_1_0_i2,
		ENTRY(mercury__hlds_data__mode_table_init_1_0));
	}
Define_label(mercury__hlds_data__mode_table_init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__mode_table_init_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module41)
	init_entry(mercury__hlds_data__mode_table_optimize_2_0);
	init_label(mercury__hlds_data__mode_table_optimize_2_0_i2);
	init_label(mercury__hlds_data__mode_table_optimize_2_0_i3);
BEGIN_CODE

/* code for predicate 'mode_table_optimize'/2 in mode 0 */
Define_entry(mercury__hlds_data__mode_table_optimize_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(2, "mode_table_optimize");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury__map__optimize_2_0);
	call_localret(ENTRY(mercury__map__optimize_2_0),
		mercury__hlds_data__mode_table_optimize_2_0_i2,
		ENTRY(mercury__hlds_data__mode_table_optimize_2_0));
	}
Define_label(mercury__hlds_data__mode_table_optimize_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_data__mode_table_optimize_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	{
	Declare_entry(mercury__list__sort_2_0);
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__hlds_data__mode_table_optimize_2_0_i3,
		ENTRY(mercury__hlds_data__mode_table_optimize_2_0));
	}
Define_label(mercury__hlds_data__mode_table_optimize_2_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_data__mode_table_optimize_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module42)
	init_entry(mercury__hlds_data__determinism_components_3_0);
BEGIN_CODE

/* code for predicate 'determinism_components'/3 in mode 0 */
Define_entry(mercury__hlds_data__determinism_components_3_0);
	{
	static const Word mercury_const_2[] = {
		((Integer) 1),
		((Integer) 1),
		((Integer) 3),
		((Integer) 3),
		((Integer) 2),
		((Integer) 2),
		((Integer) 0),
		((Integer) 0)
	};
	r2 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_2), (Integer) r1);
	}
	{
	static const Word mercury_const_1[] = {
		((Integer) 1),
		((Integer) 0),
		((Integer) 0),
		((Integer) 1),
		((Integer) 0),
		((Integer) 1),
		((Integer) 1),
		((Integer) 0)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module43)
	init_entry(mercury__hlds_data__determinism_components_3_1);
	init_label(mercury__hlds_data__determinism_components_3_1_i3);
BEGIN_CODE

/* code for predicate 'determinism_components'/3 in mode 1 */
Define_entry(mercury__hlds_data__determinism_components_3_1);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_data__determinism_components_3_1_i3);
	{
	static const Word mercury_const_1[] = {
		((Integer) 6),
		((Integer) 0),
		((Integer) 5),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__hlds_data__determinism_components_3_1_i3);
	{
	static const Word mercury_const_1[] = {
		((Integer) 7),
		((Integer) 1),
		((Integer) 4),
		((Integer) 2)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module44)
	init_entry(mercury__hlds_data__determinism_to_code_model_2_0);
BEGIN_CODE

/* code for predicate 'determinism_to_code_model'/2 in mode 0 */
Define_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 1),
		((Integer) 2),
		((Integer) 2),
		((Integer) 1),
		((Integer) 0),
		((Integer) 0),
		((Integer) 1)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module45)
	init_entry(mercury____Unify___hlds_data__cons_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__cons_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__cons_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module46)
	init_entry(mercury____Index___hlds_data__cons_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__cons_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_3);
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__cons_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module47)
	init_entry(mercury____Compare___hlds_data__cons_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__cons_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_3);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__cons_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module48)
	init_entry(mercury____Unify___hlds_data__cons_id_0_0);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i1036);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i7);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i9);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i1035);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i14);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i12);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i16);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i1032);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i1);
	init_label(mercury____Unify___hlds_data__cons_id_0_0_i1034);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__cons_id_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1035);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1036);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1032);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1032);
	if ((word_to_float((Integer) field(mktag(3), (Integer) r1, ((Integer) 1))) != word_to_float((Integer) field(mktag(3), (Integer) r2, ((Integer) 1)))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1032);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i1036);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i7);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1034);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i7);
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i9);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1034);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i9);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 2))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 3)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1034);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i1035);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i12);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury____Unify___hlds_data__cons_id_0_0_i14,
		ENTRY(mercury____Unify___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__cons_id_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i12);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i16);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1034);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i16);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((strcmp((char *)(Integer) field(mktag(2), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(2), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_id_0_0_i1034);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i1032);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_data__cons_id_0_0_i1034);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module49)
	init_entry(mercury____Index___hlds_data__cons_id_0_0);
	init_label(mercury____Index___hlds_data__cons_id_0_0_i5);
	init_label(mercury____Index___hlds_data__cons_id_0_0_i6);
	init_label(mercury____Index___hlds_data__cons_id_0_0_i7);
	init_label(mercury____Index___hlds_data__cons_id_0_0_i4);
	init_label(mercury____Index___hlds_data__cons_id_0_0_i8);
	init_label(mercury____Index___hlds_data__cons_id_0_0_i9);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__cons_id_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___hlds_data__cons_id_0_0_i4);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Index___hlds_data__cons_id_0_0_i5);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___hlds_data__cons_id_0_0_i5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury____Index___hlds_data__cons_id_0_0_i6);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___hlds_data__cons_id_0_0_i6);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury____Index___hlds_data__cons_id_0_0_i7);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___hlds_data__cons_id_0_0_i7);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___hlds_data__cons_id_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_data__cons_id_0_0_i8);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_data__cons_id_0_0_i8);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_data__cons_id_0_0_i9);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_data__cons_id_0_0_i9);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module50)
	init_entry(mercury____Compare___hlds_data__cons_id_0_0);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i2);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i3);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i4);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i6);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i13);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i20);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i21);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i19);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i16);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i30);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i26);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i39);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i45);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i12);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i56);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i52);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i62);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i9);
	init_label(mercury____Compare___hlds_data__cons_id_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__cons_id_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_data__cons_id_0_0),
		mercury____Compare___hlds_data__cons_id_0_0_i2,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_data__cons_id_0_0),
		mercury____Compare___hlds_data__cons_id_0_0_i3,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i12);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	tailcall(ENTRY(mercury__builtin_compare_float_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i13);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i16);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__cons_id_0_0_i20,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i19);
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i21);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i16);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i26);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__cons_id_0_0_i30,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i30);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i26);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_data__cons_id_0_0_i39,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_data__cons_id_0_0_i45,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i45);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i21);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i52);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		mercury____Compare___hlds_data__cons_id_0_0_i56,
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i56);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_id_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i52);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i62);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i1001);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i62);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_id_0_0_i1001);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_id_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__cons_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module51)
	init_entry(mercury____Unify___hlds_data__hlds__cons_defn_0_0);
	init_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i2);
	init_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i4);
	init_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__cons_defn_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_data__hlds__cons_defn_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__hlds__cons_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__cons_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_data__hlds__cons_defn_0_0_i4,
		ENTRY(mercury____Unify___hlds_data__hlds__cons_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__cons_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Unify___hlds_data__hlds__cons_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__cons_defn_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module52)
	init_entry(mercury____Index___hlds_data__hlds__cons_defn_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__cons_defn_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_hlds__cons_defn_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__hlds__cons_defn_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module53)
	init_entry(mercury____Compare___hlds_data__hlds__cons_defn_0_0);
	init_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i4);
	init_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i5);
	init_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i3);
	init_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__cons_defn_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_data__hlds__cons_defn_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__hlds__cons_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__cons_defn_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i3);
Define_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i3);
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_data__hlds__cons_defn_0_0_i10,
		ENTRY(mercury____Compare___hlds_data__hlds__cons_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__cons_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__cons_defn_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__cons_defn_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module54)
	init_entry(mercury____Unify___hlds_data__type_id_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__type_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_data__type_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module55)
	init_entry(mercury____Index___hlds_data__type_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__type_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_data__type_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module56)
	init_entry(mercury____Compare___hlds_data__type_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__type_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_data__type_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module57)
	init_entry(mercury____Unify___hlds_data__type_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__type_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__type_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module58)
	init_entry(mercury____Index___hlds_data__type_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__type_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__type_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module59)
	init_entry(mercury____Compare___hlds_data__type_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__type_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__type_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module60)
	init_entry(mercury____Unify___hlds_data__hlds__type_defn_0_0);
	init_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i2);
	init_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i4);
	init_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i6);
	init_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__type_defn_0_0);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_data__hlds__type_defn_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_data__hlds__type_defn_0_0_i4,
		ENTRY(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(6);
	{
		call_localret(STATIC(mercury____Unify___hlds_data__hlds__type_body_0_0),
		mercury____Unify___hlds_data__hlds__type_defn_0_0_i6,
		ENTRY(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(7)))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Unify___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_defn_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module61)
	init_entry(mercury____Index___hlds_data__hlds__type_defn_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__type_defn_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_hlds__type_defn_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__hlds__type_defn_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module62)
	init_entry(mercury____Compare___hlds_data__hlds__type_defn_0_0);
	init_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i4);
	init_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i5);
	init_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i3);
	init_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i10);
	init_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i16);
	init_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__type_defn_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_data__hlds__type_defn_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0_i3);
Define_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_data__hlds__type_defn_0_0_i10,
		ENTRY(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(6);
	{
		call_localret(STATIC(mercury____Compare___hlds_data__hlds__type_body_0_0),
		mercury____Compare___hlds_data__hlds__type_defn_0_0_i16,
		ENTRY(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__hlds__type_defn_0_0_i22,
		ENTRY(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_defn_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_defn_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__type_defn_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module63)
	init_entry(mercury____Unify___hlds_data__hlds__type_body_0_0);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1015);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i8);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i10);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i6);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i12);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1012);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
	init_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__type_body_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1015);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1012);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1015);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_data__hlds__type_body_0_0_i8,
		ENTRY(mercury____Unify___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__hlds__type_body_0_0_i10,
		ENTRY(mercury____Unify___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1014);
	r3 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__type_body_0_0_i1014);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term_0_0),
		ENTRY(mercury____Unify___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1012);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__type_body_0_0_i1014);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module64)
	init_entry(mercury____Index___hlds_data__hlds__type_body_0_0);
	init_label(mercury____Index___hlds_data__hlds__type_body_0_0_i4);
	init_label(mercury____Index___hlds_data__hlds__type_body_0_0_i5);
	init_label(mercury____Index___hlds_data__hlds__type_body_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__type_body_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_data__hlds__type_body_0_0_i4);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___hlds_data__hlds__type_body_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_data__hlds__type_body_0_0_i5);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_data__hlds__type_body_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___hlds_data__hlds__type_body_0_0_i6);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_data__hlds__type_body_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module65)
	init_entry(mercury____Compare___hlds_data__hlds__type_body_0_0);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i2);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i3);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i4);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i6);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i12);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i18);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i19);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i17);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i24);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i14);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i31);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i9);
	init_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__type_body_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_data__hlds__type_body_0_0),
		mercury____Compare___hlds_data__hlds__type_body_0_0_i2,
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_data__hlds__type_body_0_0),
		mercury____Compare___hlds_data__hlds__type_body_0_0_i3,
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i12);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i14);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i9);
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_data__hlds__type_body_0_0_i18,
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i17);
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i17);
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__hlds__type_body_0_0_i24,
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i24);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i19);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i14);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i31);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) tempr1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i1001);
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(2), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i31);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__type_body_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__type_body_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__type_body_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module66)
	init_entry(mercury____Unify___hlds_data__cons_tag_values_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__cons_tag_values_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__cons_tag_values_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module67)
	init_entry(mercury____Index___hlds_data__cons_tag_values_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__cons_tag_values_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__cons_tag_values_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module68)
	init_entry(mercury____Compare___hlds_data__cons_tag_values_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__cons_tag_values_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_values_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module69)
	init_entry(mercury____Unify___hlds_data__cons_tag_0_0);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i5);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i7);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i9);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i11);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i13);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i15);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i17);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i4);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i19);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i21);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i2);
	init_label(mercury____Unify___hlds_data__cons_tag_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__cons_tag_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i5) AND
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i7) AND
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i9) AND
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i11) AND
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i13) AND
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i15) AND
		LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i17));
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i5);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i7);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i9);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i11);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 2))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 3)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i13);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i15);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i17);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i4);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i19);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i19);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i21);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(1), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i21);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	if ((word_to_float((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != word_to_float((Integer) field(mktag(2), (Integer) r2, ((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__cons_tag_0_0_i1);
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__cons_tag_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module70)
	init_entry(mercury____Index___hlds_data__cons_tag_0_0);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i5);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i6);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i7);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i8);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i9);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i10);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i11);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i4);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i12);
	init_label(mercury____Index___hlds_data__cons_tag_0_0_i13);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__cons_tag_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___hlds_data__cons_tag_0_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i5) AND
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i6) AND
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i7) AND
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i8) AND
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i9) AND
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i10) AND
		LABEL(mercury____Index___hlds_data__cons_tag_0_0_i11));
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i7);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i8);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i9);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i10);
	r1 = ((Integer) 7);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i11);
	r1 = ((Integer) 8);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_data__cons_tag_0_0_i12);
	r1 = ((Integer) 9);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_data__cons_tag_0_0_i13);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_data__cons_tag_0_0_i13);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module71)
	init_entry(mercury____Compare___hlds_data__cons_tag_0_0);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i2);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i3);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i4);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i6);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i13);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i16);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i20);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i19);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i26);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i30);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i36);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i40);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i46);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i53);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i56);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i60);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i66);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i70);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i12);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i76);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i78);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	init_label(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__cons_tag_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_data__cons_tag_0_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i2,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_data__cons_tag_0_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i3,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i12);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i13) AND
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i16) AND
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i26) AND
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i36) AND
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i53) AND
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i56) AND
		LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i66));
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i16);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i20,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i19);
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i26);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i30,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i30);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i36);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i40,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i46,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i53);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i56);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i60,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i60);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i66);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__cons_tag_0_0_i70,
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i70);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__cons_tag_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i76);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i76);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i78);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i78);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	tailcall(ENTRY(mercury__builtin_compare_float_3_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
Define_label(mercury____Compare___hlds_data__cons_tag_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__cons_tag_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module72)
	init_entry(mercury____Unify___hlds_data__tag_bits_0_0);
	init_label(mercury____Unify___hlds_data__tag_bits_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__tag_bits_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_data__tag_bits_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__tag_bits_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module73)
	init_entry(mercury____Index___hlds_data__tag_bits_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__tag_bits_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_data__tag_bits_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module74)
	init_entry(mercury____Compare___hlds_data__tag_bits_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__tag_bits_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__tag_bits_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module75)
	init_entry(mercury____Unify___hlds_data__inst_id_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__inst_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_data__inst_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module76)
	init_entry(mercury____Index___hlds_data__inst_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__inst_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_data__inst_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module77)
	init_entry(mercury____Compare___hlds_data__inst_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__inst_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_data__inst_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module78)
	init_entry(mercury____Unify___hlds_data__inst_table_0_0);
	init_label(mercury____Unify___hlds_data__inst_table_0_0_i2);
	init_label(mercury____Unify___hlds_data__inst_table_0_0_i4);
	init_label(mercury____Unify___hlds_data__inst_table_0_0_i6);
	init_label(mercury____Unify___hlds_data__inst_table_0_0_i8);
	init_label(mercury____Unify___hlds_data__inst_table_0_0_i10);
	init_label(mercury____Unify___hlds_data__inst_table_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__inst_table_0_0);
	incr_sp_push_msg(11, "__Unify__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury____Unify___hlds_data__user_inst_table_0_0),
		mercury____Unify___hlds_data__inst_table_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__inst_table_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__inst_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__inst_table_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__inst_table_0_0_i4,
		ENTRY(mercury____Unify___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__inst_table_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__inst_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__inst_table_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__inst_table_0_0_i6,
		ENTRY(mercury____Unify___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__inst_table_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__inst_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__inst_table_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__inst_table_0_0_i8,
		ENTRY(mercury____Unify___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__inst_table_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__inst_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__inst_table_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__inst_table_0_0_i10,
		ENTRY(mercury____Unify___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__inst_table_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__inst_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__inst_table_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__inst_table_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module79)
	init_entry(mercury____Index___hlds_data__inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__inst_table_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_inst_table_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__inst_table_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module80)
	init_entry(mercury____Compare___hlds_data__inst_table_0_0);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i4);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i5);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i3);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i10);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i16);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i22);
	init_label(mercury____Compare___hlds_data__inst_table_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__inst_table_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury____Compare___hlds_data__user_inst_table_0_0),
		mercury____Compare___hlds_data__inst_table_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__inst_table_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__inst_table_0_0_i3);
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i3);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__inst_table_0_0_i10,
		ENTRY(mercury____Compare___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__inst_table_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__inst_table_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__inst_table_0_0_i16,
		ENTRY(mercury____Compare___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__inst_table_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__inst_table_0_0_i5);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__inst_table_0_0_i22,
		ENTRY(mercury____Compare___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__inst_table_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__inst_table_0_0_i5);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__inst_table_0_0_i28,
		ENTRY(mercury____Compare___hlds_data__inst_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__inst_table_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__inst_table_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__inst_table_0_0_i5);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module81)
	init_entry(mercury____Unify___hlds_data__user_inst_table_0_0);
	init_label(mercury____Unify___hlds_data__user_inst_table_0_0_i2);
	init_label(mercury____Unify___hlds_data__user_inst_table_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__user_inst_table_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__user_inst_table_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__user_inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__user_inst_table_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__user_inst_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__user_inst_table_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_data__user_inst_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__user_inst_table_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module82)
	init_entry(mercury____Index___hlds_data__user_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__user_inst_table_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_user_inst_table_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__user_inst_table_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module83)
	init_entry(mercury____Compare___hlds_data__user_inst_table_0_0);
	init_label(mercury____Compare___hlds_data__user_inst_table_0_0_i4);
	init_label(mercury____Compare___hlds_data__user_inst_table_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__user_inst_table_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__user_inst_table_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__user_inst_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__user_inst_table_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__user_inst_table_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__user_inst_table_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_data__user_inst_table_0_0_i3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_data__user_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module84)
	init_entry(mercury____Unify___hlds_data__user_inst_defns_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__user_inst_defns_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__user_inst_defns_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module85)
	init_entry(mercury____Index___hlds_data__user_inst_defns_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__user_inst_defns_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__user_inst_defns_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module86)
	init_entry(mercury____Compare___hlds_data__user_inst_defns_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__user_inst_defns_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__inst_defn_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__user_inst_defns_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module87)
	init_entry(mercury____Unify___hlds_data__unify_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__unify_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__unify_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module88)
	init_entry(mercury____Index___hlds_data__unify_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__unify_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__unify_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module89)
	init_entry(mercury____Compare___hlds_data__unify_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__unify_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_det_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__unify_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module90)
	init_entry(mercury____Unify___hlds_data__unify_inst_pair_0_0);
	init_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i2);
	init_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i4);
	init_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1005);
	init_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__unify_inst_pair_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1005);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__inst_0_0),
		mercury____Unify___hlds_data__unify_inst_pair_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__unify_inst_pair_0_0));
	}
Define_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__unify_inst_pair_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__inst_0_0),
		mercury____Unify___hlds_data__unify_inst_pair_0_0_i4,
		ENTRY(mercury____Unify___hlds_data__unify_inst_pair_0_0));
	}
Define_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__unify_inst_pair_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__unify_inst_pair_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module91)
	init_entry(mercury____Index___hlds_data__unify_inst_pair_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__unify_inst_pair_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_unify_inst_pair_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__unify_inst_pair_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module92)
	init_entry(mercury____Compare___hlds_data__unify_inst_pair_0_0);
	init_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i4);
	init_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i5);
	init_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i3);
	init_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i10);
	init_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i16);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__unify_inst_pair_0_0);
	incr_sp_push_msg(7, "__Compare__");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_data__unify_inst_pair_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	}
Define_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__unify_inst_pair_0_0_i3);
Define_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Compare___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__inst_0_0),
		mercury____Compare___hlds_data__unify_inst_pair_0_0_i10,
		ENTRY(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	}
Define_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__unify_inst_pair_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__inst_0_0),
		mercury____Compare___hlds_data__unify_inst_pair_0_0_i16,
		ENTRY(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	}
Define_label(mercury____Compare___hlds_data__unify_inst_pair_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__unify_inst_pair_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__unify_inst_pair_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module93)
	init_entry(mercury____Unify___hlds_data__merge_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__merge_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__merge_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module94)
	init_entry(mercury____Index___hlds_data__merge_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__merge_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__merge_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module95)
	init_entry(mercury____Compare___hlds_data__merge_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__merge_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_2);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__merge_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module96)
	init_entry(mercury____Unify___hlds_data__ground_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__ground_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__ground_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module97)
	init_entry(mercury____Index___hlds_data__ground_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__ground_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__ground_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module98)
	init_entry(mercury____Compare___hlds_data__ground_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__ground_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__ground_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module99)
	init_entry(mercury____Unify___hlds_data__shared_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__shared_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__shared_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module100)
	init_entry(mercury____Index___hlds_data__shared_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__shared_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__shared_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module101)
	init_entry(mercury____Compare___hlds_data__shared_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__shared_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__shared_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module102)
	init_entry(mercury____Unify___hlds_data__mostly_uniq_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__mostly_uniq_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__mostly_uniq_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module103)
	init_entry(mercury____Index___hlds_data__mostly_uniq_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__mostly_uniq_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__mostly_uniq_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module104)
	init_entry(mercury____Compare___hlds_data__mostly_uniq_inst_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__mostly_uniq_inst_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_maybe_inst_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__mostly_uniq_inst_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module105)
	init_entry(mercury____Unify___hlds_data__maybe_inst_0_0);
	init_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1008);
	init_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1005);
	init_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1007);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__maybe_inst_0_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_0_0_i1008);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_0_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1008);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_0_0_i1007);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___prog_data__inst_0_0);
	tailcall(ENTRY(mercury____Unify___prog_data__inst_0_0),
		ENTRY(mercury____Unify___hlds_data__maybe_inst_0_0));
	}
Define_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__maybe_inst_0_0_i1007);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module106)
	init_entry(mercury____Index___hlds_data__maybe_inst_0_0);
	init_label(mercury____Index___hlds_data__maybe_inst_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__maybe_inst_0_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___hlds_data__maybe_inst_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_data__maybe_inst_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module107)
	init_entry(mercury____Compare___hlds_data__maybe_inst_0_0);
	init_label(mercury____Compare___hlds_data__maybe_inst_0_0_i2);
	init_label(mercury____Compare___hlds_data__maybe_inst_0_0_i3);
	init_label(mercury____Compare___hlds_data__maybe_inst_0_0_i4);
	init_label(mercury____Compare___hlds_data__maybe_inst_0_0_i6);
	init_label(mercury____Compare___hlds_data__maybe_inst_0_0_i11);
	init_label(mercury____Compare___hlds_data__maybe_inst_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__maybe_inst_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_data__maybe_inst_0_0),
		mercury____Compare___hlds_data__maybe_inst_0_0_i2,
		ENTRY(mercury____Compare___hlds_data__maybe_inst_0_0));
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__maybe_inst_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_data__maybe_inst_0_0),
		mercury____Compare___hlds_data__maybe_inst_0_0_i3,
		ENTRY(mercury____Compare___hlds_data__maybe_inst_0_0));
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__maybe_inst_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_0_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_0_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_0_0_i9);
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Compare___prog_data__inst_0_0);
	tailcall(ENTRY(mercury____Compare___prog_data__inst_0_0),
		ENTRY(mercury____Compare___hlds_data__maybe_inst_0_0));
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__maybe_inst_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module108)
	init_entry(mercury____Unify___hlds_data__maybe_inst_det_0_0);
	init_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1009);
	init_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i6);
	init_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1006);
	init_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__maybe_inst_det_0_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1009);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__inst_0_0),
		mercury____Unify___hlds_data__maybe_inst_det_0_0_i6,
		ENTRY(mercury____Unify___hlds_data__maybe_inst_det_0_0));
	}
Define_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__maybe_inst_det_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__maybe_inst_det_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module109)
	init_entry(mercury____Index___hlds_data__maybe_inst_det_0_0);
	init_label(mercury____Index___hlds_data__maybe_inst_det_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__maybe_inst_det_0_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___hlds_data__maybe_inst_det_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_data__maybe_inst_det_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module110)
	init_entry(mercury____Compare___hlds_data__maybe_inst_det_0_0);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i2);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i3);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i4);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i6);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i11);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i16);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i15);
	init_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__maybe_inst_det_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_data__maybe_inst_det_0_0),
		mercury____Compare___hlds_data__maybe_inst_det_0_0_i2,
		ENTRY(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_data__maybe_inst_det_0_0),
		mercury____Compare___hlds_data__maybe_inst_det_0_0_i3,
		ENTRY(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0_i9);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__inst_0_0),
		mercury____Compare___hlds_data__maybe_inst_det_0_0_i16,
		ENTRY(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	}
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__maybe_inst_det_0_0_i15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i15);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	}
Define_label(mercury____Compare___hlds_data__maybe_inst_det_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__maybe_inst_det_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module111)
	init_entry(mercury____Unify___hlds_data__hlds__inst_defn_0_0);
	init_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i2);
	init_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i4);
	init_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i6);
	init_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i8);
	init_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i10);
	init_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__inst_defn_0_0);
	incr_sp_push_msg(11, "__Unify__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_data__hlds__inst_defn_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_data__hlds__inst_defn_0_0_i4,
		ENTRY(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury____Unify___hlds_data__hlds__inst_body_0_0),
		mercury____Unify___hlds_data__hlds__inst_defn_0_0_i6,
		ENTRY(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___prog_data__condition_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__condition_0_0),
		mercury____Unify___hlds_data__hlds__inst_defn_0_0_i8,
		ENTRY(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury____Unify___hlds_data__hlds__inst_defn_0_0_i10,
		ENTRY(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	if (((Integer) detstackvar(5) != (Integer) detstackvar(10)))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__inst_defn_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module112)
	init_entry(mercury____Index___hlds_data__hlds__inst_defn_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__inst_defn_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_hlds__inst_defn_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__hlds__inst_defn_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module113)
	init_entry(mercury____Compare___hlds_data__hlds__inst_defn_0_0);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i4);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i3);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i10);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i16);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i22);
	init_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__inst_defn_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_data__hlds__inst_defn_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i3);
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_data__hlds__inst_defn_0_0_i10,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury____Compare___hlds_data__hlds__inst_body_0_0),
		mercury____Compare___hlds_data__hlds__inst_defn_0_0_i16,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___prog_data__condition_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__condition_0_0),
		mercury____Compare___hlds_data__hlds__inst_defn_0_0_i22,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		mercury____Compare___hlds_data__hlds__inst_defn_0_0_i28,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_defn_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__hlds__inst_defn_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module114)
	init_entry(mercury____Unify___hlds_data__hlds__inst_body_0_0);
	init_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1008);
	init_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1005);
	init_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1007);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__inst_body_0_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1008);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1008);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1007);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___prog_data__inst_0_0);
	tailcall(ENTRY(mercury____Unify___prog_data__inst_0_0),
		ENTRY(mercury____Unify___hlds_data__hlds__inst_body_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__inst_body_0_0_i1007);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module115)
	init_entry(mercury____Index___hlds_data__hlds__inst_body_0_0);
	init_label(mercury____Index___hlds_data__hlds__inst_body_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__inst_body_0_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___hlds_data__hlds__inst_body_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_data__hlds__inst_body_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module116)
	init_entry(mercury____Compare___hlds_data__hlds__inst_body_0_0);
	init_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i2);
	init_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i3);
	init_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i4);
	init_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i6);
	init_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i11);
	init_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__inst_body_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_data__hlds__inst_body_0_0),
		mercury____Compare___hlds_data__hlds__inst_body_0_0_i2,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_data__hlds__inst_body_0_0),
		mercury____Compare___hlds_data__hlds__inst_body_0_0_i3,
		ENTRY(mercury____Compare___hlds_data__hlds__inst_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__inst_body_0_0_i9);
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Compare___prog_data__inst_0_0);
	tailcall(ENTRY(mercury____Compare___prog_data__inst_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__inst_body_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__inst_body_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__inst_body_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module117)
	init_entry(mercury____Unify___hlds_data__mode_id_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__mode_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_data__mode_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module118)
	init_entry(mercury____Index___hlds_data__mode_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__mode_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_data__mode_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module119)
	init_entry(mercury____Compare___hlds_data__mode_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__mode_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_data__mode_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module120)
	init_entry(mercury____Unify___hlds_data__mode_table_0_0);
	init_label(mercury____Unify___hlds_data__mode_table_0_0_i2);
	init_label(mercury____Unify___hlds_data__mode_table_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__mode_table_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_data__mode_table_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__mode_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__mode_table_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__mode_table_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__mode_table_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_data__mode_table_0_0));
	}
Define_label(mercury____Unify___hlds_data__mode_table_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module121)
	init_entry(mercury____Index___hlds_data__mode_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__mode_table_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_mode_table_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__mode_table_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module122)
	init_entry(mercury____Compare___hlds_data__mode_table_0_0);
	init_label(mercury____Compare___hlds_data__mode_table_0_0_i4);
	init_label(mercury____Compare___hlds_data__mode_table_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__mode_table_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_data__mode_table_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__mode_table_0_0));
	}
Define_label(mercury____Compare___hlds_data__mode_table_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__mode_table_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__mode_table_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_data__mode_table_0_0_i3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_data__mode_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module123)
	init_entry(mercury____Unify___hlds_data__mode_defns_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__mode_defns_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_data__mode_defns_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module124)
	init_entry(mercury____Index___hlds_data__mode_defns_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__mode_defns_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_data__mode_defns_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module125)
	init_entry(mercury____Compare___hlds_data__mode_defns_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__mode_defns_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_data__common_1);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__mode_defn_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_data__mode_defns_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module126)
	init_entry(mercury____Unify___hlds_data__hlds__mode_defn_0_0);
	init_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i2);
	init_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i4);
	init_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i6);
	init_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i8);
	init_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i10);
	init_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__mode_defn_0_0);
	incr_sp_push_msg(11, "__Unify__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_data__hlds__mode_defn_0_0_i2,
		ENTRY(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_data__hlds__mode_defn_0_0_i4,
		ENTRY(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury____Unify___hlds_data__hlds__mode_body_0_0),
		mercury____Unify___hlds_data__hlds__mode_defn_0_0_i6,
		ENTRY(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___prog_data__condition_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__condition_0_0),
		mercury____Unify___hlds_data__hlds__mode_defn_0_0_i8,
		ENTRY(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury____Unify___hlds_data__hlds__mode_defn_0_0_i10,
		ENTRY(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	if (((Integer) detstackvar(5) != (Integer) detstackvar(10)))
		GOTO_LABEL(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Unify___hlds_data__hlds__mode_defn_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module127)
	init_entry(mercury____Index___hlds_data__hlds__mode_defn_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__mode_defn_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_hlds__mode_defn_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__hlds__mode_defn_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module128)
	init_entry(mercury____Compare___hlds_data__hlds__mode_defn_0_0);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i4);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i3);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i10);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i16);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i22);
	init_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__mode_defn_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_data__hlds__mode_defn_0_0_i4,
		ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i3);
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_data__hlds__mode_defn_0_0_i10,
		ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury____Compare___hlds_data__hlds__mode_body_0_0),
		mercury____Compare___hlds_data__hlds__mode_defn_0_0_i16,
		ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___prog_data__condition_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__condition_0_0),
		mercury____Compare___hlds_data__hlds__mode_defn_0_0_i22,
		ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		mercury____Compare___hlds_data__hlds__mode_defn_0_0_i28,
		ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	}
Define_label(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_data__hlds__mode_defn_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__hlds__mode_defn_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module129)
	init_entry(mercury____Unify___hlds_data__hlds__mode_body_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__hlds__mode_body_0_0);
	{
	Declare_entry(mercury____Unify___prog_data__mode_0_0);
	tailcall(ENTRY(mercury____Unify___prog_data__mode_0_0),
		ENTRY(mercury____Unify___hlds_data__hlds__mode_body_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module130)
	init_entry(mercury____Index___hlds_data__hlds__mode_body_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__hlds__mode_body_0_0);
	tailcall(STATIC(mercury____Index___hlds_data_hlds__mode_body_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_data__hlds__mode_body_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module131)
	init_entry(mercury____Compare___hlds_data__hlds__mode_body_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__hlds__mode_body_0_0);
	{
	Declare_entry(mercury____Compare___prog_data__mode_0_0);
	tailcall(ENTRY(mercury____Compare___prog_data__mode_0_0),
		ENTRY(mercury____Compare___hlds_data__hlds__mode_body_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module132)
	init_entry(mercury____Unify___hlds_data__determinism_0_0);
	init_label(mercury____Unify___hlds_data__determinism_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__determinism_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_data__determinism_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__determinism_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module133)
	init_entry(mercury____Index___hlds_data__determinism_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__determinism_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_data__determinism_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module134)
	init_entry(mercury____Compare___hlds_data__determinism_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__determinism_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__determinism_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module135)
	init_entry(mercury____Unify___hlds_data__can_fail_0_0);
	init_label(mercury____Unify___hlds_data__can_fail_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__can_fail_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_data__can_fail_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__can_fail_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module136)
	init_entry(mercury____Index___hlds_data__can_fail_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__can_fail_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_data__can_fail_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module137)
	init_entry(mercury____Compare___hlds_data__can_fail_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__can_fail_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__can_fail_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module138)
	init_entry(mercury____Unify___hlds_data__soln_count_0_0);
	init_label(mercury____Unify___hlds_data__soln_count_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_data__soln_count_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_data__soln_count_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_data__soln_count_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module139)
	init_entry(mercury____Index___hlds_data__soln_count_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_data__soln_count_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_data__soln_count_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_data_module140)
	init_entry(mercury____Compare___hlds_data__soln_count_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_data__soln_count_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_data__soln_count_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__hlds_data_bunch_0(void)
{
	mercury__hlds_data_module0();
	mercury__hlds_data_module1();
	mercury__hlds_data_module2();
	mercury__hlds_data_module3();
	mercury__hlds_data_module4();
	mercury__hlds_data_module5();
	mercury__hlds_data_module6();
	mercury__hlds_data_module7();
	mercury__hlds_data_module8();
	mercury__hlds_data_module9();
	mercury__hlds_data_module10();
	mercury__hlds_data_module11();
	mercury__hlds_data_module12();
	mercury__hlds_data_module13();
	mercury__hlds_data_module14();
	mercury__hlds_data_module15();
	mercury__hlds_data_module16();
	mercury__hlds_data_module17();
	mercury__hlds_data_module18();
	mercury__hlds_data_module19();
	mercury__hlds_data_module20();
	mercury__hlds_data_module21();
	mercury__hlds_data_module22();
	mercury__hlds_data_module23();
	mercury__hlds_data_module24();
	mercury__hlds_data_module25();
	mercury__hlds_data_module26();
	mercury__hlds_data_module27();
	mercury__hlds_data_module28();
	mercury__hlds_data_module29();
	mercury__hlds_data_module30();
	mercury__hlds_data_module31();
	mercury__hlds_data_module32();
	mercury__hlds_data_module33();
	mercury__hlds_data_module34();
	mercury__hlds_data_module35();
	mercury__hlds_data_module36();
	mercury__hlds_data_module37();
	mercury__hlds_data_module38();
	mercury__hlds_data_module39();
	mercury__hlds_data_module40();
}

static void mercury__hlds_data_bunch_1(void)
{
	mercury__hlds_data_module41();
	mercury__hlds_data_module42();
	mercury__hlds_data_module43();
	mercury__hlds_data_module44();
	mercury__hlds_data_module45();
	mercury__hlds_data_module46();
	mercury__hlds_data_module47();
	mercury__hlds_data_module48();
	mercury__hlds_data_module49();
	mercury__hlds_data_module50();
	mercury__hlds_data_module51();
	mercury__hlds_data_module52();
	mercury__hlds_data_module53();
	mercury__hlds_data_module54();
	mercury__hlds_data_module55();
	mercury__hlds_data_module56();
	mercury__hlds_data_module57();
	mercury__hlds_data_module58();
	mercury__hlds_data_module59();
	mercury__hlds_data_module60();
	mercury__hlds_data_module61();
	mercury__hlds_data_module62();
	mercury__hlds_data_module63();
	mercury__hlds_data_module64();
	mercury__hlds_data_module65();
	mercury__hlds_data_module66();
	mercury__hlds_data_module67();
	mercury__hlds_data_module68();
	mercury__hlds_data_module69();
	mercury__hlds_data_module70();
	mercury__hlds_data_module71();
	mercury__hlds_data_module72();
	mercury__hlds_data_module73();
	mercury__hlds_data_module74();
	mercury__hlds_data_module75();
	mercury__hlds_data_module76();
	mercury__hlds_data_module77();
	mercury__hlds_data_module78();
	mercury__hlds_data_module79();
	mercury__hlds_data_module80();
	mercury__hlds_data_module81();
}

static void mercury__hlds_data_bunch_2(void)
{
	mercury__hlds_data_module82();
	mercury__hlds_data_module83();
	mercury__hlds_data_module84();
	mercury__hlds_data_module85();
	mercury__hlds_data_module86();
	mercury__hlds_data_module87();
	mercury__hlds_data_module88();
	mercury__hlds_data_module89();
	mercury__hlds_data_module90();
	mercury__hlds_data_module91();
	mercury__hlds_data_module92();
	mercury__hlds_data_module93();
	mercury__hlds_data_module94();
	mercury__hlds_data_module95();
	mercury__hlds_data_module96();
	mercury__hlds_data_module97();
	mercury__hlds_data_module98();
	mercury__hlds_data_module99();
	mercury__hlds_data_module100();
	mercury__hlds_data_module101();
	mercury__hlds_data_module102();
	mercury__hlds_data_module103();
	mercury__hlds_data_module104();
	mercury__hlds_data_module105();
	mercury__hlds_data_module106();
	mercury__hlds_data_module107();
	mercury__hlds_data_module108();
	mercury__hlds_data_module109();
	mercury__hlds_data_module110();
	mercury__hlds_data_module111();
	mercury__hlds_data_module112();
	mercury__hlds_data_module113();
	mercury__hlds_data_module114();
	mercury__hlds_data_module115();
	mercury__hlds_data_module116();
	mercury__hlds_data_module117();
	mercury__hlds_data_module118();
	mercury__hlds_data_module119();
	mercury__hlds_data_module120();
	mercury__hlds_data_module121();
	mercury__hlds_data_module122();
}

static void mercury__hlds_data_bunch_3(void)
{
	mercury__hlds_data_module123();
	mercury__hlds_data_module124();
	mercury__hlds_data_module125();
	mercury__hlds_data_module126();
	mercury__hlds_data_module127();
	mercury__hlds_data_module128();
	mercury__hlds_data_module129();
	mercury__hlds_data_module130();
	mercury__hlds_data_module131();
	mercury__hlds_data_module132();
	mercury__hlds_data_module133();
	mercury__hlds_data_module134();
	mercury__hlds_data_module135();
	mercury__hlds_data_module136();
	mercury__hlds_data_module137();
	mercury__hlds_data_module138();
	mercury__hlds_data_module139();
	mercury__hlds_data_module140();
}

#endif

void mercury__hlds_data__init(void); /* suppress gcc warning */
void mercury__hlds_data__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__hlds_data_bunch_0();
	mercury__hlds_data_bunch_1();
	mercury__hlds_data_bunch_2();
	mercury__hlds_data_bunch_3();
#endif
}
