/*
** Automatically generated from `code_aux.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__code_aux__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__code_aux__contains_only_builtins_1_0);
Define_extern_entry(mercury__code_aux__goal_is_flat_1_0);
Define_extern_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
Declare_label(mercury__code_aux__contains_simple_recursive_call_3_0_i3);
Declare_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1003);
Declare_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1005);
Define_extern_entry(mercury__code_aux__pre_goal_update_4_0);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i2);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i5);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i4);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i3);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i6);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i9);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i8);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i7);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i10);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i11);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i12);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i13);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i14);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i18);
Declare_label(mercury__code_aux__pre_goal_update_4_0_i20);
Define_extern_entry(mercury__code_aux__post_goal_update_3_0);
Declare_label(mercury__code_aux__post_goal_update_3_0_i2);
Declare_label(mercury__code_aux__post_goal_update_3_0_i3);
Declare_label(mercury__code_aux__post_goal_update_3_0_i4);
Declare_label(mercury__code_aux__post_goal_update_3_0_i5);
Declare_label(mercury__code_aux__post_goal_update_3_0_i6);
Declare_label(mercury__code_aux__post_goal_update_3_0_i7);
Declare_label(mercury__code_aux__post_goal_update_3_0_i8);
Define_extern_entry(mercury__code_aux__explain_stack_slots_3_0);
Declare_label(mercury__code_aux__explain_stack_slots_3_0_i2);
Declare_label(mercury__code_aux__explain_stack_slots_3_0_i3);
Define_extern_entry(mercury__code_aux__lookup_type_defn_4_0);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i2);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i5);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i4);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i7);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i8);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i9);
Declare_label(mercury__code_aux__lookup_type_defn_4_0_i10);
Declare_static(mercury__code_aux__contains_only_builtins_2_1_0);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1027);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1026);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i8);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i11);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i9);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i25);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i26);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i28);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1025);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i32);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1017);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1018);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1020);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1021);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1024);
Declare_static(mercury__code_aux__contains_only_builtins_cases_1_0);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i4);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1003);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
Declare_static(mercury__code_aux__contains_only_builtins_list_1_0);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i4);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i1003);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i1);
Declare_static(mercury__code_aux__goal_is_flat_2_1_0);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1016);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i13);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1006);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i2);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1005);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1010);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1011);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1015);
Declare_static(mercury__code_aux__goal_is_flat_list_1_0);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i4);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i1003);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i1);
Declare_static(mercury__code_aux__contains_simple_recursive_call_2_3_0);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i5);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i7);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i4);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i12);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i14);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i15);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i16);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i19);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1010);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1011);
Declare_static(mercury__code_aux__explain_stack_slots_2_4_0);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i4);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i7);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i6);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i9);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i10);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i1007);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_code_aux__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

BEGIN_MODULE(mercury__code_aux_module0)
	init_entry(mercury__code_aux__contains_only_builtins_1_0);
BEGIN_CODE

/* code for predicate 'code_aux__contains_only_builtins'/1 in mode 0 */
Define_entry(mercury__code_aux__contains_only_builtins_1_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_2_1_0),
		ENTRY(mercury__code_aux__contains_only_builtins_1_0));
END_MODULE

BEGIN_MODULE(mercury__code_aux_module1)
	init_entry(mercury__code_aux__goal_is_flat_1_0);
BEGIN_CODE

/* code for predicate 'code_aux__goal_is_flat'/1 in mode 0 */
Define_entry(mercury__code_aux__goal_is_flat_1_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__code_aux__goal_is_flat_2_1_0),
		ENTRY(mercury__code_aux__goal_is_flat_1_0));
END_MODULE

BEGIN_MODULE(mercury__code_aux_module2)
	init_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	init_label(mercury__code_aux__contains_simple_recursive_call_3_0_i3);
	init_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1003);
	init_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1005);
BEGIN_CODE

/* code for predicate 'code_aux__contains_simple_recursive_call'/3 in mode 0 */
Define_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_3_0_i1003);
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	incr_sp_push_msg(1, "code_aux__contains_simple_recursive_call");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0),
		mercury__code_aux__contains_simple_recursive_call_3_0_i3,
		ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_3_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1003);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1005);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module3)
	init_entry(mercury__code_aux__pre_goal_update_4_0);
	init_label(mercury__code_aux__pre_goal_update_4_0_i2);
	init_label(mercury__code_aux__pre_goal_update_4_0_i5);
	init_label(mercury__code_aux__pre_goal_update_4_0_i4);
	init_label(mercury__code_aux__pre_goal_update_4_0_i3);
	init_label(mercury__code_aux__pre_goal_update_4_0_i6);
	init_label(mercury__code_aux__pre_goal_update_4_0_i9);
	init_label(mercury__code_aux__pre_goal_update_4_0_i8);
	init_label(mercury__code_aux__pre_goal_update_4_0_i7);
	init_label(mercury__code_aux__pre_goal_update_4_0_i10);
	init_label(mercury__code_aux__pre_goal_update_4_0_i11);
	init_label(mercury__code_aux__pre_goal_update_4_0_i12);
	init_label(mercury__code_aux__pre_goal_update_4_0_i13);
	init_label(mercury__code_aux__pre_goal_update_4_0_i14);
	init_label(mercury__code_aux__pre_goal_update_4_0_i18);
	init_label(mercury__code_aux__pre_goal_update_4_0_i20);
BEGIN_CODE

/* code for predicate 'code_aux__pre_goal_update'/4 in mode 0 */
Define_entry(mercury__code_aux__pre_goal_update_4_0);
	incr_sp_push_msg(5, "code_aux__pre_goal_update");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__code_aux__pre_goal_update_4_0_i2,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__pre_goal_update_4_0_i4);
	r1 = string_const("pre_goal_update with resume point", 33);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_aux__pre_goal_update_4_0_i5,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__code_aux__pre_goal_update_4_0_i3);
Define_label(mercury__code_aux__pre_goal_update_4_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__code_aux__pre_goal_update_4_0_i3);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_follow_vars_2_0),
		mercury__code_aux__pre_goal_update_4_0_i6,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i6);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__pre_goal_update_4_0_i8);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__set_follow_vars_3_0);
	call_localret(ENTRY(mercury__code_info__set_follow_vars_3_0),
		mercury__code_aux__pre_goal_update_4_0_i9,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__code_aux__pre_goal_update_4_0_i7);
Define_label(mercury__code_aux__pre_goal_update_4_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__code_aux__pre_goal_update_4_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_births_2_0),
		mercury__code_aux__pre_goal_update_4_0_i10,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_deaths_2_0),
		mercury__code_aux__pre_goal_update_4_0_i11,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i11);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__update_liveness_info_3_0);
	call_localret(ENTRY(mercury__code_info__update_liveness_info_3_0),
		mercury__code_aux__pre_goal_update_4_0_i12,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i12);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__update_deadness_info_3_0);
	call_localret(ENTRY(mercury__code_info__update_deadness_info_3_0),
		mercury__code_aux__pre_goal_update_4_0_i13,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i13);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__code_aux__pre_goal_update_4_0_i14,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i14);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_aux__pre_goal_update_4_0_i20);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_deaths_2_0),
		mercury__code_aux__pre_goal_update_4_0_i18,
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i18);
	update_prof_current_proc(LABEL(mercury__code_aux__pre_goal_update_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__code_info__update_deadness_info_3_0);
	tailcall(ENTRY(mercury__code_info__update_deadness_info_3_0),
		ENTRY(mercury__code_aux__pre_goal_update_4_0));
	}
Define_label(mercury__code_aux__pre_goal_update_4_0_i20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module4)
	init_entry(mercury__code_aux__post_goal_update_3_0);
	init_label(mercury__code_aux__post_goal_update_3_0_i2);
	init_label(mercury__code_aux__post_goal_update_3_0_i3);
	init_label(mercury__code_aux__post_goal_update_3_0_i4);
	init_label(mercury__code_aux__post_goal_update_3_0_i5);
	init_label(mercury__code_aux__post_goal_update_3_0_i6);
	init_label(mercury__code_aux__post_goal_update_3_0_i7);
	init_label(mercury__code_aux__post_goal_update_3_0_i8);
BEGIN_CODE

/* code for predicate 'code_aux__post_goal_update'/3 in mode 0 */
Define_entry(mercury__code_aux__post_goal_update_3_0);
	incr_sp_push_msg(4, "code_aux__post_goal_update");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_births_2_0),
		mercury__code_aux__post_goal_update_3_0_i2,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_deaths_2_0),
		mercury__code_aux__post_goal_update_3_0_i3,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__update_liveness_info_3_0);
	call_localret(ENTRY(mercury__code_info__update_liveness_info_3_0),
		mercury__code_aux__post_goal_update_3_0_i4,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__update_deadness_info_3_0);
	call_localret(ENTRY(mercury__code_info__update_deadness_info_3_0),
		mercury__code_aux__post_goal_update_3_0_i5,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i5);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__code_aux__post_goal_update_3_0_i6,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i6);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__make_vars_live_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_live_3_0),
		mercury__code_aux__post_goal_update_3_0_i7,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i7);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__code_aux__post_goal_update_3_0_i8,
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
Define_label(mercury__code_aux__post_goal_update_3_0_i8);
	update_prof_current_proc(LABEL(mercury__code_aux__post_goal_update_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__code_info__apply_instmap_delta_3_0);
	tailcall(ENTRY(mercury__code_info__apply_instmap_delta_3_0),
		ENTRY(mercury__code_aux__post_goal_update_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__code_aux_module5)
	init_entry(mercury__code_aux__explain_stack_slots_3_0);
	init_label(mercury__code_aux__explain_stack_slots_3_0_i2);
	init_label(mercury__code_aux__explain_stack_slots_3_0_i3);
BEGIN_CODE

/* code for predicate 'code_aux__explain_stack_slots'/3 in mode 0 */
Define_entry(mercury__code_aux__explain_stack_slots_3_0);
	incr_sp_push_msg(2, "code_aux__explain_stack_slots");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__code_aux__explain_stack_slots_3_0_i2,
		ENTRY(mercury__code_aux__explain_stack_slots_3_0));
	}
Define_label(mercury__code_aux__explain_stack_slots_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = string_const("", 0);
	call_localret(STATIC(mercury__code_aux__explain_stack_slots_2_4_0),
		mercury__code_aux__explain_stack_slots_3_0_i3,
		ENTRY(mercury__code_aux__explain_stack_slots_3_0));
Define_label(mercury__code_aux__explain_stack_slots_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\nStack slot assignments (if any):\n", 34);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__code_aux__explain_stack_slots_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__code_aux_module6)
	init_entry(mercury__code_aux__lookup_type_defn_4_0);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i2);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i5);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i4);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i7);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i8);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i9);
	init_label(mercury__code_aux__lookup_type_defn_4_0_i10);
BEGIN_CODE

/* code for predicate 'code_aux__lookup_type_defn'/4 in mode 0 */
Define_entry(mercury__code_aux__lookup_type_defn_4_0);
	incr_sp_push_msg(4, "code_aux__lookup_type_defn");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__code_aux__lookup_type_defn_4_0_i2,
		ENTRY(mercury__code_aux__lookup_type_defn_4_0));
	}
Define_label(mercury__code_aux__lookup_type_defn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_aux__lookup_type_defn_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__code_aux__lookup_type_defn_4_0_i5,
		ENTRY(mercury__code_aux__lookup_type_defn_4_0));
	}
Define_label(mercury__code_aux__lookup_type_defn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_aux__lookup_type_defn_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__lookup_type_defn_4_0_i4);
	r3 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__code_aux__lookup_type_defn_4_0_i8);
Define_label(mercury__code_aux__lookup_type_defn_4_0_i4);
	r1 = string_const("unknown type in code_aux__lookup_type_defn", 42);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_aux__lookup_type_defn_4_0_i7,
		ENTRY(mercury__code_aux__lookup_type_defn_4_0));
	}
Define_label(mercury__code_aux__lookup_type_defn_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_aux__lookup_type_defn_4_0));
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__code_aux__lookup_type_defn_4_0_i8);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__code_aux__lookup_type_defn_4_0_i9,
		ENTRY(mercury__code_aux__lookup_type_defn_4_0));
	}
Define_label(mercury__code_aux__lookup_type_defn_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_aux__lookup_type_defn_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_code_aux__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_aux__lookup_type_defn_4_0_i10,
		ENTRY(mercury__code_aux__lookup_type_defn_4_0));
	}
Define_label(mercury__code_aux__lookup_type_defn_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_aux__lookup_type_defn_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module7)
	init_entry(mercury__code_aux__contains_only_builtins_2_1_0);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1027);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1026);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i8);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i11);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i9);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i25);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i26);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i28);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1025);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i32);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1017);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1018);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1020);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1021);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1024);
BEGIN_CODE

/* code for predicate 'code_aux__contains_only_builtins_2'/1 in mode 0 */
Define_static(mercury__code_aux__contains_only_builtins_2_1_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1025);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1018) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1027) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1020) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1021) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1022) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1026) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1017));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1027);
	incr_sp_push_msg(3, "code_aux__contains_only_builtins_2");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i8);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1026);
	incr_sp_push_msg(3, "code_aux__contains_only_builtins_2");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i25);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i8);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r3 = tag((Integer) r2);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i11);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1024);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i11);
	if (((Integer) r3 == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i9);
	if (((Integer) r3 == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i9);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i9);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i25);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		call_localret(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		mercury__code_aux__contains_only_builtins_2_1_0_i26,
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i26);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_2_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1);
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		mercury__code_aux__contains_only_builtins_2_1_0_i28,
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i28);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_2_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1025);
	incr_sp_push_msg(3, "code_aux__contains_only_builtins_2");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i32);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_list_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i32);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1024);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	tailcall(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1017);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1018);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_cases_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1020);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_list_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1021);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		tailcall(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1024);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module8)
	init_entry(mercury__code_aux__contains_only_builtins_cases_1_0);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i4);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1003);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
BEGIN_CODE

/* code for predicate 'code_aux__contains_only_builtins_cases'/1 in mode 0 */
Define_static(mercury__code_aux__contains_only_builtins_cases_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_cases_1_0_i1003);
	incr_sp_push_msg(2, "code_aux__contains_only_builtins_cases");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	{
		call_localret(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		mercury__code_aux__contains_only_builtins_cases_1_0_i4,
		STATIC(mercury__code_aux__contains_only_builtins_cases_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_cases_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_aux__contains_only_builtins_cases_1_0,
		STATIC(mercury__code_aux__contains_only_builtins_cases_1_0));
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module9)
	init_entry(mercury__code_aux__contains_only_builtins_list_1_0);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i4);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i1003);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i1);
BEGIN_CODE

/* code for predicate 'code_aux__contains_only_builtins_list'/1 in mode 0 */
Define_static(mercury__code_aux__contains_only_builtins_list_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_list_1_0_i1003);
	incr_sp_push_msg(2, "code_aux__contains_only_builtins_list");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__code_aux__contains_only_builtins_1_0),
		mercury__code_aux__contains_only_builtins_list_1_0_i4,
		STATIC(mercury__code_aux__contains_only_builtins_list_1_0));
	}
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_list_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_list_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_aux__contains_only_builtins_list_1_0,
		STATIC(mercury__code_aux__contains_only_builtins_list_1_0));
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module10)
	init_entry(mercury__code_aux__goal_is_flat_2_1_0);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1016);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i13);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1006);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i2);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1005);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1010);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1011);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1015);
BEGIN_CODE

/* code for predicate 'code_aux__goal_is_flat_2'/1 in mode 0 */
Define_static(mercury__code_aux__goal_is_flat_2_1_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1016);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1005) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1006) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1005) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1010) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1011) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1005) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1006));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1016);
	incr_sp_push_msg(1, "code_aux__goal_is_flat_2");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_2_1_0_i13);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__code_aux__goal_is_flat_list_1_0),
		STATIC(mercury__code_aux__goal_is_flat_2_1_0));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i13);
	if (((Integer) r2 == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_2_1_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1015);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1010);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__code_aux__goal_is_flat_1_0),
		STATIC(mercury__code_aux__goal_is_flat_2_1_0));
	}
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1011);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		tailcall(STATIC(mercury__code_aux__goal_is_flat_1_0),
		STATIC(mercury__code_aux__goal_is_flat_2_1_0));
	}
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1015);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module11)
	init_entry(mercury__code_aux__goal_is_flat_list_1_0);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i4);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i1003);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i1);
BEGIN_CODE

/* code for predicate 'code_aux__goal_is_flat_list'/1 in mode 0 */
Define_static(mercury__code_aux__goal_is_flat_list_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_list_1_0_i1003);
	incr_sp_push_msg(2, "code_aux__goal_is_flat_list");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__code_aux__goal_is_flat_1_0),
		mercury__code_aux__goal_is_flat_list_1_0_i4,
		STATIC(mercury__code_aux__goal_is_flat_list_1_0));
	}
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_is_flat_list_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_list_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_aux__goal_is_flat_list_1_0,
		STATIC(mercury__code_aux__goal_is_flat_list_1_0));
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module12)
	init_entry(mercury__code_aux__contains_simple_recursive_call_2_3_0);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i5);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i7);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i4);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i12);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i14);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i15);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i16);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i19);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1010);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1011);
BEGIN_CODE

/* code for predicate 'code_aux__contains_simple_recursive_call_2'/3 in mode 0 */
Define_static(mercury__code_aux__contains_simple_recursive_call_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1010);
	incr_sp_push_msg(5, "code_aux__contains_simple_recursive_call_2");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__code_aux__contains_only_builtins_2_1_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i5,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i4);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__code_aux__contains_simple_recursive_call_2_3_0,
		LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i7),
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1011);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i4);
	r2 = (Integer) detstackvar(3);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i12,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	}
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i12);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__get_pred_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i14,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	}
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i14);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (((Integer) r1 != (Integer) detstackvar(3)))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__get_proc_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i15,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	}
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i15);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (((Integer) r1 != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i16);
	r1 = TRUE;
	r2 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i16);
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__code_aux__contains_only_builtins_list_1_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i19,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i19);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r2 = ((Integer) 1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1011);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_aux_module13)
	init_entry(mercury__code_aux__explain_stack_slots_2_4_0);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i4);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i7);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i6);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i9);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i10);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i1007);
BEGIN_CODE

/* code for predicate 'code_aux__explain_stack_slots_2'/4 in mode 0 */
Define_static(mercury__code_aux__explain_stack_slots_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i1007);
	incr_sp_push_msg(5, "code_aux__explain_stack_slots_2");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__code_aux__explain_stack_slots_2_4_0,
		LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i4),
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
	}
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_2_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__llds_out__lval_to_string_2_0);
	call_localret(ENTRY(mercury__llds_out__lval_to_string_2_0),
		mercury__code_aux__explain_stack_slots_2_4_0_i7,
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
	}
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i6);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i9);
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = string_const("some lval", 9);
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i9);
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__varset__lookup_name_3_0);
	call_localret(ENTRY(mercury__varset__lookup_name_3_0),
		mercury__code_aux__explain_stack_slots_2_4_0_i10,
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
	}
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("\t ->\t", 5);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
	}
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i1007);
	r1 = (Integer) r3;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__code_aux_bunch_0(void)
{
	mercury__code_aux_module0();
	mercury__code_aux_module1();
	mercury__code_aux_module2();
	mercury__code_aux_module3();
	mercury__code_aux_module4();
	mercury__code_aux_module5();
	mercury__code_aux_module6();
	mercury__code_aux_module7();
	mercury__code_aux_module8();
	mercury__code_aux_module9();
	mercury__code_aux_module10();
	mercury__code_aux_module11();
	mercury__code_aux_module12();
	mercury__code_aux_module13();
}

#endif

void mercury__code_aux__init(void); /* suppress gcc warning */
void mercury__code_aux__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__code_aux_bunch_0();
#endif
}
