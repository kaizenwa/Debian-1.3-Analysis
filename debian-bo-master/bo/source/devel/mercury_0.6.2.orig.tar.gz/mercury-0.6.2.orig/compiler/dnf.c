/*
** Automatically generated from `dnf.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__dnf__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__dnf__transform_module_4_0);
Declare_label(mercury__dnf__transform_module_4_0_i2);
Define_extern_entry(mercury__dnf__transform_proc_8_0);
Declare_label(mercury__dnf__transform_proc_8_0_i2);
Declare_label(mercury__dnf__transform_proc_8_0_i3);
Declare_label(mercury__dnf__transform_proc_8_0_i4);
Declare_label(mercury__dnf__transform_proc_8_0_i5);
Declare_label(mercury__dnf__transform_proc_8_0_i6);
Declare_label(mercury__dnf__transform_proc_8_0_i7);
Declare_label(mercury__dnf__transform_proc_8_0_i8);
Declare_label(mercury__dnf__transform_proc_8_0_i9);
Declare_label(mercury__dnf__transform_proc_8_0_i10);
Declare_static(mercury__dnf__transform_preds_5_0);
Declare_label(mercury__dnf__transform_preds_5_0_i1006);
Declare_label(mercury__dnf__transform_preds_5_0_i10);
Declare_label(mercury__dnf__transform_preds_5_0_i11);
Declare_label(mercury__dnf__transform_preds_5_0_i12);
Declare_label(mercury__dnf__transform_preds_5_0_i13);
Declare_label(mercury__dnf__transform_preds_5_0_i6);
Declare_label(mercury__dnf__transform_preds_5_0_i15);
Declare_label(mercury__dnf__transform_preds_5_0_i16);
Declare_label(mercury__dnf__transform_preds_5_0_i17);
Declare_label(mercury__dnf__transform_preds_5_0_i18);
Declare_label(mercury__dnf__transform_preds_5_0_i19);
Declare_label(mercury__dnf__transform_preds_5_0_i20);
Declare_label(mercury__dnf__transform_preds_5_0_i21);
Declare_label(mercury__dnf__transform_preds_5_0_i22);
Declare_label(mercury__dnf__transform_preds_5_0_i23);
Declare_label(mercury__dnf__transform_preds_5_0_i24);
Declare_label(mercury__dnf__transform_preds_5_0_i25);
Declare_label(mercury__dnf__transform_preds_5_0_i26);
Declare_label(mercury__dnf__transform_preds_5_0_i5);
Declare_label(mercury__dnf__transform_preds_5_0_i1004);
Declare_static(mercury__dnf__transform_procs_7_0);
Declare_label(mercury__dnf__transform_procs_7_0_i4);
Declare_label(mercury__dnf__transform_procs_7_0_i5);
Declare_label(mercury__dnf__transform_procs_7_0_i6);
Declare_label(mercury__dnf__transform_procs_7_0_i7);
Declare_label(mercury__dnf__transform_procs_7_0_i8);
Declare_label(mercury__dnf__transform_procs_7_0_i9);
Declare_label(mercury__dnf__transform_procs_7_0_i10);
Declare_label(mercury__dnf__transform_procs_7_0_i11);
Declare_label(mercury__dnf__transform_procs_7_0_i12);
Declare_label(mercury__dnf__transform_procs_7_0_i13);
Declare_label(mercury__dnf__transform_procs_7_0_i14);
Declare_label(mercury__dnf__transform_procs_7_0_i1002);
Declare_static(mercury__dnf__transform_goal_10_0);
Declare_label(mercury__dnf__transform_goal_10_0_i1019);
Declare_label(mercury__dnf__transform_goal_10_0_i1018);
Declare_label(mercury__dnf__transform_goal_10_0_i1017);
Declare_label(mercury__dnf__transform_goal_10_0_i1015);
Declare_label(mercury__dnf__transform_goal_10_0_i5);
Declare_label(mercury__dnf__transform_goal_10_0_i6);
Declare_label(mercury__dnf__transform_goal_10_0_i8);
Declare_label(mercury__dnf__transform_goal_10_0_i9);
Declare_label(mercury__dnf__transform_goal_10_0_i10);
Declare_label(mercury__dnf__transform_goal_10_0_i1011);
Declare_label(mercury__dnf__transform_goal_10_0_i14);
Declare_label(mercury__dnf__transform_goal_10_0_i15);
Declare_label(mercury__dnf__transform_goal_10_0_i1014);
Declare_label(mercury__dnf__transform_goal_10_0_i17);
Declare_label(mercury__dnf__transform_goal_10_0_i1012);
Declare_label(mercury__dnf__transform_goal_10_0_i1013);
Declare_static(mercury__dnf__transform_disj_11_0);
Declare_label(mercury__dnf__transform_disj_11_0_i4);
Declare_label(mercury__dnf__transform_disj_11_0_i5);
Declare_label(mercury__dnf__transform_disj_11_0_i6);
Declare_label(mercury__dnf__transform_disj_11_0_i7);
Declare_label(mercury__dnf__transform_disj_11_0_i1002);
Declare_static(mercury__dnf__transform_switch_11_0);
Declare_label(mercury__dnf__transform_switch_11_0_i4);
Declare_label(mercury__dnf__transform_switch_11_0_i5);
Declare_label(mercury__dnf__transform_switch_11_0_i6);
Declare_label(mercury__dnf__transform_switch_11_0_i7);
Declare_label(mercury__dnf__transform_switch_11_0_i1003);
Declare_static(mercury__dnf__transform_ite_15_0);
Declare_label(mercury__dnf__transform_ite_15_0_i2);
Declare_label(mercury__dnf__transform_ite_15_0_i3);
Declare_label(mercury__dnf__transform_ite_15_0_i4);
Declare_label(mercury__dnf__transform_ite_15_0_i5);
Declare_label(mercury__dnf__transform_ite_15_0_i6);
Declare_label(mercury__dnf__transform_ite_15_0_i7);
Declare_label(mercury__dnf__transform_ite_15_0_i8);
Declare_label(mercury__dnf__transform_ite_15_0_i9);
Declare_label(mercury__dnf__transform_ite_15_0_i10);
Declare_static(mercury__dnf__transform_conj_12_0);
Declare_label(mercury__dnf__transform_conj_12_0_i4);
Declare_label(mercury__dnf__transform_conj_12_0_i5);
Declare_label(mercury__dnf__transform_conj_12_0_i6);
Declare_label(mercury__dnf__transform_conj_12_0_i7);
Declare_label(mercury__dnf__transform_conj_12_0_i1002);
Declare_static(mercury__dnf__make_goal_literal_12_0);
Declare_label(mercury__dnf__make_goal_literal_12_0_i7);
Declare_label(mercury__dnf__make_goal_literal_12_0_i1000);
Declare_label(mercury__dnf__make_goal_literal_12_0_i4);
Declare_label(mercury__dnf__make_goal_literal_12_0_i3);
Declare_label(mercury__dnf__make_goal_literal_12_0_i12);
Declare_label(mercury__dnf__make_goal_literal_12_0_i13);
Declare_label(mercury__dnf__make_goal_literal_12_0_i14);
Declare_label(mercury__dnf__make_goal_literal_12_0_i15);
Declare_label(mercury__dnf__make_goal_literal_12_0_i16);
Declare_label(mercury__dnf__make_goal_literal_12_0_i17);
Declare_label(mercury__dnf__make_goal_literal_12_0_i18);
Declare_label(mercury__dnf__make_goal_literal_12_0_i19);
Declare_label(mercury__dnf__make_goal_literal_12_0_i20);
Declare_label(mercury__dnf__make_goal_literal_12_0_i21);
Declare_label(mercury__dnf__make_goal_literal_12_0_i22);
Declare_label(mercury__dnf__make_goal_literal_12_0_i23);
Declare_label(mercury__dnf__make_goal_literal_12_0_i24);
Declare_label(mercury__dnf__make_goal_literal_12_0_i25);
Declare_label(mercury__dnf__make_goal_literal_12_0_i26);
Declare_label(mercury__dnf__make_goal_literal_12_0_i27);
Declare_label(mercury__dnf__make_goal_literal_12_0_i28);
Declare_static(mercury__dnf__get_new_pred_name_5_0);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i2);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i3);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i6);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i5);
Declare_static(mercury__dnf__compute_arg_types_modes_6_0);
Declare_label(mercury__dnf__compute_arg_types_modes_6_0_i4);
Declare_label(mercury__dnf__compute_arg_types_modes_6_0_i5);
Declare_label(mercury__dnf__compute_arg_types_modes_6_0_i6);
Declare_label(mercury__dnf__compute_arg_types_modes_6_0_i7);
Declare_label(mercury__dnf__compute_arg_types_modes_6_0_i1004);
Declare_static(mercury__dnf__is_considered_atomic_expr_2_0);
Declare_label(mercury__dnf__is_considered_atomic_expr_2_0_i5);
Declare_label(mercury__dnf__is_considered_atomic_expr_2_0_i2);
Declare_label(mercury__dnf__is_considered_atomic_expr_2_0_i1);
Declare_static(mercury__dnf__is_atomic_expr_2_0);
Declare_label(mercury__dnf__is_atomic_expr_2_0_i1005);
Declare_label(mercury__dnf__is_atomic_expr_2_0_i1006);
Declare_label(mercury__dnf__is_atomic_expr_2_0_i1014);
Declare_label(mercury__dnf__is_atomic_expr_2_0_i13);
Declare_label(mercury__dnf__is_atomic_expr_2_0_i1012);
Declare_label(mercury__dnf__is_atomic_expr_2_0_i1013);
Declare_static(mercury__dnf__expr_free_of_nonatomic_2_0);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1020);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i18);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i19);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i21);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1019);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i26);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i32);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1009);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1013);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1014);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1015);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1016);
Declare_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1018);
Declare_static(mercury__dnf__goal_free_of_nonatomic_2_0);
Declare_static(mercury__dnf__goals_free_of_nonatomic_2_0);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i4);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1003);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
Declare_static(mercury__dnf__cases_free_of_nonatomic_2_0);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i4);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1003);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_dnf__base_type_layout_dnf_info_0[];
Word * mercury_data_dnf__base_type_info_dnf_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_dnf__base_type_layout_dnf_info_0
};

extern Word * mercury_data_dnf__common_4[];
Word * mercury_data_dnf__base_type_layout_dnf_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_dnf__common_4),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word mercury_data_dnf__common_0[] = {
	((Integer) 4)
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_dnf__common_1[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_dnf__common_2[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_hlds_pred__base_type_info_marker_status_0[];
Word * mercury_data_dnf__common_3[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0
};

Word * mercury_data_dnf__common_4[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_dnf__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_dnf__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_dnf__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_dnf__common_3),
	(Word *) string_const("dnf_info", 8)
};

BEGIN_MODULE(mercury__dnf_module0)
	init_entry(mercury__dnf__transform_module_4_0);
	init_label(mercury__dnf__transform_module_4_0_i2);
BEGIN_CODE

/* code for predicate 'dnf__transform_module'/4 in mode 0 */
Define_entry(mercury__dnf__transform_module_4_0);
	incr_sp_push_msg(4, "dnf__transform_module");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__dnf__transform_module_4_0_i2,
		ENTRY(mercury__dnf__transform_module_4_0));
	}
Define_label(mercury__dnf__transform_module_4_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__transform_module_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__dnf__transform_preds_5_0),
		ENTRY(mercury__dnf__transform_module_4_0));
END_MODULE

BEGIN_MODULE(mercury__dnf_module1)
	init_entry(mercury__dnf__transform_proc_8_0);
	init_label(mercury__dnf__transform_proc_8_0_i2);
	init_label(mercury__dnf__transform_proc_8_0_i3);
	init_label(mercury__dnf__transform_proc_8_0_i4);
	init_label(mercury__dnf__transform_proc_8_0_i5);
	init_label(mercury__dnf__transform_proc_8_0_i6);
	init_label(mercury__dnf__transform_proc_8_0_i7);
	init_label(mercury__dnf__transform_proc_8_0_i8);
	init_label(mercury__dnf__transform_proc_8_0_i9);
	init_label(mercury__dnf__transform_proc_8_0_i10);
BEGIN_CODE

/* code for predicate 'dnf__transform_proc'/8 in mode 0 */
Define_entry(mercury__dnf__transform_proc_8_0);
	incr_sp_push_msg(10, "dnf__transform_proc");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__dnf__transform_proc_8_0_i2,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__dnf__transform_proc_8_0_i3,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__dnf__transform_proc_8_0_i4,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__dnf__transform_proc_8_0_i5,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__dnf__transform_proc_8_0_i6,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__dnf__transform_proc_8_0_i7,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__dnf__transform_proc_8_0_i8,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i8);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__dnf__transform_goal_10_0),
		mercury__dnf__transform_proc_8_0_i9,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__dnf__transform_proc_8_0_i10,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
	}
Define_label(mercury__dnf__transform_proc_8_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module2)
	init_entry(mercury__dnf__transform_preds_5_0);
	init_label(mercury__dnf__transform_preds_5_0_i1006);
	init_label(mercury__dnf__transform_preds_5_0_i10);
	init_label(mercury__dnf__transform_preds_5_0_i11);
	init_label(mercury__dnf__transform_preds_5_0_i12);
	init_label(mercury__dnf__transform_preds_5_0_i13);
	init_label(mercury__dnf__transform_preds_5_0_i6);
	init_label(mercury__dnf__transform_preds_5_0_i15);
	init_label(mercury__dnf__transform_preds_5_0_i16);
	init_label(mercury__dnf__transform_preds_5_0_i17);
	init_label(mercury__dnf__transform_preds_5_0_i18);
	init_label(mercury__dnf__transform_preds_5_0_i19);
	init_label(mercury__dnf__transform_preds_5_0_i20);
	init_label(mercury__dnf__transform_preds_5_0_i21);
	init_label(mercury__dnf__transform_preds_5_0_i22);
	init_label(mercury__dnf__transform_preds_5_0_i23);
	init_label(mercury__dnf__transform_preds_5_0_i24);
	init_label(mercury__dnf__transform_preds_5_0_i25);
	init_label(mercury__dnf__transform_preds_5_0_i26);
	init_label(mercury__dnf__transform_preds_5_0_i5);
	init_label(mercury__dnf__transform_preds_5_0_i1004);
BEGIN_CODE

/* code for predicate 'dnf__transform_preds'/5 in mode 0 */
Define_static(mercury__dnf__transform_preds_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i1004);
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i1006);
	r1 = (Integer) r4;
	r4 = (Integer) r6;
	incr_sp_push_msg(10, "dnf__transform_preds");
	detstackvar(10) = (Integer) succip;
	GOTO_LABEL(mercury__dnf__transform_preds_5_0_i6);
Define_label(mercury__dnf__transform_preds_5_0_i1006);
	incr_sp_push_msg(10, "dnf__transform_preds");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_preds_5_0_i10,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dnf__transform_preds_5_0_i11,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__dnf__transform_preds_5_0_i12,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i12);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_dnf__common_0);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__dnf__transform_preds_5_0_i13,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__dnf__transform_preds_5_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_preds_5_0_i15,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i15);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dnf__transform_preds_5_0_i16,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i16);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__dnf__transform_preds_5_0_i17,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i17);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__dnf__transform_procs_7_0),
		mercury__dnf__transform_preds_5_0_i18,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i18);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	detstackvar(6) = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_preds_5_0_i19,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i19);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r3 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dnf__transform_preds_5_0_i20,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i20);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	detstackvar(9) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__dnf__transform_preds_5_0_i21,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i21);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_dnf__common_0);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__dnf__transform_preds_5_0_i22,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i22);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_dnf__common_0);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_marker_list_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_marker_list_3_0),
		mercury__dnf__transform_preds_5_0_i23,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i23);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dnf__transform_preds_5_0_i24,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i24);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__dnf__transform_preds_5_0_i25,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i25);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__dnf__transform_preds_5_0_i26,
		STATIC(mercury__dnf__transform_preds_5_0));
	}
Define_label(mercury__dnf__transform_preds_5_0_i26);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__dnf__transform_preds_5_0,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__dnf__transform_preds_5_0,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i1004);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module3)
	init_entry(mercury__dnf__transform_procs_7_0);
	init_label(mercury__dnf__transform_procs_7_0_i4);
	init_label(mercury__dnf__transform_procs_7_0_i5);
	init_label(mercury__dnf__transform_procs_7_0_i6);
	init_label(mercury__dnf__transform_procs_7_0_i7);
	init_label(mercury__dnf__transform_procs_7_0_i8);
	init_label(mercury__dnf__transform_procs_7_0_i9);
	init_label(mercury__dnf__transform_procs_7_0_i10);
	init_label(mercury__dnf__transform_procs_7_0_i11);
	init_label(mercury__dnf__transform_procs_7_0_i12);
	init_label(mercury__dnf__transform_procs_7_0_i13);
	init_label(mercury__dnf__transform_procs_7_0_i14);
	init_label(mercury__dnf__transform_procs_7_0_i1002);
BEGIN_CODE

/* code for predicate 'dnf__transform_procs'/7 in mode 0 */
Define_static(mercury__dnf__transform_procs_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__transform_procs_7_0_i1002);
	incr_sp_push_msg(9, "dnf__transform_procs");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_procs_7_0_i4,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dnf__transform_procs_7_0_i5,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__dnf__transform_procs_7_0_i6,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r3 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dnf__transform_procs_7_0_i7,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__excess__excess_assignments_proc_3_0);
	call_localret(ENTRY(mercury__excess__excess_assignments_proc_3_0),
		mercury__dnf__transform_procs_7_0_i8,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i8);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__dnf__transform_proc_8_0),
		mercury__dnf__transform_procs_7_0_i9,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r3;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r5 = (Integer) r2;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dnf__transform_procs_7_0_i10,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__dnf__transform_procs_7_0_i11,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_procs_7_0_i12,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i12);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dnf__transform_procs_7_0_i13,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__dnf__transform_procs_7_0_i14,
		STATIC(mercury__dnf__transform_procs_7_0));
	}
Define_label(mercury__dnf__transform_procs_7_0_i14);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__dnf__transform_procs_7_0,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i1002);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module4)
	init_entry(mercury__dnf__transform_goal_10_0);
	init_label(mercury__dnf__transform_goal_10_0_i1019);
	init_label(mercury__dnf__transform_goal_10_0_i1018);
	init_label(mercury__dnf__transform_goal_10_0_i1017);
	init_label(mercury__dnf__transform_goal_10_0_i1015);
	init_label(mercury__dnf__transform_goal_10_0_i5);
	init_label(mercury__dnf__transform_goal_10_0_i6);
	init_label(mercury__dnf__transform_goal_10_0_i8);
	init_label(mercury__dnf__transform_goal_10_0_i9);
	init_label(mercury__dnf__transform_goal_10_0_i10);
	init_label(mercury__dnf__transform_goal_10_0_i1011);
	init_label(mercury__dnf__transform_goal_10_0_i14);
	init_label(mercury__dnf__transform_goal_10_0_i15);
	init_label(mercury__dnf__transform_goal_10_0_i1014);
	init_label(mercury__dnf__transform_goal_10_0_i17);
	init_label(mercury__dnf__transform_goal_10_0_i1012);
	init_label(mercury__dnf__transform_goal_10_0_i1013);
BEGIN_CODE

/* code for predicate 'dnf__transform_goal'/10 in mode 0 */
Define_static(mercury__dnf__transform_goal_10_0);
	r8 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r8) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dnf__transform_goal_10_0_i1014);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r8, ((Integer) 0)),
		LABEL(mercury__dnf__transform_goal_10_0_i1019) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1012) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1018) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1017) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1017) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1015) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1012));
Define_label(mercury__dnf__transform_goal_10_0_i1019);
	incr_sp_push_msg(5, "dnf__transform_goal");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__dnf__transform_goal_10_0_i5);
Define_label(mercury__dnf__transform_goal_10_0_i1018);
	incr_sp_push_msg(5, "dnf__transform_goal");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__dnf__transform_goal_10_0_i8);
Define_label(mercury__dnf__transform_goal_10_0_i1017);
	incr_sp_push_msg(5, "dnf__transform_goal");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__dnf__transform_goal_10_0_i10);
Define_label(mercury__dnf__transform_goal_10_0_i1015);
	incr_sp_push_msg(5, "dnf__transform_goal");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__dnf__transform_goal_10_0_i14);
Define_label(mercury__dnf__transform_goal_10_0_i5);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 4));
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = ((Integer) 0);
	call_localret(STATIC(mercury__dnf__transform_switch_11_0),
		mercury__dnf__transform_goal_10_0_i6,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i8);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 2));
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = ((Integer) 0);
	call_localret(STATIC(mercury__dnf__transform_disj_11_0),
		mercury__dnf__transform_goal_10_0_i9,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i10);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r8 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r8;
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_goal_10_0_i1011,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i1011);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) r4;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i14);
	r9 = (Integer) r6;
	r10 = (Integer) r7;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r6 = (Integer) r4;
	r7 = (Integer) r5;
	r4 = (Integer) r2;
	r5 = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 3));
	r3 = (Integer) field(mktag(3), (Integer) r8, ((Integer) 4));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r8, ((Integer) 5));
	r8 = ((Integer) 0);
	call_localret(STATIC(mercury__dnf__transform_ite_15_0),
		mercury__dnf__transform_goal_10_0_i15,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i15);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	r6 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i1014);
	incr_sp_push_msg(5, "dnf__transform_goal");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r8) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__dnf__transform_goal_10_0_i17);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r8, ((Integer) 0));
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = ((Integer) 0);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_goal_10_0_i1011,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i17);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r8) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dnf__transform_goal_10_0_i1013);
	r2 = (Integer) r1;
	r1 = (Integer) r4;
	r3 = (Integer) r7;
	proceed();
Define_label(mercury__dnf__transform_goal_10_0_i1012);
	r2 = (Integer) r1;
	r1 = (Integer) r4;
	r3 = (Integer) r7;
	proceed();
Define_label(mercury__dnf__transform_goal_10_0_i1013);
	r2 = (Integer) r1;
	r1 = (Integer) r4;
	r3 = (Integer) r7;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module5)
	init_entry(mercury__dnf__transform_disj_11_0);
	init_label(mercury__dnf__transform_disj_11_0_i4);
	init_label(mercury__dnf__transform_disj_11_0_i5);
	init_label(mercury__dnf__transform_disj_11_0_i6);
	init_label(mercury__dnf__transform_disj_11_0_i7);
	init_label(mercury__dnf__transform_disj_11_0_i1002);
BEGIN_CODE

/* code for predicate 'dnf__transform_disj'/11 in mode 0 */
Define_static(mercury__dnf__transform_disj_11_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__transform_disj_11_0_i1002);
	incr_sp_push_msg(10, "dnf__transform_disj");
	detstackvar(10) = (Integer) succip;
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_disj_11_0_i4,
		STATIC(mercury__dnf__transform_disj_11_0));
	}
Define_label(mercury__dnf__transform_disj_11_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_disj_11_0_i5,
		STATIC(mercury__dnf__transform_disj_11_0));
Define_label(mercury__dnf__transform_disj_11_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	detstackvar(7) = (Integer) r4;
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_disj_11_0_i6,
		STATIC(mercury__dnf__transform_disj_11_0));
	}
Define_label(mercury__dnf__transform_disj_11_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	localcall(mercury__dnf__transform_disj_11_0,
		LABEL(mercury__dnf__transform_disj_11_0_i7),
		STATIC(mercury__dnf__transform_disj_11_0));
Define_label(mercury__dnf__transform_disj_11_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__dnf__transform_disj_11_0_i1002);
	r1 = (Integer) r4;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r8;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module6)
	init_entry(mercury__dnf__transform_switch_11_0);
	init_label(mercury__dnf__transform_switch_11_0_i4);
	init_label(mercury__dnf__transform_switch_11_0_i5);
	init_label(mercury__dnf__transform_switch_11_0_i6);
	init_label(mercury__dnf__transform_switch_11_0_i7);
	init_label(mercury__dnf__transform_switch_11_0_i1003);
BEGIN_CODE

/* code for predicate 'dnf__transform_switch'/11 in mode 0 */
Define_static(mercury__dnf__transform_switch_11_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__transform_switch_11_0_i1003);
	incr_sp_push_msg(11, "dnf__transform_switch");
	detstackvar(11) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(10) = (Integer) r1;
	detstackvar(9) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_switch_11_0_i4,
		STATIC(mercury__dnf__transform_switch_11_0));
	}
	}
Define_label(mercury__dnf__transform_switch_11_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_switch_11_0_i5,
		STATIC(mercury__dnf__transform_switch_11_0));
Define_label(mercury__dnf__transform_switch_11_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	detstackvar(7) = (Integer) r4;
	r1 = (Integer) r3;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(10), ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_switch_11_0_i6,
		STATIC(mercury__dnf__transform_switch_11_0));
	}
Define_label(mercury__dnf__transform_switch_11_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	localcall(mercury__dnf__transform_switch_11_0,
		LABEL(mercury__dnf__transform_switch_11_0_i7),
		STATIC(mercury__dnf__transform_switch_11_0));
	}
Define_label(mercury__dnf__transform_switch_11_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__dnf__transform_switch_11_0_i1003);
	r1 = (Integer) r4;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r8;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module7)
	init_entry(mercury__dnf__transform_ite_15_0);
	init_label(mercury__dnf__transform_ite_15_0_i2);
	init_label(mercury__dnf__transform_ite_15_0_i3);
	init_label(mercury__dnf__transform_ite_15_0_i4);
	init_label(mercury__dnf__transform_ite_15_0_i5);
	init_label(mercury__dnf__transform_ite_15_0_i6);
	init_label(mercury__dnf__transform_ite_15_0_i7);
	init_label(mercury__dnf__transform_ite_15_0_i8);
	init_label(mercury__dnf__transform_ite_15_0_i9);
	init_label(mercury__dnf__transform_ite_15_0_i10);
BEGIN_CODE

/* code for predicate 'dnf__transform_ite'/15 in mode 0 */
Define_static(mercury__dnf__transform_ite_15_0);
	incr_sp_push_msg(12, "dnf__transform_ite");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r9;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) r6;
	r5 = (Integer) r7;
	r6 = (Integer) r8;
	r7 = (Integer) r9;
	r8 = (Integer) r10;
	call_localret(STATIC(mercury__dnf__make_goal_literal_12_0),
		mercury__dnf__transform_ite_15_0_i2,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r3;
	detstackvar(9) = (Integer) r2;
	detstackvar(10) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__dnf__transform_ite_15_0_i3,
		STATIC(mercury__dnf__transform_ite_15_0));
	}
Define_label(mercury__dnf__transform_ite_15_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__dnf__transform_ite_15_0_i4,
		STATIC(mercury__dnf__transform_ite_15_0));
	}
Define_label(mercury__dnf__transform_ite_15_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_ite_15_0_i5,
		STATIC(mercury__dnf__transform_ite_15_0));
	}
Define_label(mercury__dnf__transform_ite_15_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_ite_15_0_i6,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	detstackvar(9) = (Integer) r4;
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_ite_15_0_i7,
		STATIC(mercury__dnf__transform_ite_15_0));
	}
Define_label(mercury__dnf__transform_ite_15_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_ite_15_0_i8,
		STATIC(mercury__dnf__transform_ite_15_0));
	}
Define_label(mercury__dnf__transform_ite_15_0_i8);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_ite_15_0_i9,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(10);
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_ite_15_0_i10,
		STATIC(mercury__dnf__transform_ite_15_0));
	}
Define_label(mercury__dnf__transform_ite_15_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module8)
	init_entry(mercury__dnf__transform_conj_12_0);
	init_label(mercury__dnf__transform_conj_12_0_i4);
	init_label(mercury__dnf__transform_conj_12_0_i5);
	init_label(mercury__dnf__transform_conj_12_0_i6);
	init_label(mercury__dnf__transform_conj_12_0_i7);
	init_label(mercury__dnf__transform_conj_12_0_i1002);
BEGIN_CODE

/* code for predicate 'dnf__transform_conj'/12 in mode 0 */
Define_static(mercury__dnf__transform_conj_12_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__transform_conj_12_0_i1002);
	incr_sp_push_msg(10, "dnf__transform_conj");
	detstackvar(10) = (Integer) succip;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r7;
	call_localret(STATIC(mercury__dnf__make_goal_literal_12_0),
		mercury__dnf__transform_conj_12_0_i4,
		STATIC(mercury__dnf__transform_conj_12_0));
Define_label(mercury__dnf__transform_conj_12_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 1));
	detstackvar(5) = (Integer) r3;
	detstackvar(8) = (Integer) r2;
	detstackvar(9) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__dnf__transform_conj_12_0_i5,
		STATIC(mercury__dnf__transform_conj_12_0));
	}
Define_label(mercury__dnf__transform_conj_12_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__dnf__transform_conj_12_0_i6,
		STATIC(mercury__dnf__transform_conj_12_0));
	}
Define_label(mercury__dnf__transform_conj_12_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(9);
	localcall(mercury__dnf__transform_conj_12_0,
		LABEL(mercury__dnf__transform_conj_12_0_i7),
		STATIC(mercury__dnf__transform_conj_12_0));
Define_label(mercury__dnf__transform_conj_12_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__dnf__transform_conj_12_0_i1002);
	r1 = (Integer) r4;
	r2 = (Integer) r6;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) r8;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module9)
	init_entry(mercury__dnf__make_goal_literal_12_0);
	init_label(mercury__dnf__make_goal_literal_12_0_i7);
	init_label(mercury__dnf__make_goal_literal_12_0_i1000);
	init_label(mercury__dnf__make_goal_literal_12_0_i4);
	init_label(mercury__dnf__make_goal_literal_12_0_i3);
	init_label(mercury__dnf__make_goal_literal_12_0_i12);
	init_label(mercury__dnf__make_goal_literal_12_0_i13);
	init_label(mercury__dnf__make_goal_literal_12_0_i14);
	init_label(mercury__dnf__make_goal_literal_12_0_i15);
	init_label(mercury__dnf__make_goal_literal_12_0_i16);
	init_label(mercury__dnf__make_goal_literal_12_0_i17);
	init_label(mercury__dnf__make_goal_literal_12_0_i18);
	init_label(mercury__dnf__make_goal_literal_12_0_i19);
	init_label(mercury__dnf__make_goal_literal_12_0_i20);
	init_label(mercury__dnf__make_goal_literal_12_0_i21);
	init_label(mercury__dnf__make_goal_literal_12_0_i22);
	init_label(mercury__dnf__make_goal_literal_12_0_i23);
	init_label(mercury__dnf__make_goal_literal_12_0_i24);
	init_label(mercury__dnf__make_goal_literal_12_0_i25);
	init_label(mercury__dnf__make_goal_literal_12_0_i26);
	init_label(mercury__dnf__make_goal_literal_12_0_i27);
	init_label(mercury__dnf__make_goal_literal_12_0_i28);
BEGIN_CODE

/* code for predicate 'dnf__make_goal_literal'/12 in mode 0 */
Define_static(mercury__dnf__make_goal_literal_12_0);
	r9 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r9) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dnf__make_goal_literal_12_0_i1000);
	incr_sp_push_msg(17, "dnf__make_goal_literal");
	detstackvar(17) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r9, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__dnf__make_goal_literal_12_0_i4);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r9, ((Integer) 1)), ((Integer) 0));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__dnf__is_considered_atomic_expr_2_0),
		mercury__dnf__make_goal_literal_12_0_i7,
		STATIC(mercury__dnf__make_goal_literal_12_0));
Define_label(mercury__dnf__make_goal_literal_12_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__make_goal_literal_12_0_i3);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__dnf__make_goal_literal_12_0_i1000);
	incr_sp_push_msg(17, "dnf__make_goal_literal");
	detstackvar(17) = (Integer) succip;
Define_label(mercury__dnf__make_goal_literal_12_0_i4);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	r1 = (Integer) r9;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__dnf__is_considered_atomic_expr_2_0),
		mercury__dnf__make_goal_literal_12_0_i7,
		STATIC(mercury__dnf__make_goal_literal_12_0));
Define_label(mercury__dnf__make_goal_literal_12_0_i3);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__dnf__make_goal_literal_12_0_i12,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i12);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__dnf__get_new_pred_name_5_0),
		mercury__dnf__make_goal_literal_12_0_i13,
		STATIC(mercury__dnf__make_goal_literal_12_0));
Define_label(mercury__dnf__make_goal_literal_12_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(5) = (Integer) r1;
	r3 = (Integer) detstackvar(6);
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 1));
	detstackvar(11) = (Integer) r1;
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__dnf__make_goal_literal_12_0_i14,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i14);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__dnf__make_goal_literal_12_0_i15,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i15);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__dnf__make_goal_literal_12_0_i16,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i16);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__dnf__make_goal_literal_12_0_i17,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i17);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__dnf__make_goal_literal_12_0_i18,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i18);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dnf__make_goal_literal_12_0_i19,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i19);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r4 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(2);
	detstackvar(12) = (Integer) r1;
	call_localret(STATIC(mercury__dnf__compute_arg_types_modes_6_0),
		mercury__dnf__make_goal_literal_12_0_i20,
		STATIC(mercury__dnf__make_goal_literal_12_0));
Define_label(mercury__dnf__make_goal_literal_12_0_i20);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__dnf__make_goal_literal_12_0_i21,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i21);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	detstackvar(16) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__dnf__make_goal_literal_12_0_i22,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i22);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(12);
	r4 = (Integer) detstackvar(15);
	r5 = (Integer) detstackvar(14);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__hlds_pred__proc_info_create_9_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_create_9_0),
		mercury__dnf__make_goal_literal_12_0_i23,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i23);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(16);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(13);
	r7 = ((Integer) 8);
	r8 = (Integer) detstackvar(10);
	r9 = ((Integer) 0);
	{
	Declare_entry(mercury__hlds_pred__pred_info_create_12_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_create_12_0),
		mercury__dnf__make_goal_literal_12_0_i24,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i24);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__dnf__make_goal_literal_12_0_i25,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i25);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_table_insert_4_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_insert_4_0),
		mercury__dnf__make_goal_literal_12_0_i26,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i26);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_set_predicate_table_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_predicate_table_3_0),
		mercury__dnf__make_goal_literal_12_0_i27,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i27);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0),
		mercury__dnf__make_goal_literal_12_0_i28,
		STATIC(mercury__dnf__make_goal_literal_12_0));
	}
Define_label(mercury__dnf__make_goal_literal_12_0_i28);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_12_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 6));
	field(mktag(1), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) tempr1, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(12);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__dnf_module10)
	init_entry(mercury__dnf__get_new_pred_name_5_0);
	init_label(mercury__dnf__get_new_pred_name_5_0_i2);
	init_label(mercury__dnf__get_new_pred_name_5_0_i3);
	init_label(mercury__dnf__get_new_pred_name_5_0_i6);
	init_label(mercury__dnf__get_new_pred_name_5_0_i5);
BEGIN_CODE

/* code for predicate 'dnf__get_new_pred_name'/5 in mode 0 */
Define_static(mercury__dnf__get_new_pred_name_5_0);
	incr_sp_push_msg(5, "dnf__get_new_pred_name");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__dnf__get_new_pred_name_5_0_i2,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
	}
Define_label(mercury__dnf__get_new_pred_name_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__get_new_pred_name_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("__part_", 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__dnf__get_new_pred_name_5_0_i3,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
	}
	}
Define_label(mercury__dnf__get_new_pred_name_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__get_new_pred_name_5_0));
	detstackvar(4) = ((Integer) detstackvar(3) + ((Integer) 1));
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_table_search_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_name_3_0),
		mercury__dnf__get_new_pred_name_5_0_i6,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
	}
Define_label(mercury__dnf__get_new_pred_name_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__get_new_pred_name_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__get_new_pred_name_5_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__dnf__get_new_pred_name_5_0,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
Define_label(mercury__dnf__get_new_pred_name_5_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module11)
	init_entry(mercury__dnf__compute_arg_types_modes_6_0);
	init_label(mercury__dnf__compute_arg_types_modes_6_0_i4);
	init_label(mercury__dnf__compute_arg_types_modes_6_0_i5);
	init_label(mercury__dnf__compute_arg_types_modes_6_0_i6);
	init_label(mercury__dnf__compute_arg_types_modes_6_0_i7);
	init_label(mercury__dnf__compute_arg_types_modes_6_0_i1004);
BEGIN_CODE

/* code for predicate 'dnf__compute_arg_types_modes'/6 in mode 0 */
Define_static(mercury__dnf__compute_arg_types_modes_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__compute_arg_types_modes_6_0_i1004);
	incr_sp_push_msg(7, "dnf__compute_arg_types_modes");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dnf__compute_arg_types_modes_6_0_i4,
		STATIC(mercury__dnf__compute_arg_types_modes_6_0));
	}
Define_label(mercury__dnf__compute_arg_types_modes_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__compute_arg_types_modes_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__dnf__compute_arg_types_modes_6_0_i5,
		STATIC(mercury__dnf__compute_arg_types_modes_6_0));
	}
Define_label(mercury__dnf__compute_arg_types_modes_6_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__compute_arg_types_modes_6_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__dnf__compute_arg_types_modes_6_0_i6,
		STATIC(mercury__dnf__compute_arg_types_modes_6_0));
	}
Define_label(mercury__dnf__compute_arg_types_modes_6_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__compute_arg_types_modes_6_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	localcall(mercury__dnf__compute_arg_types_modes_6_0,
		LABEL(mercury__dnf__compute_arg_types_modes_6_0_i7),
		STATIC(mercury__dnf__compute_arg_types_modes_6_0));
	}
Define_label(mercury__dnf__compute_arg_types_modes_6_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__compute_arg_types_modes_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__dnf__compute_arg_types_modes_6_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module12)
	init_entry(mercury__dnf__is_considered_atomic_expr_2_0);
	init_label(mercury__dnf__is_considered_atomic_expr_2_0_i5);
	init_label(mercury__dnf__is_considered_atomic_expr_2_0_i2);
	init_label(mercury__dnf__is_considered_atomic_expr_2_0_i1);
BEGIN_CODE

/* code for predicate 'dnf__is_considered_atomic_expr'/2 in mode 0 */
Define_static(mercury__dnf__is_considered_atomic_expr_2_0);
	incr_sp_push_msg(3, "dnf__is_considered_atomic_expr");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__dnf__is_atomic_expr_2_0),
		mercury__dnf__is_considered_atomic_expr_2_0_i5,
		STATIC(mercury__dnf__is_considered_atomic_expr_2_0));
Define_label(mercury__dnf__is_considered_atomic_expr_2_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__is_considered_atomic_expr_2_0));
	if ((((Integer) 0) == (Integer) r1))
		GOTO_LABEL(mercury__dnf__is_considered_atomic_expr_2_0_i2);
	r3 = (Integer) detstackvar(2);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__is_considered_atomic_expr_2_0_i1);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__dnf__expr_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__is_considered_atomic_expr_2_0));
Define_label(mercury__dnf__is_considered_atomic_expr_2_0_i2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dnf__is_considered_atomic_expr_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module13)
	init_entry(mercury__dnf__is_atomic_expr_2_0);
	init_label(mercury__dnf__is_atomic_expr_2_0_i1005);
	init_label(mercury__dnf__is_atomic_expr_2_0_i1006);
	init_label(mercury__dnf__is_atomic_expr_2_0_i1014);
	init_label(mercury__dnf__is_atomic_expr_2_0_i13);
	init_label(mercury__dnf__is_atomic_expr_2_0_i1012);
	init_label(mercury__dnf__is_atomic_expr_2_0_i1013);
BEGIN_CODE

/* code for predicate 'dnf__is_atomic_expr'/2 in mode 0 */
Define_static(mercury__dnf__is_atomic_expr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_2_0_i1014);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1005) AND
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1006) AND
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1005) AND
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1005) AND
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1012) AND
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1005) AND
		LABEL(mercury__dnf__is_atomic_expr_2_0_i1006));
Define_label(mercury__dnf__is_atomic_expr_2_0_i1005);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__dnf__is_atomic_expr_2_0_i1006);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__dnf__is_atomic_expr_2_0_i1014);
	incr_sp_push_msg(1, "dnf__is_atomic_expr");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_2_0_i13);
	r1 = ((Integer) 1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__dnf__is_atomic_expr_2_0_i13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_2_0_i1013);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__dnf__is_atomic_expr_2_0_i1012);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localtailcall(mercury__dnf__is_atomic_expr_2_0,
		STATIC(mercury__dnf__is_atomic_expr_2_0));
Define_label(mercury__dnf__is_atomic_expr_2_0_i1013);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module14)
	init_entry(mercury__dnf__expr_free_of_nonatomic_2_0);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1020);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i18);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i19);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i21);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1019);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i26);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i32);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1009);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1013);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1014);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1015);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1016);
	init_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1018);
BEGIN_CODE

/* code for predicate 'dnf__expr_free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__expr_free_of_nonatomic_2_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1019);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1013) AND
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1009) AND
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1014) AND
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1015) AND
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1016) AND
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1020) AND
		LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1009));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1020);
	incr_sp_push_msg(4, "dnf__expr_free_of_nonatomic");
	detstackvar(4) = (Integer) succip;
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i18);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		mercury__dnf__expr_free_of_nonatomic_2_0_i19,
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i19);
	update_prof_current_proc(LABEL(mercury__dnf__expr_free_of_nonatomic_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		mercury__dnf__expr_free_of_nonatomic_2_0_i21,
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i21);
	update_prof_current_proc(LABEL(mercury__dnf__expr_free_of_nonatomic_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1019);
	incr_sp_push_msg(4, "dnf__expr_free_of_nonatomic");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i26);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__dnf__goals_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i26);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dnf__expr_free_of_nonatomic_2_0_i32,
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
	}
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i32);
	update_prof_current_proc(LABEL(mercury__dnf__expr_free_of_nonatomic_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((Integer) r1)
		GOTO_LABEL(mercury__dnf__expr_free_of_nonatomic_2_0_i1018);
	r1 = TRUE;
	proceed();
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1013);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__dnf__cases_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1014);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__dnf__goals_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1015);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1016);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	tailcall(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__expr_free_of_nonatomic_2_0));
Define_label(mercury__dnf__expr_free_of_nonatomic_2_0_i1018);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module15)
	init_entry(mercury__dnf__goal_free_of_nonatomic_2_0);
BEGIN_CODE

/* code for predicate 'dnf__goal_free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__goal_free_of_nonatomic_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__dnf__expr_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__goal_free_of_nonatomic_2_0));
END_MODULE

BEGIN_MODULE(mercury__dnf_module16)
	init_entry(mercury__dnf__goals_free_of_nonatomic_2_0);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i4);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1003);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
BEGIN_CODE

/* code for predicate 'dnf__goals_free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__goals_free_of_nonatomic_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__goals_free_of_nonatomic_2_0_i1003);
	incr_sp_push_msg(3, "dnf__goals_free_of_nonatomic");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		mercury__dnf__goals_free_of_nonatomic_2_0_i4,
		STATIC(mercury__dnf__goals_free_of_nonatomic_2_0));
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__goals_free_of_nonatomic_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__dnf__goals_free_of_nonatomic_2_0,
		STATIC(mercury__dnf__goals_free_of_nonatomic_2_0));
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dnf_module17)
	init_entry(mercury__dnf__cases_free_of_nonatomic_2_0);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i4);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1003);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
BEGIN_CODE

/* code for predicate 'dnf__cases_free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__cases_free_of_nonatomic_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dnf__cases_free_of_nonatomic_2_0_i1003);
	incr_sp_push_msg(3, "dnf__cases_free_of_nonatomic");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	call_localret(STATIC(mercury__dnf__goal_free_of_nonatomic_2_0),
		mercury__dnf__cases_free_of_nonatomic_2_0_i4,
		STATIC(mercury__dnf__cases_free_of_nonatomic_2_0));
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__cases_free_of_nonatomic_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__dnf__cases_free_of_nonatomic_2_0,
		STATIC(mercury__dnf__cases_free_of_nonatomic_2_0));
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__dnf_bunch_0(void)
{
	mercury__dnf_module0();
	mercury__dnf_module1();
	mercury__dnf_module2();
	mercury__dnf_module3();
	mercury__dnf_module4();
	mercury__dnf_module5();
	mercury__dnf_module6();
	mercury__dnf_module7();
	mercury__dnf_module8();
	mercury__dnf_module9();
	mercury__dnf_module10();
	mercury__dnf_module11();
	mercury__dnf_module12();
	mercury__dnf_module13();
	mercury__dnf_module14();
	mercury__dnf_module15();
	mercury__dnf_module16();
	mercury__dnf_module17();
}

#endif

void mercury__dnf__init(void); /* suppress gcc warning */
void mercury__dnf__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__dnf_bunch_0();
#endif
}
