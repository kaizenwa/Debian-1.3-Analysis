/*
** Automatically generated from `hlds_pred.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__hlds_pred__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___hlds_pred_arg_info_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_pred_clause_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_pred_clauses_info_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_pred_pred_proc_id_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_pred_pred_call_id_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_pred_proc_info_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_pred_pred_info_0__ua10000_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_init_13_0);
Declare_label(mercury__hlds_pred__pred_info_init_13_0_i2);
Declare_label(mercury__hlds_pred__pred_info_init_13_0_i3);
Declare_label(mercury__hlds_pred__pred_info_init_13_0_i4);
Declare_label(mercury__hlds_pred__pred_info_init_13_0_i5);
Define_extern_entry(mercury__hlds_pred__pred_info_create_12_0);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i2);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i3);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i4);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i5);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i6);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i7);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i8);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i9);
Declare_label(mercury__hlds_pred__pred_info_create_12_0_i10);
Define_extern_entry(mercury__hlds_pred__pred_info_set_15_0);
Define_extern_entry(mercury__hlds_pred__pred_info_module_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_name_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_arity_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_procids_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
Declare_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i2);
Declare_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i6);
Declare_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i5);
Declare_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i3);
Declare_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i11);
Declare_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i8);
Define_extern_entry(mercury__hlds_pred__pred_info_exported_procids_2_0);
Declare_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i2);
Declare_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i3);
Declare_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i1000);
Define_extern_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_arg_types_4_0);
Define_extern_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_clauses_info_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_procedures_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_context_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_import_status_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
Declare_label(mercury__hlds_pred__pred_info_is_imported_1_0_i2);
Declare_label(mercury__hlds_pred__pred_info_is_imported_1_0_i3);
Declare_label(mercury__hlds_pred__pred_info_is_imported_1_0_i1);
Define_extern_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
Declare_label(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i2);
Declare_label(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i1000);
Define_extern_entry(mercury__hlds_pred__pred_info_is_exported_1_0);
Declare_label(mercury__hlds_pred__pred_info_is_exported_1_0_i2);
Declare_label(mercury__hlds_pred__pred_info_is_exported_1_0_i1000);
Define_extern_entry(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0);
Declare_label(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i2);
Declare_label(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i1000);
Define_extern_entry(mercury__hlds_pred__pred_info_mark_as_external_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_import_status_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_typevarset_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_get_goal_type_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_goal_type_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_is_inlined_1_0);
Declare_label(mercury__hlds_pred__pred_info_is_inlined_1_0_i2);
Define_extern_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
Define_extern_entry(mercury__hlds_pred__pred_info_set_marker_list_3_0);
Define_extern_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_init_6_0);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i2);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i3);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i4);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i5);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i6);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i7);
Declare_label(mercury__hlds_pred__proc_info_init_6_0_i8);
Define_extern_entry(mercury__hlds_pred__proc_info_set_15_0);
Define_extern_entry(mercury__hlds_pred__proc_info_create_9_0);
Declare_label(mercury__hlds_pred__proc_info_create_9_0_i2);
Declare_label(mercury__hlds_pred__proc_info_create_9_0_i3);
Define_extern_entry(mercury__hlds_pred__proc_info_set_body_6_0);
Define_extern_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_inferred_determinism_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
Declare_label(mercury__hlds_pred__proc_info_interface_determinism_2_0_i2);
Declare_label(mercury__hlds_pred__proc_info_interface_determinism_2_0_i4);
Define_extern_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_label(mercury__hlds_pred__proc_info_interface_code_model_2_0_i2);
Define_extern_entry(mercury__hlds_pred__proc_info_never_succeeds_2_0);
Declare_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i2);
Declare_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i5);
Declare_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i4);
Declare_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i1000);
Define_extern_entry(mercury__hlds_pred__proc_info_variables_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_varset_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_headvars_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_headvars_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_argmodes_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_arglives_3_0);
Declare_label(mercury__hlds_pred__proc_info_arglives_3_0_i2);
Declare_label(mercury__hlds_pred__proc_info_arglives_3_0_i3);
Declare_label(mercury__hlds_pred__proc_info_arglives_3_0_i6);
Define_extern_entry(mercury__hlds_pred__proc_info_maybe_arglives_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_maybe_arglives_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_goal_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_context_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_stack_slots_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_liveness_info_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_can_process_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_arg_info_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
Declare_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i2);
Declare_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i3);
Declare_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i4);
Declare_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i5);
Define_extern_entry(mercury__hlds_pred__proc_info_set_liveness_info_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_stack_slots_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_can_process_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
Define_extern_entry(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0);
Define_extern_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i2);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i3);
Define_extern_entry(mercury__hlds_pred__proc_info_ensure_unique_names_2_0);
Declare_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i2);
Declare_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i3);
Declare_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i4);
Declare_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i5);
Declare_static(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i4);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i7);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i9);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i10);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i14);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i15);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i16);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i6);
Declare_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i1004);
Define_extern_entry(mercury__hlds_pred__make_n_fresh_vars_5_0);
Define_extern_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
Declare_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i2);
Declare_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i5);
Declare_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i8);
Declare_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i4);
Declare_static(mercury__hlds_pred__make_n_fresh_vars_2_6_0);
Declare_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i1000);
Declare_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i4);
Declare_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i5);
Declare_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i6);
Declare_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i7);
Declare_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i8);
Define_extern_entry(mercury____Unify___hlds_pred__proc_id_0_0);
Declare_label(mercury____Unify___hlds_pred__proc_id_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__proc_id_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__proc_id_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__pred_id_0_0);
Declare_label(mercury____Unify___hlds_pred__pred_id_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__pred_id_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__pred_id_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__pred_info_0_0);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i2);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i4);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i6);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i8);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i10);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i12);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i14);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i16);
Declare_label(mercury____Unify___hlds_pred__pred_info_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__pred_info_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__pred_info_0_0);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i5);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i3);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i10);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i16);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i22);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i28);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i34);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i40);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i46);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i52);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i58);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i64);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i70);
Declare_label(mercury____Compare___hlds_pred__pred_info_0_0_i76);
Define_extern_entry(mercury____Unify___hlds_pred__proc_info_0_0);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i2);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i4);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i6);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i8);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i10);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i12);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i14);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i16);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i18);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i20);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i22);
Declare_label(mercury____Unify___hlds_pred__proc_info_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__proc_info_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__proc_info_0_0);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i5);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i3);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i10);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i16);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i22);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i28);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i34);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i40);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i46);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i52);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i58);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i64);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i70);
Declare_label(mercury____Compare___hlds_pred__proc_info_0_0_i76);
Define_extern_entry(mercury____Unify___hlds_pred__proc_table_0_0);
Define_extern_entry(mercury____Index___hlds_pred__proc_table_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__proc_table_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__pred_call_id_0_0);
Declare_label(mercury____Unify___hlds_pred__pred_call_id_0_0_i2);
Declare_label(mercury____Unify___hlds_pred__pred_call_id_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__pred_call_id_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__pred_call_id_0_0);
Declare_label(mercury____Compare___hlds_pred__pred_call_id_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__pred_call_id_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_pred__pred_proc_id_0_0);
Declare_label(mercury____Unify___hlds_pred__pred_proc_id_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__pred_proc_id_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__pred_proc_id_0_0);
Declare_label(mercury____Compare___hlds_pred__pred_proc_id_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__pred_proc_id_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_pred__pred_proc_list_0_0);
Define_extern_entry(mercury____Index___hlds_pred__pred_proc_list_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__pred_proc_list_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__clauses_info_0_0);
Declare_label(mercury____Unify___hlds_pred__clauses_info_0_0_i2);
Declare_label(mercury____Unify___hlds_pred__clauses_info_0_0_i4);
Declare_label(mercury____Unify___hlds_pred__clauses_info_0_0_i6);
Declare_label(mercury____Unify___hlds_pred__clauses_info_0_0_i8);
Declare_label(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__clauses_info_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__clauses_info_0_0);
Declare_label(mercury____Compare___hlds_pred__clauses_info_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__clauses_info_0_0_i5);
Declare_label(mercury____Compare___hlds_pred__clauses_info_0_0_i3);
Declare_label(mercury____Compare___hlds_pred__clauses_info_0_0_i10);
Declare_label(mercury____Compare___hlds_pred__clauses_info_0_0_i16);
Declare_label(mercury____Compare___hlds_pred__clauses_info_0_0_i22);
Define_extern_entry(mercury____Unify___hlds_pred__clause_0_0);
Declare_label(mercury____Unify___hlds_pred__clause_0_0_i2);
Declare_label(mercury____Unify___hlds_pred__clause_0_0_i4);
Declare_label(mercury____Unify___hlds_pred__clause_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__clause_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__clause_0_0);
Declare_label(mercury____Compare___hlds_pred__clause_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__clause_0_0_i5);
Declare_label(mercury____Compare___hlds_pred__clause_0_0_i3);
Declare_label(mercury____Compare___hlds_pred__clause_0_0_i10);
Define_extern_entry(mercury____Unify___hlds_pred__goal_type_0_0);
Declare_label(mercury____Unify___hlds_pred__goal_type_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__goal_type_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__goal_type_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__liveness_info_0_0);
Define_extern_entry(mercury____Index___hlds_pred__liveness_info_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__liveness_info_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__liveness_0_0);
Declare_label(mercury____Unify___hlds_pred__liveness_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__liveness_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__liveness_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__arg_info_0_0);
Declare_label(mercury____Unify___hlds_pred__arg_info_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__arg_info_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__arg_info_0_0);
Declare_label(mercury____Compare___hlds_pred__arg_info_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__arg_info_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_pred__arg_mode_0_0);
Declare_label(mercury____Unify___hlds_pred__arg_mode_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__arg_mode_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__arg_mode_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__arg_loc_0_0);
Declare_label(mercury____Unify___hlds_pred__arg_loc_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__arg_loc_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__arg_loc_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__import_status_0_0);
Declare_label(mercury____Unify___hlds_pred__import_status_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__import_status_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__import_status_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__pred_or_func_0_0);
Declare_label(mercury____Unify___hlds_pred__pred_or_func_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__pred_or_func_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__pred_or_func_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__marker_0_0);
Declare_label(mercury____Unify___hlds_pred__marker_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__marker_0_0);
Define_extern_entry(mercury____Compare___hlds_pred__marker_0_0);
Define_extern_entry(mercury____Unify___hlds_pred__marker_status_0_0);
Declare_label(mercury____Unify___hlds_pred__marker_status_0_0_i3);
Declare_label(mercury____Unify___hlds_pred__marker_status_0_0_i1);
Define_extern_entry(mercury____Index___hlds_pred__marker_status_0_0);
Declare_label(mercury____Index___hlds_pred__marker_status_0_0_i3);
Define_extern_entry(mercury____Compare___hlds_pred__marker_status_0_0);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i2);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i3);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i4);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i6);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i11);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i9);
Declare_label(mercury____Compare___hlds_pred__marker_status_0_0_i1000);

extern Word * mercury_data_hlds_pred__base_type_layout_arg_info_0[];
Word * mercury_data_hlds_pred__base_type_info_arg_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__arg_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__arg_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__arg_info_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_arg_info_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_arg_loc_0[];
Word * mercury_data_hlds_pred__base_type_info_arg_loc_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__arg_loc_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__arg_loc_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__arg_loc_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_arg_loc_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_arg_mode_0[];
Word * mercury_data_hlds_pred__base_type_info_arg_mode_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__arg_mode_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__arg_mode_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__arg_mode_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_arg_mode_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_clause_0[];
Word * mercury_data_hlds_pred__base_type_info_clause_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__clause_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__clause_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__clause_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_clause_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_clauses_info_0[];
Word * mercury_data_hlds_pred__base_type_info_clauses_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__clauses_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__clauses_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__clauses_info_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_clauses_info_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_goal_type_0[];
Word * mercury_data_hlds_pred__base_type_info_goal_type_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__goal_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__goal_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__goal_type_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_goal_type_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_import_status_0[];
Word * mercury_data_hlds_pred__base_type_info_import_status_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__import_status_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__import_status_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__import_status_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_import_status_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_liveness_0[];
Word * mercury_data_hlds_pred__base_type_info_liveness_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__liveness_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__liveness_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__liveness_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_liveness_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_liveness_info_0[];
Word * mercury_data_hlds_pred__base_type_info_liveness_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__liveness_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__liveness_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__liveness_info_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_liveness_info_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_marker_0[];
Word * mercury_data_hlds_pred__base_type_info_marker_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__marker_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__marker_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__marker_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_marker_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_marker_status_0[];
Word * mercury_data_hlds_pred__base_type_info_marker_status_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__marker_status_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__marker_status_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__marker_status_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_marker_status_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_pred_call_id_0[];
Word * mercury_data_hlds_pred__base_type_info_pred_call_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__pred_call_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__pred_call_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__pred_call_id_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_pred_call_id_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_pred_id_0[];
Word * mercury_data_hlds_pred__base_type_info_pred_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__pred_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__pred_id_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_pred_id_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_pred_info_0[];
Word * mercury_data_hlds_pred__base_type_info_pred_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__pred_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__pred_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__pred_info_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_pred_info_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_pred_or_func_0[];
Word * mercury_data_hlds_pred__base_type_info_pred_or_func_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__pred_or_func_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__pred_or_func_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__pred_or_func_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_pred_or_func_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_pred_proc_id_0[];
Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__pred_proc_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_pred_proc_id_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_pred_proc_list_0[];
Word * mercury_data_hlds_pred__base_type_info_pred_proc_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__pred_proc_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__pred_proc_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__pred_proc_list_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_pred_proc_list_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_proc_id_0[];
Word * mercury_data_hlds_pred__base_type_info_proc_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__proc_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__proc_id_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_proc_id_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_proc_info_0[];
Word * mercury_data_hlds_pred__base_type_info_proc_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__proc_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__proc_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__proc_info_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_proc_info_0
};

extern Word * mercury_data_hlds_pred__base_type_layout_proc_table_0[];
Word * mercury_data_hlds_pred__base_type_info_proc_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_pred__proc_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_pred__proc_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_pred__proc_table_0_0),
	(Word *) (Integer) mercury_data_hlds_pred__base_type_layout_proc_table_0
};

extern Word * mercury_data_hlds_pred__common_6[];
Word * mercury_data_hlds_pred__base_type_layout_proc_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_6)
};

extern Word * mercury_data_hlds_pred__common_21[];
Word * mercury_data_hlds_pred__base_type_layout_proc_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_21),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_pred__common_23[];
Word * mercury_data_hlds_pred__base_type_layout_proc_id_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23)
};

extern Word * mercury_data_hlds_pred__common_25[];
Word * mercury_data_hlds_pred__base_type_layout_pred_proc_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_25),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_25),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_25),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_25)
};

extern Word * mercury_data_hlds_pred__common_26[];
Word * mercury_data_hlds_pred__base_type_layout_pred_proc_id_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_26),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_pred__common_27[];
Word * mercury_data_hlds_pred__base_type_layout_pred_or_func_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_27),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_27),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_27),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_27)
};

extern Word * mercury_data_hlds_pred__common_36[];
Word * mercury_data_hlds_pred__base_type_layout_pred_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_36),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_hlds_pred__base_type_layout_pred_id_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23)
};

extern Word * mercury_data_hlds_pred__common_38[];
Word * mercury_data_hlds_pred__base_type_layout_pred_call_id_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_38),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_pred__common_40[];
extern Word * mercury_data_hlds_pred__common_41[];
Word * mercury_data_hlds_pred__base_type_layout_marker_status_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_40),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_41),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_pred__common_42[];
Word * mercury_data_hlds_pred__base_type_layout_marker_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_42),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_42),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_42),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_42)
};

extern Word * mercury_data_hlds_pred__common_43[];
Word * mercury_data_hlds_pred__base_type_layout_liveness_info_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_43),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_43),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_43),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_43)
};

extern Word * mercury_data_hlds_pred__common_44[];
Word * mercury_data_hlds_pred__base_type_layout_liveness_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_44),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_44),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_44),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_44)
};

extern Word * mercury_data_hlds_pred__common_45[];
Word * mercury_data_hlds_pred__base_type_layout_import_status_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_45),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_45),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_45),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_45)
};

extern Word * mercury_data_hlds_pred__common_46[];
Word * mercury_data_hlds_pred__base_type_layout_goal_type_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_46),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_46),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_46),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_46)
};

extern Word * mercury_data_hlds_pred__common_48[];
Word * mercury_data_hlds_pred__base_type_layout_clauses_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_48),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_pred__common_50[];
Word * mercury_data_hlds_pred__base_type_layout_clause_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_50),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_pred__common_51[];
Word * mercury_data_hlds_pred__base_type_layout_arg_mode_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_51),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_51),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_51),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_51)
};

Word * mercury_data_hlds_pred__base_type_layout_arg_loc_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_pred__common_23)
};

extern Word * mercury_data_hlds_pred__common_53[];
Word * mercury_data_hlds_pred__base_type_layout_arg_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_53),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word mercury_data_hlds_pred__common_0[] = {
	((Integer) 3)
};

Word * mercury_data_hlds_pred__common_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_0),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_hlds_pred__common_2[] = {
	((Integer) 0),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_hlds_pred__common_3[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_prog_data__base_type_info_is_live_0[];
Word * mercury_data_hlds_pred__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_is_live_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_hlds_pred__common_5[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0
};

Word * mercury_data_hlds_pred__common_6[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_5)
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data_hlds_data__base_type_info_determinism_0[];
Word * mercury_data_hlds_pred__common_7[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_determinism_0
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_hlds_pred__common_8[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_hlds_pred__common_9[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_hlds_pred__common_10[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_prog_data__base_type_info_mode_0[];
Word * mercury_data_hlds_pred__common_11[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_mode_0
};

Word * mercury_data_hlds_pred__common_12[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_4)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_hlds_pred__common_13[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_hlds_pred__common_14[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

extern Word * mercury_data_llds__base_type_info_lval_0[];
Word * mercury_data_hlds_pred__common_15[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0
};

Word * mercury_data_hlds_pred__common_16[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_determinism_0
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_hlds_pred__common_17[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_hlds_pred__common_18[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0
};

extern Word * mercury_data_set__base_type_info_set_1[];
Word * mercury_data_hlds_pred__common_19[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_hlds_pred__common_20[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_hlds_pred__common_21[] = {
	(Word *) ((Integer) 14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_15),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_16),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_18),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_20),
	(Word *) string_const("procedure", 9)
};

Word * mercury_data_hlds_pred__common_22[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_hlds_pred__common_23[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_22)
};

Word * mercury_data_hlds_pred__common_24[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0
};

Word * mercury_data_hlds_pred__common_25[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_24)
};

Word * mercury_data_hlds_pred__common_26[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_22),
	(Word *) string_const("proc", 4)
};

Word * mercury_data_hlds_pred__common_27[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("predicate", 9),
	(Word *) string_const("function", 8)
};

Word * mercury_data_hlds_pred__common_28[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_prog_data__base_type_info_condition_0[];
Word * mercury_data_hlds_pred__common_29[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_condition_0
};

Word * mercury_data_hlds_pred__common_30[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_clauses_info_0
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_hlds_pred__common_31[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_hlds_pred__common_32[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_import_status_0
};

Word * mercury_data_hlds_pred__common_33[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_goal_type_0
};

Word * mercury_data_hlds_pred__common_34[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0
};

Word * mercury_data_hlds_pred__common_35[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_pred_or_func_0
};

Word * mercury_data_hlds_pred__common_36[] = {
	(Word *) ((Integer) 14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_28),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_29),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_30),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_31),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_31),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_32),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_33),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_34),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_35),
	(Word *) string_const("predicate", 9)
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
Word * mercury_data_hlds_pred__common_37[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0
};

Word * mercury_data_hlds_pred__common_38[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_37),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_22),
	(Word *) string_const("/", 1)
};

Word * mercury_data_hlds_pred__common_39[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_marker_0
};

Word * mercury_data_hlds_pred__common_40[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_39),
	(Word *) string_const("request", 7)
};

Word * mercury_data_hlds_pred__common_41[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_39),
	(Word *) string_const("done", 4)
};

Word * mercury_data_hlds_pred__common_42[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 7),
	(Word *) string_const("infer_type", 10),
	(Word *) string_const("infer_modes", 11),
	(Word *) string_const("obsolete", 8),
	(Word *) string_const("inline", 6),
	(Word *) string_const("dnf", 3),
	(Word *) string_const("magic", 5),
	(Word *) string_const("memo", 4)
};

Word * mercury_data_hlds_pred__common_43[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_19)
};

Word * mercury_data_hlds_pred__common_44[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("live", 4),
	(Word *) string_const("dead", 4)
};

Word * mercury_data_hlds_pred__common_45[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 9),
	(Word *) string_const("imported", 8),
	(Word *) string_const("opt_decl", 8),
	(Word *) string_const("opt_imported", 12),
	(Word *) string_const("abstract_imported", 17),
	(Word *) string_const("pseudo_imported", 15),
	(Word *) string_const("exported", 8),
	(Word *) string_const("abstract_exported", 17),
	(Word *) string_const("pseudo_exported", 15),
	(Word *) string_const("local", 5)
};

Word * mercury_data_hlds_pred__common_46[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("pragmas", 7),
	(Word *) string_const("clauses", 7),
	(Word *) string_const("none", 4)
};

Word * mercury_data_hlds_pred__common_47[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_clause_0
};

Word * mercury_data_hlds_pred__common_48[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_47),
	(Word *) string_const("clauses_info", 12)
};

Word * mercury_data_hlds_pred__common_49[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_hlds_pred__common_50[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_49),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_14),
	(Word *) string_const("clause", 6)
};

Word * mercury_data_hlds_pred__common_51[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("top_in", 6),
	(Word *) string_const("top_out", 7),
	(Word *) string_const("top_unused", 10)
};

Word * mercury_data_hlds_pred__common_52[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_arg_mode_0
};

Word * mercury_data_hlds_pred__common_53[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_52),
	(Word *) string_const("arg_info", 8)
};

BEGIN_MODULE(mercury__hlds_pred_module0)
	init_entry(mercury____Index___hlds_pred_arg_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_arg_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_arg_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module1)
	init_entry(mercury____Index___hlds_pred_clause_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_clause_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_clause_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module2)
	init_entry(mercury____Index___hlds_pred_clauses_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_clauses_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_clauses_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module3)
	init_entry(mercury____Index___hlds_pred_pred_proc_id_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_pred_proc_id_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_pred_proc_id_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module4)
	init_entry(mercury____Index___hlds_pred_pred_call_id_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_pred_call_id_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_pred_call_id_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module5)
	init_entry(mercury____Index___hlds_pred_proc_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_proc_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_proc_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module6)
	init_entry(mercury____Index___hlds_pred_pred_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_pred_pred_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_pred_pred_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module7)
	init_entry(mercury__hlds_pred__pred_info_init_13_0);
	init_label(mercury__hlds_pred__pred_info_init_13_0_i2);
	init_label(mercury__hlds_pred__pred_info_init_13_0_i3);
	init_label(mercury__hlds_pred__pred_info_init_13_0_i4);
	init_label(mercury__hlds_pred__pred_info_init_13_0_i5);
BEGIN_CODE

/* code for predicate 'pred_info_init'/13 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_init_13_0);
	incr_sp_push_msg(14, "pred_info_init");
	detstackvar(14) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_pred__pred_info_init_13_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_init_13_0));
	}
Define_label(mercury__hlds_pred__pred_info_init_13_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_init_13_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__hlds_pred__pred_info_init_13_0_i3,
		ENTRY(mercury__hlds_pred__pred_info_init_13_0));
	}
Define_label(mercury__hlds_pred__pred_info_init_13_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_init_13_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_util__sym_name_get_module_name_3_0);
	call_localret(ENTRY(mercury__prog_util__sym_name_get_module_name_3_0),
		mercury__hlds_pred__pred_info_init_13_0_i4,
		ENTRY(mercury__hlds_pred__pred_info_init_13_0));
	}
Define_label(mercury__hlds_pred__pred_info_init_13_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_init_13_0));
	if (((Integer) detstackvar(10) != ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_init_13_0_i5);
	tag_incr_hp(r2, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) r1;
	r1 = (Integer) r2;
	r3 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 13)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r2, ((Integer) 12)) = (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_1);
	field(mktag(0), (Integer) r2, ((Integer) 11)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r2, ((Integer) 10)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 9)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 8)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__hlds_pred__pred_info_init_13_0_i5);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	r3 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module8)
	init_entry(mercury__hlds_pred__pred_info_create_12_0);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i2);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i3);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i4);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i5);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i6);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i7);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i8);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i9);
	init_label(mercury__hlds_pred__pred_info_create_12_0_i10);
BEGIN_CODE

/* code for predicate 'pred_info_create'/12 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_create_12_0);
	incr_sp_push_msg(15, "pred_info_create");
	detstackvar(15) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_pred__pred_info_create_12_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__hlds_pred__pred_info_create_12_0_i3,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__make_hlds__next_mode_id_3_0);
	call_localret(ENTRY(mercury__make_hlds__next_mode_id_3_0),
		mercury__hlds_pred__pred_info_create_12_0_i4,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) r1;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	r5 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__hlds_pred__pred_info_create_12_0_i5,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__hlds_pred__pred_info_create_12_0_i6,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__hlds_pred__pred_info_create_12_0_i7,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i7);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__hlds_pred__pred_info_create_12_0_i8,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i8);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	r2 = (Integer) detstackvar(10);
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__hlds_pred__pred_info_create_12_0_i9,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i9);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__hlds_pred__pred_info_create_12_0_i10,
		ENTRY(mercury__hlds_pred__pred_info_create_12_0));
	}
Define_label(mercury__hlds_pred__pred_info_create_12_0_i10);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_create_12_0));
	r3 = (Integer) r1;
	tag_incr_hp(r2, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(11);
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) tempr1;
	tempr2 = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r2, ((Integer) 13)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r2, ((Integer) 12)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r2, ((Integer) 11)) = ((Integer) 1);
	field(mktag(0), (Integer) r2, ((Integer) 10)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 9)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r2, ((Integer) 8)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) tempr2;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) tempr2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module9)
	init_entry(mercury__hlds_pred__pred_info_set_15_0);
BEGIN_CODE

/* code for predicate 'pred_info_set'/15 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_15_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 13)) = (Integer) r14;
	field(mktag(0), (Integer) tempr1, ((Integer) 12)) = (Integer) r13;
	field(mktag(0), (Integer) tempr1, ((Integer) 11)) = (Integer) r12;
	field(mktag(0), (Integer) tempr1, ((Integer) 10)) = (Integer) r11;
	field(mktag(0), (Integer) tempr1, ((Integer) 9)) = (Integer) r10;
	field(mktag(0), (Integer) tempr1, ((Integer) 7)) = (Integer) r8;
	field(mktag(0), (Integer) tempr1, ((Integer) 6)) = (Integer) r7;
	field(mktag(0), (Integer) tempr1, ((Integer) 5)) = (Integer) r6;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 8)) = (Integer) r9;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module10)
	init_entry(mercury__hlds_pred__pred_info_module_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_module'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_module_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module11)
	init_entry(mercury__hlds_pred__pred_info_name_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_name'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_name_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module12)
	init_entry(mercury__hlds_pred__pred_info_arity_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_arity'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_arity_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module13)
	init_entry(mercury__hlds_pred__pred_info_procids_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_procids'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_procids_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	{
	Declare_entry(mercury__map__keys_2_0);
	tailcall(ENTRY(mercury__map__keys_2_0),
		ENTRY(mercury__hlds_pred__pred_info_procids_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module14)
	init_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	init_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i2);
	init_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i6);
	init_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i5);
	init_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i3);
	init_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i11);
	init_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i8);
BEGIN_CODE

/* code for predicate 'pred_info_non_imported_procids'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	incr_sp_push_msg(2, "pred_info_non_imported_procids");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__hlds_pred__pred_info_non_imported_procids_2_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0));
	}
Define_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_non_imported_procids_2_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i5);
Define_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i6);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i3);
Define_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i3);
	if (((Integer) r1 != ((Integer) 4)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i8);
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__hlds_pred__pred_info_non_imported_procids_2_0_i11,
		ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0));
	}
Define_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i11);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_non_imported_procids_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	tailcall(ENTRY(mercury__list__delete_all_3_1),
		ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0));
	}
Define_label(mercury__hlds_pred__pred_info_non_imported_procids_2_0_i8);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__hlds_pred__pred_info_procids_2_0),
		ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module15)
	init_entry(mercury__hlds_pred__pred_info_exported_procids_2_0);
	init_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i2);
	init_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i3);
	init_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i1000);
BEGIN_CODE

/* code for predicate 'pred_info_exported_procids'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_exported_procids_2_0);
	incr_sp_push_msg(2, "pred_info_exported_procids");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__hlds_pred__pred_info_exported_procids_2_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_exported_procids_2_0));
	}
Define_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_exported_procids_2_0));
	if (((Integer) r1 != ((Integer) 5)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_exported_procids_2_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__hlds_pred__pred_info_procids_2_0),
		ENTRY(mercury__hlds_pred__pred_info_exported_procids_2_0));
	}
Define_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r1 != ((Integer) 7)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_exported_procids_2_0_i1000);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_pred__common_2);
	proceed();
Define_label(mercury__hlds_pred__pred_info_exported_procids_2_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module16)
	init_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_arg_types'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module17)
	init_entry(mercury__hlds_pred__pred_info_set_arg_types_4_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_arg_types'/4 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_arg_types_4_0);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module18)
	init_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_clauses_info'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module19)
	init_entry(mercury__hlds_pred__pred_info_set_clauses_info_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_clauses_info'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_clauses_info_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module20)
	init_entry(mercury__hlds_pred__pred_info_procedures_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_procedures'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module21)
	init_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_procedures'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module22)
	init_entry(mercury__hlds_pred__pred_info_context_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_context'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_context_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module23)
	init_entry(mercury__hlds_pred__pred_info_import_status_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_import_status'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_import_status_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module24)
	init_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	init_label(mercury__hlds_pred__pred_info_is_imported_1_0_i2);
	init_label(mercury__hlds_pred__pred_info_is_imported_1_0_i3);
	init_label(mercury__hlds_pred__pred_info_is_imported_1_0_i1);
BEGIN_CODE

/* code for predicate 'pred_info_is_imported'/1 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	incr_sp_push_msg(1, "pred_info_is_imported");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__hlds_pred__pred_info_is_imported_1_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0));
	}
Define_label(mercury__hlds_pred__pred_info_is_imported_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_is_imported_1_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_is_imported_1_0_i3);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_is_imported_1_0_i1);
Define_label(mercury__hlds_pred__pred_info_is_imported_1_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__hlds_pred__pred_info_is_imported_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module25)
	init_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
	init_label(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i2);
	init_label(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i1000);
BEGIN_CODE

/* code for predicate 'pred_info_is_pseudo_imported'/1 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
	incr_sp_push_msg(1, "pred_info_is_pseudo_imported");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0));
	}
Define_label(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 != ((Integer) 4)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module26)
	init_entry(mercury__hlds_pred__pred_info_is_exported_1_0);
	init_label(mercury__hlds_pred__pred_info_is_exported_1_0_i2);
	init_label(mercury__hlds_pred__pred_info_is_exported_1_0_i1000);
BEGIN_CODE

/* code for predicate 'pred_info_is_exported'/1 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_is_exported_1_0);
	incr_sp_push_msg(1, "pred_info_is_exported");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__hlds_pred__pred_info_is_exported_1_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_is_exported_1_0));
	}
Define_label(mercury__hlds_pred__pred_info_is_exported_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_is_exported_1_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 != ((Integer) 5)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_is_exported_1_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_pred__pred_info_is_exported_1_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module27)
	init_entry(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0);
	init_label(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i2);
	init_label(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i1000);
BEGIN_CODE

/* code for predicate 'pred_info_is_pseudo_exported'/1 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0);
	incr_sp_push_msg(1, "pred_info_is_pseudo_exported");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0));
	}
Define_label(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 != ((Integer) 7)))
		GOTO_LABEL(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module28)
	init_entry(mercury__hlds_pred__pred_info_mark_as_external_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_mark_as_external'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_mark_as_external_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module29)
	init_entry(mercury__hlds_pred__pred_info_set_import_status_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_import_status'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_import_status_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module30)
	init_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_typevarset'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module31)
	init_entry(mercury__hlds_pred__pred_info_set_typevarset_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_typevarset'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_typevarset_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module32)
	init_entry(mercury__hlds_pred__pred_info_get_goal_type_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_get_goal_type'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_get_goal_type_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module33)
	init_entry(mercury__hlds_pred__pred_info_set_goal_type_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_goal_type'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_goal_type_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module34)
	init_entry(mercury__hlds_pred__pred_info_is_inlined_1_0);
	init_label(mercury__hlds_pred__pred_info_is_inlined_1_0_i2);
BEGIN_CODE

/* code for predicate 'pred_info_is_inlined'/1 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_is_inlined_1_0);
	incr_sp_push_msg(1, "pred_info_is_inlined");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__hlds_pred__pred_info_is_inlined_1_0_i2,
		ENTRY(mercury__hlds_pred__pred_info_is_inlined_1_0));
	}
Define_label(mercury__hlds_pred__pred_info_is_inlined_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_info_is_inlined_1_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__member_2_0);
	tailcall(ENTRY(mercury__list__member_2_0),
		ENTRY(mercury__hlds_pred__pred_info_is_inlined_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module35)
	init_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_get_marker_list'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module36)
	init_entry(mercury__hlds_pred__pred_info_set_marker_list_3_0);
BEGIN_CODE

/* code for predicate 'pred_info_set_marker_list'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_set_marker_list_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module37)
	init_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_get_is_pred_or_func'/2 in mode 0 */
Define_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module38)
	init_entry(mercury__hlds_pred__proc_info_init_6_0);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i2);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i3);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i4);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i5);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i6);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i7);
	init_label(mercury__hlds_pred__proc_info_init_6_0_i8);
BEGIN_CODE

/* code for predicate 'proc_info_init'/6 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_init_6_0);
	incr_sp_push_msg(11, "proc_info_init");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_pred__proc_info_init_6_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__hlds_pred__proc_info_init_6_0_i3,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__hlds_pred__proc_info_init_6_0_i4,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	r3 = (Integer) r1;
	r1 = string_const("HeadVar__", 9);
	r2 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__hlds_pred__make_n_fresh_vars_5_0),
		mercury__hlds_pred__proc_info_init_6_0_i5,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_pred__proc_info_init_6_0_i6,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_pred__proc_info_init_6_0_i7,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i7);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	detstackvar(10) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_3);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_pred__proc_info_init_6_0_i8,
		ENTRY(mercury__hlds_pred__proc_info_init_6_0));
	}
Define_label(mercury__hlds_pred__proc_info_init_6_0_i8);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_init_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 9)) = ((Integer) 6);
	field(mktag(0), (Integer) r1, ((Integer) 10)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module39)
	init_entry(mercury__hlds_pred__proc_info_set_15_0);
BEGIN_CODE

/* code for predicate 'proc_info_set'/15 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_15_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 13)) = (Integer) r14;
	field(mktag(0), (Integer) tempr1, ((Integer) 12)) = (Integer) r13;
	field(mktag(0), (Integer) tempr1, ((Integer) 11)) = (Integer) r12;
	field(mktag(0), (Integer) tempr1, ((Integer) 10)) = (Integer) r11;
	field(mktag(0), (Integer) tempr1, ((Integer) 9)) = (Integer) r10;
	field(mktag(0), (Integer) tempr1, ((Integer) 7)) = (Integer) r8;
	field(mktag(0), (Integer) tempr1, ((Integer) 6)) = (Integer) r7;
	field(mktag(0), (Integer) tempr1, ((Integer) 5)) = (Integer) r6;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 8)) = (Integer) r9;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module40)
	init_entry(mercury__hlds_pred__proc_info_create_9_0);
	init_label(mercury__hlds_pred__proc_info_create_9_0_i2);
	init_label(mercury__hlds_pred__proc_info_create_9_0_i3);
BEGIN_CODE

/* code for predicate 'proc_info_create'/9 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_create_9_0);
	incr_sp_push_msg(10, "proc_info_create");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_pred__proc_info_create_9_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_create_9_0));
	}
Define_label(mercury__hlds_pred__proc_info_create_9_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_create_9_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_pred__proc_info_create_9_0_i3,
		ENTRY(mercury__hlds_pred__proc_info_create_9_0));
	}
Define_label(mercury__hlds_pred__proc_info_create_9_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_create_9_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module41)
	init_entry(mercury__hlds_pred__proc_info_set_body_6_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_body'/6 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_body_6_0);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r5;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module42)
	init_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_declared_determinism'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module43)
	init_entry(mercury__hlds_pred__proc_info_inferred_determinism_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_inferred_determinism'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_inferred_determinism_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module44)
	init_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
	init_label(mercury__hlds_pred__proc_info_interface_determinism_2_0_i2);
	init_label(mercury__hlds_pred__proc_info_interface_determinism_2_0_i4);
BEGIN_CODE

/* code for predicate 'proc_info_interface_determinism'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
	incr_sp_push_msg(2, "proc_info_interface_determinism");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__hlds_pred__proc_info_interface_determinism_2_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_interface_determinism_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_interface_determinism_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_pred__proc_info_interface_determinism_2_0_i4);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__hlds_pred__proc_info_interface_determinism_2_0_i4);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__hlds_pred__proc_info_inferred_determinism_2_0),
		ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module45)
	init_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	init_label(mercury__hlds_pred__proc_info_interface_code_model_2_0_i2);
BEGIN_CODE

/* code for predicate 'proc_info_interface_code_model'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	incr_sp_push_msg(1, "proc_info_interface_code_model");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		mercury__hlds_pred__proc_info_interface_code_model_2_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_interface_code_model_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_interface_code_model_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	tailcall(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module46)
	init_entry(mercury__hlds_pred__proc_info_never_succeeds_2_0);
	init_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i2);
	init_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i5);
	init_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i4);
	init_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i1000);
BEGIN_CODE

/* code for predicate 'proc_info_never_succeeds'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_never_succeeds_2_0);
	incr_sp_push_msg(1, "proc_info_never_succeeds");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__hlds_pred__proc_info_never_succeeds_2_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_never_succeeds_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_never_succeeds_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_pred__proc_info_never_succeeds_2_0_i4);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__hlds_pred__proc_info_never_succeeds_2_0_i5,
		ENTRY(mercury__hlds_pred__proc_info_never_succeeds_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_never_succeeds_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_pred__proc_info_never_succeeds_2_0_i1000);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__hlds_pred__proc_info_never_succeeds_2_0_i1000);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module47)
	init_entry(mercury__hlds_pred__proc_info_variables_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_variables'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_variables_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module48)
	init_entry(mercury__hlds_pred__proc_info_set_varset_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_varset'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_varset_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module49)
	init_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_variables'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module50)
	init_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_vartypes'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module51)
	init_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_vartypes'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module52)
	init_entry(mercury__hlds_pred__proc_info_headvars_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_headvars'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module53)
	init_entry(mercury__hlds_pred__proc_info_set_headvars_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_headvars'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_headvars_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module54)
	init_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_argmodes'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module55)
	init_entry(mercury__hlds_pred__proc_info_set_argmodes_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_argmodes'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_argmodes_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module56)
	init_entry(mercury__hlds_pred__proc_info_arglives_3_0);
	init_label(mercury__hlds_pred__proc_info_arglives_3_0_i2);
	init_label(mercury__hlds_pred__proc_info_arglives_3_0_i3);
	init_label(mercury__hlds_pred__proc_info_arglives_3_0_i6);
BEGIN_CODE

/* code for predicate 'proc_info_arglives'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_arglives_3_0);
	incr_sp_push_msg(3, "proc_info_arglives");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_maybe_arglives_2_0),
		mercury__hlds_pred__proc_info_arglives_3_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_arglives_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_arglives_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_arglives_3_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_pred__proc_info_arglives_3_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__hlds_pred__proc_info_arglives_3_0_i3);
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__hlds_pred__proc_info_arglives_3_0_i6,
		ENTRY(mercury__hlds_pred__proc_info_arglives_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_arglives_3_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_arglives_3_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__mode_util__get_arg_lives_3_0);
	tailcall(ENTRY(mercury__mode_util__get_arg_lives_3_0),
		ENTRY(mercury__hlds_pred__proc_info_arglives_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module57)
	init_entry(mercury__hlds_pred__proc_info_maybe_arglives_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_maybe_arglives'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_maybe_arglives_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module58)
	init_entry(mercury__hlds_pred__proc_info_set_maybe_arglives_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_maybe_arglives'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_maybe_arglives_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module59)
	init_entry(mercury__hlds_pred__proc_info_goal_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_goal'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_goal_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module60)
	init_entry(mercury__hlds_pred__proc_info_context_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_context'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_context_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module61)
	init_entry(mercury__hlds_pred__proc_info_stack_slots_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_stack_slots'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_stack_slots_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module62)
	init_entry(mercury__hlds_pred__proc_info_liveness_info_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_liveness_info'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_liveness_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module63)
	init_entry(mercury__hlds_pred__proc_info_can_process_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_can_process'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_can_process_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module64)
	init_entry(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_inferred_determinism'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module65)
	init_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_goal'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module66)
	init_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_arg_info'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module67)
	init_entry(mercury__hlds_pred__proc_info_set_arg_info_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_arg_info'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_arg_info_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module68)
	init_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	init_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i2);
	init_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i3);
	init_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i4);
	init_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i5);
BEGIN_CODE

/* code for predicate 'proc_info_get_initial_instmap'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	incr_sp_push_msg(3, "proc_info_get_initial_instmap");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i3,
		ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i4,
		ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_prog_data__base_type_info_inst_0[];
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i5,
		ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_initial_instmap_3_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__instmap__from_assoc_list_2_0);
	tailcall(ENTRY(mercury__instmap__from_assoc_list_2_0),
		ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module69)
	init_entry(mercury__hlds_pred__proc_info_set_liveness_info_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_liveness_info'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_liveness_info_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module70)
	init_entry(mercury__hlds_pred__proc_info_set_stack_slots_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_stack_slots'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_stack_slots_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module71)
	init_entry(mercury__hlds_pred__proc_info_set_can_process_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_can_process'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_can_process_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module72)
	init_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
BEGIN_CODE

/* code for predicate 'proc_info_typeinfo_varmap'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module73)
	init_entry(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0);
BEGIN_CODE

/* code for predicate 'proc_info_set_typeinfo_varmap'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 14));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module74)
	init_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i2);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i3);
BEGIN_CODE

/* code for predicate 'proc_info_get_used_typeinfos_setwise'/3 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0);
	incr_sp_push_msg(2, "proc_info_get_used_typeinfos_setwise");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0),
		mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i3,
		ENTRY(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0));
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		ENTRY(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module75)
	init_entry(mercury__hlds_pred__proc_info_ensure_unique_names_2_0);
	init_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i2);
	init_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i3);
	init_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i4);
	init_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i5);
BEGIN_CODE

/* code for predicate 'proc_info_ensure_unique_names'/2 in mode 0 */
Define_entry(mercury__hlds_pred__proc_info_ensure_unique_names_2_0);
	incr_sp_push_msg(3, "proc_info_ensure_unique_names");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i2,
		ENTRY(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i3,
		ENTRY(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i4,
		ENTRY(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("p", 1);
	{
	Declare_entry(mercury__varset__ensure_unique_names_4_0);
	call_localret(ENTRY(mercury__varset__ensure_unique_names_4_0),
		mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i5,
		ENTRY(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	}
Define_label(mercury__hlds_pred__proc_info_ensure_unique_names_2_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__hlds_pred__proc_info_set_variables_3_0),
		ENTRY(mercury__hlds_pred__proc_info_ensure_unique_names_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module76)
	init_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i4);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i7);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i9);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i10);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i14);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i15);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i16);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i6);
	init_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i1004);
BEGIN_CODE

/* code for predicate 'proc_info_get_used_typeinfos_2'/3 in mode 0 */
Define_static(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i1004);
	incr_sp_push_msg(4, "proc_info_get_used_typeinfos_2");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i4,
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i7,
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i6);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__type_util__vars_2_0);
	call_localret(ENTRY(mercury__type_util__vars_2_0),
		mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i9,
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i9);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i10);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0,
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i10);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0),
		mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i14,
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i14);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__apply_to_list_3_0);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i15,
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i15);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	localcall(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0,
		LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i16),
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i16);
	update_prof_current_proc(LABEL(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__list__append_3_1);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i6);
	r1 = string_const("proc_info_get_used_typeinfos_2: var not found in typemap", 56);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0));
	}
Define_label(mercury__hlds_pred__proc_info_get_used_typeinfos_2_3_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module77)
	init_entry(mercury__hlds_pred__make_n_fresh_vars_5_0);
BEGIN_CODE

/* code for predicate 'make_n_fresh_vars'/5 in mode 0 */
Define_entry(mercury__hlds_pred__make_n_fresh_vars_5_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = ((Integer) 0);
	tailcall(STATIC(mercury__hlds_pred__make_n_fresh_vars_2_6_0),
		ENTRY(mercury__hlds_pred__make_n_fresh_vars_5_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module78)
	init_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
	init_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i2);
	init_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i5);
	init_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i8);
	init_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i4);
BEGIN_CODE

/* code for predicate 'pred_args_to_func_args'/3 in mode 0 */
Define_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
	incr_sp_push_msg(3, "pred_args_to_func_args");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__hlds_pred__pred_args_to_func_args_3_0_i2,
		ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0));
	}
Define_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_args_to_func_args_3_0));
	r2 = ((Integer) r1 - ((Integer) 1));
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__split_list_4_0);
	call_localret(ENTRY(mercury__list__split_list_4_0),
		mercury__hlds_pred__pred_args_to_func_args_3_0_i5,
		ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0));
	}
Define_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_args_to_func_args_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__hlds_pred__pred_args_to_func_args_3_0_i4);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_pred__pred_args_to_func_args_3_0_i4);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__hlds_pred__pred_args_to_func_args_3_0_i8,
		ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0));
	}
Define_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__hlds_pred__pred_args_to_func_args_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__hlds_pred__pred_args_to_func_args_3_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__hlds_pred__pred_args_to_func_args_3_0_i4);
	r1 = string_const("pred_args_to_func_args: function missing return value?", 54);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module79)
	init_entry(mercury__hlds_pred__make_n_fresh_vars_2_6_0);
	init_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i1000);
	init_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i4);
	init_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i5);
	init_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i6);
	init_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i7);
	init_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i8);
BEGIN_CODE

/* code for predicate 'make_n_fresh_vars_2'/6 in mode 0 */
Define_static(mercury__hlds_pred__make_n_fresh_vars_2_6_0);
	if (((Integer) r2 != (Integer) r3))
		GOTO_LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
Define_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i1000);
	incr_sp_push_msg(6, "make_n_fresh_vars_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = ((Integer) r2 + ((Integer) 1));
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__varset__new_var_3_0);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__hlds_pred__make_n_fresh_vars_2_6_0_i4,
		STATIC(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	}
Define_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__hlds_pred__make_n_fresh_vars_2_6_0_i5,
		STATIC(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	}
Define_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__hlds_pred__make_n_fresh_vars_2_6_0_i6,
		STATIC(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	}
Define_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__varset__name_var_4_0);
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__hlds_pred__make_n_fresh_vars_2_6_0_i7,
		STATIC(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	}
Define_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__hlds_pred__make_n_fresh_vars_2_6_0,
		LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i8),
		STATIC(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
Define_label(mercury__hlds_pred__make_n_fresh_vars_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__hlds_pred__make_n_fresh_vars_2_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module80)
	init_entry(mercury____Unify___hlds_pred__proc_id_0_0);
	init_label(mercury____Unify___hlds_pred__proc_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__proc_id_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_id_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__proc_id_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module81)
	init_entry(mercury____Index___hlds_pred__proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__proc_id_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__proc_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module82)
	init_entry(mercury____Compare___hlds_pred__proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__proc_id_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__proc_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module83)
	init_entry(mercury____Unify___hlds_pred__pred_id_0_0);
	init_label(mercury____Unify___hlds_pred__pred_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__pred_id_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_id_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__pred_id_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module84)
	init_entry(mercury____Index___hlds_pred__pred_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__pred_id_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__pred_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module85)
	init_entry(mercury____Compare___hlds_pred__pred_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__pred_id_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__pred_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module86)
	init_entry(mercury____Unify___hlds_pred__pred_info_0_0);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i2);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i4);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i6);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i8);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i10);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i12);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i14);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i16);
	init_label(mercury____Unify___hlds_pred__pred_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__pred_info_0_0);
	incr_sp_push_msg(27, "__Unify__");
	detstackvar(27) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(23) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(24) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(25) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(26) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i2,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i4,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___prog_data__condition_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__condition_0_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i6,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(16);
	{
		call_localret(STATIC(mercury____Unify___hlds_pred__clauses_info_0_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i8,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i10,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i12,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	if ((strcmp((char *)(Integer) detstackvar(6), (char *)(Integer) detstackvar(19)) !=0))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	if ((strcmp((char *)(Integer) detstackvar(7), (char *)(Integer) detstackvar(20)) !=0))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	if (((Integer) detstackvar(8) != (Integer) detstackvar(21)))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	if (((Integer) detstackvar(9) != (Integer) detstackvar(22)))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(23);
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i14,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	if (((Integer) detstackvar(11) != (Integer) detstackvar(24)))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(25);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__pred_info_0_0_i16,
		ENTRY(mercury____Unify___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	if (((Integer) detstackvar(13) != (Integer) detstackvar(26)))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	proceed();
Define_label(mercury____Unify___hlds_pred__pred_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module87)
	init_entry(mercury____Index___hlds_pred__pred_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__pred_info_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_pred_info_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__pred_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module88)
	init_entry(mercury____Compare___hlds_pred__pred_info_0_0);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i4);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i3);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i10);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i16);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i22);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i28);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i34);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i40);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i46);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i52);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i58);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i64);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i70);
	init_label(mercury____Compare___hlds_pred__pred_info_0_0_i76);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__pred_info_0_0);
	incr_sp_push_msg(27, "__Compare__");
	detstackvar(27) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(23) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(24) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(25) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(26) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i3);
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	proceed();
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i10,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Compare___prog_data__condition_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__condition_0_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i16,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(16);
	{
		call_localret(STATIC(mercury____Compare___hlds_pred__clauses_info_0_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i22,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i28,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i34,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i40,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i46,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i52,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i52);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(22);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i58,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i58);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(23);
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i64,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i64);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(24);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i70,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i70);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(25);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__pred_info_0_0_i76,
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_info_0_0_i76);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_info_0_0_i5);
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__pred_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module89)
	init_entry(mercury____Unify___hlds_pred__proc_info_0_0);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i2);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i4);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i6);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i8);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i10);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i12);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i14);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i16);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i18);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i20);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i22);
	init_label(mercury____Unify___hlds_pred__proc_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__proc_info_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(27, "__Unify__");
	detstackvar(27) = (Integer) succip;
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(23) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(24) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(25) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(26) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_determinism_0;
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i2,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i4,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i6,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i8,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i10,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i12,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i14,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i16,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i18,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	if (((Integer) detstackvar(9) != (Integer) detstackvar(22)))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	if (((Integer) detstackvar(10) != (Integer) detstackvar(23)))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(24);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i20,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(25);
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_pred__proc_info_0_0_i22,
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__proc_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__proc_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module90)
	init_entry(mercury____Index___hlds_pred__proc_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__proc_info_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_proc_info_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__proc_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module91)
	init_entry(mercury____Compare___hlds_pred__proc_info_0_0);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i4);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i3);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i10);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i16);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i22);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i28);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i34);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i40);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i46);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i52);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i58);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i64);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i70);
	init_label(mercury____Compare___hlds_pred__proc_info_0_0_i76);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__proc_info_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(27, "__Compare__");
	detstackvar(27) = (Integer) succip;
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(23) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(24) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(25) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(26) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_determinism_0;
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i3);
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	proceed();
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i10,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i16,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i22,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i28,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_pred__common_4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i34,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i40,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i46,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i52,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i52);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(22);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i58,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i58);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(23);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i64,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i64);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(24);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i70,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i70);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(25);
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_pred__proc_info_0_0_i76,
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__proc_info_0_0_i76);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__proc_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__proc_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_pred__proc_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module92)
	init_entry(mercury____Unify___hlds_pred__proc_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__proc_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_pred__proc_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module93)
	init_entry(mercury____Index___hlds_pred__proc_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__proc_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_pred__proc_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module94)
	init_entry(mercury____Compare___hlds_pred__proc_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__proc_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_pred__proc_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module95)
	init_entry(mercury____Unify___hlds_pred__pred_call_id_0_0);
	init_label(mercury____Unify___hlds_pred__pred_call_id_0_0_i2);
	init_label(mercury____Unify___hlds_pred__pred_call_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__pred_call_id_0_0);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury____Unify___hlds_pred__pred_call_id_0_0_i2,
		ENTRY(mercury____Unify___hlds_pred__pred_call_id_0_0));
	}
Define_label(mercury____Unify___hlds_pred__pred_call_id_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__pred_call_id_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_call_id_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_call_id_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_pred__pred_call_id_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module96)
	init_entry(mercury____Index___hlds_pred__pred_call_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__pred_call_id_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_pred_call_id_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__pred_call_id_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module97)
	init_entry(mercury____Compare___hlds_pred__pred_call_id_0_0);
	init_label(mercury____Compare___hlds_pred__pred_call_id_0_0_i4);
	init_label(mercury____Compare___hlds_pred__pred_call_id_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__pred_call_id_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
	call_localret(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		mercury____Compare___hlds_pred__pred_call_id_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__pred_call_id_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_call_id_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_call_id_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_call_id_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_pred__pred_call_id_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__pred_call_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module98)
	init_entry(mercury____Unify___hlds_pred__pred_proc_id_0_0);
	init_label(mercury____Unify___hlds_pred__pred_proc_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__pred_proc_id_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_proc_id_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_proc_id_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__pred_proc_id_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module99)
	init_entry(mercury____Index___hlds_pred__pred_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__pred_proc_id_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_pred_proc_id_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__pred_proc_id_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module100)
	init_entry(mercury____Compare___hlds_pred__pred_proc_id_0_0);
	init_label(mercury____Compare___hlds_pred__pred_proc_id_0_0_i4);
	init_label(mercury____Compare___hlds_pred__pred_proc_id_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__pred_proc_id_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__pred_proc_id_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0));
	}
Define_label(mercury____Compare___hlds_pred__pred_proc_id_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__pred_proc_id_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__pred_proc_id_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_pred__pred_proc_id_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module101)
	init_entry(mercury____Unify___hlds_pred__pred_proc_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__pred_proc_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_pred__pred_proc_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module102)
	init_entry(mercury____Index___hlds_pred__pred_proc_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__pred_proc_list_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___hlds_pred__pred_proc_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module103)
	init_entry(mercury____Compare___hlds_pred__pred_proc_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__pred_proc_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_pred__pred_proc_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module104)
	init_entry(mercury____Unify___hlds_pred__clauses_info_0_0);
	init_label(mercury____Unify___hlds_pred__clauses_info_0_0_i2);
	init_label(mercury____Unify___hlds_pred__clauses_info_0_0_i4);
	init_label(mercury____Unify___hlds_pred__clauses_info_0_0_i6);
	init_label(mercury____Unify___hlds_pred__clauses_info_0_0_i8);
	init_label(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__clauses_info_0_0);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___hlds_pred__clauses_info_0_0_i2,
		ENTRY(mercury____Unify___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clauses_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__clauses_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_pred__clauses_info_0_0_i4,
		ENTRY(mercury____Unify___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clauses_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__clauses_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___hlds_pred__clauses_info_0_0_i6,
		ENTRY(mercury____Unify___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clauses_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__clauses_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__clauses_info_0_0_i8,
		ENTRY(mercury____Unify___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clauses_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__clauses_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_clause_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clauses_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module105)
	init_entry(mercury____Index___hlds_pred__clauses_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__clauses_info_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_clauses_info_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__clauses_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module106)
	init_entry(mercury____Compare___hlds_pred__clauses_info_0_0);
	init_label(mercury____Compare___hlds_pred__clauses_info_0_0_i4);
	init_label(mercury____Compare___hlds_pred__clauses_info_0_0_i5);
	init_label(mercury____Compare___hlds_pred__clauses_info_0_0_i3);
	init_label(mercury____Compare___hlds_pred__clauses_info_0_0_i10);
	init_label(mercury____Compare___hlds_pred__clauses_info_0_0_i16);
	init_label(mercury____Compare___hlds_pred__clauses_info_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__clauses_info_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___hlds_pred__clauses_info_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__clauses_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__clauses_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__clauses_info_0_0_i3);
Define_label(mercury____Compare___hlds_pred__clauses_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_pred__clauses_info_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_pred__clauses_info_0_0_i10,
		ENTRY(mercury____Compare___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__clauses_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__clauses_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__clauses_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___hlds_pred__clauses_info_0_0_i16,
		ENTRY(mercury____Compare___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__clauses_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__clauses_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__clauses_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__clauses_info_0_0_i22,
		ENTRY(mercury____Compare___hlds_pred__clauses_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__clauses_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__clauses_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__clauses_info_0_0_i5);
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_clause_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_pred__clauses_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module107)
	init_entry(mercury____Unify___hlds_pred__clause_0_0);
	init_label(mercury____Unify___hlds_pred__clause_0_0_i2);
	init_label(mercury____Unify___hlds_pred__clause_0_0_i4);
	init_label(mercury____Unify___hlds_pred__clause_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__clause_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_pred__clause_0_0_i2,
		ENTRY(mercury____Unify___hlds_pred__clause_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clause_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__clause_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__clause_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_pred__clause_0_0_i4,
		ENTRY(mercury____Unify___hlds_pred__clause_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clause_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_pred__clause_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_pred__clause_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Unify___hlds_pred__clause_0_0));
	}
Define_label(mercury____Unify___hlds_pred__clause_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module108)
	init_entry(mercury____Index___hlds_pred__clause_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__clause_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_clause_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__clause_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module109)
	init_entry(mercury____Compare___hlds_pred__clause_0_0);
	init_label(mercury____Compare___hlds_pred__clause_0_0_i4);
	init_label(mercury____Compare___hlds_pred__clause_0_0_i5);
	init_label(mercury____Compare___hlds_pred__clause_0_0_i3);
	init_label(mercury____Compare___hlds_pred__clause_0_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__clause_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_pred__clause_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__clause_0_0));
	}
Define_label(mercury____Compare___hlds_pred__clause_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__clause_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__clause_0_0_i3);
Define_label(mercury____Compare___hlds_pred__clause_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_pred__clause_0_0_i3);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_pred__clause_0_0_i10,
		ENTRY(mercury____Compare___hlds_pred__clause_0_0));
	}
Define_label(mercury____Compare___hlds_pred__clause_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__clause_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__clause_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Compare___hlds_pred__clause_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module110)
	init_entry(mercury____Unify___hlds_pred__goal_type_0_0);
	init_label(mercury____Unify___hlds_pred__goal_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__goal_type_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__goal_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__goal_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module111)
	init_entry(mercury____Index___hlds_pred__goal_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__goal_type_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__goal_type_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module112)
	init_entry(mercury____Compare___hlds_pred__goal_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__goal_type_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__goal_type_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module113)
	init_entry(mercury____Unify___hlds_pred__liveness_info_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__liveness_info_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		ENTRY(mercury____Unify___hlds_pred__liveness_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module114)
	init_entry(mercury____Index___hlds_pred__liveness_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__liveness_info_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Index___set__set_1_0);
	tailcall(ENTRY(mercury____Index___set__set_1_0),
		ENTRY(mercury____Index___hlds_pred__liveness_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module115)
	init_entry(mercury____Compare___hlds_pred__liveness_info_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__liveness_info_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		ENTRY(mercury____Compare___hlds_pred__liveness_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module116)
	init_entry(mercury____Unify___hlds_pred__liveness_0_0);
	init_label(mercury____Unify___hlds_pred__liveness_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__liveness_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__liveness_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__liveness_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module117)
	init_entry(mercury____Index___hlds_pred__liveness_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__liveness_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__liveness_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module118)
	init_entry(mercury____Compare___hlds_pred__liveness_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__liveness_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__liveness_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module119)
	init_entry(mercury____Unify___hlds_pred__arg_info_0_0);
	init_label(mercury____Unify___hlds_pred__arg_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__arg_info_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_pred__arg_info_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_pred__arg_info_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__arg_info_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module120)
	init_entry(mercury____Index___hlds_pred__arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__arg_info_0_0);
	tailcall(STATIC(mercury____Index___hlds_pred_arg_info_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_pred__arg_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module121)
	init_entry(mercury____Compare___hlds_pred__arg_info_0_0);
	init_label(mercury____Compare___hlds_pred__arg_info_0_0_i4);
	init_label(mercury____Compare___hlds_pred__arg_info_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__arg_info_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_pred__arg_info_0_0_i4,
		ENTRY(mercury____Compare___hlds_pred__arg_info_0_0));
	}
Define_label(mercury____Compare___hlds_pred__arg_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__arg_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_pred__arg_info_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_pred__arg_info_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__arg_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module122)
	init_entry(mercury____Unify___hlds_pred__arg_mode_0_0);
	init_label(mercury____Unify___hlds_pred__arg_mode_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__arg_mode_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__arg_mode_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__arg_mode_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module123)
	init_entry(mercury____Index___hlds_pred__arg_mode_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__arg_mode_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__arg_mode_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module124)
	init_entry(mercury____Compare___hlds_pred__arg_mode_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__arg_mode_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__arg_mode_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module125)
	init_entry(mercury____Unify___hlds_pred__arg_loc_0_0);
	init_label(mercury____Unify___hlds_pred__arg_loc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__arg_loc_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__arg_loc_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__arg_loc_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module126)
	init_entry(mercury____Index___hlds_pred__arg_loc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__arg_loc_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__arg_loc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module127)
	init_entry(mercury____Compare___hlds_pred__arg_loc_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__arg_loc_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__arg_loc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module128)
	init_entry(mercury____Unify___hlds_pred__import_status_0_0);
	init_label(mercury____Unify___hlds_pred__import_status_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__import_status_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__import_status_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__import_status_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module129)
	init_entry(mercury____Index___hlds_pred__import_status_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__import_status_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__import_status_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module130)
	init_entry(mercury____Compare___hlds_pred__import_status_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__import_status_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__import_status_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module131)
	init_entry(mercury____Unify___hlds_pred__pred_or_func_0_0);
	init_label(mercury____Unify___hlds_pred__pred_or_func_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__pred_or_func_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__pred_or_func_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__pred_or_func_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module132)
	init_entry(mercury____Index___hlds_pred__pred_or_func_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__pred_or_func_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__pred_or_func_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module133)
	init_entry(mercury____Compare___hlds_pred__pred_or_func_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__pred_or_func_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__pred_or_func_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module134)
	init_entry(mercury____Unify___hlds_pred__marker_0_0);
	init_label(mercury____Unify___hlds_pred__marker_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__marker_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_pred__marker_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__marker_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module135)
	init_entry(mercury____Index___hlds_pred__marker_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__marker_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_pred__marker_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module136)
	init_entry(mercury____Compare___hlds_pred__marker_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__marker_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__marker_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module137)
	init_entry(mercury____Unify___hlds_pred__marker_status_0_0);
	init_label(mercury____Unify___hlds_pred__marker_status_0_0_i3);
	init_label(mercury____Unify___hlds_pred__marker_status_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_pred__marker_status_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_pred__marker_status_0_0_i3);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_pred__marker_status_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_pred__marker_status_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__marker_status_0_0_i3);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_pred__marker_status_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_pred__marker_status_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_pred__marker_status_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module138)
	init_entry(mercury____Index___hlds_pred__marker_status_0_0);
	init_label(mercury____Index___hlds_pred__marker_status_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_pred__marker_status_0_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_pred__marker_status_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_pred__marker_status_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_pred_module139)
	init_entry(mercury____Compare___hlds_pred__marker_status_0_0);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i2);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i3);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i4);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i6);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i11);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i9);
	init_label(mercury____Compare___hlds_pred__marker_status_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_pred__marker_status_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_pred__marker_status_0_0),
		mercury____Compare___hlds_pred__marker_status_0_0_i2,
		ENTRY(mercury____Compare___hlds_pred__marker_status_0_0));
	}
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__marker_status_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_pred__marker_status_0_0),
		mercury____Compare___hlds_pred__marker_status_0_0_i3,
		ENTRY(mercury____Compare___hlds_pred__marker_status_0_0));
	}
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_pred__marker_status_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_pred__marker_status_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_pred__marker_status_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i6);
	r3 = (Integer) detstackvar(1);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_pred__marker_status_0_0_i11);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_pred__marker_status_0_0_i1000);
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__marker_status_0_0));
	}
	}
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_pred__marker_status_0_0_i9);
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_pred__marker_status_0_0));
	}
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_pred__marker_status_0_0));
	}
Define_label(mercury____Compare___hlds_pred__marker_status_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_pred__marker_status_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__hlds_pred_bunch_0(void)
{
	mercury__hlds_pred_module0();
	mercury__hlds_pred_module1();
	mercury__hlds_pred_module2();
	mercury__hlds_pred_module3();
	mercury__hlds_pred_module4();
	mercury__hlds_pred_module5();
	mercury__hlds_pred_module6();
	mercury__hlds_pred_module7();
	mercury__hlds_pred_module8();
	mercury__hlds_pred_module9();
	mercury__hlds_pred_module10();
	mercury__hlds_pred_module11();
	mercury__hlds_pred_module12();
	mercury__hlds_pred_module13();
	mercury__hlds_pred_module14();
	mercury__hlds_pred_module15();
	mercury__hlds_pred_module16();
	mercury__hlds_pred_module17();
	mercury__hlds_pred_module18();
	mercury__hlds_pred_module19();
	mercury__hlds_pred_module20();
	mercury__hlds_pred_module21();
	mercury__hlds_pred_module22();
	mercury__hlds_pred_module23();
	mercury__hlds_pred_module24();
	mercury__hlds_pred_module25();
	mercury__hlds_pred_module26();
	mercury__hlds_pred_module27();
	mercury__hlds_pred_module28();
	mercury__hlds_pred_module29();
	mercury__hlds_pred_module30();
	mercury__hlds_pred_module31();
	mercury__hlds_pred_module32();
	mercury__hlds_pred_module33();
	mercury__hlds_pred_module34();
	mercury__hlds_pred_module35();
	mercury__hlds_pred_module36();
	mercury__hlds_pred_module37();
	mercury__hlds_pred_module38();
	mercury__hlds_pred_module39();
	mercury__hlds_pred_module40();
}

static void mercury__hlds_pred_bunch_1(void)
{
	mercury__hlds_pred_module41();
	mercury__hlds_pred_module42();
	mercury__hlds_pred_module43();
	mercury__hlds_pred_module44();
	mercury__hlds_pred_module45();
	mercury__hlds_pred_module46();
	mercury__hlds_pred_module47();
	mercury__hlds_pred_module48();
	mercury__hlds_pred_module49();
	mercury__hlds_pred_module50();
	mercury__hlds_pred_module51();
	mercury__hlds_pred_module52();
	mercury__hlds_pred_module53();
	mercury__hlds_pred_module54();
	mercury__hlds_pred_module55();
	mercury__hlds_pred_module56();
	mercury__hlds_pred_module57();
	mercury__hlds_pred_module58();
	mercury__hlds_pred_module59();
	mercury__hlds_pred_module60();
	mercury__hlds_pred_module61();
	mercury__hlds_pred_module62();
	mercury__hlds_pred_module63();
	mercury__hlds_pred_module64();
	mercury__hlds_pred_module65();
	mercury__hlds_pred_module66();
	mercury__hlds_pred_module67();
	mercury__hlds_pred_module68();
	mercury__hlds_pred_module69();
	mercury__hlds_pred_module70();
	mercury__hlds_pred_module71();
	mercury__hlds_pred_module72();
	mercury__hlds_pred_module73();
	mercury__hlds_pred_module74();
	mercury__hlds_pred_module75();
	mercury__hlds_pred_module76();
	mercury__hlds_pred_module77();
	mercury__hlds_pred_module78();
	mercury__hlds_pred_module79();
	mercury__hlds_pred_module80();
	mercury__hlds_pred_module81();
}

static void mercury__hlds_pred_bunch_2(void)
{
	mercury__hlds_pred_module82();
	mercury__hlds_pred_module83();
	mercury__hlds_pred_module84();
	mercury__hlds_pred_module85();
	mercury__hlds_pred_module86();
	mercury__hlds_pred_module87();
	mercury__hlds_pred_module88();
	mercury__hlds_pred_module89();
	mercury__hlds_pred_module90();
	mercury__hlds_pred_module91();
	mercury__hlds_pred_module92();
	mercury__hlds_pred_module93();
	mercury__hlds_pred_module94();
	mercury__hlds_pred_module95();
	mercury__hlds_pred_module96();
	mercury__hlds_pred_module97();
	mercury__hlds_pred_module98();
	mercury__hlds_pred_module99();
	mercury__hlds_pred_module100();
	mercury__hlds_pred_module101();
	mercury__hlds_pred_module102();
	mercury__hlds_pred_module103();
	mercury__hlds_pred_module104();
	mercury__hlds_pred_module105();
	mercury__hlds_pred_module106();
	mercury__hlds_pred_module107();
	mercury__hlds_pred_module108();
	mercury__hlds_pred_module109();
	mercury__hlds_pred_module110();
	mercury__hlds_pred_module111();
	mercury__hlds_pred_module112();
	mercury__hlds_pred_module113();
	mercury__hlds_pred_module114();
	mercury__hlds_pred_module115();
	mercury__hlds_pred_module116();
	mercury__hlds_pred_module117();
	mercury__hlds_pred_module118();
	mercury__hlds_pred_module119();
	mercury__hlds_pred_module120();
	mercury__hlds_pred_module121();
	mercury__hlds_pred_module122();
}

static void mercury__hlds_pred_bunch_3(void)
{
	mercury__hlds_pred_module123();
	mercury__hlds_pred_module124();
	mercury__hlds_pred_module125();
	mercury__hlds_pred_module126();
	mercury__hlds_pred_module127();
	mercury__hlds_pred_module128();
	mercury__hlds_pred_module129();
	mercury__hlds_pred_module130();
	mercury__hlds_pred_module131();
	mercury__hlds_pred_module132();
	mercury__hlds_pred_module133();
	mercury__hlds_pred_module134();
	mercury__hlds_pred_module135();
	mercury__hlds_pred_module136();
	mercury__hlds_pred_module137();
	mercury__hlds_pred_module138();
	mercury__hlds_pred_module139();
}

#endif

void mercury__hlds_pred__init(void); /* suppress gcc warning */
void mercury__hlds_pred__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__hlds_pred_bunch_0();
	mercury__hlds_pred_bunch_1();
	mercury__hlds_pred_bunch_2();
	mercury__hlds_pred_bunch_3();
#endif
}
