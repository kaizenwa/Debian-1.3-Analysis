/*
** Automatically generated from `jumpopt.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__jumpopt__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__jumpopt__main_5_0);
Declare_label(mercury__jumpopt__main_5_0_i2);
Declare_label(mercury__jumpopt__main_5_0_i3);
Declare_label(mercury__jumpopt__main_5_0_i4);
Declare_label(mercury__jumpopt__main_5_0_i5);
Declare_label(mercury__jumpopt__main_5_0_i6);
Declare_label(mercury__jumpopt__main_5_0_i7);
Declare_label(mercury__jumpopt__main_5_0_i8);
Declare_label(mercury__jumpopt__main_5_0_i9);
Declare_label(mercury__jumpopt__main_5_0_i10);
Declare_label(mercury__jumpopt__main_5_0_i11);
Declare_label(mercury__jumpopt__main_5_0_i12);
Declare_static(mercury__jumpopt__build_maps_15_0);
Declare_label(mercury__jumpopt__build_maps_15_0_i7);
Declare_label(mercury__jumpopt__build_maps_15_0_i12);
Declare_label(mercury__jumpopt__build_maps_15_0_i8);
Declare_label(mercury__jumpopt__build_maps_15_0_i13);
Declare_label(mercury__jumpopt__build_maps_15_0_i14);
Declare_label(mercury__jumpopt__build_maps_15_0_i15);
Declare_label(mercury__jumpopt__build_maps_15_0_i19);
Declare_label(mercury__jumpopt__build_maps_15_0_i16);
Declare_label(mercury__jumpopt__build_maps_15_0_i20);
Declare_label(mercury__jumpopt__build_maps_15_0_i23);
Declare_label(mercury__jumpopt__build_maps_15_0_i25);
Declare_label(mercury__jumpopt__build_maps_15_0_i22);
Declare_label(mercury__jumpopt__build_maps_15_0_i26);
Declare_label(mercury__jumpopt__build_maps_15_0_i29);
Declare_label(mercury__jumpopt__build_maps_15_0_i31);
Declare_label(mercury__jumpopt__build_maps_15_0_i28);
Declare_label(mercury__jumpopt__build_maps_15_0_i32);
Declare_label(mercury__jumpopt__build_maps_15_0_i35);
Declare_label(mercury__jumpopt__build_maps_15_0_i37);
Declare_label(mercury__jumpopt__build_maps_15_0_i34);
Declare_label(mercury__jumpopt__build_maps_15_0_i38);
Declare_label(mercury__jumpopt__build_maps_15_0_i42);
Declare_label(mercury__jumpopt__build_maps_15_0_i47);
Declare_label(mercury__jumpopt__build_maps_15_0_i48);
Declare_label(mercury__jumpopt__build_maps_15_0_i39);
Declare_label(mercury__jumpopt__build_maps_15_0_i1012);
Declare_label(mercury__jumpopt__build_maps_15_0_i1015);
Declare_static(mercury__jumpopt__build_forkmap_4_0);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i7);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i9);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i5);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i4);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i1005);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i1007);
Declare_static(mercury__jumpopt__instr_list_11_0);
Declare_label(mercury__jumpopt__instr_list_11_0_i4);
Declare_label(mercury__jumpopt__instr_list_11_0_i12);
Declare_label(mercury__jumpopt__instr_list_11_0_i15);
Declare_label(mercury__jumpopt__instr_list_11_0_i16);
Declare_label(mercury__jumpopt__instr_list_11_0_i10);
Declare_label(mercury__jumpopt__instr_list_11_0_i9);
Declare_label(mercury__jumpopt__instr_list_11_0_i20);
Declare_label(mercury__jumpopt__instr_list_11_0_i23);
Declare_label(mercury__jumpopt__instr_list_11_0_i18);
Declare_label(mercury__jumpopt__instr_list_11_0_i17);
Declare_label(mercury__jumpopt__instr_list_11_0_i29);
Declare_label(mercury__jumpopt__instr_list_11_0_i26);
Declare_label(mercury__jumpopt__instr_list_11_0_i25);
Declare_label(mercury__jumpopt__instr_list_11_0_i39);
Declare_label(mercury__jumpopt__instr_list_11_0_i41);
Declare_label(mercury__jumpopt__instr_list_11_0_i44);
Declare_label(mercury__jumpopt__instr_list_11_0_i43);
Declare_label(mercury__jumpopt__instr_list_11_0_i38);
Declare_label(mercury__jumpopt__instr_list_11_0_i5);
Declare_label(mercury__jumpopt__instr_list_11_0_i57);
Declare_label(mercury__jumpopt__instr_list_11_0_i56);
Declare_label(mercury__jumpopt__instr_list_11_0_i63);
Declare_label(mercury__jumpopt__instr_list_11_0_i60);
Declare_label(mercury__jumpopt__instr_list_11_0_i59);
Declare_label(mercury__jumpopt__instr_list_11_0_i67);
Declare_label(mercury__jumpopt__instr_list_11_0_i69);
Declare_label(mercury__jumpopt__instr_list_11_0_i66);
Declare_label(mercury__jumpopt__instr_list_11_0_i73);
Declare_label(mercury__jumpopt__instr_list_11_0_i75);
Declare_label(mercury__jumpopt__instr_list_11_0_i72);
Declare_label(mercury__jumpopt__instr_list_11_0_i79);
Declare_label(mercury__jumpopt__instr_list_11_0_i78);
Declare_label(mercury__jumpopt__instr_list_11_0_i84);
Declare_label(mercury__jumpopt__instr_list_11_0_i86);
Declare_label(mercury__jumpopt__instr_list_11_0_i87);
Declare_label(mercury__jumpopt__instr_list_11_0_i89);
Declare_label(mercury__jumpopt__instr_list_11_0_i83);
Declare_label(mercury__jumpopt__instr_list_11_0_i93);
Declare_label(mercury__jumpopt__instr_list_11_0_i95);
Declare_label(mercury__jumpopt__instr_list_11_0_i96);
Declare_label(mercury__jumpopt__instr_list_11_0_i97);
Declare_label(mercury__jumpopt__instr_list_11_0_i98);
Declare_label(mercury__jumpopt__instr_list_11_0_i103);
Declare_label(mercury__jumpopt__instr_list_11_0_i102);
Declare_label(mercury__jumpopt__instr_list_11_0_i106);
Declare_label(mercury__jumpopt__instr_list_11_0_i109);
Declare_label(mercury__jumpopt__instr_list_11_0_i112);
Declare_label(mercury__jumpopt__instr_list_11_0_i108);
Declare_label(mercury__jumpopt__instr_list_11_0_i92);
Declare_label(mercury__jumpopt__instr_list_11_0_i51);
Declare_label(mercury__jumpopt__instr_list_11_0_i124);
Declare_label(mercury__jumpopt__instr_list_11_0_i128);
Declare_label(mercury__jumpopt__instr_list_11_0_i125);
Declare_label(mercury__jumpopt__instr_list_11_0_i121);
Declare_label(mercury__jumpopt__instr_list_11_0_i136);
Declare_label(mercury__jumpopt__instr_list_11_0_i138);
Declare_label(mercury__jumpopt__instr_list_11_0_i141);
Declare_label(mercury__jumpopt__instr_list_11_0_i143);
Declare_label(mercury__jumpopt__instr_list_11_0_i145);
Declare_label(mercury__jumpopt__instr_list_11_0_i147);
Declare_label(mercury__jumpopt__instr_list_11_0_i149);
Declare_label(mercury__jumpopt__instr_list_11_0_i150);
Declare_label(mercury__jumpopt__instr_list_11_0_i156);
Declare_label(mercury__jumpopt__instr_list_11_0_i154);
Declare_label(mercury__jumpopt__instr_list_11_0_i153);
Declare_label(mercury__jumpopt__instr_list_11_0_i161);
Declare_label(mercury__jumpopt__instr_list_11_0_i140);
Declare_label(mercury__jumpopt__instr_list_11_0_i166);
Declare_label(mercury__jumpopt__instr_list_11_0_i165);
Declare_label(mercury__jumpopt__instr_list_11_0_i168);
Declare_label(mercury__jumpopt__instr_list_11_0_i130);
Declare_label(mercury__jumpopt__instr_list_11_0_i175);
Declare_label(mercury__jumpopt__instr_list_11_0_i176);
Declare_label(mercury__jumpopt__instr_list_11_0_i179);
Declare_label(mercury__jumpopt__instr_list_11_0_i180);
Declare_label(mercury__jumpopt__instr_list_11_0_i181);
Declare_label(mercury__jumpopt__instr_list_11_0_i182);
Declare_label(mercury__jumpopt__instr_list_11_0_i1001);
Declare_static(mercury__jumpopt__needs_workaround_2_0);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i1046);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i10);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i9);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i16);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i19);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i14);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i13);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i30);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i33);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i2);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i1042);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i1);
Declare_static(mercury__jumpopt__adjust_livevals_3_0);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i5);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i10);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i9);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i3);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i1005);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i2);
Declare_static(mercury__jumpopt__short_labels_4_0);
Declare_label(mercury__jumpopt__short_labels_4_0_i4);
Declare_label(mercury__jumpopt__short_labels_4_0_i5);
Declare_label(mercury__jumpopt__short_labels_4_0_i8);
Declare_label(mercury__jumpopt__short_labels_4_0_i7);
Declare_label(mercury__jumpopt__short_labels_4_0_i10);
Declare_label(mercury__jumpopt__short_labels_4_0_i11);
Declare_label(mercury__jumpopt__short_labels_4_0_i12);
Declare_label(mercury__jumpopt__short_labels_4_0_i1005);
Declare_label(mercury__jumpopt__short_labels_4_0_i1006);
Declare_static(mercury__jumpopt__final_dest_5_0);
Declare_static(mercury__jumpopt__final_dest_2_6_0);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i1001);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i4);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i8);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i12);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i3);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i15);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_jumpopt__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
Word * mercury_data_jumpopt__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_jumpopt__common_2[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0)
};

Word * mercury_data_jumpopt__common_3[] = {
	(Word *) string_const("", 0)
};

Word mercury_data_jumpopt__common_4[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 2)))
};

Word * mercury_data_jumpopt__common_5[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_4)
};

Word * mercury_data_jumpopt__common_6[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_5)
};

Word * mercury_data_jumpopt__common_7[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_6)
};

Word * mercury_data_jumpopt__common_8[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_7),
	(Word *) string_const("discard this frame", 18)
};

Word * mercury_data_jumpopt__common_9[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_4)
};

Word * mercury_data_jumpopt__common_10[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_9)
};

Word * mercury_data_jumpopt__common_11[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_10)
};

Word * mercury_data_jumpopt__common_12[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_11),
	(Word *) string_const("setup PC on return from tailcall", 32)
};

Word * mercury_data_jumpopt__common_13[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_4)
};

Word * mercury_data_jumpopt__common_14[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_13)
};

Word * mercury_data_jumpopt__common_15[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 2))),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_14)
};

Word * mercury_data_jumpopt__common_16[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_15),
	(Word *) string_const("setup curfr on return from tailcall", 35)
};

Word mercury_data_jumpopt__common_17[] = {
	((Integer) 6),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_jumpopt__common_18[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_jumpopt__common_17),
	(Word *) string_const("shortcircuit", 12)
};

Word * mercury_data_jumpopt__common_19[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_18),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_jumpopt__common_20[] = {
	((Integer) 1)
};

Word * mercury_data_jumpopt__common_21[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_20)
};

BEGIN_MODULE(mercury__jumpopt_module0)
	init_entry(mercury__jumpopt__main_5_0);
	init_label(mercury__jumpopt__main_5_0_i2);
	init_label(mercury__jumpopt__main_5_0_i3);
	init_label(mercury__jumpopt__main_5_0_i4);
	init_label(mercury__jumpopt__main_5_0_i5);
	init_label(mercury__jumpopt__main_5_0_i6);
	init_label(mercury__jumpopt__main_5_0_i7);
	init_label(mercury__jumpopt__main_5_0_i8);
	init_label(mercury__jumpopt__main_5_0_i9);
	init_label(mercury__jumpopt__main_5_0_i10);
	init_label(mercury__jumpopt__main_5_0_i11);
	init_label(mercury__jumpopt__main_5_0_i12);
BEGIN_CODE

/* code for predicate 'jumpopt__main'/5 in mode 0 */
Define_entry(mercury__jumpopt__main_5_0);
	incr_sp_push_msg(9, "jumpopt__main");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i2,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i2);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_1);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i3,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i3);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i4,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i4);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(6) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i5,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(7) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i6,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i6);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(8) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i7,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__jumpopt__build_maps_15_0),
		mercury__jumpopt__main_5_0_i8,
		ENTRY(mercury__jumpopt__main_5_0));
Define_label(mercury__jumpopt__main_5_0_i8);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__main_5_0_i9,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__jumpopt__build_forkmap_4_0),
		mercury__jumpopt__main_5_0_i10,
		ENTRY(mercury__jumpopt__main_5_0));
Define_label(mercury__jumpopt__main_5_0_i10);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_jumpopt__common_3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__jumpopt__instr_list_11_0),
		mercury__jumpopt__main_5_0_i11,
		ENTRY(mercury__jumpopt__main_5_0));
Define_label(mercury__jumpopt__main_5_0_i11);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__filter_out_bad_livevals_2_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_bad_livevals_2_0),
		mercury__jumpopt__main_5_0_i12,
		ENTRY(mercury__jumpopt__main_5_0));
	}
Define_label(mercury__jumpopt__main_5_0_i12);
	update_prof_current_proc(LABEL(mercury__jumpopt__main_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module1)
	init_entry(mercury__jumpopt__build_maps_15_0);
	init_label(mercury__jumpopt__build_maps_15_0_i7);
	init_label(mercury__jumpopt__build_maps_15_0_i12);
	init_label(mercury__jumpopt__build_maps_15_0_i8);
	init_label(mercury__jumpopt__build_maps_15_0_i13);
	init_label(mercury__jumpopt__build_maps_15_0_i14);
	init_label(mercury__jumpopt__build_maps_15_0_i15);
	init_label(mercury__jumpopt__build_maps_15_0_i19);
	init_label(mercury__jumpopt__build_maps_15_0_i16);
	init_label(mercury__jumpopt__build_maps_15_0_i20);
	init_label(mercury__jumpopt__build_maps_15_0_i23);
	init_label(mercury__jumpopt__build_maps_15_0_i25);
	init_label(mercury__jumpopt__build_maps_15_0_i22);
	init_label(mercury__jumpopt__build_maps_15_0_i26);
	init_label(mercury__jumpopt__build_maps_15_0_i29);
	init_label(mercury__jumpopt__build_maps_15_0_i31);
	init_label(mercury__jumpopt__build_maps_15_0_i28);
	init_label(mercury__jumpopt__build_maps_15_0_i32);
	init_label(mercury__jumpopt__build_maps_15_0_i35);
	init_label(mercury__jumpopt__build_maps_15_0_i37);
	init_label(mercury__jumpopt__build_maps_15_0_i34);
	init_label(mercury__jumpopt__build_maps_15_0_i38);
	init_label(mercury__jumpopt__build_maps_15_0_i42);
	init_label(mercury__jumpopt__build_maps_15_0_i47);
	init_label(mercury__jumpopt__build_maps_15_0_i48);
	init_label(mercury__jumpopt__build_maps_15_0_i39);
	init_label(mercury__jumpopt__build_maps_15_0_i1012);
	init_label(mercury__jumpopt__build_maps_15_0_i1015);
BEGIN_CODE

/* code for predicate 'jumpopt__build_maps'/15 in mode 0 */
Define_static(mercury__jumpopt__build_maps_15_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i1012);
	r10 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i1015);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i1015);
	incr_sp_push_msg(15, "jumpopt__build_maps");
	detstackvar(15) = (Integer) succip;
	detstackvar(10) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	r1 = (Integer) r10;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__build_maps_15_0_i7,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
	}
Define_label(mercury__jumpopt__build_maps_15_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i8);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i8);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_1);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i12,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i12);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i14);
Define_label(mercury__jumpopt__build_maps_15_0_i8);
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_1);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i13,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i13);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
Define_label(mercury__jumpopt__build_maps_15_0_i14);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(5) = (Integer) r1;
	detstackvar(11) = (Integer) r11;
	{
	Declare_entry(mercury__opt_util__skip_comments_livevals_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_livevals_2_0),
		mercury__jumpopt__build_maps_15_0_i15,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i15);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i16);
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i19,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i19);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i20);
Define_label(mercury__jumpopt__build_maps_15_0_i16);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(11);
	r11 = (Integer) detstackvar(3);
Define_label(mercury__jumpopt__build_maps_15_0_i20);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(9) = (Integer) r8;
	detstackvar(10) = (Integer) r9;
	detstackvar(5) = (Integer) r1;
	detstackvar(11) = (Integer) r10;
	detstackvar(3) = (Integer) r11;
	{
	Declare_entry(mercury__opt_util__is_proceed_next_2_0);
	call_localret(ENTRY(mercury__opt_util__is_proceed_next_2_0),
		mercury__jumpopt__build_maps_15_0_i23,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i23);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i22);
	r5 = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i25,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i25);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r10 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i26);
Define_label(mercury__jumpopt__build_maps_15_0_i22);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r10 = (Integer) detstackvar(3);
	r11 = (Integer) detstackvar(6);
Define_label(mercury__jumpopt__build_maps_15_0_i26);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(5) = (Integer) r1;
	detstackvar(11) = (Integer) r9;
	detstackvar(3) = (Integer) r10;
	detstackvar(12) = (Integer) r11;
	{
	Declare_entry(mercury__opt_util__is_sdproceed_next_2_0);
	call_localret(ENTRY(mercury__opt_util__is_sdproceed_next_2_0),
		mercury__jumpopt__build_maps_15_0_i29,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i29);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i28);
	r5 = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i31,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i31);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(8);
	r6 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i32);
Define_label(mercury__jumpopt__build_maps_15_0_i28);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(8);
	r6 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(12);
	r11 = (Integer) detstackvar(7);
Define_label(mercury__jumpopt__build_maps_15_0_i32);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(8) = (Integer) r5;
	detstackvar(9) = (Integer) r6;
	detstackvar(10) = (Integer) r7;
	detstackvar(5) = (Integer) r1;
	detstackvar(11) = (Integer) r8;
	detstackvar(3) = (Integer) r9;
	detstackvar(12) = (Integer) r10;
	detstackvar(13) = (Integer) r11;
	{
	Declare_entry(mercury__opt_util__is_succeed_next_2_0);
	call_localret(ENTRY(mercury__opt_util__is_succeed_next_2_0),
		mercury__jumpopt__build_maps_15_0_i35,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i35);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i34);
	r5 = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i37,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i37);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i38);
Define_label(mercury__jumpopt__build_maps_15_0_i34);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(8);
Define_label(mercury__jumpopt__build_maps_15_0_i38);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i39);
	if ((tag((Integer) r6) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i42);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i39);
Define_label(mercury__jumpopt__build_maps_15_0_i42);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(9) = (Integer) r5;
	detstackvar(10) = (Integer) r6;
	detstackvar(11) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(12) = (Integer) r9;
	detstackvar(13) = (Integer) r10;
	detstackvar(14) = (Integer) r11;
	{
	Declare_entry(mercury__opt_util__find_no_fallthrough_2_0);
	call_localret(ENTRY(mercury__opt_util__find_no_fallthrough_2_0),
		mercury__jumpopt__build_maps_15_0_i47,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i47);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i48,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i48);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	localtailcall(mercury__jumpopt__build_maps_15_0,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i39);
	r1 = (Integer) r5;
	r5 = (Integer) r4;
	r6 = (Integer) r7;
	r4 = (Integer) r8;
	r7 = (Integer) r9;
	r8 = (Integer) r10;
	r9 = (Integer) r11;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	localtailcall(mercury__jumpopt__build_maps_15_0,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i1012);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	r3 = (Integer) r6;
	r4 = (Integer) r7;
	r5 = (Integer) r8;
	r6 = (Integer) r9;
	proceed();
Define_label(mercury__jumpopt__build_maps_15_0_i1015);
	r1 = (Integer) r10;
	localtailcall(mercury__jumpopt__build_maps_15_0,
		STATIC(mercury__jumpopt__build_maps_15_0));
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module2)
	init_entry(mercury__jumpopt__build_forkmap_4_0);
	init_label(mercury__jumpopt__build_forkmap_4_0_i7);
	init_label(mercury__jumpopt__build_forkmap_4_0_i9);
	init_label(mercury__jumpopt__build_forkmap_4_0_i5);
	init_label(mercury__jumpopt__build_forkmap_4_0_i4);
	init_label(mercury__jumpopt__build_forkmap_4_0_i1005);
	init_label(mercury__jumpopt__build_forkmap_4_0_i1007);
BEGIN_CODE

/* code for predicate 'jumpopt__build_forkmap'/4 in mode 0 */
Define_static(mercury__jumpopt__build_forkmap_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i1005);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i1007);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i1007);
	incr_sp_push_msg(5, "jumpopt__build_forkmap");
	detstackvar(5) = (Integer) succip;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	r1 = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__opt_util__is_forkproceed_next_3_0);
	call_localret(ENTRY(mercury__opt_util__is_forkproceed_next_3_0),
		mercury__jumpopt__build_forkmap_4_0_i7,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
	}
	}
Define_label(mercury__jumpopt__build_forkmap_4_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_forkmap_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i5);
	r5 = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__jumpopt__build_forkmap_4_0_i9,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
	}
Define_label(mercury__jumpopt__build_forkmap_4_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_forkmap_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__jumpopt__build_forkmap_4_0,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
Define_label(mercury__jumpopt__build_forkmap_4_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
Define_label(mercury__jumpopt__build_forkmap_4_0_i4);
	r1 = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__jumpopt__build_forkmap_4_0,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
Define_label(mercury__jumpopt__build_forkmap_4_0_i1005);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__jumpopt__build_forkmap_4_0_i1007);
	r1 = (Integer) r4;
	localtailcall(mercury__jumpopt__build_forkmap_4_0,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module3)
	init_entry(mercury__jumpopt__instr_list_11_0);
	init_label(mercury__jumpopt__instr_list_11_0_i4);
	init_label(mercury__jumpopt__instr_list_11_0_i12);
	init_label(mercury__jumpopt__instr_list_11_0_i15);
	init_label(mercury__jumpopt__instr_list_11_0_i16);
	init_label(mercury__jumpopt__instr_list_11_0_i10);
	init_label(mercury__jumpopt__instr_list_11_0_i9);
	init_label(mercury__jumpopt__instr_list_11_0_i20);
	init_label(mercury__jumpopt__instr_list_11_0_i23);
	init_label(mercury__jumpopt__instr_list_11_0_i18);
	init_label(mercury__jumpopt__instr_list_11_0_i17);
	init_label(mercury__jumpopt__instr_list_11_0_i29);
	init_label(mercury__jumpopt__instr_list_11_0_i26);
	init_label(mercury__jumpopt__instr_list_11_0_i25);
	init_label(mercury__jumpopt__instr_list_11_0_i39);
	init_label(mercury__jumpopt__instr_list_11_0_i41);
	init_label(mercury__jumpopt__instr_list_11_0_i44);
	init_label(mercury__jumpopt__instr_list_11_0_i43);
	init_label(mercury__jumpopt__instr_list_11_0_i38);
	init_label(mercury__jumpopt__instr_list_11_0_i5);
	init_label(mercury__jumpopt__instr_list_11_0_i57);
	init_label(mercury__jumpopt__instr_list_11_0_i56);
	init_label(mercury__jumpopt__instr_list_11_0_i63);
	init_label(mercury__jumpopt__instr_list_11_0_i60);
	init_label(mercury__jumpopt__instr_list_11_0_i59);
	init_label(mercury__jumpopt__instr_list_11_0_i67);
	init_label(mercury__jumpopt__instr_list_11_0_i69);
	init_label(mercury__jumpopt__instr_list_11_0_i66);
	init_label(mercury__jumpopt__instr_list_11_0_i73);
	init_label(mercury__jumpopt__instr_list_11_0_i75);
	init_label(mercury__jumpopt__instr_list_11_0_i72);
	init_label(mercury__jumpopt__instr_list_11_0_i79);
	init_label(mercury__jumpopt__instr_list_11_0_i78);
	init_label(mercury__jumpopt__instr_list_11_0_i84);
	init_label(mercury__jumpopt__instr_list_11_0_i86);
	init_label(mercury__jumpopt__instr_list_11_0_i87);
	init_label(mercury__jumpopt__instr_list_11_0_i89);
	init_label(mercury__jumpopt__instr_list_11_0_i83);
	init_label(mercury__jumpopt__instr_list_11_0_i93);
	init_label(mercury__jumpopt__instr_list_11_0_i95);
	init_label(mercury__jumpopt__instr_list_11_0_i96);
	init_label(mercury__jumpopt__instr_list_11_0_i97);
	init_label(mercury__jumpopt__instr_list_11_0_i98);
	init_label(mercury__jumpopt__instr_list_11_0_i103);
	init_label(mercury__jumpopt__instr_list_11_0_i102);
	init_label(mercury__jumpopt__instr_list_11_0_i106);
	init_label(mercury__jumpopt__instr_list_11_0_i109);
	init_label(mercury__jumpopt__instr_list_11_0_i112);
	init_label(mercury__jumpopt__instr_list_11_0_i108);
	init_label(mercury__jumpopt__instr_list_11_0_i92);
	init_label(mercury__jumpopt__instr_list_11_0_i51);
	init_label(mercury__jumpopt__instr_list_11_0_i124);
	init_label(mercury__jumpopt__instr_list_11_0_i128);
	init_label(mercury__jumpopt__instr_list_11_0_i125);
	init_label(mercury__jumpopt__instr_list_11_0_i121);
	init_label(mercury__jumpopt__instr_list_11_0_i136);
	init_label(mercury__jumpopt__instr_list_11_0_i138);
	init_label(mercury__jumpopt__instr_list_11_0_i141);
	init_label(mercury__jumpopt__instr_list_11_0_i143);
	init_label(mercury__jumpopt__instr_list_11_0_i145);
	init_label(mercury__jumpopt__instr_list_11_0_i147);
	init_label(mercury__jumpopt__instr_list_11_0_i149);
	init_label(mercury__jumpopt__instr_list_11_0_i150);
	init_label(mercury__jumpopt__instr_list_11_0_i156);
	init_label(mercury__jumpopt__instr_list_11_0_i154);
	init_label(mercury__jumpopt__instr_list_11_0_i153);
	init_label(mercury__jumpopt__instr_list_11_0_i161);
	init_label(mercury__jumpopt__instr_list_11_0_i140);
	init_label(mercury__jumpopt__instr_list_11_0_i166);
	init_label(mercury__jumpopt__instr_list_11_0_i165);
	init_label(mercury__jumpopt__instr_list_11_0_i168);
	init_label(mercury__jumpopt__instr_list_11_0_i130);
	init_label(mercury__jumpopt__instr_list_11_0_i175);
	init_label(mercury__jumpopt__instr_list_11_0_i176);
	init_label(mercury__jumpopt__instr_list_11_0_i179);
	init_label(mercury__jumpopt__instr_list_11_0_i180);
	init_label(mercury__jumpopt__instr_list_11_0_i181);
	init_label(mercury__jumpopt__instr_list_11_0_i182);
	init_label(mercury__jumpopt__instr_list_11_0_i1001);
BEGIN_CODE

/* code for predicate 'jumpopt__instr_list'/11 in mode 0 */
Define_static(mercury__jumpopt__instr_list_11_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i1001);
	incr_sp_push_msg(28, "jumpopt__instr_list");
	detstackvar(28) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(9) = (Integer) tempr1;
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(12) = (Integer) r1;
	detstackvar(11) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = string_const(" (redirected return)", 20);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_11_0_i4,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
	}
Define_label(mercury__jumpopt__instr_list_11_0_i4);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if ((tag((Integer) detstackvar(11)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i5);
	if (((Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i5);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 2));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i5);
	r3 = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 4));
	r4 = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 3));
	r5 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r6 = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i9);
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) r6;
	detstackvar(15) = (Integer) r5;
	detstackvar(16) = (Integer) r4;
	detstackvar(17) = (Integer) r3;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i12,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i12);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i10);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i10);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__filter_out_livevals_2_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_livevals_2_0),
		mercury__jumpopt__instr_list_11_0_i15,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i15);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = string_const("", 0);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
	}
Define_label(mercury__jumpopt__instr_list_11_0_i16);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	r12 = ((Integer) 0);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i10);
	r1 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(14);
	r5 = (Integer) detstackvar(15);
	r4 = (Integer) detstackvar(16);
	r3 = (Integer) detstackvar(17);
Define_label(mercury__jumpopt__instr_list_11_0_i9);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i17);
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) r6;
	detstackvar(15) = (Integer) r5;
	detstackvar(16) = (Integer) r4;
	detstackvar(17) = (Integer) r3;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i20,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i20);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i18);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i18);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__filter_out_livevals_2_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_livevals_2_0),
		mercury__jumpopt__instr_list_11_0_i23,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i23);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = string_const("", 0);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
	}
Define_label(mercury__jumpopt__instr_list_11_0_i18);
	r1 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(14);
	r5 = (Integer) detstackvar(15);
	r4 = (Integer) detstackvar(16);
	r3 = (Integer) detstackvar(17);
Define_label(mercury__jumpopt__instr_list_11_0_i17);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i25);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i25);
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) r6;
	detstackvar(15) = (Integer) r5;
	detstackvar(16) = (Integer) r4;
	detstackvar(17) = (Integer) r3;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i29,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i29);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r2, ((Integer) 1)), ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r2, ((Integer) 1)), ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r2, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i26);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_8);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_12);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_16);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = string_const("", 0);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r16, ((Integer) 1)) = (Integer) detstackvar(13);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) tempr1;
	r12 = ((Integer) 0);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
	}
Define_label(mercury__jumpopt__instr_list_11_0_i26);
	r1 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(14);
	r5 = (Integer) detstackvar(15);
	r4 = (Integer) detstackvar(16);
	r3 = (Integer) detstackvar(17);
Define_label(mercury__jumpopt__instr_list_11_0_i25);
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) r6;
	detstackvar(15) = (Integer) r5;
	detstackvar(16) = (Integer) r4;
	detstackvar(17) = (Integer) r3;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i39,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i39);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i38);
	r1 = (Integer) detstackvar(15);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_11_0_i41,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i41);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	detstackvar(20) = (Integer) r1;
	r1 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_11_0_i44,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i44);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i43);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r12 = ((Integer) 1);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i43);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(20);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) r14, ((Integer) 4)) = (Integer) detstackvar(17);
	field(mktag(3), (Integer) r14, ((Integer) 3)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = (Integer) detstackvar(13);
	r12 = ((Integer) 0);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
	}
Define_label(mercury__jumpopt__instr_list_11_0_i38);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r12 = ((Integer) 1);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i5);
	if ((tag((Integer) detstackvar(11)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i51);
	if (((Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i51);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 1));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i51);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(21) = (Integer) r2;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__opt_util__is_this_label_next_3_0);
	call_localret(ENTRY(mercury__opt_util__is_this_label_next_3_0),
		mercury__jumpopt__instr_list_11_0_i57,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i57);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i56);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	r11 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r12 = ((Integer) 0);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i56);
	r2 = (Integer) detstackvar(21);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i59);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i59);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 2));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i59);
	detstackvar(21) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__opt_util__is_this_label_next_3_0);
	call_localret(ENTRY(mercury__opt_util__is_this_label_next_3_0),
		mercury__jumpopt__instr_list_11_0_i63,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i63);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i60);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	r12 = ((Integer) 1);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i60);
	r2 = (Integer) detstackvar(21);
Define_label(mercury__jumpopt__instr_list_11_0_i59);
	r4 = (Integer) r2;
	detstackvar(21) = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i67,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i67);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i66);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_11_0_i69,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i69);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_jumpopt__common_19);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i66);
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i73,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i73);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i72);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_11_0_i75,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i75);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_jumpopt__common_19);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i72);
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i79,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i79);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i78);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i78);
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i84,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i84);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i83);
	r1 = (Integer) detstackvar(21);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_11_0_i86,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i86);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r4 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i87,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i87);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i83);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__filter_out_labels_2_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_labels_2_0),
		mercury__jumpopt__instr_list_11_0_i89,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i89);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i83);
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i93,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i93);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i92);
	r1 = (Integer) detstackvar(21);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_11_0_i95,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i95);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r3 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(24) = (Integer) r1;
	r1 = string_const("shortcircuited jump: ", 21);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_11_0_i96,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i96);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	detstackvar(22) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__jumpopt__instr_list_11_0_i97,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i97);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i98);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = ((Integer) 0);
	r4 = (Integer) detstackvar(24);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(22);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(12);
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i106);
	}
Define_label(mercury__jumpopt__instr_list_11_0_i98);
	r1 = (Integer) detstackvar(21);
	r2 = (Integer) detstackvar(24);
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_11_0_i103,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i103);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i102);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = ((Integer) 1);
	r4 = (Integer) detstackvar(24);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i106);
Define_label(mercury__jumpopt__instr_list_11_0_i102);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = ((Integer) 0);
	r4 = (Integer) detstackvar(24);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	tag_incr_hp(r15, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r15, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r14, ((Integer) 1)) = (Integer) detstackvar(22);
	field(mktag(3), (Integer) r15, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	}
Define_label(mercury__jumpopt__instr_list_11_0_i106);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(19) = (Integer) r12;
	detstackvar(25) = (Integer) r13;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i109,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i109);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i108);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i108);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(25);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_11_0_i112,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i112);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(19);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i108);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	r11 = (Integer) detstackvar(25);
	r12 = (Integer) detstackvar(19);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i92);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r12 = ((Integer) 1);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i51);
	r3 = (Integer) detstackvar(11);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i121);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 7)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i121);
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(13) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__jumpopt__short_labels_4_0),
		mercury__jumpopt__instr_list_11_0_i124,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i124);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i125);
	detstackvar(19) = (Integer) r2;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r2 = string_const(" (some shortcircuits)", 21);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_11_0_i128,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i128);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r12 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(13);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r13, ((Integer) 1)) = (Integer) r12;
	r12 = (Integer) detstackvar(19);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
	}
Define_label(mercury__jumpopt__instr_list_11_0_i125);
	r12 = (Integer) r2;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i121);
	if ((tag((Integer) detstackvar(11)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i130);
	if (((Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i130);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 2));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i130);
	detstackvar(23) = (Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 1));
	detstackvar(27) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(27);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i136,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i136);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i92);
	r1 = (Integer) detstackvar(27);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_11_0_i138,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i138);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	detstackvar(26) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__opt_util__is_sdproceed_next_2_0);
	call_localret(ENTRY(mercury__opt_util__is_sdproceed_next_2_0),
		mercury__jumpopt__instr_list_11_0_i141,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i141);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	detstackvar(13) = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(26);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_11_0_i143,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i143);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__is_sdproceed_next_2_0);
	call_localret(ENTRY(mercury__opt_util__is_sdproceed_next_2_0),
		mercury__jumpopt__instr_list_11_0_i145,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i145);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	r1 = (Integer) detstackvar(13);
	detstackvar(13) = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__filter_out_r1_3_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_r1_3_0),
		mercury__jumpopt__instr_list_11_0_i147,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i147);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	r3 = (Integer) detstackvar(13);
	detstackvar(13) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__opt_util__filter_out_r1_3_0);
	call_localret(ENTRY(mercury__opt_util__filter_out_r1_3_0),
		mercury__jumpopt__instr_list_11_0_i149,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i149);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r3 = (Integer) r2;
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__jumpopt__instr_list_11_0_i150,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i150);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	if (((Integer) detstackvar(14) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	if (((Integer) detstackvar(13) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i154);
	if (((Integer) field(mktag(1), (Integer) detstackvar(14), ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	r1 = (Integer) detstackvar(23);
	{
	Declare_entry(mercury__code_util__neg_rval_2_0);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__jumpopt__instr_list_11_0_i156,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i156);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(23);
	r15 = (Integer) detstackvar(15);
	r16 = (Integer) detstackvar(26);
	r17 = (Integer) detstackvar(27);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i153);
Define_label(mercury__jumpopt__instr_list_11_0_i154);
	if (((Integer) detstackvar(13) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	if (((Integer) field(mktag(1), (Integer) detstackvar(14), ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(23);
	r2 = (Integer) r14;
	r15 = (Integer) detstackvar(15);
	r16 = (Integer) detstackvar(26);
	r17 = (Integer) detstackvar(27);
Define_label(mercury__jumpopt__instr_list_11_0_i153);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(23) = (Integer) r14;
	detstackvar(13) = (Integer) r2;
	detstackvar(15) = (Integer) r15;
	detstackvar(26) = (Integer) r16;
	detstackvar(27) = (Integer) r17;
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_jumpopt__common_21);
	call_localret(STATIC(mercury__jumpopt__needs_workaround_2_0),
		mercury__jumpopt__instr_list_11_0_i161,
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i161);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i140);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(13);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_jumpopt__common_21);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("shortcircuited bool computation", 31);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_jumpopt__common_19);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_11_0_i16,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
	}
Define_label(mercury__jumpopt__instr_list_11_0_i140);
	r1 = (Integer) detstackvar(27);
	r2 = (Integer) detstackvar(26);
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_11_0_i166,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i166);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i165);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r12 = ((Integer) 1);
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
Define_label(mercury__jumpopt__instr_list_11_0_i165);
	r1 = string_const("shortcircuited jump: ", 21);
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_11_0_i168,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
Define_label(mercury__jumpopt__instr_list_11_0_i168);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	r12 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) detstackvar(23);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(26);
	field(mktag(0), (Integer) r13, ((Integer) 1)) = (Integer) r12;
	r12 = ((Integer) 0);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i175);
	}
Define_label(mercury__jumpopt__instr_list_11_0_i130);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r12 = ((Integer) 1);
Define_label(mercury__jumpopt__instr_list_11_0_i175);
	if ((tag((Integer) r10) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i176);
	r10 = (Integer) r11;
	r11 = (Integer) r12;
	GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i179);
Define_label(mercury__jumpopt__instr_list_11_0_i176);
	r2 = (Integer) r10;
	r10 = (Integer) r11;
	r11 = (Integer) r12;
Define_label(mercury__jumpopt__instr_list_11_0_i179);
	detstackvar(18) = (Integer) r10;
	detstackvar(19) = (Integer) r11;
	localcall(mercury__jumpopt__instr_list_11_0,
		LABEL(mercury__jumpopt__instr_list_11_0_i180),
		STATIC(mercury__jumpopt__instr_list_11_0));
Define_label(mercury__jumpopt__instr_list_11_0_i180);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(18);
	detstackvar(18) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_11_0_i181,
		STATIC(mercury__jumpopt__instr_list_11_0));
	}
	}
Define_label(mercury__jumpopt__instr_list_11_0_i181);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_11_0));
	if (((Integer) detstackvar(19) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i182);
	if (((Integer) detstackvar(18) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_11_0_i182);
	r2 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(28);
	decr_sp_pop_msg(28);
	proceed();
Define_label(mercury__jumpopt__instr_list_11_0_i182);
	r2 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(28);
	decr_sp_pop_msg(28);
	proceed();
Define_label(mercury__jumpopt__instr_list_11_0_i1001);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module4)
	init_entry(mercury__jumpopt__needs_workaround_2_0);
	init_label(mercury__jumpopt__needs_workaround_2_0_i1046);
	init_label(mercury__jumpopt__needs_workaround_2_0_i10);
	init_label(mercury__jumpopt__needs_workaround_2_0_i9);
	init_label(mercury__jumpopt__needs_workaround_2_0_i16);
	init_label(mercury__jumpopt__needs_workaround_2_0_i19);
	init_label(mercury__jumpopt__needs_workaround_2_0_i14);
	init_label(mercury__jumpopt__needs_workaround_2_0_i13);
	init_label(mercury__jumpopt__needs_workaround_2_0_i30);
	init_label(mercury__jumpopt__needs_workaround_2_0_i33);
	init_label(mercury__jumpopt__needs_workaround_2_0_i2);
	init_label(mercury__jumpopt__needs_workaround_2_0_i1042);
	init_label(mercury__jumpopt__needs_workaround_2_0_i1);
BEGIN_CODE

/* code for predicate 'needs_workaround'/2 in mode 0 */
Define_static(mercury__jumpopt__needs_workaround_2_0);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1046);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1046);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	if (((Integer) r3 != ((Integer) 9)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1042);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1042);
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__lval_0_0);
	tailcall(ENTRY(mercury____Unify___llds__lval_0_0),
		STATIC(mercury__jumpopt__needs_workaround_2_0));
	}
	}
Define_label(mercury__jumpopt__needs_workaround_2_0_i1046);
	incr_sp_push_msg(4, "needs_workaround");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 1)) != ((Integer) 12)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i10);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i9);
Define_label(mercury__jumpopt__needs_workaround_2_0_i10);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 1)) != ((Integer) 13)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
Define_label(mercury__jumpopt__needs_workaround_2_0_i9);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__lval_0_0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__jumpopt__needs_workaround_2_0_i16,
		STATIC(mercury__jumpopt__needs_workaround_2_0));
	}
Define_label(mercury__jumpopt__needs_workaround_2_0_i16);
	update_prof_current_proc(LABEL(mercury__jumpopt__needs_workaround_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i19);
	if (((Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i19);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 1));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 2));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if ((tag((Integer) field(mktag(3), (Integer) r1, ((Integer) 2))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if (((Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), ((Integer) 1)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i19);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if (((Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 1));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__jumpopt__needs_workaround_2_0_i13);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	detstackvar(3) = (Integer) r3;
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__lval_0_0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__jumpopt__needs_workaround_2_0_i30,
		STATIC(mercury__jumpopt__needs_workaround_2_0));
	}
Define_label(mercury__jumpopt__needs_workaround_2_0_i30);
	update_prof_current_proc(LABEL(mercury__jumpopt__needs_workaround_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i33);
	if (((Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i33);
	if (((Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2)), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2)), ((Integer) 1)) != ((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2)), ((Integer) 2))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2)), ((Integer) 2)), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2)), ((Integer) 2)), ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2)), ((Integer) 2)), ((Integer) 1)), ((Integer) 0)) == ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i2);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i33);
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 1)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
Define_label(mercury__jumpopt__needs_workaround_2_0_i2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i1042);
	r1 = FALSE;
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module5)
	init_entry(mercury__jumpopt__adjust_livevals_3_0);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i5);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i10);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i9);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i3);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i1005);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i2);
BEGIN_CODE

/* code for predicate 'jumpopt__adjust_livevals'/3 in mode 0 */
Define_static(mercury__jumpopt__adjust_livevals_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i1005);
	incr_sp_push_msg(3, "jumpopt__adjust_livevals");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__adjust_livevals_3_0_i5,
		STATIC(mercury__jumpopt__adjust_livevals_3_0));
	}
Define_label(mercury__jumpopt__adjust_livevals_3_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__adjust_livevals_3_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) tempr1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i3);
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(2), (Integer) tempr1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury__jumpopt__adjust_livevals_3_0_i10,
		STATIC(mercury__jumpopt__adjust_livevals_3_0));
	}
	}
Define_label(mercury__jumpopt__adjust_livevals_3_0_i10);
	update_prof_current_proc(LABEL(mercury__jumpopt__adjust_livevals_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i9);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__jumpopt__adjust_livevals_3_0_i9);
	r1 = string_const("betweenLivevals and prevLivevals differ in jumpopt", 50);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__jumpopt__adjust_livevals_3_0));
	}
Define_label(mercury__jumpopt__adjust_livevals_3_0_i3);
	r2 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i2);
Define_label(mercury__jumpopt__adjust_livevals_3_0_i1005);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__jumpopt__adjust_livevals_3_0_i2);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module6)
	init_entry(mercury__jumpopt__short_labels_4_0);
	init_label(mercury__jumpopt__short_labels_4_0_i4);
	init_label(mercury__jumpopt__short_labels_4_0_i5);
	init_label(mercury__jumpopt__short_labels_4_0_i8);
	init_label(mercury__jumpopt__short_labels_4_0_i7);
	init_label(mercury__jumpopt__short_labels_4_0_i10);
	init_label(mercury__jumpopt__short_labels_4_0_i11);
	init_label(mercury__jumpopt__short_labels_4_0_i12);
	init_label(mercury__jumpopt__short_labels_4_0_i1005);
	init_label(mercury__jumpopt__short_labels_4_0_i1006);
BEGIN_CODE

/* code for predicate 'jumpopt__short_labels'/4 in mode 0 */
Define_static(mercury__jumpopt__short_labels_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__jumpopt__short_labels_4_0_i1005);
	incr_sp_push_msg(5, "jumpopt__short_labels");
	detstackvar(5) = (Integer) succip;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__jumpopt__short_labels_4_0_i4,
		STATIC(mercury__jumpopt__short_labels_4_0));
	}
Define_label(mercury__jumpopt__short_labels_4_0_i4);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__jumpopt__final_dest_2_6_0),
		mercury__jumpopt__short_labels_4_0_i5,
		STATIC(mercury__jumpopt__short_labels_4_0));
Define_label(mercury__jumpopt__short_labels_4_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__short_labels_4_0_i8,
		STATIC(mercury__jumpopt__short_labels_4_0));
	}
Define_label(mercury__jumpopt__short_labels_4_0_i8);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__short_labels_4_0_i7);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	GOTO_LABEL(mercury__jumpopt__short_labels_4_0_i10);
Define_label(mercury__jumpopt__short_labels_4_0_i7);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
Define_label(mercury__jumpopt__short_labels_4_0_i10);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	localcall(mercury__jumpopt__short_labels_4_0,
		LABEL(mercury__jumpopt__short_labels_4_0_i11),
		STATIC(mercury__jumpopt__short_labels_4_0));
Define_label(mercury__jumpopt__short_labels_4_0_i11);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_4_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	if (((Integer) detstackvar(4) != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__short_labels_4_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__short_labels_4_0_i1006);
	r1 = (Integer) r3;
	r2 = ((Integer) 1);
	proceed();
Define_label(mercury__jumpopt__short_labels_4_0_i12);
	r1 = (Integer) r3;
	r2 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__jumpopt__short_labels_4_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = ((Integer) 1);
	proceed();
Define_label(mercury__jumpopt__short_labels_4_0_i1006);
	r1 = (Integer) r3;
	r2 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module7)
	init_entry(mercury__jumpopt__final_dest_5_0);
BEGIN_CODE

/* code for predicate 'jumpopt__final_dest'/5 in mode 0 */
Define_static(mercury__jumpopt__final_dest_5_0);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__jumpopt__final_dest_2_6_0),
		STATIC(mercury__jumpopt__final_dest_5_0));
END_MODULE

BEGIN_MODULE(mercury__jumpopt_module8)
	init_entry(mercury__jumpopt__final_dest_2_6_0);
	init_label(mercury__jumpopt__final_dest_2_6_0_i1001);
	init_label(mercury__jumpopt__final_dest_2_6_0_i4);
	init_label(mercury__jumpopt__final_dest_2_6_0_i8);
	init_label(mercury__jumpopt__final_dest_2_6_0_i12);
	init_label(mercury__jumpopt__final_dest_2_6_0_i3);
	init_label(mercury__jumpopt__final_dest_2_6_0_i15);
BEGIN_CODE

/* code for predicate 'jumpopt__final_dest_2'/6 in mode 0 */
Define_static(mercury__jumpopt__final_dest_2_6_0);
	r5 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i1001);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i1001);
	r6 = (Integer) r2;
	r7 = (Integer) r4;
	r4 = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
	incr_sp_push_msg(7, "jumpopt__final_dest_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i4);
Define_label(mercury__jumpopt__final_dest_2_6_0_i1001);
	incr_sp_push_msg(7, "jumpopt__final_dest_2");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i15);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i15);
	if ((tag((Integer) field(mktag(3), (Integer) r5, ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i15);
	r6 = (Integer) r2;
	r7 = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) r5, ((Integer) 1)), ((Integer) 0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_jumpopt__common_0);
Define_label(mercury__jumpopt__final_dest_2_6_0_i4);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__final_dest_2_6_0_i8,
		STATIC(mercury__jumpopt__final_dest_2_6_0));
	}
Define_label(mercury__jumpopt__final_dest_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__jumpopt__final_dest_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i3);
	detstackvar(6) = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__jumpopt__final_dest_2_6_0_i12,
		STATIC(mercury__jumpopt__final_dest_2_6_0));
	}
Define_label(mercury__jumpopt__final_dest_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__jumpopt__final_dest_2_6_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i3);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__jumpopt__final_dest_2_6_0,
		STATIC(mercury__jumpopt__final_dest_2_6_0));
Define_label(mercury__jumpopt__final_dest_2_6_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
Define_label(mercury__jumpopt__final_dest_2_6_0_i15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__jumpopt_bunch_0(void)
{
	mercury__jumpopt_module0();
	mercury__jumpopt_module1();
	mercury__jumpopt_module2();
	mercury__jumpopt_module3();
	mercury__jumpopt_module4();
	mercury__jumpopt_module5();
	mercury__jumpopt_module6();
	mercury__jumpopt_module7();
	mercury__jumpopt_module8();
}

#endif

void mercury__jumpopt__init(void); /* suppress gcc warning */
void mercury__jumpopt__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__jumpopt_bunch_0();
#endif
}
