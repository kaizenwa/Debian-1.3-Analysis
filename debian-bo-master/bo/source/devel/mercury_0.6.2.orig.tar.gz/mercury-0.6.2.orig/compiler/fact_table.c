/*
** Automatically generated from `fact_table.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__fact_table__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__fact_table__write_fact_table_header__ua10000_8_0);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i2);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i3);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i4);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i5);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i6);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i7);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i8);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i9);
Declare_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i10);
Declare_static(mercury__fact_table__check_fact_term__ua10000_10_0);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i4);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i5);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i6);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i7);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i8);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i1002);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i9);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i11);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i10);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i18);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i25);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i17);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i26);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i29);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i30);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i31);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i32);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i33);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i34);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i27);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i35);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i36);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i37);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i38);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i39);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i42);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i43);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i44);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i45);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i46);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i47);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i12);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i50);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i51);
Declare_label(mercury__fact_table__check_fact_term__ua10000_10_0_i52);
Declare_static(mercury__fact_table__fact_table_generate_c_code__ua10000_3_0);
Define_extern_entry(mercury__fact_table__fact_table_compile_facts_8_0);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i2);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i5);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i6);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i7);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i8);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i4);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i9);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i10);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i13);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i14);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i15);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i16);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i12);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i17);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i19);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i20);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i21);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i22);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i23);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i24);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i25);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i26);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i27);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i28);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i29);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i18);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i30);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i11);
Declare_label(mercury__fact_table__fact_table_compile_facts_8_0_i31);
Define_extern_entry(mercury__fact_table__fact_table_generate_c_code_3_0);
Declare_static(mercury__fact_table__compile_facts_7_0);
Declare_label(mercury__fact_table__compile_facts_7_0_i2);
Declare_label(mercury__fact_table__compile_facts_7_0_i5);
Declare_label(mercury__fact_table__compile_facts_7_0_i7);
Declare_label(mercury__fact_table__compile_facts_7_0_i8);
Declare_label(mercury__fact_table__compile_facts_7_0_i9);
Declare_label(mercury__fact_table__compile_facts_7_0_i6);
Declare_label(mercury__fact_table__compile_facts_7_0_i11);
Declare_label(mercury__fact_table__compile_facts_7_0_i13);
Declare_static(mercury__fact_table__check_fact_type_and_mode_7_0);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i6);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i7);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i8);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i1002);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i14);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i15);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i16);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i13);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i18);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i19);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i20);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i11);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i29);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i30);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i32);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i33);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i22);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i43);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i44);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i45);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i47);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i48);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i36);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i60);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i61);
Declare_label(mercury__fact_table__check_fact_type_and_mode_7_0_i1001);
Declare_static(mercury__fact_table__write_fact_table_struct_7_0);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i10);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i11);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i12);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i1002);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i4);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i14);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i24);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i34);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i35);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i36);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i37);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i38);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i39);
Declare_label(mercury__fact_table__write_fact_table_struct_7_0_i1001);
Declare_static(mercury__fact_table__infer_proc_determinism_pass_1_7_0);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i4);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i5);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i6);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i8);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i9);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i10);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i15);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i14);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i11);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i18);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i19);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i20);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i21);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i22);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i23);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i24);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i25);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i26);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i27);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i28);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i29);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i33);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i34);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i30);
Declare_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i1006);
Declare_static(mercury__fact_table__fact_table_mode_type_2_0);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i1018);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i15);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i1017);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i1016);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i1015);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i4);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i21);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i24);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i25);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i28);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i31);
Declare_label(mercury__fact_table__fact_table_mode_type_2_0_i1012);
Declare_static(mercury__fact_table__open_sort_files_5_0);
Declare_label(mercury__fact_table__open_sort_files_5_0_i4);
Declare_label(mercury__fact_table__open_sort_files_5_0_i5);
Declare_label(mercury__fact_table__open_sort_files_5_0_i8);
Declare_label(mercury__fact_table__open_sort_files_5_0_i9);
Declare_label(mercury__fact_table__open_sort_files_5_0_i10);
Declare_label(mercury__fact_table__open_sort_files_5_0_i7);
Declare_label(mercury__fact_table__open_sort_files_5_0_i11);
Declare_label(mercury__fact_table__open_sort_files_5_0_i1012);
Declare_static(mercury__fact_table__write_sort_file_lines_5_0);
Declare_label(mercury__fact_table__write_sort_file_lines_5_0_i4);
Declare_label(mercury__fact_table__write_sort_file_lines_5_0_i5);
Declare_label(mercury__fact_table__write_sort_file_lines_5_0_i6);
Declare_label(mercury__fact_table__write_sort_file_lines_5_0_i7);
Declare_label(mercury__fact_table__write_sort_file_lines_5_0_i8);
Declare_label(mercury__fact_table__write_sort_file_lines_5_0_i1002);
Declare_static(mercury__fact_table__make_sort_file_key_2_0);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i16);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i15);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i18);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i17);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i20);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i21);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i22);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i19);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i24);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i13);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i25);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i26);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i1000);
Declare_label(mercury__fact_table__make_sort_file_key_2_0_i1001);
Declare_static(mercury__fact_table__key_from_chars_2_3_0);
Declare_label(mercury__fact_table__key_from_chars_2_3_0_i15);
Declare_label(mercury__fact_table__key_from_chars_2_3_0_i2);
Declare_label(mercury__fact_table__key_from_chars_2_3_0_i5);
Declare_label(mercury__fact_table__key_from_chars_2_3_0_i8);
Declare_label(mercury__fact_table__key_from_chars_2_3_0_i13);
Declare_label(mercury__fact_table__key_from_chars_2_3_0_i1);
Declare_static(mercury__fact_table__infer_determinism_pass_2_5_0);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i4);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i5);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i6);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i7);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i8);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i11);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i12);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i13);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i10);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i14);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i19);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i24);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i23);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i20);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i17);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i27);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i28);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i31);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i32);
Declare_label(mercury__fact_table__infer_determinism_pass_2_5_0_i1011);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_fact_table__base_type_layout_fact_result_0[];
Word * mercury_data_fact_table__base_type_info_fact_result_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_fact_table__base_type_layout_fact_result_0
};

extern Word * mercury_data_fact_table__base_type_layout_fact_table_mode_type_0[];
Word * mercury_data_fact_table__base_type_info_fact_table_mode_type_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_fact_table__base_type_layout_fact_table_mode_type_0
};

extern Word * mercury_data_fact_table__base_type_layout_inferred_determinism_0[];
Word * mercury_data_fact_table__base_type_info_inferred_determinism_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_fact_table__base_type_layout_inferred_determinism_0
};

extern Word * mercury_data_fact_table__common_9[];
extern Word * mercury_data_fact_table__common_11[];
Word * mercury_data_fact_table__base_type_layout_inferred_determinism_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_9),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_fact_table__common_12[];
Word * mercury_data_fact_table__base_type_layout_fact_table_mode_type_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_12)
};

extern Word * mercury_data_fact_table__common_13[];
Word * mercury_data_fact_table__base_type_layout_fact_result_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_13)
};

Word * mercury_data_fact_table__common_0[] = {
	(Word *) string_const(".  Do not edit.\n*/\n\n", 20),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_fact_table__common_1[] = {
	(Word *) string_const("/", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_fact_table__common_2[] = {
	(Word *) string_const(".\n", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_fact_table__common_3[] = {
	(Word *) string_const("\n", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_fact_table__common_4[] = {
	((Integer) 1)
};

Word mercury_data_fact_table__common_5[] = {
	((Integer) 5)
};

Word mercury_data_fact_table__common_6[] = {
	((Integer) 3)
};

Word * mercury_data_fact_table__common_7[] = {
	(Word *) string_const("  during fact table determinism inference.\n", 43),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_fact_table__common_8[] = {
	(Word *) string_const("An error occurred in the `sort' program\n", 40),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_7)
};

Word * mercury_data_fact_table__common_9[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 2),
	(Word *) string_const("no", 2),
	(Word *) string_const("error", 5)
};

extern Word * mercury_data_hlds_data__base_type_info_determinism_0[];
Word * mercury_data_fact_table__common_10[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_determinism_0
};

Word * mercury_data_fact_table__common_11[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_fact_table__common_10),
	(Word *) string_const("yes", 3)
};

Word * mercury_data_fact_table__common_12[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 5),
	(Word *) string_const("all_in", 6),
	(Word *) string_const("all_out", 7),
	(Word *) string_const("in_out", 6),
	(Word *) string_const("other", 5),
	(Word *) string_const("unknown", 7)
};

Word * mercury_data_fact_table__common_13[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("ok", 2),
	(Word *) string_const("error", 5)
};

BEGIN_MODULE(mercury__fact_table_module0)
	init_entry(mercury__fact_table__write_fact_table_header__ua10000_8_0);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i2);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i3);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i4);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i5);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i6);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i7);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i8);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i9);
	init_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i10);
BEGIN_CODE

/* code for predicate 'write_fact_table_header__ua10000'/8 in mode 0 */
Define_static(mercury__fact_table__write_fact_table_header__ua10000_8_0);
	incr_sp_push_msg(5, "write_fact_table_header__ua10000");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i2,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i2);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r3 = (Integer) r1;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("/*\n** Automatically generated from `", 36);
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("' by the\n** Mercury compiler, version ", 38);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_0);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i3,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i3);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("#include \"imp.h\"\n\n", 18);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i4,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i4);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("struct fact_table {\n", 20);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i5,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_3_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i6,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i7,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__fact_table__write_fact_table_struct_7_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i8,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("};\n\n", 4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i9,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i9);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("static struct fact_table table[] = {\n", 37);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_header__ua10000_8_0_i10,
		STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	}
Define_label(mercury__fact_table__write_fact_table_header__ua10000_8_0_i10);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_header__ua10000_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module1)
	init_entry(mercury__fact_table__check_fact_term__ua10000_10_0);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i4);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i5);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i6);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i7);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i8);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i1002);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i9);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i11);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i10);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i18);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i25);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i17);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i26);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i29);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i30);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i31);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i32);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i33);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i34);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i27);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i35);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i36);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i37);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i38);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i39);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i42);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i43);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i44);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i45);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i46);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i47);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i12);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i50);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i51);
	init_label(mercury__fact_table__check_fact_term__ua10000_10_0_i52);
BEGIN_CODE

/* code for predicate 'check_fact_term__ua10000'/10 in mode 0 */
Define_static(mercury__fact_table__check_fact_term__ua10000_10_0);
	if ((tag((Integer) r4) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i1002);
	r1 = (Integer) r7;
	incr_sp_push_msg(11, "check_fact_term__ua10000");
	detstackvar(11) = (Integer) succip;
	{
	Declare_entry(mercury__io__get_line_number_3_0);
	call_localret(ENTRY(mercury__io__get_line_number_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i4,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i4);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__input_stream_name_3_0);
	call_localret(ENTRY(mercury__io__input_stream_name_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i5,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i6,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: term is not a fact.\n", 27);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i7,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i8,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i1002);
	incr_sp_push_msg(11, "check_fact_term__ua10000");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i9,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i9);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	if ((tag((Integer) detstackvar(1)) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i11);
	r9 = (Integer) r1;
	r10 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 1));
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i10);
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i11);
	r9 = (Integer) r1;
	r10 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i10);
	if ((tag((Integer) r6) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i12);
	if (((Integer) r9 != ((Integer) 0)))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i18);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r6, ((Integer) 0)), (char *)(Integer) r10) !=0))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r7;
	r7 = (Integer) r8;
	r10 = (Integer) r1;
	GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i17);
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i18);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r6, ((Integer) 0)), (char *)string_const("=", 1)) !=0))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	if (((Integer) r7 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	if (((Integer) field(mktag(1), (Integer) r7, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r7, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	if ((tag((Integer) field(mktag(1), (Integer) r7, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r7, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	if ((strcmp((char *)(Integer) r10, (char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r7, ((Integer) 0)), ((Integer) 0)), ((Integer) 0))) !=0))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r7, ((Integer) 0)), ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r8;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r7, ((Integer) 1)), ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__fact_table__check_fact_term__ua10000_10_0_i25,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i25);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(9);
	r10 = ((Integer) detstackvar(2) + ((Integer) 1));
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i17);
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r2;
	detstackvar(1) = (Integer) r10;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i26,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i26);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	if (((Integer) r1 != (Integer) detstackvar(1)))
		GOTO_LABEL(mercury__fact_table__check_fact_term__ua10000_10_0_i27);
	r1 = (Integer) detstackvar(5);
	r2 = string_const("\t{ ", 3);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i29,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i29);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i30,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i30);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__fact_table__check_fact_type_and_mode_7_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i31,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i31);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("},\n", 3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i32,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i32);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i33,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i33);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__fact_table__write_sort_file_lines_5_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i34,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i34);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i27);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i35,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i35);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: fact has wrong number of arguments.\n", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i36,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i36);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i37,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i37);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("  Expecting %d arguments, but fact has %d arguments.\n", 53);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i38,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i38);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i39,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i39);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i8,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i15);
	detstackvar(2) = (Integer) r1;
	detstackvar(7) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	r1 = (Integer) r8;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i42,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i42);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: invalid clause for ", 26);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i43,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i43);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_out__write_pred_or_func_3_0);
	call_localret(ENTRY(mercury__hlds_out__write_pred_or_func_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i44,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i44);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" `", 2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i45,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i45);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i46,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i46);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = string_const("' .\n", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i47,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i47);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i8,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i12);
	r1 = (Integer) r8;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i50,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i50);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: term is not a fact.\n", 27);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i51,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i51);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_term__ua10000_10_0_i52,
		STATIC(mercury__fact_table__check_fact_term__ua10000_10_0));
	}
Define_label(mercury__fact_table__check_fact_term__ua10000_10_0_i52);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_term__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module2)
	init_entry(mercury__fact_table__fact_table_generate_c_code__ua10000_3_0);
BEGIN_CODE

/* code for predicate 'fact_table_generate_c_code__ua10000'/3 in mode 0 */
Define_static(mercury__fact_table__fact_table_generate_c_code__ua10000_3_0);
	r1 = string_const("fprintf(stderr, \"Fact Tables not yet working\\n\");", 49);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module3)
	init_entry(mercury__fact_table__fact_table_compile_facts_8_0);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i2);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i5);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i6);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i7);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i8);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i4);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i9);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i10);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i13);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i14);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i15);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i16);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i12);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i17);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i19);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i20);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i21);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i22);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i23);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i24);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i25);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i26);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i27);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i28);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i29);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i18);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i30);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i11);
	init_label(mercury__fact_table__fact_table_compile_facts_8_0_i31);
BEGIN_CODE

/* code for predicate 'fact_table_compile_facts'/8 in mode 0 */
Define_entry(mercury__fact_table__fact_table_compile_facts_8_0);
	incr_sp_push_msg(8, "fact_table_compile_facts");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) r3;
	r2 = (Integer) r6;
	{
	Declare_entry(mercury__io__see_4_0);
	call_localret(ENTRY(mercury__io__see_4_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i2,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i2);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__fact_table_compile_facts_8_0_i4);
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i5,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i6,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Error opening file `", 20);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("' for input: ", 13);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i7,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i8,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i4);
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".c", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__fact_table__fact_table_compile_facts_8_0_i9,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i9);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__io__open_output_4_0);
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i10,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i10);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__fact_table_compile_facts_8_0_i12);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i13,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i13);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i14,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i14);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Error opening file `", 20);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("' for output: ", 14);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i15,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i15);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i16,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i16);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__fact_table__fact_table_compile_facts_8_0_i11);
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i12);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r3;
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__fact_table__write_fact_table_header__ua10000_8_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i17,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i17);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__fact_table__fact_table_compile_facts_8_0_i19);
	r3 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__fact_table__fact_table_compile_facts_8_0_i18);
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i19);
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i20,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i20);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i21,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i21);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i22,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i22);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(6) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i23,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i23);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__fact_table__open_sort_files_5_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i24,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i24);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r4;
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__fact_table__compile_facts_7_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i25,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i25);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i26,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i26);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__fact_table__infer_determinism_pass_2_5_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i27,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i27);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i28,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i28);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("};\n", 3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i29,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i29);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i18);
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__io__close_output_3_0);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i30,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i30);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) detstackvar(1);
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i11);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__io__seen_2_0);
	call_localret(ENTRY(mercury__io__seen_2_0),
		mercury__fact_table__fact_table_compile_facts_8_0_i31,
		ENTRY(mercury__fact_table__fact_table_compile_facts_8_0));
	}
Define_label(mercury__fact_table__fact_table_compile_facts_8_0_i31);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_compile_facts_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module4)
	init_entry(mercury__fact_table__fact_table_generate_c_code_3_0);
BEGIN_CODE

/* code for predicate 'fact_table_generate_c_code'/3 in mode 0 */
Define_entry(mercury__fact_table__fact_table_generate_c_code_3_0);
	tailcall(STATIC(mercury__fact_table__fact_table_generate_c_code__ua10000_3_0),
		ENTRY(mercury__fact_table__fact_table_generate_c_code_3_0));
END_MODULE

BEGIN_MODULE(mercury__fact_table_module5)
	init_entry(mercury__fact_table__compile_facts_7_0);
	init_label(mercury__fact_table__compile_facts_7_0_i2);
	init_label(mercury__fact_table__compile_facts_7_0_i5);
	init_label(mercury__fact_table__compile_facts_7_0_i7);
	init_label(mercury__fact_table__compile_facts_7_0_i8);
	init_label(mercury__fact_table__compile_facts_7_0_i9);
	init_label(mercury__fact_table__compile_facts_7_0_i6);
	init_label(mercury__fact_table__compile_facts_7_0_i11);
	init_label(mercury__fact_table__compile_facts_7_0_i13);
BEGIN_CODE

/* code for predicate 'compile_facts'/7 in mode 0 */
Define_static(mercury__fact_table__compile_facts_7_0);
	incr_sp_push_msg(6, "compile_facts");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) r6;
	{
	Declare_entry(mercury__parser__read_term_3_0);
	call_localret(ENTRY(mercury__parser__read_term_3_0),
		mercury__fact_table__compile_facts_7_0_i2,
		STATIC(mercury__fact_table__compile_facts_7_0));
	}
Define_label(mercury__fact_table__compile_facts_7_0_i2);
	update_prof_current_proc(LABEL(mercury__fact_table__compile_facts_7_0));
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__compile_facts_7_0_i5);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__fact_table__compile_facts_7_0_i5);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__fact_table__compile_facts_7_0_i6);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__input_stream_name_3_0);
	call_localret(ENTRY(mercury__io__input_stream_name_3_0),
		mercury__fact_table__compile_facts_7_0_i7,
		STATIC(mercury__fact_table__compile_facts_7_0));
	}
Define_label(mercury__fact_table__compile_facts_7_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__compile_facts_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__compile_facts_7_0_i8,
		STATIC(mercury__fact_table__compile_facts_7_0));
	}
Define_label(mercury__fact_table__compile_facts_7_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__compile_facts_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_3);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__compile_facts_7_0_i9,
		STATIC(mercury__fact_table__compile_facts_7_0));
	}
Define_label(mercury__fact_table__compile_facts_7_0_i9);
	update_prof_current_proc(LABEL(mercury__fact_table__compile_facts_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	tailcall(ENTRY(mercury__io__set_exit_status_3_0),
		STATIC(mercury__fact_table__compile_facts_7_0));
	}
Define_label(mercury__fact_table__compile_facts_7_0_i6);
	r4 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__fact_table__check_fact_term__ua10000_10_0),
		mercury__fact_table__compile_facts_7_0_i11,
		STATIC(mercury__fact_table__compile_facts_7_0));
Define_label(mercury__fact_table__compile_facts_7_0_i11);
	update_prof_current_proc(LABEL(mercury__fact_table__compile_facts_7_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__fact_table__compile_facts_7_0_i13);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__fact_table__compile_facts_7_0,
		STATIC(mercury__fact_table__compile_facts_7_0));
Define_label(mercury__fact_table__compile_facts_7_0_i13);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__fact_table__compile_facts_7_0,
		STATIC(mercury__fact_table__compile_facts_7_0));
END_MODULE

BEGIN_MODULE(mercury__fact_table_module6)
	init_entry(mercury__fact_table__check_fact_type_and_mode_7_0);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i6);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i7);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i8);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i1002);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i14);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i15);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i16);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i13);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i18);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i19);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i20);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i11);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i29);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i30);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i32);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i33);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i22);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i43);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i44);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i45);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i47);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i48);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i36);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i60);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i61);
	init_label(mercury__fact_table__check_fact_type_and_mode_7_0_i1001);
BEGIN_CODE

/* code for predicate 'check_fact_type_and_mode'/7 in mode 0 */
Define_static(mercury__fact_table__check_fact_type_and_mode_7_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i1001);
	if ((tag((Integer) field(mktag(1), (Integer) r2, ((Integer) 0))) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i1002);
	r1 = (Integer) r3;
	r2 = (Integer) r5;
	incr_sp_push_msg(6, "check_fact_type_and_mode");
	detstackvar(6) = (Integer) succip;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i6,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: non-ground term in fact.\n", 32);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i7,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i8,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i1002);
	incr_sp_push_msg(6, "check_fact_type_and_mode");
	detstackvar(6) = (Integer) succip;
	r6 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r6) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i11);
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i13);
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 2));
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i14,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i14);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: compound types are not ", 30);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i15,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i15);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("supported in fact tables.\n", 26);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i16,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i16);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i8,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i13);
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 2));
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i18,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i18);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: enumeration types are not ", 33);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i19,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i19);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("yet supported in fact tables.\n", 30);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i20,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i20);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i8,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i11);
	if ((tag((Integer) r6) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i22);
	r7 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 2));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), (char *)string_const("int", 3)) !=0))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	r2 = (Integer) field(mktag(1), (Integer) r6, ((Integer) 0));
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__io__write_int_4_0);
	call_localret(ENTRY(mercury__io__write_int_4_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i29,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i29);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(", ", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i30,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i30);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__fact_table__check_fact_type_and_mode_7_0,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i23);
	r1 = (Integer) r7;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i32,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i32);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Type error in fact argument.\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i33,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i33);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i8,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i22);
	if ((tag((Integer) r6) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i36);
	r7 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 2));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r6, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	r2 = string_const("\"", 1);
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i43,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i43);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i44,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i44);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("\", ", 3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i45,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i45);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__fact_table__check_fact_type_and_mode_7_0,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i37);
	r1 = (Integer) r7;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i47,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i47);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Type error in fact argument.\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i48,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i48);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i8,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i36);
	r7 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 2));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	r2 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 0));
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__io__write_float_4_0);
	call_localret(ENTRY(mercury__io__write_float_4_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i29,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i51);
	r1 = (Integer) r7;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i60,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i60);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Type error in fact argument.\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i61,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i61);
	update_prof_current_proc(LABEL(mercury__fact_table__check_fact_type_and_mode_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__check_fact_type_and_mode_7_0_i8,
		STATIC(mercury__fact_table__check_fact_type_and_mode_7_0));
	}
Define_label(mercury__fact_table__check_fact_type_and_mode_7_0_i1001);
	r1 = ((Integer) 0);
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module7)
	init_entry(mercury__fact_table__write_fact_table_struct_7_0);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i10);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i11);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i12);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i1002);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i4);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i14);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i24);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i34);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i35);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i36);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i37);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i38);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i39);
	init_label(mercury__fact_table__write_fact_table_struct_7_0_i1001);
BEGIN_CODE

/* code for predicate 'write_fact_table_struct'/7 in mode 0 */
Define_static(mercury__fact_table__write_fact_table_struct_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i1001);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r7) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i1002);
	r8 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 0));
	if ((tag((Integer) r8) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i1002);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r8, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i1002);
	r8 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 1));
	incr_sp_push_msg(5, "write_fact_table_struct");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r8 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r6;
	r1 = (Integer) r4;
	r2 = string_const("\tconst char * V_", 16);
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_struct_7_0_i10,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i10);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_4_0);
	call_localret(ENTRY(mercury__io__write_int_4_0),
		mercury__fact_table__write_fact_table_struct_7_0_i11,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i11);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(";\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_struct_7_0_i12,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i12);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) detstackvar(1) + ((Integer) 1));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__fact_table__write_fact_table_struct_7_0,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i1002);
	incr_sp_push_msg(5, "write_fact_table_struct");
	detstackvar(5) = (Integer) succip;
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i4);
	if ((tag((Integer) r7) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i14);
	r1 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i14);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)string_const("int", 3)) !=0))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i14);
	r1 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i14);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r6;
	r1 = (Integer) r4;
	r2 = string_const("\tInteger V_", 11);
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_struct_7_0_i10,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i14);
	if ((tag((Integer) r7) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i24);
	if ((tag((Integer) field(mktag(0), (Integer) r7, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i24);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r7, ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i24);
	if (((Integer) field(mktag(0), (Integer) r7, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__write_fact_table_struct_7_0_i24);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r6;
	r1 = (Integer) r4;
	r2 = string_const("\tFloat V_", 9);
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__fact_table__write_fact_table_struct_7_0_i10,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i24);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r3;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__write_fact_table_struct_7_0_i34,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i34);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: invalid type in fact table:\n", 35);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__write_fact_table_struct_7_0_i35,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i35);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__write_fact_table_struct_7_0_i36,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i36);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r2 = (Integer) r1;
	r1 = string_const("  only `string', `int' and `float' types ", 41);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__write_fact_table_struct_7_0_i37,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i37);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r2 = (Integer) r1;
	r1 = string_const("are allowed in fact tables.\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__write_fact_table_struct_7_0_i38,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i38);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__write_fact_table_struct_7_0_i39,
		STATIC(mercury__fact_table__write_fact_table_struct_7_0));
	}
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i39);
	update_prof_current_proc(LABEL(mercury__fact_table__write_fact_table_struct_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__fact_table__write_fact_table_struct_7_0_i1001);
	r1 = ((Integer) 0);
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module8)
	init_entry(mercury__fact_table__infer_proc_determinism_pass_1_7_0);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i4);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i5);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i6);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i8);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i9);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i10);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i15);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i14);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i11);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i18);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i19);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i20);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i21);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i22);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i23);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i24);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i25);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i26);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i27);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i28);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i29);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i33);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i34);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i30);
	init_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i1006);
BEGIN_CODE

/* code for predicate 'infer_proc_determinism_pass_1'/7 in mode 0 */
Define_static(mercury__fact_table__infer_proc_determinism_pass_1_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i1006);
	incr_sp_push_msg(7, "infer_proc_determinism_pass_1");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i4,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i4);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i5,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	call_localret(STATIC(mercury__fact_table__fact_table_mode_type_2_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i6,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i8) AND
		LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i9) AND
		LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i18) AND
		LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i19) AND
		LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i25));
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_4);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i9);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i10,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i10);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i11);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i15);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i14);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i15);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i14);
	r7 = (Integer) r4;
	r4 = (Integer) r6;
	r6 = (Integer) r3;
	r3 = (Integer) r5;
	r5 = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_5);
	GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_6);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i18);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i19);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i20,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i20);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i21,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i21);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: only in and out modes are currently ", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i22,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i22);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) r1;
	r1 = string_const("supported in fact tables.\n", 26);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i23,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i23);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i24,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i24);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	r6 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i25);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i26,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i26);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i27,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i27);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: mode list for procedure is empty.\n", 41);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i28,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i28);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i29,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i29);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	r6 = (Integer) detstackvar(2);
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i7);
	if ((tag((Integer) r5) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i30);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r7;
	r2 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i33,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i33);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__fact_table__infer_proc_determinism_pass_1_7_0_i34,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	}
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i34);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__fact_table__infer_proc_determinism_pass_1_7_0,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i30);
	r1 = (Integer) r4;
	r3 = (Integer) r6;
	r4 = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__fact_table__infer_proc_determinism_pass_1_7_0,
		STATIC(mercury__fact_table__infer_proc_determinism_pass_1_7_0));
Define_label(mercury__fact_table__infer_proc_determinism_pass_1_7_0_i1006);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module9)
	init_entry(mercury__fact_table__fact_table_mode_type_2_0);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i1018);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i15);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i1017);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i1016);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i1015);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i4);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i21);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i24);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i25);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i28);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i31);
	init_label(mercury__fact_table__fact_table_mode_type_2_0_i1012);
BEGIN_CODE

/* code for predicate 'fact_table_mode_type'/2 in mode 0 */
Define_static(mercury__fact_table__fact_table_mode_type_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i1012);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i1015);
	if ((tag((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i1016);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i1017);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), (char *)string_const("mercury_builtin", 15)) !=0))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i1017);
	r3 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1));
	if ((strcmp((char *)(Integer) r3, (char *)string_const("in", 2)) !=0))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i1018);
	r1 = (Integer) r2;
	r2 = ((Integer) 0);
	incr_sp_push_msg(2, "fact_table_mode_type");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i4);
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i1018);
	incr_sp_push_msg(2, "fact_table_mode_type");
	detstackvar(2) = (Integer) succip;
	if ((strcmp((char *)(Integer) r3, (char *)string_const("out", 3)) !=0))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i15);
	r1 = (Integer) r2;
	r2 = ((Integer) 1);
	GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i4);
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i15);
	r1 = (Integer) r2;
	r2 = ((Integer) 3);
	GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i4);
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i1017);
	incr_sp_push_msg(2, "fact_table_mode_type");
	detstackvar(2) = (Integer) succip;
	r1 = (Integer) r2;
	r2 = ((Integer) 3);
	GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i4);
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i1016);
	incr_sp_push_msg(2, "fact_table_mode_type");
	detstackvar(2) = (Integer) succip;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) 3);
	GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i4);
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i1015);
	incr_sp_push_msg(2, "fact_table_mode_type");
	detstackvar(2) = (Integer) succip;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) 3);
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i4);
	if (((Integer) r2 != ((Integer) 3)))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i21);
	r1 = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i21);
	detstackvar(1) = (Integer) r2;
	localcall(mercury__fact_table__fact_table_mode_type_2_0,
		LABEL(mercury__fact_table__fact_table_mode_type_2_0_i24),
		STATIC(mercury__fact_table__fact_table_mode_type_2_0));
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i24);
	update_prof_current_proc(LABEL(mercury__fact_table__fact_table_mode_type_2_0));
	if (((Integer) r1 != ((Integer) 4)))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i25);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i25);
	if (((Integer) r1 != ((Integer) 3)))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i28);
	r1 = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i28);
	if (((Integer) r1 != (Integer) detstackvar(1)))
		GOTO_LABEL(mercury__fact_table__fact_table_mode_type_2_0_i31);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i31);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__fact_table__fact_table_mode_type_2_0_i1012);
	r1 = ((Integer) 4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module10)
	init_entry(mercury__fact_table__open_sort_files_5_0);
	init_label(mercury__fact_table__open_sort_files_5_0_i4);
	init_label(mercury__fact_table__open_sort_files_5_0_i5);
	init_label(mercury__fact_table__open_sort_files_5_0_i8);
	init_label(mercury__fact_table__open_sort_files_5_0_i9);
	init_label(mercury__fact_table__open_sort_files_5_0_i10);
	init_label(mercury__fact_table__open_sort_files_5_0_i7);
	init_label(mercury__fact_table__open_sort_files_5_0_i11);
	init_label(mercury__fact_table__open_sort_files_5_0_i1012);
BEGIN_CODE

/* code for predicate 'open_sort_files'/5 in mode 0 */
Define_static(mercury__fact_table__open_sort_files_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__open_sort_files_5_0_i1012);
	incr_sp_push_msg(5, "open_sort_files");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const("%s.tmp.%d", 9);
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fact_table__open_sort_files_5_0_i4,
		STATIC(mercury__fact_table__open_sort_files_5_0));
	}
Define_label(mercury__fact_table__open_sort_files_5_0_i4);
	update_prof_current_proc(LABEL(mercury__fact_table__open_sort_files_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__io__open_output_4_0);
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__fact_table__open_sort_files_5_0_i5,
		STATIC(mercury__fact_table__open_sort_files_5_0));
	}
Define_label(mercury__fact_table__open_sort_files_5_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__open_sort_files_5_0));
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__open_sort_files_5_0_i7);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__fact_table__open_sort_files_5_0_i8,
		STATIC(mercury__fact_table__open_sort_files_5_0));
	}
Define_label(mercury__fact_table__open_sort_files_5_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__open_sort_files_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Error opening file `", 20);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("' for output: ", 14);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_2);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__open_sort_files_5_0_i9,
		STATIC(mercury__fact_table__open_sort_files_5_0));
	}
	}
Define_label(mercury__fact_table__open_sort_files_5_0_i9);
	update_prof_current_proc(LABEL(mercury__fact_table__open_sort_files_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__open_sort_files_5_0_i10,
		STATIC(mercury__fact_table__open_sort_files_5_0));
	}
Define_label(mercury__fact_table__open_sort_files_5_0_i10);
	update_prof_current_proc(LABEL(mercury__fact_table__open_sort_files_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__fact_table__open_sort_files_5_0_i7);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(4);
	localcall(mercury__fact_table__open_sort_files_5_0,
		LABEL(mercury__fact_table__open_sort_files_5_0_i11),
		STATIC(mercury__fact_table__open_sort_files_5_0));
Define_label(mercury__fact_table__open_sort_files_5_0_i11);
	update_prof_current_proc(LABEL(mercury__fact_table__open_sort_files_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__fact_table__open_sort_files_5_0_i1012);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module11)
	init_entry(mercury__fact_table__write_sort_file_lines_5_0);
	init_label(mercury__fact_table__write_sort_file_lines_5_0_i4);
	init_label(mercury__fact_table__write_sort_file_lines_5_0_i5);
	init_label(mercury__fact_table__write_sort_file_lines_5_0_i6);
	init_label(mercury__fact_table__write_sort_file_lines_5_0_i7);
	init_label(mercury__fact_table__write_sort_file_lines_5_0_i8);
	init_label(mercury__fact_table__write_sort_file_lines_5_0_i1002);
BEGIN_CODE

/* code for predicate 'write_sort_file_lines'/5 in mode 0 */
Define_static(mercury__fact_table__write_sort_file_lines_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__write_sort_file_lines_5_0_i1002);
	incr_sp_push_msg(6, "write_sort_file_lines");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__fact_table__write_sort_file_lines_5_0_i4,
		STATIC(mercury__fact_table__write_sort_file_lines_5_0));
	}
	}
Define_label(mercury__fact_table__write_sort_file_lines_5_0_i4);
	update_prof_current_proc(LABEL(mercury__fact_table__write_sort_file_lines_5_0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__fact_table__write_sort_file_lines_5_0_i5,
		STATIC(mercury__fact_table__write_sort_file_lines_5_0));
	}
Define_label(mercury__fact_table__write_sort_file_lines_5_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__write_sort_file_lines_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__fact_table__write_sort_file_lines_5_0_i6,
		STATIC(mercury__fact_table__write_sort_file_lines_5_0));
	}
Define_label(mercury__fact_table__write_sort_file_lines_5_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__write_sort_file_lines_5_0));
	call_localret(STATIC(mercury__fact_table__make_sort_file_key_2_0),
		mercury__fact_table__write_sort_file_lines_5_0_i7,
		STATIC(mercury__fact_table__write_sort_file_lines_5_0));
Define_label(mercury__fact_table__write_sort_file_lines_5_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__write_sort_file_lines_5_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_3);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__fact_table__write_sort_file_lines_5_0_i8,
		STATIC(mercury__fact_table__write_sort_file_lines_5_0));
	}
Define_label(mercury__fact_table__write_sort_file_lines_5_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__write_sort_file_lines_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__fact_table__write_sort_file_lines_5_0,
		STATIC(mercury__fact_table__write_sort_file_lines_5_0));
Define_label(mercury__fact_table__write_sort_file_lines_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module12)
	init_entry(mercury__fact_table__make_sort_file_key_2_0);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i16);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i15);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i18);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i17);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i20);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i21);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i22);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i19);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i24);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i13);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i25);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i26);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i1000);
	init_label(mercury__fact_table__make_sort_file_key_2_0_i1001);
BEGIN_CODE

/* code for predicate 'make_sort_file_key'/2 in mode 0 */
Define_static(mercury__fact_table__make_sort_file_key_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1001);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	if (((Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	if ((tag((Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), (char *)string_const("mercury_builtin", 15)) !=0))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), ((Integer) 1)), (char *)string_const("in", 2)) !=0))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i1000);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	incr_sp_push_msg(2, "make_sort_file_key");
	detstackvar(2) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i15);
	detstackvar(1) = (Integer) r2;
	r1 = string_const("make_key_part: enumerated types are not supported yet.", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__fact_table__make_sort_file_key_2_0_i16,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i16);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) r2;
	GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i13);
Define_label(mercury__fact_table__make_sort_file_key_2_0_i15);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i17);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__fact_table__make_sort_file_key_2_0_i18,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i18);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i13);
Define_label(mercury__fact_table__make_sort_file_key_2_0_i17);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__fact_table__make_sort_file_key_2_0_i19);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__string__to_char_list_2_0);
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__fact_table__make_sort_file_key_2_0_i20,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i20);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__fact_table__key_from_chars_2_3_0),
		mercury__fact_table__make_sort_file_key_2_0_i21,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
Define_label(mercury__fact_table__make_sort_file_key_2_0_i21);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_character_0[];
	r1 = (Integer) mercury_data___base_type_info_character_0;
	}
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__fact_table__make_sort_file_key_2_0_i22,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i22);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	{
	Declare_entry(mercury__string__from_char_list_2_0);
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__fact_table__make_sort_file_key_2_0_i18,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i19);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__string__float_to_string_2_0);
	call_localret(ENTRY(mercury__string__float_to_string_2_0),
		mercury__fact_table__make_sort_file_key_2_0_i24,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i24);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
Define_label(mercury__fact_table__make_sort_file_key_2_0_i13);
	detstackvar(1) = (Integer) r2;
	localcall(mercury__fact_table__make_sort_file_key_2_0,
		LABEL(mercury__fact_table__make_sort_file_key_2_0_i25),
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
Define_label(mercury__fact_table__make_sort_file_key_2_0_i25);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) r1;
	r1 = string_const(":", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__fact_table__make_sort_file_key_2_0_i26,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i26);
	update_prof_current_proc(LABEL(mercury__fact_table__make_sort_file_key_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
	}
Define_label(mercury__fact_table__make_sort_file_key_2_0_i1000);
	r1 = (Integer) r2;
	localtailcall(mercury__fact_table__make_sort_file_key_2_0,
		STATIC(mercury__fact_table__make_sort_file_key_2_0));
Define_label(mercury__fact_table__make_sort_file_key_2_0_i1001);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module13)
	init_entry(mercury__fact_table__key_from_chars_2_3_0);
	init_label(mercury__fact_table__key_from_chars_2_3_0_i15);
	init_label(mercury__fact_table__key_from_chars_2_3_0_i2);
	init_label(mercury__fact_table__key_from_chars_2_3_0_i5);
	init_label(mercury__fact_table__key_from_chars_2_3_0_i8);
	init_label(mercury__fact_table__key_from_chars_2_3_0_i13);
	init_label(mercury__fact_table__key_from_chars_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'key_from_chars_2'/3 in mode 0 */
Define_static(mercury__fact_table__key_from_chars_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i1);
Define_label(mercury__fact_table__key_from_chars_2_3_0_i15);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r4 != ((Integer) 92)))
		GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i2);
	r1 = (Integer) r3;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = ((Integer) 92);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = ((Integer) 92);
	GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i13);
Define_label(mercury__fact_table__key_from_chars_2_3_0_i2);
	if (((Integer) r4 != ((Integer) 58)))
		GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i5);
	r1 = (Integer) r3;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = ((Integer) 58);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = ((Integer) 92);
	GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i13);
Define_label(mercury__fact_table__key_from_chars_2_3_0_i5);
	if (((Integer) r4 != ((Integer) 10)))
		GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i8);
	r1 = (Integer) r3;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = ((Integer) 110);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = ((Integer) 92);
	GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i13);
Define_label(mercury__fact_table__key_from_chars_2_3_0_i8);
	r1 = (Integer) r3;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
Define_label(mercury__fact_table__key_from_chars_2_3_0_i13);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__key_from_chars_2_3_0_i15);
Define_label(mercury__fact_table__key_from_chars_2_3_0_i1);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__fact_table_module14)
	init_entry(mercury__fact_table__infer_determinism_pass_2_5_0);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i4);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i5);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i6);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i7);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i8);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i11);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i12);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i13);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i10);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i14);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i19);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i24);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i23);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i20);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i17);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i27);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i28);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i31);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i32);
	init_label(mercury__fact_table__infer_determinism_pass_2_5_0_i1011);
BEGIN_CODE

/* code for predicate 'infer_determinism_pass_2'/5 in mode 0 */
Define_static(mercury__fact_table__infer_determinism_pass_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i1011);
	incr_sp_push_msg(6, "infer_determinism_pass_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__fact_table__infer_determinism_pass_2_5_0_i4,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__output_stream_name_4_0);
	call_localret(ENTRY(mercury__io__output_stream_name_4_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i5,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__close_output_3_0);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i6,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("sort %s | sort -cu >/dev/null 2>&1", 34);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i7,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__call_system_4_0);
	call_localret(ENTRY(mercury__io__call_system_4_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i8,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i10);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i11,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Error executing system command `sort': ", 39);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i12,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i13,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 6);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i10);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i14);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(2);
	r6 = (Integer) r2;
	r2 = ((Integer) 1);
	GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i14);
	if (((Integer) r3 < ((Integer) 1)))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i17);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i19,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i20);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i24);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i23);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i24);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i20);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i23);
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = ((Integer) 4);
	GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i20);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 2);
	r6 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i17);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_fact_table__common_8);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i27,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i28,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 6);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i9);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0),
		mercury__fact_table__infer_determinism_pass_2_5_0_i31,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__fact_table__infer_determinism_pass_2_5_0_i32,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
	}
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i32);
	update_prof_current_proc(LABEL(mercury__fact_table__infer_determinism_pass_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__fact_table__infer_determinism_pass_2_5_0,
		STATIC(mercury__fact_table__infer_determinism_pass_2_5_0));
Define_label(mercury__fact_table__infer_determinism_pass_2_5_0_i1011);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__fact_table_bunch_0(void)
{
	mercury__fact_table_module0();
	mercury__fact_table_module1();
	mercury__fact_table_module2();
	mercury__fact_table_module3();
	mercury__fact_table_module4();
	mercury__fact_table_module5();
	mercury__fact_table_module6();
	mercury__fact_table_module7();
	mercury__fact_table_module8();
	mercury__fact_table_module9();
	mercury__fact_table_module10();
	mercury__fact_table_module11();
	mercury__fact_table_module12();
	mercury__fact_table_module13();
	mercury__fact_table_module14();
}

#endif

void mercury__fact_table__init(void); /* suppress gcc warning */
void mercury__fact_table__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__fact_table_bunch_0();
#endif
}
