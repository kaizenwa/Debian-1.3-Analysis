/*
** Automatically generated from `globals.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__globals__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___globals_globals_0__ua10000_2_0);
Define_extern_entry(mercury__globals__convert_gc_method_2_0);
Declare_label(mercury__globals__convert_gc_method_2_0_i3);
Declare_label(mercury__globals__convert_gc_method_2_0_i4);
Declare_label(mercury__globals__convert_gc_method_2_0_i1);
Define_extern_entry(mercury__globals__convert_tags_method_2_0);
Declare_label(mercury__globals__convert_tags_method_2_0_i3);
Declare_label(mercury__globals__convert_tags_method_2_0_i4);
Declare_label(mercury__globals__convert_tags_method_2_0_i1);
Define_extern_entry(mercury__globals__convert_args_method_2_0);
Declare_label(mercury__globals__convert_args_method_2_0_i3);
Declare_label(mercury__globals__convert_args_method_2_0_i1);
Define_extern_entry(mercury__globals__convert_type_info_method_3_0);
Declare_label(mercury__globals__convert_type_info_method_3_0_i4);
Declare_label(mercury__globals__convert_type_info_method_3_0_i5);
Declare_label(mercury__globals__convert_type_info_method_3_0_i6);
Declare_label(mercury__globals__convert_type_info_method_3_0_i8);
Declare_label(mercury__globals__convert_type_info_method_3_0_i3);
Declare_label(mercury__globals__convert_type_info_method_3_0_i9);
Declare_label(mercury__globals__convert_type_info_method_3_0_i10);
Declare_label(mercury__globals__convert_type_info_method_3_0_i12);
Declare_label(mercury__globals__convert_type_info_method_3_0_i13);
Declare_label(mercury__globals__convert_type_info_method_3_0_i14);
Declare_label(mercury__globals__convert_type_info_method_3_0_i17);
Declare_label(mercury__globals__convert_type_info_method_3_0_i1);
Declare_label(mercury__globals__convert_type_info_method_3_0_i1000);
Define_extern_entry(mercury__globals__convert_prolog_dialect_2_0);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i3);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i1000);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i5);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i6);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i8);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i13);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i18);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i1);
Define_extern_entry(mercury__globals__init_7_0);
Define_extern_entry(mercury__globals__get_options_2_0);
Define_extern_entry(mercury__globals__get_gc_method_2_0);
Define_extern_entry(mercury__globals__get_tags_method_2_0);
Define_extern_entry(mercury__globals__get_args_method_2_0);
Define_extern_entry(mercury__globals__get_type_info_method_2_0);
Define_extern_entry(mercury__globals__get_prolog_dialect_2_0);
Define_extern_entry(mercury__globals__set_options_3_0);
Define_extern_entry(mercury__globals__set_gc_method_3_0);
Define_extern_entry(mercury__globals__set_tags_method_3_0);
Define_extern_entry(mercury__globals__set_args_method_3_0);
Define_extern_entry(mercury__globals__set_type_info_method_3_0);
Define_extern_entry(mercury__globals__set_prolog_dialect_3_0);
Define_extern_entry(mercury__globals__lookup_option_3_0);
Declare_label(mercury__globals__lookup_option_3_0_i2);
Define_extern_entry(mercury__globals__lookup_bool_option_3_1);
Declare_label(mercury__globals__lookup_bool_option_3_1_i2);
Declare_label(mercury__globals__lookup_bool_option_3_1_i3);
Declare_label(mercury__globals__lookup_bool_option_3_1_i7);
Declare_label(mercury__globals__lookup_bool_option_3_1_i1);
Define_extern_entry(mercury__globals__lookup_bool_option_3_0);
Declare_label(mercury__globals__lookup_bool_option_3_0_i2);
Declare_label(mercury__globals__lookup_bool_option_3_0_i1000);
Define_extern_entry(mercury__globals__lookup_int_option_3_0);
Declare_label(mercury__globals__lookup_int_option_3_0_i2);
Declare_label(mercury__globals__lookup_int_option_3_0_i1000);
Define_extern_entry(mercury__globals__lookup_string_option_3_0);
Declare_label(mercury__globals__lookup_string_option_3_0_i2);
Declare_label(mercury__globals__lookup_string_option_3_0_i3);
Declare_label(mercury__globals__lookup_string_option_3_0_i1000);
Define_extern_entry(mercury__globals__lookup_accumulating_option_3_0);
Declare_label(mercury__globals__lookup_accumulating_option_3_0_i2);
Declare_label(mercury__globals__lookup_accumulating_option_3_0_i3);
Declare_label(mercury__globals__lookup_accumulating_option_3_0_i1000);
Define_extern_entry(mercury__globals__io_init_8_0);
Declare_label(mercury__globals__io_init_8_0_i2);
Declare_label(mercury__globals__io_init_8_0_i3);
Declare_label(mercury__globals__io_init_8_0_i4);
Declare_label(mercury__globals__io_init_8_0_i5);
Declare_label(mercury__globals__io_init_8_0_i6);
Declare_label(mercury__globals__io_init_8_0_i7);
Define_extern_entry(mercury__globals__io_get_gc_method_3_0);
Declare_label(mercury__globals__io_get_gc_method_3_0_i2);
Declare_label(mercury__globals__io_get_gc_method_3_0_i3);
Define_extern_entry(mercury__globals__io_get_tags_method_3_0);
Declare_label(mercury__globals__io_get_tags_method_3_0_i2);
Declare_label(mercury__globals__io_get_tags_method_3_0_i3);
Define_extern_entry(mercury__globals__io_get_args_method_3_0);
Declare_label(mercury__globals__io_get_args_method_3_0_i2);
Declare_label(mercury__globals__io_get_args_method_3_0_i3);
Define_extern_entry(mercury__globals__io_get_type_info_method_3_0);
Declare_label(mercury__globals__io_get_type_info_method_3_0_i2);
Declare_label(mercury__globals__io_get_type_info_method_3_0_i3);
Define_extern_entry(mercury__globals__io_get_prolog_dialect_3_0);
Declare_label(mercury__globals__io_get_prolog_dialect_3_0_i2);
Declare_label(mercury__globals__io_get_prolog_dialect_3_0_i3);
Define_extern_entry(mercury__globals__io_get_globals_3_0);
Declare_label(mercury__globals__io_get_globals_3_0_i2);
Declare_label(mercury__globals__io_get_globals_3_0_i5);
Declare_label(mercury__globals__io_get_globals_3_0_i4);
Declare_label(mercury__globals__io_get_globals_3_0_i7);
Define_extern_entry(mercury__globals__io_set_globals_3_0);
Declare_label(mercury__globals__io_set_globals_3_0_i2);
Define_extern_entry(mercury__globals__io_lookup_option_4_0);
Declare_label(mercury__globals__io_lookup_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_option_4_0_i3);
Declare_label(mercury__globals__io_lookup_option_4_0_i4);
Define_extern_entry(mercury__globals__io_set_option_4_0);
Declare_label(mercury__globals__io_set_option_4_0_i2);
Declare_label(mercury__globals__io_set_option_4_0_i3);
Declare_label(mercury__globals__io_set_option_4_0_i4);
Declare_label(mercury__globals__io_set_option_4_0_i5);
Declare_label(mercury__globals__io_set_option_4_0_i6);
Define_extern_entry(mercury__globals__io_lookup_bool_option_4_1);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i2);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i3);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i1);
Define_extern_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i3);
Define_extern_entry(mercury__globals__io_lookup_int_option_4_0);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i3);
Define_extern_entry(mercury__globals__io_lookup_string_option_4_0);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i3);
Define_extern_entry(mercury__globals__io_lookup_accumulating_option_4_0);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i3);
Define_extern_entry(mercury____Unify___globals__globals_0_0);
Declare_label(mercury____Unify___globals__globals_0_0_i2);
Declare_label(mercury____Unify___globals__globals_0_0_i1);
Define_extern_entry(mercury____Index___globals__globals_0_0);
Define_extern_entry(mercury____Compare___globals__globals_0_0);
Declare_label(mercury____Compare___globals__globals_0_0_i4);
Declare_label(mercury____Compare___globals__globals_0_0_i5);
Declare_label(mercury____Compare___globals__globals_0_0_i3);
Declare_label(mercury____Compare___globals__globals_0_0_i10);
Declare_label(mercury____Compare___globals__globals_0_0_i16);
Declare_label(mercury____Compare___globals__globals_0_0_i22);
Declare_label(mercury____Compare___globals__globals_0_0_i28);
Define_extern_entry(mercury____Unify___globals__gc_method_0_0);
Declare_label(mercury____Unify___globals__gc_method_0_0_i1);
Define_extern_entry(mercury____Index___globals__gc_method_0_0);
Define_extern_entry(mercury____Compare___globals__gc_method_0_0);
Define_extern_entry(mercury____Unify___globals__tags_method_0_0);
Declare_label(mercury____Unify___globals__tags_method_0_0_i1);
Define_extern_entry(mercury____Index___globals__tags_method_0_0);
Define_extern_entry(mercury____Compare___globals__tags_method_0_0);
Define_extern_entry(mercury____Unify___globals__args_method_0_0);
Declare_label(mercury____Unify___globals__args_method_0_0_i1);
Define_extern_entry(mercury____Index___globals__args_method_0_0);
Define_extern_entry(mercury____Compare___globals__args_method_0_0);
Define_extern_entry(mercury____Unify___globals__type_info_method_0_0);
Declare_label(mercury____Unify___globals__type_info_method_0_0_i1);
Define_extern_entry(mercury____Index___globals__type_info_method_0_0);
Define_extern_entry(mercury____Compare___globals__type_info_method_0_0);
Define_extern_entry(mercury____Unify___globals__prolog_dialect_0_0);
Declare_label(mercury____Unify___globals__prolog_dialect_0_0_i1);
Define_extern_entry(mercury____Index___globals__prolog_dialect_0_0);
Define_extern_entry(mercury____Compare___globals__prolog_dialect_0_0);

extern Word * mercury_data_globals__base_type_layout_args_method_0[];
Word * mercury_data_globals__base_type_info_args_method_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___globals__args_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___globals__args_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___globals__args_method_0_0),
	(Word *) (Integer) mercury_data_globals__base_type_layout_args_method_0
};

extern Word * mercury_data_globals__base_type_layout_gc_method_0[];
Word * mercury_data_globals__base_type_info_gc_method_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___globals__gc_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___globals__gc_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___globals__gc_method_0_0),
	(Word *) (Integer) mercury_data_globals__base_type_layout_gc_method_0
};

extern Word * mercury_data_globals__base_type_layout_globals_0[];
Word * mercury_data_globals__base_type_info_globals_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___globals__globals_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___globals__globals_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___globals__globals_0_0),
	(Word *) (Integer) mercury_data_globals__base_type_layout_globals_0
};

extern Word * mercury_data_globals__base_type_layout_prolog_dialect_0[];
Word * mercury_data_globals__base_type_info_prolog_dialect_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___globals__prolog_dialect_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___globals__prolog_dialect_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___globals__prolog_dialect_0_0),
	(Word *) (Integer) mercury_data_globals__base_type_layout_prolog_dialect_0
};

extern Word * mercury_data_globals__base_type_layout_tags_method_0[];
Word * mercury_data_globals__base_type_info_tags_method_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___globals__tags_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___globals__tags_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___globals__tags_method_0_0),
	(Word *) (Integer) mercury_data_globals__base_type_layout_tags_method_0
};

extern Word * mercury_data_globals__base_type_layout_type_info_method_0[];
Word * mercury_data_globals__base_type_info_type_info_method_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___globals__type_info_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___globals__type_info_method_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___globals__type_info_method_0_0),
	(Word *) (Integer) mercury_data_globals__base_type_layout_type_info_method_0
};

extern Word * mercury_data_globals__common_2[];
Word * mercury_data_globals__base_type_layout_type_info_method_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_2)
};

extern Word * mercury_data_globals__common_3[];
Word * mercury_data_globals__base_type_layout_tags_method_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_3)
};

extern Word * mercury_data_globals__common_4[];
Word * mercury_data_globals__base_type_layout_prolog_dialect_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_4)
};

extern Word * mercury_data_globals__common_11[];
Word * mercury_data_globals__base_type_layout_globals_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_globals__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_globals__common_12[];
Word * mercury_data_globals__base_type_layout_gc_method_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_12)
};

extern Word * mercury_data_globals__common_13[];
Word * mercury_data_globals__base_type_layout_args_method_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_13)
};

Word * mercury_data_globals__common_0[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("Sicstus-Prolog", 14),
	(Word *) string_const("SICStus-Prolog", 14),
	(Word *) string_const("NU-Prolog", 9),
	(Word *) string_const("NU", 2),
	(Word *) string_const("NUprolog", 8),
	(Word *) string_const("Sicstus", 7),
	(Word *) string_const("SICStus", 7),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("default", 7),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("sicstus-prolog", 14),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("nu-prolog", 9),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("nu", 2),
	(Word *) string_const("nuprolog", 8),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("sicstus", 7)
};

Word mercury_data_globals__common_1[] = {
	((Integer) -2),
	((Integer) 2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) 7),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 3),
	((Integer) -2),
	((Integer) -2),
	((Integer) 4),
	((Integer) 5),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 6)
};

Word * mercury_data_globals__common_2[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("one_cell", 8),
	(Word *) string_const("one_or_two_cell", 15),
	(Word *) string_const("shared_one_or_two_cell", 22)
};

Word * mercury_data_globals__common_3[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("none", 4),
	(Word *) string_const("low", 3),
	(Word *) string_const("high", 4)
};

Word * mercury_data_globals__common_4[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("default", 7),
	(Word *) string_const("nu", 2),
	(Word *) string_const("sicstus", 7)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_options__base_type_info_option_0[];
extern Word * mercury_data_getopt__base_type_info_option_data_0[];
Word * mercury_data_globals__common_5[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_options__base_type_info_option_0,
	(Word *) (Integer) mercury_data_getopt__base_type_info_option_data_0
};

Word * mercury_data_globals__common_6[] = {
	(Word *) (Integer) mercury_data_globals__base_type_info_gc_method_0
};

Word * mercury_data_globals__common_7[] = {
	(Word *) (Integer) mercury_data_globals__base_type_info_tags_method_0
};

Word * mercury_data_globals__common_8[] = {
	(Word *) (Integer) mercury_data_globals__base_type_info_args_method_0
};

Word * mercury_data_globals__common_9[] = {
	(Word *) (Integer) mercury_data_globals__base_type_info_type_info_method_0
};

Word * mercury_data_globals__common_10[] = {
	(Word *) (Integer) mercury_data_globals__base_type_info_prolog_dialect_0
};

Word * mercury_data_globals__common_11[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_10),
	(Word *) string_const("globals", 7)
};

Word * mercury_data_globals__common_12[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("none", 4),
	(Word *) string_const("conservative", 12),
	(Word *) string_const("accurate", 8)
};

Word * mercury_data_globals__common_13[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("simple", 6),
	(Word *) string_const("compact", 7)
};

BEGIN_MODULE(mercury__globals_module0)
	init_entry(mercury____Index___globals_globals_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___globals_globals_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___globals_globals_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module1)
	init_entry(mercury__globals__convert_gc_method_2_0);
	init_label(mercury__globals__convert_gc_method_2_0_i3);
	init_label(mercury__globals__convert_gc_method_2_0_i4);
	init_label(mercury__globals__convert_gc_method_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_gc_method'/2 in mode 0 */
Define_entry(mercury__globals__convert_gc_method_2_0);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("accurate", 8)) !=0))
		GOTO_LABEL(mercury__globals__convert_gc_method_2_0_i3);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_gc_method_2_0_i3);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("conservative", 12)) !=0))
		GOTO_LABEL(mercury__globals__convert_gc_method_2_0_i4);
	r2 = ((Integer) 1);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_gc_method_2_0_i4);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("none", 4)) !=0))
		GOTO_LABEL(mercury__globals__convert_gc_method_2_0_i1);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_gc_method_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module2)
	init_entry(mercury__globals__convert_tags_method_2_0);
	init_label(mercury__globals__convert_tags_method_2_0_i3);
	init_label(mercury__globals__convert_tags_method_2_0_i4);
	init_label(mercury__globals__convert_tags_method_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_tags_method'/2 in mode 0 */
Define_entry(mercury__globals__convert_tags_method_2_0);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("high", 4)) !=0))
		GOTO_LABEL(mercury__globals__convert_tags_method_2_0_i3);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_tags_method_2_0_i3);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("low", 3)) !=0))
		GOTO_LABEL(mercury__globals__convert_tags_method_2_0_i4);
	r2 = ((Integer) 1);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_tags_method_2_0_i4);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("none", 4)) !=0))
		GOTO_LABEL(mercury__globals__convert_tags_method_2_0_i1);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_tags_method_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module3)
	init_entry(mercury__globals__convert_args_method_2_0);
	init_label(mercury__globals__convert_args_method_2_0_i3);
	init_label(mercury__globals__convert_args_method_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_args_method'/2 in mode 0 */
Define_entry(mercury__globals__convert_args_method_2_0);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("compact", 7)) !=0))
		GOTO_LABEL(mercury__globals__convert_args_method_2_0_i3);
	r2 = ((Integer) 1);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_args_method_2_0_i3);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("simple", 6)) !=0))
		GOTO_LABEL(mercury__globals__convert_args_method_2_0_i1);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_args_method_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module4)
	init_entry(mercury__globals__convert_type_info_method_3_0);
	init_label(mercury__globals__convert_type_info_method_3_0_i4);
	init_label(mercury__globals__convert_type_info_method_3_0_i5);
	init_label(mercury__globals__convert_type_info_method_3_0_i6);
	init_label(mercury__globals__convert_type_info_method_3_0_i8);
	init_label(mercury__globals__convert_type_info_method_3_0_i3);
	init_label(mercury__globals__convert_type_info_method_3_0_i9);
	init_label(mercury__globals__convert_type_info_method_3_0_i10);
	init_label(mercury__globals__convert_type_info_method_3_0_i12);
	init_label(mercury__globals__convert_type_info_method_3_0_i13);
	init_label(mercury__globals__convert_type_info_method_3_0_i14);
	init_label(mercury__globals__convert_type_info_method_3_0_i17);
	init_label(mercury__globals__convert_type_info_method_3_0_i1);
	init_label(mercury__globals__convert_type_info_method_3_0_i1000);
BEGIN_CODE

/* code for predicate 'convert_type_info_method'/3 in mode 0 */
Define_entry(mercury__globals__convert_type_info_method_3_0);
	incr_sp_push_msg(2, "convert_type_info_method");
	detstackvar(2) = (Integer) succip;
	if ((strcmp((char *)(Integer) r1, (char *)string_const("default", 7)) !=0))
		GOTO_LABEL(mercury__globals__convert_type_info_method_3_0_i3);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r3 = ((Integer) 48);
	{
	Declare_entry(mercury__getopt__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__globals__convert_type_info_method_3_0_i4,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r3 = ((Integer) 50);
	{
	Declare_entry(mercury__getopt__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__globals__convert_type_info_method_3_0_i5,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i5);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__exprn_aux__imported_is_constant_3_0);
	call_localret(ENTRY(mercury__exprn_aux__imported_is_constant_3_0),
		mercury__globals__convert_type_info_method_3_0_i6,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__globals__convert_type_info_method_3_0_i1000);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_type_info_method_3_0_i8);
	r2 = ((Integer) 2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__convert_type_info_method_3_0_i3);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("one-cell", 8)) !=0))
		GOTO_LABEL(mercury__globals__convert_type_info_method_3_0_i9);
	r2 = ((Integer) 0);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__convert_type_info_method_3_0_i9);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("one-or-two-cell", 15)) !=0))
		GOTO_LABEL(mercury__globals__convert_type_info_method_3_0_i10);
	r2 = ((Integer) 1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__convert_type_info_method_3_0_i10);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("shared-one-or-two-cell", 22)) !=0))
		GOTO_LABEL(mercury__globals__convert_type_info_method_3_0_i1);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r3 = ((Integer) 48);
	{
	Declare_entry(mercury__getopt__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__globals__convert_type_info_method_3_0_i12,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i12);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r3 = ((Integer) 50);
	{
	Declare_entry(mercury__getopt__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__globals__convert_type_info_method_3_0_i13,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i13);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__exprn_aux__imported_is_constant_3_0);
	call_localret(ENTRY(mercury__exprn_aux__imported_is_constant_3_0),
		mercury__globals__convert_type_info_method_3_0_i14,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i14);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__globals__convert_type_info_method_3_0_i8);
	r1 = string_const("shared_one_or_two_cell requires static code addresses", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__convert_type_info_method_3_0_i17,
		ENTRY(mercury__globals__convert_type_info_method_3_0));
	}
Define_label(mercury__globals__convert_type_info_method_3_0_i17);
	update_prof_current_proc(LABEL(mercury__globals__convert_type_info_method_3_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__convert_type_info_method_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__convert_type_info_method_3_0_i1000);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module5)
	init_entry(mercury__globals__convert_prolog_dialect_2_0);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i3);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i1000);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i5);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i6);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i8);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i13);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i18);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_prolog_dialect'/2 in mode 0 */
Define_entry(mercury__globals__convert_prolog_dialect_2_0);
	r2 = (hash_string((Integer) r1) & ((Integer) 31));
Define_label(mercury__globals__convert_prolog_dialect_2_0_i3);
	r3 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_0))[(Integer) r2];
	if (!((Integer) r3))
		GOTO_LABEL(mercury__globals__convert_prolog_dialect_2_0_i1000);
	if ((strcmp((char *)(Integer) r3, (char *)(Integer) r1) ==0))
		GOTO_LABEL(mercury__globals__convert_prolog_dialect_2_0_i5);
Define_label(mercury__globals__convert_prolog_dialect_2_0_i1000);
	r2 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_globals__common_1))[(Integer) r2];
	if (((Integer) r2 >= ((Integer) 0)))
		GOTO_LABEL(mercury__globals__convert_prolog_dialect_2_0_i3);
	r1 = FALSE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i5);
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i6) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i6) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i8) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i8) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i8) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i6) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i6) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i13) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i6) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i8) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i8) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i8) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18));
Define_label(mercury__globals__convert_prolog_dialect_2_0_i6);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i8);
	r2 = ((Integer) 1);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i13);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i18);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module6)
	init_entry(mercury__globals__init_7_0);
BEGIN_CODE

/* code for predicate 'globals__init'/7 in mode 0 */
Define_entry(mercury__globals__init_7_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 5)) = (Integer) r6;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module7)
	init_entry(mercury__globals__get_options_2_0);
BEGIN_CODE

/* code for predicate 'globals__get_options'/2 in mode 0 */
Define_entry(mercury__globals__get_options_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module8)
	init_entry(mercury__globals__get_gc_method_2_0);
BEGIN_CODE

/* code for predicate 'globals__get_gc_method'/2 in mode 0 */
Define_entry(mercury__globals__get_gc_method_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module9)
	init_entry(mercury__globals__get_tags_method_2_0);
BEGIN_CODE

/* code for predicate 'globals__get_tags_method'/2 in mode 0 */
Define_entry(mercury__globals__get_tags_method_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module10)
	init_entry(mercury__globals__get_args_method_2_0);
BEGIN_CODE

/* code for predicate 'globals__get_args_method'/2 in mode 0 */
Define_entry(mercury__globals__get_args_method_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module11)
	init_entry(mercury__globals__get_type_info_method_2_0);
BEGIN_CODE

/* code for predicate 'globals__get_type_info_method'/2 in mode 0 */
Define_entry(mercury__globals__get_type_info_method_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module12)
	init_entry(mercury__globals__get_prolog_dialect_2_0);
BEGIN_CODE

/* code for predicate 'globals__get_prolog_dialect'/2 in mode 0 */
Define_entry(mercury__globals__get_prolog_dialect_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module13)
	init_entry(mercury__globals__set_options_3_0);
BEGIN_CODE

/* code for predicate 'globals__set_options'/3 in mode 0 */
Define_entry(mercury__globals__set_options_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module14)
	init_entry(mercury__globals__set_gc_method_3_0);
BEGIN_CODE

/* code for predicate 'globals__set_gc_method'/3 in mode 0 */
Define_entry(mercury__globals__set_gc_method_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module15)
	init_entry(mercury__globals__set_tags_method_3_0);
BEGIN_CODE

/* code for predicate 'globals__set_tags_method'/3 in mode 0 */
Define_entry(mercury__globals__set_tags_method_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module16)
	init_entry(mercury__globals__set_args_method_3_0);
BEGIN_CODE

/* code for predicate 'globals__set_args_method'/3 in mode 0 */
Define_entry(mercury__globals__set_args_method_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module17)
	init_entry(mercury__globals__set_type_info_method_3_0);
BEGIN_CODE

/* code for predicate 'globals__set_type_info_method'/3 in mode 0 */
Define_entry(mercury__globals__set_type_info_method_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module18)
	init_entry(mercury__globals__set_prolog_dialect_3_0);
BEGIN_CODE

/* code for predicate 'globals__set_prolog_dialect'/3 in mode 0 */
Define_entry(mercury__globals__set_prolog_dialect_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module19)
	init_entry(mercury__globals__lookup_option_3_0);
	init_label(mercury__globals__lookup_option_3_0_i2);
BEGIN_CODE

/* code for predicate 'globals__lookup_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_option_3_0);
	incr_sp_push_msg(2, "globals__lookup_option");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_options_2_0),
		mercury__globals__lookup_option_3_0_i2,
		ENTRY(mercury__globals__lookup_option_3_0));
	}
Define_label(mercury__globals__lookup_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_option_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__globals__lookup_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module20)
	init_entry(mercury__globals__lookup_bool_option_3_1);
	init_label(mercury__globals__lookup_bool_option_3_1_i2);
	init_label(mercury__globals__lookup_bool_option_3_1_i3);
	init_label(mercury__globals__lookup_bool_option_3_1_i7);
	init_label(mercury__globals__lookup_bool_option_3_1_i1);
BEGIN_CODE

/* code for predicate 'globals__lookup_bool_option'/3 in mode 1 */
Define_entry(mercury__globals__lookup_bool_option_3_1);
	incr_sp_push_msg(2, "globals__lookup_bool_option");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__lookup_option_3_0),
		mercury__globals__lookup_bool_option_3_1_i2,
		ENTRY(mercury__globals__lookup_bool_option_3_1));
	}
Define_label(mercury__globals__lookup_bool_option_3_1_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_bool_option_3_1));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__globals__lookup_bool_option_3_1_i3);
	if (((Integer) detstackvar(1) != (Integer) field(mktag(1), (Integer) r1, ((Integer) 0))))
		GOTO_LABEL(mercury__globals__lookup_bool_option_3_1_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__lookup_bool_option_3_1_i3);
	r1 = string_const("globals__lookup_bool_option: invalid bool option", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__lookup_bool_option_3_1_i7,
		ENTRY(mercury__globals__lookup_bool_option_3_1));
	}
Define_label(mercury__globals__lookup_bool_option_3_1_i7);
	update_prof_current_proc(LABEL(mercury__globals__lookup_bool_option_3_1));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__lookup_bool_option_3_1_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module21)
	init_entry(mercury__globals__lookup_bool_option_3_0);
	init_label(mercury__globals__lookup_bool_option_3_0_i2);
	init_label(mercury__globals__lookup_bool_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'globals__lookup_bool_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_bool_option_3_0);
	incr_sp_push_msg(1, "globals__lookup_bool_option");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__lookup_option_3_0),
		mercury__globals__lookup_bool_option_3_0_i2,
		ENTRY(mercury__globals__lookup_bool_option_3_0));
	}
Define_label(mercury__globals__lookup_bool_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_bool_option_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__globals__lookup_bool_option_3_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__globals__lookup_bool_option_3_0_i1000);
	r1 = string_const("globals__lookup_bool_option: invalid bool option", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_bool_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module22)
	init_entry(mercury__globals__lookup_int_option_3_0);
	init_label(mercury__globals__lookup_int_option_3_0_i2);
	init_label(mercury__globals__lookup_int_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'globals__lookup_int_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_int_option_3_0);
	incr_sp_push_msg(1, "globals__lookup_int_option");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__lookup_option_3_0),
		mercury__globals__lookup_int_option_3_0_i2,
		ENTRY(mercury__globals__lookup_int_option_3_0));
	}
Define_label(mercury__globals__lookup_int_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_int_option_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__globals__lookup_int_option_3_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__globals__lookup_int_option_3_0_i1000);
	r1 = string_const("globals__lookup_int_option: invalid int option", 46);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_int_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module23)
	init_entry(mercury__globals__lookup_string_option_3_0);
	init_label(mercury__globals__lookup_string_option_3_0_i2);
	init_label(mercury__globals__lookup_string_option_3_0_i3);
	init_label(mercury__globals__lookup_string_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'globals__lookup_string_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_string_option_3_0);
	incr_sp_push_msg(1, "globals__lookup_string_option");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__lookup_option_3_0),
		mercury__globals__lookup_string_option_3_0_i2,
		ENTRY(mercury__globals__lookup_string_option_3_0));
	}
Define_label(mercury__globals__lookup_string_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_string_option_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__globals__lookup_string_option_3_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__globals__lookup_string_option_3_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__globals__lookup_string_option_3_0_i3);
	r1 = string_const("globals__lookup_string_option: invalid string option", 52);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_string_option_3_0));
	}
Define_label(mercury__globals__lookup_string_option_3_0_i1000);
	r1 = string_const("globals__lookup_string_option: invalid string option", 52);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_string_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module24)
	init_entry(mercury__globals__lookup_accumulating_option_3_0);
	init_label(mercury__globals__lookup_accumulating_option_3_0_i2);
	init_label(mercury__globals__lookup_accumulating_option_3_0_i3);
	init_label(mercury__globals__lookup_accumulating_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'globals__lookup_accumulating_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_accumulating_option_3_0);
	incr_sp_push_msg(1, "globals__lookup_accumulating_option");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__lookup_option_3_0),
		mercury__globals__lookup_accumulating_option_3_0_i2,
		ENTRY(mercury__globals__lookup_accumulating_option_3_0));
	}
Define_label(mercury__globals__lookup_accumulating_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_accumulating_option_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__globals__lookup_accumulating_option_3_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__globals__lookup_accumulating_option_3_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__globals__lookup_accumulating_option_3_0_i3);
	r1 = string_const("globals__lookup_accumulating_option: invalid accumulating option", 64);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_accumulating_option_3_0));
	}
Define_label(mercury__globals__lookup_accumulating_option_3_0_i1000);
	r1 = string_const("globals__lookup_accumulating_option: invalid accumulating option", 64);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_accumulating_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module25)
	init_entry(mercury__globals__io_init_8_0);
	init_label(mercury__globals__io_init_8_0_i2);
	init_label(mercury__globals__io_init_8_0_i3);
	init_label(mercury__globals__io_init_8_0_i4);
	init_label(mercury__globals__io_init_8_0_i5);
	init_label(mercury__globals__io_init_8_0_i6);
	init_label(mercury__globals__io_init_8_0_i7);
BEGIN_CODE

/* code for predicate 'globals__io_init'/8 in mode 0 */
Define_entry(mercury__globals__io_init_8_0);
	incr_sp_push_msg(7, "globals__io_init");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	r1 = (Integer) mercury_data_globals__base_type_info_gc_method_0;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i2,
		ENTRY(mercury__globals__io_init_8_0));
	}
Define_label(mercury__globals__io_init_8_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_tags_method_0;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i3,
		ENTRY(mercury__globals__io_init_8_0));
	}
Define_label(mercury__globals__io_init_8_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_args_method_0;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i4,
		ENTRY(mercury__globals__io_init_8_0));
	}
Define_label(mercury__globals__io_init_8_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_type_info_method_0;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i5,
		ENTRY(mercury__globals__io_init_8_0));
	}
Define_label(mercury__globals__io_init_8_0_i5);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_prolog_dialect_0;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i6,
		ENTRY(mercury__globals__io_init_8_0));
	}
Define_label(mercury__globals__io_init_8_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__globals__init_7_0),
		mercury__globals__io_init_8_0_i7,
		ENTRY(mercury__globals__io_init_8_0));
	}
Define_label(mercury__globals__io_init_8_0_i7);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
		tailcall(STATIC(mercury__globals__io_set_globals_3_0),
		ENTRY(mercury__globals__io_init_8_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module26)
	init_entry(mercury__globals__io_get_gc_method_3_0);
	init_label(mercury__globals__io_get_gc_method_3_0_i2);
	init_label(mercury__globals__io_get_gc_method_3_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_get_gc_method'/3 in mode 0 */
Define_entry(mercury__globals__io_get_gc_method_3_0);
	incr_sp_push_msg(2, "globals__io_get_gc_method");
	detstackvar(2) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_get_gc_method_3_0_i2,
		ENTRY(mercury__globals__io_get_gc_method_3_0));
	}
Define_label(mercury__globals__io_get_gc_method_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_gc_method_3_0));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_gc_method_2_0),
		mercury__globals__io_get_gc_method_3_0_i3,
		ENTRY(mercury__globals__io_get_gc_method_3_0));
	}
Define_label(mercury__globals__io_get_gc_method_3_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_get_gc_method_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module27)
	init_entry(mercury__globals__io_get_tags_method_3_0);
	init_label(mercury__globals__io_get_tags_method_3_0_i2);
	init_label(mercury__globals__io_get_tags_method_3_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_get_tags_method'/3 in mode 0 */
Define_entry(mercury__globals__io_get_tags_method_3_0);
	incr_sp_push_msg(2, "globals__io_get_tags_method");
	detstackvar(2) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_get_tags_method_3_0_i2,
		ENTRY(mercury__globals__io_get_tags_method_3_0));
	}
Define_label(mercury__globals__io_get_tags_method_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_tags_method_3_0));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_tags_method_2_0),
		mercury__globals__io_get_tags_method_3_0_i3,
		ENTRY(mercury__globals__io_get_tags_method_3_0));
	}
Define_label(mercury__globals__io_get_tags_method_3_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_get_tags_method_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module28)
	init_entry(mercury__globals__io_get_args_method_3_0);
	init_label(mercury__globals__io_get_args_method_3_0_i2);
	init_label(mercury__globals__io_get_args_method_3_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_get_args_method'/3 in mode 0 */
Define_entry(mercury__globals__io_get_args_method_3_0);
	incr_sp_push_msg(2, "globals__io_get_args_method");
	detstackvar(2) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_get_args_method_3_0_i2,
		ENTRY(mercury__globals__io_get_args_method_3_0));
	}
Define_label(mercury__globals__io_get_args_method_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_args_method_3_0));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_args_method_2_0),
		mercury__globals__io_get_args_method_3_0_i3,
		ENTRY(mercury__globals__io_get_args_method_3_0));
	}
Define_label(mercury__globals__io_get_args_method_3_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_get_args_method_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module29)
	init_entry(mercury__globals__io_get_type_info_method_3_0);
	init_label(mercury__globals__io_get_type_info_method_3_0_i2);
	init_label(mercury__globals__io_get_type_info_method_3_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_get_type_info_method'/3 in mode 0 */
Define_entry(mercury__globals__io_get_type_info_method_3_0);
	incr_sp_push_msg(2, "globals__io_get_type_info_method");
	detstackvar(2) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_get_type_info_method_3_0_i2,
		ENTRY(mercury__globals__io_get_type_info_method_3_0));
	}
Define_label(mercury__globals__io_get_type_info_method_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_type_info_method_3_0));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_type_info_method_2_0),
		mercury__globals__io_get_type_info_method_3_0_i3,
		ENTRY(mercury__globals__io_get_type_info_method_3_0));
	}
Define_label(mercury__globals__io_get_type_info_method_3_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_get_type_info_method_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module30)
	init_entry(mercury__globals__io_get_prolog_dialect_3_0);
	init_label(mercury__globals__io_get_prolog_dialect_3_0_i2);
	init_label(mercury__globals__io_get_prolog_dialect_3_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_get_prolog_dialect'/3 in mode 0 */
Define_entry(mercury__globals__io_get_prolog_dialect_3_0);
	incr_sp_push_msg(2, "globals__io_get_prolog_dialect");
	detstackvar(2) = (Integer) succip;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_get_prolog_dialect_3_0_i2,
		ENTRY(mercury__globals__io_get_prolog_dialect_3_0));
	}
Define_label(mercury__globals__io_get_prolog_dialect_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_prolog_dialect_3_0));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_prolog_dialect_2_0),
		mercury__globals__io_get_prolog_dialect_3_0_i3,
		ENTRY(mercury__globals__io_get_prolog_dialect_3_0));
	}
Define_label(mercury__globals__io_get_prolog_dialect_3_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_get_prolog_dialect_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module31)
	init_entry(mercury__globals__io_get_globals_3_0);
	init_label(mercury__globals__io_get_globals_3_0_i2);
	init_label(mercury__globals__io_get_globals_3_0_i5);
	init_label(mercury__globals__io_get_globals_3_0_i4);
	init_label(mercury__globals__io_get_globals_3_0_i7);
BEGIN_CODE

/* code for predicate 'globals__io_get_globals'/3 in mode 0 */
Define_entry(mercury__globals__io_get_globals_3_0);
	incr_sp_push_msg(2, "globals__io_get_globals");
	detstackvar(2) = (Integer) succip;
	{
	Declare_entry(mercury__io__get_globals_3_0);
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_globals_3_0_i2,
		ENTRY(mercury__globals__io_get_globals_3_0));
	}
Define_label(mercury__globals__io_get_globals_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_globals_3_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_globals_0;
	{
	Declare_entry(mercury__std_util__univ_to_type_2_0);
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_globals_3_0_i5,
		ENTRY(mercury__globals__io_get_globals_3_0));
	}
Define_label(mercury__globals__io_get_globals_3_0_i5);
	update_prof_current_proc(LABEL(mercury__globals__io_get_globals_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__globals__io_get_globals_3_0_i4);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_globals_3_0_i4);
	r1 = string_const("globals__io_get_globals: univ_to_type failed", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_globals_3_0_i7,
		ENTRY(mercury__globals__io_get_globals_3_0));
	}
Define_label(mercury__globals__io_get_globals_3_0_i7);
	update_prof_current_proc(LABEL(mercury__globals__io_get_globals_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module32)
	init_entry(mercury__globals__io_set_globals_3_0);
	init_label(mercury__globals__io_set_globals_3_0_i2);
BEGIN_CODE

/* code for predicate 'globals__io_set_globals'/3 in mode 0 */
Define_entry(mercury__globals__io_set_globals_3_0);
	incr_sp_push_msg(2, "globals__io_set_globals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_globals_0;
	{
	Declare_entry(mercury__std_util__type_to_univ_2_0);
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__globals__io_set_globals_3_0_i2,
		ENTRY(mercury__globals__io_set_globals_3_0));
	}
Define_label(mercury__globals__io_set_globals_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_set_globals_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__set_globals_3_0);
	tailcall(ENTRY(mercury__io__set_globals_3_0),
		ENTRY(mercury__globals__io_set_globals_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module33)
	init_entry(mercury__globals__io_lookup_option_4_0);
	init_label(mercury__globals__io_lookup_option_4_0_i2);
	init_label(mercury__globals__io_lookup_option_4_0_i3);
	init_label(mercury__globals__io_lookup_option_4_0_i4);
BEGIN_CODE

/* code for predicate 'globals__io_lookup_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_option_4_0);
	incr_sp_push_msg(3, "globals__io_lookup_option");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_lookup_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_option_4_0));
	}
Define_label(mercury__globals__io_lookup_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_options_2_0),
		mercury__globals__io_lookup_option_4_0_i3,
		ENTRY(mercury__globals__io_lookup_option_4_0));
	}
Define_label(mercury__globals__io_lookup_option_4_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__globals__io_lookup_option_4_0_i4,
		ENTRY(mercury__globals__io_lookup_option_4_0));
	}
Define_label(mercury__globals__io_lookup_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module34)
	init_entry(mercury__globals__io_set_option_4_0);
	init_label(mercury__globals__io_set_option_4_0_i2);
	init_label(mercury__globals__io_set_option_4_0_i3);
	init_label(mercury__globals__io_set_option_4_0_i4);
	init_label(mercury__globals__io_set_option_4_0_i5);
	init_label(mercury__globals__io_set_option_4_0_i6);
BEGIN_CODE

/* code for predicate 'globals__io_set_option'/4 in mode 0 */
Define_entry(mercury__globals__io_set_option_4_0);
	incr_sp_push_msg(5, "globals__io_set_option");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_set_option_4_0_i2,
		ENTRY(mercury__globals__io_set_option_4_0));
	}
Define_label(mercury__globals__io_set_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__get_options_2_0),
		mercury__globals__io_set_option_4_0_i3,
		ENTRY(mercury__globals__io_set_option_4_0));
	}
Define_label(mercury__globals__io_set_option_4_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__globals__io_set_option_4_0_i4,
		ENTRY(mercury__globals__io_set_option_4_0));
	}
Define_label(mercury__globals__io_set_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__globals__set_options_3_0),
		mercury__globals__io_set_option_4_0_i5,
		ENTRY(mercury__globals__io_set_option_4_0));
	}
Define_label(mercury__globals__io_set_option_4_0_i5);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_globals__base_type_info_globals_0;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_set_option_4_0_i6,
		ENTRY(mercury__globals__io_set_option_4_0));
	}
Define_label(mercury__globals__io_set_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__globals__io_set_globals_3_0),
		ENTRY(mercury__globals__io_set_option_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module35)
	init_entry(mercury__globals__io_lookup_bool_option_4_1);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i2);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i3);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i1);
BEGIN_CODE

/* code for predicate 'globals__io_lookup_bool_option'/4 in mode 1 */
Define_entry(mercury__globals__io_lookup_bool_option_4_1);
	incr_sp_push_msg(3, "globals__io_lookup_bool_option");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_lookup_bool_option_4_1_i2,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
	}
Define_label(mercury__globals__io_lookup_bool_option_4_1_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_1));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__globals__lookup_bool_option_3_1),
		mercury__globals__io_lookup_bool_option_4_1_i3,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
	}
Define_label(mercury__globals__io_lookup_bool_option_4_1_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_1));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__globals__io_lookup_bool_option_4_1_i1);
	r2 = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__globals__io_lookup_bool_option_4_1_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module36)
	init_entry(mercury__globals__io_lookup_bool_option_4_0);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i2);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_lookup_bool_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_bool_option_4_0);
	incr_sp_push_msg(2, "globals__io_lookup_bool_option");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_lookup_bool_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
	}
Define_label(mercury__globals__io_lookup_bool_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__lookup_bool_option_3_0),
		mercury__globals__io_lookup_bool_option_4_0_i3,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
	}
Define_label(mercury__globals__io_lookup_bool_option_4_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module37)
	init_entry(mercury__globals__io_lookup_int_option_4_0);
	init_label(mercury__globals__io_lookup_int_option_4_0_i2);
	init_label(mercury__globals__io_lookup_int_option_4_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_lookup_int_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_int_option_4_0);
	incr_sp_push_msg(2, "globals__io_lookup_int_option");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_lookup_int_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
	}
Define_label(mercury__globals__io_lookup_int_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_int_option_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__lookup_int_option_3_0),
		mercury__globals__io_lookup_int_option_4_0_i3,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
	}
Define_label(mercury__globals__io_lookup_int_option_4_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_int_option_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module38)
	init_entry(mercury__globals__io_lookup_string_option_4_0);
	init_label(mercury__globals__io_lookup_string_option_4_0_i2);
	init_label(mercury__globals__io_lookup_string_option_4_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_lookup_string_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_string_option_4_0);
	incr_sp_push_msg(2, "globals__io_lookup_string_option");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_lookup_string_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
	}
Define_label(mercury__globals__io_lookup_string_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_string_option_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__lookup_string_option_3_0),
		mercury__globals__io_lookup_string_option_4_0_i3,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
	}
Define_label(mercury__globals__io_lookup_string_option_4_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_string_option_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module39)
	init_entry(mercury__globals__io_lookup_accumulating_option_4_0);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i2);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i3);
BEGIN_CODE

/* code for predicate 'globals__io_lookup_accumulating_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_accumulating_option_4_0);
	incr_sp_push_msg(2, "globals__io_lookup_accumulating_option");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__globals__io_get_globals_3_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
	}
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_accumulating_option_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__globals__lookup_accumulating_option_3_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i3,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
	}
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_accumulating_option_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module40)
	init_entry(mercury____Unify___globals__globals_0_0);
	init_label(mercury____Unify___globals__globals_0_0_i2);
	init_label(mercury____Unify___globals__globals_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__globals_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(11, "__Unify__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___globals__globals_0_0_i2,
		ENTRY(mercury____Unify___globals__globals_0_0));
	}
Define_label(mercury____Unify___globals__globals_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___globals__globals_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(6)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(7)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(8)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if (((Integer) detstackvar(4) != (Integer) detstackvar(9)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if (((Integer) detstackvar(5) != (Integer) detstackvar(10)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Unify___globals__globals_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module41)
	init_entry(mercury____Index___globals__globals_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__globals_0_0);
	tailcall(STATIC(mercury____Index___globals_globals_0__ua10000_2_0),
		ENTRY(mercury____Index___globals__globals_0_0));
END_MODULE

BEGIN_MODULE(mercury__globals_module42)
	init_entry(mercury____Compare___globals__globals_0_0);
	init_label(mercury____Compare___globals__globals_0_0_i4);
	init_label(mercury____Compare___globals__globals_0_0_i5);
	init_label(mercury____Compare___globals__globals_0_0_i3);
	init_label(mercury____Compare___globals__globals_0_0_i10);
	init_label(mercury____Compare___globals__globals_0_0_i16);
	init_label(mercury____Compare___globals__globals_0_0_i22);
	init_label(mercury____Compare___globals__globals_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__globals_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___globals__globals_0_0_i4,
		ENTRY(mercury____Compare___globals__globals_0_0));
	}
Define_label(mercury____Compare___globals__globals_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i3);
Define_label(mercury____Compare___globals__globals_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___globals__globals_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i10,
		ENTRY(mercury____Compare___globals__globals_0_0));
	}
Define_label(mercury____Compare___globals__globals_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i16,
		ENTRY(mercury____Compare___globals__globals_0_0));
	}
Define_label(mercury____Compare___globals__globals_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i22,
		ENTRY(mercury____Compare___globals__globals_0_0));
	}
Define_label(mercury____Compare___globals__globals_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i28,
		ENTRY(mercury____Compare___globals__globals_0_0));
	}
Define_label(mercury____Compare___globals__globals_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__globals_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module43)
	init_entry(mercury____Unify___globals__gc_method_0_0);
	init_label(mercury____Unify___globals__gc_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__gc_method_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___globals__gc_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__gc_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module44)
	init_entry(mercury____Index___globals__gc_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__gc_method_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___globals__gc_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module45)
	init_entry(mercury____Compare___globals__gc_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__gc_method_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__gc_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module46)
	init_entry(mercury____Unify___globals__tags_method_0_0);
	init_label(mercury____Unify___globals__tags_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__tags_method_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___globals__tags_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__tags_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module47)
	init_entry(mercury____Index___globals__tags_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__tags_method_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___globals__tags_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module48)
	init_entry(mercury____Compare___globals__tags_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__tags_method_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__tags_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module49)
	init_entry(mercury____Unify___globals__args_method_0_0);
	init_label(mercury____Unify___globals__args_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__args_method_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___globals__args_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__args_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module50)
	init_entry(mercury____Index___globals__args_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__args_method_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___globals__args_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module51)
	init_entry(mercury____Compare___globals__args_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__args_method_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__args_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module52)
	init_entry(mercury____Unify___globals__type_info_method_0_0);
	init_label(mercury____Unify___globals__type_info_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__type_info_method_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___globals__type_info_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__type_info_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module53)
	init_entry(mercury____Index___globals__type_info_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__type_info_method_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___globals__type_info_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module54)
	init_entry(mercury____Compare___globals__type_info_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__type_info_method_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__type_info_method_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module55)
	init_entry(mercury____Unify___globals__prolog_dialect_0_0);
	init_label(mercury____Unify___globals__prolog_dialect_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__prolog_dialect_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___globals__prolog_dialect_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__prolog_dialect_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__globals_module56)
	init_entry(mercury____Index___globals__prolog_dialect_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__prolog_dialect_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___globals__prolog_dialect_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__globals_module57)
	init_entry(mercury____Compare___globals__prolog_dialect_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__prolog_dialect_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__prolog_dialect_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__globals_bunch_0(void)
{
	mercury__globals_module0();
	mercury__globals_module1();
	mercury__globals_module2();
	mercury__globals_module3();
	mercury__globals_module4();
	mercury__globals_module5();
	mercury__globals_module6();
	mercury__globals_module7();
	mercury__globals_module8();
	mercury__globals_module9();
	mercury__globals_module10();
	mercury__globals_module11();
	mercury__globals_module12();
	mercury__globals_module13();
	mercury__globals_module14();
	mercury__globals_module15();
	mercury__globals_module16();
	mercury__globals_module17();
	mercury__globals_module18();
	mercury__globals_module19();
	mercury__globals_module20();
	mercury__globals_module21();
	mercury__globals_module22();
	mercury__globals_module23();
	mercury__globals_module24();
	mercury__globals_module25();
	mercury__globals_module26();
	mercury__globals_module27();
	mercury__globals_module28();
	mercury__globals_module29();
	mercury__globals_module30();
	mercury__globals_module31();
	mercury__globals_module32();
	mercury__globals_module33();
	mercury__globals_module34();
	mercury__globals_module35();
	mercury__globals_module36();
	mercury__globals_module37();
	mercury__globals_module38();
	mercury__globals_module39();
	mercury__globals_module40();
}

static void mercury__globals_bunch_1(void)
{
	mercury__globals_module41();
	mercury__globals_module42();
	mercury__globals_module43();
	mercury__globals_module44();
	mercury__globals_module45();
	mercury__globals_module46();
	mercury__globals_module47();
	mercury__globals_module48();
	mercury__globals_module49();
	mercury__globals_module50();
	mercury__globals_module51();
	mercury__globals_module52();
	mercury__globals_module53();
	mercury__globals_module54();
	mercury__globals_module55();
	mercury__globals_module56();
	mercury__globals_module57();
}

#endif

void mercury__globals__init(void); /* suppress gcc warning */
void mercury__globals__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__globals_bunch_0();
	mercury__globals_bunch_1();
#endif
}
