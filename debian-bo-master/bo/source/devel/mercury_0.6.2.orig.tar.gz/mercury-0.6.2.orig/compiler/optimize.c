/*
** Automatically generated from `optimize.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__optimize__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__optimize__main_4_0);
Declare_label(mercury__optimize__main_4_0_i4);
Declare_label(mercury__optimize__main_4_0_i5);
Declare_label(mercury__optimize__main_4_0_i1002);
Define_extern_entry(mercury__optimize__proc_4_0);
Declare_label(mercury__optimize__proc_4_0_i2);
Declare_label(mercury__optimize__proc_4_0_i3);
Declare_label(mercury__optimize__proc_4_0_i4);
Declare_label(mercury__optimize__proc_4_0_i5);
Declare_label(mercury__optimize__proc_4_0_i6);
Declare_label(mercury__optimize__proc_4_0_i7);
Declare_label(mercury__optimize__proc_4_0_i11);
Declare_label(mercury__optimize__proc_4_0_i12);
Declare_label(mercury__optimize__proc_4_0_i8);
Declare_label(mercury__optimize__proc_4_0_i13);
Declare_label(mercury__optimize__proc_4_0_i14);
Declare_label(mercury__optimize__proc_4_0_i15);
Declare_static(mercury__optimize__repeat_6_0);
Declare_label(mercury__optimize__repeat_6_0_i4);
Declare_label(mercury__optimize__repeat_6_0_i5);
Declare_label(mercury__optimize__repeat_6_0_i6);
Declare_label(mercury__optimize__repeat_6_0_i1003);
Declare_static(mercury__optimize__repeated_8_0);
Declare_label(mercury__optimize__repeated_8_0_i2);
Declare_label(mercury__optimize__repeated_8_0_i3);
Declare_label(mercury__optimize__repeated_8_0_i4);
Declare_label(mercury__optimize__repeated_8_0_i5);
Declare_label(mercury__optimize__repeated_8_0_i6);
Declare_label(mercury__optimize__repeated_8_0_i14);
Declare_label(mercury__optimize__repeated_8_0_i15);
Declare_label(mercury__optimize__repeated_8_0_i16);
Declare_label(mercury__optimize__repeated_8_0_i11);
Declare_label(mercury__optimize__repeated_8_0_i17);
Declare_label(mercury__optimize__repeated_8_0_i18);
Declare_label(mercury__optimize__repeated_8_0_i21);
Declare_label(mercury__optimize__repeated_8_0_i20);
Declare_label(mercury__optimize__repeated_8_0_i23);
Declare_label(mercury__optimize__repeated_8_0_i24);
Declare_label(mercury__optimize__repeated_8_0_i7);
Declare_label(mercury__optimize__repeated_8_0_i26);
Declare_label(mercury__optimize__repeated_8_0_i27);
Declare_label(mercury__optimize__repeated_8_0_i28);
Declare_label(mercury__optimize__repeated_8_0_i35);
Declare_label(mercury__optimize__repeated_8_0_i36);
Declare_label(mercury__optimize__repeated_8_0_i37);
Declare_label(mercury__optimize__repeated_8_0_i32);
Declare_label(mercury__optimize__repeated_8_0_i38);
Declare_label(mercury__optimize__repeated_8_0_i39);
Declare_label(mercury__optimize__repeated_8_0_i42);
Declare_label(mercury__optimize__repeated_8_0_i41);
Declare_label(mercury__optimize__repeated_8_0_i44);
Declare_label(mercury__optimize__repeated_8_0_i45);
Declare_label(mercury__optimize__repeated_8_0_i29);
Declare_label(mercury__optimize__repeated_8_0_i47);
Declare_label(mercury__optimize__repeated_8_0_i48);
Declare_label(mercury__optimize__repeated_8_0_i55);
Declare_label(mercury__optimize__repeated_8_0_i56);
Declare_label(mercury__optimize__repeated_8_0_i57);
Declare_label(mercury__optimize__repeated_8_0_i52);
Declare_label(mercury__optimize__repeated_8_0_i58);
Declare_label(mercury__optimize__repeated_8_0_i59);
Declare_label(mercury__optimize__repeated_8_0_i62);
Declare_label(mercury__optimize__repeated_8_0_i61);
Declare_label(mercury__optimize__repeated_8_0_i64);
Declare_label(mercury__optimize__repeated_8_0_i65);
Declare_label(mercury__optimize__repeated_8_0_i49);
Declare_label(mercury__optimize__repeated_8_0_i67);
Declare_label(mercury__optimize__repeated_8_0_i68);
Declare_label(mercury__optimize__repeated_8_0_i75);
Declare_label(mercury__optimize__repeated_8_0_i76);
Declare_label(mercury__optimize__repeated_8_0_i77);
Declare_label(mercury__optimize__repeated_8_0_i72);
Declare_label(mercury__optimize__repeated_8_0_i78);
Declare_label(mercury__optimize__repeated_8_0_i79);
Declare_label(mercury__optimize__repeated_8_0_i82);
Declare_label(mercury__optimize__repeated_8_0_i81);
Declare_label(mercury__optimize__repeated_8_0_i84);
Declare_label(mercury__optimize__repeated_8_0_i85);
Declare_label(mercury__optimize__repeated_8_0_i69);
Declare_label(mercury__optimize__repeated_8_0_i87);
Declare_label(mercury__optimize__repeated_8_0_i88);
Declare_label(mercury__optimize__repeated_8_0_i95);
Declare_label(mercury__optimize__repeated_8_0_i96);
Declare_label(mercury__optimize__repeated_8_0_i97);
Declare_label(mercury__optimize__repeated_8_0_i92);
Declare_label(mercury__optimize__repeated_8_0_i98);
Declare_label(mercury__optimize__repeated_8_0_i99);
Declare_label(mercury__optimize__repeated_8_0_i102);
Declare_label(mercury__optimize__repeated_8_0_i101);
Declare_label(mercury__optimize__repeated_8_0_i104);
Declare_label(mercury__optimize__repeated_8_0_i105);
Declare_label(mercury__optimize__repeated_8_0_i89);
Declare_label(mercury__optimize__repeated_8_0_i107);
Declare_label(mercury__optimize__repeated_8_0_i113);
Declare_label(mercury__optimize__repeated_8_0_i109);
Declare_label(mercury__optimize__repeated_8_0_i108);
Declare_label(mercury__optimize__repeated_8_0_i115);
Declare_label(mercury__optimize__repeated_8_0_i116);
Declare_label(mercury__optimize__repeated_8_0_i117);
Declare_static(mercury__optimize__nonrepeat_4_0);
Declare_label(mercury__optimize__nonrepeat_4_0_i2);
Declare_label(mercury__optimize__nonrepeat_4_0_i3);
Declare_label(mercury__optimize__nonrepeat_4_0_i4);
Declare_label(mercury__optimize__nonrepeat_4_0_i5);
Declare_label(mercury__optimize__nonrepeat_4_0_i6);
Declare_label(mercury__optimize__nonrepeat_4_0_i13);
Declare_label(mercury__optimize__nonrepeat_4_0_i14);
Declare_label(mercury__optimize__nonrepeat_4_0_i15);
Declare_label(mercury__optimize__nonrepeat_4_0_i10);
Declare_label(mercury__optimize__nonrepeat_4_0_i16);
Declare_label(mercury__optimize__nonrepeat_4_0_i17);
Declare_label(mercury__optimize__nonrepeat_4_0_i18);
Declare_label(mercury__optimize__nonrepeat_4_0_i21);
Declare_label(mercury__optimize__nonrepeat_4_0_i20);
Declare_label(mercury__optimize__nonrepeat_4_0_i23);
Declare_label(mercury__optimize__nonrepeat_4_0_i24);
Declare_label(mercury__optimize__nonrepeat_4_0_i7);
Declare_label(mercury__optimize__nonrepeat_4_0_i26);
Declare_label(mercury__optimize__nonrepeat_4_0_i27);
Declare_label(mercury__optimize__nonrepeat_4_0_i28);
Declare_label(mercury__optimize__nonrepeat_4_0_i33);
Declare_label(mercury__optimize__nonrepeat_4_0_i36);
Declare_label(mercury__optimize__nonrepeat_4_0_i35);
Declare_label(mercury__optimize__nonrepeat_4_0_i38);
Declare_label(mercury__optimize__nonrepeat_4_0_i39);
Declare_label(mercury__optimize__nonrepeat_4_0_i29);
Declare_label(mercury__optimize__nonrepeat_4_0_i41);
Declare_label(mercury__optimize__nonrepeat_4_0_i42);
Declare_label(mercury__optimize__nonrepeat_4_0_i49);
Declare_label(mercury__optimize__nonrepeat_4_0_i50);
Declare_label(mercury__optimize__nonrepeat_4_0_i51);
Declare_label(mercury__optimize__nonrepeat_4_0_i46);
Declare_label(mercury__optimize__nonrepeat_4_0_i52);
Declare_label(mercury__optimize__nonrepeat_4_0_i53);
Declare_label(mercury__optimize__nonrepeat_4_0_i56);
Declare_label(mercury__optimize__nonrepeat_4_0_i55);
Declare_label(mercury__optimize__nonrepeat_4_0_i58);
Declare_label(mercury__optimize__nonrepeat_4_0_i59);
Declare_label(mercury__optimize__nonrepeat_4_0_i43);
Declare_label(mercury__optimize__nonrepeat_4_0_i61);
Declare_label(mercury__optimize__nonrepeat_4_0_i64);
Declare_label(mercury__optimize__nonrepeat_4_0_i69);
Declare_label(mercury__optimize__nonrepeat_4_0_i75);
Declare_label(mercury__optimize__nonrepeat_4_0_i76);
Declare_label(mercury__optimize__nonrepeat_4_0_i79);
Declare_label(mercury__optimize__nonrepeat_4_0_i78);
Declare_label(mercury__optimize__nonrepeat_4_0_i81);
Declare_label(mercury__optimize__nonrepeat_4_0_i82);
Declare_label(mercury__optimize__nonrepeat_4_0_i70);
Declare_label(mercury__optimize__nonrepeat_4_0_i84);
Declare_label(mercury__optimize__nonrepeat_4_0_i87);
Declare_label(mercury__optimize__nonrepeat_4_0_i86);
Declare_label(mercury__optimize__nonrepeat_4_0_i89);
Declare_label(mercury__optimize__nonrepeat_4_0_i92);
Declare_label(mercury__optimize__nonrepeat_4_0_i91);
Declare_label(mercury__optimize__nonrepeat_4_0_i94);
Declare_label(mercury__optimize__nonrepeat_4_0_i95);
Declare_label(mercury__optimize__nonrepeat_4_0_i62);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_optimize__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

BEGIN_MODULE(mercury__optimize_module0)
	init_entry(mercury__optimize__main_4_0);
	init_label(mercury__optimize__main_4_0_i4);
	init_label(mercury__optimize__main_4_0_i5);
	init_label(mercury__optimize__main_4_0_i1002);
BEGIN_CODE

/* code for predicate 'optimize__main'/4 in mode 0 */
Define_entry(mercury__optimize__main_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__optimize__main_4_0_i1002);
	incr_sp_push_msg(2, "optimize__main");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__optimize__proc_4_0),
		mercury__optimize__main_4_0_i4,
		ENTRY(mercury__optimize__main_4_0));
	}
Define_label(mercury__optimize__main_4_0_i4);
	update_prof_current_proc(LABEL(mercury__optimize__main_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__optimize__main_4_0,
		LABEL(mercury__optimize__main_4_0_i5),
		ENTRY(mercury__optimize__main_4_0));
Define_label(mercury__optimize__main_4_0_i5);
	update_prof_current_proc(LABEL(mercury__optimize__main_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__optimize__main_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__optimize_module1)
	init_entry(mercury__optimize__proc_4_0);
	init_label(mercury__optimize__proc_4_0_i2);
	init_label(mercury__optimize__proc_4_0_i3);
	init_label(mercury__optimize__proc_4_0_i4);
	init_label(mercury__optimize__proc_4_0_i5);
	init_label(mercury__optimize__proc_4_0_i6);
	init_label(mercury__optimize__proc_4_0_i7);
	init_label(mercury__optimize__proc_4_0_i11);
	init_label(mercury__optimize__proc_4_0_i12);
	init_label(mercury__optimize__proc_4_0_i8);
	init_label(mercury__optimize__proc_4_0_i13);
	init_label(mercury__optimize__proc_4_0_i14);
	init_label(mercury__optimize__proc_4_0_i15);
BEGIN_CODE

/* code for predicate 'optimize__proc'/4 in mode 0 */
Define_entry(mercury__optimize__proc_4_0);
	incr_sp_push_msg(7, "optimize__proc");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r1 = ((Integer) 18);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__proc_4_0_i2,
		ENTRY(mercury__optimize__proc_4_0));
	}
Define_label(mercury__optimize__proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	detstackvar(5) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("before optimization", 19);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__proc_4_0_i3,
		ENTRY(mercury__optimize__proc_4_0));
	}
Define_label(mercury__optimize__proc_4_0_i3);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__proc_4_0_i4,
		ENTRY(mercury__optimize__proc_4_0));
	}
Define_label(mercury__optimize__proc_4_0_i4);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 125);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__optimize__proc_4_0_i5,
		ENTRY(mercury__optimize__proc_4_0));
	}
Define_label(mercury__optimize__proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = ((Integer) 126);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__optimize__proc_4_0_i6,
		ENTRY(mercury__optimize__proc_4_0));
	}
Define_label(mercury__optimize__proc_4_0_i6);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = ((Integer) 122);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__proc_4_0_i7,
		ENTRY(mercury__optimize__proc_4_0));
	}
Define_label(mercury__optimize__proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__proc_4_0_i8);
	r4 = (Integer) r2;
	r1 = ((Integer) detstackvar(5) - (Integer) detstackvar(6));
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__optimize__repeat_6_0),
		mercury__optimize__proc_4_0_i11,
		ENTRY(mercury__optimize__proc_4_0));
Define_label(mercury__optimize__proc_4_0_i11);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r4 = (Integer) r2;
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__optimize__repeat_6_0),
		mercury__optimize__proc_4_0_i12,
		ENTRY(mercury__optimize__proc_4_0));
Define_label(mercury__optimize__proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__optimize__proc_4_0_i14);
Define_label(mercury__optimize__proc_4_0_i8);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__optimize__repeat_6_0),
		mercury__optimize__proc_4_0_i13,
		ENTRY(mercury__optimize__proc_4_0));
Define_label(mercury__optimize__proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
Define_label(mercury__optimize__proc_4_0_i14);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	call_localret(STATIC(mercury__optimize__nonrepeat_4_0),
		mercury__optimize__proc_4_0_i15,
		ENTRY(mercury__optimize__proc_4_0));
Define_label(mercury__optimize__proc_4_0_i15);
	update_prof_current_proc(LABEL(mercury__optimize__proc_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__optimize_module2)
	init_entry(mercury__optimize__repeat_6_0);
	init_label(mercury__optimize__repeat_6_0_i4);
	init_label(mercury__optimize__repeat_6_0_i5);
	init_label(mercury__optimize__repeat_6_0_i6);
	init_label(mercury__optimize__repeat_6_0_i1003);
BEGIN_CODE

/* code for predicate 'optimize__repeat'/6 in mode 0 */
Define_static(mercury__optimize__repeat_6_0);
	if (((Integer) r1 <= ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeat_6_0_i1003);
	incr_sp_push_msg(5, "optimize__repeat");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__optimize__repeat_6_0_i4,
		STATIC(mercury__optimize__repeat_6_0));
	}
Define_label(mercury__optimize__repeat_6_0_i4);
	update_prof_current_proc(LABEL(mercury__optimize__repeat_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 1);
	r5 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__optimize__repeated_8_0),
		mercury__optimize__repeat_6_0_i5,
		STATIC(mercury__optimize__repeat_6_0));
Define_label(mercury__optimize__repeat_6_0_i5);
	update_prof_current_proc(LABEL(mercury__optimize__repeat_6_0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeat_6_0_i6);
	r4 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) - ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__optimize__repeat_6_0,
		STATIC(mercury__optimize__repeat_6_0));
Define_label(mercury__optimize__repeat_6_0_i6);
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__optimize__repeat_6_0_i1003);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__optimize_module3)
	init_entry(mercury__optimize__repeated_8_0);
	init_label(mercury__optimize__repeated_8_0_i2);
	init_label(mercury__optimize__repeated_8_0_i3);
	init_label(mercury__optimize__repeated_8_0_i4);
	init_label(mercury__optimize__repeated_8_0_i5);
	init_label(mercury__optimize__repeated_8_0_i6);
	init_label(mercury__optimize__repeated_8_0_i14);
	init_label(mercury__optimize__repeated_8_0_i15);
	init_label(mercury__optimize__repeated_8_0_i16);
	init_label(mercury__optimize__repeated_8_0_i11);
	init_label(mercury__optimize__repeated_8_0_i17);
	init_label(mercury__optimize__repeated_8_0_i18);
	init_label(mercury__optimize__repeated_8_0_i21);
	init_label(mercury__optimize__repeated_8_0_i20);
	init_label(mercury__optimize__repeated_8_0_i23);
	init_label(mercury__optimize__repeated_8_0_i24);
	init_label(mercury__optimize__repeated_8_0_i7);
	init_label(mercury__optimize__repeated_8_0_i26);
	init_label(mercury__optimize__repeated_8_0_i27);
	init_label(mercury__optimize__repeated_8_0_i28);
	init_label(mercury__optimize__repeated_8_0_i35);
	init_label(mercury__optimize__repeated_8_0_i36);
	init_label(mercury__optimize__repeated_8_0_i37);
	init_label(mercury__optimize__repeated_8_0_i32);
	init_label(mercury__optimize__repeated_8_0_i38);
	init_label(mercury__optimize__repeated_8_0_i39);
	init_label(mercury__optimize__repeated_8_0_i42);
	init_label(mercury__optimize__repeated_8_0_i41);
	init_label(mercury__optimize__repeated_8_0_i44);
	init_label(mercury__optimize__repeated_8_0_i45);
	init_label(mercury__optimize__repeated_8_0_i29);
	init_label(mercury__optimize__repeated_8_0_i47);
	init_label(mercury__optimize__repeated_8_0_i48);
	init_label(mercury__optimize__repeated_8_0_i55);
	init_label(mercury__optimize__repeated_8_0_i56);
	init_label(mercury__optimize__repeated_8_0_i57);
	init_label(mercury__optimize__repeated_8_0_i52);
	init_label(mercury__optimize__repeated_8_0_i58);
	init_label(mercury__optimize__repeated_8_0_i59);
	init_label(mercury__optimize__repeated_8_0_i62);
	init_label(mercury__optimize__repeated_8_0_i61);
	init_label(mercury__optimize__repeated_8_0_i64);
	init_label(mercury__optimize__repeated_8_0_i65);
	init_label(mercury__optimize__repeated_8_0_i49);
	init_label(mercury__optimize__repeated_8_0_i67);
	init_label(mercury__optimize__repeated_8_0_i68);
	init_label(mercury__optimize__repeated_8_0_i75);
	init_label(mercury__optimize__repeated_8_0_i76);
	init_label(mercury__optimize__repeated_8_0_i77);
	init_label(mercury__optimize__repeated_8_0_i72);
	init_label(mercury__optimize__repeated_8_0_i78);
	init_label(mercury__optimize__repeated_8_0_i79);
	init_label(mercury__optimize__repeated_8_0_i82);
	init_label(mercury__optimize__repeated_8_0_i81);
	init_label(mercury__optimize__repeated_8_0_i84);
	init_label(mercury__optimize__repeated_8_0_i85);
	init_label(mercury__optimize__repeated_8_0_i69);
	init_label(mercury__optimize__repeated_8_0_i87);
	init_label(mercury__optimize__repeated_8_0_i88);
	init_label(mercury__optimize__repeated_8_0_i95);
	init_label(mercury__optimize__repeated_8_0_i96);
	init_label(mercury__optimize__repeated_8_0_i97);
	init_label(mercury__optimize__repeated_8_0_i92);
	init_label(mercury__optimize__repeated_8_0_i98);
	init_label(mercury__optimize__repeated_8_0_i99);
	init_label(mercury__optimize__repeated_8_0_i102);
	init_label(mercury__optimize__repeated_8_0_i101);
	init_label(mercury__optimize__repeated_8_0_i104);
	init_label(mercury__optimize__repeated_8_0_i105);
	init_label(mercury__optimize__repeated_8_0_i89);
	init_label(mercury__optimize__repeated_8_0_i107);
	init_label(mercury__optimize__repeated_8_0_i113);
	init_label(mercury__optimize__repeated_8_0_i109);
	init_label(mercury__optimize__repeated_8_0_i108);
	init_label(mercury__optimize__repeated_8_0_i115);
	init_label(mercury__optimize__repeated_8_0_i116);
	init_label(mercury__optimize__repeated_8_0_i117);
BEGIN_CODE

/* code for predicate 'optimize__repeated'/8 in mode 0 */
Define_static(mercury__optimize__repeated_8_0);
	incr_sp_push_msg(22, "optimize__repeated");
	detstackvar(22) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = ((Integer) 12);
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i2,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i2);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(6) = (Integer) r1;
	r1 = ((Integer) 18);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i3,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i3);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_util__find_first_label_2_0);
	call_localret(ENTRY(mercury__opt_util__find_first_label_2_0),
		mercury__optimize__repeated_8_0_i4,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i4);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	{
	Declare_entry(mercury__opt_util__format_label_2_0);
	call_localret(ENTRY(mercury__opt_util__format_label_2_0),
		mercury__optimize__repeated_8_0_i5,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i5);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(8) = (Integer) r1;
	r1 = ((Integer) 122);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i6,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i6);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i7);
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i7);
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i11);
	r1 = string_const("% Optimizing value number for ", 30);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i14,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i14);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i15,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i15);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i16,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i16);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i17);
Define_label(mercury__optimize__repeated_8_0_i11);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
Define_label(mercury__optimize__repeated_8_0_i17);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	{
	Declare_entry(mercury__value_number__main_4_0);
	call_localret(ENTRY(mercury__value_number__main_4_0),
		mercury__optimize__repeated_8_0_i18,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i18);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(16) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__repeated_8_0_i21,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i21);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i20);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(16);
	r1 = ((Integer) 118);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i26);
Define_label(mercury__optimize__repeated_8_0_i20);
	r1 = (Integer) detstackvar(7);
	r2 = string_const("after value numbering", 21);
	r3 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__repeated_8_0_i23,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i23);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__repeated_8_0_i24,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i24);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r2 = (Integer) r1;
	r1 = ((Integer) 118);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i26);
Define_label(mercury__optimize__repeated_8_0_i7);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) r3;
	r1 = ((Integer) 118);
Define_label(mercury__optimize__repeated_8_0_i26);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i27,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i27);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 119);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i28,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i28);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i29);
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i32);
	detstackvar(2) = (Integer) r1;
	r1 = string_const("% Optimizing jumps for ", 23);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i35,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i35);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i36,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i36);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i37,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i37);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i38);
Define_label(mercury__optimize__repeated_8_0_i32);
	r9 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
Define_label(mercury__optimize__repeated_8_0_i38);
	detstackvar(1) = (Integer) r4;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r1;
	detstackvar(17) = (Integer) r9;
	{
	Declare_entry(mercury__jumpopt__main_5_0);
	call_localret(ENTRY(mercury__jumpopt__main_5_0),
		mercury__optimize__repeated_8_0_i39,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i39);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(11) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__repeated_8_0_i42,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i42);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i41);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(17);
	r1 = ((Integer) 117);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i47);
Define_label(mercury__optimize__repeated_8_0_i41);
	r1 = (Integer) detstackvar(7);
	r2 = string_const("after jump optimization", 23);
	r3 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__repeated_8_0_i44,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i44);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__repeated_8_0_i45,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i45);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	r2 = (Integer) r1;
	r1 = ((Integer) 117);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i47);
Define_label(mercury__optimize__repeated_8_0_i29);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = ((Integer) 1);
	r1 = ((Integer) 117);
Define_label(mercury__optimize__repeated_8_0_i47);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(10) = (Integer) r9;
	detstackvar(11) = (Integer) r10;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i48,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i48);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i49);
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i52);
	r1 = string_const("% Optimizing locally for ", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i55,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i55);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i56,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i56);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i57,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i57);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i58);
Define_label(mercury__optimize__repeated_8_0_i52);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(11);
Define_label(mercury__optimize__repeated_8_0_i58);
	detstackvar(1) = (Integer) r4;
	detstackvar(3) = (Integer) r3;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r8;
	detstackvar(18) = (Integer) r9;
	{
	Declare_entry(mercury__peephole__optimize_5_0);
	call_localret(ENTRY(mercury__peephole__optimize_5_0),
		mercury__optimize__repeated_8_0_i59,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i59);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(13) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__repeated_8_0_i62,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i62);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i61);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(18);
	r1 = ((Integer) 120);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i67);
Define_label(mercury__optimize__repeated_8_0_i61);
	r1 = (Integer) detstackvar(7);
	r2 = string_const("after peepholing", 16);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__repeated_8_0_i64,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i64);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__repeated_8_0_i65,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i65);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r2 = (Integer) r1;
	r1 = ((Integer) 120);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i67);
Define_label(mercury__optimize__repeated_8_0_i49);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(10);
	r10 = ((Integer) 1);
	r1 = ((Integer) 120);
Define_label(mercury__optimize__repeated_8_0_i67);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(11) = (Integer) r8;
	detstackvar(12) = (Integer) r9;
	detstackvar(13) = (Integer) r10;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i68,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i68);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i69);
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i72);
	r1 = string_const("% Optimizing labels for ", 24);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i75,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i75);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i76,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i76);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i77,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i77);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i78);
Define_label(mercury__optimize__repeated_8_0_i72);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
Define_label(mercury__optimize__repeated_8_0_i78);
	detstackvar(1) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(11) = (Integer) r7;
	detstackvar(12) = (Integer) r1;
	detstackvar(13) = (Integer) r8;
	detstackvar(19) = (Integer) r9;
	{
	Declare_entry(mercury__labelopt__main_4_0);
	call_localret(ENTRY(mercury__labelopt__main_4_0),
		mercury__optimize__repeated_8_0_i79,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i79);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	detstackvar(15) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__repeated_8_0_i82,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i82);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i81);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(14);
	r10 = (Integer) detstackvar(15);
	r2 = (Integer) detstackvar(19);
	r1 = ((Integer) 121);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i87);
Define_label(mercury__optimize__repeated_8_0_i81);
	r1 = (Integer) detstackvar(7);
	r2 = string_const("after label optimization", 24);
	r3 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__repeated_8_0_i84,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i84);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__repeated_8_0_i85,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i85);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(14);
	r10 = (Integer) detstackvar(15);
	r2 = (Integer) r1;
	r1 = ((Integer) 121);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i87);
Define_label(mercury__optimize__repeated_8_0_i69);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(12);
	r10 = ((Integer) 1);
	r1 = ((Integer) 121);
Define_label(mercury__optimize__repeated_8_0_i87);
	detstackvar(1) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(11) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	detstackvar(14) = (Integer) r9;
	detstackvar(15) = (Integer) r10;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i88,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i88);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i89);
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i92);
	r1 = string_const("% Optimizing duplicates for ", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i95,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i95);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i96,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i96);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__repeated_8_0_i97,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i97);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(15);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i98);
Define_label(mercury__optimize__repeated_8_0_i92);
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(15);
Define_label(mercury__optimize__repeated_8_0_i98);
	detstackvar(1) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	detstackvar(11) = (Integer) r4;
	detstackvar(13) = (Integer) r5;
	detstackvar(14) = (Integer) r1;
	detstackvar(15) = (Integer) r6;
	detstackvar(20) = (Integer) r7;
	{
	Declare_entry(mercury__dupelim__main_2_0);
	call_localret(ENTRY(mercury__dupelim__main_2_0),
		mercury__optimize__repeated_8_0_i99,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i99);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__repeated_8_0_i102,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i102);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i101);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(15);
	r6 = (Integer) detstackvar(20);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i107);
Define_label(mercury__optimize__repeated_8_0_i101);
	r1 = (Integer) detstackvar(7);
	r2 = string_const("after duplicate elimination", 27);
	r3 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__repeated_8_0_i104,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i104);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__repeated_8_0_i105,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i105);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(15);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i107);
Define_label(mercury__optimize__repeated_8_0_i89);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(14);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(15);
Define_label(mercury__optimize__repeated_8_0_i107);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i108);
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i108);
	if (((Integer) r5 != ((Integer) 1)))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i108);
	detstackvar(2) = (Integer) r2;
	detstackvar(21) = (Integer) r6;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__repeated_8_0_i113,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i113);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__repeated_8_0_i109);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	r2 = (Integer) detstackvar(21);
	r1 = ((Integer) 14);
	GOTO_LABEL(mercury__optimize__repeated_8_0_i115);
Define_label(mercury__optimize__repeated_8_0_i109);
	r2 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(21);
Define_label(mercury__optimize__repeated_8_0_i108);
	r3 = (Integer) r2;
	r4 = ((Integer) 0);
	r2 = (Integer) r6;
	r1 = ((Integer) 14);
Define_label(mercury__optimize__repeated_8_0_i115);
	detstackvar(2) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__repeated_8_0_i116,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i116);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	{
	Declare_entry(mercury__passes_aux__maybe_report_stats_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_report_stats_3_0),
		mercury__optimize__repeated_8_0_i117,
		STATIC(mercury__optimize__repeated_8_0));
	}
Define_label(mercury__optimize__repeated_8_0_i117);
	update_prof_current_proc(LABEL(mercury__optimize__repeated_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(22);
	decr_sp_pop_msg(22);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__optimize_module4)
	init_entry(mercury__optimize__nonrepeat_4_0);
	init_label(mercury__optimize__nonrepeat_4_0_i2);
	init_label(mercury__optimize__nonrepeat_4_0_i3);
	init_label(mercury__optimize__nonrepeat_4_0_i4);
	init_label(mercury__optimize__nonrepeat_4_0_i5);
	init_label(mercury__optimize__nonrepeat_4_0_i6);
	init_label(mercury__optimize__nonrepeat_4_0_i13);
	init_label(mercury__optimize__nonrepeat_4_0_i14);
	init_label(mercury__optimize__nonrepeat_4_0_i15);
	init_label(mercury__optimize__nonrepeat_4_0_i10);
	init_label(mercury__optimize__nonrepeat_4_0_i16);
	init_label(mercury__optimize__nonrepeat_4_0_i17);
	init_label(mercury__optimize__nonrepeat_4_0_i18);
	init_label(mercury__optimize__nonrepeat_4_0_i21);
	init_label(mercury__optimize__nonrepeat_4_0_i20);
	init_label(mercury__optimize__nonrepeat_4_0_i23);
	init_label(mercury__optimize__nonrepeat_4_0_i24);
	init_label(mercury__optimize__nonrepeat_4_0_i7);
	init_label(mercury__optimize__nonrepeat_4_0_i26);
	init_label(mercury__optimize__nonrepeat_4_0_i27);
	init_label(mercury__optimize__nonrepeat_4_0_i28);
	init_label(mercury__optimize__nonrepeat_4_0_i33);
	init_label(mercury__optimize__nonrepeat_4_0_i36);
	init_label(mercury__optimize__nonrepeat_4_0_i35);
	init_label(mercury__optimize__nonrepeat_4_0_i38);
	init_label(mercury__optimize__nonrepeat_4_0_i39);
	init_label(mercury__optimize__nonrepeat_4_0_i29);
	init_label(mercury__optimize__nonrepeat_4_0_i41);
	init_label(mercury__optimize__nonrepeat_4_0_i42);
	init_label(mercury__optimize__nonrepeat_4_0_i49);
	init_label(mercury__optimize__nonrepeat_4_0_i50);
	init_label(mercury__optimize__nonrepeat_4_0_i51);
	init_label(mercury__optimize__nonrepeat_4_0_i46);
	init_label(mercury__optimize__nonrepeat_4_0_i52);
	init_label(mercury__optimize__nonrepeat_4_0_i53);
	init_label(mercury__optimize__nonrepeat_4_0_i56);
	init_label(mercury__optimize__nonrepeat_4_0_i55);
	init_label(mercury__optimize__nonrepeat_4_0_i58);
	init_label(mercury__optimize__nonrepeat_4_0_i59);
	init_label(mercury__optimize__nonrepeat_4_0_i43);
	init_label(mercury__optimize__nonrepeat_4_0_i61);
	init_label(mercury__optimize__nonrepeat_4_0_i64);
	init_label(mercury__optimize__nonrepeat_4_0_i69);
	init_label(mercury__optimize__nonrepeat_4_0_i75);
	init_label(mercury__optimize__nonrepeat_4_0_i76);
	init_label(mercury__optimize__nonrepeat_4_0_i79);
	init_label(mercury__optimize__nonrepeat_4_0_i78);
	init_label(mercury__optimize__nonrepeat_4_0_i81);
	init_label(mercury__optimize__nonrepeat_4_0_i82);
	init_label(mercury__optimize__nonrepeat_4_0_i70);
	init_label(mercury__optimize__nonrepeat_4_0_i84);
	init_label(mercury__optimize__nonrepeat_4_0_i87);
	init_label(mercury__optimize__nonrepeat_4_0_i86);
	init_label(mercury__optimize__nonrepeat_4_0_i89);
	init_label(mercury__optimize__nonrepeat_4_0_i92);
	init_label(mercury__optimize__nonrepeat_4_0_i91);
	init_label(mercury__optimize__nonrepeat_4_0_i94);
	init_label(mercury__optimize__nonrepeat_4_0_i95);
	init_label(mercury__optimize__nonrepeat_4_0_i62);
BEGIN_CODE

/* code for predicate 'optimize__nonrepeat'/4 in mode 0 */
Define_static(mercury__optimize__nonrepeat_4_0);
	incr_sp_push_msg(20, "optimize__nonrepeat");
	detstackvar(20) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 12);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__nonrepeat_4_0_i2,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i2);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 18);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__nonrepeat_4_0_i3,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i3);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_util__find_first_label_2_0);
	call_localret(ENTRY(mercury__opt_util__find_first_label_2_0),
		mercury__optimize__nonrepeat_4_0_i4,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i4);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	{
	Declare_entry(mercury__opt_util__format_label_2_0);
	call_localret(ENTRY(mercury__opt_util__format_label_2_0),
		mercury__optimize__nonrepeat_4_0_i5,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i5);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 123);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__nonrepeat_4_0_i6,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i6);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i7);
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i10);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("% Optimizing frames for ", 24);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__nonrepeat_4_0_i13,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i13);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__nonrepeat_4_0_i14,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i14);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__nonrepeat_4_0_i15,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i15);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r2 = (Integer) r1;
	r1 = ((Integer) 124);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i16);
Define_label(mercury__optimize__nonrepeat_4_0_i10);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) r1;
	r1 = ((Integer) 124);
Define_label(mercury__optimize__nonrepeat_4_0_i16);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__nonrepeat_4_0_i17,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i17);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	detstackvar(14) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__frameopt__main_5_0);
	call_localret(ENTRY(mercury__frameopt__main_5_0),
		mercury__optimize__nonrepeat_4_0_i18,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i18);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__nonrepeat_4_0_i21,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i21);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i20);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(14);
	r1 = ((Integer) 117);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i27);
Define_label(mercury__optimize__nonrepeat_4_0_i20);
	r1 = (Integer) detstackvar(3);
	r2 = string_const("after frame optimization", 24);
	r3 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__nonrepeat_4_0_i23,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i23);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__nonrepeat_4_0_i24,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i24);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r2 = (Integer) r1;
	r1 = ((Integer) 117);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i27);
Define_label(mercury__optimize__nonrepeat_4_0_i7);
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__optimize__nonrepeat_4_0_i26,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i26);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	r1 = ((Integer) 117);
Define_label(mercury__optimize__nonrepeat_4_0_i27);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__nonrepeat_4_0_i28,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i28);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i29);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i29);
	detstackvar(8) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(7);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__peephole__optimize_5_0);
	call_localret(ENTRY(mercury__peephole__optimize_5_0),
		mercury__optimize__nonrepeat_4_0_i33,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i33);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__nonrepeat_4_0_i36,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i36);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i35);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(15);
	r1 = ((Integer) 122);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i41);
Define_label(mercury__optimize__nonrepeat_4_0_i35);
	r1 = (Integer) detstackvar(3);
	r2 = string_const("after peepholing", 16);
	r3 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__nonrepeat_4_0_i38,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i38);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__nonrepeat_4_0_i39,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i39);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r2 = (Integer) r1;
	r1 = ((Integer) 122);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i41);
Define_label(mercury__optimize__nonrepeat_4_0_i29);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) r1;
	r9 = (Integer) detstackvar(6);
	r1 = ((Integer) 122);
Define_label(mercury__optimize__nonrepeat_4_0_i41);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__optimize__nonrepeat_4_0_i42,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i42);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i43);
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i46);
	detstackvar(10) = (Integer) r1;
	r1 = string_const("% Optimizing post value number for ", 35);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__nonrepeat_4_0_i49,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i49);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__nonrepeat_4_0_i50,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i50);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__optimize__nonrepeat_4_0_i51,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i51);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	r6 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i52);
Define_label(mercury__optimize__nonrepeat_4_0_i46);
	r6 = (Integer) r1;
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
Define_label(mercury__optimize__nonrepeat_4_0_i52);
	detstackvar(3) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	detstackvar(8) = (Integer) r5;
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r6;
	detstackvar(16) = (Integer) r7;
	{
	Declare_entry(mercury__value_number__post_main_2_0);
	call_localret(ENTRY(mercury__value_number__post_main_2_0),
		mercury__optimize__nonrepeat_4_0_i53,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i53);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__nonrepeat_4_0_i56,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i56);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i55);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(16);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i61);
Define_label(mercury__optimize__nonrepeat_4_0_i55);
	r1 = (Integer) detstackvar(3);
	r2 = string_const("after post value number", 23);
	r3 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__nonrepeat_4_0_i58,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i58);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__nonrepeat_4_0_i59,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i59);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(10);
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i61);
Define_label(mercury__optimize__nonrepeat_4_0_i43);
	r5 = (Integer) r2;
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
Define_label(mercury__optimize__nonrepeat_4_0_i61);
	if (((Integer) r3 == ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i64);
	if (((Integer) r7 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i62);
Define_label(mercury__optimize__nonrepeat_4_0_i64);
	detstackvar(3) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	detstackvar(8) = (Integer) r6;
	r2 = ((Integer) 1);
	r3 = ((Integer) 0);
	call_localret(STATIC(mercury__optimize__repeated_8_0),
		mercury__optimize__nonrepeat_4_0_i69,
		STATIC(mercury__optimize__nonrepeat_4_0));
Define_label(mercury__optimize__nonrepeat_4_0_i69);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i70);
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i70);
	if (((Integer) detstackvar(8) != ((Integer) 0)))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i70);
	detstackvar(12) = (Integer) r1;
	detstackvar(18) = (Integer) r3;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__optimize__nonrepeat_4_0_i75,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i75);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__peephole__optimize_5_0);
	call_localret(ENTRY(mercury__peephole__optimize_5_0),
		mercury__optimize__nonrepeat_4_0_i76,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i76);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__nonrepeat_4_0_i79,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i79);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i78);
	r2 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(18);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i84);
Define_label(mercury__optimize__nonrepeat_4_0_i78);
	r1 = (Integer) detstackvar(3);
	r2 = string_const("after peepholing", 16);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__nonrepeat_4_0_i81,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i81);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__nonrepeat_4_0_i82,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i82);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i84);
Define_label(mercury__optimize__nonrepeat_4_0_i70);
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) r3;
	r3 = (Integer) r1;
Define_label(mercury__optimize__nonrepeat_4_0_i84);
	detstackvar(3) = (Integer) r2;
	detstackvar(13) = (Integer) r3;
	detstackvar(19) = (Integer) r4;
	{
	Declare_entry(mercury__frameopt__is_succip_restored_1_0);
	call_localret(ENTRY(mercury__frameopt__is_succip_restored_1_0),
		mercury__optimize__nonrepeat_4_0_i87,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i87);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i86);
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
Define_label(mercury__optimize__nonrepeat_4_0_i86);
	r1 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__frameopt__dont_save_succip_2_0);
	call_localret(ENTRY(mercury__frameopt__dont_save_succip_2_0),
		mercury__optimize__nonrepeat_4_0_i89,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i89);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_optimize__common_0);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__optimize__nonrepeat_4_0_i92,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i92);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__optimize__nonrepeat_4_0_i91);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
Define_label(mercury__optimize__nonrepeat_4_0_i91);
	r1 = (Integer) detstackvar(3);
	r2 = string_const("after unsave succip", 19);
	r3 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	call_localret(ENTRY(mercury__opt_debug__msg_4_0),
		mercury__optimize__nonrepeat_4_0_i94,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i94);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	call_localret(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		mercury__optimize__nonrepeat_4_0_i95,
		STATIC(mercury__optimize__nonrepeat_4_0));
	}
Define_label(mercury__optimize__nonrepeat_4_0_i95);
	update_prof_current_proc(LABEL(mercury__optimize__nonrepeat_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
Define_label(mercury__optimize__nonrepeat_4_0_i62);
	r2 = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__optimize_bunch_0(void)
{
	mercury__optimize_module0();
	mercury__optimize_module1();
	mercury__optimize_module2();
	mercury__optimize_module3();
	mercury__optimize_module4();
}

#endif

void mercury__optimize__init(void); /* suppress gcc warning */
void mercury__optimize__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__optimize_bunch_0();
#endif
}
