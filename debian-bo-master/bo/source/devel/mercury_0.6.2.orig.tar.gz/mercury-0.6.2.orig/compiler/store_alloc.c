/*
** Automatically generated from `store_alloc.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__store_alloc__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0);
Declare_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i4);
Declare_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i5);
Declare_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i1003);
Declare_static(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0);
Declare_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i4);
Declare_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i6);
Declare_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i5);
Declare_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i7);
Declare_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i8);
Declare_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i1003);
Declare_static(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i6);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i7);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i9);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i5);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i10);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i11);
Declare_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i1004);
Declare_static(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1018);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1017);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1016);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1015);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1014);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i5);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i6);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i8);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i9);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i10);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i11);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i12);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i13);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i14);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i15);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i17);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i18);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i19);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i20);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i21);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1013);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i24);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1010);
Declare_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i2);
Declare_static(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i2);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i3);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i4);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i5);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i6);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i7);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i8);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i9);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i10);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i14);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i15);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i16);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i11);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i20);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i21);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i22);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i17);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i26);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i27);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i28);
Declare_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i23);
Define_extern_entry(mercury__store_alloc__store_alloc_in_proc_3_0);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i2);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i3);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i7);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i8);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i9);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i10);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i11);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i4);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i12);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i13);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i14);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i15);
Declare_label(mercury__store_alloc__store_alloc_in_proc_3_0_i16);
Declare_static(mercury__store_alloc__store_alloc_allocate_storage_3_0);
Declare_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i2);
Declare_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i3);
Declare_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i4);
Declare_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i5);
Declare_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i6);
Declare_static(mercury__store_alloc__store_alloc_remove_nonlive_4_0);
Declare_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i6);
Declare_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i5);
Declare_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i8);
Declare_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i1003);
Declare_static(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i4);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i8);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i12);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i7);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i14);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i15);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i6);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i16);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i17);
Declare_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i1007);
Declare_static(mercury__store_alloc__store_alloc_allocate_extras_5_0);
Declare_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i6);
Declare_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i5);
Declare_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i8);
Declare_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i9);
Declare_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i10);
Declare_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i1004);
Declare_static(mercury__store_alloc__next_free_reg_3_0);
Declare_label(mercury__store_alloc__next_free_reg_3_0_i4);
Declare_label(mercury__store_alloc__next_free_reg_3_0_i3);

BEGIN_MODULE(mercury__store_alloc_module0)
	init_entry(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0);
	init_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i4);
	init_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i5);
	init_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i1003);
BEGIN_CODE

/* code for predicate 'store_alloc_in_cases__ua10000'/6 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i1003);
	incr_sp_push_msg(5, "store_alloc_in_cases__ua10000");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i4,
		STATIC(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i4);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	tag_incr_hp(tempr2, mktag(0), ((Integer) 2));
	detstackvar(2) = (Integer) tempr2;
	field(mktag(0), (Integer) tempr2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr2, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0,
		LABEL(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i5),
		STATIC(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i5);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	r2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module1)
	init_entry(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0);
	init_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i4);
	init_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i6);
	init_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i5);
	init_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i7);
	init_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i8);
	init_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i1003);
BEGIN_CODE

/* code for predicate 'store_alloc_in_disj__ua10000'/6 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i1003);
	incr_sp_push_msg(5, "store_alloc_in_disj__ua10000");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) tempr1;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i4,
		STATIC(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i4);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i6);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i5);
Define_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i6);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r3 = (Integer) r4;
Define_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i5);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i7,
		STATIC(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i7);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	localcall(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0,
		LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i8),
		STATIC(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i8);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module2)
	init_entry(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i6);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i7);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i9);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i5);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i10);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i11);
	init_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i1004);
BEGIN_CODE

/* code for predicate 'store_alloc_in_conj__ua10000'/6 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i1004);
	incr_sp_push_msg(5, "store_alloc_in_conj__ua10000");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) tempr1;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i6,
		STATIC(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i6);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	{
	Declare_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_unreachable_1_0),
		mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i7,
		STATIC(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i7);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i9,
		STATIC(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i10,
		STATIC(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i10);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0,
		LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i11),
		STATIC(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i11);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module3)
	init_entry(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1018);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1017);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1016);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1015);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1014);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i5);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i6);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i8);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i9);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i10);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i11);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i12);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i13);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i14);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i15);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i17);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i18);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i19);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i20);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i21);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1013);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i24);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1010);
	init_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i2);
BEGIN_CODE

/* code for predicate 'store_alloc_in_goal_2__ua10000'/6 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1013);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1018) AND
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1010) AND
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1017) AND
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1016) AND
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1015) AND
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1014) AND
		LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1010));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1018);
	incr_sp_push_msg(8, "store_alloc_in_goal_2__ua10000");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i5);
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1017);
	incr_sp_push_msg(8, "store_alloc_in_goal_2__ua10000");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i8);
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1016);
	incr_sp_push_msg(8, "store_alloc_in_goal_2__ua10000");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i10);
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1015);
	incr_sp_push_msg(8, "store_alloc_in_goal_2__ua10000");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i14);
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1014);
	incr_sp_push_msg(8, "store_alloc_in_goal_2__ua10000");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) tempr1;
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i17,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_cases__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i6,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i6);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_disj__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i9,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i10);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i11,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i11);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	{
	Declare_entry(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i12,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i12);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i13,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i13);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i14);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i15,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i15);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i17);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	{
	Declare_entry(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i18,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i18);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i19,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i19);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i20,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i20);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i21,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i21);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	r2 = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1013);
	incr_sp_push_msg(8, "store_alloc_in_goal_2__ua10000");
	detstackvar(8) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i2);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_conj__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i24,
		STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i24);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i1010);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module4)
	init_entry(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i2);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i3);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i4);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i5);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i6);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i7);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i8);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i9);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i10);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i14);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i15);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i16);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i11);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i20);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i21);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i22);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i17);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i26);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i27);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i28);
	init_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i23);
BEGIN_CODE

/* code for predicate 'store_alloc_in_goal__ua10000'/6 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0);
	incr_sp_push_msg(8, "store_alloc_in_goal__ua10000");
	detstackvar(8) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_births_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i2,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i2);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_deaths_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i3,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i3);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_births_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i4,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i4);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_deaths_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i5,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i5);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i6,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i6);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i7,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i7);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal_2__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i8,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i8);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i9,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i10,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i10);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i11);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i11);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 4));
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i14,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i14);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i15,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i15);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i16,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i16);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r3, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i11);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i17);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i17);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 5));
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i20,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i20);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i21,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i21);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i22,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i22);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r3, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i17);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i23);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i23);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i26,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i26);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i27,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i27);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0),
		mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i28,
		STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i28);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0_i23);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module5)
	init_entry(mercury__store_alloc__store_alloc_in_proc_3_0);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i2);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i3);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i7);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i8);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i9);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i10);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i11);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i4);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i12);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i13);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i14);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i15);
	init_label(mercury__store_alloc__store_alloc_in_proc_3_0_i16);
BEGIN_CODE

/* code for predicate 'store_alloc_in_proc'/3 in mode 0 */
Define_entry(mercury__store_alloc__store_alloc_in_proc_3_0);
	incr_sp_push_msg(5, "store_alloc_in_proc");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_globals_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i2,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i2);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	detstackvar(3) = (Integer) r1;
	r2 = ((Integer) 115);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i3,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i3);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__store_alloc__store_alloc_in_proc_3_0_i4);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__globals__get_args_method_2_0);
	call_localret(ENTRY(mercury__globals__get_args_method_2_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i7,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i7);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i8,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i8);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__follow_vars__find_final_follow_vars_2_0);
	call_localret(ENTRY(mercury__follow_vars__find_final_follow_vars_2_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i9,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i9);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__follow_vars__find_follow_vars_in_goal_6_0);
	call_localret(ENTRY(mercury__follow_vars__find_follow_vars_in_goal_6_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i10,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i10);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_follow_vars_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_follow_vars_3_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i11,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i11);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	GOTO_LABEL(mercury__store_alloc__store_alloc_in_proc_3_0_i13);
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i12,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i12);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i13);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__liveness__initial_liveness_3_0);
	call_localret(ENTRY(mercury__liveness__initial_liveness_3_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i14,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i14);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i15,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i15);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__store_alloc__store_alloc_in_goal__ua10000_6_0),
		mercury__store_alloc__store_alloc_in_proc_3_0_i16,
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
Define_label(mercury__store_alloc__store_alloc_in_proc_3_0_i16);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_in_proc_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		ENTRY(mercury__store_alloc__store_alloc_in_proc_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module6)
	init_entry(mercury__store_alloc__store_alloc_allocate_storage_3_0);
	init_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i2);
	init_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i3);
	init_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i4);
	init_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i5);
	init_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i6);
BEGIN_CODE

/* code for predicate 'store_alloc_allocate_storage'/3 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_allocate_storage_3_0);
	r3 = (Integer) r2;
	incr_sp_push_msg(4, "store_alloc_allocate_storage");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__store_alloc__store_alloc_allocate_storage_3_0_i2,
		STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i2);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__store_alloc_remove_nonlive_4_0),
		mercury__store_alloc__store_alloc_allocate_storage_3_0_i3,
		STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0));
Define_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i3);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__store_alloc__store_alloc_allocate_storage_3_0_i4,
		STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i4);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__store_alloc__store_alloc_allocate_storage_3_0_i5,
		STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	}
Define_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i5);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0),
		mercury__store_alloc__store_alloc_allocate_storage_3_0_i6,
		STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0));
Define_label(mercury__store_alloc__store_alloc_allocate_storage_3_0_i6);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_storage_3_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0),
		STATIC(mercury__store_alloc__store_alloc_allocate_storage_3_0));
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module7)
	init_entry(mercury__store_alloc__store_alloc_remove_nonlive_4_0);
	init_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i6);
	init_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i5);
	init_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i8);
	init_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i1003);
BEGIN_CODE

/* code for predicate 'store_alloc_remove_nonlive'/4 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_remove_nonlive_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i1003);
	incr_sp_push_msg(5, "store_alloc_remove_nonlive");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__store_alloc__store_alloc_remove_nonlive_4_0_i6,
		STATIC(mercury__store_alloc__store_alloc_remove_nonlive_4_0));
	}
Define_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i6);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_remove_nonlive_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i5);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__store_alloc__store_alloc_remove_nonlive_4_0,
		STATIC(mercury__store_alloc__store_alloc_remove_nonlive_4_0));
Define_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i5);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__delete_3_1);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__store_alloc__store_alloc_remove_nonlive_4_0_i8,
		STATIC(mercury__store_alloc__store_alloc_remove_nonlive_4_0));
	}
Define_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i8);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_remove_nonlive_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__store_alloc__store_alloc_remove_nonlive_4_0,
		STATIC(mercury__store_alloc__store_alloc_remove_nonlive_4_0));
Define_label(mercury__store_alloc__store_alloc_remove_nonlive_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module8)
	init_entry(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i4);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i8);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i12);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i7);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i14);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i15);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i6);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i16);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i17);
	init_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i1007);
BEGIN_CODE

/* code for predicate 'store_alloc_handle_conflicts_and_nonreal'/7 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i1007);
	incr_sp_push_msg(8, "store_alloc_handle_conflicts_and_nonreal");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) r4;
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i4,
		STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	}
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i4);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i8);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i8);
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) >= ((Integer) 1)))
		GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i7);
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i8);
	r2 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i12,
		STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	}
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i12);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i7);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	call_localret(STATIC(mercury__store_alloc__next_free_reg_3_0),
		mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i14,
		STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i14);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	tag_incr_hp(detstackvar(7), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) r3;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r4 = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i15,
		STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	}
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i15);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(7);
	r6 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	GOTO_LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i16);
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i6);
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(3);
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i16);
	detstackvar(5) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i17,
		STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	}
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i17);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0,
		STATIC(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0));
Define_label(mercury__store_alloc__store_alloc_handle_conflicts_and_nonreal_7_0_i1007);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module9)
	init_entry(mercury__store_alloc__store_alloc_allocate_extras_5_0);
	init_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i6);
	init_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i5);
	init_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i8);
	init_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i9);
	init_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i10);
	init_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i1004);
BEGIN_CODE

/* code for predicate 'store_alloc_allocate_extras'/5 in mode 0 */
Define_static(mercury__store_alloc__store_alloc_allocate_extras_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__store_alloc__store_alloc_allocate_extras_5_0_i1004);
	incr_sp_push_msg(6, "store_alloc_allocate_extras");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__store_alloc__store_alloc_allocate_extras_5_0_i6,
		STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	}
Define_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i6);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__store_alloc__store_alloc_allocate_extras_5_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__store_alloc__store_alloc_allocate_extras_5_0,
		STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0));
Define_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__store_alloc__next_free_reg_3_0),
		mercury__store_alloc__store_alloc_allocate_extras_5_0_i8,
		STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0));
Define_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i8);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(detstackvar(3), mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r3 = (Integer) r2;
	field(mktag(1), (Integer) detstackvar(3), ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r5 = (Integer) detstackvar(3);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__store_alloc__store_alloc_allocate_extras_5_0_i9,
		STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	}
	}
Define_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i9);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__store_alloc__store_alloc_allocate_extras_5_0_i10,
		STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	}
Define_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i10);
	update_prof_current_proc(LABEL(mercury__store_alloc__store_alloc_allocate_extras_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__store_alloc__store_alloc_allocate_extras_5_0,
		STATIC(mercury__store_alloc__store_alloc_allocate_extras_5_0));
Define_label(mercury__store_alloc__store_alloc_allocate_extras_5_0_i1004);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__store_alloc_module10)
	init_entry(mercury__store_alloc__next_free_reg_3_0);
	init_label(mercury__store_alloc__next_free_reg_3_0_i4);
	init_label(mercury__store_alloc__next_free_reg_3_0_i3);
BEGIN_CODE

/* code for predicate 'next_free_reg'/3 in mode 0 */
Define_static(mercury__store_alloc__next_free_reg_3_0);
	incr_sp_push_msg(3, "next_free_reg");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__store_alloc__next_free_reg_3_0_i4,
		STATIC(mercury__store_alloc__next_free_reg_3_0));
	}
	}
Define_label(mercury__store_alloc__next_free_reg_3_0_i4);
	update_prof_current_proc(LABEL(mercury__store_alloc__next_free_reg_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__store_alloc__next_free_reg_3_0_i3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__store_alloc__next_free_reg_3_0,
		STATIC(mercury__store_alloc__next_free_reg_3_0));
Define_label(mercury__store_alloc__next_free_reg_3_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__store_alloc_bunch_0(void)
{
	mercury__store_alloc_module0();
	mercury__store_alloc_module1();
	mercury__store_alloc_module2();
	mercury__store_alloc_module3();
	mercury__store_alloc_module4();
	mercury__store_alloc_module5();
	mercury__store_alloc_module6();
	mercury__store_alloc_module7();
	mercury__store_alloc_module8();
	mercury__store_alloc_module9();
	mercury__store_alloc_module10();
}

#endif

void mercury__store_alloc__init(void); /* suppress gcc warning */
void mercury__store_alloc__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__store_alloc_bunch_0();
#endif
}
