/*
** Automatically generated from `type_util.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__type_util__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__type_util__type_id_arity__ua10000_3_0);
Declare_static(mercury__type_util__type_id_name__ua10000_3_0);
Declare_static(mercury__type_util__type_id_module__ua10000_3_0);
Declare_label(mercury__type_util__type_id_module__ua10000_3_0_i3);
Define_extern_entry(mercury__type_util__type_is_atomic_2_0);
Declare_label(mercury__type_util__type_is_atomic_2_0_i2);
Declare_label(mercury__type_util__type_is_atomic_2_0_i1);
Declare_label(mercury__type_util__type_is_atomic_2_0_i1000);
Define_extern_entry(mercury__type_util__type_is_higher_order_3_0);
Declare_label(mercury__type_util__type_is_higher_order_3_0_i12);
Declare_label(mercury__type_util__type_is_higher_order_3_0_i1017);
Declare_label(mercury__type_util__type_is_higher_order_3_0_i1011);
Declare_label(mercury__type_util__type_is_higher_order_3_0_i1016);
Define_extern_entry(mercury__type_util__classify_type_3_0);
Declare_label(mercury__type_util__classify_type_3_0_i1000);
Declare_label(mercury__type_util__classify_type_3_0_i5);
Declare_label(mercury__type_util__classify_type_3_0_i11);
Declare_label(mercury__type_util__classify_type_3_0_i17);
Declare_label(mercury__type_util__classify_type_3_0_i23);
Declare_label(mercury__type_util__classify_type_3_0_i31);
Declare_label(mercury__type_util__classify_type_3_0_i30);
Declare_label(mercury__type_util__classify_type_3_0_i35);
Declare_label(mercury__type_util__classify_type_3_0_i37);
Declare_label(mercury__type_util__classify_type_3_0_i38);
Declare_label(mercury__type_util__classify_type_3_0_i40);
Declare_label(mercury__type_util__classify_type_3_0_i34);
Define_extern_entry(mercury__type_util__type_to_type_id_3_0);
Declare_label(mercury__type_util__type_to_type_id_3_0_i1029);
Declare_label(mercury__type_util__type_to_type_id_3_0_i15);
Declare_label(mercury__type_util__type_to_type_id_3_0_i1027);
Declare_label(mercury__type_util__type_to_type_id_3_0_i1014);
Define_extern_entry(mercury__type_util__var_2_0);
Declare_label(mercury__type_util__var_2_0_i1);
Define_extern_entry(mercury__type_util__construct_type_3_0);
Define_extern_entry(mercury__type_util__construct_type_4_0);
Define_extern_entry(mercury__type_util__make_type_id_3_0);
Declare_label(mercury__type_util__make_type_id_3_0_i1);
Define_extern_entry(mercury__type_util__type_id_module_3_0);
Define_extern_entry(mercury__type_util__type_id_name_3_0);
Define_extern_entry(mercury__type_util__type_id_arity_3_0);
Define_extern_entry(mercury__type_util__type_constructors_3_0);
Declare_label(mercury__type_util__type_constructors_3_0_i2);
Declare_label(mercury__type_util__type_constructors_3_0_i4);
Declare_label(mercury__type_util__type_constructors_3_0_i5);
Declare_label(mercury__type_util__type_constructors_3_0_i7);
Declare_label(mercury__type_util__type_constructors_3_0_i8);
Declare_label(mercury__type_util__type_constructors_3_0_i13);
Declare_label(mercury__type_util__type_constructors_3_0_i14);
Declare_label(mercury__type_util__type_constructors_3_0_i15);
Declare_label(mercury__type_util__type_constructors_3_0_i1);
Define_extern_entry(mercury__type_util__type_is_no_tag_type_3_0);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i6);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i11);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i16);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i20);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i1);
Define_extern_entry(mercury__type_util__type_unify_5_0);
Declare_label(mercury__type_util__type_unify_5_0_i6);
Declare_label(mercury__type_util__type_unify_5_0_i7);
Declare_label(mercury__type_util__type_unify_5_0_i8);
Declare_label(mercury__type_util__type_unify_5_0_i10);
Declare_label(mercury__type_util__type_unify_5_0_i5);
Declare_label(mercury__type_util__type_unify_5_0_i14);
Declare_label(mercury__type_util__type_unify_5_0_i13);
Declare_label(mercury__type_util__type_unify_5_0_i20);
Declare_label(mercury__type_util__type_unify_5_0_i24);
Declare_label(mercury__type_util__type_unify_5_0_i26);
Declare_label(mercury__type_util__type_unify_5_0_i1003);
Declare_label(mercury__type_util__type_unify_5_0_i32);
Declare_label(mercury__type_util__type_unify_5_0_i31);
Declare_label(mercury__type_util__type_unify_5_0_i38);
Declare_label(mercury__type_util__type_unify_5_0_i42);
Declare_label(mercury__type_util__type_unify_5_0_i29);
Declare_label(mercury__type_util__type_unify_5_0_i48);
Declare_label(mercury__type_util__type_unify_5_0_i47);
Declare_label(mercury__type_util__type_unify_5_0_i54);
Declare_label(mercury__type_util__type_unify_5_0_i53);
Declare_label(mercury__type_util__type_unify_5_0_i60);
Declare_label(mercury__type_util__type_unify_5_0_i64);
Declare_label(mercury__type_util__type_unify_5_0_i63);
Declare_label(mercury__type_util__type_unify_5_0_i68);
Declare_label(mercury__type_util__type_unify_5_0_i72);
Declare_label(mercury__type_util__type_unify_5_0_i70);
Declare_label(mercury__type_util__type_unify_5_0_i69);
Declare_label(mercury__type_util__type_unify_5_0_i76);
Declare_label(mercury__type_util__type_unify_5_0_i59);
Declare_label(mercury__type_util__type_unify_5_0_i83);
Declare_label(mercury__type_util__type_unify_5_0_i85);
Declare_label(mercury__type_util__type_unify_5_0_i89);
Declare_label(mercury__type_util__type_unify_5_0_i87);
Declare_label(mercury__type_util__type_unify_5_0_i86);
Declare_label(mercury__type_util__type_unify_5_0_i93);
Declare_label(mercury__type_util__type_unify_5_0_i82);
Declare_label(mercury__type_util__type_unify_5_0_i99);
Declare_label(mercury__type_util__type_unify_5_0_i98);
Declare_label(mercury__type_util__type_unify_5_0_i101);
Declare_label(mercury__type_util__type_unify_5_0_i1);
Declare_label(mercury__type_util__type_unify_5_0_i1001);
Define_extern_entry(mercury__type_util__type_unify_list_5_0);
Declare_label(mercury__type_util__type_unify_list_5_0_i1010);
Declare_label(mercury__type_util__type_unify_list_5_0_i6);
Declare_label(mercury__type_util__type_unify_list_5_0_i8);
Declare_label(mercury__type_util__type_unify_list_5_0_i1007);
Declare_label(mercury__type_util__type_unify_list_5_0_i1);
Declare_label(mercury__type_util__type_unify_list_5_0_i1009);
Define_extern_entry(mercury__type_util__vars_2_0);
Define_extern_entry(mercury__type_util__type_list_subsumes_3_0);
Declare_label(mercury__type_util__type_list_subsumes_3_0_i2);
Declare_label(mercury__type_util__type_list_subsumes_3_0_i3);
Declare_label(mercury__type_util__type_list_subsumes_3_0_i4);
Declare_label(mercury__type_util__type_list_subsumes_3_0_i1000);
Define_extern_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
Declare_label(mercury__type_util__apply_substitution_to_type_map_3_0_i4);
Declare_label(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
Declare_label(mercury__type_util__apply_substitution_to_type_map_3_0_i6);
Define_extern_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i4);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i6);
Declare_static(mercury__type_util__substitute_type_args_2_4_0);
Declare_label(mercury__type_util__substitute_type_args_2_4_0_i4);
Declare_label(mercury__type_util__substitute_type_args_2_4_0_i5);
Declare_label(mercury__type_util__substitute_type_args_2_4_0_i1003);
Declare_static(mercury__type_util__substitute_type_args_3_4_0);
Declare_label(mercury__type_util__substitute_type_args_3_4_0_i4);
Declare_label(mercury__type_util__substitute_type_args_3_4_0_i5);
Declare_label(mercury__type_util__substitute_type_args_3_4_0_i1003);
Declare_static(mercury__type_util__type_unify_head_type_param_5_0);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i4);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i7);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i3);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i11);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i10);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i15);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i17);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i1);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i1000);
Declare_static(mercury__type_util__apply_substitution_to_type_map_2_4_0);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i4);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i5);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i6);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1002);
Declare_static(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1002);
Define_extern_entry(mercury____Unify___type_util__builtin_type_0_0);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1027);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1026);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1025);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1024);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1023);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1022);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1021);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1011);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1012);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1013);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1014);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1015);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1016);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1017);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1020);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1018);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1019);
Define_extern_entry(mercury____Index___type_util__builtin_type_0_0);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i5);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i6);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i7);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i8);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i9);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i10);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i11);
Declare_label(mercury____Index___type_util__builtin_type_0_0_i4);
Define_extern_entry(mercury____Compare___type_util__builtin_type_0_0);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i2);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i3);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i4);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i6);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i13);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i15);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i17);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i19);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i21);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i23);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i25);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i12);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i9);
Declare_label(mercury____Compare___type_util__builtin_type_0_0_i1000);

extern Word * mercury_data_type_util__base_type_layout_builtin_type_0[];
Word * mercury_data_type_util__base_type_info_builtin_type_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___type_util__builtin_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___type_util__builtin_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___type_util__builtin_type_0_0),
	(Word *) (Integer) mercury_data_type_util__base_type_layout_builtin_type_0
};

extern Word * mercury_data_type_util__common_1[];
extern Word * mercury_data_type_util__common_3[];
Word * mercury_data_type_util__base_type_layout_builtin_type_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_type_util__common_1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_type_util__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_type_util__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_type_util__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 7),
	(Word *) string_const("int_type", 8),
	(Word *) string_const("char_type", 9),
	(Word *) string_const("str_type", 8),
	(Word *) string_const("float_type", 10),
	(Word *) string_const("pred_type", 9),
	(Word *) string_const("enum_type", 9),
	(Word *) string_const("polymorphic_type", 16)
};

extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_type_util__common_2[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_type_util__common_3[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_type_util__common_2),
	(Word *) string_const("user_type", 9)
};

BEGIN_MODULE(mercury__type_util_module0)
	init_entry(mercury__type_util__type_id_arity__ua10000_3_0);
BEGIN_CODE

/* code for predicate 'type_util__type_id_arity__ua10000'/3 in mode 0 */
Define_static(mercury__type_util__type_id_arity__ua10000_3_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module1)
	init_entry(mercury__type_util__type_id_name__ua10000_3_0);
BEGIN_CODE

/* code for predicate 'type_util__type_id_name__ua10000'/3 in mode 0 */
Define_static(mercury__type_util__type_id_name__ua10000_3_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	tailcall(ENTRY(mercury__prog_util__unqualify_name_2_0),
		STATIC(mercury__type_util__type_id_name__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__type_util_module2)
	init_entry(mercury__type_util__type_id_module__ua10000_3_0);
	init_label(mercury__type_util__type_id_module__ua10000_3_0_i3);
BEGIN_CODE

/* code for predicate 'type_util__type_id_module__ua10000'/3 in mode 0 */
Define_static(mercury__type_util__type_id_module__ua10000_3_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_id_module__ua10000_3_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	proceed();
Define_label(mercury__type_util__type_id_module__ua10000_3_0_i3);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module3)
	init_entry(mercury__type_util__type_is_atomic_2_0);
	init_label(mercury__type_util__type_is_atomic_2_0_i2);
	init_label(mercury__type_util__type_is_atomic_2_0_i1);
	init_label(mercury__type_util__type_is_atomic_2_0_i1000);
BEGIN_CODE

/* code for predicate 'type_is_atomic'/2 in mode 0 */
Define_entry(mercury__type_util__type_is_atomic_2_0);
	incr_sp_push_msg(1, "type_is_atomic");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__type_util__classify_type_3_0),
		mercury__type_util__type_is_atomic_2_0_i2,
		ENTRY(mercury__type_util__type_is_atomic_2_0));
	}
Define_label(mercury__type_util__type_is_atomic_2_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_atomic_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 6)))))
		GOTO_LABEL(mercury__type_util__type_is_atomic_2_0_i1);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury__type_util__type_is_atomic_2_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r1) == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_is_atomic_2_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_is_atomic_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__type_util__type_is_atomic_2_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module4)
	init_entry(mercury__type_util__type_is_higher_order_3_0);
	init_label(mercury__type_util__type_is_higher_order_3_0_i12);
	init_label(mercury__type_util__type_is_higher_order_3_0_i1017);
	init_label(mercury__type_util__type_is_higher_order_3_0_i1011);
	init_label(mercury__type_util__type_is_higher_order_3_0_i1016);
BEGIN_CODE

/* code for predicate 'type_is_higher_order'/3 in mode 0 */
Define_entry(mercury__type_util__type_is_higher_order_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)), (char *)string_const("=", 1)) !=0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1017);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if ((tag((Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r1, ((Integer) 1)), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r1, ((Integer) 1)), ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r1, ((Integer) 1)), ((Integer) 0)), ((Integer) 0)), ((Integer) 0)), (char *)string_const("func", 4)) !=0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if (((Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r1, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r1, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1011);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r3, ((Integer) 1)), ((Integer) 0)), ((Integer) 1));
	r4 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(1, "type_is_higher_order");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__type_util__type_is_higher_order_3_0_i12,
		ENTRY(mercury__type_util__type_is_higher_order_3_0));
	}
Define_label(mercury__type_util__type_is_higher_order_3_0_i12);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_higher_order_3_0));
	r2 = ((Integer) 1);
	r3 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__type_util__type_is_higher_order_3_0_i1017);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)), (char *)string_const("pred", 4)) !=0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_3_0_i1016);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = TRUE;
	r2 = ((Integer) 0);
	proceed();
Define_label(mercury__type_util__type_is_higher_order_3_0_i1011);
	r1 = FALSE;
	proceed();
Define_label(mercury__type_util__type_is_higher_order_3_0_i1016);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module5)
	init_entry(mercury__type_util__classify_type_3_0);
	init_label(mercury__type_util__classify_type_3_0_i1000);
	init_label(mercury__type_util__classify_type_3_0_i5);
	init_label(mercury__type_util__classify_type_3_0_i11);
	init_label(mercury__type_util__classify_type_3_0_i17);
	init_label(mercury__type_util__classify_type_3_0_i23);
	init_label(mercury__type_util__classify_type_3_0_i31);
	init_label(mercury__type_util__classify_type_3_0_i30);
	init_label(mercury__type_util__classify_type_3_0_i35);
	init_label(mercury__type_util__classify_type_3_0_i37);
	init_label(mercury__type_util__classify_type_3_0_i38);
	init_label(mercury__type_util__classify_type_3_0_i40);
	init_label(mercury__type_util__classify_type_3_0_i34);
BEGIN_CODE

/* code for predicate 'classify_type'/3 in mode 0 */
Define_entry(mercury__type_util__classify_type_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 6)));
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i1000);
	incr_sp_push_msg(3, "classify_type");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i5);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i5);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("character", 9)) !=0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i5);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i5);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i11);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i11);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("int", 3)) !=0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i11);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i11);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i11);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i17);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i17);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i17);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i17);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i17);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i23);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i23);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i23);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i23);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i23);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__type_util__type_is_higher_order_3_0),
		mercury__type_util__classify_type_3_0_i31,
		ENTRY(mercury__type_util__classify_type_3_0));
	}
Define_label(mercury__type_util__classify_type_3_0_i31);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i30);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 4)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i30);
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__classify_type_3_0_i35,
		ENTRY(mercury__type_util__classify_type_3_0));
	}
Define_label(mercury__type_util__classify_type_3_0_i35);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i34);
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__classify_type_3_0_i37,
		ENTRY(mercury__type_util__classify_type_3_0));
	}
Define_label(mercury__type_util__classify_type_3_0_i37);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_type_util__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__classify_type_3_0_i38,
		ENTRY(mercury__type_util__classify_type_3_0));
	}
Define_label(mercury__type_util__classify_type_3_0_i38);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i34);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__type_util__classify_type_3_0_i40,
		ENTRY(mercury__type_util__classify_type_3_0));
	}
Define_label(mercury__type_util__classify_type_3_0_i40);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i34);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != ((Integer) 0)))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i34);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 5)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i34);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module6)
	init_entry(mercury__type_util__type_to_type_id_3_0);
	init_label(mercury__type_util__type_to_type_id_3_0_i1029);
	init_label(mercury__type_util__type_to_type_id_3_0_i15);
	init_label(mercury__type_util__type_to_type_id_3_0_i1027);
	init_label(mercury__type_util__type_to_type_id_3_0_i1014);
BEGIN_CODE

/* code for predicate 'type_to_type_id'/3 in mode 0 */
Define_entry(mercury__type_util__type_to_type_id_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((strcmp((char *)(Integer) r3, (char *)string_const(":", 1)) !=0))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1029);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1029);
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1029);
	if (((Integer) field(mktag(1), (Integer) r4, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1029);
	{
	Word tempr1, tempr2, tempr3, tempr4, tempr5;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	if ((tag((Integer) tempr2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	if (((Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	tempr4 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) tempr4) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	tempr5 = (Integer) field(mktag(0), (Integer) tempr4, ((Integer) 0));
	if ((tag((Integer) tempr5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1014);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) tempr5, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr4, ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	incr_sp_push_msg(3, "type_to_type_id");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i15);
	}
Define_label(mercury__type_util__type_to_type_id_3_0_i1029);
	incr_sp_push_msg(3, "type_to_type_id");
	detstackvar(3) = (Integer) succip;
	r1 = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
Define_label(mercury__type_util__type_to_type_id_3_0_i15);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_to_type_id_3_0_i1027,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
	}
Define_label(mercury__type_util__type_to_type_id_3_0_i1027);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r3 = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__type_to_type_id_3_0_i1014);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module7)
	init_entry(mercury__type_util__var_2_0);
	init_label(mercury__type_util__var_2_0_i1);
BEGIN_CODE

/* code for predicate 'type_util__var'/2 in mode 0 */
Define_entry(mercury__type_util__var_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__var_2_0_i1);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__var_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module8)
	init_entry(mercury__type_util__construct_type_3_0);
BEGIN_CODE

/* code for predicate 'construct_type'/3 in mode 0 */
Define_entry(mercury__type_util__construct_type_3_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__prog_util__construct_qualified_term_3_0);
	tailcall(ENTRY(mercury__prog_util__construct_qualified_term_3_0),
		ENTRY(mercury__type_util__construct_type_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__type_util_module9)
	init_entry(mercury__type_util__construct_type_4_0);
BEGIN_CODE

/* code for predicate 'construct_type'/4 in mode 0 */
Define_entry(mercury__type_util__construct_type_4_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__prog_util__construct_qualified_term_4_0);
	tailcall(ENTRY(mercury__prog_util__construct_qualified_term_4_0),
		ENTRY(mercury__type_util__construct_type_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__type_util_module10)
	init_entry(mercury__type_util__make_type_id_3_0);
	init_label(mercury__type_util__make_type_id_3_0_i1);
BEGIN_CODE

/* code for predicate 'make_type_id'/3 in mode 0 */
Define_entry(mercury__type_util__make_type_id_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__make_type_id_3_0_i1);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	proceed();
	}
Define_label(mercury__type_util__make_type_id_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module11)
	init_entry(mercury__type_util__type_id_module_3_0);
BEGIN_CODE

/* code for predicate 'type_util__type_id_module'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_module_3_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__type_util__type_id_module__ua10000_3_0),
		ENTRY(mercury__type_util__type_id_module_3_0));
END_MODULE

BEGIN_MODULE(mercury__type_util_module12)
	init_entry(mercury__type_util__type_id_name_3_0);
BEGIN_CODE

/* code for predicate 'type_util__type_id_name'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_name_3_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__type_util__type_id_name__ua10000_3_0),
		ENTRY(mercury__type_util__type_id_name_3_0));
END_MODULE

BEGIN_MODULE(mercury__type_util_module13)
	init_entry(mercury__type_util__type_id_arity_3_0);
BEGIN_CODE

/* code for predicate 'type_util__type_id_arity'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_arity_3_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__type_util__type_id_arity__ua10000_3_0),
		ENTRY(mercury__type_util__type_id_arity_3_0));
END_MODULE

BEGIN_MODULE(mercury__type_util_module14)
	init_entry(mercury__type_util__type_constructors_3_0);
	init_label(mercury__type_util__type_constructors_3_0_i2);
	init_label(mercury__type_util__type_constructors_3_0_i4);
	init_label(mercury__type_util__type_constructors_3_0_i5);
	init_label(mercury__type_util__type_constructors_3_0_i7);
	init_label(mercury__type_util__type_constructors_3_0_i8);
	init_label(mercury__type_util__type_constructors_3_0_i13);
	init_label(mercury__type_util__type_constructors_3_0_i14);
	init_label(mercury__type_util__type_constructors_3_0_i15);
	init_label(mercury__type_util__type_constructors_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_constructors'/3 in mode 0 */
Define_entry(mercury__type_util__type_constructors_3_0);
	incr_sp_push_msg(3, "type_constructors");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__type_constructors_3_0_i2,
		ENTRY(mercury__type_util__type_constructors_3_0));
	}
Define_label(mercury__type_util__type_constructors_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i1);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__type_constructors_3_0_i4,
		ENTRY(mercury__type_util__type_constructors_3_0));
	}
Define_label(mercury__type_util__type_constructors_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_type_util__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_constructors_3_0_i5,
		ENTRY(mercury__type_util__type_constructors_3_0));
	}
Define_label(mercury__type_util__type_constructors_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i1);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_tparams_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tparams_2_0),
		mercury__type_util__type_constructors_3_0_i7,
		ENTRY(mercury__type_util__type_constructors_3_0));
	}
Define_label(mercury__type_util__type_constructors_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__type_util__type_constructors_3_0_i8,
		ENTRY(mercury__type_util__type_constructors_3_0));
	}
Define_label(mercury__type_util__type_constructors_3_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i1);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) detstackvar(1) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i15);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__term__term_list_to_var_list_2_0);
	call_localret(ENTRY(mercury__term__term_list_to_var_list_2_0),
		mercury__type_util__type_constructors_3_0_i13,
		ENTRY(mercury__type_util__type_constructors_3_0));
	}
Define_label(mercury__type_util__type_constructors_3_0_i13);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__type_util__substitute_type_args_2_4_0),
		mercury__type_util__type_constructors_3_0_i14,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r2 = (Integer) r1;
Define_label(mercury__type_util__type_constructors_3_0_i15);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__type_constructors_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module15)
	init_entry(mercury__type_util__type_is_no_tag_type_3_0);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i6);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i11);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i16);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i20);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_is_no_tag_type'/3 in mode 0 */
Define_entry(mercury__type_util__type_is_no_tag_type_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	if (((Integer) tempr2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	if (((Integer) field(mktag(1), (Integer) tempr2, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0)), ((Integer) 1));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i6);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), (char *)string_const("mercury_builtin", 15)) !=0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i6);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), (char *)string_const("type_info", 9)) ==0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	}
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i6);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i11);
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	if ((strcmp((char *)(Integer) r1, (char *)string_const("mercury_builtin", 15)) !=0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i11);
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	if ((strcmp((char *)(Integer) r1, (char *)string_const("base_type_info", 14)) ==0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i11);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i16);
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((strcmp((char *)(Integer) r1, (char *)string_const("type_info", 9)) ==0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i16);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i20);
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((strcmp((char *)(Integer) r1, (char *)string_const("base_type_info", 14)) ==0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i20);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module16)
	init_entry(mercury__type_util__type_unify_5_0);
	init_label(mercury__type_util__type_unify_5_0_i6);
	init_label(mercury__type_util__type_unify_5_0_i7);
	init_label(mercury__type_util__type_unify_5_0_i8);
	init_label(mercury__type_util__type_unify_5_0_i10);
	init_label(mercury__type_util__type_unify_5_0_i5);
	init_label(mercury__type_util__type_unify_5_0_i14);
	init_label(mercury__type_util__type_unify_5_0_i13);
	init_label(mercury__type_util__type_unify_5_0_i20);
	init_label(mercury__type_util__type_unify_5_0_i24);
	init_label(mercury__type_util__type_unify_5_0_i26);
	init_label(mercury__type_util__type_unify_5_0_i1003);
	init_label(mercury__type_util__type_unify_5_0_i32);
	init_label(mercury__type_util__type_unify_5_0_i31);
	init_label(mercury__type_util__type_unify_5_0_i38);
	init_label(mercury__type_util__type_unify_5_0_i42);
	init_label(mercury__type_util__type_unify_5_0_i29);
	init_label(mercury__type_util__type_unify_5_0_i48);
	init_label(mercury__type_util__type_unify_5_0_i47);
	init_label(mercury__type_util__type_unify_5_0_i54);
	init_label(mercury__type_util__type_unify_5_0_i53);
	init_label(mercury__type_util__type_unify_5_0_i60);
	init_label(mercury__type_util__type_unify_5_0_i64);
	init_label(mercury__type_util__type_unify_5_0_i63);
	init_label(mercury__type_util__type_unify_5_0_i68);
	init_label(mercury__type_util__type_unify_5_0_i72);
	init_label(mercury__type_util__type_unify_5_0_i70);
	init_label(mercury__type_util__type_unify_5_0_i69);
	init_label(mercury__type_util__type_unify_5_0_i76);
	init_label(mercury__type_util__type_unify_5_0_i59);
	init_label(mercury__type_util__type_unify_5_0_i83);
	init_label(mercury__type_util__type_unify_5_0_i85);
	init_label(mercury__type_util__type_unify_5_0_i89);
	init_label(mercury__type_util__type_unify_5_0_i87);
	init_label(mercury__type_util__type_unify_5_0_i86);
	init_label(mercury__type_util__type_unify_5_0_i93);
	init_label(mercury__type_util__type_unify_5_0_i82);
	init_label(mercury__type_util__type_unify_5_0_i99);
	init_label(mercury__type_util__type_unify_5_0_i98);
	init_label(mercury__type_util__type_unify_5_0_i101);
	init_label(mercury__type_util__type_unify_5_0_i1);
	init_label(mercury__type_util__type_unify_5_0_i1001);
BEGIN_CODE

/* code for predicate 'type_unify'/5 in mode 0 */
Define_entry(mercury__type_util__type_unify_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1003);
	incr_sp_push_msg(8, "type_unify");
	detstackvar(8) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i5);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) r2;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_unify_5_0_i6,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_unify_5_0_i7,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__const_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__const_0_0),
		mercury__type_util__type_unify_5_0_i8,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	if (((Integer) detstackvar(5) != (Integer) detstackvar(1)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__type_util__type_unify_list_5_0),
		mercury__type_util__type_unify_5_0_i10,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i10);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1001);
	r1 = FALSE;
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i5);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	detstackvar(1) = (Integer) r1;
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i14,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i13);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__type_util__type_unify_5_0,
		LABEL(mercury__type_util__type_unify_5_0_i10),
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i13);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__occurs_list_3_0);
	call_localret(ENTRY(mercury__term__occurs_list_3_0),
		mercury__type_util__type_unify_5_0_i20,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i20);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i24,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i24);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__type_unify_5_0_i26,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i26);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i1003);
	incr_sp_push_msg(8, "type_unify");
	detstackvar(8) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i29);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i32,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i32);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i31);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__type_util__type_unify_5_0,
		LABEL(mercury__type_util__type_unify_5_0_i10),
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i31);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__occurs_list_3_0);
	call_localret(ENTRY(mercury__term__occurs_list_3_0),
		mercury__type_util__type_unify_5_0_i38,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i38);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i42,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i42);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__type_unify_5_0_i26,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i29);
	detstackvar(1) = (Integer) r2;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i48,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i48);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i47);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__type_util__type_unify_head_type_param_5_0),
		mercury__type_util__type_unify_5_0_i10,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i47);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i54,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i54);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i53);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__type_util__type_unify_head_type_param_5_0),
		mercury__type_util__type_unify_5_0_i10,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i53);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i60,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i60);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i59);
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i64,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i64);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i63);
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__type_util__type_unify_5_0,
		LABEL(mercury__type_util__type_unify_5_0_i10),
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i63);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__apply_rec_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__type_unify_5_0_i68,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i68);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i69);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__type_util__type_unify_5_0_i72,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i72);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i70);
	r2 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i70);
	r1 = (Integer) detstackvar(2);
Define_label(mercury__type_util__type_unify_5_0_i69);
	detstackvar(2) = (Integer) r1;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__occurs_3_0);
	call_localret(ENTRY(mercury__term__occurs_3_0),
		mercury__type_util__type_unify_5_0_i76,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i76);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__type_unify_5_0_i26,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i59);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i83,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i83);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i82);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__apply_rec_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__type_unify_5_0_i85,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i85);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i86);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__type_util__type_unify_5_0_i89,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i89);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i87);
	r2 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i87);
	r1 = (Integer) detstackvar(2);
Define_label(mercury__type_util__type_unify_5_0_i86);
	detstackvar(2) = (Integer) r1;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__occurs_3_0);
	call_localret(ENTRY(mercury__term__occurs_3_0),
		mercury__type_util__type_unify_5_0_i93,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i93);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__type_unify_5_0_i26,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i82);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__type_util__type_unify_5_0_i99,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i99);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i98);
	r2 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i98);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__type_unify_5_0_i101,
		ENTRY(mercury__type_util__type_unify_5_0));
	}
Define_label(mercury__type_util__type_unify_5_0_i101);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i1001);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module17)
	init_entry(mercury__type_util__type_unify_list_5_0);
	init_label(mercury__type_util__type_unify_list_5_0_i1010);
	init_label(mercury__type_util__type_unify_list_5_0_i6);
	init_label(mercury__type_util__type_unify_list_5_0_i8);
	init_label(mercury__type_util__type_unify_list_5_0_i1007);
	init_label(mercury__type_util__type_unify_list_5_0_i1);
	init_label(mercury__type_util__type_unify_list_5_0_i1009);
BEGIN_CODE

/* code for predicate 'type_unify_list'/5 in mode 0 */
Define_entry(mercury__type_util__type_unify_list_5_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1010);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1007);
	r2 = (Integer) r4;
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_unify_list_5_0_i1010);
	incr_sp_push_msg(4, "type_unify_list");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__type_util__type_unify_5_0),
		mercury__type_util__type_unify_list_5_0_i6,
		ENTRY(mercury__type_util__type_unify_list_5_0));
	}
Define_label(mercury__type_util__type_unify_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_list_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	localcall(mercury__type_util__type_unify_list_5_0,
		LABEL(mercury__type_util__type_unify_list_5_0_i8),
		ENTRY(mercury__type_util__type_unify_list_5_0));
Define_label(mercury__type_util__type_unify_list_5_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_list_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_unify_list_5_0_i1007);
	r1 = FALSE;
	proceed();
Define_label(mercury__type_util__type_unify_list_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__type_util__type_unify_list_5_0_i1009);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module18)
	init_entry(mercury__type_util__vars_2_0);
BEGIN_CODE

/* code for predicate 'type_util__vars'/2 in mode 0 */
Define_entry(mercury__type_util__vars_2_0);
	{
	Declare_entry(mercury__term__vars_2_0);
	tailcall(ENTRY(mercury__term__vars_2_0),
		ENTRY(mercury__type_util__vars_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__type_util_module19)
	init_entry(mercury__type_util__type_list_subsumes_3_0);
	init_label(mercury__type_util__type_list_subsumes_3_0_i2);
	init_label(mercury__type_util__type_list_subsumes_3_0_i3);
	init_label(mercury__type_util__type_list_subsumes_3_0_i4);
	init_label(mercury__type_util__type_list_subsumes_3_0_i1000);
BEGIN_CODE

/* code for predicate 'type_list_subsumes'/3 in mode 0 */
Define_entry(mercury__type_util__type_list_subsumes_3_0);
	incr_sp_push_msg(4, "type_list_subsumes");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__term__vars_list_2_0);
	call_localret(ENTRY(mercury__term__vars_list_2_0),
		mercury__type_util__type_list_subsumes_3_0_i2,
		ENTRY(mercury__type_util__type_list_subsumes_3_0));
	}
Define_label(mercury__type_util__type_list_subsumes_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_list_subsumes_3_0));
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__type_util__type_list_subsumes_3_0_i3,
		ENTRY(mercury__type_util__type_list_subsumes_3_0));
	}
Define_label(mercury__type_util__type_list_subsumes_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__type_list_subsumes_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__type_util__type_unify_list_5_0),
		mercury__type_util__type_list_subsumes_3_0_i4,
		ENTRY(mercury__type_util__type_list_subsumes_3_0));
	}
Define_label(mercury__type_util__type_list_subsumes_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__type_list_subsumes_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_list_subsumes_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_list_subsumes_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module20)
	init_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
	init_label(mercury__type_util__apply_substitution_to_type_map_3_0_i4);
	init_label(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
	init_label(mercury__type_util__apply_substitution_to_type_map_3_0_i6);
BEGIN_CODE

/* code for predicate 'apply_substitution_to_type_map'/3 in mode 0 */
Define_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
	r3 = (Integer) r2;
	incr_sp_push_msg(3, "apply_substitution_to_type_map");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__is_empty_1_0);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_substitution_to_type_map_3_0_i4,
		ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0));
	}
Define_label(mercury__type_util__apply_substitution_to_type_map_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__type_util__apply_substitution_to_type_map_3_0_i6,
		ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0));
	}
Define_label(mercury__type_util__apply_substitution_to_type_map_3_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0),
		ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0));
END_MODULE

BEGIN_MODULE(mercury__type_util_module21)
	init_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i4);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i6);
BEGIN_CODE

/* code for predicate 'apply_rec_substitution_to_type_map'/3 in mode 0 */
Define_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
	r3 = (Integer) r2;
	incr_sp_push_msg(3, "apply_rec_substitution_to_type_map");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__is_empty_1_0);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_rec_substitution_to_type_map_3_0_i4,
		ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
	}
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__type_util__apply_rec_substitution_to_type_map_3_0_i6,
		ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
	}
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0),
		ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
END_MODULE

BEGIN_MODULE(mercury__type_util_module22)
	init_entry(mercury__type_util__substitute_type_args_2_4_0);
	init_label(mercury__type_util__substitute_type_args_2_4_0_i4);
	init_label(mercury__type_util__substitute_type_args_2_4_0_i5);
	init_label(mercury__type_util__substitute_type_args_2_4_0_i1003);
BEGIN_CODE

/* code for predicate 'substitute_type_args_2'/4 in mode 0 */
Define_static(mercury__type_util__substitute_type_args_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__substitute_type_args_2_4_0_i1003);
	incr_sp_push_msg(5, "substitute_type_args_2");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__type_util__substitute_type_args_3_4_0),
		mercury__type_util__substitute_type_args_2_4_0_i4,
		STATIC(mercury__type_util__substitute_type_args_2_4_0));
	}
Define_label(mercury__type_util__substitute_type_args_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_2_4_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__type_util__substitute_type_args_2_4_0,
		LABEL(mercury__type_util__substitute_type_args_2_4_0_i5),
		STATIC(mercury__type_util__substitute_type_args_2_4_0));
	}
Define_label(mercury__type_util__substitute_type_args_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__substitute_type_args_2_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module23)
	init_entry(mercury__type_util__substitute_type_args_3_4_0);
	init_label(mercury__type_util__substitute_type_args_3_4_0_i4);
	init_label(mercury__type_util__substitute_type_args_3_4_0_i5);
	init_label(mercury__type_util__substitute_type_args_3_4_0_i1003);
BEGIN_CODE

/* code for predicate 'substitute_type_args_3'/4 in mode 0 */
Define_static(mercury__type_util__substitute_type_args_3_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__substitute_type_args_3_4_0_i1003);
	incr_sp_push_msg(5, "substitute_type_args_3");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	{
	Declare_entry(mercury__term__substitute_corresponding_4_0);
	call_localret(ENTRY(mercury__term__substitute_corresponding_4_0),
		mercury__type_util__substitute_type_args_3_4_0_i4,
		STATIC(mercury__type_util__substitute_type_args_3_4_0));
	}
	}
Define_label(mercury__type_util__substitute_type_args_3_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_3_4_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__type_util__substitute_type_args_3_4_0,
		LABEL(mercury__type_util__substitute_type_args_3_4_0_i5),
		STATIC(mercury__type_util__substitute_type_args_3_4_0));
	}
Define_label(mercury__type_util__substitute_type_args_3_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_3_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__substitute_type_args_3_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module24)
	init_entry(mercury__type_util__type_unify_head_type_param_5_0);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i4);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i7);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i3);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i11);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i10);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i15);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i17);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i1);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i1000);
BEGIN_CODE

/* code for predicate 'type_unify_head_type_param'/5 in mode 0 */
Define_static(mercury__type_util__type_unify_head_type_param_5_0);
	incr_sp_push_msg(5, "type_unify_head_type_param");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r4;
	detstackvar(4) = (Integer) r4;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_head_type_param_5_0_i4,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
	}
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i3);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i1);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	localcall(mercury__type_util__type_unify_head_type_param_5_0,
		LABEL(mercury__type_util__type_unify_head_type_param_5_0_i7),
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__type_util__type_unify_head_type_param_5_0_i11,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
	}
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i11);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i10);
	r2 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i10);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_head_type_param_5_0_i15,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
	}
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i15);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i1);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__type_unify_head_type_param_5_0_i17,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
	}
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i17);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i1000);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module25)
	init_entry(mercury__type_util__apply_substitution_to_type_map_2_4_0);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i4);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i5);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i6);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'apply_substitution_to_type_map_2'/4 in mode 0 */
Define_static(mercury__type_util__apply_substitution_to_type_map_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1002);
	incr_sp_push_msg(5, "apply_substitution_to_type_map_2");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__type_util__apply_substitution_to_type_map_2_4_0_i4,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	}
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__term__apply_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_substitution_3_0),
		mercury__type_util__apply_substitution_to_type_map_2_4_0_i5,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	}
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__type_util__apply_substitution_to_type_map_2_4_0_i6,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	}
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__type_util__apply_substitution_to_type_map_2_4_0,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module26)
	init_entry(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'apply_rec_substitution_to_type_map_2'/4 in mode 0 */
Define_static(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1002);
	incr_sp_push_msg(5, "apply_rec_substitution_to_type_map_2");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	}
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__term__apply_rec_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	}
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	}
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module27)
	init_entry(mercury____Unify___type_util__builtin_type_0_0);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1027);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1026);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1025);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1024);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1023);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1022);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1021);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1011);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1012);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1013);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1014);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1015);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1016);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1017);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1020);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1018);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1019);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___type_util__builtin_type_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1020);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1027) AND
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1026) AND
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1025) AND
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1024) AND
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1023) AND
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1022) AND
		LABEL(mercury____Unify___type_util__builtin_type_0_0_i1021));
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1027);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1011);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1026);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1012);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1025);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1013);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1024);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1014);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1023);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1015);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1022);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1016);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1021);
	incr_sp_push_msg(1, "__Unify__");
	GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1017);
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1011);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1012);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1013);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1014);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1015);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1016);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 5)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1017);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 6)))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1020);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1019);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term_0_0),
		ENTRY(mercury____Unify___type_util__builtin_type_0_0));
	}
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1018);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1019);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module28)
	init_entry(mercury____Index___type_util__builtin_type_0_0);
	init_label(mercury____Index___type_util__builtin_type_0_0_i5);
	init_label(mercury____Index___type_util__builtin_type_0_0_i6);
	init_label(mercury____Index___type_util__builtin_type_0_0_i7);
	init_label(mercury____Index___type_util__builtin_type_0_0_i8);
	init_label(mercury____Index___type_util__builtin_type_0_0_i9);
	init_label(mercury____Index___type_util__builtin_type_0_0_i10);
	init_label(mercury____Index___type_util__builtin_type_0_0_i11);
	init_label(mercury____Index___type_util__builtin_type_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___type_util__builtin_type_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___type_util__builtin_type_0_0_i4);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Index___type_util__builtin_type_0_0_i5) AND
		LABEL(mercury____Index___type_util__builtin_type_0_0_i6) AND
		LABEL(mercury____Index___type_util__builtin_type_0_0_i7) AND
		LABEL(mercury____Index___type_util__builtin_type_0_0_i8) AND
		LABEL(mercury____Index___type_util__builtin_type_0_0_i9) AND
		LABEL(mercury____Index___type_util__builtin_type_0_0_i10) AND
		LABEL(mercury____Index___type_util__builtin_type_0_0_i11));
Define_label(mercury____Index___type_util__builtin_type_0_0_i5);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i6);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i7);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i8);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i10);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i11);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___type_util__builtin_type_0_0_i4);
	r1 = ((Integer) 7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__type_util_module29)
	init_entry(mercury____Compare___type_util__builtin_type_0_0);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i2);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i3);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i4);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i6);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i13);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i15);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i17);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i19);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i21);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i23);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i25);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i12);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i9);
	init_label(mercury____Compare___type_util__builtin_type_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___type_util__builtin_type_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___type_util__builtin_type_0_0),
		mercury____Compare___type_util__builtin_type_0_0_i2,
		ENTRY(mercury____Compare___type_util__builtin_type_0_0));
	}
Define_label(mercury____Compare___type_util__builtin_type_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___type_util__builtin_type_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___type_util__builtin_type_0_0),
		mercury____Compare___type_util__builtin_type_0_0_i3,
		ENTRY(mercury____Compare___type_util__builtin_type_0_0));
	}
Define_label(mercury____Compare___type_util__builtin_type_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___type_util__builtin_type_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i6);
	r1 = (Integer) detstackvar(1);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i12);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i13) AND
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i15) AND
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i17) AND
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i19) AND
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i21) AND
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i23) AND
		LABEL(mercury____Compare___type_util__builtin_type_0_0_i25));
Define_label(mercury____Compare___type_util__builtin_type_0_0_i13);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i15);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i17);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i19);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i21);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i23);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 5)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i25);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 6)))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___type_util__builtin_type_0_0_i12);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___type_util__builtin_type_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term_0_0),
		ENTRY(mercury____Compare___type_util__builtin_type_0_0));
	}
Define_label(mercury____Compare___type_util__builtin_type_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___type_util__builtin_type_0_0));
	}
Define_label(mercury____Compare___type_util__builtin_type_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___type_util__builtin_type_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__type_util_bunch_0(void)
{
	mercury__type_util_module0();
	mercury__type_util_module1();
	mercury__type_util_module2();
	mercury__type_util_module3();
	mercury__type_util_module4();
	mercury__type_util_module5();
	mercury__type_util_module6();
	mercury__type_util_module7();
	mercury__type_util_module8();
	mercury__type_util_module9();
	mercury__type_util_module10();
	mercury__type_util_module11();
	mercury__type_util_module12();
	mercury__type_util_module13();
	mercury__type_util_module14();
	mercury__type_util_module15();
	mercury__type_util_module16();
	mercury__type_util_module17();
	mercury__type_util_module18();
	mercury__type_util_module19();
	mercury__type_util_module20();
	mercury__type_util_module21();
	mercury__type_util_module22();
	mercury__type_util_module23();
	mercury__type_util_module24();
	mercury__type_util_module25();
	mercury__type_util_module26();
	mercury__type_util_module27();
	mercury__type_util_module28();
	mercury__type_util_module29();
}

#endif

void mercury__type_util__init(void); /* suppress gcc warning */
void mercury__type_util__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__type_util_bunch_0();
#endif
}
