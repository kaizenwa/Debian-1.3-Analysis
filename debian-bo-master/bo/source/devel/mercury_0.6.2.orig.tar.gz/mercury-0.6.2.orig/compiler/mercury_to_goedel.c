/*
** Automatically generated from `mercury_to_goedel.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__mercury_to_goedel__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i1002);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i14);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i22);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i24);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i25);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i26);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i27);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i28);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i17);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i30);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i34);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i35);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i36);
Declare_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i2);
Declare_static(mercury__mercury_to_goedel__goedel_output_func_mode__ua10000_7_0);
Declare_static(mercury__mercury_to_goedel__goedel_output_pred_mode__ua10000_6_0);
Declare_static(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i4);
Declare_static(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i8);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i14);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i17);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i18);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i19);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i20);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i21);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i22);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i23);
Declare_static(mercury__mercury_to_goedel__goedel_output_mode_defn__ua10000_5_0);
Declare_static(mercury__mercury_to_goedel__goedel_output_inst_defn__ua10000_5_0);
Declare_static(mercury__mercury_to_goedel__LambdaGoal__1_2_0);
Define_extern_entry(mercury__mercury_to_goedel__convert_to_goedel_4_0);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i2);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i3);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i4);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i5);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i6);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i7);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i8);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i12);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i13);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i14);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i18);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i19);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i20);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i21);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i22);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i23);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i24);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i25);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i26);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i27);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i15);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i29);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i30);
Declare_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i33);
Declare_static(mercury__mercury_to_goedel__goedel_output_item_list_3_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_output_item_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1023);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1022);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1021);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1020);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1008);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i14);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i15);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i17);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i18);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i19);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i25);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i26);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1019);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i28);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i30);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i29);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i32);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1013);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1014);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1016);
Declare_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1017);
Declare_static(mercury__mercury_to_goedel__goedel_output_type_defn_5_0);
Declare_static(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i14);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i15);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i17);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i18);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i19);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i20);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i21);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i22);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i23);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i24);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i25);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i26);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i27);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i28);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i29);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i7);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i34);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i35);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i36);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i37);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i38);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i33);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i40);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i41);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i42);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i43);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i39);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i46);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i47);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i48);
Declare_static(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i7);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i8);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i14);
Declare_static(mercury__mercury_to_goedel__goedel_output_ctors_5_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i15);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i17);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i22);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i18);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i26);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i24);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i31);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i32);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i33);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i34);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i35);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i36);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i37);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i38);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i39);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i40);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i41);
Declare_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i1000);
Declare_static(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i10);
Declare_static(mercury__mercury_to_goedel__goedel_output_func_clause_8_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i10);
Declare_static(mercury__mercury_to_goedel__goedel_output_goal_5_0);
Declare_static(mercury__mercury_to_goedel__goedel_output_goal_2_5_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1016);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1015);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1014);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1013);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1012);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1011);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1010);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1009);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1008);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i7);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i8);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i17);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i18);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i19);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i20);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i21);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i24);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i25);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i29);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i30);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i31);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i32);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i33);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i34);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i37);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i38);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i39);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i41);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i42);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i43);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i44);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i45);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i46);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i47);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i48);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i49);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i50);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i52);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i53);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i54);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i55);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i56);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i57);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i58);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i59);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i60);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i61);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i62);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i63);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i64);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i65);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i67);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i68);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i69);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i71);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i72);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i73);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1007);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i75);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i80);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i81);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i82);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i79);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i84);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i85);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i86);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i87);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i88);
Declare_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1005);
Declare_static(mercury__mercury_to_goedel__goedel_output_disj_5_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i8);
Declare_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i5);
Declare_static(mercury__mercury_to_goedel__goedel_output_some_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i1001);
Declare_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i6);
Declare_static(mercury__mercury_to_goedel__goedel_convert_expression_2_0);
Declare_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
Declare_static(mercury__mercury_to_goedel__goedel_output_newline_3_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_newline_3_0_i2);
Declare_static(mercury__mercury_to_goedel__goedel_output_tabs_3_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i1000);
Declare_label(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i5);
Declare_static(mercury__mercury_to_goedel__goedel_output_list_args_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
Declare_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i19);
Declare_static(mercury__mercury_to_goedel__goedel_output_term_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i1006);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i14);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i22);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i23);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i24);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i25);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i32);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i34);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i35);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i36);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i37);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i28);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i27);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i45);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i47);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i48);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i49);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i50);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i51);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i52);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i40);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i54);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i58);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i59);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i60);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i2);
Declare_static(mercury__mercury_to_goedel__goedel_output_term_args_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_output_constant_3_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i7);
Declare_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i9);
Declare_static(mercury__mercury_to_goedel__goedel_quote_string_3_0);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i14);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i15);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i6);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i3);
Declare_static(mercury__mercury_to_goedel__goedel_output_vars_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_vars_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_vars_4_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_output_vars_2_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_output_var_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i8);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i7);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i13);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i12);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i16);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i20);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i21);
Declare_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i22);
Declare_static(mercury__mercury_to_goedel__goedel_output_type_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i1002);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i9);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i10);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i11);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i2);
Declare_static(mercury__mercury_to_goedel__goedel_output_type_args_4_0);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i4);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i1002);
Declare_static(mercury__mercury_to_goedel__goedel_infix_op_1_0);
Declare_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1000);
Declare_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1);
Declare_static(mercury__mercury_to_goedel__goedel_infix_pred_1_0);
Declare_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i3);
Declare_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1000);
Declare_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i5);
Declare_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2);
Declare_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1);
Declare_static(mercury__mercury_to_goedel__convert_functor_name_2_0);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i4);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i6);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i8);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i10);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i13);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i12);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i3);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i19);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i21);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i18);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i27);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i1006);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i29);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i30);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i31);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i32);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i33);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i34);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i35);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i36);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i37);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i38);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i39);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i40);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i41);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i42);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i43);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i44);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i45);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i46);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i47);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i48);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i49);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i50);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i51);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i52);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i24);
Declare_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i53);
Declare_static(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0);
Declare_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i4);
Declare_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i6);
Declare_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i7);
Declare_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i8);
Declare_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i9);
Declare_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i3);
Declare_static(mercury__mercury_to_goedel__maybe_write_line_number_3_0);
Declare_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i2);
Declare_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i6);
Declare_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i7);
Declare_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i3);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data___base_type_info_string_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_mercury_to_goedel__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_mercury_to_goedel__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury__mercury_to_goedel__LambdaGoal__1_2_0)
};

Word * mercury_data_mercury_to_goedel__common_2[] = {
	(Word *) string_const("int", 3)
};

Word * mercury_data_mercury_to_goedel__common_3[] = {
	(Word *) string_const("integer", 7)
};

Word * mercury_data_mercury_to_goedel__common_4[] = {
	(Word *) string_const("=", 1)
};

Word * mercury_data_mercury_to_goedel__common_5[] = {
	(Word *) string_const("div", 3)
};

Word * mercury_data_mercury_to_goedel__common_6[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("++", 2),
	(Word *) string_const("//", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("mod", 3),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("+", 1),
	(Word *) string_const("*", 1),
	(Word *) string_const("-", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("/", 1),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("div", 3),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("^", 1)
};

Word mercury_data_mercury_to_goedel__common_7[] = {
	((Integer) -2),
	((Integer) -1),
	((Integer) 1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1)
};

Word * mercury_data_mercury_to_goedel__common_8[] = {
	(Word *) string_const("subset", 6),
	(Word *) string_const("strictSubset", 12),
	(Word *) string_const(">=", 2),
	(Word *) string_const("=<", 2),
	(Word *) ((Integer) 0),
	(Word *) string_const("in", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("is", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("<", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const(">", 1)
};

Word mercury_data_mercury_to_goedel__common_9[] = {
	((Integer) -1),
	((Integer) 2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1)
};

Word * mercury_data_mercury_to_goedel__common_10[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const(">=", 2),
	(Word *) string_const("=<", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\=", 2),
	(Word *) string_const("[]", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("+", 1),
	(Word *) string_const("*", 1),
	(Word *) string_const("-", 1),
	(Word *) string_const(",", 1),
	(Word *) string_const("/", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("1", 1),
	(Word *) string_const("0", 1),
	(Word *) string_const("3", 1),
	(Word *) string_const("2", 1),
	(Word *) string_const("5", 1),
	(Word *) string_const("4", 1),
	(Word *) string_const("7", 1),
	(Word *) string_const("6", 1),
	(Word *) string_const("9", 1),
	(Word *) string_const("8", 1),
	(Word *) string_const(";", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("=", 1),
	(Word *) string_const("<", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const(">", 1)
};

Word mercury_data_mercury_to_goedel__common_11[] = {
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1)
};

BEGIN_MODULE(mercury__mercury_to_goedel_module0)
	init_entry(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i1002);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i14);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i22);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i24);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i25);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i26);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i27);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i28);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i17);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i30);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i34);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i35);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i36);
	init_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i2);
BEGIN_CODE

/* code for predicate 'goedel_output_call__ua10000'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i1002);
	incr_sp_push_msg(8, "goedel_output_call__ua10000");
	detstackvar(8) = (Integer) succip;
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r5, ((Integer) 0)), (char *)string_const("is", 2)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_convert_expression_2_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i12,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i13,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" Is ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i5);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
	r1 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_infix_pred_1_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i17);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i24,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i25,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i26,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i27,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i28,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i28);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i17);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i16);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r5;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i30,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	if (((Integer) detstackvar(4) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i2);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = string_const("(", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i34,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i35,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_args_4_0),
		mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i36,
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module1)
	init_entry(mercury__mercury_to_goedel__goedel_output_func_mode__ua10000_7_0);
BEGIN_CODE

/* code for predicate 'goedel_output_func_mode__ua10000'/7 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_func_mode__ua10000_7_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module2)
	init_entry(mercury__mercury_to_goedel__goedel_output_pred_mode__ua10000_6_0);
BEGIN_CODE

/* code for predicate 'goedel_output_pred_mode__ua10000'/6 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_pred_mode__ua10000_6_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module3)
	init_entry(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0);
	init_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i4);
BEGIN_CODE

/* code for predicate 'goedel_output_func__ua10000'/7 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0);
	incr_sp_push_msg(7, "goedel_output_func__ua10000");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__prog_util__split_types_and_modes_3_0);
	call_localret(ENTRY(mercury__prog_util__split_types_and_modes_3_0),
		mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__prog_util__split_type_and_mode_3_0);
	call_localret(ENTRY(mercury__prog_util__split_type_and_mode_3_0),
		mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i3,
		STATIC(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
	r4 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_0);
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_1);
	{
	Declare_entry(mercury__list__map_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module4)
	init_entry(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i8);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i14);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i17);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i18);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i19);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i20);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i21);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i22);
	init_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i23);
BEGIN_CODE

/* code for predicate 'goedel_output_pred__ua10000'/6 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0);
	incr_sp_push_msg(8, "goedel_output_pred__ua10000");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__prog_util__split_types_and_modes_3_0);
	call_localret(ENTRY(mercury__prog_util__split_types_and_modes_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i3,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	detstackvar(5) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	if (((Integer) detstackvar(2) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i5);
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r3 = (Integer) detstackvar(2);
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = string_const("PREDICATE    ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i8,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i12);
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_infix_pred_1_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i12);
	r1 = string_const(" : zPz", 6);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i16,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r2 = (Integer) r1;
	r1 = string_const(" : ", 3);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i17);
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i12);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r1 = string_const(" : ", 3);
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i17);
	detstackvar(1) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i18,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i19,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i20,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r3 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i23);
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i5);
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("PROPOSITION  ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i21,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	r3 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
Define_label(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0_i23);
	detstackvar(4) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module5)
	init_entry(mercury__mercury_to_goedel__goedel_output_mode_defn__ua10000_5_0);
BEGIN_CODE

/* code for predicate 'goedel_output_mode_defn__ua10000'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_mode_defn__ua10000_5_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module6)
	init_entry(mercury__mercury_to_goedel__goedel_output_inst_defn__ua10000_5_0);
BEGIN_CODE

/* code for predicate 'goedel_output_inst_defn__ua10000'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_inst_defn__ua10000_5_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module7)
	init_entry(mercury__mercury_to_goedel__LambdaGoal__1_2_0);
BEGIN_CODE

/* code for predicate 'mercury_to_goedel__LambdaGoal__1'/2 in mode 0 */
Define_static(mercury__mercury_to_goedel__LambdaGoal__1_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = string_const("", 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module8)
	init_entry(mercury__mercury_to_goedel__convert_to_goedel_4_0);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i2);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i3);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i4);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i5);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i6);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i7);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i8);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i12);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i13);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i14);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i18);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i19);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i20);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i21);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i22);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i23);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i24);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i25);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i26);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i27);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i15);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i29);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i30);
	init_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i33);
BEGIN_CODE

/* code for predicate 'convert_to_goedel'/4 in mode 0 */
Define_entry(mercury__mercury_to_goedel__convert_to_goedel_4_0);
	incr_sp_push_msg(6, "convert_to_goedel");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i2,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	detstackvar(3) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% Expanding equivalence types...", 32);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i3,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__flush_output_3_0);
	call_localret(ENTRY(mercury__io__flush_output_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i4,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i5,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i6,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(2), ((Integer) 3));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_2);
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	field(mktag(2), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) r5;
	field(mktag(3), (Integer) r4, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_3);
	{
	Declare_entry(mercury__equiv_type__expand_eqv_types_6_0);
	call_localret(ENTRY(mercury__equiv_type__expand_eqv_types_6_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i7,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(" done\n", 6);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i8,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	if (((Integer) detstackvar(4) != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0_i33);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i12,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	detstackvar(1) = (Integer) r1;
	r2 = string_const(".loc", 4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i13,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__io__tell_4_0);
	call_localret(ENTRY(mercury__io__tell_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i14,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0_i15);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) r2;
	r2 = string_const("% Writing output to ", 20);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i18,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i19,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("...\n", 4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i20,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = string_const("MODULE       ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i21,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i22,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i23,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i23);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = string_const("IMPORT       MercuryCompat.\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i24,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i25,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_item_list_3_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i26,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("% done\n", 7);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i27,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__told_2_0);
	tailcall(ENTRY(mercury__io__told_2_0),
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i15);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) r2;
	r2 = string_const("Error: couldn't open file `", 27);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i29,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i29);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_to_goedel__convert_to_goedel_4_0_i30,
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("' for output.\n", 14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		ENTRY(mercury__mercury_to_goedel__convert_to_goedel_4_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_goedel_4_0_i33);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module9)
	init_entry(mercury__mercury_to_goedel__goedel_output_item_list_3_0);
	init_label(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_item_list'/3 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_item_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i1002);
	incr_sp_push_msg(2, "goedel_output_item_list");
	detstackvar(2) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0),
		mercury__mercury_to_goedel__goedel_output_item_list_3_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_list_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_list_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__mercury_to_goedel__goedel_output_item_list_3_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_list_3_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_list_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module10)
	init_entry(mercury__mercury_to_goedel__goedel_output_item_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1023);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1022);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1021);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1020);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1008);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i14);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i15);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i17);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i18);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i19);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i25);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i26);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1019);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i28);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i30);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i29);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i32);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1013);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1014);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1016);
	init_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1017);
BEGIN_CODE

/* code for predicate 'goedel_output_item'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_item_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1019);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1023) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1013) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1014) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1008) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1022) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1021) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1016) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1017) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i1020));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1023);
	incr_sp_push_msg(7, "goedel_output_item");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i5);
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1022);
	incr_sp_push_msg(7, "goedel_output_item");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i13);
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1021);
	incr_sp_push_msg(7, "goedel_output_item");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i17);
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1020);
	incr_sp_push_msg(7, "goedel_output_item");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i25);
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i5);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = string_const("\n", 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i6,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1008);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i13);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = string_const("\n", 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i15,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_pred__ua10000_6_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i17);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = string_const("\n", 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i18,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i19,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_func__ua10000_7_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i25);
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i26,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r3 = (Integer) r2;
	r2 = string_const("warning: C header declarations not allowed. Ignoring\n", 53);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_4_0);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1019);
	incr_sp_push_msg(7, "goedel_output_item");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i28);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i28);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0_i29);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i30,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i29);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0),
		mercury__mercury_to_goedel__goedel_output_item_4_0_i32,
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i32);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_item_4_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1013);
	r1 = (Integer) r3;
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_inst_defn__ua10000_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1014);
	r1 = (Integer) r3;
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_mode_defn__ua10000_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1016);
	r1 = (Integer) r3;
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_pred_mode__ua10000_6_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_item_4_0_i1017);
	r1 = (Integer) r3;
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_func_mode__ua10000_7_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_item_4_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module11)
	init_entry(mercury__mercury_to_goedel__goedel_output_type_defn_5_0);
BEGIN_CODE

/* code for predicate 'goedel_output_type_defn'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_type_defn_5_0);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module12)
	init_entry(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i14);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i15);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i17);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i18);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i19);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i20);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i21);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i22);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i23);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i24);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i25);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i26);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i27);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i28);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i29);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i7);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i34);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i35);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i36);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i37);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i38);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i33);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i40);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i41);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i42);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i43);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i39);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i46);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i47);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i48);
BEGIN_CODE

/* code for predicate 'goedel_output_type_defn_2'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0);
	incr_sp_push_msg(10, "goedel_output_type_defn_2");
	detstackvar(10) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	detstackvar(6) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i6,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	if ((strcmp((char *)(Integer) detstackvar(6), (char *)string_const("character", 9)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i7);
	r2 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	r1 = string_const("Type__", 6);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	detstackvar(8) = (Integer) r1;
	r2 = string_const(".exp", 4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i11,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = string_const(".loc", 4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i12,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__output_stream_3_0);
	call_localret(ENTRY(mercury__io__output_stream_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i13,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r3 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__tell_4_0);
	call_localret(ENTRY(mercury__io__tell_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r1 = string_const("EXPORT       ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i15,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i16,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i17,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("IMPORT       MercuryCompat.\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i18,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i19,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i20,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	{
	Declare_entry(mercury__io__told_2_0);
	call_localret(ENTRY(mercury__io__told_2_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i21,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__tell_4_0);
	call_localret(ENTRY(mercury__io__tell_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r1 = string_const("LOCAL       ", 12);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i23,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i24,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i25,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	{
	Declare_entry(mercury__io__told_2_0);
	call_localret(ENTRY(mercury__io__told_2_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i26,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i27,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r1 = string_const("IMPORT       ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i28,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i29,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i29);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i7);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i4);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i33);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i34,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i35,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i36,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("warning: undiscriminated union types not yet supported.\n", 56);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i37,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i37);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i38,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i38);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i33);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i39);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i40,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i40);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i41,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i41);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i42,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i42);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("mercury_to_goedel internal error:\n", 34);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i43,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i43);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("equivalence type unexpected.\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i37,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i39);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i46,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i46);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i47,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i47);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i48,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i48);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("warning: abstract type definition ignored.\n", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0_i37,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_2_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module13)
	init_entry(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i7);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i8);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i14);
BEGIN_CODE

/* code for predicate 'goedel_output_type_defn_3'/8 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0);
	incr_sp_push_msg(8, "goedel_output_type_defn_3");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r6;
	r2 = (Integer) r7;
	call_localret(STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i3,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i4);
	r1 = string_const("BASE         ", 13);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i7,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i8,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i13);
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i4);
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = string_const("CONSTRUCTOR  ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	r2 = (Integer) r1;
	r1 = string_const("/", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i11,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i12,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i13);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r4 = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_defn_3_8_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module14)
	init_entry(mercury__mercury_to_goedel__goedel_output_ctors_5_0);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i15);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i17);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i22);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i18);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i26);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i24);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i31);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i32);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i33);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i34);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i35);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i36);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i37);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i38);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i39);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i40);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i41);
	init_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i1000);
BEGIN_CODE

/* code for predicate 'goedel_output_ctors'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_ctors_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i1000);
	incr_sp_push_msg(9, "goedel_output_ctors");
	detstackvar(9) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	detstackvar(6) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	if (((Integer) detstackvar(4) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i6);
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	r1 = string_const("FUNCTION     ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_0);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i11,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i12);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_infix_op_1_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i15,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i13);
	r1 = string_const(" : xFx(100)", 11);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i17,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r2 = (Integer) r1;
	r1 = string_const(" : ", 3);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i31);
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i13);
	r1 = (Integer) detstackvar(3);
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i12);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i18);
	if ((strcmp((char *)(Integer) detstackvar(6), (char *)string_const("-", 1)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i18);
	r1 = string_const(" : Fx(100)", 10);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r2 = (Integer) r1;
	r1 = string_const(" : ", 3);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i31);
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i18);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i24);
	{
	Declare_entry(mercury__std_util__semidet_fail_0_0);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i26,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i24);
	r1 = string_const(" : xF(100)", 10);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i24);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(4);
	r1 = string_const(" : ", 3);
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i31);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i32,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i32);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i33,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i33);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i34,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" -> ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i35,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i39);
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i6);
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("CONSTANT     ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i36,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i37,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i37);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" : ", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i38,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i38);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i39);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(5) = (Integer) r4;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i40,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i40);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_ctors_5_0_i41,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i41);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__mercury_to_goedel__goedel_output_ctors_5_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_ctors_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_ctors_5_0_i1000);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module15)
	init_entry(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_remaining_ctor_args'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i1002);
	incr_sp_push_msg(4, "goedel_output_remaining_ctor_args");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const(" * ", 3);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0),
		mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_remaining_ctor_args_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module16)
	init_entry(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_remaining_types'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i1002);
	incr_sp_push_msg(4, "goedel_output_remaining_types");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const(" * ", 3);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0),
		mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_remaining_types_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module17)
	init_entry(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0);
	init_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i10);
BEGIN_CODE

/* code for predicate 'goedel_output_pred_clause'/7 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0);
	incr_sp_push_msg(6, "goedel_output_pred_clause");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i3,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
Define_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i6,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i5);
	if (((Integer) detstackvar(4) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i5);
	r2 = (Integer) detstackvar(2);
	r1 = string_const(".\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i5);
	r1 = string_const(" <-\n\t", 5);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
Define_label(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_pred_clause_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module18)
	init_entry(mercury__mercury_to_goedel__goedel_output_func_clause_8_0);
	init_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i10);
BEGIN_CODE

/* code for predicate 'goedel_output_func_clause'/8 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_func_clause_8_0);
	incr_sp_push_msg(7, "goedel_output_func_clause");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_4);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r4, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i3,
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i6,
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i5);
	if (((Integer) detstackvar(3) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i5);
	r2 = (Integer) detstackvar(2);
	r1 = string_const(".\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i5);
	r1 = string_const(" <-\n\t", 5);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
Define_label(mercury__mercury_to_goedel__goedel_output_func_clause_8_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_func_clause_8_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module19)
	init_entry(mercury__mercury_to_goedel__goedel_output_goal_5_0);
BEGIN_CODE

/* code for predicate 'goedel_output_goal'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_goal_5_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module20)
	init_entry(mercury__mercury_to_goedel__goedel_output_goal_2_5_0);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1016);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1015);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1014);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1013);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1012);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1011);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1010);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1009);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1008);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i7);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i8);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i17);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i18);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i19);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i20);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i21);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i24);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i25);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i29);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i30);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i31);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i32);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i33);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i34);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i37);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i38);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i39);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i41);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i42);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i43);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i44);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i45);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i46);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i47);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i48);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i49);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i50);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i52);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i53);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i54);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i55);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i56);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i57);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i58);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i59);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i60);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i61);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i62);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i63);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i64);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i65);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i67);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i68);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i69);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i71);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i72);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i73);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1007);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i75);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i80);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i81);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i82);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i79);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i84);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i85);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i86);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i87);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i88);
	init_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1005);
BEGIN_CODE

/* code for predicate 'goedel_output_goal_2'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1007);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1016) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1015) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1014) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1013) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1012) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1011) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1010) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1009) AND
		LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1008));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1016);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i5);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1015);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i11);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1014);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i24);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1013);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i37);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1012);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i39);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1011);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i41);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1010);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i52);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1009);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i67);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1008);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i71);
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i5);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = string_const("(~", 2);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i6,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i7,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i8,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i11);
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i12);
	r1 = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	r1 = string_const("(SOME [", 7);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i16,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_vars_4_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i17,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("] ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i18,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i19,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i20,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i21,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i24);
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i25);
	r1 = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i25);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	r1 = string_const("(ALL [", 6);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i29,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i29);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_vars_4_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i30,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("] ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i31,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i32,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i32);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i33,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i33);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i34,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i37);
	detstackvar(1) = (Integer) r4;
	r1 = string_const("mercury_to_goedel: implies/2 in goedel_output_goal", 50);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i38,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i38);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i39);
	detstackvar(1) = (Integer) r4;
	r1 = string_const("mercury_to_goedel: equivalent/2 in goedel_output_goal", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i38,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i41);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = string_const("(IF", 3);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i42,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i42);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_some_4_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i43,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i43);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i44,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i44);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i45,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i45);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i46,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i46);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("THEN", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i47,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i47);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i48,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i48);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i49,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i49);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i50,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i50);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i52);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = string_const("(IF", 3);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i53,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i53);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_some_4_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i54,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i54);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i55,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i55);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i56,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i56);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i57,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i57);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("THEN", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i58,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i58);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i59,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i59);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i60,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i60);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i61,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i61);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const("ELSE", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i62,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i62);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i63,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i63);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i64,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i64);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i65,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i65);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i67);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i68,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i68);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i69,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i69);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_call__ua10000_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i71);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i72,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i72);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" = ", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i73,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i73);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1007);
	incr_sp_push_msg(7, "goedel_output_goal_2");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i75);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if ((unmkbody((Integer) r1) != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1005);
	r1 = string_const("True", 4);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i75);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i79);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i80,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i80);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" &", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i81,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i81);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i82,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i82);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i79);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = string_const("(", 1);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i84,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i84);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	detstackvar(5) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i85,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i85);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i86,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i86);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i87,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i87);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i88,
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i88);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_goal_2_5_0_i1005);
	r1 = string_const("False", 5);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_goal_2_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module21)
	init_entry(mercury__mercury_to_goedel__goedel_output_disj_5_0);
	init_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i8);
	init_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i5);
BEGIN_CODE

/* code for predicate 'goedel_output_disj'/5 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_disj_5_0);
	incr_sp_push_msg(5, "goedel_output_disj");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_disj_5_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_disj_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\\/", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_disj_5_0_i3,
		STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_disj_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(3) + ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0),
		mercury__mercury_to_goedel__goedel_output_disj_5_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_disj_5_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_disj_5_0_i5);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	r4 = (Integer) r1;
	r1 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		mercury__mercury_to_goedel__goedel_output_disj_5_0_i8,
		STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_disj_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__mercury_to_goedel__goedel_output_disj_5_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0));
Define_label(mercury__mercury_to_goedel__goedel_output_disj_5_0_i5);
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_goal_5_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_disj_5_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module22)
	init_entry(mercury__mercury_to_goedel__goedel_output_some_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i1001);
	init_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i6);
BEGIN_CODE

/* code for predicate 'goedel_output_some'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_some_4_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_some_4_0_i1001);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i1001);
	incr_sp_push_msg(3, "goedel_output_some");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = string_const(" SOME [", 7);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_some_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_some_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_some_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_vars_4_0),
		mercury__mercury_to_goedel__goedel_output_some_4_0_i6,
		STATIC(mercury__mercury_to_goedel__goedel_output_some_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_some_4_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_some_4_0));
	r2 = (Integer) r1;
	r1 = string_const("]", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_some_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module23)
	init_entry(mercury__mercury_to_goedel__goedel_convert_expression_2_0);
	init_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
BEGIN_CODE

/* code for predicate 'goedel_convert_expression'/2 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_convert_expression_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
	incr_sp_push_msg(4, "goedel_convert_expression");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	localcall(mercury__mercury_to_goedel__goedel_convert_expression_2_0,
		LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i9),
		STATIC(mercury__mercury_to_goedel__goedel_convert_expression_2_0));
Define_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__mercury_to_goedel__goedel_convert_expression_2_0,
		LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i10),
		STATIC(mercury__mercury_to_goedel__goedel_convert_expression_2_0));
Define_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0));
	if ((strcmp((char *)(Integer) detstackvar(1), (char *)string_const("//", 2)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i11);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i11);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__mercury_to_goedel__goedel_convert_expression_2_0_i1013);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module24)
	init_entry(mercury__mercury_to_goedel__goedel_output_newline_3_0);
	init_label(mercury__mercury_to_goedel__goedel_output_newline_3_0_i2);
BEGIN_CODE

/* code for predicate 'goedel_output_newline'/3 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_newline_3_0);
	incr_sp_push_msg(2, "goedel_output_newline");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_newline_3_0_i2,
		STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_newline_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_newline_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_tabs_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_newline_3_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module25)
	init_entry(mercury__mercury_to_goedel__goedel_output_tabs_3_0);
	init_label(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i1000);
	init_label(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i5);
BEGIN_CODE

/* code for predicate 'goedel_output_tabs'/3 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_tabs_3_0);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i1000);
	incr_sp_push_msg(2, "goedel_output_tabs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\t", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_tabs_3_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_tabs_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_tabs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_tabs_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) - ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__mercury_to_goedel__goedel_output_tabs_3_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_tabs_3_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module26)
	init_entry(mercury__mercury_to_goedel__goedel_output_list_args_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	init_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i19);
BEGIN_CODE

/* code for predicate 'goedel_output_list_args'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_list_args_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r4, ((Integer) 0)), (char *)string_const(".", 1)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	if (((Integer) field(mktag(1), (Integer) r4, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	incr_sp_push_msg(4, "goedel_output_list_args");
	detstackvar(4) = (Integer) succip;
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i2);
	detstackvar(2) = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	r1 = string_const(", ", 2);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_list_args_4_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_list_args_4_0_i11,
		STATIC(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_output_list_args_4_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i1000);
	incr_sp_push_msg(4, "goedel_output_list_args");
	detstackvar(4) = (Integer) succip;
Define_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i2);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r4, ((Integer) 0)), (char *)string_const("[]", 2)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r4 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i13);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = string_const(" | ", 3);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_list_args_4_0_i19,
		STATIC(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_list_args_4_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_list_args_4_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module27)
	init_entry(mercury__mercury_to_goedel__goedel_output_term_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i1006);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i14);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i22);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i23);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i24);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i25);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i32);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i34);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i35);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i36);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i37);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i28);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i27);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i45);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i47);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i48);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i49);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i50);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i51);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i52);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i40);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i54);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i58);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i59);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i60);
	init_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i2);
BEGIN_CODE

/* code for predicate 'goedel_output_term'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_term_4_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i1006);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i1006);
	incr_sp_push_msg(7, "goedel_output_term");
	detstackvar(7) = (Integer) succip;
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	r6 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	if ((strcmp((char *)(Integer) r6, (char *)string_const(".", 1)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	r6 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) r6 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	if (((Integer) field(mktag(1), (Integer) r6, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r6, ((Integer) 0));
	r1 = string_const("[", 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i12,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_term_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i13),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_list_args_4_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const("]", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i5);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
	r1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
	r1 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	if ((strcmp((char *)(Integer) r1, (char *)string_const("-", 1)) !=0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r5;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	r1 = string_const("(", 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i23,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i23);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i24,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_term_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i25),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i16);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i27);
	r1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i27);
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i27);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	{
	Declare_entry(mercury__std_util__semidet_fail_0_0);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i32,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i32);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i28);
	r1 = string_const("(", 1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i34,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_term_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i35),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i36,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i37,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i37);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i28);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i27);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
	r1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_infix_op_1_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i45,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i45);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i40);
	r1 = string_const("(", 1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i47,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i47);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_term_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i48),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i48);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i49,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i49);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i50,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i50);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i51,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i51);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_term_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i52),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i52);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i40);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i39);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r5;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i54,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i54);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	if (((Integer) detstackvar(4) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i2);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = string_const("(", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i58,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i58);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_term_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0_i59),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i59);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_args_4_0),
		mercury__mercury_to_goedel__goedel_output_term_4_0_i60,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i60);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_4_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_4_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module28)
	init_entry(mercury__mercury_to_goedel__goedel_output_term_args_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_term_args'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_term_args_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i1002);
	incr_sp_push_msg(4, "goedel_output_term_args");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const(", ", 2);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_term_args_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_args_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_term_4_0),
		mercury__mercury_to_goedel__goedel_output_term_args_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_term_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_output_term_args_4_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_term_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_term_args_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module29)
	init_entry(mercury__mercury_to_goedel__goedel_output_constant_3_0);
	init_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i7);
	init_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i9);
BEGIN_CODE

/* code for predicate 'goedel_output_constant'/3 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_constant_3_0);
	r3 = tag((Integer) r1);
	incr_sp_push_msg(2, "goedel_output_constant");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_constant_3_0_i4);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0),
		mercury__mercury_to_goedel__goedel_output_constant_3_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
Define_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_constant_3_0_i7);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_int_3_0);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i7);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_constant_3_0_i9);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = string_const("\"", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_constant_3_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0),
		mercury__mercury_to_goedel__goedel_output_constant_3_0_i11,
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
Define_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\"", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_constant_3_0_i9);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_float_3_0);
	tailcall(ENTRY(mercury__io__write_float_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module30)
	init_entry(mercury__mercury_to_goedel__goedel_quote_string_3_0);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i14);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i15);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i6);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i3);
BEGIN_CODE

/* code for predicate 'goedel_quote_string'/3 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_quote_string_3_0);
	incr_sp_push_msg(4, "goedel_quote_string");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__string__first_char_3_3);
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__mercury_to_goedel__goedel_quote_string_3_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i3);
	if (((Integer) r2 != ((Integer) 8)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i9);
	r2 = (Integer) detstackvar(1);
	r4 = ((Integer) 98);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i9);
	if (((Integer) r2 != ((Integer) 9)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i10);
	r2 = (Integer) detstackvar(1);
	r4 = ((Integer) 116);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i10);
	if (((Integer) r2 != ((Integer) 10)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i11);
	r2 = (Integer) detstackvar(1);
	r4 = ((Integer) 110);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i11);
	if (((Integer) r2 != ((Integer) 34)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i12);
	r2 = (Integer) detstackvar(1);
	r4 = ((Integer) 34);
	GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i12);
	if (((Integer) r2 != ((Integer) 92)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0_i6);
	r2 = (Integer) detstackvar(1);
	r4 = ((Integer) 92);
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i8);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r1 = ((Integer) 92);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_goedel__goedel_quote_string_3_0_i14,
		STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_goedel__goedel_quote_string_3_0_i15,
		STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_quote_string_3_0,
		STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0));
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i6);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_goedel__goedel_quote_string_3_0_i16,
		STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_quote_string_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_quote_string_3_0,
		STATIC(mercury__mercury_to_goedel__goedel_quote_string_3_0));
Define_label(mercury__mercury_to_goedel__goedel_quote_string_3_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module31)
	init_entry(mercury__mercury_to_goedel__goedel_output_vars_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_vars_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_vars_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_vars'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_vars_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_vars_4_0_i1002);
	incr_sp_push_msg(3, "goedel_output_vars");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0),
		mercury__mercury_to_goedel__goedel_output_vars_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_vars_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_vars_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_vars_2_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_vars_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_vars_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module32)
	init_entry(mercury__mercury_to_goedel__goedel_output_vars_2_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_vars_2'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_vars_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i1002);
	incr_sp_push_msg(4, "goedel_output_vars_2");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const(", ", 2);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_vars_2_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_vars_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0),
		mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_vars_2_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_vars_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_output_vars_2_4_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_vars_2_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_vars_2_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module33)
	init_entry(mercury__mercury_to_goedel__goedel_output_var_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i8);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i7);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i13);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i12);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i16);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i20);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i21);
	init_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i22);
BEGIN_CODE

/* code for predicate 'goedel_output_var'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_var_4_0);
	incr_sp_push_msg(4, "goedel_output_var");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__varset__search_name_3_0);
	call_localret(ENTRY(mercury__varset__search_name_3_0),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0_i3);
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) r2;
	r2 = string_const("_", 1);
	{
	Declare_entry(mercury__string__prefix_2_0);
	call_localret(ENTRY(mercury__string__prefix_2_0),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i8,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0_i7);
	r1 = string_const("v_", 2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i7);
	r1 = (Integer) detstackvar(3);
	r2 = string_const("V_", 2);
	{
	Declare_entry(mercury__string__prefix_2_0);
	call_localret(ENTRY(mercury__string__prefix_2_0),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i13,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0_i12);
	r1 = string_const("v_", 2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i10,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i12);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__uncapitalize_first_2_0);
	call_localret(ENTRY(mercury__string__uncapitalize_first_2_0),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i16,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i3);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__term__var_to_int_2_0);
	call_localret(ENTRY(mercury__term__var_to_int_2_0),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i20,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i21,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	r2 = (Integer) r1;
	r1 = string_const("v_", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__goedel_output_var_4_0_i22,
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_var_4_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_var_4_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module34)
	init_entry(mercury__mercury_to_goedel__goedel_output_type_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i1002);
	init_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i9);
	init_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i10);
	init_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i11);
	init_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i2);
BEGIN_CODE

/* code for predicate 'goedel_output_type'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_type_4_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__mercury_to_goedel__goedel_output_var_4_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i1002);
	incr_sp_push_msg(4, "goedel_output_type");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_constant_3_0),
		mercury__mercury_to_goedel__goedel_output_type_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0));
	if (((Integer) detstackvar(2) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0_i2);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = string_const("(", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_4_0_i9,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__mercury_to_goedel__goedel_output_type_4_0,
		LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0_i10),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_type_args_4_0),
		mercury__mercury_to_goedel__goedel_output_type_4_0_i11,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_4_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_4_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module35)
	init_entry(mercury__mercury_to_goedel__goedel_output_type_args_4_0);
	init_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i4);
	init_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goedel_output_type_args'/4 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_output_type_args_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i1002);
	incr_sp_push_msg(4, "goedel_output_type_args");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const(", ", 2);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__goedel_output_type_args_4_0_i4,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_args_4_0));
	}
Define_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__goedel_output_type_4_0),
		mercury__mercury_to_goedel__goedel_output_type_args_4_0_i5,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__goedel_output_type_args_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__mercury_to_goedel__goedel_output_type_args_4_0,
		STATIC(mercury__mercury_to_goedel__goedel_output_type_args_4_0));
Define_label(mercury__mercury_to_goedel__goedel_output_type_args_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module36)
	init_entry(mercury__mercury_to_goedel__goedel_infix_op_1_0);
	init_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1000);
	init_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1);
BEGIN_CODE

/* code for predicate 'goedel_infix_op'/1 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_infix_op_1_0);
	r2 = (hash_string((Integer) r1) & ((Integer) 31));
Define_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i3);
	r3 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_6))[(Integer) r2];
	if (!((Integer) r3))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1000);
	if ((strcmp((char *)(Integer) r3, (char *)(Integer) r1) ==0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i5);
Define_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1000);
	r2 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_7))[(Integer) r2];
	if (((Integer) r2 >= ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i3);
	r1 = FALSE;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i5);
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2));
Define_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_infix_op_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module37)
	init_entry(mercury__mercury_to_goedel__goedel_infix_pred_1_0);
	init_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i3);
	init_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1000);
	init_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i5);
	init_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2);
	init_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1);
BEGIN_CODE

/* code for predicate 'goedel_infix_pred'/1 in mode 0 */
Define_static(mercury__mercury_to_goedel__goedel_infix_pred_1_0);
	r2 = (hash_string((Integer) r1) & ((Integer) 15));
Define_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i3);
	r3 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_8))[(Integer) r2];
	if (!((Integer) r3))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1000);
	if ((strcmp((char *)(Integer) r3, (char *)(Integer) r1) ==0))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i5);
Define_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1000);
	r2 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_9))[(Integer) r2];
	if (((Integer) r2 >= ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i3);
	r1 = FALSE;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i5);
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1) AND
		LABEL(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2));
Define_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__mercury_to_goedel__goedel_infix_pred_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module38)
	init_entry(mercury__mercury_to_goedel__convert_functor_name_2_0);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i4);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i6);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i8);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i10);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i13);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i12);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i3);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i19);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i21);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i18);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i27);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i1006);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i29);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i30);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i31);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i32);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i33);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i34);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i35);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i36);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i37);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i38);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i39);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i40);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i41);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i42);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i43);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i44);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i45);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i46);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i47);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i48);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i49);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i50);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i51);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i52);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i24);
	init_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i53);
BEGIN_CODE

/* code for predicate 'convert_functor_name'/2 in mode 0 */
Define_static(mercury__mercury_to_goedel__convert_functor_name_2_0);
	incr_sp_push_msg(3, "convert_functor_name");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__string__first_char_3_3);
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i4,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i3);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__char__is_lower_1_0);
	call_localret(ENTRY(mercury__char__is_lower_1_0),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i6,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i3);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__is_alnum_or_underscore_1_0);
	call_localret(ENTRY(mercury__string__is_alnum_or_underscore_1_0),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i8,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i3);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__string__capitalize_first_2_0);
	call_localret(ENTRY(mercury__string__capitalize_first_2_0),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i10,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = string_const("F_", 2);
	{
	Declare_entry(mercury__string__append_3_1);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i13,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i12);
	r1 = string_const("F__", 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i12);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = string_const("", 0);
	{
	Declare_entry(mercury__string__first_char_3_1);
	call_localret(ENTRY(mercury__string__first_char_3_1),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i19,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i18);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__char__is_upper_1_0);
	call_localret(ENTRY(mercury__char__is_upper_1_0),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i21,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i18);
	r1 = string_const("F_", 2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i18);
	r1 = (hash_string((Integer) detstackvar(1)) & ((Integer) 63));
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i27);
	r2 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_10))[(Integer) r1];
	if (!((Integer) r2))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i1006);
	if ((strcmp((char *)(Integer) r2, (char *)(Integer) detstackvar(1)) ==0))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i29);
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i1006);
	r1 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_goedel__common_11))[(Integer) r1];
	if (((Integer) r1 >= ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i27);
	GOTO_LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24);
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i29);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i30) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i31) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i32) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i33) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i34) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i35) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i36) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i37) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i38) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i39) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i40) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i41) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i42) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i43) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i44) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i45) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i46) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i47) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i48) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i49) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i50) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i51) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i24) AND
		LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0_i52));
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i30);
	r1 = string_const(">=", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i31);
	r1 = string_const("=<", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i32);
	r1 = string_const("~=", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i33);
	r1 = string_const("[]", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i34);
	r1 = string_const("+", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i35);
	r1 = string_const("*", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i36);
	r1 = string_const("-", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i37);
	r1 = string_const("F_Comma", 7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i38);
	r1 = string_const("/", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i39);
	r1 = string_const("F_Digit_1", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i40);
	r1 = string_const("F_Digit_0", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i41);
	r1 = string_const("F_Digit_3", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i42);
	r1 = string_const("F_Digit_2", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i43);
	r1 = string_const("F_Digit_5", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i44);
	r1 = string_const("F_Digit_4", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i45);
	r1 = string_const("F_Digit_7", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i46);
	r1 = string_const("F_Digit_6", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i47);
	r1 = string_const("F_Digit_9", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i48);
	r1 = string_const("F_Digit_8", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i49);
	r1 = string_const("F_Semicolon", 11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i50);
	r1 = string_const("=", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i51);
	r1 = string_const("<", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i52);
	r1 = string_const(">", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i24);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0),
		mercury__mercury_to_goedel__convert_functor_name_2_0_i53,
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
Define_label(mercury__mercury_to_goedel__convert_functor_name_2_0_i53);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_functor_name_2_0));
	r2 = (Integer) r1;
	r1 = string_const("F", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__mercury_to_goedel__convert_functor_name_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module39)
	init_entry(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0);
	init_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i4);
	init_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i6);
	init_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i7);
	init_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i8);
	init_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i9);
	init_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i3);
BEGIN_CODE

/* code for predicate 'convert_to_valid_functor_name_2'/2 in mode 0 */
Define_static(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0);
	incr_sp_push_msg(3, "convert_to_valid_functor_name_2");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__string__first_char_3_3);
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i4,
		STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i3);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__char__to_int_2_0);
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i6,
		STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i7,
		STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	r2 = (Integer) r1;
	r1 = string_const("_", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i8,
		STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0,
		LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i9),
		STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
Define_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0));
	}
Define_label(mercury__mercury_to_goedel__convert_to_valid_functor_name_2_2_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_goedel_module40)
	init_entry(mercury__mercury_to_goedel__maybe_write_line_number_3_0);
	init_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i2);
	init_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i6);
	init_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i7);
	init_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_write_line_number'/3 in mode 0 */
Define_static(mercury__mercury_to_goedel__maybe_write_line_number_3_0);
	incr_sp_push_msg(2, "maybe_write_line_number");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 34);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__mercury_to_goedel__maybe_write_line_number_3_0_i2,
		STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	}
Define_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i3);
	r1 = string_const("\t% ", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_goedel__maybe_write_line_number_3_0_i6,
		STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	}
Define_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__mercury_to_goedel__maybe_write_line_number_3_0_i7,
		STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	}
Define_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_goedel__maybe_write_line_number_3_0));
	}
Define_label(mercury__mercury_to_goedel__maybe_write_line_number_3_0_i3);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__mercury_to_goedel_bunch_0(void)
{
	mercury__mercury_to_goedel_module0();
	mercury__mercury_to_goedel_module1();
	mercury__mercury_to_goedel_module2();
	mercury__mercury_to_goedel_module3();
	mercury__mercury_to_goedel_module4();
	mercury__mercury_to_goedel_module5();
	mercury__mercury_to_goedel_module6();
	mercury__mercury_to_goedel_module7();
	mercury__mercury_to_goedel_module8();
	mercury__mercury_to_goedel_module9();
	mercury__mercury_to_goedel_module10();
	mercury__mercury_to_goedel_module11();
	mercury__mercury_to_goedel_module12();
	mercury__mercury_to_goedel_module13();
	mercury__mercury_to_goedel_module14();
	mercury__mercury_to_goedel_module15();
	mercury__mercury_to_goedel_module16();
	mercury__mercury_to_goedel_module17();
	mercury__mercury_to_goedel_module18();
	mercury__mercury_to_goedel_module19();
	mercury__mercury_to_goedel_module20();
	mercury__mercury_to_goedel_module21();
	mercury__mercury_to_goedel_module22();
	mercury__mercury_to_goedel_module23();
	mercury__mercury_to_goedel_module24();
	mercury__mercury_to_goedel_module25();
	mercury__mercury_to_goedel_module26();
	mercury__mercury_to_goedel_module27();
	mercury__mercury_to_goedel_module28();
	mercury__mercury_to_goedel_module29();
	mercury__mercury_to_goedel_module30();
	mercury__mercury_to_goedel_module31();
	mercury__mercury_to_goedel_module32();
	mercury__mercury_to_goedel_module33();
	mercury__mercury_to_goedel_module34();
	mercury__mercury_to_goedel_module35();
	mercury__mercury_to_goedel_module36();
	mercury__mercury_to_goedel_module37();
	mercury__mercury_to_goedel_module38();
	mercury__mercury_to_goedel_module39();
	mercury__mercury_to_goedel_module40();
}

#endif

void mercury__mercury_to_goedel__init(void); /* suppress gcc warning */
void mercury__mercury_to_goedel__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__mercury_to_goedel_bunch_0();
#endif
}
