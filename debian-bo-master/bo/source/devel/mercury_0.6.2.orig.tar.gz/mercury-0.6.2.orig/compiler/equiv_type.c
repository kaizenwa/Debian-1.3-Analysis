/*
** Automatically generated from `equiv_type.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__equiv_type__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___equiv_type_eqv_type_body_0__ua10000_2_0);
Define_extern_entry(mercury__equiv_type__expand_eqv_types_6_0);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i2);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i3);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i4);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i5);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i6);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i9);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i10);
Define_extern_entry(mercury__equiv_type__replace_in_type_5_0);
Declare_static(mercury__equiv_type__build_eqv_map_3_0);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i8);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i9);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i1006);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i1008);
Declare_static(mercury__equiv_type__replace_in_item_list_5_0);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1052);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1051);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1048);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1047);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i9);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i13);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i12);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i15);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i14);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i17);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i18);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i19);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i20);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i21);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i22);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i23);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i6);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1041);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1043);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i28);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i29);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i1022);
Declare_static(mercury__equiv_type__replace_in_du_5_0);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i5);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i1003);
Declare_static(mercury__equiv_type__replace_in_type_list_2_8_0);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i4);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i5);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i6);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i1002);
Declare_static(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i1003);
Declare_static(mercury__equiv_type__replace_in_type_2_7_0);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i1000);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i6);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i8);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i11);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i10);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i13);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i16);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i18);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i22);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i23);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i15);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i25);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i26);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i5);
Declare_static(mercury__equiv_type__replace_in_tms_5_0);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i5);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i1002);
Declare_static(mercury__equiv_type__replace_in_tm_5_0);
Declare_label(mercury__equiv_type__replace_in_tm_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_tm_5_0_i3);
Declare_label(mercury__equiv_type__replace_in_tm_5_0_i5);
Declare_static(mercury__equiv_type__report_circular_types_3_0);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i8);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i9);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i10);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i11);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i12);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i13);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i14);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i1005);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i1007);
Define_extern_entry(mercury____Unify___equiv_type__eqv_map_0_0);
Define_extern_entry(mercury____Index___equiv_type__eqv_map_0_0);
Define_extern_entry(mercury____Compare___equiv_type__eqv_map_0_0);
Declare_static(mercury____Unify___equiv_type__eqv_type_body_0_0);
Declare_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i2);
Declare_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i4);
Declare_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
Declare_static(mercury____Index___equiv_type__eqv_type_body_0_0);
Declare_static(mercury____Compare___equiv_type__eqv_type_body_0_0);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i4);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i5);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i10);

extern Word * mercury_data_equiv_type__base_type_layout_eqv_map_0[];
Word * mercury_data_equiv_type__base_type_info_eqv_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___equiv_type__eqv_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___equiv_type__eqv_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___equiv_type__eqv_map_0_0),
	(Word *) (Integer) mercury_data_equiv_type__base_type_layout_eqv_map_0
};

extern Word * mercury_data_equiv_type__base_type_layout_eqv_type_body_0[];
Word * mercury_data_equiv_type__base_type_info_eqv_type_body_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0),
	(Word *) (Integer) STATIC(mercury____Index___equiv_type__eqv_type_body_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0),
	(Word *) (Integer) mercury_data_equiv_type__base_type_layout_eqv_type_body_0
};

extern Word * mercury_data_equiv_type__common_5[];
Word * mercury_data_equiv_type__base_type_layout_eqv_type_body_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_equiv_type__common_5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_equiv_type__common_7[];
Word * mercury_data_equiv_type__base_type_layout_eqv_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_equiv_type__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_equiv_type__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_equiv_type__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_equiv_type__common_7)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_equiv_type__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_prog_data__base_type_info_item_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_equiv_type__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_item_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_equiv_type__common_2[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_equiv_type__common_3[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_equiv_type__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_equiv_type__common_5[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_4),
	(Word *) string_const("eqv_type_body", 13)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_equiv_type__common_6[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0),
	(Word *) (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0
};

Word * mercury_data_equiv_type__common_7[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_6)
};

BEGIN_MODULE(mercury__equiv_type_module0)
	init_entry(mercury____Index___equiv_type_eqv_type_body_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___equiv_type_eqv_type_body_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___equiv_type_eqv_type_body_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module1)
	init_entry(mercury__equiv_type__expand_eqv_types_6_0);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i2);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i3);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i4);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i5);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i6);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i9);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i10);
BEGIN_CODE

/* code for predicate 'equiv_type__expand_eqv_types'/6 in mode 0 */
Define_entry(mercury__equiv_type__expand_eqv_types_6_0);
	incr_sp_push_msg(4, "equiv_type__expand_eqv_types");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	r2 = (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__equiv_type__expand_eqv_types_6_0_i2,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
	}
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i2);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__equiv_type__build_eqv_map_3_0),
		mercury__equiv_type__expand_eqv_types_6_0_i3,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i3);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__equiv_type__replace_in_item_list_5_0),
		mercury__equiv_type__expand_eqv_types_6_0_i4,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__equiv_type__expand_eqv_types_6_0_i5,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
	}
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__expand_eqv_types_6_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i6);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__equiv_type__report_circular_types_3_0),
		mercury__equiv_type__expand_eqv_types_6_0_i9,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__equiv_type__expand_eqv_types_6_0_i10,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
	}
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module2)
	init_entry(mercury__equiv_type__replace_in_type_5_0);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_type'/5 in mode 0 */
Define_entry(mercury__equiv_type__replace_in_type_5_0);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		ENTRY(mercury__equiv_type__replace_in_type_5_0));
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module3)
	init_entry(mercury__equiv_type__build_eqv_map_3_0);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i8);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i9);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i1006);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i1008);
BEGIN_CODE

/* code for predicate 'equiv_type__build_eqv_map'/3 in mode 0 */
Define_static(mercury__equiv_type__build_eqv_map_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i1006);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i1008);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i1008);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i1008);
	incr_sp_push_msg(7, "equiv_type__build_eqv_map");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	tempr1 = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 2));
	r2 = (Integer) field(mktag(2), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) tempr1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__equiv_type__build_eqv_map_3_0_i8,
		STATIC(mercury__equiv_type__build_eqv_map_3_0));
	}
	}
Define_label(mercury__equiv_type__build_eqv_map_3_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__build_eqv_map_3_0));
	r2 = (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0;
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	tag_incr_hp(r5, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r5, ((Integer) 2)) = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__equiv_type__build_eqv_map_3_0_i9,
		STATIC(mercury__equiv_type__build_eqv_map_3_0));
	}
Define_label(mercury__equiv_type__build_eqv_map_3_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__build_eqv_map_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__equiv_type__build_eqv_map_3_0,
		STATIC(mercury__equiv_type__build_eqv_map_3_0));
Define_label(mercury__equiv_type__build_eqv_map_3_0_i1006);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__equiv_type__build_eqv_map_3_0_i1008);
	r1 = (Integer) r3;
	localtailcall(mercury__equiv_type__build_eqv_map_3_0,
		STATIC(mercury__equiv_type__build_eqv_map_3_0));
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module4)
	init_entry(mercury__equiv_type__replace_in_item_list_5_0);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1052);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1051);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1048);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1047);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i9);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i13);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i12);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i15);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i14);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i17);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i18);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i19);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i20);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i21);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i22);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i23);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i6);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1041);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1043);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i4);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i28);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i29);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i1022);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_item_list'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_item_list_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1022);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r6 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	if ((tag((Integer) r6) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1043);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r6, ((Integer) 0)),
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1052) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1051) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1051) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1051) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1048) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1047) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1051) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1051) AND
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1051));
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1052);
	incr_sp_push_msg(11, "equiv_type__replace_in_item_list");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i9);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1051);
	incr_sp_push_msg(11, "equiv_type__replace_in_item_list");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i4);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1048);
	incr_sp_push_msg(11, "equiv_type__replace_in_item_list");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i19);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1047);
	incr_sp_push_msg(11, "equiv_type__replace_in_item_list");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i21);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i9);
	r7 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	if ((tag((Integer) r7) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i12);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r7, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r7, ((Integer) 0));
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	call_localret(STATIC(mercury__equiv_type__replace_in_du_5_0),
		mercury__equiv_type__replace_in_item_list_5_0_i13,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i13);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r7 = (Integer) r1;
	tag_incr_hp(r6, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 0);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r7;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	r7 = ((Integer) 1);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) tempr1;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i6);
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i12);
	if ((tag((Integer) r7) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i14);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	r2 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	r1 = (Integer) field(mktag(1), (Integer) r7, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r7, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r7, ((Integer) 0));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	detstackvar(3) = (Integer) r6;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_list_2_8_0),
		mercury__equiv_type__replace_in_item_list_5_0_i15,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i15);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r8 = (Integer) r1;
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r9;
	r7 = ((Integer) 1);
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 3));
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) r8;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) tempr1;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i6);
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i14);
	if ((tag((Integer) r7) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i4);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(2), (Integer) r7, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(2), (Integer) r7, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r7, ((Integer) 0));
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__equiv_type__replace_in_item_list_5_0_i17,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i17);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_item_list_5_0_i18,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i18);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r7 = (Integer) r3;
	r8 = (Integer) r1;
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 3));
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) r8;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) tempr1;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i6);
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i19);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 5));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	call_localret(STATIC(mercury__equiv_type__replace_in_tms_5_0),
		mercury__equiv_type__replace_in_item_list_5_0_i20,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i20);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r7 = (Integer) r1;
	r8 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r8;
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) r7;
	field(mktag(3), (Integer) r6, ((Integer) 4)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) r6, ((Integer) 5)) = (Integer) detstackvar(8);
	r7 = ((Integer) 1);
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i6);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i21);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 6));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 5));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	call_localret(STATIC(mercury__equiv_type__replace_in_tms_5_0),
		mercury__equiv_type__replace_in_item_list_5_0_i22,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i22);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r3 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__equiv_type__replace_in_tm_5_0),
		mercury__equiv_type__replace_in_item_list_5_0_i23,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i23);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r7 = (Integer) r1;
	r8 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(3), ((Integer) 7));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r8;
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) r6, ((Integer) 4)) = (Integer) r7;
	field(mktag(3), (Integer) r6, ((Integer) 5)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r6, ((Integer) 6)) = (Integer) detstackvar(9);
	r7 = ((Integer) 1);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i6);
	if (((Integer) r7 != ((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i1041);
	r4 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i28);
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1041);
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i28);
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1043);
	incr_sp_push_msg(11, "equiv_type__replace_in_item_list");
	detstackvar(11) = (Integer) succip;
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i4);
	r1 = (Integer) r4;
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r5;
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i28);
	detstackvar(6) = (Integer) r4;
	localcall(mercury__equiv_type__replace_in_item_list_5_0,
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i29),
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i29);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i1022);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module5)
	init_entry(mercury__equiv_type__replace_in_du_5_0);
	init_label(mercury__equiv_type__replace_in_du_5_0_i4);
	init_label(mercury__equiv_type__replace_in_du_5_0_i5);
	init_label(mercury__equiv_type__replace_in_du_5_0_i1003);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_du'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_du_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__replace_in_du_5_0_i1003);
	incr_sp_push_msg(4, "equiv_type__replace_in_du");
	detstackvar(4) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0),
		mercury__equiv_type__replace_in_du_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_du_5_0));
	}
Define_label(mercury__equiv_type__replace_in_du_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_du_5_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__equiv_type__replace_in_du_5_0,
		LABEL(mercury__equiv_type__replace_in_du_5_0_i5),
		STATIC(mercury__equiv_type__replace_in_du_5_0));
	}
Define_label(mercury__equiv_type__replace_in_du_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_du_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__equiv_type__replace_in_du_5_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module6)
	init_entry(mercury__equiv_type__replace_in_type_list_2_8_0);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i4);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i5);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i6);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i1002);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_type_list_2'/8 in mode 0 */
Define_static(mercury__equiv_type__replace_in_type_list_2_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_list_2_8_0_i1002);
	incr_sp_push_msg(6, "equiv_type__replace_in_type_list_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_type_list_2_8_0_i4,
		STATIC(mercury__equiv_type__replace_in_type_list_2_8_0));
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_list_2_8_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) tempr1;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__equiv_type__replace_in_type_list_2_8_0_i5,
		STATIC(mercury__equiv_type__replace_in_type_list_2_8_0));
	}
	}
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_list_2_8_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__equiv_type__replace_in_type_list_2_8_0,
		LABEL(mercury__equiv_type__replace_in_type_list_2_8_0_i6),
		STATIC(mercury__equiv_type__replace_in_type_list_2_8_0));
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_list_2_8_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module7)
	init_entry(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i1003);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_ctor_arg_list_2'/8 in mode 0 */
Define_static(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i1003);
	incr_sp_push_msg(6, "equiv_type__replace_in_ctor_arg_list_2");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4,
		STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	}
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) tempr1;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5,
		STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	}
	}
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0,
		LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6),
		STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module8)
	init_entry(mercury__equiv_type__replace_in_type_2_7_0);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i1000);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i6);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i8);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i11);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i10);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i13);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i16);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i18);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i22);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i23);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i15);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i25);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i26);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i5);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_type_2'/7 in mode 0 */
Define_static(mercury__equiv_type__replace_in_type_2_7_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i1000);
	r3 = ((Integer) 1);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i1000);
	incr_sp_push_msg(13, "equiv_type__replace_in_type_2");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__equiv_type__replace_in_type_2_7_0_i6,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i5);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = ((Integer) 1);
	call_localret(STATIC(mercury__equiv_type__replace_in_type_list_2_8_0),
		mercury__equiv_type__replace_in_type_2_7_0_i8,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r2;
	detstackvar(11) = (Integer) r3;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__equiv_type__replace_in_type_2_7_0_i11,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i10);
	r3 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r8 = ((Integer) 0);
	GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i13);
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i10);
	r3 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r8 = ((Integer) 1);
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i13);
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r4;
	detstackvar(9) = (Integer) r5;
	detstackvar(10) = (Integer) r6;
	detstackvar(11) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	r2 = (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__equiv_type__replace_in_type_2_7_0_i16,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i15);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__varset__merge_5_0);
	call_localret(ENTRY(mercury__varset__merge_5_0),
		mercury__equiv_type__replace_in_type_2_7_0_i18,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i18);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i15);
	if (((Integer) detstackvar(11) != ((Integer) 1)))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i15);
	if (((Integer) detstackvar(5) != ((Integer) 1)))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i15);
	detstackvar(6) = (Integer) r1;
	detstackvar(12) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__term__term_list_to_var_list_2_0);
	call_localret(ENTRY(mercury__term__term_list_to_var_list_2_0),
		mercury__equiv_type__replace_in_type_2_7_0_i22,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i22);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__term__substitute_corresponding_4_0);
	call_localret(ENTRY(mercury__term__substitute_corresponding_4_0),
		mercury__equiv_type__replace_in_type_2_7_0_i23,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i23);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	localtailcall(mercury__equiv_type__replace_in_type_2_7_0,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i15);
	detstackvar(6) = (Integer) detstackvar(10);
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(8), ((Integer) 0));
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__prog_util__construct_qualified_term_4_0);
	call_localret(ENTRY(mercury__prog_util__construct_qualified_term_4_0),
		mercury__equiv_type__replace_in_type_2_7_0_i25,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i25);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__equiv_type__replace_in_type_2_7_0_i26,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
	}
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i26);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module9)
	init_entry(mercury__equiv_type__replace_in_tms_5_0);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i4);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i5);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i1002);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_tms'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_tms_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__replace_in_tms_5_0_i1002);
	incr_sp_push_msg(3, "equiv_type__replace_in_tms");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_tm_5_0),
		mercury__equiv_type__replace_in_tms_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_tms_5_0));
Define_label(mercury__equiv_type__replace_in_tms_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tms_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__equiv_type__replace_in_tms_5_0,
		LABEL(mercury__equiv_type__replace_in_tms_5_0_i5),
		STATIC(mercury__equiv_type__replace_in_tms_5_0));
Define_label(mercury__equiv_type__replace_in_tms_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tms_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__equiv_type__replace_in_tms_5_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module10)
	init_entry(mercury__equiv_type__replace_in_tm_5_0);
	init_label(mercury__equiv_type__replace_in_tm_5_0_i4);
	init_label(mercury__equiv_type__replace_in_tm_5_0_i3);
	init_label(mercury__equiv_type__replace_in_tm_5_0_i5);
BEGIN_CODE

/* code for predicate 'equiv_type__replace_in_tm'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_tm_5_0);
	incr_sp_push_msg(2, "equiv_type__replace_in_tm");
	detstackvar(2) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_tm_5_0_i3);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__equiv_type__replace_in_type_5_0),
		mercury__equiv_type__replace_in_tm_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_tm_5_0));
	}
Define_label(mercury__equiv_type__replace_in_tm_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tm_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__equiv_type__replace_in_tm_5_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__equiv_type__replace_in_type_5_0),
		mercury__equiv_type__replace_in_tm_5_0_i5,
		STATIC(mercury__equiv_type__replace_in_tm_5_0));
	}
Define_label(mercury__equiv_type__replace_in_tm_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tm_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module11)
	init_entry(mercury__equiv_type__report_circular_types_3_0);
	init_label(mercury__equiv_type__report_circular_types_3_0_i8);
	init_label(mercury__equiv_type__report_circular_types_3_0_i9);
	init_label(mercury__equiv_type__report_circular_types_3_0_i10);
	init_label(mercury__equiv_type__report_circular_types_3_0_i11);
	init_label(mercury__equiv_type__report_circular_types_3_0_i12);
	init_label(mercury__equiv_type__report_circular_types_3_0_i13);
	init_label(mercury__equiv_type__report_circular_types_3_0_i14);
	init_label(mercury__equiv_type__report_circular_types_3_0_i1005);
	init_label(mercury__equiv_type__report_circular_types_3_0_i1007);
BEGIN_CODE

/* code for predicate 'equiv_type__report_circular_types'/3 in mode 0 */
Define_static(mercury__equiv_type__report_circular_types_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i1005);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Word tempr1, tempr2, tempr3;
	tempr1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i1007);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i1007);
	tempr3 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	if ((tag((Integer) tempr3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i1007);
	incr_sp_push_msg(5, "equiv_type__report_circular_types");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(2), (Integer) tempr3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) tempr3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__equiv_type__report_circular_types_3_0_i8,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__equiv_type__report_circular_types_3_0_i9,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) r1;
	r1 = string_const("Error: circular equivalence type `", 34);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__equiv_type__report_circular_types_3_0_i10,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__prog_out__write_sym_name_3_0);
	call_localret(ENTRY(mercury__prog_out__write_sym_name_3_0),
		mercury__equiv_type__report_circular_types_3_0_i11,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i11);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) r1;
	r1 = string_const("'/", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__equiv_type__report_circular_types_3_0_i12,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i12);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__equiv_type__report_circular_types_3_0_i13,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i13);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__equiv_type__report_circular_types_3_0_i14,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i14);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__equiv_type__report_circular_types_3_0,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i1005);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__equiv_type__report_circular_types_3_0_i1007);
	r1 = string_const("equiv_type__report_circular_types: invalid item", 47);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module12)
	init_entry(mercury____Unify___equiv_type__eqv_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___equiv_type__eqv_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___equiv_type__eqv_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module13)
	init_entry(mercury____Index___equiv_type__eqv_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___equiv_type__eqv_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	r2 = (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___equiv_type__eqv_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module14)
	init_entry(mercury____Compare___equiv_type__eqv_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___equiv_type__eqv_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_equiv_type__common_0);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_equiv_type__base_type_info_eqv_type_body_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___equiv_type__eqv_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module15)
	init_entry(mercury____Unify___equiv_type__eqv_type_body_0_0);
	init_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i2);
	init_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i4);
	init_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___equiv_type__eqv_type_body_0_0);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___equiv_type__eqv_type_body_0_0_i2,
		STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0));
	}
Define_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___equiv_type__eqv_type_body_0_0_i4,
		STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0));
	}
Define_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term_0_0),
		STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0));
	}
Define_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module16)
	init_entry(mercury____Index___equiv_type__eqv_type_body_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___equiv_type__eqv_type_body_0_0);
	tailcall(STATIC(mercury____Index___equiv_type_eqv_type_body_0__ua10000_2_0),
		STATIC(mercury____Index___equiv_type__eqv_type_body_0_0));
END_MODULE

BEGIN_MODULE(mercury__equiv_type_module17)
	init_entry(mercury____Compare___equiv_type__eqv_type_body_0_0);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i4);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i5);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___equiv_type__eqv_type_body_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___equiv_type__eqv_type_body_0_0_i4,
		STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0));
	}
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___equiv_type__eqv_type_body_0_0_i10,
		STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0));
	}
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term_0_0),
		STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__equiv_type_bunch_0(void)
{
	mercury__equiv_type_module0();
	mercury__equiv_type_module1();
	mercury__equiv_type_module2();
	mercury__equiv_type_module3();
	mercury__equiv_type_module4();
	mercury__equiv_type_module5();
	mercury__equiv_type_module6();
	mercury__equiv_type_module7();
	mercury__equiv_type_module8();
	mercury__equiv_type_module9();
	mercury__equiv_type_module10();
	mercury__equiv_type_module11();
	mercury__equiv_type_module12();
	mercury__equiv_type_module13();
	mercury__equiv_type_module14();
	mercury__equiv_type_module15();
	mercury__equiv_type_module16();
	mercury__equiv_type_module17();
}

#endif

void mercury__equiv_type__init(void); /* suppress gcc warning */
void mercury__equiv_type__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__equiv_type_bunch_0();
#endif
}
