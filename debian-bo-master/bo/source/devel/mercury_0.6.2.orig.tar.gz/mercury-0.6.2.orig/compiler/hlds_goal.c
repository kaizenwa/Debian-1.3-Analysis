/*
** Automatically generated from `hlds_goal.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__hlds_goal__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___hlds_goal_uni_mode_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_goal_hlds__goal_info_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_goal_call_unify_context_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_goal_unify_context_0__ua10000_2_0);
Declare_static(mercury____Index___hlds_goal_case_0__ua10000_2_0);
Define_extern_entry(mercury__hlds_goal__get_pragma_c_var_names_2_0);
Declare_label(mercury__hlds_goal__get_pragma_c_var_names_2_0_i2);
Declare_static(mercury__hlds_goal__get_pragma_c_var_names_2_3_0);
Declare_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i5);
Declare_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i3);
Declare_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i2);
Declare_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i1);
Define_extern_entry(mercury__hlds_goal__goal_info_init_1_0);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i2);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i3);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i4);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i5);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i6);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i7);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i8);
Declare_label(mercury__hlds_goal__goal_info_init_1_0_i9);
Define_extern_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_pre_births_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_post_births_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_pre_deaths_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_post_deaths_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
Declare_label(mercury__hlds_goal__goal_info_get_code_model_2_0_i2);
Define_extern_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_determinism_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_nonlocals_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_features_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_features_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_add_feature_3_0);
Declare_label(mercury__hlds_goal__goal_info_add_feature_3_0_i2);
Declare_label(mercury__hlds_goal__goal_info_add_feature_3_0_i3);
Define_extern_entry(mercury__hlds_goal__goal_info_remove_feature_3_0);
Declare_label(mercury__hlds_goal__goal_info_remove_feature_3_0_i2);
Declare_label(mercury__hlds_goal__goal_info_remove_feature_3_0_i3);
Define_extern_entry(mercury__hlds_goal__goal_info_has_feature_2_0);
Declare_label(mercury__hlds_goal__goal_info_has_feature_2_0_i2);
Define_extern_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_instmap_delta_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_context_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_follow_vars_3_0);
Define_extern_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
Define_extern_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
Define_extern_entry(mercury__hlds_goal__goal_set_follow_vars_3_0);
Declare_label(mercury__hlds_goal__goal_set_follow_vars_3_0_i2);
Define_extern_entry(mercury__hlds_goal__goal_set_resume_point_3_0);
Declare_label(mercury__hlds_goal__goal_set_resume_point_3_0_i2);
Define_extern_entry(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0);
Declare_label(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0_i1003);
Define_extern_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
Declare_label(mercury__hlds_goal__goal_to_conj_list_2_0_i2);
Define_extern_entry(mercury__hlds_goal__goal_to_disj_list_2_0);
Declare_label(mercury__hlds_goal__goal_to_disj_list_2_0_i2);
Define_extern_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
Declare_label(mercury__hlds_goal__conj_list_to_goal_3_0_i2);
Define_extern_entry(mercury__hlds_goal__disj_list_to_goal_3_0);
Declare_label(mercury__hlds_goal__disj_list_to_goal_3_0_i1000);
Declare_label(mercury__hlds_goal__disj_list_to_goal_3_0_i6);
Define_extern_entry(mercury__hlds_goal__goal_is_atomic_1_0);
Declare_label(mercury__hlds_goal__goal_is_atomic_1_0_i6);
Declare_label(mercury__hlds_goal__goal_is_atomic_1_0_i4);
Declare_label(mercury__hlds_goal__goal_is_atomic_1_0_i9);
Declare_label(mercury__hlds_goal__goal_is_atomic_1_0_i2);
Declare_label(mercury__hlds_goal__goal_is_atomic_1_0_i1);
Define_extern_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
Declare_label(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0_i1);
Define_extern_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
Declare_label(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0_i1);
Define_extern_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
Define_extern_entry(mercury____Unify___hlds_goal__hlds__goal_0_0);
Define_extern_entry(mercury____Index___hlds_goal__hlds__goal_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__hlds__goal_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__hlds__goal_expr_0_0);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1061);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1060);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1059);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1058);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1057);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1056);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1055);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i5);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i7);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i9);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i13);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i15);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i17);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i19);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i21);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i25);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i27);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1052);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i35);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i37);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i41);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i43);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i45);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i47);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i49);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i53);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i55);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1054);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i59);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i65);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i67);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i69);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i63);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i74);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i76);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i78);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i80);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1053);
Define_extern_entry(mercury____Index___hlds_goal__hlds__goal_expr_0_0);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i5);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i6);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i7);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i8);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i9);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i10);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i11);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i4);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i12);
Declare_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i13);
Define_extern_entry(mercury____Compare___hlds_goal__hlds__goal_expr_0_0);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i2);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i6);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i13);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i17);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i16);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i23);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i29);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i37);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i41);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i47);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i53);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i59);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i68);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i72);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i78);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i81);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i85);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i91);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i95);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i101);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i107);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i113);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i122);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i126);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i132);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i138);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i144);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i150);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i12);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i160);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i167);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i173);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i179);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i185);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i191);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i163);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i204);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i210);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i216);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i222);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i1001);
Define_extern_entry(mercury____Unify___hlds_goal__is_builtin_0_0);
Define_extern_entry(mercury____Index___hlds_goal__is_builtin_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__is_builtin_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__case_0_0);
Declare_label(mercury____Unify___hlds_goal__case_0_0_i2);
Declare_label(mercury____Unify___hlds_goal__case_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__case_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__case_0_0);
Declare_label(mercury____Compare___hlds_goal__case_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__case_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_goal__stack_slots_0_0);
Define_extern_entry(mercury____Index___hlds_goal__stack_slots_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__stack_slots_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__follow_vars_0_0);
Define_extern_entry(mercury____Index___hlds_goal__follow_vars_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__follow_vars_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__store_map_0_0);
Define_extern_entry(mercury____Index___hlds_goal__store_map_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__store_map_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__unify_rhs_0_0);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1015);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i10);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i8);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i15);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i17);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i19);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1012);
Declare_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__unify_rhs_0_0);
Declare_label(mercury____Index___hlds_goal__unify_rhs_0_0_i4);
Declare_label(mercury____Index___hlds_goal__unify_rhs_0_0_i5);
Define_extern_entry(mercury____Compare___hlds_goal__unify_rhs_0_0);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i2);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i6);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i12);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i19);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i18);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i15);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i28);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i34);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i40);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i46);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i9);
Declare_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i1001);
Define_extern_entry(mercury____Unify___hlds_goal__unification_0_0);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i7);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i1030);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i12);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i1029);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i16);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i18);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i20);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i14);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i26);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i28);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i30);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i32);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i24);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i35);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i1026);
Declare_label(mercury____Unify___hlds_goal__unification_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__unification_0_0);
Declare_label(mercury____Index___hlds_goal__unification_0_0_i5);
Declare_label(mercury____Index___hlds_goal__unification_0_0_i4);
Declare_label(mercury____Index___hlds_goal__unification_0_0_i6);
Declare_label(mercury____Index___hlds_goal__unification_0_0_i7);
Define_extern_entry(mercury____Compare___hlds_goal__unification_0_0);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i2);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i6);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i17);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i18);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i16);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i13);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i26);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i12);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i36);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i42);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i48);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i32);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i60);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i66);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i72);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i78);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i56);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i90);
Declare_label(mercury____Compare___hlds_goal__unification_0_0_i9);
Define_extern_entry(mercury____Unify___hlds_goal__unify_context_0_0);
Declare_label(mercury____Unify___hlds_goal__unify_context_0_0_i2);
Declare_label(mercury____Unify___hlds_goal__unify_context_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__unify_context_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__unify_context_0_0);
Declare_label(mercury____Compare___hlds_goal__unify_context_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__unify_context_0_0_i3);
Define_extern_entry(mercury____Unify___hlds_goal__unify_main_context_0_0);
Declare_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1012);
Declare_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i6);
Declare_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i9);
Declare_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1009);
Declare_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
Declare_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1011);
Define_extern_entry(mercury____Index___hlds_goal__unify_main_context_0_0);
Declare_label(mercury____Index___hlds_goal__unify_main_context_0_0_i4);
Declare_label(mercury____Index___hlds_goal__unify_main_context_0_0_i5);
Define_extern_entry(mercury____Compare___hlds_goal__unify_main_context_0_0);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i2);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i6);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i12);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i14);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i20);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i19);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i9);
Declare_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i1000);
Define_extern_entry(mercury____Unify___hlds_goal__unify_sub_context_0_0);
Define_extern_entry(mercury____Index___hlds_goal__unify_sub_context_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__unify_sub_context_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__unify_sub_contexts_0_0);
Define_extern_entry(mercury____Index___hlds_goal__unify_sub_contexts_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__unify_sub_contexts_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__call_unify_context_0_0);
Declare_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i2);
Declare_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i4);
Declare_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__call_unify_context_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__call_unify_context_0_0);
Declare_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i5);
Declare_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i10);
Define_extern_entry(mercury____Unify___hlds_goal__hlds__goals_0_0);
Define_extern_entry(mercury____Index___hlds_goal__hlds__goals_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__hlds__goals_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__hlds__goal_info_0_0);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i2);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i4);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i6);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i8);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i10);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i12);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i14);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i16);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i18);
Declare_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__hlds__goal_info_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__hlds__goal_info_0_0);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i10);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i16);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i22);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i28);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i34);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i40);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i46);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i52);
Declare_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i58);
Define_extern_entry(mercury____Unify___hlds_goal__goal_feature_0_0);
Declare_label(mercury____Unify___hlds_goal__goal_feature_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__goal_feature_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__goal_feature_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__resume_point_0_0);
Declare_label(mercury____Unify___hlds_goal__resume_point_0_0_i1009);
Declare_label(mercury____Unify___hlds_goal__resume_point_0_0_i6);
Declare_label(mercury____Unify___hlds_goal__resume_point_0_0_i1006);
Declare_label(mercury____Unify___hlds_goal__resume_point_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__resume_point_0_0);
Declare_label(mercury____Index___hlds_goal__resume_point_0_0_i3);
Define_extern_entry(mercury____Compare___hlds_goal__resume_point_0_0);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i2);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i3);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i6);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i11);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i16);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i15);
Declare_label(mercury____Compare___hlds_goal__resume_point_0_0_i9);
Define_extern_entry(mercury____Unify___hlds_goal__resume_locs_0_0);
Declare_label(mercury____Unify___hlds_goal__resume_locs_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__resume_locs_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__resume_locs_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__unify_mode_0_0);
Define_extern_entry(mercury____Index___hlds_goal__unify_mode_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__unify_mode_0_0);
Define_extern_entry(mercury____Unify___hlds_goal__uni_mode_0_0);
Declare_label(mercury____Unify___hlds_goal__uni_mode_0_0_i2);
Declare_label(mercury____Unify___hlds_goal__uni_mode_0_0_i1);
Define_extern_entry(mercury____Index___hlds_goal__uni_mode_0_0);
Define_extern_entry(mercury____Compare___hlds_goal__uni_mode_0_0);
Declare_label(mercury____Compare___hlds_goal__uni_mode_0_0_i4);
Declare_label(mercury____Compare___hlds_goal__uni_mode_0_0_i3);

extern Word * mercury_data_hlds_goal__base_type_layout_call_unify_context_0[];
Word * mercury_data_hlds_goal__base_type_info_call_unify_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__call_unify_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__call_unify_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__call_unify_context_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_call_unify_context_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_case_0[];
Word * mercury_data_hlds_goal__base_type_info_case_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__case_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__case_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__case_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_case_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_follow_vars_0[];
Word * mercury_data_hlds_goal__base_type_info_follow_vars_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__follow_vars_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__follow_vars_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__follow_vars_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_follow_vars_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_goal_feature_0[];
Word * mercury_data_hlds_goal__base_type_info_goal_feature_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__goal_feature_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__goal_feature_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__goal_feature_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_goal_feature_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_hlds__goal_0[];
Word * mercury_data_hlds_goal__base_type_info_hlds__goal_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__hlds__goal_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__hlds__goal_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__hlds__goal_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_hlds__goal_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_hlds__goal_expr_0[];
Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__hlds__goal_expr_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_hlds__goal_expr_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_hlds__goal_info_0[];
Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__hlds__goal_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_hlds__goal_info_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_hlds__goals_0[];
Word * mercury_data_hlds_goal__base_type_info_hlds__goals_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__hlds__goals_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__hlds__goals_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__hlds__goals_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_hlds__goals_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_is_builtin_0[];
Word * mercury_data_hlds_goal__base_type_info_is_builtin_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__is_builtin_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__is_builtin_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__is_builtin_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_is_builtin_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_resume_locs_0[];
Word * mercury_data_hlds_goal__base_type_info_resume_locs_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__resume_locs_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__resume_locs_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__resume_locs_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_resume_locs_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_resume_point_0[];
Word * mercury_data_hlds_goal__base_type_info_resume_point_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__resume_point_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__resume_point_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__resume_point_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_resume_point_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_stack_slots_0[];
Word * mercury_data_hlds_goal__base_type_info_stack_slots_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__stack_slots_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__stack_slots_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__stack_slots_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_stack_slots_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_store_map_0[];
Word * mercury_data_hlds_goal__base_type_info_store_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__store_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__store_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__store_map_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_store_map_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_uni_mode_0[];
Word * mercury_data_hlds_goal__base_type_info_uni_mode_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__uni_mode_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__uni_mode_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__uni_mode_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_uni_mode_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unification_0[];
Word * mercury_data_hlds_goal__base_type_info_unification_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unification_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unification_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unification_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unification_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unify_context_0[];
Word * mercury_data_hlds_goal__base_type_info_unify_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unify_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unify_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unify_context_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unify_context_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unify_main_context_0[];
Word * mercury_data_hlds_goal__base_type_info_unify_main_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unify_main_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unify_main_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unify_main_context_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unify_mode_0[];
Word * mercury_data_hlds_goal__base_type_info_unify_mode_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unify_mode_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unify_mode_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unify_mode_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unify_mode_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unify_rhs_0[];
Word * mercury_data_hlds_goal__base_type_info_unify_rhs_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unify_rhs_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unify_rhs_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unify_sub_context_0[];
Word * mercury_data_hlds_goal__base_type_info_unify_sub_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unify_sub_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unify_sub_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unify_sub_context_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unify_sub_context_0
};

extern Word * mercury_data_hlds_goal__base_type_layout_unify_sub_contexts_0[];
Word * mercury_data_hlds_goal__base_type_info_unify_sub_contexts_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___hlds_goal__unify_sub_contexts_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___hlds_goal__unify_sub_contexts_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___hlds_goal__unify_sub_contexts_0_0),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_layout_unify_sub_contexts_0
};

extern Word * mercury_data_hlds_goal__common_5[];
Word * mercury_data_hlds_goal__base_type_layout_unify_sub_contexts_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_5)
};

extern Word * mercury_data_hlds_goal__common_6[];
Word * mercury_data_hlds_goal__base_type_layout_unify_sub_context_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_6)
};

extern Word * mercury_data_hlds_goal__common_8[];
extern Word * mercury_data_hlds_goal__common_11[];
extern Word * mercury_data_hlds_goal__common_15[];
Word * mercury_data_hlds_goal__base_type_layout_unify_rhs_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_8),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_11),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_15),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_17[];
Word * mercury_data_hlds_goal__base_type_layout_unify_mode_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_17),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_17),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_17),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_17)
};

extern Word * mercury_data_hlds_goal__common_18[];
extern Word * mercury_data_hlds_goal__common_20[];
extern Word * mercury_data_hlds_goal__common_22[];
Word * mercury_data_hlds_goal__base_type_layout_unify_main_context_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_18),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_20),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_22),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_24[];
Word * mercury_data_hlds_goal__base_type_layout_unify_context_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_24),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_26[];
extern Word * mercury_data_hlds_goal__common_28[];
extern Word * mercury_data_hlds_goal__common_29[];
extern Word * mercury_data_hlds_goal__common_33[];
Word * mercury_data_hlds_goal__base_type_layout_unification_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_26),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_28),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_29),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_hlds_goal__common_33)
};

extern Word * mercury_data_hlds_goal__common_35[];
Word * mercury_data_hlds_goal__base_type_layout_uni_mode_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_35),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_36[];
Word * mercury_data_hlds_goal__base_type_layout_store_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36)
};

Word * mercury_data_hlds_goal__base_type_layout_stack_slots_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36)
};

extern Word * mercury_data_hlds_goal__common_37[];
extern Word * mercury_data_hlds_goal__common_40[];
Word * mercury_data_hlds_goal__base_type_layout_resume_point_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_37),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_40),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_41[];
Word * mercury_data_hlds_goal__base_type_layout_resume_locs_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_41),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_41),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_41),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_41)
};

extern Word * mercury_data_hlds_goal__common_43[];
Word * mercury_data_hlds_goal__base_type_layout_is_builtin_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_43),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_43),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_43),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_43)
};

extern Word * mercury_data_hlds_goal__common_45[];
Word * mercury_data_hlds_goal__base_type_layout_hlds__goals_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_45),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_45),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_45),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_45)
};

extern Word * mercury_data_hlds_goal__common_51[];
Word * mercury_data_hlds_goal__base_type_layout_hlds__goal_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_51),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_52[];
extern Word * mercury_data_hlds_goal__common_55[];
extern Word * mercury_data_hlds_goal__common_57[];
extern Word * mercury_data_hlds_goal__common_72[];
Word * mercury_data_hlds_goal__base_type_layout_hlds__goal_expr_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_52),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_55),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_57),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_hlds_goal__common_72)
};

extern Word * mercury_data_hlds_goal__common_73[];
Word * mercury_data_hlds_goal__base_type_layout_hlds__goal_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_73),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_73),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_73),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_73)
};

extern Word * mercury_data_hlds_goal__common_74[];
Word * mercury_data_hlds_goal__base_type_layout_goal_feature_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_74),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_74),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_74),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_74)
};

Word * mercury_data_hlds_goal__base_type_layout_follow_vars_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_hlds_goal__common_36)
};

extern Word * mercury_data_hlds_goal__common_75[];
Word * mercury_data_hlds_goal__base_type_layout_case_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_75),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_hlds_goal__common_76[];
Word * mercury_data_hlds_goal__base_type_layout_call_unify_context_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_76),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
Word * mercury_data_hlds_goal__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_hlds_goal__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_hlds_goal__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_llds__base_type_info_lval_0[];
Word * mercury_data_hlds_goal__common_3[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_hlds_goal__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2)
};

Word * mercury_data_hlds_goal__common_5[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_4)
};

Word * mercury_data_hlds_goal__common_6[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2)
};

Word * mercury_data_hlds_goal__common_7[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_hlds_goal__common_8[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) string_const("var", 3)
};

Word * mercury_data_hlds_goal__common_9[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0
};

Word * mercury_data_hlds_goal__common_10[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_hlds_goal__common_11[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) string_const("functor", 7)
};

extern Word * mercury_data_hlds_pred__base_type_info_pred_or_func_0[];
Word * mercury_data_hlds_goal__common_12[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_pred_or_func_0
};

extern Word * mercury_data_prog_data__base_type_info_mode_0[];
Word * mercury_data_hlds_goal__common_13[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_mode_0
};

extern Word * mercury_data_hlds_data__base_type_info_determinism_0[];
Word * mercury_data_hlds_goal__common_14[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_determinism_0
};

Word * mercury_data_hlds_goal__common_15[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) string_const("lambda_goal", 11)
};

Word * mercury_data_hlds_goal__common_16[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_mode_0,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_mode_0
};

Word * mercury_data_hlds_goal__common_17[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_16)
};

Word * mercury_data_hlds_goal__common_18[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("explicit", 8)
};

Word * mercury_data_hlds_goal__common_19[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_hlds_goal__common_20[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_19),
	(Word *) string_const("head", 4)
};

extern Word * mercury_data_hlds_pred__base_type_info_pred_call_id_0[];
Word * mercury_data_hlds_goal__common_21[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_pred_call_id_0
};

Word * mercury_data_hlds_goal__common_22[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_21),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_19),
	(Word *) string_const("call", 4)
};

Word * mercury_data_hlds_goal__common_23[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_unify_main_context_0
};

Word * mercury_data_hlds_goal__common_24[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_23),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_4),
	(Word *) string_const("unify_context", 13)
};

Word * mercury_data_hlds_goal__common_25[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0
};

Word * mercury_data_hlds_goal__common_26[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_25),
	(Word *) string_const("construct", 9)
};

extern Word * mercury_data_hlds_data__base_type_info_can_fail_0[];
Word * mercury_data_hlds_goal__common_27[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_can_fail_0
};

Word * mercury_data_hlds_goal__common_28[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_25),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_27),
	(Word *) string_const("deconstruct", 11)
};

Word * mercury_data_hlds_goal__common_29[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) string_const("assign", 6)
};

Word * mercury_data_hlds_goal__common_30[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) string_const("simple_test", 11)
};

Word * mercury_data_hlds_goal__common_31[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0
};

Word * mercury_data_hlds_goal__common_32[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_31),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_27),
	(Word *) string_const("complicated_unify", 17)
};

Word * mercury_data_hlds_goal__common_33[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_30),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_32)
};

extern Word * mercury_data_prog_data__base_type_info_inst_0[];
Word * mercury_data_hlds_goal__common_34[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0
};

Word * mercury_data_hlds_goal__common_35[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_34),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_34),
	(Word *) string_const("->", 2)
};

Word * mercury_data_hlds_goal__common_36[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3)
};

Word * mercury_data_hlds_goal__common_37[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("no_resume_point", 15)
};

extern Word * mercury_data_set__base_type_info_set_1[];
Word * mercury_data_hlds_goal__common_38[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_hlds_goal__common_39[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_resume_locs_0
};

Word * mercury_data_hlds_goal__common_40[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_39),
	(Word *) string_const("resume_point", 12)
};

Word * mercury_data_hlds_goal__common_41[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 4),
	(Word *) string_const("orig_only", 9),
	(Word *) string_const("stack_only", 10),
	(Word *) string_const("orig_and_stack", 14),
	(Word *) string_const("stack_and_orig", 14)
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_hlds_goal__common_42[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0,
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_hlds_goal__common_43[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_42)
};

Word * mercury_data_hlds_goal__common_44[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0)
};

Word * mercury_data_hlds_goal__common_45[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_44)
};

extern Word * mercury_data_instmap__base_type_info_instmap_delta_0[];
Word * mercury_data_hlds_goal__common_46[] = {
	(Word *) (Integer) mercury_data_instmap__base_type_info_instmap_delta_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_hlds_goal__common_47[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

Word * mercury_data_hlds_goal__common_48[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3)
};

Word * mercury_data_hlds_goal__common_49[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0
};

Word * mercury_data_hlds_goal__common_50[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_resume_point_0
};

Word * mercury_data_hlds_goal__common_51[] = {
	(Word *) ((Integer) 11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_46),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_47),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_48),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_49),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_50),
	(Word *) string_const("goal_info", 9)
};

Word * mercury_data_hlds_goal__common_52[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_44),
	(Word *) string_const("conj", 4)
};

Word * mercury_data_hlds_goal__common_53[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_call_unify_context_0
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
Word * mercury_data_hlds_goal__common_54[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0
};

Word * mercury_data_hlds_goal__common_55[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_42),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_53),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_54),
	(Word *) string_const("call", 4)
};

extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_hlds_goal__common_56[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_hlds_goal__common_57[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_56),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_13),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_14),
	(Word *) string_const("higher_order_call", 17)
};

Word * mercury_data_hlds_goal__common_58[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_case_0
};

Word * mercury_data_hlds_goal__common_59[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_27),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_58),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3),
	(Word *) string_const("switch", 6)
};

Word * mercury_data_hlds_goal__common_60[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_unify_rhs_0
};

Word * mercury_data_hlds_goal__common_61[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_unification_0
};

Word * mercury_data_hlds_goal__common_62[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_unify_context_0
};

Word * mercury_data_hlds_goal__common_63[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_60),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_16),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_61),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_62),
	(Word *) string_const("unify", 5)
};

Word * mercury_data_hlds_goal__common_64[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_44),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3),
	(Word *) string_const("disj", 4)
};

Word * mercury_data_hlds_goal__common_65[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) string_const("not", 3)
};

Word * mercury_data_hlds_goal__common_66[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) string_const("some", 4)
};

Word * mercury_data_hlds_goal__common_67[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3),
	(Word *) string_const("if_then_else", 12)
};

Word * mercury_data_hlds_goal__common_68[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_prog_data__base_type_info_c_is_recursive_0[];
Word * mercury_data_hlds_goal__common_69[] = {
	(Word *) (Integer) mercury_data_prog_data__base_type_info_c_is_recursive_0
};

Word * mercury_data_hlds_goal__common_70[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_1)
};

Word * mercury_data_hlds_goal__common_71[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_68),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_69),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_70),
	(Word *) string_const("pragma_c_code", 13)
};

Word * mercury_data_hlds_goal__common_72[] = {
	(Word *) ((Integer) 7),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_59),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_63),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_64),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_65),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_66),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_67),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_hlds_goal__common_71)
};

Word * mercury_data_hlds_goal__common_73[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0)
};

Word * mercury_data_hlds_goal__common_74[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 1),
	(Word *) string_const("constraint", 10)
};

Word * mercury_data_hlds_goal__common_75[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0),
	(Word *) string_const("case", 4)
};

Word * mercury_data_hlds_goal__common_76[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_60),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_62),
	(Word *) string_const("call_unify_context", 18)
};

BEGIN_MODULE(mercury__hlds_goal_module0)
	init_entry(mercury____Index___hlds_goal_uni_mode_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_goal_uni_mode_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_goal_uni_mode_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module1)
	init_entry(mercury____Index___hlds_goal_hlds__goal_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_goal_hlds__goal_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_goal_hlds__goal_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module2)
	init_entry(mercury____Index___hlds_goal_call_unify_context_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_goal_call_unify_context_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_goal_call_unify_context_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module3)
	init_entry(mercury____Index___hlds_goal_unify_context_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_goal_unify_context_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_goal_unify_context_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module4)
	init_entry(mercury____Index___hlds_goal_case_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___hlds_goal_case_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___hlds_goal_case_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module5)
	init_entry(mercury__hlds_goal__get_pragma_c_var_names_2_0);
	init_label(mercury__hlds_goal__get_pragma_c_var_names_2_0_i2);
BEGIN_CODE

/* code for predicate 'get_pragma_c_var_names'/2 in mode 0 */
Define_entry(mercury__hlds_goal__get_pragma_c_var_names_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(1, "get_pragma_c_var_names");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__hlds_goal__get_pragma_c_var_names_2_3_0),
		mercury__hlds_goal__get_pragma_c_var_names_2_0_i2,
		ENTRY(mercury__hlds_goal__get_pragma_c_var_names_2_0));
Define_label(mercury__hlds_goal__get_pragma_c_var_names_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__get_pragma_c_var_names_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		ENTRY(mercury__hlds_goal__get_pragma_c_var_names_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module6)
	init_entry(mercury__hlds_goal__get_pragma_c_var_names_2_3_0);
	init_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i5);
	init_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i3);
	init_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i2);
	init_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'get_pragma_c_var_names_2'/3 in mode 0 */
Define_static(mercury__hlds_goal__get_pragma_c_var_names_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i1);
Define_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i5);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i3);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	GOTO_LABEL(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i2);
Define_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
Define_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i2);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i5);
Define_label(mercury__hlds_goal__get_pragma_c_var_names_2_3_0_i1);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module7)
	init_entry(mercury__hlds_goal__goal_info_init_1_0);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i2);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i3);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i4);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i5);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i6);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i7);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i8);
	init_label(mercury__hlds_goal__goal_info_init_1_0_i9);
BEGIN_CODE

/* code for predicate 'goal_info_init'/1 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_init_1_0);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	incr_sp_push_msg(8, "goal_info_init");
	detstackvar(8) = (Integer) succip;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i2,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i3,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i4,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i4);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i5,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i5);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_init_unreachable_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i6,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i7,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i7);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i8,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i8);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__hlds_goal__goal_info_init_1_0_i9,
		ENTRY(mercury__hlds_goal__goal_info_init_1_0));
	}
Define_label(mercury__hlds_goal__goal_info_init_1_0_i9);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_init_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = ((Integer) 6);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module8)
	init_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_pre_births'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module9)
	init_entry(mercury__hlds_goal__goal_info_set_pre_births_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_pre_births'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_pre_births_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module10)
	init_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_post_births'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module11)
	init_entry(mercury__hlds_goal__goal_info_set_post_births_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_post_births'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_post_births_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module12)
	init_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_pre_deaths'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module13)
	init_entry(mercury__hlds_goal__goal_info_set_pre_deaths_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_pre_deaths'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_pre_deaths_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module14)
	init_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_post_deaths'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module15)
	init_entry(mercury__hlds_goal__goal_info_set_post_deaths_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_post_deaths'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_post_deaths_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module16)
	init_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	init_label(mercury__hlds_goal__goal_info_get_code_model_2_0_i2);
BEGIN_CODE

/* code for predicate 'goal_info_get_code_model'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	incr_sp_push_msg(1, "goal_info_get_code_model");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__hlds_goal__goal_info_get_code_model_2_0_i2,
		ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0));
	}
Define_label(mercury__hlds_goal__goal_info_get_code_model_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_get_code_model_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	tailcall(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module17)
	init_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_determinism'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module18)
	init_entry(mercury__hlds_goal__goal_info_set_determinism_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_determinism'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_determinism_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module19)
	init_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_nonlocals'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module20)
	init_entry(mercury__hlds_goal__goal_info_set_nonlocals_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_nonlocals'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_nonlocals_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module21)
	init_entry(mercury__hlds_goal__goal_info_get_features_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_features'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_features_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module22)
	init_entry(mercury__hlds_goal__goal_info_set_features_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_features'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_features_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module23)
	init_entry(mercury__hlds_goal__goal_info_add_feature_3_0);
	init_label(mercury__hlds_goal__goal_info_add_feature_3_0_i2);
	init_label(mercury__hlds_goal__goal_info_add_feature_3_0_i3);
BEGIN_CODE

/* code for predicate 'goal_info_add_feature'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_add_feature_3_0);
	incr_sp_push_msg(3, "goal_info_add_feature");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_goal__goal_info_get_features_2_0),
		mercury__hlds_goal__goal_info_add_feature_3_0_i2,
		ENTRY(mercury__hlds_goal__goal_info_add_feature_3_0));
	}
Define_label(mercury__hlds_goal__goal_info_add_feature_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_add_feature_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__hlds_goal__goal_info_add_feature_3_0_i3,
		ENTRY(mercury__hlds_goal__goal_info_add_feature_3_0));
	}
Define_label(mercury__hlds_goal__goal_info_add_feature_3_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_add_feature_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__hlds_goal__goal_info_set_features_3_0),
		ENTRY(mercury__hlds_goal__goal_info_add_feature_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module24)
	init_entry(mercury__hlds_goal__goal_info_remove_feature_3_0);
	init_label(mercury__hlds_goal__goal_info_remove_feature_3_0_i2);
	init_label(mercury__hlds_goal__goal_info_remove_feature_3_0_i3);
BEGIN_CODE

/* code for predicate 'goal_info_remove_feature'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_remove_feature_3_0);
	incr_sp_push_msg(3, "goal_info_remove_feature");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_goal__goal_info_get_features_2_0),
		mercury__hlds_goal__goal_info_remove_feature_3_0_i2,
		ENTRY(mercury__hlds_goal__goal_info_remove_feature_3_0));
	}
Define_label(mercury__hlds_goal__goal_info_remove_feature_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_remove_feature_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__delete_3_0);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__hlds_goal__goal_info_remove_feature_3_0_i3,
		ENTRY(mercury__hlds_goal__goal_info_remove_feature_3_0));
	}
Define_label(mercury__hlds_goal__goal_info_remove_feature_3_0_i3);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_remove_feature_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__hlds_goal__goal_info_set_features_3_0),
		ENTRY(mercury__hlds_goal__goal_info_remove_feature_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module25)
	init_entry(mercury__hlds_goal__goal_info_has_feature_2_0);
	init_label(mercury__hlds_goal__goal_info_has_feature_2_0_i2);
BEGIN_CODE

/* code for predicate 'goal_info_has_feature'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_has_feature_2_0);
	incr_sp_push_msg(2, "goal_info_has_feature");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__hlds_goal__goal_info_get_features_2_0),
		mercury__hlds_goal__goal_info_has_feature_2_0_i2,
		ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0));
	}
Define_label(mercury__hlds_goal__goal_info_has_feature_2_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_info_has_feature_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__member_2_0);
	tailcall(ENTRY(mercury__set__member_2_0),
		ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module26)
	init_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_instmap_delta'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module27)
	init_entry(mercury__hlds_goal__goal_info_set_instmap_delta_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_instmap_delta'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_instmap_delta_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module28)
	init_entry(mercury__hlds_goal__goal_info_get_context_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_context'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_context_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module29)
	init_entry(mercury__hlds_goal__goal_info_set_context_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_context'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_context_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module30)
	init_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_follow_vars'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module31)
	init_entry(mercury__hlds_goal__goal_info_set_follow_vars_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_follow_vars'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_follow_vars_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module32)
	init_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
BEGIN_CODE

/* code for predicate 'goal_info_get_resume_point'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module33)
	init_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
BEGIN_CODE

/* code for predicate 'goal_info_set_resume_point'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module34)
	init_entry(mercury__hlds_goal__goal_set_follow_vars_3_0);
	init_label(mercury__hlds_goal__goal_set_follow_vars_3_0_i2);
BEGIN_CODE

/* code for predicate 'goal_set_follow_vars'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_set_follow_vars_3_0);
	incr_sp_push_msg(2, "goal_set_follow_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__hlds_goal__goal_info_set_follow_vars_3_0),
		mercury__hlds_goal__goal_set_follow_vars_3_0_i2,
		ENTRY(mercury__hlds_goal__goal_set_follow_vars_3_0));
	}
Define_label(mercury__hlds_goal__goal_set_follow_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_set_follow_vars_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module35)
	init_entry(mercury__hlds_goal__goal_set_resume_point_3_0);
	init_label(mercury__hlds_goal__goal_set_resume_point_3_0_i2);
BEGIN_CODE

/* code for predicate 'goal_set_resume_point'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_set_resume_point_3_0);
	incr_sp_push_msg(2, "goal_set_resume_point");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__hlds_goal__goal_info_set_resume_point_3_0),
		mercury__hlds_goal__goal_set_resume_point_3_0_i2,
		ENTRY(mercury__hlds_goal__goal_set_resume_point_3_0));
	}
Define_label(mercury__hlds_goal__goal_set_resume_point_3_0_i2);
	update_prof_current_proc(LABEL(mercury__hlds_goal__goal_set_resume_point_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module36)
	init_entry(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0);
	init_label(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0_i1003);
BEGIN_CODE

/* code for predicate 'goal_info_resume_vars_and_loc'/3 in mode 0 */
Define_entry(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0_i1003);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0_i1003);
	r1 = string_const("goal_info__get_resume_vars_and_loc: no resume point", 51);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__hlds_goal__goal_info_resume_vars_and_loc_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module37)
	init_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	init_label(mercury__hlds_goal__goal_to_conj_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'goal_to_conj_list'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__hlds_goal__goal_to_conj_list_2_0_i2);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	proceed();
Define_label(mercury__hlds_goal__goal_to_conj_list_2_0_i2);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module38)
	init_entry(mercury__hlds_goal__goal_to_disj_list_2_0);
	init_label(mercury__hlds_goal__goal_to_disj_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'goal_to_disj_list'/2 in mode 0 */
Define_entry(mercury__hlds_goal__goal_to_disj_list_2_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__hlds_goal__goal_to_disj_list_2_0_i2);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__hlds_goal__goal_to_disj_list_2_0_i2);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	proceed();
Define_label(mercury__hlds_goal__goal_to_disj_list_2_0_i2);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module39)
	init_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	init_label(mercury__hlds_goal__conj_list_to_goal_3_0_i2);
BEGIN_CODE

/* code for predicate 'conj_list_to_goal'/3 in mode 0 */
Define_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__conj_list_to_goal_3_0_i2);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__conj_list_to_goal_3_0_i2);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__hlds_goal__conj_list_to_goal_3_0_i2);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module40)
	init_entry(mercury__hlds_goal__disj_list_to_goal_3_0);
	init_label(mercury__hlds_goal__disj_list_to_goal_3_0_i1000);
	init_label(mercury__hlds_goal__disj_list_to_goal_3_0_i6);
BEGIN_CODE

/* code for predicate 'disj_list_to_goal'/3 in mode 0 */
Define_entry(mercury__hlds_goal__disj_list_to_goal_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__disj_list_to_goal_3_0_i1000);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__disj_list_to_goal_3_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__hlds_goal__disj_list_to_goal_3_0_i1000);
	incr_sp_push_msg(3, "disj_list_to_goal");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__hlds_goal__disj_list_to_goal_3_0_i6,
		ENTRY(mercury__hlds_goal__disj_list_to_goal_3_0));
	}
Define_label(mercury__hlds_goal__disj_list_to_goal_3_0_i6);
	update_prof_current_proc(LABEL(mercury__hlds_goal__disj_list_to_goal_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module41)
	init_entry(mercury__hlds_goal__goal_is_atomic_1_0);
	init_label(mercury__hlds_goal__goal_is_atomic_1_0_i6);
	init_label(mercury__hlds_goal__goal_is_atomic_1_0_i4);
	init_label(mercury__hlds_goal__goal_is_atomic_1_0_i9);
	init_label(mercury__hlds_goal__goal_is_atomic_1_0_i2);
	init_label(mercury__hlds_goal__goal_is_atomic_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_is_atomic'/1 in mode 0 */
Define_entry(mercury__hlds_goal__goal_is_atomic_1_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i1) AND
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i2) AND
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i6) AND
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i1) AND
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i1) AND
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i1) AND
		LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i2));
Define_label(mercury__hlds_goal__goal_is_atomic_1_0_i6);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__hlds_goal__goal_is_atomic_1_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i9);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__hlds_goal__goal_is_atomic_1_0_i9);
	if (((Integer) r2 == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i2);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__hlds_goal__goal_is_atomic_1_0_i1);
Define_label(mercury__hlds_goal__goal_is_atomic_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_goal__goal_is_atomic_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module42)
	init_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	init_label(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0_i1);
BEGIN_CODE

/* code for predicate 'hlds__is_builtin_is_internal'/1 in mode 0 */
Define_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module43)
	init_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	init_label(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0_i1);
BEGIN_CODE

/* code for predicate 'hlds__is_builtin_is_inline'/1 in mode 0 */
Define_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module44)
	init_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
BEGIN_CODE

/* code for predicate 'hlds__is_builtin_make_builtin'/3 in mode 0 */
Define_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module45)
	init_entry(mercury____Unify___hlds_goal__hlds__goal_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__hlds__goal_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module46)
	init_entry(mercury____Index___hlds_goal__hlds__goal_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__hlds__goal_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_goal__hlds__goal_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module47)
	init_entry(mercury____Compare___hlds_goal__hlds__goal_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__hlds__goal_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module48)
	init_entry(mercury____Unify___hlds_goal__hlds__goal_expr_0_0);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1061);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1060);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1059);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1058);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1057);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1056);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1055);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i5);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i7);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i9);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i13);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i15);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i17);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i19);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i21);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i25);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i27);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1052);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i35);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i37);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i41);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i43);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i45);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i47);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i49);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i53);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i55);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1054);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i59);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i65);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i67);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i69);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i63);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i74);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i76);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i78);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i80);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	init_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1053);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__hlds__goal_expr_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1054);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1061) AND
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1060) AND
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1059) AND
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1058) AND
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1057) AND
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1056) AND
		LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1055));
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1061);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i5);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1060);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i13);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1059);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i25);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1058);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1052);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1057);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i35);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1056);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i41);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1055);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i53);
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i5);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i7,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_case_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i9,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i9);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i13);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i15,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury____Unify___hlds_goal__unify_rhs_0_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i17,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i17);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i19,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury____Unify___hlds_goal__unification_0_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i21,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
		tailcall(STATIC(mercury____Unify___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i25);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i27,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1052);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	decr_sp_pop_msg(9);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1053);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i35);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i37,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i37);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i41);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 5));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i43,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i43);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i45,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i45);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i47,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i47);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i49,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i49);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i53);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) !=0))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 3)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 4)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 4))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 5));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 6));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 6));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i55,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i55);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1054);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i59);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1053);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i59);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i63);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 5));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i65,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i65);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r2 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i67,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i67);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_call_unify_context_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i69,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i69);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
	tailcall(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i63);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i74,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i74);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i76,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i76);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i78,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i78);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i80,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i80);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	if (((Integer) detstackvar(4) != (Integer) detstackvar(8)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___hlds_goal__hlds__goal_expr_0_0_i1053);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module49)
	init_entry(mercury____Index___hlds_goal__hlds__goal_expr_0_0);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i5);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i6);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i7);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i8);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i9);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i10);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i11);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i4);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i12);
	init_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i13);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__hlds__goal_expr_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i5) AND
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i6) AND
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i7) AND
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i8) AND
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i9) AND
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i10) AND
		LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i11));
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i5);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i6);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i7);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i8);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i9);
	r1 = ((Integer) 7);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i10);
	r1 = ((Integer) 8);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i11);
	r1 = ((Integer) 9);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i12);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i13);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_goal__hlds__goal_expr_0_0_i13);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module50)
	init_entry(mercury____Compare___hlds_goal__hlds__goal_expr_0_0);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i2);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i3);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i4);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i6);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i13);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i17);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i16);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i23);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i29);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i37);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i41);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i47);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i53);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i59);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i68);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i72);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i78);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i81);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i85);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i91);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i95);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i101);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i107);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i113);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i122);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i126);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i132);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i138);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i144);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i150);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i12);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i160);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i167);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i173);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i179);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i185);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i191);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i163);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i204);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i210);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i216);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i222);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	init_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__hlds__goal_expr_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_goal__hlds__goal_expr_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i2,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_goal__hlds__goal_expr_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i3,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i12);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i13) AND
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i37) AND
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i68) AND
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i78) AND
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i81) AND
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i91) AND
		LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i122));
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i17,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i17);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i16);
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i23,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_case_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i29,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i29);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i37);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 5));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i41,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i41);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury____Compare___hlds_goal__unify_rhs_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i47,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i47);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i53,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i53);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury____Compare___hlds_goal__unification_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i59,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i59);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
		tailcall(STATIC(mercury____Compare___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i68);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i72,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i72);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i78);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i1001);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i81);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i85,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i85);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i91);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r3 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 5));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i95,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i95);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i101,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i101);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i107,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i107);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i113,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i113);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i122);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 5));
	detstackvar(10) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 6));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 6));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i126,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i126);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i132,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i132);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i138,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i138);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i144,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i144);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i150,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i150);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i160);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i1001);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i160);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i163);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 5));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i167,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i167);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i173,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i173);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i179,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i179);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r2 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i185,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i185);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_call_unify_context_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i191,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i191);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
	tailcall(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i163);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i204,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i204);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i210,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i210);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i216,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i216);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i222,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i222);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i18);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_expr_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_expr_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module51)
	init_entry(mercury____Unify___hlds_goal__is_builtin_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__is_builtin_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_bool__base_type_info_bool_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__is_builtin_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module52)
	init_entry(mercury____Index___hlds_goal__is_builtin_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__is_builtin_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r2 = (Integer) mercury_data_bool__base_type_info_bool_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_goal__is_builtin_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module53)
	init_entry(mercury____Compare___hlds_goal__is_builtin_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__is_builtin_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_bool__base_type_info_bool_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_bool__base_type_info_bool_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__is_builtin_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module54)
	init_entry(mercury____Unify___hlds_goal__case_0_0);
	init_label(mercury____Unify___hlds_goal__case_0_0_i2);
	init_label(mercury____Unify___hlds_goal__case_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__case_0_0);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___hlds_goal__case_0_0_i2,
		ENTRY(mercury____Unify___hlds_goal__case_0_0));
	}
Define_label(mercury____Unify___hlds_goal__case_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__case_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__case_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__case_0_0));
	}
Define_label(mercury____Unify___hlds_goal__case_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module55)
	init_entry(mercury____Index___hlds_goal__case_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__case_0_0);
	tailcall(STATIC(mercury____Index___hlds_goal_case_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_goal__case_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module56)
	init_entry(mercury____Compare___hlds_goal__case_0_0);
	init_label(mercury____Compare___hlds_goal__case_0_0_i4);
	init_label(mercury____Compare___hlds_goal__case_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__case_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___hlds_goal__case_0_0_i4,
		ENTRY(mercury____Compare___hlds_goal__case_0_0));
	}
Define_label(mercury____Compare___hlds_goal__case_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__case_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__case_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_goal__case_0_0_i3);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__case_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module57)
	init_entry(mercury____Unify___hlds_goal__stack_slots_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__stack_slots_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_goal__stack_slots_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module58)
	init_entry(mercury____Index___hlds_goal__stack_slots_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__stack_slots_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_goal__stack_slots_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module59)
	init_entry(mercury____Compare___hlds_goal__stack_slots_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__stack_slots_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_goal__stack_slots_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module60)
	init_entry(mercury____Unify___hlds_goal__follow_vars_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__follow_vars_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_goal__follow_vars_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module61)
	init_entry(mercury____Index___hlds_goal__follow_vars_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__follow_vars_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_goal__follow_vars_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module62)
	init_entry(mercury____Compare___hlds_goal__follow_vars_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__follow_vars_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_goal__follow_vars_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module63)
	init_entry(mercury____Unify___hlds_goal__store_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__store_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___hlds_goal__store_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module64)
	init_entry(mercury____Index___hlds_goal__store_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__store_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___hlds_goal__store_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module65)
	init_entry(mercury____Compare___hlds_goal__store_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__store_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___hlds_goal__store_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module66)
	init_entry(mercury____Unify___hlds_goal__unify_rhs_0_0);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1015);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i10);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i8);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i15);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i17);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i19);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1012);
	init_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unify_rhs_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1015);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1012);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1015);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___hlds_goal__unify_rhs_0_0_i10,
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_pred__pred_or_func_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_or_func_0_0),
		mercury____Unify___hlds_goal__unify_rhs_0_0_i15,
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__unify_rhs_0_0_i17,
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i17);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__unify_rhs_0_0_i19,
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(7)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1012);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_goal__unify_rhs_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module67)
	init_entry(mercury____Index___hlds_goal__unify_rhs_0_0);
	init_label(mercury____Index___hlds_goal__unify_rhs_0_0_i4);
	init_label(mercury____Index___hlds_goal__unify_rhs_0_0_i5);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unify_rhs_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_goal__unify_rhs_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_goal__unify_rhs_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_goal__unify_rhs_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_goal__unify_rhs_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module68)
	init_entry(mercury____Compare___hlds_goal__unify_rhs_0_0);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i2);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i3);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i4);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i6);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i12);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i19);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i18);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i15);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i28);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i34);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i40);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i46);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i9);
	init_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unify_rhs_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_goal__unify_rhs_0_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i2,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_goal__unify_rhs_0_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i3,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i12);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i1001);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i15);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i19,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i18);
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i15);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___hlds_pred__pred_or_func_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_or_func_0_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i28,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i34,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i40,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__unify_rhs_0_0_i46,
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_rhs_0_0_i20);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_rhs_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__unify_rhs_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module69)
	init_entry(mercury____Unify___hlds_goal__unification_0_0);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i7);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i1030);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i12);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i1029);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i16);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i18);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i20);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i14);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i26);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i28);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i30);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i32);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i24);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i35);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i1026);
	init_label(mercury____Unify___hlds_goal__unification_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unification_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1029);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1030);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1026);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1026);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i7,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i1030);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
		call_localret(STATIC(mercury____Unify___hlds_goal__uni_mode_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i12,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___hlds_goal__unification_0_0_i1029);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i14);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i16,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i18,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__unification_0_0_i20,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i14);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i24);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i26,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i26);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i28,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__unification_0_0_i30,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i30);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___hlds_goal__unification_0_0_i32,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i32);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	if (((Integer) detstackvar(4) != (Integer) detstackvar(8)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___hlds_goal__unification_0_0_i24);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__unification_0_0_i35,
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unification_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		ENTRY(mercury____Unify___hlds_goal__unification_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unification_0_0_i1026);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_goal__unification_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module70)
	init_entry(mercury____Index___hlds_goal__unification_0_0);
	init_label(mercury____Index___hlds_goal__unification_0_0_i5);
	init_label(mercury____Index___hlds_goal__unification_0_0_i4);
	init_label(mercury____Index___hlds_goal__unification_0_0_i6);
	init_label(mercury____Index___hlds_goal__unification_0_0_i7);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unification_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___hlds_goal__unification_0_0_i4);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Index___hlds_goal__unification_0_0_i5);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___hlds_goal__unification_0_0_i5);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___hlds_goal__unification_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_goal__unification_0_0_i6);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_goal__unification_0_0_i6);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_goal__unification_0_0_i7);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_goal__unification_0_0_i7);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module71)
	init_entry(mercury____Compare___hlds_goal__unification_0_0);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i2);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i3);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i4);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i6);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i17);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i18);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i16);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i13);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i26);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i12);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i36);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i42);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i48);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i32);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i60);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i66);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i72);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i78);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i56);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i90);
	init_label(mercury____Compare___hlds_goal__unification_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unification_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_goal__unification_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i2,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_goal__unification_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i3,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_goal__unification_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_goal__unification_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i12);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i17,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i17);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i16);
Define_label(mercury____Compare___hlds_goal__unification_0_0_i18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___hlds_goal__unification_0_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
		call_localret(STATIC(mercury____Compare___hlds_goal__uni_mode_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i26,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i26);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i32);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i36,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i36);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i42,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i42);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__unification_0_0_i48,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i48);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i32);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i56);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i60,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i60);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i66,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i66);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__unification_0_0_i72,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i72);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___hlds_goal__unification_0_0_i78,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i78);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i56);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__unification_0_0_i90,
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i90);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unification_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unification_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unification_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__unification_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module72)
	init_entry(mercury____Unify___hlds_goal__unify_context_0_0);
	init_label(mercury____Unify___hlds_goal__unify_context_0_0_i2);
	init_label(mercury____Unify___hlds_goal__unify_context_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unify_context_0_0);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury____Unify___hlds_goal__unify_main_context_0_0),
		mercury____Unify___hlds_goal__unify_context_0_0_i2,
		ENTRY(mercury____Unify___hlds_goal__unify_context_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_context_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unify_context_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_context_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__unify_context_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_context_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module73)
	init_entry(mercury____Index___hlds_goal__unify_context_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unify_context_0_0);
	tailcall(STATIC(mercury____Index___hlds_goal_unify_context_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_goal__unify_context_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module74)
	init_entry(mercury____Compare___hlds_goal__unify_context_0_0);
	init_label(mercury____Compare___hlds_goal__unify_context_0_0_i4);
	init_label(mercury____Compare___hlds_goal__unify_context_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unify_context_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury____Compare___hlds_goal__unify_main_context_0_0),
		mercury____Compare___hlds_goal__unify_context_0_0_i4,
		ENTRY(mercury____Compare___hlds_goal__unify_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_context_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_context_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_context_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_context_0_0_i3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__unify_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module75)
	init_entry(mercury____Unify___hlds_goal__unify_main_context_0_0);
	init_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1012);
	init_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i6);
	init_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i9);
	init_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1009);
	init_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
	init_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1011);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unify_main_context_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1012);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1009);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1012);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1011);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_pred__pred_call_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_call_id_0_0),
		mercury____Unify___hlds_goal__unify_main_context_0_0_i9,
		ENTRY(mercury____Unify___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i9);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_goal__unify_main_context_0_0_i1011);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module76)
	init_entry(mercury____Index___hlds_goal__unify_main_context_0_0);
	init_label(mercury____Index___hlds_goal__unify_main_context_0_0_i4);
	init_label(mercury____Index___hlds_goal__unify_main_context_0_0_i5);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unify_main_context_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___hlds_goal__unify_main_context_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_goal__unify_main_context_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___hlds_goal__unify_main_context_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___hlds_goal__unify_main_context_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module77)
	init_entry(mercury____Compare___hlds_goal__unify_main_context_0_0);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i2);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i3);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i4);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i6);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i12);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i14);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i20);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i19);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i9);
	init_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unify_main_context_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_goal__unify_main_context_0_0),
		mercury____Compare___hlds_goal__unify_main_context_0_0_i2,
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_goal__unify_main_context_0_0),
		mercury____Compare___hlds_goal__unify_main_context_0_0_i3,
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i12);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i14);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i14);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___hlds_pred__pred_call_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_call_id_0_0),
		mercury____Compare___hlds_goal__unify_main_context_0_0_i20,
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__unify_main_context_0_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__unify_main_context_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__unify_main_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module78)
	init_entry(mercury____Unify___hlds_goal__unify_sub_context_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unify_sub_context_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__unify_sub_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module79)
	init_entry(mercury____Index___hlds_goal__unify_sub_context_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unify_sub_context_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_goal__unify_sub_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module80)
	init_entry(mercury____Compare___hlds_goal__unify_sub_context_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unify_sub_context_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__unify_sub_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module81)
	init_entry(mercury____Unify___hlds_goal__unify_sub_contexts_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unify_sub_contexts_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__unify_sub_contexts_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module82)
	init_entry(mercury____Index___hlds_goal__unify_sub_contexts_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unify_sub_contexts_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2);
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___hlds_goal__unify_sub_contexts_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module83)
	init_entry(mercury____Compare___hlds_goal__unify_sub_contexts_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unify_sub_contexts_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_2);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__unify_sub_contexts_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module84)
	init_entry(mercury____Unify___hlds_goal__call_unify_context_0_0);
	init_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i2);
	init_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i4);
	init_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__call_unify_context_0_0);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___hlds_goal__call_unify_context_0_0_i2,
		ENTRY(mercury____Unify___hlds_goal__call_unify_context_0_0));
	}
Define_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__call_unify_context_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__call_unify_context_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury____Unify___hlds_goal__unify_rhs_0_0),
		mercury____Unify___hlds_goal__call_unify_context_0_0_i4,
		ENTRY(mercury____Unify___hlds_goal__call_unify_context_0_0));
	}
Define_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__call_unify_context_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__call_unify_context_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury____Unify___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Unify___hlds_goal__call_unify_context_0_0));
	}
Define_label(mercury____Unify___hlds_goal__call_unify_context_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module85)
	init_entry(mercury____Index___hlds_goal__call_unify_context_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__call_unify_context_0_0);
	tailcall(STATIC(mercury____Index___hlds_goal_call_unify_context_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_goal__call_unify_context_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module86)
	init_entry(mercury____Compare___hlds_goal__call_unify_context_0_0);
	init_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i4);
	init_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i5);
	init_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i3);
	init_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__call_unify_context_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___hlds_goal__call_unify_context_0_0_i4,
		ENTRY(mercury____Compare___hlds_goal__call_unify_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__call_unify_context_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__call_unify_context_0_0_i3);
Define_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury____Compare___hlds_goal__unify_rhs_0_0),
		mercury____Compare___hlds_goal__call_unify_context_0_0_i10,
		ENTRY(mercury____Compare___hlds_goal__call_unify_context_0_0));
	}
Define_label(mercury____Compare___hlds_goal__call_unify_context_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__call_unify_context_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__call_unify_context_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury____Compare___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Compare___hlds_goal__call_unify_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module87)
	init_entry(mercury____Unify___hlds_goal__hlds__goals_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__hlds__goals_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goals_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module88)
	init_entry(mercury____Index___hlds_goal__hlds__goals_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__hlds__goals_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___hlds_goal__hlds__goals_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module89)
	init_entry(mercury____Compare___hlds_goal__hlds__goals_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__hlds__goals_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_0);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goals_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module90)
	init_entry(mercury____Unify___hlds_goal__hlds__goal_info_0_0);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i2);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i4);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i6);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i8);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i10);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i12);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i14);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i16);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i18);
	init_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__hlds__goal_info_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(21, "__Unify__");
	detstackvar(21) = (Integer) succip;
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i2,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i4,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i6,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i8,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	if (((Integer) detstackvar(4) != (Integer) detstackvar(14)))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___instmap__instmap_delta_0_0);
	call_localret(ENTRY(mercury____Unify___instmap__instmap_delta_0_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i10,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i12,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i14,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i16,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__hlds__goal_info_0_0_i18,
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	{
		tailcall(STATIC(mercury____Unify___hlds_goal__resume_point_0_0),
		ENTRY(mercury____Unify___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Unify___hlds_goal__hlds__goal_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module91)
	init_entry(mercury____Index___hlds_goal__hlds__goal_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__hlds__goal_info_0_0);
	tailcall(STATIC(mercury____Index___hlds_goal_hlds__goal_info_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_goal__hlds__goal_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module92)
	init_entry(mercury____Compare___hlds_goal__hlds__goal_info_0_0);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i4);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i3);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i10);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i16);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i22);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i28);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i34);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i40);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i46);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i52);
	init_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i58);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__hlds__goal_info_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(21, "__Compare__");
	detstackvar(21) = (Integer) succip;
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i4,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i3);
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	proceed();
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i10,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i16,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i22,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i28,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Compare___instmap__instmap_delta_0_0);
	call_localret(ENTRY(mercury____Compare___instmap__instmap_delta_0_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i34,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i40,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i46,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_hlds_goal__common_3);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i52,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i52);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_goal_feature_0;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__hlds__goal_info_0_0_i58,
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
Define_label(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i58);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__hlds__goal_info_0_0_i5);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	{
		tailcall(STATIC(mercury____Compare___hlds_goal__resume_point_0_0),
		ENTRY(mercury____Compare___hlds_goal__hlds__goal_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module93)
	init_entry(mercury____Unify___hlds_goal__goal_feature_0_0);
	init_label(mercury____Unify___hlds_goal__goal_feature_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__goal_feature_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_goal__goal_feature_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_goal__goal_feature_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module94)
	init_entry(mercury____Index___hlds_goal__goal_feature_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__goal_feature_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_goal__goal_feature_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module95)
	init_entry(mercury____Compare___hlds_goal__goal_feature_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__goal_feature_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__goal_feature_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module96)
	init_entry(mercury____Unify___hlds_goal__resume_point_0_0);
	init_label(mercury____Unify___hlds_goal__resume_point_0_0_i1009);
	init_label(mercury____Unify___hlds_goal__resume_point_0_0_i6);
	init_label(mercury____Unify___hlds_goal__resume_point_0_0_i1006);
	init_label(mercury____Unify___hlds_goal__resume_point_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__resume_point_0_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_goal__resume_point_0_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_goal__resume_point_0_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___hlds_goal__resume_point_0_0_i1009);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___hlds_goal__resume_point_0_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___hlds_goal__resume_point_0_0_i6,
		ENTRY(mercury____Unify___hlds_goal__resume_point_0_0));
	}
Define_label(mercury____Unify___hlds_goal__resume_point_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__resume_point_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__resume_point_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___hlds_goal__resume_point_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___hlds_goal__resume_point_0_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_goal__resume_point_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module97)
	init_entry(mercury____Index___hlds_goal__resume_point_0_0);
	init_label(mercury____Index___hlds_goal__resume_point_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__resume_point_0_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___hlds_goal__resume_point_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___hlds_goal__resume_point_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module98)
	init_entry(mercury____Compare___hlds_goal__resume_point_0_0);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i2);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i3);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i4);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i6);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i11);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i16);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i15);
	init_label(mercury____Compare___hlds_goal__resume_point_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__resume_point_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___hlds_goal__resume_point_0_0),
		mercury____Compare___hlds_goal__resume_point_0_0_i2,
		ENTRY(mercury____Compare___hlds_goal__resume_point_0_0));
	}
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__resume_point_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___hlds_goal__resume_point_0_0),
		mercury____Compare___hlds_goal__resume_point_0_0_i3,
		ENTRY(mercury____Compare___hlds_goal__resume_point_0_0));
	}
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__resume_point_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__resume_point_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___hlds_goal__resume_point_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_goal__resume_point_0_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_goal__resume_point_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i11);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___hlds_goal__resume_point_0_0_i9);
	tempr2 = (Integer) detstackvar(1);
	r2 = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___hlds_goal__resume_point_0_0_i16,
		ENTRY(mercury____Compare___hlds_goal__resume_point_0_0));
	}
	}
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__resume_point_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__resume_point_0_0_i15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i15);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__resume_point_0_0));
	}
Define_label(mercury____Compare___hlds_goal__resume_point_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___hlds_goal__resume_point_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module99)
	init_entry(mercury____Unify___hlds_goal__resume_locs_0_0);
	init_label(mercury____Unify___hlds_goal__resume_locs_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__resume_locs_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___hlds_goal__resume_locs_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___hlds_goal__resume_locs_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module100)
	init_entry(mercury____Index___hlds_goal__resume_locs_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__resume_locs_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___hlds_goal__resume_locs_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module101)
	init_entry(mercury____Compare___hlds_goal__resume_locs_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__resume_locs_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___hlds_goal__resume_locs_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module102)
	init_entry(mercury____Unify___hlds_goal__unify_mode_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__unify_mode_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__unify_mode_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module103)
	init_entry(mercury____Index___hlds_goal__unify_mode_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__unify_mode_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___hlds_goal__unify_mode_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module104)
	init_entry(mercury____Compare___hlds_goal__unify_mode_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__unify_mode_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__unify_mode_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module105)
	init_entry(mercury____Unify___hlds_goal__uni_mode_0_0);
	init_label(mercury____Unify___hlds_goal__uni_mode_0_0_i2);
	init_label(mercury____Unify___hlds_goal__uni_mode_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___hlds_goal__uni_mode_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___hlds_goal__uni_mode_0_0_i2,
		ENTRY(mercury____Unify___hlds_goal__uni_mode_0_0));
	}
Define_label(mercury____Unify___hlds_goal__uni_mode_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___hlds_goal__uni_mode_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___hlds_goal__uni_mode_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___hlds_goal__uni_mode_0_0));
	}
Define_label(mercury____Unify___hlds_goal__uni_mode_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module106)
	init_entry(mercury____Index___hlds_goal__uni_mode_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___hlds_goal__uni_mode_0_0);
	tailcall(STATIC(mercury____Index___hlds_goal_uni_mode_0__ua10000_2_0),
		ENTRY(mercury____Index___hlds_goal__uni_mode_0_0));
END_MODULE

BEGIN_MODULE(mercury__hlds_goal_module107)
	init_entry(mercury____Compare___hlds_goal__uni_mode_0_0);
	init_label(mercury____Compare___hlds_goal__uni_mode_0_0_i4);
	init_label(mercury____Compare___hlds_goal__uni_mode_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___hlds_goal__uni_mode_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___hlds_goal__uni_mode_0_0_i4,
		ENTRY(mercury____Compare___hlds_goal__uni_mode_0_0));
	}
Define_label(mercury____Compare___hlds_goal__uni_mode_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___hlds_goal__uni_mode_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___hlds_goal__uni_mode_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___hlds_goal__uni_mode_0_0_i3);
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___hlds_goal__uni_mode_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__hlds_goal_bunch_0(void)
{
	mercury__hlds_goal_module0();
	mercury__hlds_goal_module1();
	mercury__hlds_goal_module2();
	mercury__hlds_goal_module3();
	mercury__hlds_goal_module4();
	mercury__hlds_goal_module5();
	mercury__hlds_goal_module6();
	mercury__hlds_goal_module7();
	mercury__hlds_goal_module8();
	mercury__hlds_goal_module9();
	mercury__hlds_goal_module10();
	mercury__hlds_goal_module11();
	mercury__hlds_goal_module12();
	mercury__hlds_goal_module13();
	mercury__hlds_goal_module14();
	mercury__hlds_goal_module15();
	mercury__hlds_goal_module16();
	mercury__hlds_goal_module17();
	mercury__hlds_goal_module18();
	mercury__hlds_goal_module19();
	mercury__hlds_goal_module20();
	mercury__hlds_goal_module21();
	mercury__hlds_goal_module22();
	mercury__hlds_goal_module23();
	mercury__hlds_goal_module24();
	mercury__hlds_goal_module25();
	mercury__hlds_goal_module26();
	mercury__hlds_goal_module27();
	mercury__hlds_goal_module28();
	mercury__hlds_goal_module29();
	mercury__hlds_goal_module30();
	mercury__hlds_goal_module31();
	mercury__hlds_goal_module32();
	mercury__hlds_goal_module33();
	mercury__hlds_goal_module34();
	mercury__hlds_goal_module35();
	mercury__hlds_goal_module36();
	mercury__hlds_goal_module37();
	mercury__hlds_goal_module38();
	mercury__hlds_goal_module39();
	mercury__hlds_goal_module40();
}

static void mercury__hlds_goal_bunch_1(void)
{
	mercury__hlds_goal_module41();
	mercury__hlds_goal_module42();
	mercury__hlds_goal_module43();
	mercury__hlds_goal_module44();
	mercury__hlds_goal_module45();
	mercury__hlds_goal_module46();
	mercury__hlds_goal_module47();
	mercury__hlds_goal_module48();
	mercury__hlds_goal_module49();
	mercury__hlds_goal_module50();
	mercury__hlds_goal_module51();
	mercury__hlds_goal_module52();
	mercury__hlds_goal_module53();
	mercury__hlds_goal_module54();
	mercury__hlds_goal_module55();
	mercury__hlds_goal_module56();
	mercury__hlds_goal_module57();
	mercury__hlds_goal_module58();
	mercury__hlds_goal_module59();
	mercury__hlds_goal_module60();
	mercury__hlds_goal_module61();
	mercury__hlds_goal_module62();
	mercury__hlds_goal_module63();
	mercury__hlds_goal_module64();
	mercury__hlds_goal_module65();
	mercury__hlds_goal_module66();
	mercury__hlds_goal_module67();
	mercury__hlds_goal_module68();
	mercury__hlds_goal_module69();
	mercury__hlds_goal_module70();
	mercury__hlds_goal_module71();
	mercury__hlds_goal_module72();
	mercury__hlds_goal_module73();
	mercury__hlds_goal_module74();
	mercury__hlds_goal_module75();
	mercury__hlds_goal_module76();
	mercury__hlds_goal_module77();
	mercury__hlds_goal_module78();
	mercury__hlds_goal_module79();
	mercury__hlds_goal_module80();
	mercury__hlds_goal_module81();
}

static void mercury__hlds_goal_bunch_2(void)
{
	mercury__hlds_goal_module82();
	mercury__hlds_goal_module83();
	mercury__hlds_goal_module84();
	mercury__hlds_goal_module85();
	mercury__hlds_goal_module86();
	mercury__hlds_goal_module87();
	mercury__hlds_goal_module88();
	mercury__hlds_goal_module89();
	mercury__hlds_goal_module90();
	mercury__hlds_goal_module91();
	mercury__hlds_goal_module92();
	mercury__hlds_goal_module93();
	mercury__hlds_goal_module94();
	mercury__hlds_goal_module95();
	mercury__hlds_goal_module96();
	mercury__hlds_goal_module97();
	mercury__hlds_goal_module98();
	mercury__hlds_goal_module99();
	mercury__hlds_goal_module100();
	mercury__hlds_goal_module101();
	mercury__hlds_goal_module102();
	mercury__hlds_goal_module103();
	mercury__hlds_goal_module104();
	mercury__hlds_goal_module105();
	mercury__hlds_goal_module106();
	mercury__hlds_goal_module107();
}

#endif

void mercury__hlds_goal__init(void); /* suppress gcc warning */
void mercury__hlds_goal__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__hlds_goal_bunch_0();
	mercury__hlds_goal_bunch_1();
	mercury__hlds_goal_bunch_2();
#endif
}
