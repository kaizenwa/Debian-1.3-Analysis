/*
** Automatically generated from `special_pred.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__special_pred__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__special_pred__special_pred_info_6_0);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1032);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1031);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1030);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1029);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1028);
Declare_label(mercury__special_pred__special_pred_info_6_0_i3);
Declare_label(mercury__special_pred__special_pred_info_6_0_i4);
Declare_label(mercury__special_pred__special_pred_info_6_0_i5);
Declare_label(mercury__special_pred__special_pred_info_6_0_i6);
Declare_label(mercury__special_pred__special_pred_info_6_0_i7);
Declare_label(mercury__special_pred__special_pred_info_6_0_i8);
Declare_label(mercury__special_pred__special_pred_info_6_0_i9);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1021);
Declare_label(mercury__special_pred__special_pred_info_6_0_i11);
Declare_label(mercury__special_pred__special_pred_info_6_0_i12);
Declare_label(mercury__special_pred__special_pred_info_6_0_i13);
Declare_label(mercury__special_pred__special_pred_info_6_0_i14);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1027);
Declare_label(mercury__special_pred__special_pred_info_6_0_i16);
Declare_label(mercury__special_pred__special_pred_info_6_0_i17);
Declare_label(mercury__special_pred__special_pred_info_6_0_i18);
Declare_label(mercury__special_pred__special_pred_info_6_0_i19);
Declare_label(mercury__special_pred__special_pred_info_6_0_i20);
Declare_label(mercury__special_pred__special_pred_info_6_0_i21);
Declare_label(mercury__special_pred__special_pred_info_6_0_i22);
Define_extern_entry(mercury__special_pred__special_pred_name_arity_4_1);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i3);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i5);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i7);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i9);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i1);
Define_extern_entry(mercury__special_pred__special_pred_name_arity_4_2);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i3);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i5);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i7);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i9);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i1);
Define_extern_entry(mercury__special_pred__special_pred_name_arity_4_0);
Define_extern_entry(mercury__special_pred__special_pred_mode_num_2_0);
Define_extern_entry(mercury__special_pred__special_pred_list_1_0);
Define_extern_entry(mercury__special_pred__special_pred_get_type_3_0);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i4);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i1001);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i7);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i6);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i11);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i10);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i13);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i18);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i1);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i1000);
Declare_static(mercury__special_pred__in_mode_1_0);
Declare_static(mercury__special_pred__out_mode_1_0);
Define_extern_entry(mercury____Unify___special_pred__special_pred_map_0_0);
Define_extern_entry(mercury____Index___special_pred__special_pred_map_0_0);
Define_extern_entry(mercury____Compare___special_pred__special_pred_map_0_0);
Define_extern_entry(mercury____Unify___special_pred__special_pred_0_0);
Define_extern_entry(mercury____Index___special_pred__special_pred_0_0);
Define_extern_entry(mercury____Compare___special_pred__special_pred_0_0);
Define_extern_entry(mercury____Unify___special_pred__special_pred_id_0_0);
Declare_label(mercury____Unify___special_pred__special_pred_id_0_0_i1);
Define_extern_entry(mercury____Index___special_pred__special_pred_id_0_0);
Define_extern_entry(mercury____Compare___special_pred__special_pred_id_0_0);

extern Word * mercury_data_special_pred__base_type_layout_special_pred_0[];
Word * mercury_data_special_pred__base_type_info_special_pred_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___special_pred__special_pred_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___special_pred__special_pred_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___special_pred__special_pred_0_0),
	(Word *) (Integer) mercury_data_special_pred__base_type_layout_special_pred_0
};

extern Word * mercury_data_special_pred__base_type_layout_special_pred_id_0[];
Word * mercury_data_special_pred__base_type_info_special_pred_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___special_pred__special_pred_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___special_pred__special_pred_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___special_pred__special_pred_id_0_0),
	(Word *) (Integer) mercury_data_special_pred__base_type_layout_special_pred_id_0
};

extern Word * mercury_data_special_pred__base_type_layout_special_pred_map_0[];
Word * mercury_data_special_pred__base_type_info_special_pred_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___special_pred__special_pred_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___special_pred__special_pred_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___special_pred__special_pred_map_0_0),
	(Word *) (Integer) mercury_data_special_pred__base_type_layout_special_pred_map_0
};

extern Word * mercury_data_special_pred__common_16[];
Word * mercury_data_special_pred__base_type_layout_special_pred_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_16)
};

extern Word * mercury_data_special_pred__common_17[];
Word * mercury_data_special_pred__base_type_layout_special_pred_id_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_17)
};

extern Word * mercury_data_special_pred__common_18[];
Word * mercury_data_special_pred__base_type_layout_special_pred_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_special_pred__common_18)
};

Word * mercury_data_special_pred__common_0[] = {
	(Word *) string_const("int", 3)
};

Word * mercury_data_special_pred__common_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_0),
	(Word *) ((Integer) 0)
};

Word * mercury_data_special_pred__common_2[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("comparison_result", 17)
};

Word * mercury_data_special_pred__common_3[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_2),
	(Word *) ((Integer) 0)
};

Word * mercury_data_special_pred__common_4[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("term", 4)
};

Word * mercury_data_special_pred__common_5[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_4),
	(Word *) ((Integer) 0)
};

Word mercury_data_special_pred__common_6[] = {
	((Integer) 2),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_special_pred__common_7[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_6)
};

Word * mercury_data_special_pred__common_8[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_7)
};

Word * mercury_data_special_pred__common_9[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("in", 2)
};

Word * mercury_data_special_pred__common_10[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_special_pred__common_11[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("out", 3)
};

Word * mercury_data_special_pred__common_12[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_special_pred__common_13[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_special_pred__common_14[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_special_pred__base_type_info_special_pred_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_13)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_special_pred__common_15[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_14),
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_special_pred__common_16[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_15)
};

Word * mercury_data_special_pred__common_17[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 5),
	(Word *) string_const("unify", 5),
	(Word *) string_const("index", 5),
	(Word *) string_const("compare", 7),
	(Word *) string_const("term_to_type", 12),
	(Word *) string_const("type_to_term", 12)
};

Word * mercury_data_special_pred__common_18[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_14)
};

BEGIN_MODULE(mercury__special_pred_module0)
	init_entry(mercury__special_pred__special_pred_info_6_0);
	init_label(mercury__special_pred__special_pred_info_6_0_i1032);
	init_label(mercury__special_pred__special_pred_info_6_0_i1031);
	init_label(mercury__special_pred__special_pred_info_6_0_i1030);
	init_label(mercury__special_pred__special_pred_info_6_0_i1029);
	init_label(mercury__special_pred__special_pred_info_6_0_i1028);
	init_label(mercury__special_pred__special_pred_info_6_0_i3);
	init_label(mercury__special_pred__special_pred_info_6_0_i4);
	init_label(mercury__special_pred__special_pred_info_6_0_i5);
	init_label(mercury__special_pred__special_pred_info_6_0_i6);
	init_label(mercury__special_pred__special_pred_info_6_0_i7);
	init_label(mercury__special_pred__special_pred_info_6_0_i8);
	init_label(mercury__special_pred__special_pred_info_6_0_i9);
	init_label(mercury__special_pred__special_pred_info_6_0_i1021);
	init_label(mercury__special_pred__special_pred_info_6_0_i11);
	init_label(mercury__special_pred__special_pred_info_6_0_i12);
	init_label(mercury__special_pred__special_pred_info_6_0_i13);
	init_label(mercury__special_pred__special_pred_info_6_0_i14);
	init_label(mercury__special_pred__special_pred_info_6_0_i1027);
	init_label(mercury__special_pred__special_pred_info_6_0_i16);
	init_label(mercury__special_pred__special_pred_info_6_0_i17);
	init_label(mercury__special_pred__special_pred_info_6_0_i18);
	init_label(mercury__special_pred__special_pred_info_6_0_i19);
	init_label(mercury__special_pred__special_pred_info_6_0_i20);
	init_label(mercury__special_pred__special_pred_info_6_0_i21);
	init_label(mercury__special_pred__special_pred_info_6_0_i22);
BEGIN_CODE

/* code for predicate 'special_pred_info'/6 in mode 0 */
Define_entry(mercury__special_pred__special_pred_info_6_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__special_pred__special_pred_info_6_0_i1032) AND
		LABEL(mercury__special_pred__special_pred_info_6_0_i1031) AND
		LABEL(mercury__special_pred__special_pred_info_6_0_i1030) AND
		LABEL(mercury__special_pred__special_pred_info_6_0_i1029) AND
		LABEL(mercury__special_pred__special_pred_info_6_0_i1028));
Define_label(mercury__special_pred__special_pred_info_6_0_i1032);
	incr_sp_push_msg(3, "special_pred_info");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i3);
Define_label(mercury__special_pred__special_pred_info_6_0_i1031);
	incr_sp_push_msg(3, "special_pred_info");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i6);
Define_label(mercury__special_pred__special_pred_info_6_0_i1030);
	incr_sp_push_msg(3, "special_pred_info");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i1021);
Define_label(mercury__special_pred__special_pred_info_6_0_i1029);
	incr_sp_push_msg(3, "special_pred_info");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i1027);
Define_label(mercury__special_pred__special_pred_info_6_0_i1028);
	incr_sp_push_msg(3, "special_pred_info");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i19);
Define_label(mercury__special_pred__special_pred_info_6_0_i3);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i4,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i4);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	detstackvar(2) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i5,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i5);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = (Integer) r1;
	r1 = string_const("__Unify__", 9);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = ((Integer) 1);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i6);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__special_pred__special_pred_info_6_0_i7,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i7);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i8,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i8);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	detstackvar(2) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__out_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i9,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i9);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = (Integer) r1;
	r1 = string_const("__Index__", 9);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = ((Integer) 0);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i1021);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_3);
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__special_pred__special_pred_info_6_0_i11,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i11);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i12,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i12);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	detstackvar(2) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i13,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i13);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__out_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i14,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i14);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = (Integer) r1;
	r1 = string_const("__Compare__", 11);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__special_pred__special_pred_info_6_0_i1027);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_5);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__special_pred__special_pred_info_6_0_i16,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i16);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i17,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i17);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	detstackvar(2) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__out_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i18,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i18);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = (Integer) r1;
	r1 = string_const("__Term_To_Type__", 16);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = ((Integer) 1);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i19);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_5);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__special_pred__special_pred_info_6_0_i20,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i20);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i21,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i21);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	detstackvar(2) = (Integer) r1;
	call_localret(STATIC(mercury__special_pred__out_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i22,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i22);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = (Integer) r1;
	r1 = string_const("__Type_To_Term__", 16);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = ((Integer) 0);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module1)
	init_entry(mercury__special_pred__special_pred_name_arity_4_1);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i3);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i5);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i7);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i9);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i1);
BEGIN_CODE

/* code for predicate 'special_pred_name_arity'/4 in mode 1 */
Define_entry(mercury__special_pred__special_pred_name_arity_4_1);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("compare", 7)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i3);
	if (((Integer) r2 != ((Integer) 3)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = ((Integer) 2);
	r3 = string_const("__Compare__", 11);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i3);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("index", 5)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i5);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = ((Integer) 1);
	r3 = string_const("__Index__", 9);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i5);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("term_to_type", 12)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i7);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = ((Integer) 3);
	r3 = string_const("__Term_To_Type__", 16);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i7);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("type_to_term", 12)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i9);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = ((Integer) 4);
	r3 = string_const("__Type_To_Term__", 16);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i9);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("unify", 5)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = ((Integer) 0);
	r3 = string_const("__Unify__", 9);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module2)
	init_entry(mercury__special_pred__special_pred_name_arity_4_2);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i3);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i5);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i7);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i9);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i1);
BEGIN_CODE

/* code for predicate 'special_pred_name_arity'/4 in mode 2 */
Define_entry(mercury__special_pred__special_pred_name_arity_4_2);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("__Compare__", 11)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i3);
	if (((Integer) r2 != ((Integer) 3)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = ((Integer) 2);
	r3 = string_const("compare", 7);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i3);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("__Index__", 9)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i5);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = ((Integer) 1);
	r3 = string_const("index", 5);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i5);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("__Term_To_Type__", 16)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i7);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = ((Integer) 3);
	r3 = string_const("term_to_type", 12);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i7);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("__Type_To_Term__", 16)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i9);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = ((Integer) 4);
	r3 = string_const("type_to_term", 12);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i9);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("__Unify__", 9)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = ((Integer) 0);
	r3 = string_const("unify", 5);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module3)
	init_entry(mercury__special_pred__special_pred_name_arity_4_0);
BEGIN_CODE

/* code for predicate 'special_pred_name_arity'/4 in mode 0 */
Define_entry(mercury__special_pred__special_pred_name_arity_4_0);
	{
	static const Word * mercury_const_2[] = {
		(Word *) string_const("__Unify__", 9),
		(Word *) string_const("__Index__", 9),
		(Word *) string_const("__Compare__", 11),
		(Word *) string_const("__Term_To_Type__", 16),
		(Word *) string_const("__Type_To_Term__", 16)
	};
	r2 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_2), (Integer) r1);
	}
	{
	static const Word mercury_const_3[] = {
		((Integer) 2),
		((Integer) 2),
		((Integer) 3),
		((Integer) 2),
		((Integer) 2)
	};
	r3 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_3), (Integer) r1);
	}
	{
	static const Word * mercury_const_1[] = {
		(Word *) string_const("unify", 5),
		(Word *) string_const("index", 5),
		(Word *) string_const("compare", 7),
		(Word *) string_const("term_to_type", 12),
		(Word *) string_const("type_to_term", 12)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module4)
	init_entry(mercury__special_pred__special_pred_mode_num_2_0);
BEGIN_CODE

/* code for predicate 'special_pred_mode_num'/2 in mode 0 */
Define_entry(mercury__special_pred__special_pred_mode_num_2_0);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 10000),
		((Integer) 10000),
		((Integer) 0),
		((Integer) 10000)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module5)
	init_entry(mercury__special_pred__special_pred_list_1_0);
BEGIN_CODE

/* code for predicate 'special_pred_list'/1 in mode 0 */
Define_entry(mercury__special_pred__special_pred_list_1_0);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module6)
	init_entry(mercury__special_pred__special_pred_get_type_3_0);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i4);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i1001);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i7);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i6);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i11);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i10);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i13);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i18);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i1);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i1000);
BEGIN_CODE

/* code for predicate 'special_pred_get_type'/3 in mode 0 */
Define_entry(mercury__special_pred__special_pred_get_type_3_0);
	if ((strcmp((char *)(Integer) r2, (char *)string_const("__Compare__", 11)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1001);
	r2 = (Integer) r3;
	incr_sp_push_msg(1, "special_pred_get_type");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i4,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
	}
Define_label(mercury__special_pred__special_pred_get_type_3_0_i4);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1000);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i1001);
	incr_sp_push_msg(1, "special_pred_get_type");
	detstackvar(1) = (Integer) succip;
	if ((strcmp((char *)(Integer) r2, (char *)string_const("__Index__", 9)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i6);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i7,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
	}
Define_label(mercury__special_pred__special_pred_get_type_3_0_i7);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1000);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i6);
	if ((strcmp((char *)(Integer) r2, (char *)string_const("__Term_To_Type__", 16)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i10);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i11,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
	}
Define_label(mercury__special_pred__special_pred_get_type_3_0_i11);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1000);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i10);
	if ((strcmp((char *)(Integer) r2, (char *)string_const("__Type_To_Term__", 16)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i13);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i7,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
	}
Define_label(mercury__special_pred__special_pred_get_type_3_0_i13);
	if ((strcmp((char *)(Integer) r2, (char *)string_const("__Unify__", 9)) !=0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i18,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
	}
Define_label(mercury__special_pred__special_pred_get_type_3_0_i18);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1000);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module7)
	init_entry(mercury__special_pred__in_mode_1_0);
BEGIN_CODE

/* code for predicate 'in_mode'/1 in mode 0 */
Define_static(mercury__special_pred__in_mode_1_0);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module8)
	init_entry(mercury__special_pred__out_mode_1_0);
BEGIN_CODE

/* code for predicate 'out_mode'/1 in mode 0 */
Define_static(mercury__special_pred__out_mode_1_0);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_special_pred__common_12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module9)
	init_entry(mercury____Unify___special_pred__special_pred_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___special_pred__special_pred_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_14);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___special_pred__special_pred_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module10)
	init_entry(mercury____Index___special_pred__special_pred_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___special_pred__special_pred_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_14);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___special_pred__special_pred_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module11)
	init_entry(mercury____Compare___special_pred__special_pred_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___special_pred__special_pred_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_14);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___special_pred__special_pred_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module12)
	init_entry(mercury____Unify___special_pred__special_pred_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___special_pred__special_pred_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_special_pred__base_type_info_special_pred_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_13);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___special_pred__special_pred_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module13)
	init_entry(mercury____Index___special_pred__special_pred_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___special_pred__special_pred_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_special_pred__base_type_info_special_pred_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_13);
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___special_pred__special_pred_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module14)
	init_entry(mercury____Compare___special_pred__special_pred_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___special_pred__special_pred_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_special_pred__base_type_info_special_pred_id_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_special_pred__common_13);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___special_pred__special_pred_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module15)
	init_entry(mercury____Unify___special_pred__special_pred_id_0_0);
	init_label(mercury____Unify___special_pred__special_pred_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___special_pred__special_pred_id_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___special_pred__special_pred_id_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___special_pred__special_pred_id_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__special_pred_module16)
	init_entry(mercury____Index___special_pred__special_pred_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___special_pred__special_pred_id_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___special_pred__special_pred_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__special_pred_module17)
	init_entry(mercury____Compare___special_pred__special_pred_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___special_pred__special_pred_id_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___special_pred__special_pred_id_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__special_pred_bunch_0(void)
{
	mercury__special_pred_module0();
	mercury__special_pred_module1();
	mercury__special_pred_module2();
	mercury__special_pred_module3();
	mercury__special_pred_module4();
	mercury__special_pred_module5();
	mercury__special_pred_module6();
	mercury__special_pred_module7();
	mercury__special_pred_module8();
	mercury__special_pred_module9();
	mercury__special_pred_module10();
	mercury__special_pred_module11();
	mercury__special_pred_module12();
	mercury__special_pred_module13();
	mercury__special_pred_module14();
	mercury__special_pred_module15();
	mercury__special_pred_module16();
	mercury__special_pred_module17();
}

#endif

void mercury__special_pred__init(void); /* suppress gcc warning */
void mercury__special_pred__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__special_pred_bunch_0();
#endif
}
