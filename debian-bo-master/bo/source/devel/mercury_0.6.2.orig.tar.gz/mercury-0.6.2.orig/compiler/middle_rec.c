/*
** Automatically generated from `middle_rec.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__middle_rec__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__middle_rec__generate_ite__ua10000_10_0);
Declare_label(mercury__middle_rec__generate_ite__ua10000_10_0_i4);
Declare_label(mercury__middle_rec__generate_ite__ua10000_10_0_i3);
Declare_label(mercury__middle_rec__generate_ite__ua10000_10_0_i6);
Define_extern_entry(mercury__middle_rec__match_and_generate_4_0);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i10);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i12);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i14);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i9);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i16);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i18);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i1003);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i26);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i28);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i30);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i32);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i34);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i25);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i35);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i37);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i39);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i1);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i1001);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i1002);
Declare_static(mercury__middle_rec__generate_switch_9_0);
Declare_label(mercury__middle_rec__generate_switch_9_0_i2);
Declare_label(mercury__middle_rec__generate_switch_9_0_i3);
Declare_label(mercury__middle_rec__generate_switch_9_0_i4);
Declare_label(mercury__middle_rec__generate_switch_9_0_i5);
Declare_label(mercury__middle_rec__generate_switch_9_0_i6);
Declare_label(mercury__middle_rec__generate_switch_9_0_i7);
Declare_label(mercury__middle_rec__generate_switch_9_0_i8);
Declare_label(mercury__middle_rec__generate_switch_9_0_i9);
Declare_label(mercury__middle_rec__generate_switch_9_0_i10);
Declare_label(mercury__middle_rec__generate_switch_9_0_i11);
Declare_label(mercury__middle_rec__generate_switch_9_0_i12);
Declare_label(mercury__middle_rec__generate_switch_9_0_i13);
Declare_label(mercury__middle_rec__generate_switch_9_0_i14);
Declare_label(mercury__middle_rec__generate_switch_9_0_i15);
Declare_label(mercury__middle_rec__generate_switch_9_0_i16);
Declare_label(mercury__middle_rec__generate_switch_9_0_i17);
Declare_label(mercury__middle_rec__generate_switch_9_0_i18);
Declare_label(mercury__middle_rec__generate_switch_9_0_i19);
Declare_label(mercury__middle_rec__generate_switch_9_0_i20);
Declare_label(mercury__middle_rec__generate_switch_9_0_i21);
Declare_label(mercury__middle_rec__generate_switch_9_0_i22);
Declare_label(mercury__middle_rec__generate_switch_9_0_i23);
Declare_label(mercury__middle_rec__generate_switch_9_0_i24);
Declare_label(mercury__middle_rec__generate_switch_9_0_i25);
Declare_label(mercury__middle_rec__generate_switch_9_0_i26);
Declare_label(mercury__middle_rec__generate_switch_9_0_i27);
Declare_label(mercury__middle_rec__generate_switch_9_0_i28);
Declare_label(mercury__middle_rec__generate_switch_9_0_i29);
Declare_label(mercury__middle_rec__generate_switch_9_0_i30);
Declare_label(mercury__middle_rec__generate_switch_9_0_i31);
Declare_label(mercury__middle_rec__generate_switch_9_0_i32);
Declare_label(mercury__middle_rec__generate_switch_9_0_i33);
Declare_label(mercury__middle_rec__generate_switch_9_0_i34);
Declare_label(mercury__middle_rec__generate_switch_9_0_i35);
Declare_label(mercury__middle_rec__generate_switch_9_0_i36);
Declare_label(mercury__middle_rec__generate_switch_9_0_i37);
Declare_label(mercury__middle_rec__generate_switch_9_0_i38);
Declare_label(mercury__middle_rec__generate_switch_9_0_i39);
Declare_label(mercury__middle_rec__generate_switch_9_0_i42);
Declare_label(mercury__middle_rec__generate_switch_9_0_i1161);
Declare_label(mercury__middle_rec__generate_switch_9_0_i43);
Declare_label(mercury__middle_rec__generate_switch_9_0_i47);
Declare_label(mercury__middle_rec__generate_switch_9_0_i1197);
Declare_label(mercury__middle_rec__generate_switch_9_0_i1);
Declare_static(mercury__middle_rec__generate_downloop_test_3_0);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i1012);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i10);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i11);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i12);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i1011);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i13);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i1010);
Declare_static(mercury__middle_rec__split_rec_code_3_0);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i9);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i8);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i1010);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i14);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i1008);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i1009);
Declare_static(mercury__middle_rec__add_counter_to_livevals_3_0);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i7);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i9);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i1005);
Declare_static(mercury__middle_rec__find_unused_register_2_0);
Declare_label(mercury__middle_rec__find_unused_register_2_0_i2);
Declare_label(mercury__middle_rec__find_unused_register_2_0_i3);
Declare_label(mercury__middle_rec__find_unused_register_2_0_i4);
Declare_static(mercury__middle_rec__find_unused_register_2_3_0);
Declare_label(mercury__middle_rec__find_unused_register_2_3_0_i1013);
Declare_label(mercury__middle_rec__find_unused_register_2_3_0_i1012);
Declare_static(mercury__middle_rec__find_used_registers_3_0);
Declare_label(mercury__middle_rec__find_used_registers_3_0_i4);
Declare_label(mercury__middle_rec__find_used_registers_3_0_i1002);
Declare_static(mercury__middle_rec__find_used_registers_instr_3_0);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1007);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1006);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1005);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i7);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i8);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i20);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i33);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i34);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1004);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i36);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i37);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i38);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1000);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1001);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1002);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1003);
Declare_static(mercury__middle_rec__find_used_registers_lvals_3_0);
Declare_label(mercury__middle_rec__find_used_registers_lvals_3_0_i4);
Declare_label(mercury__middle_rec__find_used_registers_lvals_3_0_i1002);
Declare_static(mercury__middle_rec__find_used_registers_lval_3_0);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i6);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i1001);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i2);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i11);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i8);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i13);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i1000);
Declare_static(mercury__middle_rec__find_used_registers_rval_3_0);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i1002);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i7);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i8);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i10);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i1001);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i12);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i1000);
Declare_static(mercury__middle_rec__find_used_registers_maybe_rvals_3_0);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1003);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1005);
Declare_static(mercury__middle_rec__insert_pragma_c_input_registers_3_0);
Declare_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4);
Declare_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1002);
Declare_static(mercury__middle_rec__insert_pragma_c_output_registers_3_0);
Declare_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4);
Declare_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1002);
Declare_static(mercury__middle_rec__find_labels_2_0);
Declare_static(mercury__middle_rec__find_labels_2_3_0);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i1009);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i4);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i10);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i7);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i1006);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_middle_rec__base_type_layout_ite_rec_0[];
Word * mercury_data_middle_rec__base_type_info_ite_rec_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_middle_rec__base_type_layout_ite_rec_0
};

extern Word * mercury_data_middle_rec__common_12[];
Word * mercury_data_middle_rec__base_type_layout_ite_rec_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_12)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_middle_rec__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_middle_rec__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0)
};

Word mercury_data_middle_rec__common_2[] = {
	((Integer) 0)
};

Word * mercury_data_middle_rec__common_3[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_middle_rec__common_2)
};

Word mercury_data_middle_rec__common_4[] = {
	((Integer) 1)
};

Word * mercury_data_middle_rec__common_5[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_middle_rec__common_4)
};

Word mercury_data_middle_rec__common_6[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 4)))
};

Word mercury_data_middle_rec__common_7[] = {
	((Integer) 6),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_middle_rec__common_8[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_middle_rec__common_7),
	(Word *) string_const("exit from base case", 19)
};

Word * mercury_data_middle_rec__common_9[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_8),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_middle_rec__common_10[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_middle_rec__common_9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_middle_rec__common_11[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_middle_rec__common_7),
	(Word *) string_const("exit from recursive case", 24)
};

Word * mercury_data_middle_rec__common_12[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("in_then", 7),
	(Word *) string_const("in_else", 7)
};

BEGIN_MODULE(mercury__middle_rec_module0)
	init_entry(mercury__middle_rec__generate_ite__ua10000_10_0);
	init_label(mercury__middle_rec__generate_ite__ua10000_10_0_i4);
	init_label(mercury__middle_rec__generate_ite__ua10000_10_0_i3);
	init_label(mercury__middle_rec__generate_ite__ua10000_10_0_i6);
BEGIN_CODE

/* code for predicate 'middle_rec__generate_ite__ua10000'/10 in mode 0 */
Define_static(mercury__middle_rec__generate_ite__ua10000_10_0);
	incr_sp_push_msg(2, "middle_rec__generate_ite__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__std_util__semidet_fail_0_0);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__generate_ite__ua10000_10_0_i4,
		STATIC(mercury__middle_rec__generate_ite__ua10000_10_0));
	}
Define_label(mercury__middle_rec__generate_ite__ua10000_10_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_ite__ua10000_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__generate_ite__ua10000_10_0_i3);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__generate_ite__ua10000_10_0_i3);
	r1 = string_const("middle_rec__generate_ite reached", 32);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__middle_rec__generate_ite__ua10000_10_0_i6,
		STATIC(mercury__middle_rec__generate_ite__ua10000_10_0));
	}
Define_label(mercury__middle_rec__generate_ite__ua10000_10_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_ite__ua10000_10_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module1)
	init_entry(mercury__middle_rec__match_and_generate_4_0);
	init_label(mercury__middle_rec__match_and_generate_4_0_i10);
	init_label(mercury__middle_rec__match_and_generate_4_0_i12);
	init_label(mercury__middle_rec__match_and_generate_4_0_i14);
	init_label(mercury__middle_rec__match_and_generate_4_0_i9);
	init_label(mercury__middle_rec__match_and_generate_4_0_i16);
	init_label(mercury__middle_rec__match_and_generate_4_0_i18);
	init_label(mercury__middle_rec__match_and_generate_4_0_i1003);
	init_label(mercury__middle_rec__match_and_generate_4_0_i26);
	init_label(mercury__middle_rec__match_and_generate_4_0_i28);
	init_label(mercury__middle_rec__match_and_generate_4_0_i30);
	init_label(mercury__middle_rec__match_and_generate_4_0_i32);
	init_label(mercury__middle_rec__match_and_generate_4_0_i34);
	init_label(mercury__middle_rec__match_and_generate_4_0_i25);
	init_label(mercury__middle_rec__match_and_generate_4_0_i35);
	init_label(mercury__middle_rec__match_and_generate_4_0_i37);
	init_label(mercury__middle_rec__match_and_generate_4_0_i39);
	init_label(mercury__middle_rec__match_and_generate_4_0_i1);
	init_label(mercury__middle_rec__match_and_generate_4_0_i1001);
	init_label(mercury__middle_rec__match_and_generate_4_0_i1002);
BEGIN_CODE

/* code for predicate 'middle_rec__match_and_generate'/4 in mode 0 */
Define_entry(mercury__middle_rec__match_and_generate_4_0);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1003);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1003);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 2)) != ((Integer) 1)))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1002);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1002);
	if (((Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1002);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1002);
	incr_sp_push_msg(9, "middle_rec__match_and_generate");
	detstackvar(9) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)), ((Integer) 1)), ((Integer) 0)), ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)), ((Integer) 1)), ((Integer) 0)), ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)), ((Integer) 0)), ((Integer) 1));
	r6 = (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 4));
	r7 = (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r8 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r8;
	detstackvar(3) = (Integer) r7;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 3)), ((Integer) 0)), ((Integer) 0));
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r4;
	detstackvar(8) = (Integer) r3;
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i10,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i9);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i12,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i12);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i9);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__middle_rec__generate_switch_9_0),
		mercury__middle_rec__match_and_generate_4_0_i14,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i14);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	if ((Integer) r1)
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1001);
	r1 = FALSE;
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i9);
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i16,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i16);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i18,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i18);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__middle_rec__generate_switch_9_0),
		mercury__middle_rec__match_and_generate_4_0_i14,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i1003);
	incr_sp_push_msg(9, "middle_rec__match_and_generate");
	detstackvar(9) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i26,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i26);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i25);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i28,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i28);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i25);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i30,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i30);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i25);
	if ((((Integer) 1) != (Integer) r2))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i25);
	{
	Declare_entry(mercury__std_util__semidet_fail_0_0);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__match_and_generate_4_0_i32,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i32);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__middle_rec__generate_ite__ua10000_10_0),
		mercury__middle_rec__match_and_generate_4_0_i34,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i34);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i25);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i35,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i35);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i37,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i37);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	if ((((Integer) 1) != (Integer) r2))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i39,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i39);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	{
	Declare_entry(mercury__std_util__semidet_fail_0_0);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__match_and_generate_4_0_i32,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
	}
Define_label(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i1001);
	r1 = TRUE;
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i1002);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module2)
	init_entry(mercury__middle_rec__generate_switch_9_0);
	init_label(mercury__middle_rec__generate_switch_9_0_i2);
	init_label(mercury__middle_rec__generate_switch_9_0_i3);
	init_label(mercury__middle_rec__generate_switch_9_0_i4);
	init_label(mercury__middle_rec__generate_switch_9_0_i5);
	init_label(mercury__middle_rec__generate_switch_9_0_i6);
	init_label(mercury__middle_rec__generate_switch_9_0_i7);
	init_label(mercury__middle_rec__generate_switch_9_0_i8);
	init_label(mercury__middle_rec__generate_switch_9_0_i9);
	init_label(mercury__middle_rec__generate_switch_9_0_i10);
	init_label(mercury__middle_rec__generate_switch_9_0_i11);
	init_label(mercury__middle_rec__generate_switch_9_0_i12);
	init_label(mercury__middle_rec__generate_switch_9_0_i13);
	init_label(mercury__middle_rec__generate_switch_9_0_i14);
	init_label(mercury__middle_rec__generate_switch_9_0_i15);
	init_label(mercury__middle_rec__generate_switch_9_0_i16);
	init_label(mercury__middle_rec__generate_switch_9_0_i17);
	init_label(mercury__middle_rec__generate_switch_9_0_i18);
	init_label(mercury__middle_rec__generate_switch_9_0_i19);
	init_label(mercury__middle_rec__generate_switch_9_0_i20);
	init_label(mercury__middle_rec__generate_switch_9_0_i21);
	init_label(mercury__middle_rec__generate_switch_9_0_i22);
	init_label(mercury__middle_rec__generate_switch_9_0_i23);
	init_label(mercury__middle_rec__generate_switch_9_0_i24);
	init_label(mercury__middle_rec__generate_switch_9_0_i25);
	init_label(mercury__middle_rec__generate_switch_9_0_i26);
	init_label(mercury__middle_rec__generate_switch_9_0_i27);
	init_label(mercury__middle_rec__generate_switch_9_0_i28);
	init_label(mercury__middle_rec__generate_switch_9_0_i29);
	init_label(mercury__middle_rec__generate_switch_9_0_i30);
	init_label(mercury__middle_rec__generate_switch_9_0_i31);
	init_label(mercury__middle_rec__generate_switch_9_0_i32);
	init_label(mercury__middle_rec__generate_switch_9_0_i33);
	init_label(mercury__middle_rec__generate_switch_9_0_i34);
	init_label(mercury__middle_rec__generate_switch_9_0_i35);
	init_label(mercury__middle_rec__generate_switch_9_0_i36);
	init_label(mercury__middle_rec__generate_switch_9_0_i37);
	init_label(mercury__middle_rec__generate_switch_9_0_i38);
	init_label(mercury__middle_rec__generate_switch_9_0_i39);
	init_label(mercury__middle_rec__generate_switch_9_0_i42);
	init_label(mercury__middle_rec__generate_switch_9_0_i1161);
	init_label(mercury__middle_rec__generate_switch_9_0_i43);
	init_label(mercury__middle_rec__generate_switch_9_0_i47);
	init_label(mercury__middle_rec__generate_switch_9_0_i1197);
	init_label(mercury__middle_rec__generate_switch_9_0_i1);
BEGIN_CODE

/* code for predicate 'middle_rec__generate_switch'/9 in mode 0 */
Define_static(mercury__middle_rec__generate_switch_9_0);
	incr_sp_push_msg(19, "middle_rec__generate_switch");
	detstackvar(19) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r7;
	{
	Declare_entry(mercury__code_info__get_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__middle_rec__generate_switch_9_0_i2,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i2);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_varset_3_0);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__middle_rec__generate_switch_9_0_i3,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i3);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_aux__explain_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_aux__explain_stack_slots_3_0),
		mercury__middle_rec__generate_switch_9_0_i4,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__middle_rec__generate_switch_9_0_i5,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i5);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_pred_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__middle_rec__generate_switch_9_0_i6,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_proc_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__middle_rec__generate_switch_9_0_i7,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i7);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__middle_rec__generate_switch_9_0_i8,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i8);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__code_util__make_local_entry_label_5_0);
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__middle_rec__generate_switch_9_0_i9,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_aux__pre_goal_update_4_0);
	call_localret(ENTRY(mercury__code_aux__pre_goal_update_4_0),
		mercury__middle_rec__generate_switch_9_0_i10,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__unify_gen__generate_tag_test_7_0);
	call_localret(ENTRY(mercury__unify_gen__generate_tag_test_7_0),
		mercury__middle_rec__generate_switch_9_0_i11,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i11);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_1);
	{
	Declare_entry(mercury__tree__flatten_2_0);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__middle_rec__generate_switch_9_0_i12,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i12);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i13,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i13);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__middle_rec__generate_switch_9_0_i14,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i14);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__middle_rec__generate_switch_9_0_i15,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i15);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__middle_rec__generate_switch_9_0_i16,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i16);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__middle_rec__generate_switch_9_0_i17,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i17);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__middle_rec__generate_switch_9_0_i18,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i18);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__middle_rec__generate_switch_9_0_i19,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i19);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_aux__post_goal_update_3_0);
	call_localret(ENTRY(mercury__code_aux__post_goal_update_3_0),
		mercury__middle_rec__generate_switch_9_0_i20,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i20);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__remake_with_store_map_3_0);
	call_localret(ENTRY(mercury__code_info__remake_with_store_map_3_0),
		mercury__middle_rec__generate_switch_9_0_i21,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i21);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	{
	Declare_entry(mercury__code_info__get_arginfo_3_0);
	call_localret(ENTRY(mercury__code_info__get_arginfo_3_0),
		mercury__middle_rec__generate_switch_9_0_i22,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i22);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_headvars_3_0);
	call_localret(ENTRY(mercury__code_info__get_headvars_3_0),
		mercury__middle_rec__generate_switch_9_0_i23,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i23);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r4 = (Integer) detstackvar(5);
	r3 = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__middle_rec__generate_switch_9_0_i24,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i24);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) detstackvar(5);
	r2 = ((Integer) 1);
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__middle_rec__generate_switch_9_0_i25,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i25);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_gen__output_args_2_0);
	call_localret(ENTRY(mercury__code_gen__output_args_2_0),
		mercury__middle_rec__generate_switch_9_0_i26,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i26);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	detstackvar(1) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(detstackvar(3), mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	r5 = (Integer) r2;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) detstackvar(3), ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_1);
	field(mktag(1), (Integer) detstackvar(3), ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__tree__flatten_2_0);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__middle_rec__generate_switch_9_0_i27,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i27);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i28,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i28);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_1);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__tree__flatten_2_0);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__middle_rec__generate_switch_9_0_i29,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i29);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i30,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i30);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__middle_rec__generate_switch_9_0_i31,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i31);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	call_localret(STATIC(mercury__middle_rec__find_unused_register_2_0),
		mercury__middle_rec__generate_switch_9_0_i32,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i32);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__middle_rec__split_rec_code_3_0),
		mercury__middle_rec__generate_switch_9_0_i33,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i33);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__middle_rec__add_counter_to_livevals_3_0),
		mercury__middle_rec__generate_switch_9_0_i34,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i34);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__middle_rec__generate_switch_9_0_i35,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i35);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(12) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__middle_rec__generate_downloop_test_3_0),
		mercury__middle_rec__generate_switch_9_0_i36,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i36);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__middle_rec__generate_switch_9_0_i37,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i37);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__middle_rec__generate_switch_9_0_i38,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i38);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i39);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(11);
	r11 = (Integer) detstackvar(12);
	r12 = (Integer) detstackvar(13);
	r13 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r14 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(3), (Integer) mercury_data_middle_rec__common_3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("initialize counter register", 27);
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	tag_incr_hp(r17, mktag(0), ((Integer) 2));
	tag_incr_hp(r18, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r18, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r18, ((Integer) 1)) = (Integer) detstackvar(1);
	tag_incr_hp(r19, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r19, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r19, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r19, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_middle_rec__common_5);
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r17, ((Integer) 1)) = string_const("increment loop counter", 22);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r18, ((Integer) 2)) = (Integer) r19;
	field(mktag(3), (Integer) r19, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	tag_incr_hp(r18, mktag(0), ((Integer) 2));
	tag_incr_hp(r19, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r19, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r19, ((Integer) 1)) = (Integer) detstackvar(1);
	tag_incr_hp(r20, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r20, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r20, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) r20, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_middle_rec__common_5);
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r18, ((Integer) 1)) = string_const("decrement loop counter", 22);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r19, ((Integer) 2)) = (Integer) r20;
	field(mktag(3), (Integer) r20, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(0), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	tag_incr_hp(r19, mktag(0), ((Integer) 2));
	tag_incr_hp(r20, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r20, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r21, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r21, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r21, ((Integer) 1)) = ((Integer) 22);
	field(mktag(3), (Integer) r21, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_middle_rec__common_3);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(3), (Integer) r21, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r19, ((Integer) 1)) = string_const("test on upward loop", 19);
	field(mktag(3), (Integer) r20, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	field(mktag(0), (Integer) r19, ((Integer) 0)) = (Integer) r20;
	GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i42);
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i39);
	r14 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(11);
	r11 = (Integer) detstackvar(12);
	r12 = (Integer) detstackvar(13);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r15, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r15, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r15;
	field(mktag(0), (Integer) r15, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r14;
	r15 = (Integer) r14;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r15;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r17, mktag(0), ((Integer) 2));
	r16 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r17, ((Integer) 1)) = string_const("initialize counter register", 27);
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r17, ((Integer) 0)) = (Integer) tempr1;
	r17 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	tag_incr_hp(r19, mktag(0), ((Integer) 2));
	tag_incr_hp(r20, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r20, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r21, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r21, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r21, ((Integer) 1)) = ((Integer) 22);
	field(mktag(3), (Integer) r21, ((Integer) 2)) = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_6);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(3), (Integer) r21, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r19, ((Integer) 1)) = string_const("test on upward loop", 19);
	field(mktag(3), (Integer) r20, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	field(mktag(0), (Integer) r19, ((Integer) 0)) = (Integer) r20;
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i42);
	if (((Integer) r8 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i43);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0);
	r12 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r14, ((Integer) 1)) = string_const("Procedure entry point", 21);
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r15, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r15, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	field(mktag(0), (Integer) r15, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r10;
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("start of the down loop", 22);
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r9;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r11;
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	tag_incr_hp(r19, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r19, ((Integer) 1)) = string_const("start of base case", 18);
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	field(mktag(0), (Integer) r19, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r7;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_middle_rec__common_10);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r6;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i1161,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i1161);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__middle_rec__generate_switch_9_0_i43);
	detstackvar(1) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	detstackvar(9) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	detstackvar(6) = (Integer) r9;
	detstackvar(11) = (Integer) r10;
	detstackvar(12) = (Integer) r11;
	detstackvar(13) = (Integer) r12;
	detstackvar(8) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(15) = (Integer) r15;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r17;
	detstackvar(18) = (Integer) r18;
	r1 = (Integer) r7;
	call_localret(STATIC(mercury__middle_rec__find_labels_2_0),
		mercury__middle_rec__generate_switch_9_0_i47,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i47);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("Procedure entry point", 21);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(15);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("start of the down loop", 22);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(16);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(13);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(14);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(17);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) detstackvar(18);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_middle_rec__common_11);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	tag_incr_hp(r20, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r20, ((Integer) 1)) = string_const("start of base case", 18);
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 0)) = (Integer) r20;
	field(mktag(0), (Integer) r20, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_middle_rec__common_10);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i1197,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i1197);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__middle_rec__generate_switch_9_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module3)
	init_entry(mercury__middle_rec__generate_downloop_test_3_0);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i1012);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i10);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i11);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i12);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i1011);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i13);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i1010);
BEGIN_CODE

/* code for predicate 'middle_rec__generate_downloop_test'/3 in mode 0 */
Define_static(mercury__middle_rec__generate_downloop_test_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i1010);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i1011);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i1011);
	r4 = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i1012);
	r1 = (Integer) r4;
	incr_sp_push_msg(3, "middle_rec__generate_downloop_test");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i11);
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i1012);
	incr_sp_push_msg(3, "middle_rec__generate_downloop_test");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r4;
	r1 = string_const("middle_rec__generate_downloop_test: if_val followed by other instructions", 73);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__middle_rec__generate_downloop_test_3_0_i10,
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
	}
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_downloop_test_3_0));
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(2);
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i11);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__code_util__neg_rval_2_0);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__middle_rec__generate_downloop_test_3_0_i12,
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
	}
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i12);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_downloop_test_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("test on downward loop", 21);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i1011);
	incr_sp_push_msg(3, "middle_rec__generate_downloop_test");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__middle_rec__generate_downloop_test_3_0,
		LABEL(mercury__middle_rec__generate_downloop_test_3_0_i13),
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i13);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_downloop_test_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i1010);
	r1 = string_const("middle_rec__generate_downloop_test on empty list", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module4)
	init_entry(mercury__middle_rec__split_rec_code_3_0);
	init_label(mercury__middle_rec__split_rec_code_3_0_i9);
	init_label(mercury__middle_rec__split_rec_code_3_0_i8);
	init_label(mercury__middle_rec__split_rec_code_3_0_i1010);
	init_label(mercury__middle_rec__split_rec_code_3_0_i14);
	init_label(mercury__middle_rec__split_rec_code_3_0_i1008);
	init_label(mercury__middle_rec__split_rec_code_3_0_i1009);
BEGIN_CODE

/* code for predicate 'middle_rec__split_rec_code'/3 in mode 0 */
Define_static(mercury__middle_rec__split_rec_code_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i1009);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i1010);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i1010);
	r1 = (Integer) r2;
	incr_sp_push_msg(2, "middle_rec__split_rec_code");
	detstackvar(2) = (Integer) succip;
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__middle_rec__split_rec_code_3_0_i9,
		STATIC(mercury__middle_rec__split_rec_code_3_0));
	}
Define_label(mercury__middle_rec__split_rec_code_3_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__split_rec_code_3_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i8);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i1008);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	proceed();
Define_label(mercury__middle_rec__split_rec_code_3_0_i8);
	r1 = string_const("call not followed by label in middle_rec__split_rec_code", 56);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
	}
Define_label(mercury__middle_rec__split_rec_code_3_0_i1010);
	incr_sp_push_msg(2, "middle_rec__split_rec_code");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__middle_rec__split_rec_code_3_0,
		LABEL(mercury__middle_rec__split_rec_code_3_0_i14),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
Define_label(mercury__middle_rec__split_rec_code_3_0_i14);
	update_prof_current_proc(LABEL(mercury__middle_rec__split_rec_code_3_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__split_rec_code_3_0_i1008);
	r1 = string_const("call not followed by label in middle_rec__split_rec_code", 56);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
	}
Define_label(mercury__middle_rec__split_rec_code_3_0_i1009);
	r1 = string_const("did not find call in middle_rec__split_rec_code", 47);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module5)
	init_entry(mercury__middle_rec__add_counter_to_livevals_3_0);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i7);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i9);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i1005);
BEGIN_CODE

/* code for predicate 'middle_rec__add_counter_to_livevals'/3 in mode 0 */
Define_static(mercury__middle_rec__add_counter_to_livevals_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i1005);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	incr_sp_push_msg(4, "middle_rec__add_counter_to_livevals");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r5) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(2), (Integer) r5, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__middle_rec__add_counter_to_livevals_3_0_i7,
		STATIC(mercury__middle_rec__add_counter_to_livevals_3_0));
	}
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i7);
	update_prof_current_proc(LABEL(mercury__middle_rec__add_counter_to_livevals_3_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
	}
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
	r1 = (Integer) r3;
	r3 = (Integer) r4;
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
	detstackvar(1) = (Integer) r3;
	localcall(mercury__middle_rec__add_counter_to_livevals_3_0,
		LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i9),
		STATIC(mercury__middle_rec__add_counter_to_livevals_3_0));
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__add_counter_to_livevals_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module6)
	init_entry(mercury__middle_rec__find_unused_register_2_0);
	init_label(mercury__middle_rec__find_unused_register_2_0_i2);
	init_label(mercury__middle_rec__find_unused_register_2_0_i3);
	init_label(mercury__middle_rec__find_unused_register_2_0_i4);
BEGIN_CODE

/* code for predicate 'middle_rec__find_unused_register'/2 in mode 0 */
Define_static(mercury__middle_rec__find_unused_register_2_0);
	incr_sp_push_msg(2, "middle_rec__find_unused_register");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__middle_rec__find_unused_register_2_0_i2,
		STATIC(mercury__middle_rec__find_unused_register_2_0));
	}
Define_label(mercury__middle_rec__find_unused_register_2_0_i2);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_unused_register_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_3_0),
		mercury__middle_rec__find_unused_register_2_0_i3,
		STATIC(mercury__middle_rec__find_unused_register_2_0));
Define_label(mercury__middle_rec__find_unused_register_2_0_i3);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_unused_register_2_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__middle_rec__find_unused_register_2_0_i4,
		STATIC(mercury__middle_rec__find_unused_register_2_0));
	}
Define_label(mercury__middle_rec__find_unused_register_2_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_unused_register_2_0));
	r2 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_unused_register_2_3_0),
		STATIC(mercury__middle_rec__find_unused_register_2_0));
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module7)
	init_entry(mercury__middle_rec__find_unused_register_2_3_0);
	init_label(mercury__middle_rec__find_unused_register_2_3_0_i1013);
	init_label(mercury__middle_rec__find_unused_register_2_3_0_i1012);
BEGIN_CODE

/* code for predicate 'middle_rec__find_unused_register_2'/3 in mode 0 */
Define_static(mercury__middle_rec__find_unused_register_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__find_unused_register_2_3_0_i1013);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 >= (Integer) field(mktag(1), (Integer) r1, ((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_unused_register_2_3_0_i1012);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	proceed();
Define_label(mercury__middle_rec__find_unused_register_2_3_0_i1013);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	proceed();
Define_label(mercury__middle_rec__find_unused_register_2_3_0_i1012);
	r1 = (Integer) r3;
	r2 = ((Integer) r2 + ((Integer) 1));
	localtailcall(mercury__middle_rec__find_unused_register_2_3_0,
		STATIC(mercury__middle_rec__find_unused_register_2_3_0));
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module8)
	init_entry(mercury__middle_rec__find_used_registers_3_0);
	init_label(mercury__middle_rec__find_used_registers_3_0_i4);
	init_label(mercury__middle_rec__find_used_registers_3_0_i1002);
BEGIN_CODE

/* code for predicate 'middle_rec__find_used_registers'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_3_0_i1002);
	incr_sp_push_msg(2, "middle_rec__find_used_registers");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_instr_3_0),
		mercury__middle_rec__find_used_registers_3_0_i4,
		STATIC(mercury__middle_rec__find_used_registers_3_0));
Define_label(mercury__middle_rec__find_used_registers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_used_registers_3_0,
		STATIC(mercury__middle_rec__find_used_registers_3_0));
Define_label(mercury__middle_rec__find_used_registers_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module9)
	init_entry(mercury__middle_rec__find_used_registers_instr_3_0);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1007);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1006);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1005);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i7);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i8);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i20);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i33);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i34);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1004);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i36);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i37);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i38);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1000);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1001);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1002);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1003);
BEGIN_CODE

/* code for predicate 'middle_rec__find_used_registers_instr'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_instr_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1004);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1000) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1007) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1002) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1002) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1006) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1003) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1002) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1003) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1002) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1001) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1005));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1007);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_instr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i7);
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1006);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_instr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i20);
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1005);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_instr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i33);
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i7);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i8,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i8);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_instr_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i20);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i8,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i33);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__middle_rec__insert_pragma_c_input_registers_3_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i34,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i34);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_instr_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__insert_pragma_c_output_registers_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1004);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_instr");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i36);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i36);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i37);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i37);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i38,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
	}
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i38);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_instr_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_lvals_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__middle_rec__find_used_registers_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1001);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1002);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1003);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module10)
	init_entry(mercury__middle_rec__find_used_registers_lvals_3_0);
	init_label(mercury__middle_rec__find_used_registers_lvals_3_0_i4);
	init_label(mercury__middle_rec__find_used_registers_lvals_3_0_i1002);
BEGIN_CODE

/* code for predicate 'middle_rec__find_used_registers_lvals'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_lvals_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lvals_3_0_i1002);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_lvals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__find_used_registers_lvals_3_0_i4,
		STATIC(mercury__middle_rec__find_used_registers_lvals_3_0));
Define_label(mercury__middle_rec__find_used_registers_lvals_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_lvals_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_used_registers_lvals_3_0,
		STATIC(mercury__middle_rec__find_used_registers_lvals_3_0));
Define_label(mercury__middle_rec__find_used_registers_lvals_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module11)
	init_entry(mercury__middle_rec__find_used_registers_lval_3_0);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i6);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i1001);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i11);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i8);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i13);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i1000);
BEGIN_CODE

/* code for predicate 'middle_rec__find_used_registers_lval'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_lval_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i1001);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(2, "middle_rec__find_used_registers_lval");
	detstackvar(2) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	detstackvar(1) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__middle_rec__find_used_registers_lval_3_0_i6,
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
	}
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_lval_3_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__insert_3_0);
	tailcall(ENTRY(mercury__set__insert_3_0),
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
	}
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i1001);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_lval");
	detstackvar(2) = (Integer) succip;
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i8);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		mercury__middle_rec__find_used_registers_lval_3_0_i11,
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i11);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_lval_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i8);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 7)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i1000);
	r1 = string_const("lvar found in middle_rec__find_used_registers_lval", 50);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
	}
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i13);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module12)
	init_entry(mercury__middle_rec__find_used_registers_rval_3_0);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i1002);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i7);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i8);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i10);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i1001);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i12);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i1000);
BEGIN_CODE

/* code for predicate 'middle_rec__find_used_registers_rval'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_rval_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i1001);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i1002);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localtailcall(mercury__middle_rec__find_used_registers_rval_3_0,
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i1002);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_rval");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i7);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i7);
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_used_registers_rval_3_0,
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__middle_rec__find_used_registers_rval_3_0,
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i10),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_rval_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_used_registers_rval_3_0,
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i1001);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_rval");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i12);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i1000);
	r1 = string_const("var found in middle_rec__find_used_registers_rval", 49);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
	}
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__middle_rec__find_used_registers_maybe_rvals_3_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module13)
	init_entry(mercury__middle_rec__find_used_registers_maybe_rvals_3_0);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1003);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1005);
BEGIN_CODE

/* code for predicate 'middle_rec__find_used_registers_maybe_rvals'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_maybe_rvals_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1003);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1005);
	incr_sp_push_msg(2, "middle_rec__find_used_registers_maybe_rvals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6,
		STATIC(mercury__middle_rec__find_used_registers_maybe_rvals_3_0));
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_used_registers_maybe_rvals_3_0,
		STATIC(mercury__middle_rec__find_used_registers_maybe_rvals_3_0));
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1005);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localtailcall(mercury__middle_rec__find_used_registers_maybe_rvals_3_0,
		STATIC(mercury__middle_rec__find_used_registers_maybe_rvals_3_0));
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module14)
	init_entry(mercury__middle_rec__insert_pragma_c_input_registers_3_0);
	init_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4);
	init_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1002);
BEGIN_CODE

/* code for predicate 'insert_pragma_c_input_registers'/3 in mode 0 */
Define_static(mercury__middle_rec__insert_pragma_c_input_registers_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1002);
	incr_sp_push_msg(2, "insert_pragma_c_input_registers");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 2));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4,
		STATIC(mercury__middle_rec__insert_pragma_c_input_registers_3_0));
Define_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__insert_pragma_c_input_registers_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__insert_pragma_c_input_registers_3_0,
		STATIC(mercury__middle_rec__insert_pragma_c_input_registers_3_0));
Define_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module15)
	init_entry(mercury__middle_rec__insert_pragma_c_output_registers_3_0);
	init_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4);
	init_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1002);
BEGIN_CODE

/* code for predicate 'insert_pragma_c_output_registers'/3 in mode 0 */
Define_static(mercury__middle_rec__insert_pragma_c_output_registers_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1002);
	incr_sp_push_msg(2, "insert_pragma_c_output_registers");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4,
		STATIC(mercury__middle_rec__insert_pragma_c_output_registers_3_0));
Define_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__insert_pragma_c_output_registers_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__insert_pragma_c_output_registers_3_0,
		STATIC(mercury__middle_rec__insert_pragma_c_output_registers_3_0));
Define_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module16)
	init_entry(mercury__middle_rec__find_labels_2_0);
BEGIN_CODE

/* code for predicate 'middle_rec__find_labels'/2 in mode 0 */
Define_static(mercury__middle_rec__find_labels_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__middle_rec__find_labels_2_3_0),
		STATIC(mercury__middle_rec__find_labels_2_0));
END_MODULE

BEGIN_MODULE(mercury__middle_rec_module17)
	init_entry(mercury__middle_rec__find_labels_2_3_0);
	init_label(mercury__middle_rec__find_labels_2_3_0_i1009);
	init_label(mercury__middle_rec__find_labels_2_3_0_i4);
	init_label(mercury__middle_rec__find_labels_2_3_0_i10);
	init_label(mercury__middle_rec__find_labels_2_3_0_i7);
	init_label(mercury__middle_rec__find_labels_2_3_0_i1006);
BEGIN_CODE

/* code for predicate 'middle_rec__find_labels_2'/3 in mode 0 */
Define_static(mercury__middle_rec__find_labels_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i1006);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i1009);
	incr_sp_push_msg(2, "middle_rec__find_labels_2");
	detstackvar(2) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_labels_2_3_0,
		STATIC(mercury__middle_rec__find_labels_2_3_0));
	}
Define_label(mercury__middle_rec__find_labels_2_3_0_i1009);
	incr_sp_push_msg(2, "middle_rec__find_labels_2");
	detstackvar(2) = (Integer) succip;
Define_label(mercury__middle_rec__find_labels_2_3_0_i4);
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i7);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i7);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 3));
	localcall(mercury__middle_rec__find_labels_2_3_0,
		LABEL(mercury__middle_rec__find_labels_2_3_0_i10),
		STATIC(mercury__middle_rec__find_labels_2_3_0));
Define_label(mercury__middle_rec__find_labels_2_3_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_labels_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_labels_2_3_0,
		STATIC(mercury__middle_rec__find_labels_2_3_0));
Define_label(mercury__middle_rec__find_labels_2_3_0_i7);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__middle_rec__find_labels_2_3_0,
		STATIC(mercury__middle_rec__find_labels_2_3_0));
Define_label(mercury__middle_rec__find_labels_2_3_0_i1006);
	r1 = (Integer) r2;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__middle_rec_bunch_0(void)
{
	mercury__middle_rec_module0();
	mercury__middle_rec_module1();
	mercury__middle_rec_module2();
	mercury__middle_rec_module3();
	mercury__middle_rec_module4();
	mercury__middle_rec_module5();
	mercury__middle_rec_module6();
	mercury__middle_rec_module7();
	mercury__middle_rec_module8();
	mercury__middle_rec_module9();
	mercury__middle_rec_module10();
	mercury__middle_rec_module11();
	mercury__middle_rec_module12();
	mercury__middle_rec_module13();
	mercury__middle_rec_module14();
	mercury__middle_rec_module15();
	mercury__middle_rec_module16();
	mercury__middle_rec_module17();
}

#endif

void mercury__middle_rec__init(void); /* suppress gcc warning */
void mercury__middle_rec__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__middle_rec_bunch_0();
#endif
}
