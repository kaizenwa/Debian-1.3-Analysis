/*
** Automatically generated from `dependency_graph.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__dependency_graph__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__dependency_graph__add_proc_nodes__ua10000_5_0);
Declare_label(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i4);
Declare_label(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i1002);
Define_extern_entry(mercury__dependency_graph__module_info_ensure_dependency_info_2_0);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i4);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i3);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i6);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i7);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i8);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i9);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i10);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i11);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i12);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i13);
Declare_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i14);
Define_extern_entry(mercury__dependency_graph__write_dependency_graph_4_0);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i2);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i3);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i4);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i5);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i6);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i7);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i8);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i9);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i10);
Declare_label(mercury__dependency_graph__write_dependency_graph_4_0_i11);
Define_extern_entry(mercury__dependency_graph__write_prof_dependency_graph_4_0);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i2);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i3);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i4);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i5);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i6);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i7);
Declare_static(mercury__dependency_graph__sets_to_lists_3_0);
Declare_label(mercury__dependency_graph__sets_to_lists_3_0_i4);
Declare_label(mercury__dependency_graph__sets_to_lists_3_0_i1002);
Declare_static(mercury__dependency_graph__add_pred_nodes_4_0);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i4);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i5);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i8);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i7);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i10);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i11);
Declare_label(mercury__dependency_graph__add_pred_nodes_4_0_i1003);
Declare_static(mercury__dependency_graph__add_pred_arcs_4_0);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i4);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i5);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i8);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i7);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i10);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i11);
Declare_label(mercury__dependency_graph__add_pred_arcs_4_0_i1003);
Declare_static(mercury__dependency_graph__add_proc_arcs_5_0);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i4);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i5);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i6);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i7);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i8);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i9);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i10);
Declare_label(mercury__dependency_graph__add_proc_arcs_5_0_i1002);
Declare_static(mercury__dependency_graph__add_arcs_in_goal_4_0);
Declare_static(mercury__dependency_graph__add_arcs_in_goal_2_4_0);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1008);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1007);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i7);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i10);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i12);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i22);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i23);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i24);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1006);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i27);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i32);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i31);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i36);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i35);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i29);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1000);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1001);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1002);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1003);
Declare_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1004);
Declare_static(mercury__dependency_graph__add_arcs_in_list_4_0);
Declare_label(mercury__dependency_graph__add_arcs_in_list_4_0_i4);
Declare_label(mercury__dependency_graph__add_arcs_in_list_4_0_i1002);
Declare_static(mercury__dependency_graph__add_arcs_in_cases_4_0);
Declare_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i4);
Declare_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i5);
Declare_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i1002);
Declare_static(mercury__dependency_graph__add_arcs_in_cons_4_0);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1003);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i9);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i8);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i6);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i13);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1002);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i20);
Declare_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1001);
Declare_static(mercury__dependency_graph__write_dependency_graph_2_5_0);
Declare_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i4);
Declare_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i5);
Declare_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i6);
Declare_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i7);
Declare_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i1002);
Declare_static(mercury__dependency_graph__write_dependency_graph_3_6_0);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i4);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i5);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i6);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i7);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i8);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i9);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i10);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i11);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i12);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i13);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i14);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i15);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i16);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i17);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i18);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i19);
Declare_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i1003);
Declare_static(mercury__dependency_graph__write_dependency_ordering_5_0);
Declare_label(mercury__dependency_graph__write_dependency_ordering_5_0_i4);
Declare_label(mercury__dependency_graph__write_dependency_ordering_5_0_i5);
Declare_label(mercury__dependency_graph__write_dependency_ordering_5_0_i6);
Declare_label(mercury__dependency_graph__write_dependency_ordering_5_0_i7);
Declare_label(mercury__dependency_graph__write_dependency_ordering_5_0_i1003);
Declare_static(mercury__dependency_graph__write_clique_4_0);
Declare_label(mercury__dependency_graph__write_clique_4_0_i4);
Declare_label(mercury__dependency_graph__write_clique_4_0_i5);
Declare_label(mercury__dependency_graph__write_clique_4_0_i6);
Declare_label(mercury__dependency_graph__write_clique_4_0_i7);
Declare_label(mercury__dependency_graph__write_clique_4_0_i8);
Declare_label(mercury__dependency_graph__write_clique_4_0_i9);
Declare_label(mercury__dependency_graph__write_clique_4_0_i10);
Declare_label(mercury__dependency_graph__write_clique_4_0_i11);
Declare_label(mercury__dependency_graph__write_clique_4_0_i12);
Declare_label(mercury__dependency_graph__write_clique_4_0_i1002);
Declare_static(mercury__dependency_graph__write_prof_dependency_graph_2_5_0);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i4);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i5);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i6);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i7);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i1002);
Declare_static(mercury__dependency_graph__write_prof_dependency_graph_3_6_0);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i4);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i5);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i6);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i7);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i8);
Declare_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i1002);
Declare_static(mercury__dependency_graph__output_label_5_0);
Declare_label(mercury__dependency_graph__output_label_5_0_i2);
Declare_label(mercury__dependency_graph__output_label_5_0_i3);
Declare_label(mercury__dependency_graph__output_label_5_0_i8);
Declare_label(mercury__dependency_graph__output_label_5_0_i12);

BEGIN_MODULE(mercury__dependency_graph_module0)
	init_entry(mercury__dependency_graph__add_proc_nodes__ua10000_5_0);
	init_label(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i4);
	init_label(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_proc_nodes__ua10000'/5 in mode 0 */
Define_static(mercury__dependency_graph__add_proc_nodes__ua10000_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i1002);
	incr_sp_push_msg(3, "dependency_graph__add_proc_nodes__ua10000");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__relation__add_element_4_0);
	call_localret(ENTRY(mercury__relation__add_element_4_0),
		mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i4,
		STATIC(mercury__dependency_graph__add_proc_nodes__ua10000_5_0));
	}
	}
Define_label(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_nodes__ua10000_5_0));
	r3 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__dependency_graph__add_proc_nodes__ua10000_5_0,
		STATIC(mercury__dependency_graph__add_proc_nodes__ua10000_5_0));
Define_label(mercury__dependency_graph__add_proc_nodes__ua10000_5_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module1)
	init_entry(mercury__dependency_graph__module_info_ensure_dependency_info_2_0);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i4);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i3);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i6);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i7);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i8);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i9);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i10);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i11);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i12);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i13);
	init_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i14);
BEGIN_CODE

/* code for predicate 'module_info_ensure_dependency_info'/2 in mode 0 */
Define_entry(mercury__dependency_graph__module_info_ensure_dependency_info_2_0);
	incr_sp_push_msg(3, "module_info_ensure_dependency_info");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_dependency_info_built_1_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_dependency_info_built_1_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i4,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i3);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i6,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__relation__init_1_0);
	call_localret(ENTRY(mercury__relation__init_1_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i7,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__dependency_graph__add_pred_nodes_4_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i8,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__dependency_graph__add_pred_arcs_4_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i9,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i9);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_init_1_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i10,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_set_dependency_graph_3_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_set_dependency_graph_3_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i11,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i11);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__relation__atsort_2_0);
	call_localret(ENTRY(mercury__relation__atsort_2_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i12,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i12);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__dependency_graph__sets_to_lists_3_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i13,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i13);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_set_dependency_ordering_3_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_set_dependency_ordering_3_0),
		mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i14,
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
Define_label(mercury__dependency_graph__module_info_ensure_dependency_info_2_0_i14);
	update_prof_current_proc(LABEL(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__hlds_module__module_info_set_dependency_info_3_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_dependency_info_3_0),
		ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module2)
	init_entry(mercury__dependency_graph__write_dependency_graph_4_0);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i2);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i3);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i4);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i5);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i6);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i7);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i8);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i9);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i10);
	init_label(mercury__dependency_graph__write_dependency_graph_4_0_i11);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_dependency_graph'/4 in mode 0 */
Define_entry(mercury__dependency_graph__write_dependency_graph_4_0);
	incr_sp_push_msg(5, "dependency_graph__write_dependency_graph");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("% Dependency graph\n", 19);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i2,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i2);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__dependency_graph__module_info_ensure_dependency_info_2_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i3,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i3);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_dependency_info_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_dependency_info_2_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i4,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_get_dependency_graph_2_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_get_dependency_graph_2_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i5,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__relation__domain_2_0);
	call_localret(ENTRY(mercury__relation__domain_2_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i6,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i7,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__dependency_graph__write_dependency_graph_2_5_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i8,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n\n% Dependency ordering\n", 24);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i9,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i9);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_get_dependency_ordering_2_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_get_dependency_ordering_2_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i10,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__dependency_graph__write_dependency_ordering_5_0),
		mercury__dependency_graph__write_dependency_graph_4_0_i11,
		ENTRY(mercury__dependency_graph__write_dependency_graph_4_0));
Define_label(mercury__dependency_graph__write_dependency_graph_4_0_i11);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module3)
	init_entry(mercury__dependency_graph__write_prof_dependency_graph_4_0);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i2);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i3);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i4);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i5);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i6);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i7);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_prof_dependency_graph'/4 in mode 0 */
Define_entry(mercury__dependency_graph__write_prof_dependency_graph_4_0);
	incr_sp_push_msg(4, "dependency_graph__write_prof_dependency_graph");
	detstackvar(4) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__dependency_graph__module_info_ensure_dependency_info_2_0),
		mercury__dependency_graph__write_prof_dependency_graph_4_0_i2,
		ENTRY(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i2);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_dependency_info_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_dependency_info_2_0),
		mercury__dependency_graph__write_prof_dependency_graph_4_0_i3,
		ENTRY(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i3);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_get_dependency_graph_2_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_get_dependency_graph_2_0),
		mercury__dependency_graph__write_prof_dependency_graph_4_0_i4,
		ENTRY(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__relation__domain_2_0);
	call_localret(ENTRY(mercury__relation__domain_2_0),
		mercury__dependency_graph__write_prof_dependency_graph_4_0_i5,
		ENTRY(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dependency_graph__write_prof_dependency_graph_4_0_i6,
		ENTRY(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__dependency_graph__write_prof_dependency_graph_2_5_0),
		mercury__dependency_graph__write_prof_dependency_graph_4_0_i7,
		ENTRY(mercury__dependency_graph__write_prof_dependency_graph_4_0));
Define_label(mercury__dependency_graph__write_prof_dependency_graph_4_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module4)
	init_entry(mercury__dependency_graph__sets_to_lists_3_0);
	init_label(mercury__dependency_graph__sets_to_lists_3_0_i4);
	init_label(mercury__dependency_graph__sets_to_lists_3_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__sets_to_lists'/3 in mode 0 */
Define_static(mercury__dependency_graph__sets_to_lists_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__sets_to_lists_3_0_i1002);
	incr_sp_push_msg(3, "dependency_graph__sets_to_lists");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dependency_graph__sets_to_lists_3_0_i4,
		STATIC(mercury__dependency_graph__sets_to_lists_3_0));
	}
Define_label(mercury__dependency_graph__sets_to_lists_3_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__sets_to_lists_3_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__dependency_graph__sets_to_lists_3_0,
		STATIC(mercury__dependency_graph__sets_to_lists_3_0));
Define_label(mercury__dependency_graph__sets_to_lists_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module5)
	init_entry(mercury__dependency_graph__add_pred_nodes_4_0);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i4);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i5);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i8);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i7);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i10);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i11);
	init_label(mercury__dependency_graph__add_pred_nodes_4_0_i1003);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_pred_nodes'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_pred_nodes_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__add_pred_nodes_4_0_i1003);
	incr_sp_push_msg(6, "dependency_graph__add_pred_nodes");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dependency_graph__add_pred_nodes_4_0_i4,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_nodes_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dependency_graph__add_pred_nodes_4_0_i5,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_nodes_4_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__dependency_graph__add_pred_nodes_4_0_i8,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_nodes_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dependency_graph__add_pred_nodes_4_0_i7);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__add_pred_nodes_4_0,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i7);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__dependency_graph__add_pred_nodes_4_0_i10,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_nodes_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__dependency_graph__add_proc_nodes__ua10000_5_0),
		mercury__dependency_graph__add_pred_nodes_4_0_i11,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i11);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_nodes_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__add_pred_nodes_4_0,
		STATIC(mercury__dependency_graph__add_pred_nodes_4_0));
Define_label(mercury__dependency_graph__add_pred_nodes_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module6)
	init_entry(mercury__dependency_graph__add_pred_arcs_4_0);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i4);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i5);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i8);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i7);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i10);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i11);
	init_label(mercury__dependency_graph__add_pred_arcs_4_0_i1003);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_pred_arcs'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_pred_arcs_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__add_pred_arcs_4_0_i1003);
	incr_sp_push_msg(6, "dependency_graph__add_pred_arcs");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dependency_graph__add_pred_arcs_4_0_i4,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_arcs_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dependency_graph__add_pred_arcs_4_0_i5,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_arcs_4_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__dependency_graph__add_pred_arcs_4_0_i8,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_arcs_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dependency_graph__add_pred_arcs_4_0_i7);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__add_pred_arcs_4_0,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i7);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__dependency_graph__add_pred_arcs_4_0_i10,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
	}
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_arcs_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__dependency_graph__add_proc_arcs_5_0),
		mercury__dependency_graph__add_pred_arcs_4_0_i11,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i11);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_pred_arcs_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__add_pred_arcs_4_0,
		STATIC(mercury__dependency_graph__add_pred_arcs_4_0));
Define_label(mercury__dependency_graph__add_pred_arcs_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module7)
	init_entry(mercury__dependency_graph__add_proc_arcs_5_0);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i4);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i5);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i6);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i7);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i8);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i9);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i10);
	init_label(mercury__dependency_graph__add_proc_arcs_5_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_proc_arcs'/5 in mode 0 */
Define_static(mercury__dependency_graph__add_proc_arcs_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__add_proc_arcs_5_0_i1002);
	incr_sp_push_msg(6, "dependency_graph__add_proc_arcs");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dependency_graph__add_proc_arcs_5_0_i4,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
	}
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dependency_graph__add_proc_arcs_5_0_i5,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
	}
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__dependency_graph__add_proc_arcs_5_0_i6,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
	}
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__dependency_graph__add_proc_arcs_5_0_i7,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
	}
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__dependency_graph__add_proc_arcs_5_0_i8,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
	}
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__relation__lookup_element_3_0);
	call_localret(ENTRY(mercury__relation__lookup_element_3_0),
		mercury__dependency_graph__add_proc_arcs_5_0_i9,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
	}
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i9);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		mercury__dependency_graph__add_proc_arcs_5_0_i10,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_proc_arcs_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__add_proc_arcs_5_0,
		STATIC(mercury__dependency_graph__add_proc_arcs_5_0));
Define_label(mercury__dependency_graph__add_proc_arcs_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module8)
	init_entry(mercury__dependency_graph__add_arcs_in_goal_4_0);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_arcs_in_goal'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_arcs_in_goal_4_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0));
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module9)
	init_entry(mercury__dependency_graph__add_arcs_in_goal_2_4_0);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1008);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1007);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i7);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i10);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i12);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i22);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i23);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i24);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1006);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i27);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i32);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i31);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i36);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i35);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i29);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1000);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1001);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1002);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1003);
	init_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1004);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_arcs_in_goal_2'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_arcs_in_goal_2_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1006);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1000) AND
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1008) AND
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1002) AND
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1003) AND
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1004) AND
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1007) AND
		LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1001));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1008);
	incr_sp_push_msg(5, "dependency_graph__add_arcs_in_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i7);
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1007);
	incr_sp_push_msg(5, "dependency_graph__add_arcs_in_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i22);
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i7);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1001);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i10);
	if ((tag((Integer) r4) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i12);
	r1 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_cons_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r4) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1001);
	r1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_cons_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i22);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		mercury__dependency_graph__add_arcs_in_goal_2_4_0_i23,
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i23);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		mercury__dependency_graph__add_arcs_in_goal_2_4_0_i24,
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i24);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1006);
	incr_sp_push_msg(5, "dependency_graph__add_arcs_in_goal_2");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i27);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_list_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i27);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i29);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		mercury__dependency_graph__add_arcs_in_goal_2_4_0_i32,
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i32);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i31);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i31);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__relation__search_element_3_0);
	call_localret(ENTRY(mercury__relation__search_element_3_0),
		mercury__dependency_graph__add_arcs_in_goal_2_4_0_i36,
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i36);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i35);
	r4 = (Integer) r2;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__relation__add_4_0);
	tailcall(ENTRY(mercury__relation__add_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i35);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i29);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_cases_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1001);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1002);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_list_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1003);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_goal_2_4_0_i1004);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	tailcall(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_goal_2_4_0));
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module10)
	init_entry(mercury__dependency_graph__add_arcs_in_list_4_0);
	init_label(mercury__dependency_graph__add_arcs_in_list_4_0_i4);
	init_label(mercury__dependency_graph__add_arcs_in_list_4_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_arcs_in_list'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_arcs_in_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_list_4_0_i1002);
	incr_sp_push_msg(3, "dependency_graph__add_arcs_in_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		mercury__dependency_graph__add_arcs_in_list_4_0_i4,
		STATIC(mercury__dependency_graph__add_arcs_in_list_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_list_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__dependency_graph__add_arcs_in_list_4_0,
		STATIC(mercury__dependency_graph__add_arcs_in_list_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_list_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module11)
	init_entry(mercury__dependency_graph__add_arcs_in_cases_4_0);
	init_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i4);
	init_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i5);
	init_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_arcs_in_cases'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_arcs_in_cases_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cases_4_0_i1002);
	incr_sp_push_msg(4, "dependency_graph__add_arcs_in_cases");
	detstackvar(4) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__dependency_graph__add_arcs_in_cons_4_0),
		mercury__dependency_graph__add_arcs_in_cases_4_0_i4,
		STATIC(mercury__dependency_graph__add_arcs_in_cases_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_cases_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__dependency_graph__add_arcs_in_goal_4_0),
		mercury__dependency_graph__add_arcs_in_cases_4_0_i5,
		STATIC(mercury__dependency_graph__add_arcs_in_cases_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_cases_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__dependency_graph__add_arcs_in_cases_4_0,
		STATIC(mercury__dependency_graph__add_arcs_in_cases_4_0));
Define_label(mercury__dependency_graph__add_arcs_in_cases_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module12)
	init_entry(mercury__dependency_graph__add_arcs_in_cons_4_0);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1003);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i9);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i8);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i6);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i13);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1002);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i20);
	init_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1001);
BEGIN_CODE

/* code for predicate 'dependency_graph__add_arcs_in_cons'/4 in mode 0 */
Define_static(mercury__dependency_graph__add_arcs_in_cons_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i1002);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1003);
	incr_sp_push_msg(3, "dependency_graph__add_arcs_in_cons");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i6);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__relation__search_element_3_0);
	call_localret(ENTRY(mercury__relation__search_element_3_0),
		mercury__dependency_graph__add_arcs_in_cons_4_0_i9,
		STATIC(mercury__dependency_graph__add_arcs_in_cons_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i9);
	update_prof_current_proc(LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i8);
	r4 = (Integer) r2;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__relation__add_4_0);
	tailcall(ENTRY(mercury__relation__add_4_0),
		STATIC(mercury__dependency_graph__add_arcs_in_cons_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i8);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i6);
	if (((Integer) r4 != ((Integer) 2)))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i13);
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	{
	Declare_entry(mercury__relation__search_element_3_0);
	call_localret(ENTRY(mercury__relation__search_element_3_0),
		mercury__dependency_graph__add_arcs_in_cons_4_0_i9,
		STATIC(mercury__dependency_graph__add_arcs_in_cons_4_0));
	}
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i13);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1002);
	incr_sp_push_msg(3, "dependency_graph__add_arcs_in_cons");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i20);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dependency_graph__add_arcs_in_cons_4_0_i1001);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__dependency_graph__add_arcs_in_cons_4_0_i1001);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module13)
	init_entry(mercury__dependency_graph__write_dependency_graph_2_5_0);
	init_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i4);
	init_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i5);
	init_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i6);
	init_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i7);
	init_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_dependency_graph_2'/5 in mode 0 */
Define_static(mercury__dependency_graph__write_dependency_graph_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__write_dependency_graph_2_5_0_i1002);
	incr_sp_push_msg(6, "dependency_graph__write_dependency_graph_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__relation__lookup_element_3_0);
	call_localret(ENTRY(mercury__relation__lookup_element_3_0),
		mercury__dependency_graph__write_dependency_graph_2_5_0_i4,
		STATIC(mercury__dependency_graph__write_dependency_graph_2_5_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_2_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__relation__lookup_from_3_0);
	call_localret(ENTRY(mercury__relation__lookup_from_3_0),
		mercury__dependency_graph__write_dependency_graph_2_5_0_i5,
		STATIC(mercury__dependency_graph__write_dependency_graph_2_5_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_2_5_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_relation__base_type_info_relation_key_0[];
	r1 = (Integer) mercury_data_relation__base_type_info_relation_key_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dependency_graph__write_dependency_graph_2_5_0_i6,
		STATIC(mercury__dependency_graph__write_dependency_graph_2_5_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_2_5_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0),
		mercury__dependency_graph__write_dependency_graph_2_5_0_i7,
		STATIC(mercury__dependency_graph__write_dependency_graph_2_5_0));
Define_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__write_dependency_graph_2_5_0,
		STATIC(mercury__dependency_graph__write_dependency_graph_2_5_0));
Define_label(mercury__dependency_graph__write_dependency_graph_2_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module14)
	init_entry(mercury__dependency_graph__write_dependency_graph_3_6_0);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i4);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i5);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i6);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i7);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i8);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i9);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i10);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i11);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i12);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i13);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i14);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i15);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i16);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i17);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i18);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i19);
	init_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i1003);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_dependency_graph_3'/6 in mode 0 */
Define_static(mercury__dependency_graph__write_dependency_graph_3_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0_i1003);
	incr_sp_push_msg(14, "dependency_graph__write_dependency_graph_3");
	detstackvar(14) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__relation__lookup_key_3_0);
	call_localret(ENTRY(mercury__relation__lookup_key_3_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i4,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i5,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r3 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i6,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i7,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i8,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i9,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i9);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i10,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i11,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i11);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i12,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i12);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i13,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i13);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i14,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i14);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	detstackvar(13) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i15,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i15);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(6);
	detstackvar(4) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_pred_mode_subdecl_7_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_pred_mode_subdecl_7_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i16,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i16);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r2 = (Integer) r1;
	r1 = string_const(" -> ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i17,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i17);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r6 = (Integer) r3;
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(12);
	r5 = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_pred_mode_subdecl_7_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_pred_mode_subdecl_7_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i18,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i18);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_dependency_graph_3_6_0_i19,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i19);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_graph_3_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	localtailcall(mercury__dependency_graph__write_dependency_graph_3_6_0,
		STATIC(mercury__dependency_graph__write_dependency_graph_3_6_0));
Define_label(mercury__dependency_graph__write_dependency_graph_3_6_0_i1003);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module15)
	init_entry(mercury__dependency_graph__write_dependency_ordering_5_0);
	init_label(mercury__dependency_graph__write_dependency_ordering_5_0_i4);
	init_label(mercury__dependency_graph__write_dependency_ordering_5_0_i5);
	init_label(mercury__dependency_graph__write_dependency_ordering_5_0_i6);
	init_label(mercury__dependency_graph__write_dependency_ordering_5_0_i7);
	init_label(mercury__dependency_graph__write_dependency_ordering_5_0_i1003);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_dependency_ordering'/5 in mode 0 */
Define_static(mercury__dependency_graph__write_dependency_ordering_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__write_dependency_ordering_5_0_i1003);
	incr_sp_push_msg(5, "dependency_graph__write_dependency_ordering");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const("% Clique ", 9);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_dependency_ordering_5_0_i4,
		STATIC(mercury__dependency_graph__write_dependency_ordering_5_0));
	}
Define_label(mercury__dependency_graph__write_dependency_ordering_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_ordering_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__dependency_graph__write_dependency_ordering_5_0_i5,
		STATIC(mercury__dependency_graph__write_dependency_ordering_5_0));
	}
Define_label(mercury__dependency_graph__write_dependency_ordering_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_ordering_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_dependency_ordering_5_0_i6,
		STATIC(mercury__dependency_graph__write_dependency_ordering_5_0));
	}
Define_label(mercury__dependency_graph__write_dependency_ordering_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_ordering_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__dependency_graph__write_clique_4_0),
		mercury__dependency_graph__write_dependency_ordering_5_0_i7,
		STATIC(mercury__dependency_graph__write_dependency_ordering_5_0));
Define_label(mercury__dependency_graph__write_dependency_ordering_5_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_dependency_ordering_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) detstackvar(2) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__dependency_graph__write_dependency_ordering_5_0,
		STATIC(mercury__dependency_graph__write_dependency_ordering_5_0));
Define_label(mercury__dependency_graph__write_dependency_ordering_5_0_i1003);
	r1 = string_const("\n", 1);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__dependency_graph__write_dependency_ordering_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module16)
	init_entry(mercury__dependency_graph__write_clique_4_0);
	init_label(mercury__dependency_graph__write_clique_4_0_i4);
	init_label(mercury__dependency_graph__write_clique_4_0_i5);
	init_label(mercury__dependency_graph__write_clique_4_0_i6);
	init_label(mercury__dependency_graph__write_clique_4_0_i7);
	init_label(mercury__dependency_graph__write_clique_4_0_i8);
	init_label(mercury__dependency_graph__write_clique_4_0_i9);
	init_label(mercury__dependency_graph__write_clique_4_0_i10);
	init_label(mercury__dependency_graph__write_clique_4_0_i11);
	init_label(mercury__dependency_graph__write_clique_4_0_i12);
	init_label(mercury__dependency_graph__write_clique_4_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_clique'/4 in mode 0 */
Define_static(mercury__dependency_graph__write_clique_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__write_clique_4_0_i1002);
	incr_sp_push_msg(8, "dependency_graph__write_clique");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__dependency_graph__write_clique_4_0_i4,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	detstackvar(4) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__dependency_graph__write_clique_4_0_i5,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__dependency_graph__write_clique_4_0_i6,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__dependency_graph__write_clique_4_0_i7,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__dependency_graph__write_clique_4_0_i8,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__dependency_graph__write_clique_4_0_i9,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i9);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = string_const("% ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_clique_4_0_i10,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i10);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_pred_mode_subdecl_7_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_pred_mode_subdecl_7_0),
		mercury__dependency_graph__write_clique_4_0_i11,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i11);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_clique_4_0_i12,
		STATIC(mercury__dependency_graph__write_clique_4_0));
	}
Define_label(mercury__dependency_graph__write_clique_4_0_i12);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_clique_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__dependency_graph__write_clique_4_0,
		STATIC(mercury__dependency_graph__write_clique_4_0));
Define_label(mercury__dependency_graph__write_clique_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module17)
	init_entry(mercury__dependency_graph__write_prof_dependency_graph_2_5_0);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i4);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i5);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i6);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i7);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_prof_dependency_graph_2'/5 in mode 0 */
Define_static(mercury__dependency_graph__write_prof_dependency_graph_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i1002);
	incr_sp_push_msg(6, "dependency_graph__write_prof_dependency_graph_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__relation__lookup_element_3_0);
	call_localret(ENTRY(mercury__relation__lookup_element_3_0),
		mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i4,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__relation__lookup_from_3_0);
	call_localret(ENTRY(mercury__relation__lookup_from_3_0),
		mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i5,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_relation__base_type_info_relation_key_0[];
	r1 = (Integer) mercury_data_relation__base_type_info_relation_key_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i6,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0),
		mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i7,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
Define_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__dependency_graph__write_prof_dependency_graph_2_5_0,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_2_5_0));
Define_label(mercury__dependency_graph__write_prof_dependency_graph_2_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module18)
	init_entry(mercury__dependency_graph__write_prof_dependency_graph_3_6_0);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i4);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i5);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i6);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i7);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i8);
	init_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i1002);
BEGIN_CODE

/* code for predicate 'dependency_graph__write_prof_dependency_graph_3'/6 in mode 0 */
Define_static(mercury__dependency_graph__write_prof_dependency_graph_3_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i1002);
	incr_sp_push_msg(7, "dependency_graph__write_prof_dependency_graph_3");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__relation__lookup_key_3_0);
	call_localret(ENTRY(mercury__relation__lookup_key_3_0),
		mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i4,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	r4 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__dependency_graph__output_label_5_0),
		mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i5,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i5);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\t", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i6,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i6);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__dependency_graph__output_label_5_0),
		mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i7,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
Define_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i7);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i8,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	}
Define_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i8);
	update_prof_current_proc(LABEL(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__dependency_graph__write_prof_dependency_graph_3_6_0,
		STATIC(mercury__dependency_graph__write_prof_dependency_graph_3_6_0));
Define_label(mercury__dependency_graph__write_prof_dependency_graph_3_6_0_i1002);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__dependency_graph_module19)
	init_entry(mercury__dependency_graph__output_label_5_0);
	init_label(mercury__dependency_graph__output_label_5_0_i2);
	init_label(mercury__dependency_graph__output_label_5_0_i3);
	init_label(mercury__dependency_graph__output_label_5_0_i8);
	init_label(mercury__dependency_graph__output_label_5_0_i12);
BEGIN_CODE

/* code for predicate 'dependency_graph__output_label'/5 in mode 0 */
Define_static(mercury__dependency_graph__output_label_5_0);
	incr_sp_push_msg(2, "dependency_graph__output_label");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__code_util__make_entry_label_5_0);
	call_localret(ENTRY(mercury__code_util__make_entry_label_5_0),
		mercury__dependency_graph__output_label_5_0_i2,
		STATIC(mercury__dependency_graph__output_label_5_0));
	}
Define_label(mercury__dependency_graph__output_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dependency_graph__output_label_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dependency_graph__output_label_5_0_i3);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__dependency_graph__output_label_5_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__llds_out__output_label_3_0);
	tailcall(ENTRY(mercury__llds_out__output_label_3_0),
		STATIC(mercury__dependency_graph__output_label_5_0));
	}
Define_label(mercury__dependency_graph__output_label_5_0_i3);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__dependency_graph__output_label_5_0_i8);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__llds_out__output_proc_label_3_0);
	tailcall(ENTRY(mercury__llds_out__output_proc_label_3_0),
		STATIC(mercury__dependency_graph__output_label_5_0));
	}
Define_label(mercury__dependency_graph__output_label_5_0_i8);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__dependency_graph__output_label_5_0_i12);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__dependency_graph__output_label_5_0_i12);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__llds_out__output_label_3_0);
	tailcall(ENTRY(mercury__llds_out__output_label_3_0),
		STATIC(mercury__dependency_graph__output_label_5_0));
	}
Define_label(mercury__dependency_graph__output_label_5_0_i12);
	r1 = string_const("dependency_graph__output_label: label not of type local or imported or exported\n", 80);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__dependency_graph__output_label_5_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__dependency_graph_bunch_0(void)
{
	mercury__dependency_graph_module0();
	mercury__dependency_graph_module1();
	mercury__dependency_graph_module2();
	mercury__dependency_graph_module3();
	mercury__dependency_graph_module4();
	mercury__dependency_graph_module5();
	mercury__dependency_graph_module6();
	mercury__dependency_graph_module7();
	mercury__dependency_graph_module8();
	mercury__dependency_graph_module9();
	mercury__dependency_graph_module10();
	mercury__dependency_graph_module11();
	mercury__dependency_graph_module12();
	mercury__dependency_graph_module13();
	mercury__dependency_graph_module14();
	mercury__dependency_graph_module15();
	mercury__dependency_graph_module16();
	mercury__dependency_graph_module17();
	mercury__dependency_graph_module18();
	mercury__dependency_graph_module19();
}

#endif

void mercury__dependency_graph__init(void); /* suppress gcc warning */
void mercury__dependency_graph__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__dependency_graph_bunch_0();
#endif
}
