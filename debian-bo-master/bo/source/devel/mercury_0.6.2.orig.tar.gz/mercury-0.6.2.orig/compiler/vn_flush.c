/*
** Automatically generated from `vn_flush.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_flush__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__vn_flush__nodelist_8_0);
Declare_label(mercury__vn_flush__nodelist_8_0_i1005);
Declare_label(mercury__vn_flush__nodelist_8_0_i7);
Declare_label(mercury__vn_flush__nodelist_8_0_i8);
Declare_label(mercury__vn_flush__nodelist_8_0_i9);
Declare_label(mercury__vn_flush__nodelist_8_0_i10);
Declare_label(mercury__vn_flush__nodelist_8_0_i1003);
Declare_static(mercury__vn_flush__node_12_0);
Declare_label(mercury__vn_flush__node_12_0_i2);
Declare_label(mercury__vn_flush__node_12_0_i8);
Declare_label(mercury__vn_flush__node_12_0_i9);
Declare_label(mercury__vn_flush__node_12_0_i7);
Declare_label(mercury__vn_flush__node_12_0_i11);
Declare_label(mercury__vn_flush__node_12_0_i14);
Declare_label(mercury__vn_flush__node_12_0_i16);
Declare_label(mercury__vn_flush__node_12_0_i17);
Declare_label(mercury__vn_flush__node_12_0_i13);
Declare_label(mercury__vn_flush__node_12_0_i18);
Declare_label(mercury__vn_flush__node_12_0_i19);
Declare_label(mercury__vn_flush__node_12_0_i5);
Declare_label(mercury__vn_flush__node_12_0_i22);
Declare_label(mercury__vn_flush__node_12_0_i21);
Declare_label(mercury__vn_flush__node_12_0_i23);
Declare_label(mercury__vn_flush__node_12_0_i24);
Declare_label(mercury__vn_flush__node_12_0_i25);
Declare_label(mercury__vn_flush__node_12_0_i3);
Declare_label(mercury__vn_flush__node_12_0_i26);
Declare_static(mercury__vn_flush__lval_node_12_0);
Declare_label(mercury__vn_flush__lval_node_12_0_i2);
Declare_label(mercury__vn_flush__lval_node_12_0_i3);
Declare_label(mercury__vn_flush__lval_node_12_0_i6);
Declare_label(mercury__vn_flush__lval_node_12_0_i8);
Declare_label(mercury__vn_flush__lval_node_12_0_i9);
Declare_label(mercury__vn_flush__lval_node_12_0_i16);
Declare_label(mercury__vn_flush__lval_node_12_0_i17);
Declare_label(mercury__vn_flush__lval_node_12_0_i1013);
Declare_label(mercury__vn_flush__lval_node_12_0_i18);
Declare_label(mercury__vn_flush__lval_node_12_0_i19);
Declare_label(mercury__vn_flush__lval_node_12_0_i20);
Declare_label(mercury__vn_flush__lval_node_12_0_i21);
Declare_label(mercury__vn_flush__lval_node_12_0_i4);
Declare_label(mercury__vn_flush__lval_node_12_0_i22);
Declare_static(mercury__vn_flush__ctrl_node_8_0);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1011);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1010);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1009);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1008);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1007);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1006);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1005);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1004);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1003);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1002);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1001);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i5);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i6);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i7);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i8);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i9);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i10);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i11);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i12);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i13);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i14);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i15);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i17);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i18);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i19);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i20);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i22);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i23);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i24);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i26);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i27);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i28);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i29);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i31);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i32);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i34);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i35);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1000);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i36);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i37);
Declare_static(mercury__vn_flush__choose_loc_for_shared_vn_5_0);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i5);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i8);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i14);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i15);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i22);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i23);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i26);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i30);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i35);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i37);
Declare_static(mercury__vn_flush__choose_temp_5_0);
Declare_label(mercury__vn_flush__choose_temp_5_0_i2);
Declare_label(mercury__vn_flush__choose_temp_5_0_i3);
Declare_label(mercury__vn_flush__choose_temp_5_0_i4);
Declare_static(mercury__vn_flush__find_cheap_users_3_0);
Declare_label(mercury__vn_flush__find_cheap_users_3_0_i4);
Declare_label(mercury__vn_flush__find_cheap_users_3_0_i3);
Declare_static(mercury__vn_flush__find_cheap_users_2_3_0);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i4);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i10);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i12);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i13);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i21);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i25);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i28);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i29);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i23);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i1034);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i20);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i32);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i16);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i9);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i5);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i1023);
Declare_static(mercury__vn_flush__ensure_assignment_9_0);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i4);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i6);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i1005);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i8);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i3);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i9);
Declare_static(mercury__vn_flush__generate_assignment_10_0);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i5);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i2);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i6);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i9);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i8);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i11);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i12);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i13);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i14);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i17);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i18);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i19);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i16);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i15);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i22);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i24);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i21);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i25);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i26);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i27);
Declare_static(mercury__vn_flush__get_incr_hp_3_0);
Declare_label(mercury__vn_flush__get_incr_hp_3_0_i1006);
Declare_label(mercury__vn_flush__get_incr_hp_3_0_i7);
Declare_label(mercury__vn_flush__get_incr_hp_3_0_i1005);
Declare_static(mercury__vn_flush__vn_10_0);
Declare_label(mercury__vn_flush__vn_10_0_i1000);
Declare_label(mercury__vn_flush__vn_10_0_i5);
Declare_label(mercury__vn_flush__vn_10_0_i6);
Declare_label(mercury__vn_flush__vn_10_0_i7);
Declare_label(mercury__vn_flush__vn_10_0_i10);
Declare_label(mercury__vn_flush__vn_10_0_i11);
Declare_label(mercury__vn_flush__vn_10_0_i12);
Declare_label(mercury__vn_flush__vn_10_0_i15);
Declare_label(mercury__vn_flush__vn_10_0_i20);
Declare_label(mercury__vn_flush__vn_10_0_i17);
Declare_label(mercury__vn_flush__vn_10_0_i25);
Declare_label(mercury__vn_flush__vn_10_0_i29);
Declare_label(mercury__vn_flush__vn_10_0_i30);
Declare_label(mercury__vn_flush__vn_10_0_i22);
Declare_label(mercury__vn_flush__vn_10_0_i21);
Declare_label(mercury__vn_flush__vn_10_0_i31);
Declare_label(mercury__vn_flush__vn_10_0_i14);
Declare_label(mercury__vn_flush__vn_10_0_i40);
Declare_label(mercury__vn_flush__vn_10_0_i34);
Declare_label(mercury__vn_flush__vn_10_0_i9);
Declare_label(mercury__vn_flush__vn_10_0_i45);
Declare_label(mercury__vn_flush__vn_10_0_i8);
Declare_label(mercury__vn_flush__vn_10_0_i46);
Declare_static(mercury__vn_flush__vn_value_10_0);
Declare_label(mercury__vn_flush__vn_value_10_0_i2);
Declare_label(mercury__vn_flush__vn_value_10_0_i6);
Declare_label(mercury__vn_flush__vn_value_10_0_i8);
Declare_label(mercury__vn_flush__vn_value_10_0_i7);
Declare_label(mercury__vn_flush__vn_value_10_0_i9);
Declare_label(mercury__vn_flush__vn_value_10_0_i10);
Declare_label(mercury__vn_flush__vn_value_10_0_i11);
Declare_label(mercury__vn_flush__vn_value_10_0_i5);
Declare_label(mercury__vn_flush__vn_value_10_0_i16);
Declare_label(mercury__vn_flush__vn_value_10_0_i13);
Declare_label(mercury__vn_flush__vn_value_10_0_i17);
Declare_label(mercury__vn_flush__vn_value_10_0_i18);
Declare_label(mercury__vn_flush__vn_value_10_0_i21);
Declare_label(mercury__vn_flush__vn_value_10_0_i20);
Declare_label(mercury__vn_flush__vn_value_10_0_i22);
Declare_label(mercury__vn_flush__vn_value_10_0_i25);
Declare_label(mercury__vn_flush__vn_value_10_0_i24);
Declare_label(mercury__vn_flush__vn_value_10_0_i27);
Declare_label(mercury__vn_flush__vn_value_10_0_i28);
Declare_label(mercury__vn_flush__vn_value_10_0_i29);
Declare_label(mercury__vn_flush__vn_value_10_0_i31);
Declare_label(mercury__vn_flush__vn_value_10_0_i12);
Declare_label(mercury__vn_flush__vn_value_10_0_i35);
Declare_label(mercury__vn_flush__vn_value_10_0_i38);
Declare_label(mercury__vn_flush__vn_value_10_0_i39);
Declare_label(mercury__vn_flush__vn_value_10_0_i43);
Declare_label(mercury__vn_flush__vn_value_10_0_i1049);
Declare_label(mercury__vn_flush__vn_value_10_0_i34);
Declare_label(mercury__vn_flush__vn_value_10_0_i45);
Declare_label(mercury__vn_flush__vn_value_10_0_i32);
Declare_static(mercury__vn_flush__old_hp_9_0);
Declare_label(mercury__vn_flush__old_hp_9_0_i2);
Declare_label(mercury__vn_flush__old_hp_9_0_i3);
Declare_label(mercury__vn_flush__old_hp_9_0_i6);
Declare_label(mercury__vn_flush__old_hp_9_0_i7);
Declare_label(mercury__vn_flush__old_hp_9_0_i11);
Declare_label(mercury__vn_flush__old_hp_9_0_i5);
Declare_label(mercury__vn_flush__old_hp_9_0_i19);
Declare_label(mercury__vn_flush__old_hp_9_0_i4);
Declare_label(mercury__vn_flush__old_hp_9_0_i20);
Declare_label(mercury__vn_flush__old_hp_9_0_i21);
Declare_label(mercury__vn_flush__old_hp_9_0_i22);
Declare_label(mercury__vn_flush__old_hp_9_0_i25);
Declare_label(mercury__vn_flush__old_hp_9_0_i26);
Declare_label(mercury__vn_flush__old_hp_9_0_i27);
Declare_label(mercury__vn_flush__old_hp_9_0_i28);
Declare_label(mercury__vn_flush__old_hp_9_0_i33);
Declare_label(mercury__vn_flush__old_hp_9_0_i39);
Declare_label(mercury__vn_flush__old_hp_9_0_i35);
Declare_label(mercury__vn_flush__old_hp_9_0_i42);
Declare_label(mercury__vn_flush__old_hp_9_0_i43);
Declare_label(mercury__vn_flush__old_hp_9_0_i46);
Declare_label(mercury__vn_flush__old_hp_9_0_i48);
Declare_label(mercury__vn_flush__old_hp_9_0_i49);
Declare_label(mercury__vn_flush__old_hp_9_0_i41);
Declare_label(mercury__vn_flush__old_hp_9_0_i50);
Declare_label(mercury__vn_flush__old_hp_9_0_i51);
Declare_label(mercury__vn_flush__old_hp_9_0_i53);
Declare_label(mercury__vn_flush__old_hp_9_0_i54);
Declare_label(mercury__vn_flush__old_hp_9_0_i29);
Declare_label(mercury__vn_flush__old_hp_9_0_i57);
Declare_label(mercury__vn_flush__old_hp_9_0_i58);
Declare_label(mercury__vn_flush__old_hp_9_0_i60);
Declare_label(mercury__vn_flush__old_hp_9_0_i61);
Declare_label(mercury__vn_flush__old_hp_9_0_i59);
Declare_label(mercury__vn_flush__old_hp_9_0_i62);
Declare_label(mercury__vn_flush__old_hp_9_0_i65);
Declare_label(mercury__vn_flush__old_hp_9_0_i67);
Declare_label(mercury__vn_flush__old_hp_9_0_i68);
Declare_label(mercury__vn_flush__old_hp_9_0_i69);
Declare_label(mercury__vn_flush__old_hp_9_0_i64);
Declare_label(mercury__vn_flush__old_hp_9_0_i70);
Declare_label(mercury__vn_flush__old_hp_9_0_i71);
Declare_label(mercury__vn_flush__old_hp_9_0_i72);
Declare_static(mercury__vn_flush__hp_incr_10_0);
Declare_label(mercury__vn_flush__hp_incr_10_0_i4);
Declare_label(mercury__vn_flush__hp_incr_10_0_i5);
Declare_label(mercury__vn_flush__hp_incr_10_0_i6);
Declare_label(mercury__vn_flush__hp_incr_10_0_i7);
Declare_label(mercury__vn_flush__hp_incr_10_0_i9);
Declare_label(mercury__vn_flush__hp_incr_10_0_i3);
Declare_label(mercury__vn_flush__hp_incr_10_0_i10);
Declare_label(mercury__vn_flush__hp_incr_10_0_i15);
Declare_label(mercury__vn_flush__hp_incr_10_0_i14);
Declare_label(mercury__vn_flush__hp_incr_10_0_i16);
Declare_label(mercury__vn_flush__hp_incr_10_0_i18);
Declare_label(mercury__vn_flush__hp_incr_10_0_i19);
Declare_label(mercury__vn_flush__hp_incr_10_0_i20);
Declare_label(mercury__vn_flush__hp_incr_10_0_i24);
Declare_label(mercury__vn_flush__hp_incr_10_0_i25);
Declare_label(mercury__vn_flush__hp_incr_10_0_i28);
Declare_label(mercury__vn_flush__hp_incr_10_0_i22);
Declare_label(mercury__vn_flush__hp_incr_10_0_i32);
Declare_label(mercury__vn_flush__hp_incr_10_0_i31);
Declare_label(mercury__vn_flush__hp_incr_10_0_i13);
Declare_label(mercury__vn_flush__hp_incr_10_0_i39);
Declare_label(mercury__vn_flush__hp_incr_10_0_i38);
Declare_label(mercury__vn_flush__hp_incr_10_0_i44);
Declare_label(mercury__vn_flush__hp_incr_10_0_i46);
Declare_label(mercury__vn_flush__hp_incr_10_0_i49);
Declare_label(mercury__vn_flush__hp_incr_10_0_i11);
Declare_label(mercury__vn_flush__hp_incr_10_0_i51);
Declare_label(mercury__vn_flush__hp_incr_10_0_i54);
Declare_label(mercury__vn_flush__hp_incr_10_0_i55);
Declare_label(mercury__vn_flush__hp_incr_10_0_i56);
Declare_static(mercury__vn_flush__free_of_old_hp_2_0);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i4);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i5);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i1003);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i1);
Declare_static(mercury__vn_flush__rec_find_ref_vns_list_3_0);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i4);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i5);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i1002);
Declare_static(mercury__vn_flush__access_path_10_0);
Declare_label(mercury__vn_flush__access_path_10_0_i1035);
Declare_label(mercury__vn_flush__access_path_10_0_i1034);
Declare_label(mercury__vn_flush__access_path_10_0_i1033);
Declare_label(mercury__vn_flush__access_path_10_0_i1032);
Declare_label(mercury__vn_flush__access_path_10_0_i1031);
Declare_label(mercury__vn_flush__access_path_10_0_i1030);
Declare_label(mercury__vn_flush__access_path_10_0_i1023);
Declare_label(mercury__vn_flush__access_path_10_0_i6);
Declare_label(mercury__vn_flush__access_path_10_0_i7);
Declare_label(mercury__vn_flush__access_path_10_0_i8);
Declare_label(mercury__vn_flush__access_path_10_0_i9);
Declare_label(mercury__vn_flush__access_path_10_0_i10);
Declare_label(mercury__vn_flush__access_path_10_0_i11);
Declare_label(mercury__vn_flush__access_path_10_0_i12);
Declare_label(mercury__vn_flush__access_path_10_0_i13);
Declare_label(mercury__vn_flush__access_path_10_0_i14);
Declare_label(mercury__vn_flush__access_path_10_0_i15);
Declare_label(mercury__vn_flush__access_path_10_0_i16);
Declare_label(mercury__vn_flush__access_path_10_0_i17);
Declare_label(mercury__vn_flush__access_path_10_0_i18);
Declare_label(mercury__vn_flush__access_path_10_0_i1029);
Declare_label(mercury__vn_flush__access_path_10_0_i20);
Declare_label(mercury__vn_flush__access_path_10_0_i21);
Declare_label(mercury__vn_flush__access_path_10_0_i22);
Declare_label(mercury__vn_flush__access_path_10_0_i23);
Declare_label(mercury__vn_flush__access_path_10_0_i24);
Declare_label(mercury__vn_flush__access_path_10_0_i19);
Declare_label(mercury__vn_flush__access_path_10_0_i25);
Declare_static(mercury__vn_flush__maybe_save_prev_value_10_0);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i4);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i5);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i7);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i12);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i13);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i14);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i19);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i20);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i22);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i27);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i29);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i30);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i41);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i42);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i43);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i44);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
Declare_static(mercury__vn_flush__no_good_copies_1_0);
Declare_label(mercury__vn_flush__no_good_copies_1_0_i1004);
Declare_label(mercury__vn_flush__no_good_copies_1_0_i1005);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_vn_flush__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word mercury_data_vn_flush__common_1[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_vn_flush__common_2[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_1)
};

Word mercury_data_vn_flush__common_3[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 3)))
};

Word * mercury_data_vn_flush__common_4[] = {
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Word *) string_const("", 0)
};

Word * mercury_data_vn_flush__common_5[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_4),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_flush__common_6[] = {
	((Integer) 42)
};

Word * mercury_data_vn_flush__common_7[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_flush__common_6)
};

BEGIN_MODULE(mercury__vn_flush_module0)
	init_entry(mercury__vn_flush__nodelist_8_0);
	init_label(mercury__vn_flush__nodelist_8_0_i1005);
	init_label(mercury__vn_flush__nodelist_8_0_i7);
	init_label(mercury__vn_flush__nodelist_8_0_i8);
	init_label(mercury__vn_flush__nodelist_8_0_i9);
	init_label(mercury__vn_flush__nodelist_8_0_i10);
	init_label(mercury__vn_flush__nodelist_8_0_i1003);
BEGIN_CODE

/* code for predicate 'vn_flush__nodelist'/8 in mode 0 */
Define_entry(mercury__vn_flush__nodelist_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__nodelist_8_0_i1003);
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r8) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_flush__nodelist_8_0_i1005);
	r1 = (Integer) r7;
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(3, "vn_flush__nodelist");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__nodelist_8_0_i8);
Define_label(mercury__vn_flush__nodelist_8_0_i1005);
	incr_sp_push_msg(3, "vn_flush__nodelist");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) r5;
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) tempr1;
	r1 = (Integer) r8;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__vn_flush__node_12_0),
		mercury__vn_flush__nodelist_8_0_i7,
		ENTRY(mercury__vn_flush__nodelist_8_0));
	}
Define_label(mercury__vn_flush__nodelist_8_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__nodelist_8_0));
	r6 = (Integer) r5;
	r7 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
Define_label(mercury__vn_flush__nodelist_8_0_i8);
	detstackvar(1) = (Integer) r7;
	localcall(mercury__vn_flush__nodelist_8_0,
		LABEL(mercury__vn_flush__nodelist_8_0_i9),
		ENTRY(mercury__vn_flush__nodelist_8_0));
Define_label(mercury__vn_flush__nodelist_8_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__nodelist_8_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__nodelist_8_0_i10,
		ENTRY(mercury__vn_flush__nodelist_8_0));
	}
	}
Define_label(mercury__vn_flush__nodelist_8_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__nodelist_8_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_flush__nodelist_8_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module1)
	init_entry(mercury__vn_flush__node_12_0);
	init_label(mercury__vn_flush__node_12_0_i2);
	init_label(mercury__vn_flush__node_12_0_i8);
	init_label(mercury__vn_flush__node_12_0_i9);
	init_label(mercury__vn_flush__node_12_0_i7);
	init_label(mercury__vn_flush__node_12_0_i11);
	init_label(mercury__vn_flush__node_12_0_i14);
	init_label(mercury__vn_flush__node_12_0_i16);
	init_label(mercury__vn_flush__node_12_0_i17);
	init_label(mercury__vn_flush__node_12_0_i13);
	init_label(mercury__vn_flush__node_12_0_i18);
	init_label(mercury__vn_flush__node_12_0_i19);
	init_label(mercury__vn_flush__node_12_0_i5);
	init_label(mercury__vn_flush__node_12_0_i22);
	init_label(mercury__vn_flush__node_12_0_i21);
	init_label(mercury__vn_flush__node_12_0_i23);
	init_label(mercury__vn_flush__node_12_0_i24);
	init_label(mercury__vn_flush__node_12_0_i25);
	init_label(mercury__vn_flush__node_12_0_i3);
	init_label(mercury__vn_flush__node_12_0_i26);
BEGIN_CODE

/* code for predicate 'vn_flush__node'/12 in mode 0 */
Define_static(mercury__vn_flush__node_12_0);
	incr_sp_push_msg(13, "vn_flush__node");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	r2 = (Integer) r7;
	{
	Declare_entry(mercury__vn_debug__flush_start_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__flush_start_msg_3_0),
		mercury__vn_flush__node_12_0_i2,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r2 = (Integer) detstackvar(1);
	r3 = tag((Integer) r2);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i5);
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(9) = (Integer) r1;
	r2 = string_const("vn_flush__shared_node", 21);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__node_12_0_i8,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_flush__node_12_0_i9,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i7);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i7);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0),
		mercury__vn_flush__node_12_0_i11,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(12) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_flush__node_12_0_i14,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i13);
	if (((Integer) detstackvar(9) != (Integer) r2))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i13);
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__vn_debug__flush_also_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__flush_also_msg_3_0),
		mercury__vn_flush__node_12_0_i16,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_node_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	}
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__node_12_0_i17,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r7 = (Integer) r1;
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(12);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__vn_flush__node_12_0_i18);
Define_label(mercury__vn_flush__node_12_0_i13);
	r7 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(12);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__vn_flush__node_12_0_i18);
	detstackvar(1) = (Integer) r7;
	detstackvar(2) = (Integer) r8;
	call_localret(STATIC(mercury__vn_flush__ensure_assignment_9_0),
		mercury__vn_flush__node_12_0_i19,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i5);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i21);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__vn_flush__lval_node_12_0),
		mercury__vn_flush__node_12_0_i22,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) r1;
	r1 = (Integer) r4;
	tempr2 = (Integer) r3;
	r3 = (Integer) r5;
	r5 = (Integer) tempr2;
	r4 = (Integer) tempr1;
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
	}
Define_label(mercury__vn_flush__node_12_0_i21);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i23);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i23);
	detstackvar(1) = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	detstackvar(10) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_instr_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_flush__node_12_0_i24,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__vn_flush__ctrl_node_8_0),
		mercury__vn_flush__node_12_0_i25,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) detstackvar(10);
Define_label(mercury__vn_flush__node_12_0_i3);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r2;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__vn_debug__flush_end_msg_4_0);
	call_localret(ENTRY(mercury__vn_debug__flush_end_msg_4_0),
		mercury__vn_flush__node_12_0_i26,
		STATIC(mercury__vn_flush__node_12_0));
	}
Define_label(mercury__vn_flush__node_12_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module2)
	init_entry(mercury__vn_flush__lval_node_12_0);
	init_label(mercury__vn_flush__lval_node_12_0_i2);
	init_label(mercury__vn_flush__lval_node_12_0_i3);
	init_label(mercury__vn_flush__lval_node_12_0_i6);
	init_label(mercury__vn_flush__lval_node_12_0_i8);
	init_label(mercury__vn_flush__lval_node_12_0_i9);
	init_label(mercury__vn_flush__lval_node_12_0_i16);
	init_label(mercury__vn_flush__lval_node_12_0_i17);
	init_label(mercury__vn_flush__lval_node_12_0_i1013);
	init_label(mercury__vn_flush__lval_node_12_0_i18);
	init_label(mercury__vn_flush__lval_node_12_0_i19);
	init_label(mercury__vn_flush__lval_node_12_0_i20);
	init_label(mercury__vn_flush__lval_node_12_0_i21);
	init_label(mercury__vn_flush__lval_node_12_0_i4);
	init_label(mercury__vn_flush__lval_node_12_0_i22);
BEGIN_CODE

/* code for predicate 'vn_flush__lval_node'/12 in mode 0 */
Define_static(mercury__vn_flush__lval_node_12_0);
	incr_sp_push_msg(12, "vn_flush__lval_node");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	r2 = string_const("vn_flush__lval_node", 19);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_flush__lval_node_12_0_i2,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
Define_label(mercury__vn_flush__lval_node_12_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__lval_node", 19);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_value_4_0),
		mercury__vn_flush__lval_node_12_0_i3,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
Define_label(mercury__vn_flush__lval_node_12_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (((Integer) r1 != (Integer) detstackvar(11)))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i4);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__lval_node_12_0_i6,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
Define_label(mercury__vn_flush__lval_node_12_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i4);
	r1 = (Integer) detstackvar(11);
	r2 = string_const("vn_flush__lval_node", 19);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__lval_node_12_0_i8,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
Define_label(mercury__vn_flush__lval_node_12_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_util__real_uses_3_0);
	call_localret(ENTRY(mercury__vn_util__real_uses_3_0),
		mercury__vn_flush__lval_node_12_0_i9,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
Define_label(mercury__vn_flush__lval_node_12_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i4);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i4);
	if ((tag((Integer) field(mktag(1), (Integer) r2, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i1013);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i1013);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__vn_flush__node_12_0),
		mercury__vn_flush__lval_node_12_0_i16,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	detstackvar(5) = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_node_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	}
	detstackvar(7) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__lval_node_12_0_i17,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
Define_label(mercury__vn_flush__lval_node_12_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i19);
Define_label(mercury__vn_flush__lval_node_12_0_i1013);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__vn_flush__node_12_0),
		mercury__vn_flush__lval_node_12_0_i18,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r7 = (Integer) r1;
	r8 = (Integer) r5;
	r9 = (Integer) r4;
	r4 = (Integer) r2;
	r5 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(8);
Define_label(mercury__vn_flush__lval_node_12_0_i19);
	detstackvar(2) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	call_localret(STATIC(mercury__vn_flush__ensure_assignment_9_0),
		mercury__vn_flush__lval_node_12_0_i20,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) tempr1;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__lval_node_12_0_i21,
		STATIC(mercury__vn_flush__lval_node_12_0));
	}
	}
Define_label(mercury__vn_flush__lval_node_12_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__vn_flush__lval_node_12_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__ensure_assignment_9_0),
		mercury__vn_flush__lval_node_12_0_i22,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module3)
	init_entry(mercury__vn_flush__ctrl_node_8_0);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1011);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1010);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1009);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1008);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1007);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1006);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1005);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1004);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1003);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1002);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1001);
	init_label(mercury__vn_flush__ctrl_node_8_0_i5);
	init_label(mercury__vn_flush__ctrl_node_8_0_i6);
	init_label(mercury__vn_flush__ctrl_node_8_0_i7);
	init_label(mercury__vn_flush__ctrl_node_8_0_i8);
	init_label(mercury__vn_flush__ctrl_node_8_0_i9);
	init_label(mercury__vn_flush__ctrl_node_8_0_i10);
	init_label(mercury__vn_flush__ctrl_node_8_0_i11);
	init_label(mercury__vn_flush__ctrl_node_8_0_i12);
	init_label(mercury__vn_flush__ctrl_node_8_0_i13);
	init_label(mercury__vn_flush__ctrl_node_8_0_i14);
	init_label(mercury__vn_flush__ctrl_node_8_0_i15);
	init_label(mercury__vn_flush__ctrl_node_8_0_i17);
	init_label(mercury__vn_flush__ctrl_node_8_0_i18);
	init_label(mercury__vn_flush__ctrl_node_8_0_i19);
	init_label(mercury__vn_flush__ctrl_node_8_0_i20);
	init_label(mercury__vn_flush__ctrl_node_8_0_i22);
	init_label(mercury__vn_flush__ctrl_node_8_0_i23);
	init_label(mercury__vn_flush__ctrl_node_8_0_i24);
	init_label(mercury__vn_flush__ctrl_node_8_0_i26);
	init_label(mercury__vn_flush__ctrl_node_8_0_i27);
	init_label(mercury__vn_flush__ctrl_node_8_0_i28);
	init_label(mercury__vn_flush__ctrl_node_8_0_i29);
	init_label(mercury__vn_flush__ctrl_node_8_0_i31);
	init_label(mercury__vn_flush__ctrl_node_8_0_i32);
	init_label(mercury__vn_flush__ctrl_node_8_0_i34);
	init_label(mercury__vn_flush__ctrl_node_8_0_i35);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1000);
	init_label(mercury__vn_flush__ctrl_node_8_0_i36);
	init_label(mercury__vn_flush__ctrl_node_8_0_i37);
BEGIN_CODE

/* code for predicate 'vn_flush__ctrl_node'/8 in mode 0 */
Define_static(mercury__vn_flush__ctrl_node_8_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i1000);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1011) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1010) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1009) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1008) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1007) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1006) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1005) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1004) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1003) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1002) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1001));
Define_label(mercury__vn_flush__ctrl_node_8_0_i1011);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i5);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1010);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i9);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1009);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i10);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1008);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i11);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1007);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i14);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1006);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i17);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1005);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i22);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1004);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i26);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1003);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i31);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1002);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i34);
Define_label(mercury__vn_flush__ctrl_node_8_0_i1001);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i35);
Define_label(mercury__vn_flush__ctrl_node_8_0_i5);
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r4;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r2 = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_util__rval_to_vn_4_0);
	call_localret(ENTRY(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i6,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mkword(mktag(3), (Integer) mercury_data_vn_flush__common_2);
	{
	Declare_entry(mercury__vn_util__lval_to_vnlval_4_0);
	call_localret(ENTRY(mercury__vn_util__lval_to_vnlval_4_0),
		mercury__vn_flush__ctrl_node_8_0_i7,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i8,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i9);
	r5 = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i10);
	r5 = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i11);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r6 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i12,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r2 = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i13,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__ctrl_node_8_0_i14);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r6 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i15,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r2 = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i13,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i17);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r1;
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r6 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__ctrl_node_8_0_i18,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_3);
	r2 = string_const("vn_flush__ctrl_node", 19);
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i19,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i20,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 11);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i13,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i22);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r1;
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r6 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i23,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i24,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 12);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i13,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i26);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r6 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__ctrl_node_8_0_i27,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	r2 = string_const("vn_flush__ctrl_node", 19);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i28,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i29,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 13);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i13,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i31);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r6 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i32,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r2 = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 14);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i13,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i34);
	r5 = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i35);
	r5 = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i1000);
	incr_sp_push_msg(6, "vn_flush__ctrl_node");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i36);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_flush__common_5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__ctrl_node_8_0_i36);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__ctrl_node_8_0_i37);
	r5 = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i37);
	r5 = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) field(mktag(2), (Integer) r5, ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(2), (Integer) r5, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r5, ((Integer) 0));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) field(mktag(2), (Integer) r5, ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module4)
	init_entry(mercury__vn_flush__choose_loc_for_shared_vn_5_0);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i5);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i8);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i14);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i15);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i22);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i23);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i26);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i30);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i35);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i37);
BEGIN_CODE

/* code for predicate 'vn_flush__choose_loc_for_shared_vn'/5 in mode 0 */
Define_static(mercury__vn_flush__choose_loc_for_shared_vn_5_0);
	incr_sp_push_msg(5, "vn_flush__choose_loc_for_shared_vn");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	r2 = string_const("vn_flush__choose_loc_for_shared_vn", 34);
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__vn_table__lookup_current_locs_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	{
	Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i5,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i8,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_util__classify_loc_cost_2_0);
	call_localret(ENTRY(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__choose_loc_for_shared_vn", 34);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i14,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i15,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_flush__find_cheap_users_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i22,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	{
	Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i23,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i26,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_util__classify_loc_cost_2_0);
	call_localret(ENTRY(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i30);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i30);
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__choose_loc_for_shared_vn", 34);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i35,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	}
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_flush__choose_temp_5_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i37,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i37);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module5)
	init_entry(mercury__vn_flush__choose_temp_5_0);
	init_label(mercury__vn_flush__choose_temp_5_0_i2);
	init_label(mercury__vn_flush__choose_temp_5_0_i3);
	init_label(mercury__vn_flush__choose_temp_5_0_i4);
BEGIN_CODE

/* code for predicate 'vn_flush__choose_temp'/5 in mode 0 */
Define_static(mercury__vn_flush__choose_temp_5_0);
	incr_sp_push_msg(2, "vn_flush__choose_temp");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r2;
	r2 = string_const("vn_flush__choose_temp", 21);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__choose_temp_5_0_i2,
		STATIC(mercury__vn_flush__choose_temp_5_0));
	}
Define_label(mercury__vn_flush__choose_temp_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_temp_5_0));
	{
	Declare_entry(mercury__vn_type__vnrval_type_2_0);
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__choose_temp_5_0_i3,
		STATIC(mercury__vn_flush__choose_temp_5_0));
	}
Define_label(mercury__vn_flush__choose_temp_5_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_temp_5_0));
	if (((Integer) r1 != ((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__choose_temp_5_0_i4);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__vn_temploc__next_tempf_3_0);
	tailcall(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		STATIC(mercury__vn_flush__choose_temp_5_0));
	}
Define_label(mercury__vn_flush__choose_temp_5_0_i4);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__vn_temploc__next_tempr_3_0);
	tailcall(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		STATIC(mercury__vn_flush__choose_temp_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module6)
	init_entry(mercury__vn_flush__find_cheap_users_3_0);
	init_label(mercury__vn_flush__find_cheap_users_3_0_i4);
	init_label(mercury__vn_flush__find_cheap_users_3_0_i3);
BEGIN_CODE

/* code for predicate 'vn_flush__find_cheap_users'/3 in mode 0 */
Define_static(mercury__vn_flush__find_cheap_users_3_0);
	incr_sp_push_msg(2, "vn_flush__find_cheap_users");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__vn_table__search_uses_3_0);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_flush__find_cheap_users_3_0_i4,
		STATIC(mercury__vn_flush__find_cheap_users_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_3_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__vn_flush__find_cheap_users_2_3_0),
		STATIC(mercury__vn_flush__find_cheap_users_3_0));
Define_label(mercury__vn_flush__find_cheap_users_3_0_i3);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module7)
	init_entry(mercury__vn_flush__find_cheap_users_2_3_0);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i4);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i10);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i12);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i13);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i21);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i25);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i28);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i29);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i23);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i1034);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i20);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i32);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i16);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i9);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i5);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i1023);
BEGIN_CODE

/* code for predicate 'vn_flush__find_cheap_users_2'/3 in mode 0 */
Define_static(mercury__vn_flush__find_cheap_users_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i1023);
	incr_sp_push_msg(8, "vn_flush__find_cheap_users_2");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_flush__find_cheap_users_2_3_0,
		LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i4),
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i5);
	r2 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i10,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i9);
	r1 = (Integer) r2;
	r2 = string_const("vn_flush__find_cheap_users_2", 28);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i12,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i13);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i13);
	detstackvar(5) = (Integer) curfr;
	detstackvar(6) = (Integer) maxfr;
	detstackvar(7) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i20);
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	{
	Declare_entry(mercury__list__member_2_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__vn_flush__find_cheap_users_2_3_0_i21,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i23);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i25,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i23);
	{
	Declare_entry(do_redo);
	if ((tag((Integer) detstackvar(4)) != mktag(((Integer) 1))))
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) r2;
	r2 = string_const("vn_flush__find_cheap_users_2", 28);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i28,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i29,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
	}
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i1034);
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i23);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i1034);
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i32);
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i16);
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i32);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i16);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i9);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i1023);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module8)
	init_entry(mercury__vn_flush__ensure_assignment_9_0);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i4);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i6);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i1005);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i8);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i3);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i9);
BEGIN_CODE

/* code for predicate 'vn_flush__ensure_assignment'/9 in mode 0 */
Define_static(mercury__vn_flush__ensure_assignment_9_0);
	incr_sp_push_msg(8, "vn_flush__ensure_assignment");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__ensure_assignment_9_0_i4,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
	}
Define_label(mercury__vn_flush__ensure_assignment_9_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__ensure_assignment_9_0_i3);
	if (((Integer) detstackvar(2) != (Integer) r2))
		GOTO_LABEL(mercury__vn_flush__ensure_assignment_9_0_i3);
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__del_old_use_4_0);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__ensure_assignment_9_0_i6,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
	}
Define_label(mercury__vn_flush__ensure_assignment_9_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__ensure_assignment_9_0_i1005,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
	}
Define_label(mercury__vn_flush__ensure_assignment_9_0_i1005);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__vn_table__del_old_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__del_old_uses_4_0),
		mercury__vn_flush__ensure_assignment_9_0_i8,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
	}
Define_label(mercury__vn_flush__ensure_assignment_9_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__ensure_assignment_9_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__ensure_assignment_9_0_i9,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
Define_label(mercury__vn_flush__ensure_assignment_9_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	r3 = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module9)
	init_entry(mercury__vn_flush__generate_assignment_10_0);
	init_label(mercury__vn_flush__generate_assignment_10_0_i5);
	init_label(mercury__vn_flush__generate_assignment_10_0_i2);
	init_label(mercury__vn_flush__generate_assignment_10_0_i6);
	init_label(mercury__vn_flush__generate_assignment_10_0_i9);
	init_label(mercury__vn_flush__generate_assignment_10_0_i8);
	init_label(mercury__vn_flush__generate_assignment_10_0_i11);
	init_label(mercury__vn_flush__generate_assignment_10_0_i12);
	init_label(mercury__vn_flush__generate_assignment_10_0_i13);
	init_label(mercury__vn_flush__generate_assignment_10_0_i14);
	init_label(mercury__vn_flush__generate_assignment_10_0_i17);
	init_label(mercury__vn_flush__generate_assignment_10_0_i18);
	init_label(mercury__vn_flush__generate_assignment_10_0_i19);
	init_label(mercury__vn_flush__generate_assignment_10_0_i16);
	init_label(mercury__vn_flush__generate_assignment_10_0_i15);
	init_label(mercury__vn_flush__generate_assignment_10_0_i22);
	init_label(mercury__vn_flush__generate_assignment_10_0_i24);
	init_label(mercury__vn_flush__generate_assignment_10_0_i21);
	init_label(mercury__vn_flush__generate_assignment_10_0_i25);
	init_label(mercury__vn_flush__generate_assignment_10_0_i26);
	init_label(mercury__vn_flush__generate_assignment_10_0_i27);
BEGIN_CODE

/* code for predicate 'vn_flush__generate_assignment'/10 in mode 0 */
Define_static(mercury__vn_flush__generate_assignment_10_0);
	incr_sp_push_msg(15, "vn_flush__generate_assignment");
	detstackvar(15) = (Integer) succip;
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	r1 = string_const("vn_hp should never need to be explicitly flushed", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__generate_assignment_10_0_i5,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i6);
Define_label(mercury__vn_flush__generate_assignment_10_0_i2);
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r4;
	r4 = (Integer) tempr1;
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i6);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r2;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__generate_assignment_10_0_i9,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i8);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i11);
Define_label(mercury__vn_flush__generate_assignment_10_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__vn_flush__generate_assignment_10_0_i11);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__vn_temploc__no_temploc_3_0);
	call_localret(ENTRY(mercury__vn_temploc__no_temploc_3_0),
		mercury__vn_flush__generate_assignment_10_0_i12,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	r5 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(8);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__generate_assignment_10_0_i13,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r4;
	r1 = (Integer) detstackvar(2);
	r6 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	r4 = (Integer) r6;
	r5 = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__generate_assignment_10_0_i14,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i16);
	detstackvar(13) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(5) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	detstackvar(11) = (Integer) r1;
	detstackvar(12) = (Integer) r4;
	{
	Declare_entry(mercury__vn_util__find_lvals_in_rval_2_0);
	call_localret(ENTRY(mercury__vn_util__find_lvals_in_rval_2_0),
		mercury__vn_flush__generate_assignment_10_0_i17,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__generate_assignment_10_0_i18,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__maybe_save_prev_value_10_0),
		mercury__vn_flush__generate_assignment_10_0_i19,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r4 = (Integer) r2;
	r9 = (Integer) r3;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i15);
Define_label(mercury__vn_flush__generate_assignment_10_0_i16);
	r7 = (Integer) r1;
	r8 = (Integer) r4;
	r4 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__vn_flush__generate_assignment_10_0_i15);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	detstackvar(9) = (Integer) r5;
	detstackvar(10) = (Integer) r6;
	detstackvar(11) = (Integer) r7;
	detstackvar(12) = (Integer) r8;
	detstackvar(13) = (Integer) r2;
	detstackvar(14) = (Integer) r9;
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__generate_assignment_10_0_i22,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i21);
	if (((Integer) detstackvar(2) != (Integer) r2))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i21);
	r1 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__vn_flush__get_incr_hp_3_0),
		mercury__vn_flush__generate_assignment_10_0_i24,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r3 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(14);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i26);
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__generate_assignment_10_0_i25,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r3 = (Integer) r1;
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(9);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(14);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("vn flush", 8);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i26);
	detstackvar(5) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	detstackvar(9) = (Integer) r5;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_flush__generate_assignment_10_0_i27,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module10)
	init_entry(mercury__vn_flush__get_incr_hp_3_0);
	init_label(mercury__vn_flush__get_incr_hp_3_0_i1006);
	init_label(mercury__vn_flush__get_incr_hp_3_0_i7);
	init_label(mercury__vn_flush__get_incr_hp_3_0_i1005);
BEGIN_CODE

/* code for predicate 'vn_flush__get_incr_hp'/3 in mode 0 */
Define_static(mercury__vn_flush__get_incr_hp_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__get_incr_hp_3_0_i1005);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__get_incr_hp_3_0_i1006);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 10)))
		GOTO_LABEL(mercury__vn_flush__get_incr_hp_3_0_i1006);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__vn_flush__get_incr_hp_3_0_i1006);
	incr_sp_push_msg(2, "vn_flush__get_incr_hp");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__vn_flush__get_incr_hp_3_0,
		LABEL(mercury__vn_flush__get_incr_hp_3_0_i7),
		STATIC(mercury__vn_flush__get_incr_hp_3_0));
Define_label(mercury__vn_flush__get_incr_hp_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__get_incr_hp_3_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_flush__get_incr_hp_3_0_i1005);
	r1 = string_const("could not find incr_hp", 22);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_flush__get_incr_hp_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module11)
	init_entry(mercury__vn_flush__vn_10_0);
	init_label(mercury__vn_flush__vn_10_0_i1000);
	init_label(mercury__vn_flush__vn_10_0_i5);
	init_label(mercury__vn_flush__vn_10_0_i6);
	init_label(mercury__vn_flush__vn_10_0_i7);
	init_label(mercury__vn_flush__vn_10_0_i10);
	init_label(mercury__vn_flush__vn_10_0_i11);
	init_label(mercury__vn_flush__vn_10_0_i12);
	init_label(mercury__vn_flush__vn_10_0_i15);
	init_label(mercury__vn_flush__vn_10_0_i20);
	init_label(mercury__vn_flush__vn_10_0_i17);
	init_label(mercury__vn_flush__vn_10_0_i25);
	init_label(mercury__vn_flush__vn_10_0_i29);
	init_label(mercury__vn_flush__vn_10_0_i30);
	init_label(mercury__vn_flush__vn_10_0_i22);
	init_label(mercury__vn_flush__vn_10_0_i21);
	init_label(mercury__vn_flush__vn_10_0_i31);
	init_label(mercury__vn_flush__vn_10_0_i14);
	init_label(mercury__vn_flush__vn_10_0_i40);
	init_label(mercury__vn_flush__vn_10_0_i34);
	init_label(mercury__vn_flush__vn_10_0_i9);
	init_label(mercury__vn_flush__vn_10_0_i45);
	init_label(mercury__vn_flush__vn_10_0_i8);
	init_label(mercury__vn_flush__vn_10_0_i46);
BEGIN_CODE

/* code for predicate 'vn_flush__vn'/10 in mode 0 */
Define_static(mercury__vn_flush__vn_10_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i1000);
	r7 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r4;
	r4 = (Integer) tempr1;
	incr_sp_push_msg(13, "vn_flush__vn");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__vn_10_0_i6);
	}
Define_label(mercury__vn_flush__vn_10_0_i1000);
	incr_sp_push_msg(13, "vn_flush__vn");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	r1 = string_const("empty source list in flush_vn", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__vn_10_0_i5,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(10);
Define_label(mercury__vn_flush__vn_10_0_i6);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(10) = (Integer) r7;
	{
	Declare_entry(mercury__vn_util__is_const_expr_3_0);
	call_localret(ENTRY(mercury__vn_util__is_const_expr_3_0),
		mercury__vn_flush__vn_10_0_i7,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i9);
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__vn", 12);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_table__lookup_current_locs_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__vn_10_0_i10,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__vn", 12);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__vn_10_0_i11,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	r3 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__vn_10_0_i12,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__vn_10_0_i15,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i14);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i17);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__old_hp_9_0),
		mercury__vn_flush__vn_10_0_i20,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = (Integer) r3;
	r6 = (Integer) r4;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_flush__vn_10_0_i8);
Define_label(mercury__vn_flush__vn_10_0_i17);
	r3 = (Integer) detstackvar(11);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i21);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i21);
	r1 = (Integer) r2;
	detstackvar(12) = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__classify_loc_cost_2_0);
	call_localret(ENTRY(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_flush__vn_10_0_i25,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (((Integer) r1 <= ((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i22);
	if ((tag((Integer) detstackvar(10)) == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i22);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__vn_flush__choose_temp_5_0),
		mercury__vn_flush__vn_10_0_i29,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__vn_10_0_i30,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = (Integer) r2;
	r6 = (Integer) r4;
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_flush__vn_10_0_i8);
Define_label(mercury__vn_flush__vn_10_0_i22);
	r2 = (Integer) detstackvar(12);
Define_label(mercury__vn_flush__vn_10_0_i21);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_10_0_i31,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r6 = (Integer) r4;
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	r5 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_flush__vn_10_0_i8);
Define_label(mercury__vn_flush__vn_10_0_i14);
	r1 = (Integer) detstackvar(11);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i34);
	if ((tag((Integer) detstackvar(10)) == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i34);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0),
		mercury__vn_flush__vn_10_0_i40,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__vn_10_0_i30,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i34);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_value_10_0),
		mercury__vn_flush__vn_10_0_i20,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i9);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_value_10_0),
		mercury__vn_flush__vn_10_0_i45,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i45);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = (Integer) r3;
	r6 = (Integer) r4;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
Define_label(mercury__vn_flush__vn_10_0_i8);
	detstackvar(4) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(9) = (Integer) r6;
	{
	Declare_entry(mercury__vn_table__del_old_use_4_0);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__vn_10_0_i46,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i46);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module12)
	init_entry(mercury__vn_flush__vn_value_10_0);
	init_label(mercury__vn_flush__vn_value_10_0_i2);
	init_label(mercury__vn_flush__vn_value_10_0_i6);
	init_label(mercury__vn_flush__vn_value_10_0_i8);
	init_label(mercury__vn_flush__vn_value_10_0_i7);
	init_label(mercury__vn_flush__vn_value_10_0_i9);
	init_label(mercury__vn_flush__vn_value_10_0_i10);
	init_label(mercury__vn_flush__vn_value_10_0_i11);
	init_label(mercury__vn_flush__vn_value_10_0_i5);
	init_label(mercury__vn_flush__vn_value_10_0_i16);
	init_label(mercury__vn_flush__vn_value_10_0_i13);
	init_label(mercury__vn_flush__vn_value_10_0_i17);
	init_label(mercury__vn_flush__vn_value_10_0_i18);
	init_label(mercury__vn_flush__vn_value_10_0_i21);
	init_label(mercury__vn_flush__vn_value_10_0_i20);
	init_label(mercury__vn_flush__vn_value_10_0_i22);
	init_label(mercury__vn_flush__vn_value_10_0_i25);
	init_label(mercury__vn_flush__vn_value_10_0_i24);
	init_label(mercury__vn_flush__vn_value_10_0_i27);
	init_label(mercury__vn_flush__vn_value_10_0_i28);
	init_label(mercury__vn_flush__vn_value_10_0_i29);
	init_label(mercury__vn_flush__vn_value_10_0_i31);
	init_label(mercury__vn_flush__vn_value_10_0_i12);
	init_label(mercury__vn_flush__vn_value_10_0_i35);
	init_label(mercury__vn_flush__vn_value_10_0_i38);
	init_label(mercury__vn_flush__vn_value_10_0_i39);
	init_label(mercury__vn_flush__vn_value_10_0_i43);
	init_label(mercury__vn_flush__vn_value_10_0_i1049);
	init_label(mercury__vn_flush__vn_value_10_0_i34);
	init_label(mercury__vn_flush__vn_value_10_0_i45);
	init_label(mercury__vn_flush__vn_value_10_0_i32);
BEGIN_CODE

/* code for predicate 'vn_flush__vn_value'/10 in mode 0 */
Define_static(mercury__vn_flush__vn_value_10_0);
	incr_sp_push_msg(13, "vn_flush__vn_value");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	r2 = string_const("vn_flush__vn_value", 18);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__vn_value_10_0_i2,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i5);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	field(mktag(2), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 4));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i6);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i7);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i8,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i7);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r4 = (Integer) detstackvar(4);
	tag_incr_hp(detstackvar(4), mktag(1), ((Integer) 2));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	tempr2 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr2, ((Integer) 1)) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) tempr2;
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i9,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r4;
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i10,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	detstackvar(1) = (Integer) tempr1;
	detstackvar(5) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__vn_value_10_0_i11,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
	}
Define_label(mercury__vn_flush__vn_value_10_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i5);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i12);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i13);
	detstackvar(5) = (Integer) r2;
	r1 = string_const("vn_hp found in flush_vn_value", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__vn_value_10_0_i16,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i17);
Define_label(mercury__vn_flush__vn_value_10_0_i13);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) r2;
	r2 = string_const("vn_flush__vn_value", 18);
Define_label(mercury__vn_flush__vn_value_10_0_i17);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r3;
	detstackvar(6) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	{
	Declare_entry(mercury__vn_table__lookup_current_locs_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__vn_value_10_0_i18,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("vn_flush__vn_value", 18);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_value_4_0),
		mercury__vn_flush__vn_value_10_0_i21,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if (((Integer) detstackvar(1) != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i20);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(5);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i22);
Define_label(mercury__vn_flush__vn_value_10_0_i20);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(7);
Define_label(mercury__vn_flush__vn_value_10_0_i22);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	{
	Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__vn_value_10_0_i25,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i24);
	r1 = (Integer) r2;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_value_10_0_i31,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i24);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__opt_debug__dump_vnlval_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_flush__vn_value_10_0_i27,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r2 = (Integer) r1;
	r1 = string_const("cannot find copy of an origlval: ", 33);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__vn_flush__vn_value_10_0_i28,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__vn_value_10_0_i29,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_value_10_0_i31,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i32);
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(11) = (Integer) r1;
	r2 = string_const("vn_flush__vn_value", 18);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__vn_value_10_0_i35,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i34);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i34);
	r1 = (Integer) detstackvar(11);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i38,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	detstackvar(7) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__vn_value", 18);
	detstackvar(9) = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_current_locs_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__vn_value_10_0_i39,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i1049);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_value_10_0_i43,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i1049);
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i34);
	r1 = (Integer) detstackvar(11);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i45,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i45);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i32);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module13)
	init_entry(mercury__vn_flush__old_hp_9_0);
	init_label(mercury__vn_flush__old_hp_9_0_i2);
	init_label(mercury__vn_flush__old_hp_9_0_i3);
	init_label(mercury__vn_flush__old_hp_9_0_i6);
	init_label(mercury__vn_flush__old_hp_9_0_i7);
	init_label(mercury__vn_flush__old_hp_9_0_i11);
	init_label(mercury__vn_flush__old_hp_9_0_i5);
	init_label(mercury__vn_flush__old_hp_9_0_i19);
	init_label(mercury__vn_flush__old_hp_9_0_i4);
	init_label(mercury__vn_flush__old_hp_9_0_i20);
	init_label(mercury__vn_flush__old_hp_9_0_i21);
	init_label(mercury__vn_flush__old_hp_9_0_i22);
	init_label(mercury__vn_flush__old_hp_9_0_i25);
	init_label(mercury__vn_flush__old_hp_9_0_i26);
	init_label(mercury__vn_flush__old_hp_9_0_i27);
	init_label(mercury__vn_flush__old_hp_9_0_i28);
	init_label(mercury__vn_flush__old_hp_9_0_i33);
	init_label(mercury__vn_flush__old_hp_9_0_i39);
	init_label(mercury__vn_flush__old_hp_9_0_i35);
	init_label(mercury__vn_flush__old_hp_9_0_i42);
	init_label(mercury__vn_flush__old_hp_9_0_i43);
	init_label(mercury__vn_flush__old_hp_9_0_i46);
	init_label(mercury__vn_flush__old_hp_9_0_i48);
	init_label(mercury__vn_flush__old_hp_9_0_i49);
	init_label(mercury__vn_flush__old_hp_9_0_i41);
	init_label(mercury__vn_flush__old_hp_9_0_i50);
	init_label(mercury__vn_flush__old_hp_9_0_i51);
	init_label(mercury__vn_flush__old_hp_9_0_i53);
	init_label(mercury__vn_flush__old_hp_9_0_i54);
	init_label(mercury__vn_flush__old_hp_9_0_i29);
	init_label(mercury__vn_flush__old_hp_9_0_i57);
	init_label(mercury__vn_flush__old_hp_9_0_i58);
	init_label(mercury__vn_flush__old_hp_9_0_i60);
	init_label(mercury__vn_flush__old_hp_9_0_i61);
	init_label(mercury__vn_flush__old_hp_9_0_i59);
	init_label(mercury__vn_flush__old_hp_9_0_i62);
	init_label(mercury__vn_flush__old_hp_9_0_i65);
	init_label(mercury__vn_flush__old_hp_9_0_i67);
	init_label(mercury__vn_flush__old_hp_9_0_i68);
	init_label(mercury__vn_flush__old_hp_9_0_i69);
	init_label(mercury__vn_flush__old_hp_9_0_i64);
	init_label(mercury__vn_flush__old_hp_9_0_i70);
	init_label(mercury__vn_flush__old_hp_9_0_i71);
	init_label(mercury__vn_flush__old_hp_9_0_i72);
BEGIN_CODE

/* code for predicate 'vn_flush__old_hp'/9 in mode 0 */
Define_static(mercury__vn_flush__old_hp_9_0);
	incr_sp_push_msg(17, "vn_flush__old_hp");
	detstackvar(17) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	r2 = string_const("vn_flush__old_hp", 16);
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_flush__old_hp_9_0_i2,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__vn_flush__hp_incr_10_0),
		mercury__vn_flush__old_hp_9_0_i3,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i5);
	detstackvar(4) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_type__bytes_per_word_2_0);
	call_localret(ENTRY(mercury__vn_type__bytes_per_word_2_0),
		mercury__vn_flush__old_hp_9_0_i6,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(8);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i7);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i7);
	r10 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	if ((tag((Integer) r10) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i7);
	tag_incr_hp(r9, mktag(3), ((Integer) 2));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(tempr2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = ((Integer) field(mktag(1), (Integer) r10, ((Integer) 0)) / (Integer) r1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) tempr2;
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i4);
	}
Define_label(mercury__vn_flush__old_hp_9_0_i7);
	if ((tag((Integer) detstackvar(8)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if (((Integer) field(mktag(3), (Integer) detstackvar(8), ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(8), ((Integer) 1));
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(8), ((Integer) 3));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if (((Integer) r1 != (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) r2, ((Integer) 1)), ((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) field(mktag(3), (Integer) detstackvar(8), ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i4);
Define_label(mercury__vn_flush__old_hp_9_0_i11);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	tag_incr_hp(r9, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = ((Integer) 3);
	field(mktag(3), (Integer) r9, ((Integer) 2)) = (Integer) detstackvar(8);
	tag_incr_hp(r10, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r10, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	field(mktag(3), (Integer) r9, ((Integer) 3)) = (Integer) r10;
	field(mktag(3), (Integer) r10, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i4);
	}
Define_label(mercury__vn_flush__old_hp_9_0_i5);
	detstackvar(4) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	r1 = string_const("empty expression for hp increment", 33);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i19,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
Define_label(mercury__vn_flush__old_hp_9_0_i4);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i20,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = (Integer) r1;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_3);
	r2 = string_const("vn_flush__old_hp", 16);
	{
	Declare_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__old_hp_9_0_i21,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i22);
	r9 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i26);
	}
Define_label(mercury__vn_flush__old_hp_9_0_i22);
	detstackvar(10) = (Integer) r1;
	r1 = string_const("empty src list in vn_flush__old_hp", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i25,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r9 = (Integer) detstackvar(3);
Define_label(mercury__vn_flush__old_hp_9_0_i26);
	detstackvar(2) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r3;
	detstackvar(10) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r9;
	{
	Declare_entry(mercury__vn_table__del_old_use_4_0);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__old_hp_9_0_i27,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = (Integer) r1;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = string_const("vn_flush__old_hp", 16);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__old_hp_9_0_i28,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i29);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i29);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__old_hp", 16);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__old_hp_9_0_i33,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i29);
	if (((Integer) detstackvar(10) != (Integer) field(mktag(1), (Integer) r1, ((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i29);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) detstackvar(3) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i35);
	if ((tag((Integer) field(mktag(1), (Integer) detstackvar(3), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i35);
	detstackvar(12) = (Integer) r3;
	detstackvar(13) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) detstackvar(3), ((Integer) 0)), ((Integer) 0));
	detstackvar(14) = (Integer) r1;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__old_hp_9_0_i39,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(3), (Integer) mercury_data_vn_flush__common_7);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(1);
	r12 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i62);
Define_label(mercury__vn_flush__old_hp_9_0_i35);
	detstackvar(12) = (Integer) r3;
	detstackvar(13) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__vn_flush__find_cheap_users_3_0),
		mercury__vn_flush__old_hp_9_0_i42,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	{
	Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__old_hp_9_0_i43,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i41);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i41);
	detstackvar(14) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__old_hp_9_0_i46,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i46);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i48);
	r11 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(3), (Integer) mercury_data_vn_flush__common_7);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r12 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i62);
Define_label(mercury__vn_flush__old_hp_9_0_i48);
	r1 = string_const("register needs access path", 26);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i49,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r1 = (Integer) detstackvar(14);
	r11 = (Integer) detstackvar(15);
	r12 = (Integer) detstackvar(16);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i62);
Define_label(mercury__vn_flush__old_hp_9_0_i41);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__vn_temploc__next_tempr_3_0);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__old_hp_9_0_i50,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i50);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	detstackvar(14) = (Integer) r2;
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__old_hp_9_0_i51,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i51);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i53);
	r11 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(3), (Integer) mercury_data_vn_flush__common_7);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r12 = (Integer) detstackvar(16);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i62);
Define_label(mercury__vn_flush__old_hp_9_0_i53);
	r1 = string_const("temploc needs access path", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i54,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r1 = (Integer) detstackvar(14);
	r11 = (Integer) detstackvar(15);
	r12 = (Integer) detstackvar(16);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i62);
Define_label(mercury__vn_flush__old_hp_9_0_i29);
	detstackvar(13) = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__vn_temploc__next_tempr_3_0);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__old_hp_9_0_i57,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i57);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	detstackvar(14) = (Integer) r2;
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__old_hp_9_0_i58,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i58);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i60);
	r3 = (Integer) detstackvar(2);
	r10 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(16);
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r10;
	r1 = (Integer) detstackvar(14);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i59);
Define_label(mercury__vn_flush__old_hp_9_0_i60);
	r1 = string_const("temploc needs access path", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i61,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i61);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(14);
	r10 = (Integer) detstackvar(15);
	r11 = (Integer) detstackvar(16);
Define_label(mercury__vn_flush__old_hp_9_0_i59);
	r12 = (Integer) r11;
	r11 = (Integer) r10;
	r10 = (Integer) r9;
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__vn_flush__old_hp_9_0_i62);
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(9) = (Integer) r8;
	detstackvar(11) = (Integer) r2;
	detstackvar(12) = (Integer) r9;
	detstackvar(13) = (Integer) r10;
	detstackvar(14) = (Integer) r1;
	detstackvar(15) = (Integer) r11;
	detstackvar(16) = (Integer) r12;
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__old_hp_9_0_i65,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i65);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i64);
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__vn_util__find_lvals_in_rval_2_0);
	call_localret(ENTRY(mercury__vn_util__find_lvals_in_rval_2_0),
		mercury__vn_flush__old_hp_9_0_i67,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i67);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__old_hp_9_0_i68,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i68);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(16);
	r7 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__maybe_save_prev_value_10_0),
		mercury__vn_flush__old_hp_9_0_i69,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i69);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r5 = (Integer) r2;
	r10 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(12);
	r9 = (Integer) detstackvar(15);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i70);
Define_label(mercury__vn_flush__old_hp_9_0_i64);
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(16);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(12);
	r9 = (Integer) detstackvar(15);
	r10 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__vn_flush__old_hp_9_0_i70);
	detstackvar(1) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(12) = (Integer) r8;
	detstackvar(15) = (Integer) r9;
	detstackvar(3) = (Integer) r10;
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i71,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i71);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 4));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(12);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(15);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 10);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_flush__old_hp_9_0_i72,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i72);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module14)
	init_entry(mercury__vn_flush__hp_incr_10_0);
	init_label(mercury__vn_flush__hp_incr_10_0_i4);
	init_label(mercury__vn_flush__hp_incr_10_0_i5);
	init_label(mercury__vn_flush__hp_incr_10_0_i6);
	init_label(mercury__vn_flush__hp_incr_10_0_i7);
	init_label(mercury__vn_flush__hp_incr_10_0_i9);
	init_label(mercury__vn_flush__hp_incr_10_0_i3);
	init_label(mercury__vn_flush__hp_incr_10_0_i10);
	init_label(mercury__vn_flush__hp_incr_10_0_i15);
	init_label(mercury__vn_flush__hp_incr_10_0_i14);
	init_label(mercury__vn_flush__hp_incr_10_0_i16);
	init_label(mercury__vn_flush__hp_incr_10_0_i18);
	init_label(mercury__vn_flush__hp_incr_10_0_i19);
	init_label(mercury__vn_flush__hp_incr_10_0_i20);
	init_label(mercury__vn_flush__hp_incr_10_0_i24);
	init_label(mercury__vn_flush__hp_incr_10_0_i25);
	init_label(mercury__vn_flush__hp_incr_10_0_i28);
	init_label(mercury__vn_flush__hp_incr_10_0_i22);
	init_label(mercury__vn_flush__hp_incr_10_0_i32);
	init_label(mercury__vn_flush__hp_incr_10_0_i31);
	init_label(mercury__vn_flush__hp_incr_10_0_i13);
	init_label(mercury__vn_flush__hp_incr_10_0_i39);
	init_label(mercury__vn_flush__hp_incr_10_0_i38);
	init_label(mercury__vn_flush__hp_incr_10_0_i44);
	init_label(mercury__vn_flush__hp_incr_10_0_i46);
	init_label(mercury__vn_flush__hp_incr_10_0_i49);
	init_label(mercury__vn_flush__hp_incr_10_0_i11);
	init_label(mercury__vn_flush__hp_incr_10_0_i51);
	init_label(mercury__vn_flush__hp_incr_10_0_i54);
	init_label(mercury__vn_flush__hp_incr_10_0_i55);
	init_label(mercury__vn_flush__hp_incr_10_0_i56);
BEGIN_CODE

/* code for predicate 'vn_flush__hp_incr'/10 in mode 0 */
Define_static(mercury__vn_flush__hp_incr_10_0);
	incr_sp_push_msg(8, "vn_flush__hp_incr");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r2 = string_const("vn_flush__rec_find_ref_vns", 26);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__hp_incr_10_0_i4,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	{
	Declare_entry(mercury__vn_util__find_sub_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__find_sub_vns_2_0),
		mercury__vn_flush__hp_incr_10_0_i5,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0),
		mercury__vn_flush__hp_incr_10_0_i6,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_flush__free_of_old_hp_2_0),
		mercury__vn_flush__hp_incr_10_0_i7,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__hp_incr_10_0_i9,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__hp_incr_10_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_flush__hp_incr", 17);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__hp_incr_10_0_i10,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i13);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i14);
	r1 = string_const("create in calculation of new hp", 31);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i15,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
Define_label(mercury__vn_flush__hp_incr_10_0_i14);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i16);
	r1 = string_const("unop in calculation of new hp", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i15,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i16);
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tag_incr_hp(detstackvar(7), mktag(1), ((Integer) 2));
	r4 = (Integer) r2;
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 1));
	r5 = (Integer) r3;
	tempr2 = (Integer) detstackvar(7);
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) tempr2;
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) tempr2, ((Integer) 1)) = (Integer) detstackvar(2);
	localcall(mercury__vn_flush__hp_incr_10_0,
		LABEL(mercury__vn_flush__hp_incr_10_0_i18),
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r5 = (Integer) r3;
	r6 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(7);
	localcall(mercury__vn_flush__hp_incr_10_0,
		LABEL(mercury__vn_flush__hp_incr_10_0_i19),
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r3;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__hp_incr_10_0_i20,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i22);
	if (((Integer) detstackvar(7) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i24);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) field(mktag(1), (Integer) detstackvar(7), ((Integer) 0));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	r3 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i24);
	if (((Integer) detstackvar(4) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i25);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
Define_label(mercury__vn_flush__hp_incr_10_0_i25);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("non-+ op on hp", 14);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i28,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
Define_label(mercury__vn_flush__hp_incr_10_0_i22);
	if (((Integer) detstackvar(7) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i31);
	if (((Integer) detstackvar(4) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i32);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
Define_label(mercury__vn_flush__hp_incr_10_0_i32);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("non-+ op on hp", 14);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i28,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i31);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("two 'no's in flush_hp_incr", 26);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i15,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i13);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i38);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i39);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
Define_label(mercury__vn_flush__hp_incr_10_0_i39);
	r1 = string_const("non-hp origlval in flush_hp_incr", 32);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i15,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i38);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i44);
	r1 = string_const("mkword in calculation of new hp", 31);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i15,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i44);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i46);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	r3 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i11);
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i46);
	r1 = string_const("non-int const in flush_hp_incr", 30);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i49,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
Define_label(mercury__vn_flush__hp_incr_10_0_i11);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i51);
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i55);
Define_label(mercury__vn_flush__hp_incr_10_0_i51);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r3;
	r1 = string_const("empty source list in flush_vn", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i54,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
Define_label(mercury__vn_flush__hp_incr_10_0_i55);
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	{
	Declare_entry(mercury__vn_table__del_old_use_4_0);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__hp_incr_10_0_i56,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i56);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module15)
	init_entry(mercury__vn_flush__free_of_old_hp_2_0);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i4);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i5);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i1003);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i1);
BEGIN_CODE

/* code for predicate 'vn_flush__free_of_old_hp'/2 in mode 0 */
Define_static(mercury__vn_flush__free_of_old_hp_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i1003);
	incr_sp_push_msg(3, "vn_flush__free_of_old_hp");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = string_const("vn_flush__free_of_old_hp", 24);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__free_of_old_hp_2_0_i4,
		STATIC(mercury__vn_flush__free_of_old_hp_2_0));
	}
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__free_of_old_hp_2_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i5);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i1);
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_flush__free_of_old_hp_2_0,
		STATIC(mercury__vn_flush__free_of_old_hp_2_0));
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module16)
	init_entry(mercury__vn_flush__rec_find_ref_vns_list_3_0);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i4);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i5);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_flush__rec_find_ref_vns_list'/3 in mode 0 */
Define_static(mercury__vn_flush__rec_find_ref_vns_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0_i1002);
	incr_sp_push_msg(4, "vn_flush__rec_find_ref_vns_list");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	r2 = string_const("vn_flush__rec_find_ref_vns", 26);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__rec_find_ref_vns_list_3_0_i4,
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	}
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	{
	Declare_entry(mercury__vn_util__find_sub_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__find_sub_vns_2_0),
		mercury__vn_flush__rec_find_ref_vns_list_3_0_i5,
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	}
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	r2 = (Integer) detstackvar(1);
	localcall(mercury__vn_flush__rec_find_ref_vns_list_3_0,
		LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6),
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	localcall(mercury__vn_flush__rec_find_ref_vns_list_3_0,
		LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7),
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__list__append_3_1);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	}
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module17)
	init_entry(mercury__vn_flush__access_path_10_0);
	init_label(mercury__vn_flush__access_path_10_0_i1035);
	init_label(mercury__vn_flush__access_path_10_0_i1034);
	init_label(mercury__vn_flush__access_path_10_0_i1033);
	init_label(mercury__vn_flush__access_path_10_0_i1032);
	init_label(mercury__vn_flush__access_path_10_0_i1031);
	init_label(mercury__vn_flush__access_path_10_0_i1030);
	init_label(mercury__vn_flush__access_path_10_0_i1023);
	init_label(mercury__vn_flush__access_path_10_0_i6);
	init_label(mercury__vn_flush__access_path_10_0_i7);
	init_label(mercury__vn_flush__access_path_10_0_i8);
	init_label(mercury__vn_flush__access_path_10_0_i9);
	init_label(mercury__vn_flush__access_path_10_0_i10);
	init_label(mercury__vn_flush__access_path_10_0_i11);
	init_label(mercury__vn_flush__access_path_10_0_i12);
	init_label(mercury__vn_flush__access_path_10_0_i13);
	init_label(mercury__vn_flush__access_path_10_0_i14);
	init_label(mercury__vn_flush__access_path_10_0_i15);
	init_label(mercury__vn_flush__access_path_10_0_i16);
	init_label(mercury__vn_flush__access_path_10_0_i17);
	init_label(mercury__vn_flush__access_path_10_0_i18);
	init_label(mercury__vn_flush__access_path_10_0_i1029);
	init_label(mercury__vn_flush__access_path_10_0_i20);
	init_label(mercury__vn_flush__access_path_10_0_i21);
	init_label(mercury__vn_flush__access_path_10_0_i22);
	init_label(mercury__vn_flush__access_path_10_0_i23);
	init_label(mercury__vn_flush__access_path_10_0_i24);
	init_label(mercury__vn_flush__access_path_10_0_i19);
	init_label(mercury__vn_flush__access_path_10_0_i25);
BEGIN_CODE

/* code for predicate 'vn_flush__access_path'/10 in mode 0 */
Define_static(mercury__vn_flush__access_path_10_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__access_path_10_0_i1029);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_flush__access_path_10_0_i1023) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1035) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1034) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1033) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1032) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1031) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1030));
Define_label(mercury__vn_flush__access_path_10_0_i1035);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__access_path_10_0_i6);
Define_label(mercury__vn_flush__access_path_10_0_i1034);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__access_path_10_0_i8);
Define_label(mercury__vn_flush__access_path_10_0_i1033);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__access_path_10_0_i10);
Define_label(mercury__vn_flush__access_path_10_0_i1032);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__access_path_10_0_i12);
Define_label(mercury__vn_flush__access_path_10_0_i1031);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__access_path_10_0_i14);
Define_label(mercury__vn_flush__access_path_10_0_i1030);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__vn_flush__access_path_10_0_i18);
Define_label(mercury__vn_flush__access_path_10_0_i1023);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	proceed();
	}
Define_label(mercury__vn_flush__access_path_10_0_i6);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r8 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i7,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i8);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r8 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i9,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i10);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r8 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i11,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i12);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r8 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i13,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i14);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	detstackvar(5) = (Integer) tempr1;
	tag_incr_hp(tempr2, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr2, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) tempr2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) tempr1;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i15,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = (Integer) r3;
	r6 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	detstackvar(2) = (Integer) r4;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i16,
		STATIC(mercury__vn_flush__access_path_10_0));
Define_label(mercury__vn_flush__access_path_10_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = (Integer) detstackvar(1);
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	tempr2 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr2;
	detstackvar(1) = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_flush__common_0);
	r3 = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__access_path_10_0_i17,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
	}
Define_label(mercury__vn_flush__access_path_10_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i18);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i1029);
	incr_sp_push_msg(6, "vn_flush__access_path");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__access_path_10_0_i19);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__vn_flush__access_path_10_0_i20) AND
		LABEL(mercury__vn_flush__access_path_10_0_i21) AND
		LABEL(mercury__vn_flush__access_path_10_0_i22) AND
		LABEL(mercury__vn_flush__access_path_10_0_i23) AND
		LABEL(mercury__vn_flush__access_path_10_0_i24));
Define_label(mercury__vn_flush__access_path_10_0_i20);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i21);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i22);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i23);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i24);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 4)));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i19);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__access_path_10_0_i25);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i25);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module18)
	init_entry(mercury__vn_flush__maybe_save_prev_value_10_0);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i4);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i5);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i7);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i12);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i13);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i14);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i19);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i20);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i22);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i27);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i29);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i30);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i41);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i42);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i43);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i44);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
BEGIN_CODE

/* code for predicate 'vn_flush__maybe_save_prev_value'/10 in mode 0 */
Define_static(mercury__vn_flush__maybe_save_prev_value_10_0);
	incr_sp_push_msg(11, "vn_flush__maybe_save_prev_value");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	r2 = (Integer) r3;
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__vn_table__set_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i4,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r2 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__vn_table__search_uses_3_0);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i5,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__vn_util__real_uses_3_0);
	call_localret(ENTRY(mercury__vn_util__real_uses_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i7,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_util__is_const_expr_3_0);
	call_localret(ENTRY(mercury__vn_util__is_const_expr_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i12,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = string_const("vn_flush__maybe_save_prev_value", 31);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_current_locs_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i13,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__maybe_save_prev_value_10_0_i14,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(STATIC(mercury__vn_flush__no_good_copies_1_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i15,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_flush__find_cheap_users_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i19,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	{
	Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i20,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i22,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i27,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__choose_temp_5_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i29,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r5 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i42);
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(8);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i30);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i30);
	if ((tag((Integer) detstackvar(9)) == mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i30);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__choose_temp_5_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i29,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i30);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i42);
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__choose_temp_5_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i29,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_flush__choose_temp_5_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i41,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r5 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i42);
	detstackvar(8) = (Integer) r7;
	call_localret(STATIC(mercury__vn_flush__ensure_assignment_9_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i43,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	detstackvar(10) = (Integer) r3;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__opt_debug__dump_uses_list_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_uses_list_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i44,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r2 = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_flush_module19)
	init_entry(mercury__vn_flush__no_good_copies_1_0);
	init_label(mercury__vn_flush__no_good_copies_1_0_i1004);
	init_label(mercury__vn_flush__no_good_copies_1_0_i1005);
BEGIN_CODE

/* code for predicate 'vn_flush__no_good_copies'/1 in mode 0 */
Define_static(mercury__vn_flush__no_good_copies_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_flush__no_good_copies_1_0_i1004);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__no_good_copies_1_0_i1005);
	if (((Integer) field(mktag(3), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__vn_flush__no_good_copies_1_0_i1005);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localtailcall(mercury__vn_flush__no_good_copies_1_0,
		STATIC(mercury__vn_flush__no_good_copies_1_0));
Define_label(mercury__vn_flush__no_good_copies_1_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_flush__no_good_copies_1_0_i1005);
	r1 = FALSE;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_flush_bunch_0(void)
{
	mercury__vn_flush_module0();
	mercury__vn_flush_module1();
	mercury__vn_flush_module2();
	mercury__vn_flush_module3();
	mercury__vn_flush_module4();
	mercury__vn_flush_module5();
	mercury__vn_flush_module6();
	mercury__vn_flush_module7();
	mercury__vn_flush_module8();
	mercury__vn_flush_module9();
	mercury__vn_flush_module10();
	mercury__vn_flush_module11();
	mercury__vn_flush_module12();
	mercury__vn_flush_module13();
	mercury__vn_flush_module14();
	mercury__vn_flush_module15();
	mercury__vn_flush_module16();
	mercury__vn_flush_module17();
	mercury__vn_flush_module18();
	mercury__vn_flush_module19();
}

#endif

void mercury__vn_flush__init(void); /* suppress gcc warning */
void mercury__vn_flush__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_flush_bunch_0();
#endif
}
