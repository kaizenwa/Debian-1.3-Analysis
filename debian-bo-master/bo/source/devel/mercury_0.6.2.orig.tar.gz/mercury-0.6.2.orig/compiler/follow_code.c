/*
** Automatically generated from `follow_code.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__follow_code__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__follow_code__move_follow_code_in_proc_4_0);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i2);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i3);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i4);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i5);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i6);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i7);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i10);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i12);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i13);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i14);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i9);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i15);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i16);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i17);
Declare_label(mercury__follow_code__move_follow_code_in_proc_4_0_i18);
Declare_static(mercury__follow_code__move_follow_code_in_goal_5_0);
Declare_label(mercury__follow_code__move_follow_code_in_goal_5_0_i2);
Declare_static(mercury__follow_code__move_follow_code_in_goal_2_5_0);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1019);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1018);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1017);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1016);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1015);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i5);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i6);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1011);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i8);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i9);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i10);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i11);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i12);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i13);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i14);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i15);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i16);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i17);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1014);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i20);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i19);
Declare_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1013);
Declare_static(mercury__follow_code__move_follow_code_in_disj_5_0);
Declare_label(mercury__follow_code__move_follow_code_in_disj_5_0_i4);
Declare_label(mercury__follow_code__move_follow_code_in_disj_5_0_i5);
Declare_label(mercury__follow_code__move_follow_code_in_disj_5_0_i1002);
Declare_static(mercury__follow_code__move_follow_code_in_cases_5_0);
Declare_label(mercury__follow_code__move_follow_code_in_cases_5_0_i4);
Declare_label(mercury__follow_code__move_follow_code_in_cases_5_0_i5);
Declare_label(mercury__follow_code__move_follow_code_in_cases_5_0_i1003);
Declare_static(mercury__follow_code__move_follow_code_in_conj_5_0);
Declare_label(mercury__follow_code__move_follow_code_in_conj_5_0_i2);
Declare_label(mercury__follow_code__move_follow_code_in_conj_5_0_i3);
Declare_static(mercury__follow_code__move_follow_code_in_conj_2_6_0);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i7);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i9);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i16);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i17);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i19);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i20);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i22);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i23);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i25);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i13);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i4);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i27);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i31);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i28);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i32);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i33);
Declare_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i1017);
Declare_static(mercury__follow_code__move_follow_code_select_3_0);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i8);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i7);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i1005);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i6);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i14);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i5);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i4);
Declare_label(mercury__follow_code__move_follow_code_select_3_0_i1008);
Declare_static(mercury__follow_code__move_follow_code_move_goals_cases_3_0);
Declare_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1001);
Declare_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i4);
Declare_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i6);
Declare_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1);
Declare_static(mercury__follow_code__move_follow_code_move_goals_disj_3_0);
Declare_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1001);
Declare_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i4);
Declare_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i6);
Declare_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1);
Declare_static(mercury__follow_code__conjoin_goal_and_goal_list_3_0);
Declare_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i2);
Declare_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i3);
Declare_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i4);
Declare_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i9);
Declare_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1007);
Declare_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1);
Declare_static(mercury__follow_code__check_follow_code_detism_3_0);
Declare_label(mercury__follow_code__check_follow_code_detism_3_0_i4);
Declare_label(mercury__follow_code__check_follow_code_detism_3_0_i5);
Declare_label(mercury__follow_code__check_follow_code_detism_3_0_i6);
Declare_label(mercury__follow_code__check_follow_code_detism_3_0_i7);
Declare_label(mercury__follow_code__check_follow_code_detism_3_0_i1004);
Declare_label(mercury__follow_code__check_follow_code_detism_3_0_i1);
Declare_static(mercury__follow_code__move_prev_code_forbidden_vars_2_0);
Declare_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i4);
Declare_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i5);
Declare_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i1003);

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_follow_code__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

BEGIN_MODULE(mercury__follow_code_module0)
	init_entry(mercury__follow_code__move_follow_code_in_proc_4_0);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i2);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i3);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i4);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i5);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i6);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i7);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i10);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i12);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i13);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i14);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i9);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i15);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i16);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i17);
	init_label(mercury__follow_code__move_follow_code_in_proc_4_0_i18);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_proc'/4 in mode 0 */
Define_entry(mercury__follow_code__move_follow_code_in_proc_4_0);
	incr_sp_push_msg(9, "move_follow_code_in_proc");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_globals_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i2,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	detstackvar(3) = (Integer) r1;
	r2 = ((Integer) 102);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i3,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i3);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 103);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i4,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i5,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i6,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i6);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i7,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i10,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i10);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_proc_4_0_i9);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i12,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i13,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r3;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__mode_util__recompute_instmap_delta_4_0);
	call_localret(ENTRY(mercury__mode_util__recompute_instmap_delta_4_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i14,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i14);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_proc_4_0_i15);
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i9);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i15);
	detstackvar(3) = (Integer) r3;
	detstackvar(7) = (Integer) r4;
	detstackvar(8) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i16,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i16);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_varset_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_varset_3_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i17,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i17);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		mercury__follow_code__move_follow_code_in_proc_4_0_i18,
		ENTRY(mercury__follow_code__move_follow_code_in_proc_4_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_proc_4_0_i18);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_proc_4_0));
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module1)
	init_entry(mercury__follow_code__move_follow_code_in_goal_5_0);
	init_label(mercury__follow_code__move_follow_code_in_goal_5_0_i2);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_goal'/5 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_in_goal_5_0);
	incr_sp_push_msg(2, "move_follow_code_in_goal");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0),
		mercury__follow_code__move_follow_code_in_goal_5_0_i2,
		STATIC(mercury__follow_code__move_follow_code_in_goal_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_5_0_i2);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module2)
	init_entry(mercury__follow_code__move_follow_code_in_goal_2_5_0);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1019);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1018);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1017);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1016);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1015);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i5);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i6);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1011);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i8);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i9);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i10);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i11);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i12);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i13);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i14);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i15);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i16);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i17);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1014);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i20);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i19);
	init_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1013);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_goal_2'/5 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_in_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1014);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1019) AND
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1011) AND
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1018) AND
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1017) AND
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1016) AND
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1015) AND
		LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1011));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1019);
	incr_sp_push_msg(6, "move_follow_code_in_goal_2");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i5);
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1018);
	incr_sp_push_msg(6, "move_follow_code_in_goal_2");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i8);
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1017);
	incr_sp_push_msg(6, "move_follow_code_in_goal_2");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i10);
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1016);
	incr_sp_push_msg(6, "move_follow_code_in_goal_2");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i12);
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1015);
	incr_sp_push_msg(6, "move_follow_code_in_goal_2");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i14);
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_cases_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i6,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1011);
	r2 = (Integer) r3;
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_disj_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i9,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i11,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i12);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i13,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i14);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i15,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i16,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i17,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1014);
	incr_sp_push_msg(6, "move_follow_code_in_goal_2");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i19);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_conj_5_0),
		mercury__follow_code__move_follow_code_in_goal_2_5_0_i20,
		STATIC(mercury__follow_code__move_follow_code_in_goal_2_5_0));
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i20);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1013);
	r2 = (Integer) r3;
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_goal_2_5_0_i1013);
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module3)
	init_entry(mercury__follow_code__move_follow_code_in_disj_5_0);
	init_label(mercury__follow_code__move_follow_code_in_disj_5_0_i4);
	init_label(mercury__follow_code__move_follow_code_in_disj_5_0_i5);
	init_label(mercury__follow_code__move_follow_code_in_disj_5_0_i1002);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_disj'/5 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_in_disj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_disj_5_0_i1002);
	incr_sp_push_msg(3, "move_follow_code_in_disj");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_disj_5_0_i4,
		STATIC(mercury__follow_code__move_follow_code_in_disj_5_0));
Define_label(mercury__follow_code__move_follow_code_in_disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_disj_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__follow_code__move_follow_code_in_disj_5_0,
		LABEL(mercury__follow_code__move_follow_code_in_disj_5_0_i5),
		STATIC(mercury__follow_code__move_follow_code_in_disj_5_0));
Define_label(mercury__follow_code__move_follow_code_in_disj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_disj_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_disj_5_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module4)
	init_entry(mercury__follow_code__move_follow_code_in_cases_5_0);
	init_label(mercury__follow_code__move_follow_code_in_cases_5_0_i4);
	init_label(mercury__follow_code__move_follow_code_in_cases_5_0_i5);
	init_label(mercury__follow_code__move_follow_code_in_cases_5_0_i1003);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_cases'/5 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_in_cases_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_cases_5_0_i1003);
	incr_sp_push_msg(4, "move_follow_code_in_cases");
	detstackvar(4) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_cases_5_0_i4,
		STATIC(mercury__follow_code__move_follow_code_in_cases_5_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_cases_5_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_cases_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	localcall(mercury__follow_code__move_follow_code_in_cases_5_0,
		LABEL(mercury__follow_code__move_follow_code_in_cases_5_0_i5),
		STATIC(mercury__follow_code__move_follow_code_in_cases_5_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_cases_5_0_i5);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_cases_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__follow_code__move_follow_code_in_cases_5_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module5)
	init_entry(mercury__follow_code__move_follow_code_in_conj_5_0);
	init_label(mercury__follow_code__move_follow_code_in_conj_5_0_i2);
	init_label(mercury__follow_code__move_follow_code_in_conj_5_0_i3);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_conj'/5 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_in_conj_5_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(2, "move_follow_code_in_conj");
	detstackvar(2) = (Integer) succip;
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0),
		mercury__follow_code__move_follow_code_in_conj_5_0_i2,
		STATIC(mercury__follow_code__move_follow_code_in_conj_5_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_5_0_i2);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_5_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_follow_code__common_0);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__follow_code__move_follow_code_in_conj_5_0_i3,
		STATIC(mercury__follow_code__move_follow_code_in_conj_5_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_5_0_i3);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module6)
	init_entry(mercury__follow_code__move_follow_code_in_conj_2_6_0);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i7);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i9);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i16);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i17);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i19);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i20);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i22);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i23);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i25);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i13);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i4);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i27);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i31);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i28);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i32);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i33);
	init_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i1017);
BEGIN_CODE

/* code for predicate 'move_follow_code_in_conj_2'/6 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_in_conj_2_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i1017);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	incr_sp_push_msg(14, "move_follow_code_in_conj_2");
	detstackvar(14) = (Integer) succip;
	if (((Integer) field(mktag(0), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i4);
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r6;
	r1 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	{
	Declare_entry(mercury__goal_util__goal_is_branched_1_0);
	call_localret(ENTRY(mercury__goal_util__goal_is_branched_1_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i7,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__follow_code__move_follow_code_select_3_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i9,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i9);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)),
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i16) AND
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5) AND
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i19) AND
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5) AND
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5) AND
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i22) AND
		LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i16);
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 1));
	call_localret(STATIC(mercury__follow_code__move_follow_code_move_goals_cases_3_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i17,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i17);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(6);
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r9;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r8, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i13);
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i19);
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 1));
	call_localret(STATIC(mercury__follow_code__move_follow_code_move_goals_disj_3_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i20,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i20);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(6);
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r8, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i13);
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i22);
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(13) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 5));
	detstackvar(12) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(10) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 1));
	call_localret(STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i23,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i23);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r3;
	r1 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i25,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i25);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(6);
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r9;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r8, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i13);
	r4 = (Integer) r7;
	r5 = ((Integer) 0);
	r6 = (Integer) r8;
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i27);
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i4);
	r1 = (Integer) r6;
	{
	Word tempr1;
	tempr1 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = (Integer) tempr1;
	r6 = (Integer) r7;
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i27);
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i28);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r1;
	call_localret(STATIC(mercury__follow_code__move_prev_code_forbidden_vars_2_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i31,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i31);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0_i32);
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i28);
	r4 = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) r5;
	r5 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	r1 = (Integer) r6;
	}
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i32);
	detstackvar(2) = (Integer) r2;
	detstackvar(9) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	call_localret(STATIC(mercury__follow_code__move_follow_code_in_goal_5_0),
		mercury__follow_code__move_follow_code_in_conj_2_6_0_i33,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i33);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_in_conj_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	localtailcall(mercury__follow_code__move_follow_code_in_conj_2_6_0,
		STATIC(mercury__follow_code__move_follow_code_in_conj_2_6_0));
Define_label(mercury__follow_code__move_follow_code_in_conj_2_6_0_i1017);
	r1 = (Integer) r2;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module7)
	init_entry(mercury__follow_code__move_follow_code_select_3_0);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i8);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i7);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i1005);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i6);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i14);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i5);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i4);
	init_label(mercury__follow_code__move_follow_code_select_3_0_i1008);
BEGIN_CODE

/* code for predicate 'move_follow_code_select'/3 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_select_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i1008);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	incr_sp_push_msg(4, "move_follow_code_select");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		mercury__follow_code__move_follow_code_select_3_0_i8,
		STATIC(mercury__follow_code__move_follow_code_select_3_0));
	}
Define_label(mercury__follow_code__move_follow_code_select_3_0_i8);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_select_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i5);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i6);
Define_label(mercury__follow_code__move_follow_code_select_3_0_i7);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i4);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i4);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 4))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i1005);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 4)), ((Integer) 0)) == ((Integer) 1)))
		GOTO_LABEL(mercury__follow_code__move_follow_code_select_3_0_i4);
Define_label(mercury__follow_code__move_follow_code_select_3_0_i1005);
	r1 = (Integer) r4;
Define_label(mercury__follow_code__move_follow_code_select_3_0_i6);
	detstackvar(2) = (Integer) r3;
	localcall(mercury__follow_code__move_follow_code_select_3_0,
		LABEL(mercury__follow_code__move_follow_code_select_3_0_i14),
		STATIC(mercury__follow_code__move_follow_code_select_3_0));
Define_label(mercury__follow_code__move_follow_code_select_3_0_i14);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_select_3_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__follow_code__move_follow_code_select_3_0_i5);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__follow_code__move_follow_code_select_3_0_i4);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__follow_code__move_follow_code_select_3_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module8)
	init_entry(mercury__follow_code__move_follow_code_move_goals_cases_3_0);
	init_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1001);
	init_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i4);
	init_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i6);
	init_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1);
BEGIN_CODE

/* code for predicate 'move_follow_code_move_goals_cases'/3 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_move_goals_cases_3_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1001);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1001);
	incr_sp_push_msg(4, "move_follow_code_move_goals_cases");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0),
		mercury__follow_code__move_follow_code_move_goals_cases_3_0_i4,
		STATIC(mercury__follow_code__move_follow_code_move_goals_cases_3_0));
Define_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_move_goals_cases_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__follow_code__move_follow_code_move_goals_cases_3_0,
		LABEL(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i6),
		STATIC(mercury__follow_code__move_follow_code_move_goals_cases_3_0));
Define_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i6);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_move_goals_cases_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__follow_code__move_follow_code_move_goals_cases_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module9)
	init_entry(mercury__follow_code__move_follow_code_move_goals_disj_3_0);
	init_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1001);
	init_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i4);
	init_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i6);
	init_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1);
BEGIN_CODE

/* code for predicate 'move_follow_code_move_goals_disj'/3 in mode 0 */
Define_static(mercury__follow_code__move_follow_code_move_goals_disj_3_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1001);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1001);
	incr_sp_push_msg(3, "move_follow_code_move_goals_disj");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0),
		mercury__follow_code__move_follow_code_move_goals_disj_3_0_i4,
		STATIC(mercury__follow_code__move_follow_code_move_goals_disj_3_0));
Define_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_move_goals_disj_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__follow_code__move_follow_code_move_goals_disj_3_0,
		LABEL(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i6),
		STATIC(mercury__follow_code__move_follow_code_move_goals_disj_3_0));
Define_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i6);
	update_prof_current_proc(LABEL(mercury__follow_code__move_follow_code_move_goals_disj_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__follow_code__move_follow_code_move_goals_disj_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module10)
	init_entry(mercury__follow_code__conjoin_goal_and_goal_list_3_0);
	init_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i2);
	init_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i3);
	init_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i4);
	init_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i9);
	init_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1007);
	init_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1);
BEGIN_CODE

/* code for predicate 'conjoin_goal_and_goal_list'/3 in mode 0 */
Define_static(mercury__follow_code__conjoin_goal_and_goal_list_3_0);
	incr_sp_push_msg(5, "conjoin_goal_and_goal_list");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__follow_code__conjoin_goal_and_goal_list_3_0_i2,
		STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	}
Define_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__follow_code__conjoin_goal_and_goal_list_3_0_i3,
		STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	}
Define_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i3);
	update_prof_current_proc(LABEL(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__follow_code__check_follow_code_detism_3_0),
		mercury__follow_code__conjoin_goal_and_goal_list_3_0_i4,
		STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
Define_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(3);
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1007);
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_follow_code__common_0);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__follow_code__conjoin_goal_and_goal_list_3_0_i9,
		STATIC(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	}
	}
Define_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i9);
	update_prof_current_proc(LABEL(mercury__follow_code__conjoin_goal_and_goal_list_3_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1007);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__follow_code__conjoin_goal_and_goal_list_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module11)
	init_entry(mercury__follow_code__check_follow_code_detism_3_0);
	init_label(mercury__follow_code__check_follow_code_detism_3_0_i4);
	init_label(mercury__follow_code__check_follow_code_detism_3_0_i5);
	init_label(mercury__follow_code__check_follow_code_detism_3_0_i6);
	init_label(mercury__follow_code__check_follow_code_detism_3_0_i7);
	init_label(mercury__follow_code__check_follow_code_detism_3_0_i1004);
	init_label(mercury__follow_code__check_follow_code_detism_3_0_i1);
BEGIN_CODE

/* code for predicate 'check_follow_code_detism'/3 in mode 0 */
Define_static(mercury__follow_code__check_follow_code_detism_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__check_follow_code_detism_3_0_i1004);
	incr_sp_push_msg(5, "check_follow_code_detism");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__follow_code__check_follow_code_detism_3_0_i4,
		STATIC(mercury__follow_code__check_follow_code_detism_3_0));
	}
Define_label(mercury__follow_code__check_follow_code_detism_3_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__check_follow_code_detism_3_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__follow_code__check_follow_code_detism_3_0_i5,
		STATIC(mercury__follow_code__check_follow_code_detism_3_0));
	}
Define_label(mercury__follow_code__check_follow_code_detism_3_0_i5);
	update_prof_current_proc(LABEL(mercury__follow_code__check_follow_code_detism_3_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__det_analysis__det_conjunction_maxsoln_3_0);
	call_localret(ENTRY(mercury__det_analysis__det_conjunction_maxsoln_3_0),
		mercury__follow_code__check_follow_code_detism_3_0_i6,
		STATIC(mercury__follow_code__check_follow_code_detism_3_0));
	}
Define_label(mercury__follow_code__check_follow_code_detism_3_0_i6);
	update_prof_current_proc(LABEL(mercury__follow_code__check_follow_code_detism_3_0));
	if (((Integer) detstackvar(2) != (Integer) r1))
		GOTO_LABEL(mercury__follow_code__check_follow_code_detism_3_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__det_analysis__det_conjunction_canfail_3_0);
	call_localret(ENTRY(mercury__det_analysis__det_conjunction_canfail_3_0),
		mercury__follow_code__check_follow_code_detism_3_0_i7,
		STATIC(mercury__follow_code__check_follow_code_detism_3_0));
	}
Define_label(mercury__follow_code__check_follow_code_detism_3_0_i7);
	update_prof_current_proc(LABEL(mercury__follow_code__check_follow_code_detism_3_0));
	if (((Integer) detstackvar(1) != (Integer) r1))
		GOTO_LABEL(mercury__follow_code__check_follow_code_detism_3_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__follow_code__check_follow_code_detism_3_0,
		STATIC(mercury__follow_code__check_follow_code_detism_3_0));
Define_label(mercury__follow_code__check_follow_code_detism_3_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__follow_code__check_follow_code_detism_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__follow_code_module12)
	init_entry(mercury__follow_code__move_prev_code_forbidden_vars_2_0);
	init_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i4);
	init_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i5);
	init_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i1003);
BEGIN_CODE

/* code for predicate 'move_prev_code_forbidden_vars'/2 in mode 0 */
Define_static(mercury__follow_code__move_prev_code_forbidden_vars_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i1003);
	incr_sp_push_msg(2, "move_prev_code_forbidden_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__follow_code__move_prev_code_forbidden_vars_2_0,
		LABEL(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i4),
		STATIC(mercury__follow_code__move_prev_code_forbidden_vars_2_0));
Define_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i4);
	update_prof_current_proc(LABEL(mercury__follow_code__move_prev_code_forbidden_vars_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__follow_code__move_prev_code_forbidden_vars_2_0_i5,
		STATIC(mercury__follow_code__move_prev_code_forbidden_vars_2_0));
	}
Define_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i5);
	update_prof_current_proc(LABEL(mercury__follow_code__move_prev_code_forbidden_vars_2_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__union_3_0);
	tailcall(ENTRY(mercury__set__union_3_0),
		STATIC(mercury__follow_code__move_prev_code_forbidden_vars_2_0));
	}
Define_label(mercury__follow_code__move_prev_code_forbidden_vars_2_0_i1003);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	tailcall(ENTRY(mercury__set__init_1_0),
		STATIC(mercury__follow_code__move_prev_code_forbidden_vars_2_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__follow_code_bunch_0(void)
{
	mercury__follow_code_module0();
	mercury__follow_code_module1();
	mercury__follow_code_module2();
	mercury__follow_code_module3();
	mercury__follow_code_module4();
	mercury__follow_code_module5();
	mercury__follow_code_module6();
	mercury__follow_code_module7();
	mercury__follow_code_module8();
	mercury__follow_code_module9();
	mercury__follow_code_module10();
	mercury__follow_code_module11();
	mercury__follow_code_module12();
}

#endif

void mercury__follow_code__init(void); /* suppress gcc warning */
void mercury__follow_code__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__follow_code_bunch_0();
#endif
}
