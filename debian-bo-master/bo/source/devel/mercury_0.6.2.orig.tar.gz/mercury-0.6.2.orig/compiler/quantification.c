/*
** Automatically generated from `quantification.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__quantification__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___quantification_quant_warning_0__ua10000_2_0);
Define_extern_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
Declare_label(mercury__quantification__implicitly_quantify_clause_body_8_0_i2);
Define_extern_entry(mercury__quantification__implicitly_quantify_goal_8_0);
Declare_label(mercury__quantification__implicitly_quantify_goal_8_0_i2);
Declare_label(mercury__quantification__implicitly_quantify_goal_8_0_i3);
Declare_label(mercury__quantification__implicitly_quantify_goal_8_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_goal_8_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_goal_8_0_i6);
Define_extern_entry(mercury__quantification__goal_vars_2_0);
Declare_label(mercury__quantification__goal_vars_2_0_i2);
Declare_static(mercury__quantification__implicitly_quantify_goal_4_0);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i2);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i3);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i7);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i8);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i9);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i12);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i14);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i15);
Declare_label(mercury__quantification__implicitly_quantify_goal_4_0_i16);
Declare_static(mercury__quantification__implicitly_quantify_goal_2_5_0);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1019);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1018);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1017);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1016);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1015);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1014);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1013);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i7);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i8);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i9);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i10);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i11);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i12);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1007);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i14);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i15);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i16);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i17);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i18);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i19);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i21);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i22);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i23);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i24);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i25);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i26);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i27);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i28);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i29);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i30);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i31);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i33);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i34);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i35);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i36);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i37);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i38);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i39);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i40);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i43);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i42);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i45);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i46);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i47);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i48);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i49);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i50);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i51);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1011);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i53);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i54);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i55);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i57);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i58);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i59);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i60);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i61);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i62);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i63);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i64);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i67);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i66);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i69);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i70);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i71);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i72);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i73);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i74);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i75);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i76);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i77);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i78);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i79);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i80);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i81);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i82);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i83);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i84);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i85);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i86);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i87);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i88);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i89);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i90);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i91);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i92);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i93);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i94);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i95);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i97);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1012);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i100);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i99);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i101);
Declare_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i103);
Declare_static(mercury__quantification__implicitly_quantify_atomic_goal_3_0);
Declare_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i2);
Declare_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i3);
Declare_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i7);
Declare_static(mercury__quantification__implicitly_quantify_unify_rhs_5_0);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i7);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i10);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i11);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i12);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i15);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i14);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i17);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i18);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i19);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i20);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i21);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i22);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i23);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i24);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i25);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i26);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i27);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i28);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i29);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i30);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i31);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i32);
Declare_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i33);
Declare_static(mercury__quantification__implicitly_quantify_conj_4_0);
Declare_label(mercury__quantification__implicitly_quantify_conj_4_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_conj_4_0_i1004);
Declare_static(mercury__quantification__implicitly_quantify_conj_2_5_0);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i7);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i8);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i9);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i10);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i11);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i12);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i13);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i14);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i15);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i16);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i17);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i18);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i19);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i1001);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i21);
Declare_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i22);
Declare_static(mercury__quantification__implicitly_quantify_disj_4_0);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i7);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i8);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i9);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i3);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i10);
Declare_label(mercury__quantification__implicitly_quantify_disj_4_0_i11);
Declare_static(mercury__quantification__implicitly_quantify_cases_4_0);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i4);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i5);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i6);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i7);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i8);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i9);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i3);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i10);
Declare_label(mercury__quantification__implicitly_quantify_cases_4_0_i11);
Declare_static(mercury__quantification__update_seen_vars_3_0);
Declare_label(mercury__quantification__update_seen_vars_3_0_i2);
Declare_static(mercury__quantification__get_vars_2_4_0);
Declare_label(mercury__quantification__get_vars_2_4_0_i4);
Declare_label(mercury__quantification__get_vars_2_4_0_i5);
Declare_label(mercury__quantification__get_vars_2_4_0_i6);
Declare_label(mercury__quantification__get_vars_2_4_0_i7);
Declare_label(mercury__quantification__get_vars_2_4_0_i3);
Declare_label(mercury__quantification__get_vars_2_4_0_i8);
Declare_label(mercury__quantification__get_vars_2_4_0_i9);
Declare_static(mercury__quantification__goal_list_vars_2_5_0);
Declare_label(mercury__quantification__goal_list_vars_2_5_0_i4);
Declare_label(mercury__quantification__goal_list_vars_2_5_0_i1002);
Declare_static(mercury__quantification__case_list_vars_2_5_0);
Declare_label(mercury__quantification__case_list_vars_2_5_0_i4);
Declare_label(mercury__quantification__case_list_vars_2_5_0_i1002);
Declare_static(mercury__quantification__goal_vars_3_0);
Declare_label(mercury__quantification__goal_vars_3_0_i2);
Declare_label(mercury__quantification__goal_vars_3_0_i3);
Declare_static(mercury__quantification__goal_vars_2_5_0);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1007);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1006);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1005);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1004);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1003);
Declare_label(mercury__quantification__goal_vars_2_5_0_i5);
Declare_label(mercury__quantification__goal_vars_2_5_0_i6);
Declare_label(mercury__quantification__goal_vars_2_5_0_i8);
Declare_label(mercury__quantification__goal_vars_2_5_0_i9);
Declare_label(mercury__quantification__goal_vars_2_5_0_i15);
Declare_label(mercury__quantification__goal_vars_2_5_0_i16);
Declare_label(mercury__quantification__goal_vars_2_5_0_i17);
Declare_label(mercury__quantification__goal_vars_2_5_0_i18);
Declare_label(mercury__quantification__goal_vars_2_5_0_i19);
Declare_label(mercury__quantification__goal_vars_2_5_0_i20);
Declare_label(mercury__quantification__goal_vars_2_5_0_i21);
Declare_label(mercury__quantification__goal_vars_2_5_0_i22);
Declare_label(mercury__quantification__goal_vars_2_5_0_i23);
Declare_label(mercury__quantification__goal_vars_2_5_0_i24);
Declare_label(mercury__quantification__goal_vars_2_5_0_i25);
Declare_label(mercury__quantification__goal_vars_2_5_0_i26);
Declare_label(mercury__quantification__goal_vars_2_5_0_i27);
Declare_label(mercury__quantification__goal_vars_2_5_0_i28);
Declare_label(mercury__quantification__goal_vars_2_5_0_i29);
Declare_label(mercury__quantification__goal_vars_2_5_0_i30);
Declare_label(mercury__quantification__goal_vars_2_5_0_i33);
Declare_label(mercury__quantification__goal_vars_2_5_0_i34);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1002);
Declare_label(mercury__quantification__goal_vars_2_5_0_i35);
Declare_label(mercury__quantification__goal_vars_2_5_0_i37);
Declare_label(mercury__quantification__goal_vars_2_5_0_i39);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1000);
Declare_label(mercury__quantification__goal_vars_2_5_0_i1001);
Declare_static(mercury__quantification__unify_rhs_vars_5_0);
Declare_label(mercury__quantification__unify_rhs_vars_5_0_i5);
Declare_label(mercury__quantification__unify_rhs_vars_5_0_i4);
Declare_label(mercury__quantification__unify_rhs_vars_5_0_i6);
Declare_label(mercury__quantification__unify_rhs_vars_5_0_i8);
Declare_label(mercury__quantification__unify_rhs_vars_5_0_i9);
Declare_label(mercury__quantification__unify_rhs_vars_5_0_i10);
Declare_static(mercury__quantification__warn_overlapping_scope_4_0);
Declare_label(mercury__quantification__warn_overlapping_scope_4_0_i2);
Declare_static(mercury__quantification__rename_apart_6_0);
Declare_label(mercury__quantification__rename_apart_6_0_i2);
Declare_label(mercury__quantification__rename_apart_6_0_i3);
Declare_label(mercury__quantification__rename_apart_6_0_i4);
Declare_label(mercury__quantification__rename_apart_6_0_i5);
Declare_static(mercury__quantification__get_outside_3_0);
Declare_static(mercury__quantification__set_outside_3_0);
Declare_static(mercury__quantification__get_quant_vars_3_0);
Declare_static(mercury__quantification__set_quant_vars_3_0);
Declare_static(mercury__quantification__get_lambda_outside_3_0);
Declare_static(mercury__quantification__set_lambda_outside_3_0);
Declare_static(mercury__quantification__get_nonlocals_3_0);
Declare_static(mercury__quantification__set_nonlocals_3_0);
Define_extern_entry(mercury____Unify___quantification__quant_warning_0_0);
Declare_label(mercury____Unify___quantification__quant_warning_0_0_i2);
Declare_label(mercury____Unify___quantification__quant_warning_0_0_i1);
Define_extern_entry(mercury____Index___quantification__quant_warning_0_0);
Define_extern_entry(mercury____Compare___quantification__quant_warning_0_0);
Declare_label(mercury____Compare___quantification__quant_warning_0_0_i4);
Declare_label(mercury____Compare___quantification__quant_warning_0_0_i3);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_quantification__base_type_layout_quant_info_0[];
Word * mercury_data_quantification__base_type_info_quant_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_quantification__base_type_layout_quant_info_0
};

extern Word * mercury_data_quantification__base_type_layout_quant_warning_0[];
Word * mercury_data_quantification__base_type_info_quant_warning_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___quantification__quant_warning_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___quantification__quant_warning_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___quantification__quant_warning_0_0),
	(Word *) (Integer) mercury_data_quantification__base_type_layout_quant_warning_0
};

extern Word * mercury_data_quantification__common_2[];
Word * mercury_data_quantification__base_type_layout_quant_warning_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_quantification__common_2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_quantification__common_7[];
Word * mercury_data_quantification__base_type_layout_quant_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_quantification__common_7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_quantification__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_quantification__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

Word * mercury_data_quantification__common_2[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_1),
	(Word *) string_const("warn_overlap", 12)
};

extern Word * mercury_data_set__base_type_info_set_1[];
Word * mercury_data_quantification__common_3[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_quantification__common_4[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_quantification__common_5[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_quantification__common_6[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_quantification__base_type_info_quant_warning_0
};

Word * mercury_data_quantification__common_7[] = {
	(Word *) ((Integer) 8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_quantification__common_6),
	(Word *) string_const("quant_info", 10)
};

BEGIN_MODULE(mercury__quantification_module0)
	init_entry(mercury____Index___quantification_quant_warning_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___quantification_quant_warning_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___quantification_quant_warning_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module1)
	init_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	init_label(mercury__quantification__implicitly_quantify_clause_body_8_0_i2);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_clause_body'/8 in mode 0 */
Define_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	incr_sp_push_msg(4, "implicitly_quantify_clause_body");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__quantification__implicitly_quantify_clause_body_8_0_i2,
		ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0));
	}
Define_label(mercury__quantification__implicitly_quantify_clause_body_8_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_clause_body_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
		tailcall(STATIC(mercury__quantification__implicitly_quantify_goal_8_0),
		ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0));
	}
END_MODULE

BEGIN_MODULE(mercury__quantification_module2)
	init_entry(mercury__quantification__implicitly_quantify_goal_8_0);
	init_label(mercury__quantification__implicitly_quantify_goal_8_0_i2);
	init_label(mercury__quantification__implicitly_quantify_goal_8_0_i3);
	init_label(mercury__quantification__implicitly_quantify_goal_8_0_i4);
	init_label(mercury__quantification__implicitly_quantify_goal_8_0_i5);
	init_label(mercury__quantification__implicitly_quantify_goal_8_0_i6);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_goal'/8 in mode 0 */
Define_entry(mercury__quantification__implicitly_quantify_goal_8_0);
	incr_sp_push_msg(7, "implicitly_quantify_goal");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_goal_8_0_i2,
		ENTRY(mercury__quantification__implicitly_quantify_goal_8_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_8_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_8_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_goal_8_0_i3,
		ENTRY(mercury__quantification__implicitly_quantify_goal_8_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_8_0_i3);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_8_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_goal_8_0_i4,
		ENTRY(mercury__quantification__implicitly_quantify_goal_8_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_8_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_8_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_goal_8_0_i5,
		ENTRY(mercury__quantification__implicitly_quantify_goal_8_0));
Define_label(mercury__quantification__implicitly_quantify_goal_8_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_8_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r1 = (Integer) mercury_data_quantification__base_type_info_quant_warning_0;
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__quantification__implicitly_quantify_goal_8_0_i6,
		ENTRY(mercury__quantification__implicitly_quantify_goal_8_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_8_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module3)
	init_entry(mercury__quantification__goal_vars_2_0);
	init_label(mercury__quantification__goal_vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'goal_vars'/2 in mode 0 */
Define_entry(mercury__quantification__goal_vars_2_0);
	incr_sp_push_msg(1, "goal_vars");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__goal_vars_2_0_i2,
		ENTRY(mercury__quantification__goal_vars_2_0));
Define_label(mercury__quantification__goal_vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__set__union_3_0);
	tailcall(ENTRY(mercury__set__union_3_0),
		ENTRY(mercury__quantification__goal_vars_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__quantification_module4)
	init_entry(mercury__quantification__implicitly_quantify_goal_4_0);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i2);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i3);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i4);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i7);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i8);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i9);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i12);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i14);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i6);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i15);
	init_label(mercury__quantification__implicitly_quantify_goal_4_0_i16);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_goal'/4 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_goal_4_0);
	incr_sp_push_msg(8, "implicitly_quantify_goal");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i2,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i3,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i3);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i4,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__quantification__goal_vars_2_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i7,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i8,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__empty_1_0);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i12,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i12);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_4_0_i6);
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__quantification__rename_apart_6_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i14,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i14);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_4_0_i15);
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i6);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	r1 = (Integer) detstackvar(4);
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i15);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_nonlocals_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_4_0_i16,
		STATIC(mercury__quantification__implicitly_quantify_goal_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_4_0_i16);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module5)
	init_entry(mercury__quantification__implicitly_quantify_goal_2_5_0);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1019);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1018);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1017);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1016);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1015);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1014);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1013);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i5);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i6);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i7);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i8);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i9);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i10);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i11);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i12);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1007);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i14);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i15);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i16);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i17);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i18);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i19);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i21);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i22);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i23);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i24);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i25);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i26);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i27);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i28);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i29);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i30);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i31);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i33);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i34);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i35);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i36);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i37);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i38);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i39);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i40);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i43);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i42);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i45);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i46);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i47);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i48);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i49);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i50);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i51);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1011);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i53);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i54);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i55);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i57);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i58);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i59);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i60);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i61);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i62);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i63);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i64);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i67);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i66);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i69);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i70);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i71);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i72);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i73);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i74);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i75);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i76);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i77);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i78);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i79);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i80);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i81);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i82);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i83);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i84);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i85);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i86);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i87);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i88);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i89);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i90);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i91);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i92);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i93);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i94);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i95);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i97);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1012);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i100);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i99);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i101);
	init_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i103);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_goal_2'/5 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1012);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1019) AND
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1018) AND
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1017) AND
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1016) AND
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1015) AND
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1014) AND
		LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i1013));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1019);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i5);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1018);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i10);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1017);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i21);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1016);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i23);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1015);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i33);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1014);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i57);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1013);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i97);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_cases_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i6,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	tag_incr_hp(r3, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i7,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i8,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i10);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i11,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_lambda_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i12,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i1007,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1007);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	tag_incr_hp(r3, mktag(3), ((Integer) 6));
	detstackvar(2) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 5)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i14,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i15,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__quantification__update_seen_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i16,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i17,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i18,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i19,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i21);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_disj_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i22,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i23);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i24,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i25,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i25);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i26,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i27,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i28,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i29,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i29);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i30,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i30);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	detstackvar(2) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i31,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i33);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i34,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i34);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_lambda_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i35,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i35);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i36,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i36);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i37,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i37);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i38,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i38);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i39,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i39);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i40,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i40);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__empty_1_0);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i43,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i43);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i42);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r1 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i48);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i42);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__quantification__warn_overlapping_scope_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i45,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i45);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__quantification__rename_apart_6_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i46,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i46);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__goal_util__rename_var_list_4_0);
	call_localret(ENTRY(mercury__goal_util__rename_var_list_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i47,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i47);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	r4 = (Integer) detstackvar(6);
	r1 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i48);
	detstackvar(5) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	call_localret(STATIC(mercury__quantification__update_seen_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i49,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i49);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i50,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i50);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i51,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i51);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i1011,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1011);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	detstackvar(2) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 4);
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i53,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i53);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i54,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i54);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i55,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i55);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i57);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i58,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i58);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i59,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i59);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_lambda_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i60,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i60);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(12) = (Integer) r1;
	detstackvar(17) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i61,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i61);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i62,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i62);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i63,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i63);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i64,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i64);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__empty_1_0);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i67,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i67);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i66);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(5);
	r11 = (Integer) detstackvar(17);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i73);
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i66);
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(17);
	call_localret(STATIC(mercury__quantification__warn_overlapping_scope_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i69,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i69);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__quantification__rename_apart_6_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i70,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i70);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	detstackvar(18) = (Integer) r3;
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i71,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i71);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__goal_util__rename_var_list_4_0);
	call_localret(ENTRY(mercury__goal_util__rename_var_list_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i72,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i72);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r3 = (Integer) r1;
	r2 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(18);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i73);
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(2) = (Integer) r3;
	detstackvar(10) = (Integer) r2;
	detstackvar(11) = (Integer) r6;
	detstackvar(12) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(18) = (Integer) r11;
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i74,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i74);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i75,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i75);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(16) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i76,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i76);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(16);
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i77,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i77);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(15);
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(18);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i78,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i78);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(16);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i79,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i79);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(15);
	call_localret(STATIC(mercury__quantification__set_lambda_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i80,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i80);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__quantification__update_seen_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i81,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i81);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i82,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i82);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i83,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i83);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	detstackvar(15) = (Integer) r1;
	detstackvar(16) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i84,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i84);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(16);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i85,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i85);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__quantification__set_lambda_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i86,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i86);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i87,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i87);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i88,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i88);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i89,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i89);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i90,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i90);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i91,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i91);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	detstackvar(2) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i92,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i92);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	detstackvar(8) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(15);
	r3 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i93,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i93);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i94,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i94);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i95,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i95);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i97);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i1012);
	incr_sp_push_msg(19, "implicitly_quantify_goal_2");
	detstackvar(19) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i99);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_conj_4_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i100,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i100);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i99);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0_i101);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i101);
	detstackvar(2) = (Integer) r1;
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0),
		mercury__quantification__implicitly_quantify_goal_2_5_0_i103,
		STATIC(mercury__quantification__implicitly_quantify_goal_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_goal_2_5_0_i103);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_goal_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module6)
	init_entry(mercury__quantification__implicitly_quantify_atomic_goal_3_0);
	init_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i2);
	init_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i3);
	init_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i4);
	init_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i5);
	init_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i6);
	init_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i7);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_atomic_goal'/3 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_atomic_goal_3_0);
	incr_sp_push_msg(4, "implicitly_quantify_atomic_goal");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__quantification__implicitly_quantify_atomic_goal_3_0_i2,
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	}
Define_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	call_localret(STATIC(mercury__quantification__update_seen_vars_3_0),
		mercury__quantification__implicitly_quantify_atomic_goal_3_0_i3,
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
Define_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i3);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_atomic_goal_3_0_i4,
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
Define_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(3) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_atomic_goal_3_0_i5,
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	}
Define_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_atomic_goal_3_0_i6,
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	}
Define_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_atomic_goal_3_0_i7,
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	}
Define_label(mercury__quantification__implicitly_quantify_atomic_goal_3_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__quantification__set_nonlocals_3_0),
		STATIC(mercury__quantification__implicitly_quantify_atomic_goal_3_0));
END_MODULE

BEGIN_MODULE(mercury__quantification_module7)
	init_entry(mercury__quantification__implicitly_quantify_unify_rhs_5_0);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i5);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i6);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i4);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i7);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i10);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i11);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i12);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i15);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i14);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i17);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i18);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i19);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i20);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i21);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i22);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i23);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i24);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i25);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i26);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i27);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i28);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i29);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i30);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i31);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i32);
	init_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i33);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_unify_rhs'/5 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_unify_rhs_5_0);
	incr_sp_push_msg(16, "implicitly_quantify_unify_rhs");
	detstackvar(16) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i4);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__set__singleton_set_2_1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i5,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i6,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i4);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i7);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i5,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i7);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i10,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i10);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(14) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i11,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r3 = (Integer) r1;
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i12,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i12);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__empty_1_0);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i15,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i15);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i14);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(14), ((Integer) 4));
	r11 = (Integer) detstackvar(14);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	GOTO_LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i18);
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i14);
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(14);
	call_localret(STATIC(mercury__quantification__warn_overlapping_scope_4_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i17,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i17);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(11);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r11 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i18);
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(11) = (Integer) r10;
	detstackvar(2) = (Integer) r11;
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i19,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i19);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i20,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i20);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__rename_apart_6_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i21,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i21);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	detstackvar(15) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__goal_util__rename_var_list_4_0);
	call_localret(ENTRY(mercury__goal_util__rename_var_list_4_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i22,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i22);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	detstackvar(8) = (Integer) r1;
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(15), ((Integer) 1));
	detstackvar(12) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i23,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i23);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i24,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i24);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i25,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i25);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) detstackvar(13);
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(15);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i26,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i26);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i27,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i27);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i28,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i28);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	tag_incr_hp(r3, mktag(2), ((Integer) 5));
	detstackvar(2) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 4)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(2), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(2), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i29,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i29);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r3 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i30,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i30);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__quantification__set_quant_vars_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i31,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i31);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i32,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i32);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_unify_rhs_5_0_i33,
		STATIC(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
Define_label(mercury__quantification__implicitly_quantify_unify_rhs_5_0_i33);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_unify_rhs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module8)
	init_entry(mercury__quantification__implicitly_quantify_conj_4_0);
	init_label(mercury__quantification__implicitly_quantify_conj_4_0_i4);
	init_label(mercury__quantification__implicitly_quantify_conj_4_0_i1004);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_conj'/4 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_conj_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_conj_4_0_i1004);
	incr_sp_push_msg(3, "implicitly_quantify_conj");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__quantification__get_vars_2_4_0),
		mercury__quantification__implicitly_quantify_conj_4_0_i4,
		STATIC(mercury__quantification__implicitly_quantify_conj_4_0));
Define_label(mercury__quantification__implicitly_quantify_conj_4_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r5 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	r6 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0),
		STATIC(mercury__quantification__implicitly_quantify_conj_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_4_0_i1004);
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0),
		STATIC(mercury__quantification__implicitly_quantify_conj_4_0));
END_MODULE

BEGIN_MODULE(mercury__quantification_module9)
	init_entry(mercury__quantification__implicitly_quantify_conj_2_5_0);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i6);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i7);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i8);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i9);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i10);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i11);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i12);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i13);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i14);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i15);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i16);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i17);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i18);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i19);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i5);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i1001);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i21);
	init_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i22);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_conj_2'/5 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_conj_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0_i1001);
	incr_sp_push_msg(9, "implicitly_quantify_conj_2");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0_i5);
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_outside_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i6,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i7,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i8,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i10,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i11,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i12,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i13,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 4));
	field(mktag(0), (Integer) r3, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 6));
	field(mktag(0), (Integer) r3, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 7));
	localcall(mercury__quantification__implicitly_quantify_conj_2_5_0,
		LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0_i14),
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i15,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i16,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i17,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__quantification__set_outside_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i18,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i19,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i5);
	r1 = string_const("implicitly_quantify_conj_2: length mismatch", 43);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i19,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i1001);
	incr_sp_push_msg(9, "implicitly_quantify_conj_2");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i21,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
	}
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i21);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_conj_2_5_0_i22,
		STATIC(mercury__quantification__implicitly_quantify_conj_2_5_0));
Define_label(mercury__quantification__implicitly_quantify_conj_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_conj_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module10)
	init_entry(mercury__quantification__implicitly_quantify_disj_4_0);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i4);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i5);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i6);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i7);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i8);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i9);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i3);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i10);
	init_label(mercury__quantification__implicitly_quantify_disj_4_0_i11);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_disj'/4 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_disj_4_0);
	incr_sp_push_msg(4, "implicitly_quantify_disj");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_disj_4_0_i3);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i4,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i5,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	localcall(mercury__quantification__implicitly_quantify_disj_4_0,
		LABEL(mercury__quantification__implicitly_quantify_disj_4_0_i6),
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i7,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	detstackvar(2) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i8,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i3);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i10,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i10);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_disj_4_0_i11,
		STATIC(mercury__quantification__implicitly_quantify_disj_4_0));
Define_label(mercury__quantification__implicitly_quantify_disj_4_0_i11);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_disj_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module11)
	init_entry(mercury__quantification__implicitly_quantify_cases_4_0);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i4);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i5);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i6);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i7);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i8);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i9);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i3);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i10);
	init_label(mercury__quantification__implicitly_quantify_cases_4_0_i11);
BEGIN_CODE

/* code for predicate 'implicitly_quantify_cases'/4 in mode 0 */
Define_static(mercury__quantification__implicitly_quantify_cases_4_0);
	incr_sp_push_msg(3, "implicitly_quantify_cases");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__implicitly_quantify_cases_4_0_i3);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__quantification__implicitly_quantify_goal_4_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i4,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i5,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__quantification__implicitly_quantify_cases_4_0,
		LABEL(mercury__quantification__implicitly_quantify_cases_4_0_i6),
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__quantification__get_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i7,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i8,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
	}
	}
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i9,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i3);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i10,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
	}
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i10);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__set_nonlocals_3_0),
		mercury__quantification__implicitly_quantify_cases_4_0_i11,
		STATIC(mercury__quantification__implicitly_quantify_cases_4_0));
Define_label(mercury__quantification__implicitly_quantify_cases_4_0_i11);
	update_prof_current_proc(LABEL(mercury__quantification__implicitly_quantify_cases_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module12)
	init_entry(mercury__quantification__update_seen_vars_3_0);
	init_label(mercury__quantification__update_seen_vars_3_0_i2);
BEGIN_CODE

/* code for predicate 'quantification__update_seen_vars'/3 in mode 0 */
Define_static(mercury__quantification__update_seen_vars_3_0);
	incr_sp_push_msg(2, "quantification__update_seen_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__update_seen_vars_3_0_i2,
		STATIC(mercury__quantification__update_seen_vars_3_0));
	}
Define_label(mercury__quantification__update_seen_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__update_seen_vars_3_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) r1;
	r1 = (Integer) r2;
	r3 = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module13)
	init_entry(mercury__quantification__get_vars_2_4_0);
	init_label(mercury__quantification__get_vars_2_4_0_i4);
	init_label(mercury__quantification__get_vars_2_4_0_i5);
	init_label(mercury__quantification__get_vars_2_4_0_i6);
	init_label(mercury__quantification__get_vars_2_4_0_i7);
	init_label(mercury__quantification__get_vars_2_4_0_i3);
	init_label(mercury__quantification__get_vars_2_4_0_i8);
	init_label(mercury__quantification__get_vars_2_4_0_i9);
BEGIN_CODE

/* code for predicate 'get_vars_2'/4 in mode 0 */
Define_static(mercury__quantification__get_vars_2_4_0);
	incr_sp_push_msg(5, "get_vars_2");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__get_vars_2_4_0_i3);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__quantification__get_vars_2_4_0,
		LABEL(mercury__quantification__get_vars_2_4_0_i4),
		STATIC(mercury__quantification__get_vars_2_4_0));
Define_label(mercury__quantification__get_vars_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__get_vars_2_4_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__get_vars_2_4_0_i5,
		STATIC(mercury__quantification__get_vars_2_4_0));
Define_label(mercury__quantification__get_vars_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__get_vars_2_4_0));
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__get_vars_2_4_0_i6,
		STATIC(mercury__quantification__get_vars_2_4_0));
	}
Define_label(mercury__quantification__get_vars_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__get_vars_2_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__get_vars_2_4_0_i7,
		STATIC(mercury__quantification__get_vars_2_4_0));
	}
Define_label(mercury__quantification__get_vars_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__quantification__get_vars_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__quantification__get_vars_2_4_0_i3);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__get_vars_2_4_0_i8,
		STATIC(mercury__quantification__get_vars_2_4_0));
	}
Define_label(mercury__quantification__get_vars_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__get_vars_2_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__get_vars_2_4_0_i9,
		STATIC(mercury__quantification__get_vars_2_4_0));
	}
Define_label(mercury__quantification__get_vars_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__get_vars_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module14)
	init_entry(mercury__quantification__goal_list_vars_2_5_0);
	init_label(mercury__quantification__goal_list_vars_2_5_0_i4);
	init_label(mercury__quantification__goal_list_vars_2_5_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_list_vars_2'/5 in mode 0 */
Define_static(mercury__quantification__goal_list_vars_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__goal_list_vars_2_5_0_i1002);
	incr_sp_push_msg(2, "goal_list_vars_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	call_localret(STATIC(mercury__quantification__goal_vars_2_5_0),
		mercury__quantification__goal_list_vars_2_5_0_i4,
		STATIC(mercury__quantification__goal_list_vars_2_5_0));
Define_label(mercury__quantification__goal_list_vars_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__goal_list_vars_2_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__quantification__goal_list_vars_2_5_0,
		STATIC(mercury__quantification__goal_list_vars_2_5_0));
Define_label(mercury__quantification__goal_list_vars_2_5_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module15)
	init_entry(mercury__quantification__case_list_vars_2_5_0);
	init_label(mercury__quantification__case_list_vars_2_5_0_i4);
	init_label(mercury__quantification__case_list_vars_2_5_0_i1002);
BEGIN_CODE

/* code for predicate 'case_list_vars_2'/5 in mode 0 */
Define_static(mercury__quantification__case_list_vars_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__quantification__case_list_vars_2_5_0_i1002);
	incr_sp_push_msg(2, "case_list_vars_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	call_localret(STATIC(mercury__quantification__goal_vars_2_5_0),
		mercury__quantification__case_list_vars_2_5_0_i4,
		STATIC(mercury__quantification__case_list_vars_2_5_0));
Define_label(mercury__quantification__case_list_vars_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__case_list_vars_2_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__quantification__case_list_vars_2_5_0,
		STATIC(mercury__quantification__case_list_vars_2_5_0));
Define_label(mercury__quantification__case_list_vars_2_5_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module16)
	init_entry(mercury__quantification__goal_vars_3_0);
	init_label(mercury__quantification__goal_vars_3_0_i2);
	init_label(mercury__quantification__goal_vars_3_0_i3);
BEGIN_CODE

/* code for predicate 'goal_vars'/3 in mode 0 */
Define_static(mercury__quantification__goal_vars_3_0);
	incr_sp_push_msg(3, "goal_vars");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__goal_vars_3_0_i2,
		STATIC(mercury__quantification__goal_vars_3_0));
	}
Define_label(mercury__quantification__goal_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__quantification__goal_vars_3_0_i3,
		STATIC(mercury__quantification__goal_vars_3_0));
	}
Define_label(mercury__quantification__goal_vars_3_0_i3);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__quantification__goal_vars_2_5_0),
		STATIC(mercury__quantification__goal_vars_3_0));
END_MODULE

BEGIN_MODULE(mercury__quantification_module17)
	init_entry(mercury__quantification__goal_vars_2_5_0);
	init_label(mercury__quantification__goal_vars_2_5_0_i1007);
	init_label(mercury__quantification__goal_vars_2_5_0_i1006);
	init_label(mercury__quantification__goal_vars_2_5_0_i1005);
	init_label(mercury__quantification__goal_vars_2_5_0_i1004);
	init_label(mercury__quantification__goal_vars_2_5_0_i1003);
	init_label(mercury__quantification__goal_vars_2_5_0_i5);
	init_label(mercury__quantification__goal_vars_2_5_0_i6);
	init_label(mercury__quantification__goal_vars_2_5_0_i8);
	init_label(mercury__quantification__goal_vars_2_5_0_i9);
	init_label(mercury__quantification__goal_vars_2_5_0_i15);
	init_label(mercury__quantification__goal_vars_2_5_0_i16);
	init_label(mercury__quantification__goal_vars_2_5_0_i17);
	init_label(mercury__quantification__goal_vars_2_5_0_i18);
	init_label(mercury__quantification__goal_vars_2_5_0_i19);
	init_label(mercury__quantification__goal_vars_2_5_0_i20);
	init_label(mercury__quantification__goal_vars_2_5_0_i21);
	init_label(mercury__quantification__goal_vars_2_5_0_i22);
	init_label(mercury__quantification__goal_vars_2_5_0_i23);
	init_label(mercury__quantification__goal_vars_2_5_0_i24);
	init_label(mercury__quantification__goal_vars_2_5_0_i25);
	init_label(mercury__quantification__goal_vars_2_5_0_i26);
	init_label(mercury__quantification__goal_vars_2_5_0_i27);
	init_label(mercury__quantification__goal_vars_2_5_0_i28);
	init_label(mercury__quantification__goal_vars_2_5_0_i29);
	init_label(mercury__quantification__goal_vars_2_5_0_i30);
	init_label(mercury__quantification__goal_vars_2_5_0_i33);
	init_label(mercury__quantification__goal_vars_2_5_0_i34);
	init_label(mercury__quantification__goal_vars_2_5_0_i1002);
	init_label(mercury__quantification__goal_vars_2_5_0_i35);
	init_label(mercury__quantification__goal_vars_2_5_0_i37);
	init_label(mercury__quantification__goal_vars_2_5_0_i39);
	init_label(mercury__quantification__goal_vars_2_5_0_i1000);
	init_label(mercury__quantification__goal_vars_2_5_0_i1001);
BEGIN_CODE

/* code for predicate 'goal_vars_2'/5 in mode 0 */
Define_static(mercury__quantification__goal_vars_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i1002);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__quantification__goal_vars_2_5_0_i1007) AND
		LABEL(mercury__quantification__goal_vars_2_5_0_i1006) AND
		LABEL(mercury__quantification__goal_vars_2_5_0_i1000) AND
		LABEL(mercury__quantification__goal_vars_2_5_0_i1001) AND
		LABEL(mercury__quantification__goal_vars_2_5_0_i1005) AND
		LABEL(mercury__quantification__goal_vars_2_5_0_i1004) AND
		LABEL(mercury__quantification__goal_vars_2_5_0_i1003));
Define_label(mercury__quantification__goal_vars_2_5_0_i1007);
	incr_sp_push_msg(7, "goal_vars_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i5);
Define_label(mercury__quantification__goal_vars_2_5_0_i1006);
	incr_sp_push_msg(7, "goal_vars_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i8);
Define_label(mercury__quantification__goal_vars_2_5_0_i1005);
	incr_sp_push_msg(7, "goal_vars_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i15);
Define_label(mercury__quantification__goal_vars_2_5_0_i1004);
	incr_sp_push_msg(7, "goal_vars_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i21);
Define_label(mercury__quantification__goal_vars_2_5_0_i1003);
	incr_sp_push_msg(7, "goal_vars_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i33);
Define_label(mercury__quantification__goal_vars_2_5_0_i5);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__quantification__goal_vars_2_5_0_i6,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__quantification__case_list_vars_2_5_0),
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i8);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__quantification__goal_vars_2_5_0_i9,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__quantification__unify_rhs_vars_5_0),
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i15);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__goal_vars_2_5_0_i16,
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i17,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i18,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i19,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i20,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i20);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__quantification__goal_vars_2_5_0_i21);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__goal_vars_2_5_0_i22,
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__goal_vars_2_5_0_i23,
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i24,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i25,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i25);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i26,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i27,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i28,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i29,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i29);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__quantification__goal_vars_3_0),
		mercury__quantification__goal_vars_2_5_0_i30,
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i30);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__goal_vars_2_5_0_i19,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i33);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i34,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i34);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__quantification__goal_vars_2_5_0_i1002);
	incr_sp_push_msg(7, "goal_vars_2");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i35);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__quantification__goal_list_vars_2_5_0),
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i35);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__quantification__goal_vars_2_5_0_i37);
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i34,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i37);
	detstackvar(1) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__goal_vars_2_5_0_i39,
		STATIC(mercury__quantification__goal_vars_2_5_0));
	}
Define_label(mercury__quantification__goal_vars_2_5_0_i39);
	update_prof_current_proc(LABEL(mercury__quantification__goal_vars_2_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__quantification__goal_vars_2_5_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__quantification__goal_list_vars_2_5_0),
		STATIC(mercury__quantification__goal_vars_2_5_0));
Define_label(mercury__quantification__goal_vars_2_5_0_i1001);
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), ((Integer) 0));
	localtailcall(mercury__quantification__goal_vars_2_5_0,
		STATIC(mercury__quantification__goal_vars_2_5_0));
END_MODULE

BEGIN_MODULE(mercury__quantification_module18)
	init_entry(mercury__quantification__unify_rhs_vars_5_0);
	init_label(mercury__quantification__unify_rhs_vars_5_0_i5);
	init_label(mercury__quantification__unify_rhs_vars_5_0_i4);
	init_label(mercury__quantification__unify_rhs_vars_5_0_i6);
	init_label(mercury__quantification__unify_rhs_vars_5_0_i8);
	init_label(mercury__quantification__unify_rhs_vars_5_0_i9);
	init_label(mercury__quantification__unify_rhs_vars_5_0_i10);
BEGIN_CODE

/* code for predicate 'quantification__unify_rhs_vars'/5 in mode 0 */
Define_static(mercury__quantification__unify_rhs_vars_5_0);
	incr_sp_push_msg(4, "quantification__unify_rhs_vars");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__quantification__unify_rhs_vars_5_0_i4);
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__quantification__unify_rhs_vars_5_0_i5,
		STATIC(mercury__quantification__unify_rhs_vars_5_0));
	}
Define_label(mercury__quantification__unify_rhs_vars_5_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__unify_rhs_vars_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__quantification__unify_rhs_vars_5_0_i4);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__quantification__unify_rhs_vars_5_0_i6);
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__quantification__unify_rhs_vars_5_0_i5,
		STATIC(mercury__quantification__unify_rhs_vars_5_0));
	}
Define_label(mercury__quantification__unify_rhs_vars_5_0_i6);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	{
		call_localret(STATIC(mercury__quantification__goal_vars_2_0),
		mercury__quantification__unify_rhs_vars_5_0_i8,
		STATIC(mercury__quantification__unify_rhs_vars_5_0));
	}
Define_label(mercury__quantification__unify_rhs_vars_5_0_i8);
	update_prof_current_proc(LABEL(mercury__quantification__unify_rhs_vars_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__quantification__unify_rhs_vars_5_0_i9,
		STATIC(mercury__quantification__unify_rhs_vars_5_0));
	}
Define_label(mercury__quantification__unify_rhs_vars_5_0_i9);
	update_prof_current_proc(LABEL(mercury__quantification__unify_rhs_vars_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__quantification__unify_rhs_vars_5_0_i10,
		STATIC(mercury__quantification__unify_rhs_vars_5_0));
	}
Define_label(mercury__quantification__unify_rhs_vars_5_0_i10);
	update_prof_current_proc(LABEL(mercury__quantification__unify_rhs_vars_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module19)
	init_entry(mercury__quantification__warn_overlapping_scope_4_0);
	init_label(mercury__quantification__warn_overlapping_scope_4_0_i2);
BEGIN_CODE

/* code for predicate 'quantification__warn_overlapping_scope'/4 in mode 0 */
Define_static(mercury__quantification__warn_overlapping_scope_4_0);
	incr_sp_push_msg(3, "quantification__warn_overlapping_scope");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__quantification__warn_overlapping_scope_4_0_i2,
		STATIC(mercury__quantification__warn_overlapping_scope_4_0));
	}
Define_label(mercury__quantification__warn_overlapping_scope_4_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__warn_overlapping_scope_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 8));
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__quantification_module20)
	init_entry(mercury__quantification__rename_apart_6_0);
	init_label(mercury__quantification__rename_apart_6_0_i2);
	init_label(mercury__quantification__rename_apart_6_0_i3);
	init_label(mercury__quantification__rename_apart_6_0_i4);
	init_label(mercury__quantification__rename_apart_6_0_i5);
BEGIN_CODE

/* code for predicate 'quantification__rename_apart'/6 in mode 0 */
Define_static(mercury__quantification__rename_apart_6_0);
	incr_sp_push_msg(6, "quantification__rename_apart");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__quantification__rename_apart_6_0_i2,
		STATIC(mercury__quantification__rename_apart_6_0));
	}
Define_label(mercury__quantification__rename_apart_6_0_i2);
	update_prof_current_proc(LABEL(mercury__quantification__rename_apart_6_0));
	detstackvar(3) = (Integer) r1;
	r3 = (Integer) detstackvar(2);
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__quantification__rename_apart_6_0_i3,
		STATIC(mercury__quantification__rename_apart_6_0));
	}
Define_label(mercury__quantification__rename_apart_6_0_i3);
	update_prof_current_proc(LABEL(mercury__quantification__rename_apart_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) r3;
	r6 = (Integer) r2;
	{
	Declare_entry(mercury__goal_util__create_variables_9_0);
	call_localret(ENTRY(mercury__goal_util__create_variables_9_0),
		mercury__quantification__rename_apart_6_0_i4,
		STATIC(mercury__quantification__rename_apart_6_0));
	}
Define_label(mercury__quantification__rename_apart_6_0_i4);
	update_prof_current_proc(LABEL(mercury__quantification__rename_apart_6_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) r3;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__quantification__rename_apart_6_0_i5,
		STATIC(mercury__quantification__rename_apart_6_0));
	}
Define_label(mercury__quantification__rename_apart_6_0_i5);
	update_prof_current_proc(LABEL(mercury__quantification__rename_apart_6_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 8));
	r2 = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 7));
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 6)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 5)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__quantification_module21)
	init_entry(mercury__quantification__get_outside_3_0);
BEGIN_CODE

/* code for predicate 'quantification__get_outside'/3 in mode 0 */
Define_static(mercury__quantification__get_outside_3_0);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module22)
	init_entry(mercury__quantification__set_outside_3_0);
BEGIN_CODE

/* code for predicate 'quantification__set_outside'/3 in mode 0 */
Define_static(mercury__quantification__set_outside_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module23)
	init_entry(mercury__quantification__get_quant_vars_3_0);
BEGIN_CODE

/* code for predicate 'quantification__get_quant_vars'/3 in mode 0 */
Define_static(mercury__quantification__get_quant_vars_3_0);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module24)
	init_entry(mercury__quantification__set_quant_vars_3_0);
BEGIN_CODE

/* code for predicate 'quantification__set_quant_vars'/3 in mode 0 */
Define_static(mercury__quantification__set_quant_vars_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module25)
	init_entry(mercury__quantification__get_lambda_outside_3_0);
BEGIN_CODE

/* code for predicate 'quantification__get_lambda_outside'/3 in mode 0 */
Define_static(mercury__quantification__get_lambda_outside_3_0);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module26)
	init_entry(mercury__quantification__set_lambda_outside_3_0);
BEGIN_CODE

/* code for predicate 'quantification__set_lambda_outside'/3 in mode 0 */
Define_static(mercury__quantification__set_lambda_outside_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module27)
	init_entry(mercury__quantification__get_nonlocals_3_0);
BEGIN_CODE

/* code for predicate 'quantification__get_nonlocals'/3 in mode 0 */
Define_static(mercury__quantification__get_nonlocals_3_0);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module28)
	init_entry(mercury__quantification__set_nonlocals_3_0);
BEGIN_CODE

/* code for predicate 'quantification__set_nonlocals'/3 in mode 0 */
Define_static(mercury__quantification__set_nonlocals_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module29)
	init_entry(mercury____Unify___quantification__quant_warning_0_0);
	init_label(mercury____Unify___quantification__quant_warning_0_0_i2);
	init_label(mercury____Unify___quantification__quant_warning_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___quantification__quant_warning_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___quantification__quant_warning_0_0_i2,
		ENTRY(mercury____Unify___quantification__quant_warning_0_0));
	}
Define_label(mercury____Unify___quantification__quant_warning_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___quantification__quant_warning_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___quantification__quant_warning_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Unify___quantification__quant_warning_0_0));
	}
Define_label(mercury____Unify___quantification__quant_warning_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__quantification_module30)
	init_entry(mercury____Index___quantification__quant_warning_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___quantification__quant_warning_0_0);
	tailcall(STATIC(mercury____Index___quantification_quant_warning_0__ua10000_2_0),
		ENTRY(mercury____Index___quantification__quant_warning_0_0));
END_MODULE

BEGIN_MODULE(mercury__quantification_module31)
	init_entry(mercury____Compare___quantification__quant_warning_0_0);
	init_label(mercury____Compare___quantification__quant_warning_0_0_i4);
	init_label(mercury____Compare___quantification__quant_warning_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___quantification__quant_warning_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___quantification__quant_warning_0_0_i4,
		ENTRY(mercury____Compare___quantification__quant_warning_0_0));
	}
Define_label(mercury____Compare___quantification__quant_warning_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___quantification__quant_warning_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___quantification__quant_warning_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___quantification__quant_warning_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Compare___quantification__quant_warning_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__quantification_bunch_0(void)
{
	mercury__quantification_module0();
	mercury__quantification_module1();
	mercury__quantification_module2();
	mercury__quantification_module3();
	mercury__quantification_module4();
	mercury__quantification_module5();
	mercury__quantification_module6();
	mercury__quantification_module7();
	mercury__quantification_module8();
	mercury__quantification_module9();
	mercury__quantification_module10();
	mercury__quantification_module11();
	mercury__quantification_module12();
	mercury__quantification_module13();
	mercury__quantification_module14();
	mercury__quantification_module15();
	mercury__quantification_module16();
	mercury__quantification_module17();
	mercury__quantification_module18();
	mercury__quantification_module19();
	mercury__quantification_module20();
	mercury__quantification_module21();
	mercury__quantification_module22();
	mercury__quantification_module23();
	mercury__quantification_module24();
	mercury__quantification_module25();
	mercury__quantification_module26();
	mercury__quantification_module27();
	mercury__quantification_module28();
	mercury__quantification_module29();
	mercury__quantification_module30();
	mercury__quantification_module31();
}

#endif

void mercury__quantification__init(void); /* suppress gcc warning */
void mercury__quantification__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__quantification_bunch_0();
#endif
}
