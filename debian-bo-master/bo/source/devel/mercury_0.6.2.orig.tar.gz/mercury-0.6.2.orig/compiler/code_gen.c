/*
** Automatically generated from `code_gen.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__code_gen__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___code_gen_c_arg_0__ua10000_2_0);
Declare_static(mercury__code_gen__generate_pragma_c_code__ua10000_11_0);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i2);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i3);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i4);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i5);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i6);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i7);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i10);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i11);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i12);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i13);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i14);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i15);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i16);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i20);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i21);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i24);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i25);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i26);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i27);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i28);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i29);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i30);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i17);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i31);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i34);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i35);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i36);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i37);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i38);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i39);
Declare_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i42);
Define_extern_entry(mercury__code_gen__generate_code_5_0);
Declare_label(mercury__code_gen__generate_code_5_0_i2);
Define_extern_entry(mercury__code_gen__generate_proc_code_9_0);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i2);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i3);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i4);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i5);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i6);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i7);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i8);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i10);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i11);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i9);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i12);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i13);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i16);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i17);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i18);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i19);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i20);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i21);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i22);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i26);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i23);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i27);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i28);
Declare_label(mercury__code_gen__generate_proc_code_9_0_i29);
Define_extern_entry(mercury__code_gen__generate_goal_5_0);
Declare_label(mercury__code_gen__generate_goal_5_0_i4);
Declare_label(mercury__code_gen__generate_goal_5_0_i3);
Declare_label(mercury__code_gen__generate_goal_5_0_i6);
Declare_label(mercury__code_gen__generate_goal_5_0_i7);
Declare_label(mercury__code_gen__generate_goal_5_0_i8);
Declare_label(mercury__code_gen__generate_goal_5_0_i11);
Declare_label(mercury__code_gen__generate_goal_5_0_i13);
Declare_label(mercury__code_gen__generate_goal_5_0_i16);
Declare_label(mercury__code_gen__generate_goal_5_0_i15);
Declare_label(mercury__code_gen__generate_goal_5_0_i23);
Declare_label(mercury__code_gen__generate_goal_5_0_i18);
Declare_label(mercury__code_gen__generate_goal_5_0_i24);
Declare_label(mercury__code_gen__generate_goal_5_0_i17);
Declare_label(mercury__code_gen__generate_goal_5_0_i26);
Declare_label(mercury__code_gen__generate_goal_5_0_i30);
Declare_label(mercury__code_gen__generate_goal_5_0_i14);
Declare_label(mercury__code_gen__generate_goal_5_0_i32);
Declare_label(mercury__code_gen__generate_goal_5_0_i33);
Declare_label(mercury__code_gen__generate_goal_5_0_i34);
Declare_label(mercury__code_gen__generate_goal_5_0_i37);
Declare_label(mercury__code_gen__generate_goal_5_0_i36);
Declare_label(mercury__code_gen__generate_goal_5_0_i39);
Declare_label(mercury__code_gen__generate_goal_5_0_i10);
Declare_label(mercury__code_gen__generate_goal_5_0_i41);
Declare_label(mercury__code_gen__generate_goal_5_0_i42);
Define_extern_entry(mercury__code_gen__output_args_2_0);
Declare_label(mercury__code_gen__output_args_2_0_i4);
Declare_label(mercury__code_gen__output_args_2_0_i8);
Declare_label(mercury__code_gen__output_args_2_0_i5);
Declare_label(mercury__code_gen__output_args_2_0_i1005);
Declare_static(mercury__code_gen__generate_pred_list_code_6_0);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i4);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i5);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i6);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i7);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i10);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i14);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i15);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i16);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i17);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i18);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i11);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i19);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i20);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i21);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i22);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i23);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i24);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i25);
Declare_label(mercury__code_gen__generate_pred_list_code_6_0_i1004);
Declare_static(mercury__code_gen__generate_proc_list_code_10_0);
Declare_label(mercury__code_gen__generate_proc_list_code_10_0_i4);
Declare_label(mercury__code_gen__generate_proc_list_code_10_0_i5);
Declare_label(mercury__code_gen__generate_proc_list_code_10_0_i6);
Declare_label(mercury__code_gen__generate_proc_list_code_10_0_i1002);
Declare_static(mercury__code_gen__generate_category_code_6_0);
Declare_label(mercury__code_gen__generate_category_code_6_0_i6);
Declare_label(mercury__code_gen__generate_category_code_6_0_i7);
Declare_label(mercury__code_gen__generate_category_code_6_0_i9);
Declare_label(mercury__code_gen__generate_category_code_6_0_i5);
Declare_label(mercury__code_gen__generate_category_code_6_0_i11);
Declare_label(mercury__code_gen__generate_category_code_6_0_i12);
Declare_label(mercury__code_gen__generate_category_code_6_0_i13);
Declare_label(mercury__code_gen__generate_category_code_6_0_i14);
Declare_label(mercury__code_gen__generate_category_code_6_0_i17);
Declare_label(mercury__code_gen__generate_category_code_6_0_i19);
Declare_label(mercury__code_gen__generate_category_code_6_0_i16);
Declare_label(mercury__code_gen__generate_category_code_6_0_i3);
Declare_label(mercury__code_gen__generate_category_code_6_0_i23);
Declare_label(mercury__code_gen__generate_category_code_6_0_i24);
Declare_label(mercury__code_gen__generate_category_code_6_0_i25);
Declare_label(mercury__code_gen__generate_category_code_6_0_i22);
Declare_label(mercury__code_gen__generate_category_code_6_0_i27);
Declare_label(mercury__code_gen__generate_category_code_6_0_i28);
Declare_label(mercury__code_gen__generate_category_code_6_0_i29);
Declare_static(mercury__code_gen__generate_det_prolog_4_0);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i2);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i3);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i4);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i5);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i6);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i7);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i8);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i9);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i10);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i11);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i14);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i15);
Declare_label(mercury__code_gen__generate_det_prolog_4_0_i18);
Declare_static(mercury__code_gen__generate_det_epilog_3_0);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i2);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i3);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i4);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i5);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i8);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i7);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i10);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i11);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i12);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i13);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i14);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i17);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i18);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i21);
Declare_label(mercury__code_gen__generate_det_epilog_3_0_i22);
Declare_static(mercury__code_gen__generate_semi_prolog_4_0);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i2);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i3);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i4);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i5);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i6);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i7);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i8);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i9);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i10);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i11);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i14);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i15);
Declare_label(mercury__code_gen__generate_semi_prolog_4_0_i18);
Declare_static(mercury__code_gen__generate_semi_epilog_3_0);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i2);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i3);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i4);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i5);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i8);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i7);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i10);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i11);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i12);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i13);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i14);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i15);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i16);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i1009);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i18);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i21);
Declare_label(mercury__code_gen__generate_semi_epilog_3_0_i22);
Declare_static(mercury__code_gen__generate_non_prolog_4_0);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i2);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i3);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i4);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i5);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i6);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i7);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i8);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i9);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i10);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i11);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i12);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i13);
Declare_label(mercury__code_gen__generate_non_prolog_4_0_i14);
Declare_static(mercury__code_gen__generate_non_epilog_3_0);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i2);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i3);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i4);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i5);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i8);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i7);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i10);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i11);
Declare_label(mercury__code_gen__generate_non_epilog_3_0_i12);
Declare_static(mercury__code_gen__generate_goals_5_0);
Declare_label(mercury__code_gen__generate_goals_5_0_i4);
Declare_label(mercury__code_gen__generate_goals_5_0_i5);
Declare_label(mercury__code_gen__generate_goals_5_0_i8);
Declare_label(mercury__code_gen__generate_goals_5_0_i7);
Declare_label(mercury__code_gen__generate_goals_5_0_i10);
Declare_label(mercury__code_gen__generate_goals_5_0_i1003);
Declare_static(mercury__code_gen__generate_det_goal_2_5_0);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1030);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1029);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1014);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i10);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i14);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i23);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i24);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i26);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i28);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i30);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i31);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i32);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1028);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i37);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i42);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i41);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i45);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i39);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1020);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1021);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1022);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1023);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1024);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1025);
Declare_label(mercury__code_gen__generate_det_goal_2_5_0_i1026);
Declare_static(mercury__code_gen__make_c_arg_list_3_0);
Declare_label(mercury__code_gen__make_c_arg_list_3_0_i2);
Declare_static(mercury__code_gen__make_c_arg_list_2_4_0);
Declare_label(mercury__code_gen__make_c_arg_list_2_4_0_i1009);
Declare_label(mercury__code_gen__make_c_arg_list_2_4_0_i1007);
Declare_label(mercury__code_gen__make_c_arg_list_2_4_0_i1008);
Declare_static(mercury__code_gen__get_c_arg_list_vars_2_0);
Declare_label(mercury__code_gen__get_c_arg_list_vars_2_0_i3);
Declare_label(mercury__code_gen__get_c_arg_list_vars_2_0_i4);
Declare_label(mercury__code_gen__get_c_arg_list_vars_2_0_i1);
Declare_static(mercury__code_gen__pragma_select_out_args_2_0);
Declare_label(mercury__code_gen__pragma_select_out_args_2_0_i7);
Declare_label(mercury__code_gen__pragma_select_out_args_2_0_i8);
Declare_label(mercury__code_gen__pragma_select_out_args_2_0_i3);
Declare_label(mercury__code_gen__pragma_select_out_args_2_0_i1);
Declare_static(mercury__code_gen__pragma_select_in_args_2_0);
Declare_label(mercury__code_gen__pragma_select_in_args_2_0_i7);
Declare_label(mercury__code_gen__pragma_select_in_args_2_0_i8);
Declare_label(mercury__code_gen__pragma_select_in_args_2_0_i3);
Declare_label(mercury__code_gen__pragma_select_in_args_2_0_i1);
Declare_static(mercury__code_gen__make_pragma_decls_4_0);
Declare_label(mercury__code_gen__make_pragma_decls_4_0_i7);
Declare_label(mercury__code_gen__make_pragma_decls_4_0_i8);
Declare_label(mercury__code_gen__make_pragma_decls_4_0_i1004);
Declare_label(mercury__code_gen__make_pragma_decls_4_0_i1006);
Declare_static(mercury__code_gen__get_pragma_input_vars_5_0);
Declare_label(mercury__code_gen__get_pragma_input_vars_5_0_i7);
Declare_label(mercury__code_gen__get_pragma_input_vars_5_0_i8);
Declare_label(mercury__code_gen__get_pragma_input_vars_5_0_i9);
Declare_label(mercury__code_gen__get_pragma_input_vars_5_0_i1005);
Declare_label(mercury__code_gen__get_pragma_input_vars_5_0_i1007);
Declare_static(mercury__code_gen__pragma_acquire_regs_4_0);
Declare_label(mercury__code_gen__pragma_acquire_regs_4_0_i4);
Declare_label(mercury__code_gen__pragma_acquire_regs_4_0_i5);
Declare_label(mercury__code_gen__pragma_acquire_regs_4_0_i1002);
Declare_static(mercury__code_gen__place_pragma_output_args_in_regs_5_0);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i9);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i10);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i11);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i12);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i6);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i13);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1002);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1001);
Declare_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i17);
Declare_static(mercury__code_gen__generate_semi_goal_2_5_0);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1030);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1029);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i7);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i10);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i14);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i23);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i24);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i26);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i28);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i30);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i31);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i32);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1028);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i37);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i42);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i41);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i45);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i39);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1020);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1021);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1022);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1023);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1024);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1025);
Declare_label(mercury__code_gen__generate_semi_goal_2_5_0_i1026);
Declare_static(mercury__code_gen__generate_negation_5_0);
Declare_label(mercury__code_gen__generate_negation_5_0_i2);
Declare_label(mercury__code_gen__generate_negation_5_0_i3);
Declare_label(mercury__code_gen__generate_negation_5_0_i6);
Declare_label(mercury__code_gen__generate_negation_5_0_i7);
Declare_label(mercury__code_gen__generate_negation_5_0_i8);
Declare_label(mercury__code_gen__generate_negation_5_0_i9);
Declare_label(mercury__code_gen__generate_negation_5_0_i15);
Declare_label(mercury__code_gen__generate_negation_5_0_i17);
Declare_label(mercury__code_gen__generate_negation_5_0_i18);
Declare_label(mercury__code_gen__generate_negation_5_0_i20);
Declare_label(mercury__code_gen__generate_negation_5_0_i21);
Declare_label(mercury__code_gen__generate_negation_5_0_i22);
Declare_label(mercury__code_gen__generate_negation_5_0_i23);
Declare_label(mercury__code_gen__generate_negation_5_0_i24);
Declare_label(mercury__code_gen__generate_negation_5_0_i30);
Declare_label(mercury__code_gen__generate_negation_5_0_i37);
Declare_label(mercury__code_gen__generate_negation_5_0_i1063);
Declare_label(mercury__code_gen__generate_negation_5_0_i11);
Declare_label(mercury__code_gen__generate_negation_5_0_i10);
Declare_label(mercury__code_gen__generate_negation_5_0_i39);
Declare_label(mercury__code_gen__generate_negation_5_0_i40);
Declare_label(mercury__code_gen__generate_negation_5_0_i41);
Declare_static(mercury__code_gen__generate_negation_general_7_0);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i2);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i3);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i6);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i8);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i5);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i10);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i11);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i12);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i13);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i16);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i17);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i18);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i19);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i20);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i21);
Declare_label(mercury__code_gen__generate_negation_general_7_0_i22);
Declare_static(mercury__code_gen__generate_non_goal_2_5_0);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1008);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1007);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1006);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i7);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i8);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i11);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i13);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i14);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1005);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i20);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i25);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i27);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i24);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i28);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i22);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1000);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1001);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1002);
Declare_label(mercury__code_gen__generate_non_goal_2_5_0_i1003);
Declare_static(mercury__code_gen__add_saved_succip_3_0);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i1020);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i7);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i12);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i1019);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i13);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i17);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i18);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i1017);
Declare_static(mercury____Unify___code_gen__c_arg_0_0);
Declare_label(mercury____Unify___code_gen__c_arg_0_0_i2);
Declare_label(mercury____Unify___code_gen__c_arg_0_0_i1);
Declare_static(mercury____Index___code_gen__c_arg_0_0);
Declare_static(mercury____Compare___code_gen__c_arg_0_0);
Declare_label(mercury____Compare___code_gen__c_arg_0_0_i4);
Declare_label(mercury____Compare___code_gen__c_arg_0_0_i3);

extern Word * mercury_data_code_gen__base_type_layout_c_arg_0[];
Word * mercury_data_code_gen__base_type_info_c_arg_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___code_gen__c_arg_0_0),
	(Word *) (Integer) STATIC(mercury____Index___code_gen__c_arg_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___code_gen__c_arg_0_0),
	(Word *) (Integer) mercury_data_code_gen__base_type_layout_c_arg_0
};

extern Word * mercury_data_code_gen__common_46[];
Word * mercury_data_code_gen__base_type_layout_c_arg_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_46),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word mercury_data_code_gen__common_0[] = {
	((Integer) 1)
};

Word * mercury_data_code_gen__common_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_0)
};

Word * mercury_data_code_gen__common_2[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_1)
};

Word * mercury_data_code_gen__common_3[] = {
	(Word *) string_const("#endif\n", 7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_4[] = {
	(Word *) string_const("\trestore_registers();\n", 22),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_3)
};

Word * mercury_data_code_gen__common_5[] = {
	(Word *) string_const("#ifndef CONSERVATIVE_GC\n", 24),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_4)
};

Word * mercury_data_code_gen__common_6[] = {
	(Word *) string_const("\n}\n", 3),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_5)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_code_gen__common_7[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_code_gen__common_8[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_7)
};

Word mercury_data_code_gen__common_9[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_10[] = {
	(Word *) string_const("Start of procedure prologue", 27)
};

Word * mercury_data_code_gen__common_11[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_10),
	(Word *) string_const("", 0)
};

Word * mercury_data_code_gen__common_12[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_13[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_12)
};

Word * mercury_data_code_gen__common_14[] = {
	(Word *) string_const("End of procedure prologue", 25)
};

Word * mercury_data_code_gen__common_15[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_14),
	(Word *) string_const("", 0)
};

Word * mercury_data_code_gen__common_16[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_15),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_17[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_16)
};

Word mercury_data_code_gen__common_18[] = {
	((Integer) 6),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_19[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_18),
	(Word *) string_const("Return from procedure call", 26)
};

Word * mercury_data_code_gen__common_20[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_19),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_21[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_20)
};

Word * mercury_data_code_gen__common_22[] = {
	(Word *) string_const("Start of procedure epilogue", 27)
};

Word * mercury_data_code_gen__common_23[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_22),
	(Word *) string_const("", 0)
};

Word * mercury_data_code_gen__common_24[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_23),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_25[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_24)
};

Word * mercury_data_code_gen__common_26[] = {
	(Word *) string_const("End of procedure epilogue", 25)
};

Word * mercury_data_code_gen__common_27[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_26),
	(Word *) string_const("", 0)
};

Word * mercury_data_code_gen__common_28[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_27),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_29[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_28)
};

Word mercury_data_code_gen__common_30[] = {
	((Integer) 1),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_31[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_30)
};

Word * mercury_data_code_gen__common_32[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_31),
	(Word *) string_const("Succeed", 7)
};

Word * mercury_data_code_gen__common_33[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_32),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_34[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_33)
};

Word mercury_data_code_gen__common_35[] = {
	((Integer) 1),
	(Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_code_gen__common_36[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_35)
};

Word * mercury_data_code_gen__common_37[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_36),
	(Word *) string_const("Fail", 4)
};

Word * mercury_data_code_gen__common_38[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_37),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_39[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_38)
};

Word * mercury_data_code_gen__common_40[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_0)
};

Word * mercury_data_code_gen__common_41[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_code_gen__common_40),
	(Word *) string_const("Succeed", 7)
};

Word * mercury_data_code_gen__common_42[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_41),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_gen__common_43[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_42)
};

extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_code_gen__common_44[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
Word * mercury_data_code_gen__common_45[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_code_gen__common_46[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_44),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_45),
	(Word *) string_const("c_arg", 5)
};

BEGIN_MODULE(mercury__code_gen_module0)
	init_entry(mercury____Index___code_gen_c_arg_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___code_gen_c_arg_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___code_gen_c_arg_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module1)
	init_entry(mercury__code_gen__generate_pragma_c_code__ua10000_11_0);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i2);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i3);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i4);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i5);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i6);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i7);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i10);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i11);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i12);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i13);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i14);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i15);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i16);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i20);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i21);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i24);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i25);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i26);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i27);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i28);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i29);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i30);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i17);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i31);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i34);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i35);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i36);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i37);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i38);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i39);
	init_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i42);
BEGIN_CODE

/* code for predicate 'code_gen__generate_pragma_c_code__ua10000'/11 in mode 0 */
Define_static(mercury__code_gen__generate_pragma_c_code__ua10000_11_0);
	incr_sp_push_msg(11, "code_gen__generate_pragma_c_code__ua10000");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	r3 = (Integer) r8;
	{
	Declare_entry(mercury__code_info__get_pred_proc_arginfo_5_0);
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i2,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__code_gen__make_c_arg_list_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i3,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r4 = (Integer) detstackvar(4);
	r3 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_code_gen__base_type_info_c_arg_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i4,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	detstackvar(5) = (Integer) r1;
	call_localret(STATIC(mercury__code_gen__pragma_select_in_args_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i5,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__code_gen__pragma_select_out_args_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i6,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i7);
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i14);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i7);
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__set_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__set_succip_used_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i10,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__code_gen__get_c_arg_list_vars_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i11,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i12,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__call_gen__save_variables_4_0);
	call_localret(ENTRY(mercury__call_gen__save_variables_4_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i13,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i14);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	call_localret(STATIC(mercury__code_gen__make_pragma_decls_4_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i15,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i15);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__code_gen__get_pragma_input_vars_5_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i16,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i17);
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__clear_r1_3_0);
	call_localret(ENTRY(mercury__code_info__clear_r1_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i20,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i20);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i21);
	r9 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i25);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i21);
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__clear_all_registers_2_0);
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i24,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i25);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i26,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i26);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i27,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	tag_incr_hp(detstackvar(10), mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_2);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("Test for success of pragma_c_code", 33);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(2), (Integer) detstackvar(10), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_0);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) detstackvar(10), ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("", 0);
	{
	Declare_entry(mercury__code_info__lock_reg_3_0);
	call_localret(ENTRY(mercury__code_info__lock_reg_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i28,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__code_gen__pragma_acquire_regs_4_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i29,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_0);
	{
	Declare_entry(mercury__code_info__unlock_reg_3_0);
	call_localret(ENTRY(mercury__code_info__unlock_reg_3_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i30,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i37);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i17);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i31);
	r7 = (Integer) r1;
	r8 = (Integer) r2;
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i35);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i31);
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__clear_all_registers_2_0);
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i34,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i34);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i35);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r1;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(10) = (Integer) r9;
	call_localret(STATIC(mercury__code_gen__pragma_acquire_regs_4_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i36,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i36);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r11 = (Integer) detstackvar(10);
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i37);
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	call_localret(STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i38,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i38);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i39);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 17);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("Pragma C inclusion", 18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i39);
	r3 = (Integer) detstackvar(2);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\tsave_registers();\n{\n", 21);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_6);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i42,
		STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	}
Define_label(mercury__code_gen__generate_pragma_c_code__ua10000_11_0_i42);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pragma_c_code__ua10000_11_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 17);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("Pragma C inclusion", 18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module2)
	init_entry(mercury__code_gen__generate_code_5_0);
	init_label(mercury__code_gen__generate_code_5_0_i2);
BEGIN_CODE

/* code for predicate 'generate_code'/5 in mode 0 */
Define_entry(mercury__code_gen__generate_code_5_0);
	incr_sp_push_msg(3, "generate_code");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__code_gen__generate_code_5_0_i2,
		ENTRY(mercury__code_gen__generate_code_5_0));
	}
Define_label(mercury__code_gen__generate_code_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_code_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_gen__generate_pred_list_code_6_0),
		ENTRY(mercury__code_gen__generate_code_5_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module3)
	init_entry(mercury__code_gen__generate_proc_code_9_0);
	init_label(mercury__code_gen__generate_proc_code_9_0_i2);
	init_label(mercury__code_gen__generate_proc_code_9_0_i3);
	init_label(mercury__code_gen__generate_proc_code_9_0_i4);
	init_label(mercury__code_gen__generate_proc_code_9_0_i5);
	init_label(mercury__code_gen__generate_proc_code_9_0_i6);
	init_label(mercury__code_gen__generate_proc_code_9_0_i7);
	init_label(mercury__code_gen__generate_proc_code_9_0_i8);
	init_label(mercury__code_gen__generate_proc_code_9_0_i10);
	init_label(mercury__code_gen__generate_proc_code_9_0_i11);
	init_label(mercury__code_gen__generate_proc_code_9_0_i9);
	init_label(mercury__code_gen__generate_proc_code_9_0_i12);
	init_label(mercury__code_gen__generate_proc_code_9_0_i13);
	init_label(mercury__code_gen__generate_proc_code_9_0_i16);
	init_label(mercury__code_gen__generate_proc_code_9_0_i17);
	init_label(mercury__code_gen__generate_proc_code_9_0_i18);
	init_label(mercury__code_gen__generate_proc_code_9_0_i19);
	init_label(mercury__code_gen__generate_proc_code_9_0_i20);
	init_label(mercury__code_gen__generate_proc_code_9_0_i21);
	init_label(mercury__code_gen__generate_proc_code_9_0_i22);
	init_label(mercury__code_gen__generate_proc_code_9_0_i26);
	init_label(mercury__code_gen__generate_proc_code_9_0_i23);
	init_label(mercury__code_gen__generate_proc_code_9_0_i27);
	init_label(mercury__code_gen__generate_proc_code_9_0_i28);
	init_label(mercury__code_gen__generate_proc_code_9_0_i29);
BEGIN_CODE

/* code for predicate 'generate_proc_code'/9 in mode 0 */
Define_entry(mercury__code_gen__generate_proc_code_9_0);
	incr_sp_push_msg(14, "generate_proc_code");
	detstackvar(14) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__code_gen__generate_proc_code_9_0_i2,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__code_gen__generate_proc_code_9_0_i3,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__code_gen__generate_proc_code_9_0_i4,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_liveness_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_liveness_info_2_0),
		mercury__code_gen__generate_proc_code_9_0_i5,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_stack_slots_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_stack_slots_2_0),
		mercury__code_gen__generate_proc_code_9_0_i6,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__code_gen__generate_proc_code_9_0_i7,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(8), ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_follow_vars_2_0),
		mercury__code_gen__generate_proc_code_9_0_i8,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_9_0_i10);
	r13 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_9_0_i9);
Define_label(mercury__code_gen__generate_proc_code_9_0_i10);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__code_gen__generate_proc_code_9_0_i11,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r13 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
Define_label(mercury__code_gen__generate_proc_code_9_0_i9);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(6) = (Integer) r13;
	{
	Declare_entry(mercury__globals__io_get_gc_method_3_0);
	call_localret(ENTRY(mercury__globals__io_get_gc_method_3_0),
		mercury__code_gen__generate_proc_code_9_0_i12,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_9_0_i13);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(6);
	r14 = ((Integer) 0);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_9_0_i16);
Define_label(mercury__code_gen__generate_proc_code_9_0_i13);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(6);
	r14 = ((Integer) 1);
Define_label(mercury__code_gen__generate_proc_code_9_0_i16);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(6) = (Integer) r13;
	detstackvar(13) = (Integer) r14;
	{
	Declare_entry(mercury__globals__io_get_globals_3_0);
	call_localret(ENTRY(mercury__globals__io_get_globals_3_0),
		mercury__code_gen__generate_proc_code_9_0_i17,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r12 = (Integer) detstackvar(5);
	r5 = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(1);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(6);
	r11 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__init_13_0);
	call_localret(ENTRY(mercury__code_info__init_13_0),
		mercury__code_gen__generate_proc_code_9_0_i18,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__code_gen__generate_category_code_6_0),
		mercury__code_gen__generate_proc_code_9_0_i19,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
Define_label(mercury__code_gen__generate_proc_code_9_0_i19);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_shapes_3_0);
	call_localret(ENTRY(mercury__code_info__get_shapes_3_0),
		mercury__code_gen__generate_proc_code_9_0_i20,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i20);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_8);
	{
	Declare_entry(mercury__tree__flatten_2_0);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__code_gen__generate_proc_code_9_0_i21,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i21);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_7);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__code_gen__generate_proc_code_9_0_i22,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r3 = (Integer) detstackvar(6);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_9_0_i23);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__code_gen__add_saved_succip_3_0),
		mercury__code_gen__generate_proc_code_9_0_i26,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
Define_label(mercury__code_gen__generate_proc_code_9_0_i26);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_9_0_i27);
Define_label(mercury__code_gen__generate_proc_code_9_0_i23);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__code_gen__generate_proc_code_9_0_i27);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_gen__generate_proc_code_9_0_i28,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_module__predicate_arity_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_arity_3_0),
		mercury__code_gen__generate_proc_code_9_0_i29,
		ENTRY(mercury__code_gen__generate_proc_code_9_0));
	}
Define_label(mercury__code_gen__generate_proc_code_9_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_9_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module4)
	init_entry(mercury__code_gen__generate_goal_5_0);
	init_label(mercury__code_gen__generate_goal_5_0_i4);
	init_label(mercury__code_gen__generate_goal_5_0_i3);
	init_label(mercury__code_gen__generate_goal_5_0_i6);
	init_label(mercury__code_gen__generate_goal_5_0_i7);
	init_label(mercury__code_gen__generate_goal_5_0_i8);
	init_label(mercury__code_gen__generate_goal_5_0_i11);
	init_label(mercury__code_gen__generate_goal_5_0_i13);
	init_label(mercury__code_gen__generate_goal_5_0_i16);
	init_label(mercury__code_gen__generate_goal_5_0_i15);
	init_label(mercury__code_gen__generate_goal_5_0_i23);
	init_label(mercury__code_gen__generate_goal_5_0_i18);
	init_label(mercury__code_gen__generate_goal_5_0_i24);
	init_label(mercury__code_gen__generate_goal_5_0_i17);
	init_label(mercury__code_gen__generate_goal_5_0_i26);
	init_label(mercury__code_gen__generate_goal_5_0_i30);
	init_label(mercury__code_gen__generate_goal_5_0_i14);
	init_label(mercury__code_gen__generate_goal_5_0_i32);
	init_label(mercury__code_gen__generate_goal_5_0_i33);
	init_label(mercury__code_gen__generate_goal_5_0_i34);
	init_label(mercury__code_gen__generate_goal_5_0_i37);
	init_label(mercury__code_gen__generate_goal_5_0_i36);
	init_label(mercury__code_gen__generate_goal_5_0_i39);
	init_label(mercury__code_gen__generate_goal_5_0_i10);
	init_label(mercury__code_gen__generate_goal_5_0_i41);
	init_label(mercury__code_gen__generate_goal_5_0_i42);
BEGIN_CODE

/* code for predicate 'code_gen__generate_goal'/5 in mode 0 */
Define_entry(mercury__code_gen__generate_goal_5_0);
	incr_sp_push_msg(9, "code_gen__generate_goal");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_is_atomic_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_is_atomic_1_0),
		mercury__code_gen__generate_goal_5_0_i4,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i3);
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(5);
	r2 = ((Integer) 0);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i6);
Define_label(mercury__code_gen__generate_goal_5_0_i3);
	r1 = (Integer) detstackvar(5);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
Define_label(mercury__code_gen__generate_goal_5_0_i6);
	detstackvar(1) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__code_aux__pre_goal_update_4_0);
	call_localret(ENTRY(mercury__code_aux__pre_goal_update_4_0),
		mercury__code_gen__generate_goal_5_0_i7,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_goal_5_0_i8,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__instmap__is_reachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__code_gen__generate_goal_5_0_i11,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i10);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__code_gen__generate_goal_5_0_i13,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i15);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__code_gen__generate_det_goal_2_5_0),
		mercury__code_gen__generate_goal_5_0_i16,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i14);
Define_label(mercury__code_gen__generate_goal_5_0_i15);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i17);
	if (((Integer) detstackvar(1) == ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i18);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__code_gen__generate_semi_goal_2_5_0),
		mercury__code_gen__generate_goal_5_0_i23,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i23);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i14);
Define_label(mercury__code_gen__generate_goal_5_0_i18);
	r1 = string_const("semidet model in det context", 28);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_goal_5_0_i24,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r3 = (Integer) detstackvar(5);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i14);
Define_label(mercury__code_gen__generate_goal_5_0_i17);
	if (((Integer) detstackvar(1) != ((Integer) 2)))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i26);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__code_gen__generate_non_goal_2_5_0),
		mercury__code_gen__generate_goal_5_0_i23,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i26);
	r1 = string_const("nondet model in det/semidet context", 35);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_goal_5_0_i30,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r3 = (Integer) detstackvar(5);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
Define_label(mercury__code_gen__generate_goal_5_0_i14);
	detstackvar(5) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__code_info__set_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__set_instmap_3_0),
		mercury__code_gen__generate_goal_5_0_i32,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i32);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_aux__post_goal_update_3_0);
	call_localret(ENTRY(mercury__code_aux__post_goal_update_3_0),
		mercury__code_gen__generate_goal_5_0_i33,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i33);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__code_gen__generate_goal_5_0_i34,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i34);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	detstackvar(8) = (Integer) r2;
	r2 = ((Integer) 71);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_1);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__code_gen__generate_goal_5_0_i37,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i37);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i36);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(8);
	{
	extern Word * mercury_data_code_info__base_type_info_code_info_0[];
	r1 = (Integer) mercury_data_code_info__base_type_info_code_info_0;
	}
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i41);
Define_label(mercury__code_gen__generate_goal_5_0_i36);
	r1 = string_const("Eager code unavailable", 22);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_goal_5_0_i39,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i39);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i41);
Define_label(mercury__code_gen__generate_goal_5_0_i10);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	extern Word * mercury_data_code_info__base_type_info_code_info_0[];
	r1 = (Integer) mercury_data_code_info__base_type_info_code_info_0;
	}
Define_label(mercury__code_gen__generate_goal_5_0_i41);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__f_cut_2_1);
	call_localret(ENTRY(mercury__f_cut_2_1),
		mercury__code_gen__generate_goal_5_0_i42,
		ENTRY(mercury__code_gen__generate_goal_5_0));
	}
Define_label(mercury__code_gen__generate_goal_5_0_i42);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module5)
	init_entry(mercury__code_gen__output_args_2_0);
	init_label(mercury__code_gen__output_args_2_0_i4);
	init_label(mercury__code_gen__output_args_2_0_i8);
	init_label(mercury__code_gen__output_args_2_0_i5);
	init_label(mercury__code_gen__output_args_2_0_i1005);
BEGIN_CODE

/* code for predicate 'code_gen__output_args'/2 in mode 0 */
Define_entry(mercury__code_gen__output_args_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__output_args_2_0_i1005);
	incr_sp_push_msg(3, "code_gen__output_args");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__code_gen__output_args_2_0,
		LABEL(mercury__code_gen__output_args_2_0_i4),
		ENTRY(mercury__code_gen__output_args_2_0));
Define_label(mercury__code_gen__output_args_2_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__output_args_2_0));
	if (((Integer) detstackvar(2) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__output_args_2_0_i5);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_util__arg_loc_to_register_2_0);
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__code_gen__output_args_2_0_i8,
		ENTRY(mercury__code_gen__output_args_2_0));
	}
Define_label(mercury__code_gen__output_args_2_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__output_args_2_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	tailcall(ENTRY(mercury__set__insert_3_1),
		ENTRY(mercury__code_gen__output_args_2_0));
	}
Define_label(mercury__code_gen__output_args_2_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_gen__output_args_2_0_i1005);
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	tailcall(ENTRY(mercury__set__init_1_0),
		ENTRY(mercury__code_gen__output_args_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module6)
	init_entry(mercury__code_gen__generate_pred_list_code_6_0);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i4);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i5);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i6);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i7);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i10);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i14);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i15);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i16);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i17);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i18);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i11);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i19);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i20);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i21);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i22);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i23);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i24);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i25);
	init_label(mercury__code_gen__generate_pred_list_code_6_0_i1004);
BEGIN_CODE

/* code for predicate 'generate_pred_list_code'/6 in mode 0 */
Define_static(mercury__code_gen__generate_pred_list_code_6_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_6_0_i1004);
	incr_sp_push_msg(7, "generate_pred_list_code");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__code_gen__generate_pred_list_code_6_0_i4,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_gen__generate_pred_list_code_6_0_i5,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__code_gen__generate_pred_list_code_6_0_i6,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_6_0_i7);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__code_gen__generate_pred_list_code_6_0_i23);
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i7);
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 12);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__code_gen__generate_pred_list_code_6_0_i10,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_6_0_i11);
	r1 = string_const("% Generating code for ", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__code_gen__generate_pred_list_code_6_0_i14,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_out__write_pred_id_4_0);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__code_gen__generate_pred_list_code_6_0_i15,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i15);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__code_gen__generate_pred_list_code_6_0_i16,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 14);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__code_gen__generate_pred_list_code_6_0_i17,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	{
	Declare_entry(mercury__passes_aux__maybe_report_stats_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_report_stats_3_0),
		mercury__code_gen__generate_pred_list_code_6_0_i18,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__code_gen__generate_pred_list_code_6_0_i19);
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i11);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(2);
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i19);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_module__module_info_get_shapes_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_shapes_2_0),
		mercury__code_gen__generate_pred_list_code_6_0_i20,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i20);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r7 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__code_gen__generate_proc_list_code_10_0),
		mercury__code_gen__generate_pred_list_code_6_0_i21,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i21);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_set_shapes_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_shapes_3_0),
		mercury__code_gen__generate_pred_list_code_6_0_i22,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i23);
	detstackvar(1) = (Integer) r4;
	localcall(mercury__code_gen__generate_pred_list_code_6_0,
		LABEL(mercury__code_gen__generate_pred_list_code_6_0_i24),
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_c_procedure_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_c_procedure_0;
	}
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__code_gen__generate_pred_list_code_6_0_i25,
		STATIC(mercury__code_gen__generate_pred_list_code_6_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_gen__generate_pred_list_code_6_0_i1004);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module7)
	init_entry(mercury__code_gen__generate_proc_list_code_10_0);
	init_label(mercury__code_gen__generate_proc_list_code_10_0_i4);
	init_label(mercury__code_gen__generate_proc_list_code_10_0_i5);
	init_label(mercury__code_gen__generate_proc_list_code_10_0_i6);
	init_label(mercury__code_gen__generate_proc_list_code_10_0_i1002);
BEGIN_CODE

/* code for predicate 'generate_proc_list_code'/10 in mode 0 */
Define_static(mercury__code_gen__generate_proc_list_code_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_proc_list_code_10_0_i1002);
	incr_sp_push_msg(9, "generate_proc_list_code");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__code_gen__generate_proc_list_code_10_0_i4,
		STATIC(mercury__code_gen__generate_proc_list_code_10_0));
	}
Define_label(mercury__code_gen__generate_proc_list_code_10_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_list_code_10_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_gen__generate_proc_list_code_10_0_i5,
		STATIC(mercury__code_gen__generate_proc_list_code_10_0));
	}
Define_label(mercury__code_gen__generate_proc_list_code_10_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_list_code_10_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	{
		call_localret(STATIC(mercury__code_gen__generate_proc_code_9_0),
		mercury__code_gen__generate_proc_list_code_10_0_i6,
		STATIC(mercury__code_gen__generate_proc_list_code_10_0));
	}
Define_label(mercury__code_gen__generate_proc_list_code_10_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_list_code_10_0));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	r5 = (Integer) r1;
	r7 = (Integer) r3;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__code_gen__generate_proc_list_code_10_0,
		STATIC(mercury__code_gen__generate_proc_list_code_10_0));
Define_label(mercury__code_gen__generate_proc_list_code_10_0_i1002);
	r1 = (Integer) r5;
	r2 = (Integer) r6;
	r3 = (Integer) r7;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module8)
	init_entry(mercury__code_gen__generate_category_code_6_0);
	init_label(mercury__code_gen__generate_category_code_6_0_i6);
	init_label(mercury__code_gen__generate_category_code_6_0_i7);
	init_label(mercury__code_gen__generate_category_code_6_0_i9);
	init_label(mercury__code_gen__generate_category_code_6_0_i5);
	init_label(mercury__code_gen__generate_category_code_6_0_i11);
	init_label(mercury__code_gen__generate_category_code_6_0_i12);
	init_label(mercury__code_gen__generate_category_code_6_0_i13);
	init_label(mercury__code_gen__generate_category_code_6_0_i14);
	init_label(mercury__code_gen__generate_category_code_6_0_i17);
	init_label(mercury__code_gen__generate_category_code_6_0_i19);
	init_label(mercury__code_gen__generate_category_code_6_0_i16);
	init_label(mercury__code_gen__generate_category_code_6_0_i3);
	init_label(mercury__code_gen__generate_category_code_6_0_i23);
	init_label(mercury__code_gen__generate_category_code_6_0_i24);
	init_label(mercury__code_gen__generate_category_code_6_0_i25);
	init_label(mercury__code_gen__generate_category_code_6_0_i22);
	init_label(mercury__code_gen__generate_category_code_6_0_i27);
	init_label(mercury__code_gen__generate_category_code_6_0_i28);
	init_label(mercury__code_gen__generate_category_code_6_0_i29);
BEGIN_CODE

/* code for predicate 'generate_category_code'/6 in mode 0 */
Define_static(mercury__code_gen__generate_category_code_6_0);
	incr_sp_push_msg(5, "generate_category_code");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_category_code_6_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__code_gen__generate_category_code_6_0_i6,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(3) = (Integer) r2;
	r2 = ((Integer) 113);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_1);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__code_gen__generate_category_code_6_0_i7,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_category_code_6_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__middle_rec__match_and_generate_4_0);
	call_localret(ENTRY(mercury__middle_rec__match_and_generate_4_0),
		mercury__code_gen__generate_category_code_6_0_i9,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_category_code_6_0_i5);
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_category_code_6_0_i5);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__manufacture_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__manufacture_failure_cont_3_0),
		mercury__code_gen__generate_category_code_6_0_i11,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_6_0_i12,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_category_code_6_0_i13,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__code_gen__generate_det_prolog_4_0),
		mercury__code_gen__generate_category_code_6_0_i14,
		STATIC(mercury__code_gen__generate_category_code_6_0));
Define_label(mercury__code_gen__generate_category_code_6_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__instmap__is_reachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__code_gen__generate_category_code_6_0_i17,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_category_code_6_0_i16);
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__code_gen__generate_det_epilog_3_0),
		mercury__code_gen__generate_category_code_6_0_i19,
		STATIC(mercury__code_gen__generate_category_code_6_0));
Define_label(mercury__code_gen__generate_category_code_6_0_i19);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) r2;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(1);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i16);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i3);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_category_code_6_0_i22);
	detstackvar(1) = (Integer) r2;
	r1 = ((Integer) 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__manufacture_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__manufacture_failure_cont_3_0),
		mercury__code_gen__generate_category_code_6_0_i23,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i23);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_6_0_i24,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__code_gen__generate_semi_prolog_4_0),
		mercury__code_gen__generate_category_code_6_0_i25,
		STATIC(mercury__code_gen__generate_category_code_6_0));
Define_label(mercury__code_gen__generate_category_code_6_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__code_gen__generate_semi_epilog_3_0),
		mercury__code_gen__generate_category_code_6_0_i19,
		STATIC(mercury__code_gen__generate_category_code_6_0));
Define_label(mercury__code_gen__generate_category_code_6_0_i22);
	detstackvar(1) = (Integer) r2;
	r1 = ((Integer) 0);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__manufacture_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__manufacture_failure_cont_3_0),
		mercury__code_gen__generate_category_code_6_0_i27,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_6_0_i28,
		STATIC(mercury__code_gen__generate_category_code_6_0));
	}
Define_label(mercury__code_gen__generate_category_code_6_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__code_gen__generate_non_prolog_4_0),
		mercury__code_gen__generate_category_code_6_0_i29,
		STATIC(mercury__code_gen__generate_category_code_6_0));
Define_label(mercury__code_gen__generate_category_code_6_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_6_0));
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__code_gen__generate_non_epilog_3_0),
		mercury__code_gen__generate_category_code_6_0_i19,
		STATIC(mercury__code_gen__generate_category_code_6_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module9)
	init_entry(mercury__code_gen__generate_det_prolog_4_0);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i2);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i3);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i4);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i5);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i6);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i7);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i8);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i9);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i10);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i11);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i14);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i15);
	init_label(mercury__code_gen__generate_det_prolog_4_0_i18);
BEGIN_CODE

/* code for predicate 'code_gen__generate_det_prolog'/4 in mode 0 */
Define_static(mercury__code_gen__generate_det_prolog_4_0);
	incr_sp_push_msg(7, "code_gen__generate_det_prolog");
	detstackvar(7) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__get_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i2,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_varset_3_0);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i3,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_aux__explain_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_aux__explain_stack_slots_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i4,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i5,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_pred_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i6,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_proc_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i7,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__get_succip_used_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i8,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i9,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__code_util__make_local_entry_label_5_0);
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_gen__generate_det_prolog_4_0_i10,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("Procedure entry point", 21);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_det_prolog_4_0_i11);
	r4 = ((Integer) detstackvar(3) + ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	r3 = (Integer) detstackvar(2);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("Procedure entry point", 21);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) tempr1;
	r9 = ((Integer) detstackvar(3) + ((Integer) 1));
	r6 = (Integer) r9;
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(r11, mktag(0), ((Integer) 2));
	tag_incr_hp(r12, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r12, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r12, ((Integer) 2)) = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_9);
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r11, ((Integer) 1)) = string_const("save the success ip", 19);
	field(mktag(3), (Integer) r12, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	GOTO_LABEL(mercury__code_gen__generate_det_prolog_4_0_i14);
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i11);
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__code_gen__generate_det_prolog_4_0_i14);
	if (((Integer) r6 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_det_prolog_4_0_i15);
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_13);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_17);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i15);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_gen__generate_det_prolog_4_0_i18,
		STATIC(mercury__code_gen__generate_det_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_det_prolog_4_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_prolog_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_13);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("Allocate stack frame", 20);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_17);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module10)
	init_entry(mercury__code_gen__generate_det_epilog_3_0);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i2);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i3);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i4);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i5);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i8);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i7);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i10);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i11);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i12);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i13);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i14);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i17);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i18);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i21);
	init_label(mercury__code_gen__generate_det_epilog_3_0_i22);
BEGIN_CODE

/* code for predicate 'code_gen__generate_det_epilog'/3 in mode 0 */
Define_static(mercury__code_gen__generate_det_epilog_3_0);
	incr_sp_push_msg(8, "code_gen__generate_det_epilog");
	detstackvar(8) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_det_epilog_3_0_i2,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_arginfo_3_0);
	call_localret(ENTRY(mercury__code_info__get_arginfo_3_0),
		mercury__code_gen__generate_det_epilog_3_0_i3,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_headvars_3_0);
	call_localret(ENTRY(mercury__code_info__get_headvars_3_0),
		mercury__code_gen__generate_det_epilog_3_0_i4,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	detstackvar(7) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__code_gen__generate_det_epilog_3_0_i5,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__instmap__is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__code_gen__generate_det_epilog_3_0_i8,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_det_epilog_3_0_i7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__code_gen__generate_det_epilog_3_0_i11);
Define_label(mercury__code_gen__generate_det_epilog_3_0_i7);
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__code_gen__generate_det_epilog_3_0_i10,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
Define_label(mercury__code_gen__generate_det_epilog_3_0_i11);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__get_succip_used_3_0),
		mercury__code_gen__generate_det_epilog_3_0_i12,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__code_gen__generate_det_epilog_3_0_i13,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	if (((Integer) detstackvar(1) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_det_epilog_3_0_i14);
	r3 = (Integer) detstackvar(3);
	r4 = ((Integer) r1 + ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r9, mktag(0), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("restore the success ip", 22);
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) r9;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	r6 = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_21);
	GOTO_LABEL(mercury__code_gen__generate_det_epilog_3_0_i17);
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i14);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_21);
Define_label(mercury__code_gen__generate_det_epilog_3_0_i17);
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_det_epilog_3_0_i18);
	r4 = (Integer) r5;
	r5 = (Integer) r6;
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__code_gen__generate_det_epilog_3_0_i21);
Define_label(mercury__code_gen__generate_det_epilog_3_0_i18);
	r7 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = (Integer) r6;
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(r11, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r7;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r11, ((Integer) 1)) = string_const("Deallocate stack frame", 22);
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i21);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
		call_localret(STATIC(mercury__code_gen__output_args_2_0),
		mercury__code_gen__generate_det_epilog_3_0_i22,
		STATIC(mercury__code_gen__generate_det_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_det_epilog_3_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_epilog_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_25);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_29);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module11)
	init_entry(mercury__code_gen__generate_semi_prolog_4_0);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i2);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i3);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i4);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i5);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i6);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i7);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i8);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i9);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i10);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i11);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i14);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i15);
	init_label(mercury__code_gen__generate_semi_prolog_4_0_i18);
BEGIN_CODE

/* code for predicate 'code_gen__generate_semi_prolog'/4 in mode 0 */
Define_static(mercury__code_gen__generate_semi_prolog_4_0);
	incr_sp_push_msg(7, "code_gen__generate_semi_prolog");
	detstackvar(7) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__get_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i2,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_varset_3_0);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i3,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_aux__explain_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_aux__explain_stack_slots_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i4,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_pred_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i5,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_proc_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i6,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__get_succip_used_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i7,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i8,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i9,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__code_util__make_local_entry_label_5_0);
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_gen__generate_semi_prolog_4_0_i10,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("Procedure entry point", 21);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	if (((Integer) detstackvar(4) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_semi_prolog_4_0_i11);
	r4 = ((Integer) detstackvar(5) + ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	r3 = (Integer) detstackvar(2);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("Procedure entry point", 21);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) tempr1;
	r9 = ((Integer) detstackvar(5) + ((Integer) 1));
	r6 = (Integer) r9;
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(r11, mktag(0), ((Integer) 2));
	tag_incr_hp(r12, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r12, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r12, ((Integer) 2)) = (Integer) mkword(mktag(0), (Integer) mercury_data_code_gen__common_9);
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r11, ((Integer) 1)) = string_const("save the success ip", 19);
	field(mktag(3), (Integer) r12, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	GOTO_LABEL(mercury__code_gen__generate_semi_prolog_4_0_i14);
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i11);
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i14);
	if (((Integer) r6 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_semi_prolog_4_0_i15);
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_13);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_17);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i15);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_gen__generate_semi_prolog_4_0_i18,
		STATIC(mercury__code_gen__generate_semi_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_semi_prolog_4_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_prolog_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_13);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("Allocate stack frame", 20);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_17);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module12)
	init_entry(mercury__code_gen__generate_semi_epilog_3_0);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i2);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i3);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i4);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i5);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i8);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i7);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i10);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i11);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i12);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i13);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i14);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i15);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i16);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i1009);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i18);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i21);
	init_label(mercury__code_gen__generate_semi_epilog_3_0_i22);
BEGIN_CODE

/* code for predicate 'code_gen__generate_semi_epilog'/3 in mode 0 */
Define_static(mercury__code_gen__generate_semi_epilog_3_0);
	incr_sp_push_msg(9, "code_gen__generate_semi_epilog");
	detstackvar(9) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i2,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_arginfo_3_0);
	call_localret(ENTRY(mercury__code_info__get_arginfo_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i3,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_headvars_3_0);
	call_localret(ENTRY(mercury__code_info__get_headvars_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i4,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(8) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i5,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__instmap__is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__code_gen__generate_semi_epilog_3_0_i8,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_semi_epilog_3_0_i7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_semi_epilog_3_0_i11);
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i7);
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__code_gen__generate_semi_epilog_3_0_i10,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i11);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__restore_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__restore_failure_cont_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i12,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__get_succip_used_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i13,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__code_gen__generate_semi_epilog_3_0_i14,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	detstackvar(1) = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__code_gen__output_args_2_0),
		mercury__code_gen__generate_semi_epilog_3_0_i15,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i15);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_1);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__code_gen__generate_semi_epilog_3_0_i16,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	tag_incr_hp(detstackvar(7), mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("", 0);
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	field(mktag(1), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_1);
	{
	Declare_entry(mercury__set__singleton_set_2_1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__code_gen__generate_semi_epilog_3_0_i1009,
		STATIC(mercury__code_gen__generate_semi_epilog_3_0));
	}
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i1009);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_epilog_3_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_semi_epilog_3_0_i18);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(7);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	r8 = ((Integer) detstackvar(6) + ((Integer) 1));
	r6 = (Integer) r8;
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(r11, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r12, mktag(0), ((Integer) 1));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r8;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("restore the success ip", 22);
	field(mktag(3), (Integer) r11, ((Integer) 2)) = (Integer) r12;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__code_gen__generate_semi_epilog_3_0_i21);
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i18);
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i21);
	if (((Integer) r6 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_semi_epilog_3_0_i22);
	r6 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_25);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	tag_incr_hp(r10, mktag(2), ((Integer) 2));
	tag_incr_hp(r11, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_21);
	field(mktag(2), (Integer) r11, ((Integer) 1)) = (Integer) r4;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_34);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(2), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(2), (Integer) r11, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r10, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r10, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r11, mktag(2), ((Integer) 2));
	tag_incr_hp(r12, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r12, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_29);
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(2), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(2), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_21);
	field(mktag(2), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(2), (Integer) r12, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_39);
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__code_gen__generate_semi_epilog_3_0_i22);
	r8 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_25);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	tag_incr_hp(r10, mktag(2), ((Integer) 2));
	tag_incr_hp(r11, mktag(2), ((Integer) 2));
	tag_incr_hp(r12, mktag(2), ((Integer) 2));
	tag_incr_hp(r13, mktag(2), ((Integer) 2));
	tag_incr_hp(r14, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r14, ((Integer) 0)) = (Integer) r7;
	tag_incr_hp(r15, mktag(1), ((Integer) 1));
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	tag_incr_hp(r17, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	field(mktag(2), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_21);
	field(mktag(2), (Integer) r12, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_34);
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r17, ((Integer) 1)) = string_const("Deallocate stack frame", 22);
	field(mktag(2), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(2), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(2), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(2), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(2), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r17, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r11, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r11, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r12, mktag(2), ((Integer) 2));
	tag_incr_hp(r13, mktag(2), ((Integer) 2));
	tag_incr_hp(r14, mktag(2), ((Integer) 2));
	tag_incr_hp(r15, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r15, ((Integer) 0)) = (Integer) r7;
	tag_incr_hp(r16, mktag(1), ((Integer) 1));
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	tag_incr_hp(r18, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r18, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 16);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_29);
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(2), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(2), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(2), (Integer) r12, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_21);
	field(mktag(2), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(2), (Integer) r13, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(2), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_39);
	field(mktag(2), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	field(mktag(2), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(0), (Integer) r18, ((Integer) 1)) = string_const("Deallocate stack frame", 22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module13)
	init_entry(mercury__code_gen__generate_non_prolog_4_0);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i2);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i3);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i4);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i5);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i6);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i7);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i8);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i9);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i10);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i11);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i12);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i13);
	init_label(mercury__code_gen__generate_non_prolog_4_0_i14);
BEGIN_CODE

/* code for predicate 'code_gen__generate_non_prolog'/4 in mode 0 */
Define_static(mercury__code_gen__generate_non_prolog_4_0);
	incr_sp_push_msg(6, "code_gen__generate_non_prolog");
	detstackvar(6) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__get_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i2,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_varset_3_0);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i3,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_aux__explain_stack_slots_3_0);
	call_localret(ENTRY(mercury__code_aux__explain_stack_slots_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i4,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__get_pred_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i5,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_proc_id_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i6,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i7,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i8,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__code_util__make_local_entry_label_5_0);
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_gen__generate_non_prolog_4_0_i9,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(detstackvar(2), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) detstackvar(2), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("Procedure entry point", 21);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i10,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_module__predicate_arity_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_arity_3_0),
		mercury__code_gen__generate_non_prolog_4_0_i11,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__code_gen__generate_non_prolog_4_0_i12,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = string_const("/", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__code_gen__generate_non_prolog_4_0_i13,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__code_gen__generate_non_prolog_4_0_i14,
		STATIC(mercury__code_gen__generate_non_prolog_4_0));
	}
Define_label(mercury__code_gen__generate_non_prolog_4_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_prolog_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_13);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_17);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("Nondet stackframe", 17);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(1);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module14)
	init_entry(mercury__code_gen__generate_non_epilog_3_0);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i2);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i3);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i4);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i5);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i8);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i7);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i10);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i11);
	init_label(mercury__code_gen__generate_non_epilog_3_0_i12);
BEGIN_CODE

/* code for predicate 'code_gen__generate_non_epilog'/3 in mode 0 */
Define_static(mercury__code_gen__generate_non_epilog_3_0);
	incr_sp_push_msg(5, "code_gen__generate_non_epilog");
	detstackvar(5) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_non_epilog_3_0_i2,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_arginfo_3_0);
	call_localret(ENTRY(mercury__code_info__get_arginfo_3_0),
		mercury__code_gen__generate_non_epilog_3_0_i3,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_headvars_3_0);
	call_localret(ENTRY(mercury__code_info__get_headvars_3_0),
		mercury__code_gen__generate_non_epilog_3_0_i4,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	detstackvar(4) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__code_gen__generate_non_epilog_3_0_i5,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__instmap__is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__code_gen__generate_non_epilog_3_0_i8,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_non_epilog_3_0_i7);
	r2 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__code_gen__generate_non_epilog_3_0_i11);
Define_label(mercury__code_gen__generate_non_epilog_3_0_i7);
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__code_gen__generate_non_epilog_3_0_i10,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
Define_label(mercury__code_gen__generate_non_epilog_3_0_i11);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
		call_localret(STATIC(mercury__code_gen__output_args_2_0),
		mercury__code_gen__generate_non_epilog_3_0_i12,
		STATIC(mercury__code_gen__generate_non_epilog_3_0));
	}
Define_label(mercury__code_gen__generate_non_epilog_3_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_epilog_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_25);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_29);
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_gen__common_43);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module15)
	init_entry(mercury__code_gen__generate_goals_5_0);
	init_label(mercury__code_gen__generate_goals_5_0_i4);
	init_label(mercury__code_gen__generate_goals_5_0_i5);
	init_label(mercury__code_gen__generate_goals_5_0_i8);
	init_label(mercury__code_gen__generate_goals_5_0_i7);
	init_label(mercury__code_gen__generate_goals_5_0_i10);
	init_label(mercury__code_gen__generate_goals_5_0_i1003);
BEGIN_CODE

/* code for predicate 'code_gen__generate_goals'/5 in mode 0 */
Define_static(mercury__code_gen__generate_goals_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_goals_5_0_i1003);
	incr_sp_push_msg(5, "code_gen__generate_goals");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_goals_5_0_i4,
		STATIC(mercury__code_gen__generate_goals_5_0));
	}
	}
Define_label(mercury__code_gen__generate_goals_5_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_goals_5_0_i5,
		STATIC(mercury__code_gen__generate_goals_5_0));
	}
Define_label(mercury__code_gen__generate_goals_5_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	detstackvar(4) = (Integer) r2;
	{
	Declare_entry(mercury__instmap__is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__code_gen__generate_goals_5_0_i8,
		STATIC(mercury__code_gen__generate_goals_5_0));
	}
Define_label(mercury__code_gen__generate_goals_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_goals_5_0_i7);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_goals_5_0_i7);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	localcall(mercury__code_gen__generate_goals_5_0,
		LABEL(mercury__code_gen__generate_goals_5_0_i10),
		STATIC(mercury__code_gen__generate_goals_5_0));
Define_label(mercury__code_gen__generate_goals_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_goals_5_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module16)
	init_entry(mercury__code_gen__generate_det_goal_2_5_0);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1030);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1029);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1014);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i10);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i14);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i23);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i24);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i26);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i28);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i30);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i31);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i32);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1028);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i37);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i42);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i41);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i45);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i39);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1020);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1021);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1022);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1023);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1024);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1025);
	init_label(mercury__code_gen__generate_det_goal_2_5_0_i1026);
BEGIN_CODE

/* code for predicate 'code_gen__generate_det_goal_2'/5 in mode 0 */
Define_static(mercury__code_gen__generate_det_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1028);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1020) AND
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1030) AND
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1023) AND
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1024) AND
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1029) AND
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1025) AND
		LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1026));
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1030);
	incr_sp_push_msg(5, "code_gen__generate_det_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1014);
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1029);
	incr_sp_push_msg(5, "code_gen__generate_det_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i23);
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1014);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i10);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1021);
	r1 = string_const("generate_det_goal_2: cannot have det simple_test", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i10);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i14);
	r5 = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__unify_gen__generate_construction_7_0);
	tailcall(ENTRY(mercury__unify_gen__generate_construction_7_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i1022);
	r5 = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__unify_gen__generate_det_deconstruction_7_0);
	tailcall(ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i23);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__code_gen__generate_det_goal_2_5_0_i24,
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_goal_2_5_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i26);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__code_gen__generate_goal_5_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i26);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i28);
	r1 = string_const("semidet model in det context", 28);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i28);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__generate_det_pre_commit_3_0);
	call_localret(ENTRY(mercury__code_info__generate_det_pre_commit_3_0),
		mercury__code_gen__generate_det_goal_2_5_0_i30,
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_goal_2_5_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_det_goal_2_5_0_i31,
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_goal_2_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__generate_det_commit_3_0);
	call_localret(ENTRY(mercury__code_info__generate_det_commit_3_0),
		mercury__code_gen__generate_det_goal_2_5_0_i32,
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i32);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1028);
	incr_sp_push_msg(5, "code_gen__generate_det_goal_2");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i37);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__code_gen__generate_goals_5_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i37);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i39);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__code_gen__generate_det_goal_2_5_0_i42,
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i42);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_goal_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_det_goal_2_5_0_i41);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_det_builtin_6_0);
	tailcall(ENTRY(mercury__call_gen__generate_det_builtin_6_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i41);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__set_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__set_succip_used_3_0),
		mercury__code_gen__generate_det_goal_2_5_0_i45,
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i45);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_det_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_det_call_6_0);
	tailcall(ENTRY(mercury__call_gen__generate_det_call_6_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i39);
	r7 = (Integer) r3;
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	r5 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	r6 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_higher_order_call_9_0);
	tailcall(ENTRY(mercury__call_gen__generate_higher_order_call_9_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1020);
	r6 = (Integer) r2;
	r7 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 0);
	{
	Declare_entry(mercury__switch_gen__generate_switch_9_0);
	tailcall(ENTRY(mercury__switch_gen__generate_switch_9_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1021);
	r1 = string_const("code_gen__generate_det_goal_2 - complicated unify", 49);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1022);
	r1 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__unify_gen__generate_assignment_5_0);
	tailcall(ENTRY(mercury__unify_gen__generate_assignment_5_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1023);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__disj_gen__generate_det_disj_5_0);
	tailcall(ENTRY(mercury__disj_gen__generate_det_disj_5_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1024);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) 0);
	tailcall(STATIC(mercury__code_gen__generate_negation_5_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1025);
	r5 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	Declare_entry(mercury__ite_gen__generate_det_ite_7_0);
	tailcall(ENTRY(mercury__ite_gen__generate_det_ite_7_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_det_goal_2_5_0_i1026);
	r8 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 6));
	r1 = ((Integer) 0);
	tailcall(STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0),
		STATIC(mercury__code_gen__generate_det_goal_2_5_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module17)
	init_entry(mercury__code_gen__make_c_arg_list_3_0);
	init_label(mercury__code_gen__make_c_arg_list_3_0_i2);
BEGIN_CODE

/* code for predicate 'make_c_arg_list'/3 in mode 0 */
Define_static(mercury__code_gen__make_c_arg_list_3_0);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(1, "make_c_arg_list");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__code_gen__make_c_arg_list_2_4_0),
		mercury__code_gen__make_c_arg_list_3_0_i2,
		STATIC(mercury__code_gen__make_c_arg_list_3_0));
Define_label(mercury__code_gen__make_c_arg_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__make_c_arg_list_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_code_gen__base_type_info_c_arg_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__code_gen__make_c_arg_list_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module18)
	init_entry(mercury__code_gen__make_c_arg_list_2_4_0);
	init_label(mercury__code_gen__make_c_arg_list_2_4_0_i1009);
	init_label(mercury__code_gen__make_c_arg_list_2_4_0_i1007);
	init_label(mercury__code_gen__make_c_arg_list_2_4_0_i1008);
BEGIN_CODE

/* code for predicate 'make_c_arg_list_2'/4 in mode 0 */
Define_static(mercury__code_gen__make_c_arg_list_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__make_c_arg_list_2_4_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__make_c_arg_list_2_4_0_i1007);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r6 = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	localtailcall(mercury__code_gen__make_c_arg_list_2_4_0,
		STATIC(mercury__code_gen__make_c_arg_list_2_4_0));
	}
Define_label(mercury__code_gen__make_c_arg_list_2_4_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__make_c_arg_list_2_4_0_i1008);
	r1 = string_const("code_gen:make_c_arg_list_2 - length mismatch", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__code_gen__make_c_arg_list_2_4_0));
	}
Define_label(mercury__code_gen__make_c_arg_list_2_4_0_i1007);
	r1 = string_const("code_gen:make_c_arg_list_2 - length mismatch", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__code_gen__make_c_arg_list_2_4_0));
	}
Define_label(mercury__code_gen__make_c_arg_list_2_4_0_i1008);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module19)
	init_entry(mercury__code_gen__get_c_arg_list_vars_2_0);
	init_label(mercury__code_gen__get_c_arg_list_vars_2_0_i3);
	init_label(mercury__code_gen__get_c_arg_list_vars_2_0_i4);
	init_label(mercury__code_gen__get_c_arg_list_vars_2_0_i1);
BEGIN_CODE

/* code for predicate 'get_c_arg_list_vars'/2 in mode 0 */
Define_static(mercury__code_gen__get_c_arg_list_vars_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__get_c_arg_list_vars_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__code_gen__get_c_arg_list_vars_2_0_i3);
	while (1) {
	incr_sp_push_msg(1, "get_c_arg_list_vars");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__code_gen__get_c_arg_list_vars_2_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__code_gen__get_c_arg_list_vars_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module20)
	init_entry(mercury__code_gen__pragma_select_out_args_2_0);
	init_label(mercury__code_gen__pragma_select_out_args_2_0_i7);
	init_label(mercury__code_gen__pragma_select_out_args_2_0_i8);
	init_label(mercury__code_gen__pragma_select_out_args_2_0_i3);
	init_label(mercury__code_gen__pragma_select_out_args_2_0_i1);
BEGIN_CODE

/* code for predicate 'pragma_select_out_args'/2 in mode 0 */
Define_static(mercury__code_gen__pragma_select_out_args_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__pragma_select_out_args_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__code_gen__pragma_select_out_args_2_0_i7);
	while (1) {
	incr_sp_push_msg(2, "pragma_select_out_args");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__code_gen__pragma_select_out_args_2_0_i8);
	if (((Integer) detstackvar(2) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__pragma_select_out_args_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__code_gen__pragma_select_out_args_2_0_i3);
	decr_sp_pop_msg(2);
	if (((Integer) sp > (Integer) r3))
		GOTO_LABEL(mercury__code_gen__pragma_select_out_args_2_0_i8);
	proceed();
Define_label(mercury__code_gen__pragma_select_out_args_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module21)
	init_entry(mercury__code_gen__pragma_select_in_args_2_0);
	init_label(mercury__code_gen__pragma_select_in_args_2_0_i7);
	init_label(mercury__code_gen__pragma_select_in_args_2_0_i8);
	init_label(mercury__code_gen__pragma_select_in_args_2_0_i3);
	init_label(mercury__code_gen__pragma_select_in_args_2_0_i1);
BEGIN_CODE

/* code for predicate 'pragma_select_in_args'/2 in mode 0 */
Define_static(mercury__code_gen__pragma_select_in_args_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__pragma_select_in_args_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__code_gen__pragma_select_in_args_2_0_i7);
	while (1) {
	incr_sp_push_msg(2, "pragma_select_in_args");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__code_gen__pragma_select_in_args_2_0_i8);
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__pragma_select_in_args_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__code_gen__pragma_select_in_args_2_0_i3);
	decr_sp_pop_msg(2);
	if (((Integer) sp > (Integer) r3))
		GOTO_LABEL(mercury__code_gen__pragma_select_in_args_2_0_i8);
	proceed();
Define_label(mercury__code_gen__pragma_select_in_args_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module22)
	init_entry(mercury__code_gen__make_pragma_decls_4_0);
	init_label(mercury__code_gen__make_pragma_decls_4_0_i7);
	init_label(mercury__code_gen__make_pragma_decls_4_0_i8);
	init_label(mercury__code_gen__make_pragma_decls_4_0_i1004);
	init_label(mercury__code_gen__make_pragma_decls_4_0_i1006);
BEGIN_CODE

/* code for predicate 'make_pragma_decls'/4 in mode 0 */
Define_static(mercury__code_gen__make_pragma_decls_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__make_pragma_decls_4_0_i1004);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	if (((Integer) tempr2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__make_pragma_decls_4_0_i1006);
	incr_sp_push_msg(3, "make_pragma_decls");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__code_gen__make_pragma_decls_4_0_i7,
		STATIC(mercury__code_gen__make_pragma_decls_4_0));
	}
	}
Define_label(mercury__code_gen__make_pragma_decls_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__make_pragma_decls_4_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	localcall(mercury__code_gen__make_pragma_decls_4_0,
		LABEL(mercury__code_gen__make_pragma_decls_4_0_i8),
		STATIC(mercury__code_gen__make_pragma_decls_4_0));
Define_label(mercury__code_gen__make_pragma_decls_4_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__make_pragma_decls_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_gen__make_pragma_decls_4_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__code_gen__make_pragma_decls_4_0_i1006);
	r1 = (Integer) r3;
	localtailcall(mercury__code_gen__make_pragma_decls_4_0,
		STATIC(mercury__code_gen__make_pragma_decls_4_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module23)
	init_entry(mercury__code_gen__get_pragma_input_vars_5_0);
	init_label(mercury__code_gen__get_pragma_input_vars_5_0_i7);
	init_label(mercury__code_gen__get_pragma_input_vars_5_0_i8);
	init_label(mercury__code_gen__get_pragma_input_vars_5_0_i9);
	init_label(mercury__code_gen__get_pragma_input_vars_5_0_i1005);
	init_label(mercury__code_gen__get_pragma_input_vars_5_0_i1007);
BEGIN_CODE

/* code for predicate 'get_pragma_input_vars'/5 in mode 0 */
Define_static(mercury__code_gen__get_pragma_input_vars_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__get_pragma_input_vars_5_0_i1005);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	if (((Integer) tempr2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__get_pragma_input_vars_5_0_i1007);
	incr_sp_push_msg(4, "get_pragma_input_vars");
	detstackvar(4) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__code_gen__get_pragma_input_vars_5_0_i7,
		STATIC(mercury__code_gen__get_pragma_input_vars_5_0));
	}
	}
Define_label(mercury__code_gen__get_pragma_input_vars_5_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__get_pragma_input_vars_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__code_gen__get_pragma_input_vars_5_0_i8,
		STATIC(mercury__code_gen__get_pragma_input_vars_5_0));
	}
Define_label(mercury__code_gen__get_pragma_input_vars_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__get_pragma_input_vars_5_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	r2 = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__code_gen__get_pragma_input_vars_5_0,
		LABEL(mercury__code_gen__get_pragma_input_vars_5_0_i9),
		STATIC(mercury__code_gen__get_pragma_input_vars_5_0));
	}
Define_label(mercury__code_gen__get_pragma_input_vars_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__get_pragma_input_vars_5_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_gen__get_pragma_input_vars_5_0_i1005);
	r3 = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__code_gen__get_pragma_input_vars_5_0_i1007);
	r1 = (Integer) r3;
	localtailcall(mercury__code_gen__get_pragma_input_vars_5_0,
		STATIC(mercury__code_gen__get_pragma_input_vars_5_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module24)
	init_entry(mercury__code_gen__pragma_acquire_regs_4_0);
	init_label(mercury__code_gen__pragma_acquire_regs_4_0_i4);
	init_label(mercury__code_gen__pragma_acquire_regs_4_0_i5);
	init_label(mercury__code_gen__pragma_acquire_regs_4_0_i1002);
BEGIN_CODE

/* code for predicate 'pragma_acquire_regs'/4 in mode 0 */
Define_static(mercury__code_gen__pragma_acquire_regs_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__pragma_acquire_regs_4_0_i1002);
	incr_sp_push_msg(2, "pragma_acquire_regs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__code_gen__pragma_acquire_regs_4_0_i4,
		STATIC(mercury__code_gen__pragma_acquire_regs_4_0));
	}
Define_label(mercury__code_gen__pragma_acquire_regs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__pragma_acquire_regs_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__code_gen__pragma_acquire_regs_4_0,
		LABEL(mercury__code_gen__pragma_acquire_regs_4_0_i5),
		STATIC(mercury__code_gen__pragma_acquire_regs_4_0));
Define_label(mercury__code_gen__pragma_acquire_regs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__pragma_acquire_regs_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_gen__pragma_acquire_regs_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module25)
	init_entry(mercury__code_gen__place_pragma_output_args_in_regs_5_0);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i9);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i10);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i11);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i12);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i6);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i13);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1002);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1001);
	init_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i17);
BEGIN_CODE

/* code for predicate 'place_pragma_output_args_in_regs'/5 in mode 0 */
Define_static(mercury__code_gen__place_pragma_output_args_in_regs_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1001);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1002);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr1 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	incr_sp_push_msg(7, "place_pragma_output_args_in_regs");
	detstackvar(7) = (Integer) succip;
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i6);
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__code_gen__place_pragma_output_args_in_regs_5_0_i9,
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__code_gen__place_pragma_output_args_in_regs_5_0_i10,
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__set_var_location_4_0);
	call_localret(ENTRY(mercury__code_info__set_var_location_4_0),
		mercury__code_gen__place_pragma_output_args_in_regs_5_0_i11,
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	localcall(mercury__code_gen__place_pragma_output_args_in_regs_5_0,
		LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i12),
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i6);
	r1 = string_const("code_gen:place_pragma_output_args_in_regs", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__place_pragma_output_args_in_regs_5_0_i13,
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1002);
	incr_sp_push_msg(7, "place_pragma_output_args_in_regs");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = string_const("place_pragma_output_args_in_regs: list length mismatch", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__place_pragma_output_args_in_regs_5_0_i13,
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i1001);
	incr_sp_push_msg(7, "place_pragma_output_args_in_regs");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i17);
	detstackvar(1) = (Integer) r3;
	r1 = string_const("place_pragma_output_args_in_regs: list length mismatch", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__place_pragma_output_args_in_regs_5_0_i13,
		STATIC(mercury__code_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__code_gen__place_pragma_output_args_in_regs_5_0_i17);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module26)
	init_entry(mercury__code_gen__generate_semi_goal_2_5_0);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1030);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1029);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i7);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i10);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i14);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i23);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i24);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i26);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i28);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i30);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i31);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i32);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1028);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i37);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i42);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i41);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i45);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i39);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1020);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1021);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1022);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1023);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1024);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1025);
	init_label(mercury__code_gen__generate_semi_goal_2_5_0_i1026);
BEGIN_CODE

/* code for predicate 'code_gen__generate_semi_goal_2'/5 in mode 0 */
Define_static(mercury__code_gen__generate_semi_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1028);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1020) AND
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1030) AND
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1023) AND
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1024) AND
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1029) AND
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1025) AND
		LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1026));
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1030);
	incr_sp_push_msg(5, "code_gen__generate_semi_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i7);
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1029);
	incr_sp_push_msg(5, "code_gen__generate_semi_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i23);
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i7);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1021);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	{
	Declare_entry(mercury__unify_gen__generate_test_5_0);
	tailcall(ENTRY(mercury__unify_gen__generate_test_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i10);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i14);
	r5 = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__unify_gen__generate_construction_7_0);
	tailcall(ENTRY(mercury__unify_gen__generate_construction_7_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i1022);
	r5 = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__unify_gen__generate_semi_deconstruction_7_0);
	tailcall(ENTRY(mercury__unify_gen__generate_semi_deconstruction_7_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i23);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__code_gen__generate_semi_goal_2_5_0_i24,
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_goal_2_5_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i26);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__code_gen__generate_goal_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i26);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i28);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__code_gen__generate_goal_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i28);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__generate_semi_pre_commit_4_0);
	call_localret(ENTRY(mercury__code_info__generate_semi_pre_commit_4_0),
		mercury__code_gen__generate_semi_goal_2_5_0_i30,
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_goal_2_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 2);
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_semi_goal_2_5_0_i31,
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_goal_2_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__generate_semi_commit_4_0);
	call_localret(ENTRY(mercury__code_info__generate_semi_commit_4_0),
		mercury__code_gen__generate_semi_goal_2_5_0_i32,
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i32);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1028);
	incr_sp_push_msg(5, "code_gen__generate_semi_goal_2");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i37);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__code_gen__generate_goals_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i37);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i39);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__code_gen__generate_semi_goal_2_5_0_i42,
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i42);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_goal_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_semi_goal_2_5_0_i41);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_semidet_builtin_6_0);
	tailcall(ENTRY(mercury__call_gen__generate_semidet_builtin_6_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i41);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__set_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__set_succip_used_3_0),
		mercury__code_gen__generate_semi_goal_2_5_0_i45,
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i45);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_semi_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_semidet_call_6_0);
	tailcall(ENTRY(mercury__call_gen__generate_semidet_call_6_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i39);
	r7 = (Integer) r3;
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	r5 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	r6 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_higher_order_call_9_0);
	tailcall(ENTRY(mercury__call_gen__generate_higher_order_call_9_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1020);
	r6 = (Integer) r2;
	r7 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__switch_gen__generate_switch_9_0);
	tailcall(ENTRY(mercury__switch_gen__generate_switch_9_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1021);
	r1 = string_const("code_gen__generate_semi_goal_2 - complicated_unify", 50);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1022);
	r1 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__unify_gen__generate_assignment_5_0);
	tailcall(ENTRY(mercury__unify_gen__generate_assignment_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1023);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__disj_gen__generate_semi_disj_5_0);
	tailcall(ENTRY(mercury__disj_gen__generate_semi_disj_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1024);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) 1);
	tailcall(STATIC(mercury__code_gen__generate_negation_5_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1025);
	r5 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	Declare_entry(mercury__ite_gen__generate_semidet_ite_7_0);
	tailcall(ENTRY(mercury__ite_gen__generate_semidet_ite_7_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_semi_goal_2_5_0_i1026);
	r8 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 6));
	r1 = ((Integer) 1);
	tailcall(STATIC(mercury__code_gen__generate_pragma_c_code__ua10000_11_0),
		STATIC(mercury__code_gen__generate_semi_goal_2_5_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module27)
	init_entry(mercury__code_gen__generate_negation_5_0);
	init_label(mercury__code_gen__generate_negation_5_0_i2);
	init_label(mercury__code_gen__generate_negation_5_0_i3);
	init_label(mercury__code_gen__generate_negation_5_0_i6);
	init_label(mercury__code_gen__generate_negation_5_0_i7);
	init_label(mercury__code_gen__generate_negation_5_0_i8);
	init_label(mercury__code_gen__generate_negation_5_0_i9);
	init_label(mercury__code_gen__generate_negation_5_0_i15);
	init_label(mercury__code_gen__generate_negation_5_0_i17);
	init_label(mercury__code_gen__generate_negation_5_0_i18);
	init_label(mercury__code_gen__generate_negation_5_0_i20);
	init_label(mercury__code_gen__generate_negation_5_0_i21);
	init_label(mercury__code_gen__generate_negation_5_0_i22);
	init_label(mercury__code_gen__generate_negation_5_0_i23);
	init_label(mercury__code_gen__generate_negation_5_0_i24);
	init_label(mercury__code_gen__generate_negation_5_0_i30);
	init_label(mercury__code_gen__generate_negation_5_0_i37);
	init_label(mercury__code_gen__generate_negation_5_0_i1063);
	init_label(mercury__code_gen__generate_negation_5_0_i11);
	init_label(mercury__code_gen__generate_negation_5_0_i10);
	init_label(mercury__code_gen__generate_negation_5_0_i39);
	init_label(mercury__code_gen__generate_negation_5_0_i40);
	init_label(mercury__code_gen__generate_negation_5_0_i41);
BEGIN_CODE

/* code for predicate 'code_gen__generate_negation'/5 in mode 0 */
Define_static(mercury__code_gen__generate_negation_5_0);
	incr_sp_push_msg(12, "code_gen__generate_negation");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__code_gen__generate_negation_5_0_i2,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i3);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i7);
Define_label(mercury__code_gen__generate_negation_5_0_i3);
	r1 = string_const("negated goal has no resume point", 32);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_negation_5_0_i6,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
Define_label(mercury__code_gen__generate_negation_5_0_i7);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__code_info__push_resume_point_vars_3_0);
	call_localret(ENTRY(mercury__code_info__push_resume_point_vars_3_0),
		mercury__code_gen__generate_negation_5_0_i8,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_resume_point_3_0),
		mercury__code_gen__generate_negation_5_0_i9,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i10);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i10);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i10);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i10);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i10);
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 2));
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_info__can_generate_direct_branch_3_0);
	call_localret(ENTRY(mercury__code_info__can_generate_direct_branch_3_0),
		mercury__code_gen__generate_negation_5_0_i15,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
	}
Define_label(mercury__code_gen__generate_negation_5_0_i15);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i11);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__code_gen__generate_negation_5_0_i17,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	detstackvar(9) = (Integer) r2;
	r2 = ((Integer) 114);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_1);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__code_gen__generate_negation_5_0_i18,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i11);
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_aux__pre_goal_update_4_0);
	call_localret(ENTRY(mercury__code_aux__pre_goal_update_4_0),
		mercury__code_gen__generate_negation_5_0_i20,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i20);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__code_gen__generate_negation_5_0_i21,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i21);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) tempr1;
	detstackvar(9) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__code_gen__generate_negation_5_0_i22,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
	}
Define_label(mercury__code_gen__generate_negation_5_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) tempr1;
	detstackvar(10) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__code_gen__generate_negation_5_0_i23,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
	}
Define_label(mercury__code_gen__generate_negation_5_0_i23);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i24);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i24);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i24);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i24);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) detstackvar(8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 15);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(10);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("test inequality", 15);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i37);
	}
Define_label(mercury__code_gen__generate_negation_5_0_i24);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i30);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i30);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i30);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i30);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) detstackvar(8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 29);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(10);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("test inequality", 15);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i37);
	}
Define_label(mercury__code_gen__generate_negation_5_0_i30);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) detstackvar(8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 12);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(10);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("test inequality", 15);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	}
Define_label(mercury__code_gen__generate_negation_5_0_i37);
	detstackvar(7) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	{
	Declare_entry(mercury__code_aux__post_goal_update_3_0);
	call_localret(ENTRY(mercury__code_aux__post_goal_update_3_0),
		mercury__code_gen__generate_negation_5_0_i1063,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i1063);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__code_gen__generate_negation_5_0_i40);
Define_label(mercury__code_gen__generate_negation_5_0_i11);
	r2 = (Integer) detstackvar(3);
Define_label(mercury__code_gen__generate_negation_5_0_i10);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__code_gen__generate_negation_general_7_0),
		mercury__code_gen__generate_negation_5_0_i39,
		STATIC(mercury__code_gen__generate_negation_5_0));
Define_label(mercury__code_gen__generate_negation_5_0_i39);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r3;
Define_label(mercury__code_gen__generate_negation_5_0_i40);
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pop_resume_point_vars_2_0);
	call_localret(ENTRY(mercury__code_info__pop_resume_point_vars_2_0),
		mercury__code_gen__generate_negation_5_0_i41,
		STATIC(mercury__code_gen__generate_negation_5_0));
	}
Define_label(mercury__code_gen__generate_negation_5_0_i41);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module28)
	init_entry(mercury__code_gen__generate_negation_general_7_0);
	init_label(mercury__code_gen__generate_negation_general_7_0_i2);
	init_label(mercury__code_gen__generate_negation_general_7_0_i3);
	init_label(mercury__code_gen__generate_negation_general_7_0_i6);
	init_label(mercury__code_gen__generate_negation_general_7_0_i8);
	init_label(mercury__code_gen__generate_negation_general_7_0_i5);
	init_label(mercury__code_gen__generate_negation_general_7_0_i10);
	init_label(mercury__code_gen__generate_negation_general_7_0_i11);
	init_label(mercury__code_gen__generate_negation_general_7_0_i12);
	init_label(mercury__code_gen__generate_negation_general_7_0_i13);
	init_label(mercury__code_gen__generate_negation_general_7_0_i16);
	init_label(mercury__code_gen__generate_negation_general_7_0_i17);
	init_label(mercury__code_gen__generate_negation_general_7_0_i18);
	init_label(mercury__code_gen__generate_negation_general_7_0_i19);
	init_label(mercury__code_gen__generate_negation_general_7_0_i20);
	init_label(mercury__code_gen__generate_negation_general_7_0_i21);
	init_label(mercury__code_gen__generate_negation_general_7_0_i22);
BEGIN_CODE

/* code for predicate 'code_gen__generate_negation_general'/7 in mode 0 */
Define_static(mercury__code_gen__generate_negation_general_7_0);
	incr_sp_push_msg(9, "code_gen__generate_negation_general");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = ((Integer) 1);
	r4 = ((Integer) 1);
	{
	Declare_entry(mercury__code_info__make_known_failure_cont_8_0);
	call_localret(ENTRY(mercury__code_info__make_known_failure_cont_8_0),
		mercury__code_gen__generate_negation_general_7_0_i2,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	r1 = (Integer) r3;
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__code_gen__generate_negation_general_7_0_i3,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	detstackvar(8) = (Integer) r2;
	r2 = ((Integer) 69);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_1);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__code_gen__generate_negation_general_7_0_i6,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_negation_general_7_0_i5);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_util__goal_may_allocate_heap_1_0);
	call_localret(ENTRY(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__code_gen__generate_negation_general_7_0_i8,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_negation_general_7_0_i5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_negation_general_7_0_i10);
Define_label(mercury__code_gen__generate_negation_general_7_0_i5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__code_gen__generate_negation_general_7_0_i10);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_hp_4_0),
		mercury__code_gen__generate_negation_general_7_0_i11,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	r3 = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_negation_general_7_0_i12,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	if (((Integer) detstackvar(1) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_gen__generate_negation_general_7_0_i13);
	r5 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__code_gen__generate_negation_general_7_0_i20);
Define_label(mercury__code_gen__generate_negation_general_7_0_i13);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__code_gen__generate_negation_general_7_0_i16,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pop_failure_cont_2_0);
	call_localret(ENTRY(mercury__code_info__pop_failure_cont_2_0),
		mercury__code_gen__generate_negation_general_7_0_i17,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__code_gen__generate_negation_general_7_0_i18,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	r3 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__code_gen__generate_negation_general_7_0_i19,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i19);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
Define_label(mercury__code_gen__generate_negation_general_7_0_i20);
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	{
	Declare_entry(mercury__code_info__restore_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__restore_failure_cont_3_0),
		mercury__code_gen__generate_negation_general_7_0_i21,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i21);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__maybe_restore_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_hp_4_0),
		mercury__code_gen__generate_negation_general_7_0_i22,
		STATIC(mercury__code_gen__generate_negation_general_7_0));
	}
Define_label(mercury__code_gen__generate_negation_general_7_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_negation_general_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__code_gen_module29)
	init_entry(mercury__code_gen__generate_non_goal_2_5_0);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1008);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1007);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1006);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i7);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i8);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i11);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i13);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i14);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1005);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i20);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i25);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i27);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i24);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i28);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i22);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1000);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1001);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1002);
	init_label(mercury__code_gen__generate_non_goal_2_5_0_i1003);
BEGIN_CODE

/* code for predicate 'code_gen__generate_non_goal_2'/5 in mode 0 */
Define_static(mercury__code_gen__generate_non_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1005);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1000) AND
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1008) AND
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1001) AND
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1007) AND
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1006) AND
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1002) AND
		LABEL(mercury__code_gen__generate_non_goal_2_5_0_i1003));
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1008);
	incr_sp_push_msg(5, "code_gen__generate_non_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i7);
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1007);
	incr_sp_push_msg(5, "code_gen__generate_non_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i11);
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1006);
	incr_sp_push_msg(5, "code_gen__generate_non_goal_2");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i13);
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i7);
	detstackvar(1) = (Integer) r3;
	r1 = string_const("Cannot have a nondet unification.", 33);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_non_goal_2_5_0_i8,
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_goal_2_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i11);
	detstackvar(1) = (Integer) r3;
	r1 = string_const("Cannot have a nondet negation.", 30);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_non_goal_2_5_0_i8,
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i13);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__code_gen__generate_non_goal_2_5_0_i14,
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_goal_2_5_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__code_gen__generate_goal_5_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1005);
	incr_sp_push_msg(5, "code_gen__generate_non_goal_2");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i20);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__code_gen__generate_goals_5_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i20);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i22);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__code_gen__generate_non_goal_2_5_0_i25,
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_goal_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_gen__generate_non_goal_2_5_0_i24);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__call_gen__generate_nondet_builtin_6_0);
	call_localret(ENTRY(mercury__call_gen__generate_nondet_builtin_6_0),
		mercury__code_gen__generate_non_goal_2_5_0_i27,
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_goal_2_5_0));
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i24);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__set_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__set_succip_used_3_0),
		mercury__code_gen__generate_non_goal_2_5_0_i28,
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_non_goal_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_nondet_call_6_0);
	tailcall(ENTRY(mercury__call_gen__generate_nondet_call_6_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i22);
	r7 = (Integer) r3;
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	r5 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	r6 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__call_gen__generate_higher_order_call_9_0);
	tailcall(ENTRY(mercury__call_gen__generate_higher_order_call_9_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1000);
	r6 = (Integer) r2;
	r7 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__switch_gen__generate_switch_9_0);
	tailcall(ENTRY(mercury__switch_gen__generate_switch_9_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1001);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__disj_gen__generate_non_disj_5_0);
	tailcall(ENTRY(mercury__disj_gen__generate_non_disj_5_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1002);
	r5 = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	Declare_entry(mercury__ite_gen__generate_nondet_ite_7_0);
	tailcall(ENTRY(mercury__ite_gen__generate_nondet_ite_7_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
	}
Define_label(mercury__code_gen__generate_non_goal_2_5_0_i1003);
	tailcall(STATIC(mercury__code_gen__generate_det_goal_2_5_0),
		STATIC(mercury__code_gen__generate_non_goal_2_5_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module30)
	init_entry(mercury__code_gen__add_saved_succip_3_0);
	init_label(mercury__code_gen__add_saved_succip_3_0_i1020);
	init_label(mercury__code_gen__add_saved_succip_3_0_i7);
	init_label(mercury__code_gen__add_saved_succip_3_0_i12);
	init_label(mercury__code_gen__add_saved_succip_3_0_i1019);
	init_label(mercury__code_gen__add_saved_succip_3_0_i13);
	init_label(mercury__code_gen__add_saved_succip_3_0_i17);
	init_label(mercury__code_gen__add_saved_succip_3_0_i18);
	init_label(mercury__code_gen__add_saved_succip_3_0_i1017);
BEGIN_CODE

/* code for predicate 'code_gen__add_saved_succip'/3 in mode 0 */
Define_static(mercury__code_gen__add_saved_succip_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i1017);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i1019);
	r6 = (Integer) field(mktag(2), (Integer) r5, ((Integer) 0));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i1020);
	r7 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r7) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i1020);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i1020);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i1019);
	incr_sp_push_msg(6, "code_gen__add_saved_succip");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i7);
Define_label(mercury__code_gen__add_saved_succip_3_0_i1020);
	incr_sp_push_msg(6, "code_gen__add_saved_succip");
	detstackvar(6) = (Integer) succip;
Define_label(mercury__code_gen__add_saved_succip_3_0_i7);
	detstackvar(4) = (Integer) r3;
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	detstackvar(1) = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) r6;
	detstackvar(3) = (Integer) r4;
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__code_gen__add_saved_succip_3_0_i12,
		STATIC(mercury__code_gen__add_saved_succip_3_0));
	}
Define_label(mercury__code_gen__add_saved_succip_3_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__add_saved_succip_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i17);
	}
Define_label(mercury__code_gen__add_saved_succip_3_0_i1019);
	incr_sp_push_msg(6, "code_gen__add_saved_succip");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i13);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i13);
	r1 = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	tag_incr_hp(r7, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 1));
	field(mktag(3), (Integer) r7, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 2));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 3));
	field(mktag(3), (Integer) r7, ((Integer) 4)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 4));
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r5, ((Integer) 3));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r9, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r7, ((Integer) 3)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i17);
	}
Define_label(mercury__code_gen__add_saved_succip_3_0_i13);
	r1 = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r4;
Define_label(mercury__code_gen__add_saved_succip_3_0_i17);
	detstackvar(5) = (Integer) r3;
	localcall(mercury__code_gen__add_saved_succip_3_0,
		LABEL(mercury__code_gen__add_saved_succip_3_0_i18),
		STATIC(mercury__code_gen__add_saved_succip_3_0));
Define_label(mercury__code_gen__add_saved_succip_3_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__add_saved_succip_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_gen__add_saved_succip_3_0_i1017);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module31)
	init_entry(mercury____Unify___code_gen__c_arg_0_0);
	init_label(mercury____Unify___code_gen__c_arg_0_0_i2);
	init_label(mercury____Unify___code_gen__c_arg_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___code_gen__c_arg_0_0);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___code_gen__c_arg_0_0_i2,
		STATIC(mercury____Unify___code_gen__c_arg_0_0));
	}
Define_label(mercury____Unify___code_gen__c_arg_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___code_gen__c_arg_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___code_gen__c_arg_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		STATIC(mercury____Unify___code_gen__c_arg_0_0));
	}
Define_label(mercury____Unify___code_gen__c_arg_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_gen_module32)
	init_entry(mercury____Index___code_gen__c_arg_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___code_gen__c_arg_0_0);
	tailcall(STATIC(mercury____Index___code_gen_c_arg_0__ua10000_2_0),
		STATIC(mercury____Index___code_gen__c_arg_0_0));
END_MODULE

BEGIN_MODULE(mercury__code_gen_module33)
	init_entry(mercury____Compare___code_gen__c_arg_0_0);
	init_label(mercury____Compare___code_gen__c_arg_0_0_i4);
	init_label(mercury____Compare___code_gen__c_arg_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___code_gen__c_arg_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___code_gen__c_arg_0_0_i4,
		STATIC(mercury____Compare___code_gen__c_arg_0_0));
	}
Define_label(mercury____Compare___code_gen__c_arg_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___code_gen__c_arg_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___code_gen__c_arg_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___code_gen__c_arg_0_0_i3);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		STATIC(mercury____Compare___code_gen__c_arg_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__code_gen_bunch_0(void)
{
	mercury__code_gen_module0();
	mercury__code_gen_module1();
	mercury__code_gen_module2();
	mercury__code_gen_module3();
	mercury__code_gen_module4();
	mercury__code_gen_module5();
	mercury__code_gen_module6();
	mercury__code_gen_module7();
	mercury__code_gen_module8();
	mercury__code_gen_module9();
	mercury__code_gen_module10();
	mercury__code_gen_module11();
	mercury__code_gen_module12();
	mercury__code_gen_module13();
	mercury__code_gen_module14();
	mercury__code_gen_module15();
	mercury__code_gen_module16();
	mercury__code_gen_module17();
	mercury__code_gen_module18();
	mercury__code_gen_module19();
	mercury__code_gen_module20();
	mercury__code_gen_module21();
	mercury__code_gen_module22();
	mercury__code_gen_module23();
	mercury__code_gen_module24();
	mercury__code_gen_module25();
	mercury__code_gen_module26();
	mercury__code_gen_module27();
	mercury__code_gen_module28();
	mercury__code_gen_module29();
	mercury__code_gen_module30();
	mercury__code_gen_module31();
	mercury__code_gen_module32();
	mercury__code_gen_module33();
}

#endif

void mercury__code_gen__init(void); /* suppress gcc warning */
void mercury__code_gen__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__code_gen_bunch_0();
#endif
}
