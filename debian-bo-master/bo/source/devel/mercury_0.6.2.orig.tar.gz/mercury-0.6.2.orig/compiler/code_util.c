/*
** Automatically generated from `code_util.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__code_util__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__code_util__predinfo_is_builtin__ua0_2_0);
Declare_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i2);
Declare_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i3);
Declare_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i4);
Declare_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i8);
Declare_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i5);
Define_extern_entry(mercury__code_util__make_entry_label_5_0);
Declare_label(mercury__code_util__make_entry_label_5_0_i2);
Declare_label(mercury__code_util__make_entry_label_5_0_i3);
Declare_label(mercury__code_util__make_entry_label_5_0_i9);
Declare_label(mercury__code_util__make_entry_label_5_0_i8);
Declare_label(mercury__code_util__make_entry_label_5_0_i11);
Declare_label(mercury__code_util__make_entry_label_5_0_i14);
Declare_label(mercury__code_util__make_entry_label_5_0_i5);
Declare_label(mercury__code_util__make_entry_label_5_0_i15);
Define_extern_entry(mercury__code_util__make_local_entry_label_5_0);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i2);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i3);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i4);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i10);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i9);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i12);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i7);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i16);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i6);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i1011);
Define_extern_entry(mercury__code_util__make_internal_label_5_0);
Declare_label(mercury__code_util__make_internal_label_5_0_i2);
Define_extern_entry(mercury__code_util__make_proc_label_4_0);
Declare_label(mercury__code_util__make_proc_label_4_0_i2);
Declare_label(mercury__code_util__make_proc_label_4_0_i3);
Declare_label(mercury__code_util__make_proc_label_4_0_i4);
Declare_label(mercury__code_util__make_proc_label_4_0_i7);
Declare_label(mercury__code_util__make_proc_label_4_0_i9);
Declare_label(mercury__code_util__make_proc_label_4_0_i12);
Declare_label(mercury__code_util__make_proc_label_4_0_i14);
Declare_label(mercury__code_util__make_proc_label_4_0_i1007);
Declare_label(mercury__code_util__make_proc_label_4_0_i16);
Declare_label(mercury__code_util__make_proc_label_4_0_i6);
Declare_label(mercury__code_util__make_proc_label_4_0_i19);
Declare_label(mercury__code_util__make_proc_label_4_0_i20);
Define_extern_entry(mercury__code_util__make_uni_label_4_0);
Declare_label(mercury__code_util__make_uni_label_4_0_i2);
Define_extern_entry(mercury__code_util__arg_loc_to_register_2_0);
Define_extern_entry(mercury__code_util__goal_may_allocate_heap_1_0);
Define_extern_entry(mercury__code_util__goal_list_may_allocate_heap_1_0);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i6);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1003);
Define_extern_entry(mercury__code_util__neg_rval_2_0);
Declare_label(mercury__code_util__neg_rval_2_0_i9);
Declare_label(mercury__code_util__neg_rval_2_0_i7);
Declare_label(mercury__code_util__neg_rval_2_0_i11);
Declare_label(mercury__code_util__neg_rval_2_0_i27);
Declare_label(mercury__code_util__neg_rval_2_0_i28);
Declare_label(mercury__code_util__neg_rval_2_0_i30);
Declare_label(mercury__code_util__neg_rval_2_0_i31);
Declare_label(mercury__code_util__neg_rval_2_0_i32);
Declare_label(mercury__code_util__neg_rval_2_0_i33);
Declare_label(mercury__code_util__neg_rval_2_0_i34);
Declare_label(mercury__code_util__neg_rval_2_0_i35);
Declare_label(mercury__code_util__neg_rval_2_0_i36);
Declare_label(mercury__code_util__neg_rval_2_0_i37);
Declare_label(mercury__code_util__neg_rval_2_0_i38);
Declare_label(mercury__code_util__neg_rval_2_0_i39);
Declare_label(mercury__code_util__neg_rval_2_0_i44);
Declare_label(mercury__code_util__neg_rval_2_0_i45);
Declare_label(mercury__code_util__neg_rval_2_0_i46);
Declare_label(mercury__code_util__neg_rval_2_0_i47);
Declare_label(mercury__code_util__neg_rval_2_0_i48);
Declare_label(mercury__code_util__neg_rval_2_0_i49);
Declare_label(mercury__code_util__neg_rval_2_0_i2);
Define_extern_entry(mercury__code_util__negate_the_test_2_0);
Declare_label(mercury__code_util__negate_the_test_2_0_i7);
Declare_label(mercury__code_util__negate_the_test_2_0_i1009);
Declare_label(mercury__code_util__negate_the_test_2_0_i4);
Declare_label(mercury__code_util__negate_the_test_2_0_i8);
Declare_label(mercury__code_util__negate_the_test_2_0_i1008);
Define_extern_entry(mercury__code_util__compiler_generated_1_0);
Declare_label(mercury__code_util__compiler_generated_1_0_i2);
Declare_label(mercury__code_util__compiler_generated_1_0_i3);
Declare_label(mercury__code_util__compiler_generated_1_0_i5);
Declare_label(mercury__code_util__compiler_generated_1_0_i7);
Declare_label(mercury__code_util__compiler_generated_1_0_i9);
Declare_label(mercury__code_util__compiler_generated_1_0_i11);
Declare_label(mercury__code_util__compiler_generated_1_0_i1);
Declare_label(mercury__code_util__compiler_generated_1_0_i1000);
Define_extern_entry(mercury__code_util__predinfo_is_builtin_2_0);
Define_extern_entry(mercury__code_util__is_builtin_4_0);
Declare_label(mercury__code_util__is_builtin_4_0_i2);
Declare_label(mercury__code_util__is_builtin_4_0_i3);
Declare_label(mercury__code_util__is_builtin_4_0_i4);
Declare_label(mercury__code_util__is_builtin_4_0_i7);
Declare_label(mercury__code_util__is_builtin_4_0_i1000);
Define_extern_entry(mercury__code_util__translate_builtin_6_0);
Declare_label(mercury__code_util__translate_builtin_6_0_i7);
Declare_label(mercury__code_util__translate_builtin_6_0_i1003);
Declare_label(mercury__code_util__translate_builtin_6_0_i9);
Declare_label(mercury__code_util__translate_builtin_6_0_i10);
Declare_label(mercury__code_util__translate_builtin_6_0_i13);
Declare_label(mercury__code_util__translate_builtin_6_0_i19);
Declare_label(mercury__code_util__translate_builtin_6_0_i23);
Declare_label(mercury__code_util__translate_builtin_6_0_i24);
Declare_label(mercury__code_util__translate_builtin_6_0_i26);
Declare_label(mercury__code_util__translate_builtin_6_0_i30);
Declare_label(mercury__code_util__translate_builtin_6_0_i31);
Declare_label(mercury__code_util__translate_builtin_6_0_i33);
Declare_label(mercury__code_util__translate_builtin_6_0_i39);
Declare_label(mercury__code_util__translate_builtin_6_0_i43);
Declare_label(mercury__code_util__translate_builtin_6_0_i41);
Declare_label(mercury__code_util__translate_builtin_6_0_i45);
Declare_label(mercury__code_util__translate_builtin_6_0_i58);
Declare_label(mercury__code_util__translate_builtin_6_0_i62);
Declare_label(mercury__code_util__translate_builtin_6_0_i60);
Declare_label(mercury__code_util__translate_builtin_6_0_i64);
Declare_label(mercury__code_util__translate_builtin_6_0_i70);
Declare_label(mercury__code_util__translate_builtin_6_0_i74);
Declare_label(mercury__code_util__translate_builtin_6_0_i75);
Declare_label(mercury__code_util__translate_builtin_6_0_i77);
Declare_label(mercury__code_util__translate_builtin_6_0_i87);
Declare_label(mercury__code_util__translate_builtin_6_0_i91);
Declare_label(mercury__code_util__translate_builtin_6_0_i92);
Declare_label(mercury__code_util__translate_builtin_6_0_i5);
Declare_label(mercury__code_util__translate_builtin_6_0_i102);
Declare_label(mercury__code_util__translate_builtin_6_0_i1181);
Declare_label(mercury__code_util__translate_builtin_6_0_i104);
Declare_label(mercury__code_util__translate_builtin_6_0_i105);
Declare_label(mercury__code_util__translate_builtin_6_0_i108);
Declare_label(mercury__code_util__translate_builtin_6_0_i112);
Declare_label(mercury__code_util__translate_builtin_6_0_i116);
Declare_label(mercury__code_util__translate_builtin_6_0_i119);
Declare_label(mercury__code_util__translate_builtin_6_0_i123);
Declare_label(mercury__code_util__translate_builtin_6_0_i126);
Declare_label(mercury__code_util__translate_builtin_6_0_i130);
Declare_label(mercury__code_util__translate_builtin_6_0_i134);
Declare_label(mercury__code_util__translate_builtin_6_0_i138);
Declare_label(mercury__code_util__translate_builtin_6_0_i139);
Declare_label(mercury__code_util__translate_builtin_6_0_i141);
Declare_label(mercury__code_util__translate_builtin_6_0_i145);
Declare_label(mercury__code_util__translate_builtin_6_0_i149);
Declare_label(mercury__code_util__translate_builtin_6_0_i153);
Declare_label(mercury__code_util__translate_builtin_6_0_i157);
Declare_label(mercury__code_util__translate_builtin_6_0_i160);
Declare_label(mercury__code_util__translate_builtin_6_0_i171);
Declare_label(mercury__code_util__translate_builtin_6_0_i174);
Declare_label(mercury__code_util__translate_builtin_6_0_i178);
Declare_label(mercury__code_util__translate_builtin_6_0_i179);
Declare_label(mercury__code_util__translate_builtin_6_0_i181);
Declare_label(mercury__code_util__translate_builtin_6_0_i185);
Declare_label(mercury__code_util__translate_builtin_6_0_i183);
Declare_label(mercury__code_util__translate_builtin_6_0_i187);
Declare_label(mercury__code_util__translate_builtin_6_0_i193);
Declare_label(mercury__code_util__translate_builtin_6_0_i197);
Declare_label(mercury__code_util__translate_builtin_6_0_i198);
Declare_label(mercury__code_util__translate_builtin_6_0_i200);
Declare_label(mercury__code_util__translate_builtin_6_0_i204);
Declare_label(mercury__code_util__translate_builtin_6_0_i202);
Declare_label(mercury__code_util__translate_builtin_6_0_i206);
Declare_label(mercury__code_util__translate_builtin_6_0_i212);
Declare_label(mercury__code_util__translate_builtin_6_0_i215);
Declare_label(mercury__code_util__translate_builtin_6_0_i219);
Declare_label(mercury__code_util__translate_builtin_6_0_i230);
Declare_label(mercury__code_util__translate_builtin_6_0_i236);
Declare_label(mercury__code_util__translate_builtin_6_0_i240);
Declare_label(mercury__code_util__translate_builtin_6_0_i241);
Declare_label(mercury__code_util__translate_builtin_6_0_i100);
Declare_label(mercury__code_util__translate_builtin_6_0_i247);
Declare_label(mercury__code_util__translate_builtin_6_0_i1);
Define_extern_entry(mercury__code_util__cons_id_to_tag_4_0);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i5);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i6);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i7);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i1004);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i10);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i18);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i20);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i13);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i12);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i23);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i25);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i26);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i29);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i35);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i36);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i37);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i38);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i39);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i31);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i28);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i22);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i51);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i50);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i53);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i54);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i55);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i56);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i57);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i58);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i61);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i8);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i66);
Define_extern_entry(mercury__code_util__cannot_stack_flush_1_0);
Define_extern_entry(mercury__code_util__cannot_fail_before_stack_flush_1_0);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i2);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i3);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i10);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1001);
Declare_static(mercury__code_util__choose_local_label_type_7_0);
Declare_label(mercury__code_util__choose_local_label_type_7_0_i5);
Declare_label(mercury__code_util__choose_local_label_type_7_0_i4);
Declare_label(mercury__code_util__choose_local_label_type_7_0_i1007);
Declare_static(mercury__code_util__builtin_4_0);
Declare_label(mercury__code_util__builtin_4_0_i2);
Declare_label(mercury__code_util__builtin_4_0_i3);
Declare_label(mercury__code_util__builtin_4_0_i1002);
Declare_static(mercury__code_util__goal_may_allocate_heap_2_1_0);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1026);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1025);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1011);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i20);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i24);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i28);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1024);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i32);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i38);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i35);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i2);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1016);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1017);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1018);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1019);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1020);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1021);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1023);
Declare_static(mercury__code_util__cases_may_allocate_heap_1_0);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i6);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i3);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i1003);
Declare_static(mercury__code_util__cannot_stack_flush_2_1_0);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1016);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i8);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1001);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1015);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i12);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i16);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1010);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1011);
Declare_static(mercury__code_util__cannot_stack_flush_goals_1_0);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i4);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1003);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
Declare_static(mercury__code_util__cannot_stack_flush_cases_1_0);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i4);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1003);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
Declare_static(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1009);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i4);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i9);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i10);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);

Word * mercury_data_code_util__common_0[] = {
	(Word *) string_const("'", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_code_util__common_1[] = {
	((Integer) 1),
	(Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word mercury_data_code_util__common_2[] = {
	((Integer) 1),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_code_util__common_3[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const(">=", 2),
	(Word *) string_const("=<", 2),
	(Word *) string_const("builtin_float_ge", 16),
	(Word *) string_const("builtin_float_times", 19),
	(Word *) string_const("/", 1),
	(Word *) string_const("builtin_float_lt", 16),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_float_le", 16),
	(Word *) ((Integer) 0),
	(Word *) string_const("+", 1),
	(Word *) string_const("*", 1),
	(Word *) string_const("-", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_float_minus", 19),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_float_gt", 16),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_float_divide", 20),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_float_plus", 18),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("<", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const(">", 1)
};

Word mercury_data_code_util__common_4[] = {
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) 2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) 5),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) 6),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1)
};

static const Float mercury_float_const_0 = 0;
Word * mercury_data_code_util__common_5[] = {
	(Word *) (Word)(&mercury_float_const_0)
};

Word * mercury_data_code_util__common_6[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_code_util__common_5)
};

Word * mercury_data_code_util__common_7[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const(">=", 2),
	(Word *) string_const(">>", 2),
	(Word *) string_const("<<", 2),
	(Word *) string_const("<", 1),
	(Word *) string_const("mod", 3),
	(Word *) string_const(">", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_left_shift", 18),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_bit_or", 14),
	(Word *) string_const("builtin_div", 11),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("/\\", 2),
	(Word *) string_const("builtin_right_shift", 19),
	(Word *) string_const("builtin_mod", 11),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_bit_and", 15),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("^", 1),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("//", 2),
	(Word *) string_const("=<", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_plus", 12),
	(Word *) ((Integer) 0),
	(Word *) string_const("+", 1),
	(Word *) string_const("*", 1),
	(Word *) string_const("-", 1),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_unary_minus", 19),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\/", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_bit_xor", 15),
	(Word *) string_const("builtin_times", 13),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_unary_plus", 18),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_bit_neg", 15),
	(Word *) ((Integer) 0),
	(Word *) string_const("builtin_minus", 13)
};

Word mercury_data_code_util__common_8[] = {
	((Integer) -2),
	((Integer) -1),
	((Integer) 3),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 4),
	((Integer) -2),
	((Integer) 6)
};

Word mercury_data_code_util__common_9[] = {
	((Integer) 0)
};

Word * mercury_data_code_util__common_10[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_code_util__common_9)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_code_util__common_11[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

BEGIN_MODULE(mercury__code_util_module0)
	init_entry(mercury__code_util__predinfo_is_builtin__ua0_2_0);
	init_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i2);
	init_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i3);
	init_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i4);
	init_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i8);
	init_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i5);
BEGIN_CODE

/* code for predicate 'code_util__predinfo_is_builtin__ua0'/2 in mode 0 */
Define_static(mercury__code_util__predinfo_is_builtin__ua0_2_0);
	incr_sp_push_msg(4, "code_util__predinfo_is_builtin__ua0");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__code_util__predinfo_is_builtin__ua0_2_0_i2,
		STATIC(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	}
Define_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_util__predinfo_is_builtin__ua0_2_0_i3,
		STATIC(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	}
Define_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__predinfo_is_builtin__ua0_2_0_i4,
		STATIC(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	}
Define_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	r4 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 0);
	call_localret(STATIC(mercury__code_util__builtin_4_0),
		mercury__code_util__predinfo_is_builtin__ua0_2_0_i8,
		STATIC(mercury__code_util__predinfo_is_builtin__ua0_2_0));
Define_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin__ua0_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_util__predinfo_is_builtin__ua0_2_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 10000);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__code_util__builtin_4_0),
		STATIC(mercury__code_util__predinfo_is_builtin__ua0_2_0));
Define_label(mercury__code_util__predinfo_is_builtin__ua0_2_0_i5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module1)
	init_entry(mercury__code_util__make_entry_label_5_0);
	init_label(mercury__code_util__make_entry_label_5_0_i2);
	init_label(mercury__code_util__make_entry_label_5_0_i3);
	init_label(mercury__code_util__make_entry_label_5_0_i9);
	init_label(mercury__code_util__make_entry_label_5_0_i8);
	init_label(mercury__code_util__make_entry_label_5_0_i11);
	init_label(mercury__code_util__make_entry_label_5_0_i14);
	init_label(mercury__code_util__make_entry_label_5_0_i5);
	init_label(mercury__code_util__make_entry_label_5_0_i15);
BEGIN_CODE

/* code for predicate 'code_util__make_entry_label'/5 in mode 0 */
Define_entry(mercury__code_util__make_entry_label_5_0);
	incr_sp_push_msg(6, "code_util__make_entry_label");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__code_util__make_entry_label_5_0_i2,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_util__make_entry_label_5_0_i3,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__code_util__make_entry_label_5_0_i9,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_entry_label_5_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_entry_label_5_0_i14,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i8);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0),
		mercury__code_util__make_entry_label_5_0_i11,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i11);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_entry_label_5_0_i5);
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__make_entry_label_5_0_i5);
	r3 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_entry_label_5_0_i14,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i14);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_entry_label_5_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_util__make_entry_label_5_0_i15,
		ENTRY(mercury__code_util__make_entry_label_5_0));
	}
Define_label(mercury__code_util__make_entry_label_5_0_i15);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module2)
	init_entry(mercury__code_util__make_local_entry_label_5_0);
	init_label(mercury__code_util__make_local_entry_label_5_0_i2);
	init_label(mercury__code_util__make_local_entry_label_5_0_i3);
	init_label(mercury__code_util__make_local_entry_label_5_0_i4);
	init_label(mercury__code_util__make_local_entry_label_5_0_i10);
	init_label(mercury__code_util__make_local_entry_label_5_0_i9);
	init_label(mercury__code_util__make_local_entry_label_5_0_i12);
	init_label(mercury__code_util__make_local_entry_label_5_0_i7);
	init_label(mercury__code_util__make_local_entry_label_5_0_i16);
	init_label(mercury__code_util__make_local_entry_label_5_0_i6);
	init_label(mercury__code_util__make_local_entry_label_5_0_i1011);
BEGIN_CODE

/* code for predicate 'code_util__make_local_entry_label'/5 in mode 0 */
Define_entry(mercury__code_util__make_local_entry_label_5_0);
	incr_sp_push_msg(6, "code_util__make_local_entry_label");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
		call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_local_entry_label_5_0_i2,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__code_util__make_local_entry_label_5_0_i3,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_util__make_local_entry_label_5_0_i4,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_exported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_exported_1_0),
		mercury__code_util__make_local_entry_label_5_0_i10,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i9);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i7);
Define_label(mercury__code_util__make_local_entry_label_5_0_i9);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_pseudo_exported_1_0),
		mercury__code_util__make_local_entry_label_5_0_i12,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i12);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i6);
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i6);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
Define_label(mercury__code_util__make_local_entry_label_5_0_i7);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i16);
	r6 = (Integer) r4;
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r3 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__choose_local_label_type_7_0),
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i16);
	tag_incr_hp(r1, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_local_entry_label_5_0_i6);
	{
	Word tempr1, tempr2, tempr3;
	tempr1 = (Integer) detstackvar(4);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1011);
	tempr3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr3, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) tempr3, ((Integer) 0));
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__choose_local_label_type_7_0),
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i1011);
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module3)
	init_entry(mercury__code_util__make_internal_label_5_0);
	init_label(mercury__code_util__make_internal_label_5_0_i2);
BEGIN_CODE

/* code for predicate 'code_util__make_internal_label'/5 in mode 0 */
Define_entry(mercury__code_util__make_internal_label_5_0);
	incr_sp_push_msg(2, "code_util__make_internal_label");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	{
		call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_internal_label_5_0_i2,
		ENTRY(mercury__code_util__make_internal_label_5_0));
	}
Define_label(mercury__code_util__make_internal_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_internal_label_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module4)
	init_entry(mercury__code_util__make_proc_label_4_0);
	init_label(mercury__code_util__make_proc_label_4_0_i2);
	init_label(mercury__code_util__make_proc_label_4_0_i3);
	init_label(mercury__code_util__make_proc_label_4_0_i4);
	init_label(mercury__code_util__make_proc_label_4_0_i7);
	init_label(mercury__code_util__make_proc_label_4_0_i9);
	init_label(mercury__code_util__make_proc_label_4_0_i12);
	init_label(mercury__code_util__make_proc_label_4_0_i14);
	init_label(mercury__code_util__make_proc_label_4_0_i1007);
	init_label(mercury__code_util__make_proc_label_4_0_i16);
	init_label(mercury__code_util__make_proc_label_4_0_i6);
	init_label(mercury__code_util__make_proc_label_4_0_i19);
	init_label(mercury__code_util__make_proc_label_4_0_i20);
BEGIN_CODE

/* code for predicate 'code_util__make_proc_label'/4 in mode 0 */
Define_entry(mercury__code_util__make_proc_label_4_0);
	incr_sp_push_msg(5, "code_util__make_proc_label");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__predicate_module_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__code_util__make_proc_label_4_0_i2,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_util__make_proc_label_4_0_i3,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__code_util__make_proc_label_4_0_i4,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	detstackvar(2) = (Integer) r1;
	{
		call_localret(STATIC(mercury__code_util__compiler_generated_1_0),
		mercury__code_util__make_proc_label_4_0_i7,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i6);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_3_0),
		mercury__code_util__make_proc_label_4_0_i9,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r3 = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__special_pred__special_pred_get_type_3_0);
	call_localret(ENTRY(mercury__special_pred__special_pred_get_type_3_0),
		mercury__code_util__make_proc_label_4_0_i12,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i12);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i1007);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__code_util__make_proc_label_4_0_i14,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i14);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i1007);
	tag_incr_hp(r1, mktag(1), ((Integer) 5));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_util__make_proc_label_4_0_i1007);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("code_util__make_proc_label:\n", 28);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("cannot make label for special pred `", 36);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_code_util__common_0);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__code_util__make_proc_label_4_0_i16,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i16);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i6);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__code_util__make_proc_label_4_0_i19,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i19);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__make_proc_label_4_0_i20,
		ENTRY(mercury__code_util__make_proc_label_4_0));
	}
Define_label(mercury__code_util__make_proc_label_4_0_i20);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module5)
	init_entry(mercury__code_util__make_uni_label_4_0);
	init_label(mercury__code_util__make_uni_label_4_0_i2);
BEGIN_CODE

/* code for predicate 'code_util__make_uni_label'/4 in mode 0 */
Define_entry(mercury__code_util__make_uni_label_4_0);
	incr_sp_push_msg(3, "code_util__make_uni_label");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__code_util__make_uni_label_4_0_i2,
		ENTRY(mercury__code_util__make_uni_label_4_0));
	}
Define_label(mercury__code_util__make_uni_label_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_uni_label_4_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 5));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) r2;
	r3 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = string_const("__Unify__", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module6)
	init_entry(mercury__code_util__arg_loc_to_register_2_0);
BEGIN_CODE

/* code for predicate 'code_util__arg_loc_to_register'/2 in mode 0 */
Define_entry(mercury__code_util__arg_loc_to_register_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module7)
	init_entry(mercury__code_util__goal_may_allocate_heap_1_0);
BEGIN_CODE

/* code for predicate 'code_util__goal_may_allocate_heap'/1 in mode 0 */
Define_entry(mercury__code_util__goal_may_allocate_heap_1_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0),
		ENTRY(mercury__code_util__goal_may_allocate_heap_1_0));
END_MODULE

BEGIN_MODULE(mercury__code_util_module8)
	init_entry(mercury__code_util__goal_list_may_allocate_heap_1_0);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i6);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1003);
BEGIN_CODE

/* code for predicate 'code_util__goal_list_may_allocate_heap'/1 in mode 0 */
Define_entry(mercury__code_util__goal_list_may_allocate_heap_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0_i1003);
	incr_sp_push_msg(2, "code_util__goal_list_may_allocate_heap");
	detstackvar(2) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__code_util__goal_list_may_allocate_heap_1_0_i6,
		ENTRY(mercury__code_util__goal_list_may_allocate_heap_1_0));
	}
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i6);
	update_prof_current_proc(LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_util__goal_list_may_allocate_heap_1_0,
		ENTRY(mercury__code_util__goal_list_may_allocate_heap_1_0));
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module9)
	init_entry(mercury__code_util__neg_rval_2_0);
	init_label(mercury__code_util__neg_rval_2_0_i9);
	init_label(mercury__code_util__neg_rval_2_0_i7);
	init_label(mercury__code_util__neg_rval_2_0_i11);
	init_label(mercury__code_util__neg_rval_2_0_i27);
	init_label(mercury__code_util__neg_rval_2_0_i28);
	init_label(mercury__code_util__neg_rval_2_0_i30);
	init_label(mercury__code_util__neg_rval_2_0_i31);
	init_label(mercury__code_util__neg_rval_2_0_i32);
	init_label(mercury__code_util__neg_rval_2_0_i33);
	init_label(mercury__code_util__neg_rval_2_0_i34);
	init_label(mercury__code_util__neg_rval_2_0_i35);
	init_label(mercury__code_util__neg_rval_2_0_i36);
	init_label(mercury__code_util__neg_rval_2_0_i37);
	init_label(mercury__code_util__neg_rval_2_0_i38);
	init_label(mercury__code_util__neg_rval_2_0_i39);
	init_label(mercury__code_util__neg_rval_2_0_i44);
	init_label(mercury__code_util__neg_rval_2_0_i45);
	init_label(mercury__code_util__neg_rval_2_0_i46);
	init_label(mercury__code_util__neg_rval_2_0_i47);
	init_label(mercury__code_util__neg_rval_2_0_i48);
	init_label(mercury__code_util__neg_rval_2_0_i49);
	init_label(mercury__code_util__neg_rval_2_0_i2);
BEGIN_CODE

/* code for predicate 'code_util__neg_rval'/2 in mode 0 */
Define_entry(mercury__code_util__neg_rval_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i7);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i9);
	r1 = (Integer) mkword(mktag(3), (Integer) mercury_data_code_util__common_1);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i9);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	r1 = (Integer) mkword(mktag(3), (Integer) mercury_data_code_util__common_2);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i7);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i11);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != ((Integer) 9)))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i11);
	if (((Integer) r2 != ((Integer) 3)))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i27) AND
		LABEL(mercury__code_util__neg_rval_2_0_i28) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i30) AND
		LABEL(mercury__code_util__neg_rval_2_0_i31) AND
		LABEL(mercury__code_util__neg_rval_2_0_i32) AND
		LABEL(mercury__code_util__neg_rval_2_0_i33) AND
		LABEL(mercury__code_util__neg_rval_2_0_i34) AND
		LABEL(mercury__code_util__neg_rval_2_0_i35) AND
		LABEL(mercury__code_util__neg_rval_2_0_i36) AND
		LABEL(mercury__code_util__neg_rval_2_0_i37) AND
		LABEL(mercury__code_util__neg_rval_2_0_i38) AND
		LABEL(mercury__code_util__neg_rval_2_0_i39) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i44) AND
		LABEL(mercury__code_util__neg_rval_2_0_i45) AND
		LABEL(mercury__code_util__neg_rval_2_0_i46) AND
		LABEL(mercury__code_util__neg_rval_2_0_i47) AND
		LABEL(mercury__code_util__neg_rval_2_0_i48) AND
		LABEL(mercury__code_util__neg_rval_2_0_i49));
Define_label(mercury__code_util__neg_rval_2_0_i27);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 13);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i28);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 12);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i30);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 16);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i31);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 15);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i32);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 20);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i33);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 19);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i34);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 18);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i35);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 17);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i36);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 24);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i37);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 23);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i38);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 22);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i39);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 21);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i44);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 30);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i45);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 29);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i46);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 34);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i47);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 33);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i48);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 32);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i49);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 31);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i2);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 9);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module10)
	init_entry(mercury__code_util__negate_the_test_2_0);
	init_label(mercury__code_util__negate_the_test_2_0_i7);
	init_label(mercury__code_util__negate_the_test_2_0_i1009);
	init_label(mercury__code_util__negate_the_test_2_0_i4);
	init_label(mercury__code_util__negate_the_test_2_0_i8);
	init_label(mercury__code_util__negate_the_test_2_0_i1008);
BEGIN_CODE

/* code for predicate 'code_util__negate_the_test'/2 in mode 0 */
Define_entry(mercury__code_util__negate_the_test_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__negate_the_test_2_0_i1008);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr1 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) tempr2;
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_util__negate_the_test_2_0_i1009);
	incr_sp_push_msg(3, "code_util__negate_the_test");
	detstackvar(3) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury__code_util__negate_the_test_2_0_i4);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	{
		call_localret(STATIC(mercury__code_util__neg_rval_2_0),
		mercury__code_util__negate_the_test_2_0_i7,
		ENTRY(mercury__code_util__negate_the_test_2_0));
	}
	}
Define_label(mercury__code_util__negate_the_test_2_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__negate_the_test_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__code_util__negate_the_test_2_0_i1009);
	incr_sp_push_msg(3, "code_util__negate_the_test");
	detstackvar(3) = (Integer) succip;
Define_label(mercury__code_util__negate_the_test_2_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__code_util__negate_the_test_2_0,
		LABEL(mercury__code_util__negate_the_test_2_0_i8),
		ENTRY(mercury__code_util__negate_the_test_2_0));
Define_label(mercury__code_util__negate_the_test_2_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__negate_the_test_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__negate_the_test_2_0_i1008);
	r1 = string_const("code_util__negate_the_test on empty list", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__negate_the_test_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__code_util_module11)
	init_entry(mercury__code_util__compiler_generated_1_0);
	init_label(mercury__code_util__compiler_generated_1_0_i2);
	init_label(mercury__code_util__compiler_generated_1_0_i3);
	init_label(mercury__code_util__compiler_generated_1_0_i5);
	init_label(mercury__code_util__compiler_generated_1_0_i7);
	init_label(mercury__code_util__compiler_generated_1_0_i9);
	init_label(mercury__code_util__compiler_generated_1_0_i11);
	init_label(mercury__code_util__compiler_generated_1_0_i1);
	init_label(mercury__code_util__compiler_generated_1_0_i1000);
BEGIN_CODE

/* code for predicate 'code_util__compiler_generated'/1 in mode 0 */
Define_entry(mercury__code_util__compiler_generated_1_0);
	incr_sp_push_msg(2, "code_util__compiler_generated");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_util__compiler_generated_1_0_i2,
		ENTRY(mercury__code_util__compiler_generated_1_0));
	}
Define_label(mercury__code_util__compiler_generated_1_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__compiler_generated_1_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__compiler_generated_1_0_i3,
		ENTRY(mercury__code_util__compiler_generated_1_0));
	}
Define_label(mercury__code_util__compiler_generated_1_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__compiler_generated_1_0));
	if ((strcmp((char *)(Integer) detstackvar(1), (char *)string_const("__Compare__", 11)) !=0))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r1 == ((Integer) 3)))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__compiler_generated_1_0_i5);
	if ((strcmp((char *)(Integer) detstackvar(1), (char *)string_const("__Index__", 9)) !=0))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r1 == ((Integer) 2)))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__compiler_generated_1_0_i7);
	if ((strcmp((char *)(Integer) detstackvar(1), (char *)string_const("__Term_To_Type__", 16)) !=0))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r1 == ((Integer) 2)))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__compiler_generated_1_0_i9);
	if ((strcmp((char *)(Integer) detstackvar(1), (char *)string_const("__Type_To_Term__", 16)) !=0))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r1 == ((Integer) 2)))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__compiler_generated_1_0_i11);
	if ((strcmp((char *)(Integer) detstackvar(1), (char *)string_const("__Unify__", 9)) !=0))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i1);
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__code_util__compiler_generated_1_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__compiler_generated_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__compiler_generated_1_0_i1000);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module12)
	init_entry(mercury__code_util__predinfo_is_builtin_2_0);
BEGIN_CODE

/* code for predicate 'code_util__predinfo_is_builtin'/2 in mode 0 */
Define_entry(mercury__code_util__predinfo_is_builtin_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__code_util__predinfo_is_builtin__ua0_2_0),
		ENTRY(mercury__code_util__predinfo_is_builtin_2_0));
END_MODULE

BEGIN_MODULE(mercury__code_util_module13)
	init_entry(mercury__code_util__is_builtin_4_0);
	init_label(mercury__code_util__is_builtin_4_0_i2);
	init_label(mercury__code_util__is_builtin_4_0_i3);
	init_label(mercury__code_util__is_builtin_4_0_i4);
	init_label(mercury__code_util__is_builtin_4_0_i7);
	init_label(mercury__code_util__is_builtin_4_0_i1000);
BEGIN_CODE

/* code for predicate 'code_util__is_builtin'/4 in mode 0 */
Define_entry(mercury__code_util__is_builtin_4_0);
	incr_sp_push_msg(5, "code_util__is_builtin");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__predicate_module_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__code_util__is_builtin_4_0_i2,
		ENTRY(mercury__code_util__is_builtin_4_0));
	}
Define_label(mercury__code_util__is_builtin_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__is_builtin_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_util__is_builtin_4_0_i3,
		ENTRY(mercury__code_util__is_builtin_4_0));
	}
Define_label(mercury__code_util__is_builtin_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__is_builtin_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__predicate_arity_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_arity_3_0),
		mercury__code_util__is_builtin_4_0_i4,
		ENTRY(mercury__code_util__is_builtin_4_0));
	}
Define_label(mercury__code_util__is_builtin_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__is_builtin_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__code_util__builtin_4_0),
		mercury__code_util__is_builtin_4_0_i7,
		ENTRY(mercury__code_util__is_builtin_4_0));
Define_label(mercury__code_util__is_builtin_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__is_builtin_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__is_builtin_4_0_i1000);
	r1 = ((Integer) 0);
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
	tailcall(ENTRY(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0),
		ENTRY(mercury__code_util__is_builtin_4_0));
	}
Define_label(mercury__code_util__is_builtin_4_0_i1000);
	r1 = ((Integer) 1);
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
	tailcall(ENTRY(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0),
		ENTRY(mercury__code_util__is_builtin_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__code_util_module14)
	init_entry(mercury__code_util__translate_builtin_6_0);
	init_label(mercury__code_util__translate_builtin_6_0_i7);
	init_label(mercury__code_util__translate_builtin_6_0_i1003);
	init_label(mercury__code_util__translate_builtin_6_0_i9);
	init_label(mercury__code_util__translate_builtin_6_0_i10);
	init_label(mercury__code_util__translate_builtin_6_0_i13);
	init_label(mercury__code_util__translate_builtin_6_0_i19);
	init_label(mercury__code_util__translate_builtin_6_0_i23);
	init_label(mercury__code_util__translate_builtin_6_0_i24);
	init_label(mercury__code_util__translate_builtin_6_0_i26);
	init_label(mercury__code_util__translate_builtin_6_0_i30);
	init_label(mercury__code_util__translate_builtin_6_0_i31);
	init_label(mercury__code_util__translate_builtin_6_0_i33);
	init_label(mercury__code_util__translate_builtin_6_0_i39);
	init_label(mercury__code_util__translate_builtin_6_0_i43);
	init_label(mercury__code_util__translate_builtin_6_0_i41);
	init_label(mercury__code_util__translate_builtin_6_0_i45);
	init_label(mercury__code_util__translate_builtin_6_0_i58);
	init_label(mercury__code_util__translate_builtin_6_0_i62);
	init_label(mercury__code_util__translate_builtin_6_0_i60);
	init_label(mercury__code_util__translate_builtin_6_0_i64);
	init_label(mercury__code_util__translate_builtin_6_0_i70);
	init_label(mercury__code_util__translate_builtin_6_0_i74);
	init_label(mercury__code_util__translate_builtin_6_0_i75);
	init_label(mercury__code_util__translate_builtin_6_0_i77);
	init_label(mercury__code_util__translate_builtin_6_0_i87);
	init_label(mercury__code_util__translate_builtin_6_0_i91);
	init_label(mercury__code_util__translate_builtin_6_0_i92);
	init_label(mercury__code_util__translate_builtin_6_0_i5);
	init_label(mercury__code_util__translate_builtin_6_0_i102);
	init_label(mercury__code_util__translate_builtin_6_0_i1181);
	init_label(mercury__code_util__translate_builtin_6_0_i104);
	init_label(mercury__code_util__translate_builtin_6_0_i105);
	init_label(mercury__code_util__translate_builtin_6_0_i108);
	init_label(mercury__code_util__translate_builtin_6_0_i112);
	init_label(mercury__code_util__translate_builtin_6_0_i116);
	init_label(mercury__code_util__translate_builtin_6_0_i119);
	init_label(mercury__code_util__translate_builtin_6_0_i123);
	init_label(mercury__code_util__translate_builtin_6_0_i126);
	init_label(mercury__code_util__translate_builtin_6_0_i130);
	init_label(mercury__code_util__translate_builtin_6_0_i134);
	init_label(mercury__code_util__translate_builtin_6_0_i138);
	init_label(mercury__code_util__translate_builtin_6_0_i139);
	init_label(mercury__code_util__translate_builtin_6_0_i141);
	init_label(mercury__code_util__translate_builtin_6_0_i145);
	init_label(mercury__code_util__translate_builtin_6_0_i149);
	init_label(mercury__code_util__translate_builtin_6_0_i153);
	init_label(mercury__code_util__translate_builtin_6_0_i157);
	init_label(mercury__code_util__translate_builtin_6_0_i160);
	init_label(mercury__code_util__translate_builtin_6_0_i171);
	init_label(mercury__code_util__translate_builtin_6_0_i174);
	init_label(mercury__code_util__translate_builtin_6_0_i178);
	init_label(mercury__code_util__translate_builtin_6_0_i179);
	init_label(mercury__code_util__translate_builtin_6_0_i181);
	init_label(mercury__code_util__translate_builtin_6_0_i185);
	init_label(mercury__code_util__translate_builtin_6_0_i183);
	init_label(mercury__code_util__translate_builtin_6_0_i187);
	init_label(mercury__code_util__translate_builtin_6_0_i193);
	init_label(mercury__code_util__translate_builtin_6_0_i197);
	init_label(mercury__code_util__translate_builtin_6_0_i198);
	init_label(mercury__code_util__translate_builtin_6_0_i200);
	init_label(mercury__code_util__translate_builtin_6_0_i204);
	init_label(mercury__code_util__translate_builtin_6_0_i202);
	init_label(mercury__code_util__translate_builtin_6_0_i206);
	init_label(mercury__code_util__translate_builtin_6_0_i212);
	init_label(mercury__code_util__translate_builtin_6_0_i215);
	init_label(mercury__code_util__translate_builtin_6_0_i219);
	init_label(mercury__code_util__translate_builtin_6_0_i230);
	init_label(mercury__code_util__translate_builtin_6_0_i236);
	init_label(mercury__code_util__translate_builtin_6_0_i240);
	init_label(mercury__code_util__translate_builtin_6_0_i241);
	init_label(mercury__code_util__translate_builtin_6_0_i100);
	init_label(mercury__code_util__translate_builtin_6_0_i247);
	init_label(mercury__code_util__translate_builtin_6_0_i1);
BEGIN_CODE

/* code for predicate 'code_util__translate_builtin'/6 in mode 0 */
Define_entry(mercury__code_util__translate_builtin_6_0);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r4, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i5);
	r1 = (hash_string((Integer) r2) & ((Integer) 31));
Define_label(mercury__code_util__translate_builtin_6_0_i7);
	{
	Word tempr1;
	tempr1 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_code_util__common_3))[(Integer) r1];
	if (!((Integer) tempr1))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1003);
	if ((strcmp((char *)(Integer) tempr1, (char *)(Integer) r2) ==0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i9);
	}
Define_label(mercury__code_util__translate_builtin_6_0_i1003);
	r1 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_code_util__common_4))[(Integer) r1];
	if (((Integer) r1 >= ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i7);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i9);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i10) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i13) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i10) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i19) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i26) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i33) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i13) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i39) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i19) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i58) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i70) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i77) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i26) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i87) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i33) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i77));
Define_label(mercury__code_util__translate_builtin_6_0_i10);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 34);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i13);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 33);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i19);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i23);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 27);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i23);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i24);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 28);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i24);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 28);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i26);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i30);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 28);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i30);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i31);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 27);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i31);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 28);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i33);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 31);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i39);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i41);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i43);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i43);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 25);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i41);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i45);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i45);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i58);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i60);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i62);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) mkword(mktag(3), (Integer) mercury_data_code_util__common_6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i62);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i60);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i64);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 25);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i64);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i70);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i74);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i74);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i75);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 25);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i75);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i77);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 32);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i87);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i91);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 25);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i91);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i92);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i92);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 26);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i5);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("int", 3)) !=0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i100);
	r1 = (hash_string((Integer) r2) & ((Integer) 63));
Define_label(mercury__code_util__translate_builtin_6_0_i102);
	{
	Word tempr1;
	tempr1 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_code_util__common_7))[(Integer) r1];
	if (!((Integer) tempr1))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1181);
	if ((strcmp((char *)(Integer) tempr1, (char *)(Integer) r2) ==0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i104);
	}
Define_label(mercury__code_util__translate_builtin_6_0_i1181);
	r1 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_code_util__common_8))[(Integer) r1];
	if (((Integer) r1 >= ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i102);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i104);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i105) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i108) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i112) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i116) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i119) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i123) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i126) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i130) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i134) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i141) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i145) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i149) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i153) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i157) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i160) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i134) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i171) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i174) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i181) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i193) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i200) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i212) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i215) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i219) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i193) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i230) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i157) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i1) AND
		LABEL(mercury__code_util__translate_builtin_6_0_i236));
Define_label(mercury__code_util__translate_builtin_6_0_i105);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 24);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i108);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i112);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i116);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 21);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i119);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i123);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 22);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i126);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i130);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i134);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i138);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i138);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i139);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i139);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i141);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i145);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i149);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i153);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i157);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i160);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i171);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 23);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i174);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i178);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i178);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i179);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i179);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i181);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i183);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i185);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i185);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i183);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i187);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i187);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i193);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i197);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i197);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i198);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i198);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i200);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i202);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i204);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) mkword(mktag(3), (Integer) mercury_data_code_util__common_10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i204);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i202);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i206);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i206);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i212);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) mkword(mktag(3), (Integer) mercury_data_code_util__common_10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i215);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i219);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i230);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i236);
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 10000)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i240);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i240);
	if (((Integer) r3 != ((Integer) 10001)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i241);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i241);
	if (((Integer) r3 != ((Integer) 10002)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_6_0_i100);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("mercury_builtin", 15)) !=0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	if ((strcmp((char *)(Integer) r2, (char *)string_const("builtin_int_gt", 14)) !=0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i247);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 22);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i247);
	if ((strcmp((char *)(Integer) r2, (char *)string_const("builtin_int_lt", 14)) !=0))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 21);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_6_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module15)
	init_entry(mercury__code_util__cons_id_to_tag_4_0);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i5);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i6);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i7);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i1004);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i10);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i18);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i20);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i13);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i12);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i23);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i25);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i26);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i29);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i35);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i36);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i37);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i38);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i39);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i31);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i28);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i22);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i51);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i50);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i53);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i54);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i55);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i56);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i57);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i58);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i61);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i8);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i66);
BEGIN_CODE

/* code for predicate 'code_util__cons_id_to_tag'/4 in mode 0 */
Define_entry(mercury__code_util__cons_id_to_tag_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i1004);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(8, "code_util__cons_id_to_tag");
	detstackvar(8) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i5);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i5);
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i6);
	if (((Integer) r4 != ((Integer) 2)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i7);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i7);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i1004);
	incr_sp_push_msg(8, "code_util__cons_id_to_tag");
	detstackvar(8) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i8);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r4) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i10);
	r1 = string_const("code_util__cons_id_to_tag - qualified cons_id", 45);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i10);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r6 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i12);
	r7 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r7) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i12);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r7, ((Integer) 0)), (char *)string_const("character", 9)) !=0))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i12);
	r7 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	if (((Integer) r7 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i12);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r6;
	detstackvar(7) = (Integer) r5;
	r1 = (Integer) r6;
	{
	Declare_entry(mercury__string__char_to_string_2_1);
	call_localret(ENTRY(mercury__string__char_to_string_2_1),
		mercury__code_util__cons_id_to_tag_4_0_i18,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i18);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i13);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__char__to_int_2_0);
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i20,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i20);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i13);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(7);
Define_label(mercury__code_util__cons_id_to_tag_4_0_i12);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r6;
	detstackvar(7) = (Integer) r5;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_is_higher_order_3_0);
	call_localret(ENTRY(mercury__type_util__type_is_higher_order_3_0),
		mercury__code_util__cons_id_to_tag_4_0_i23,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i23);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i22);
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i25,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i25);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i26,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i26);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r3 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r4 = ((Integer) detstackvar(7) + (Integer) detstackvar(6));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__predicate_table_search_pf_name_arity_5_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_pf_name_arity_5_0),
		mercury__code_util__cons_id_to_tag_4_0_i29,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i29);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i28);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i31);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i31);
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_module__predicate_table_get_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_get_preds_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i35,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i35);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_util__cons_id_to_tag_4_0_i36,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i36);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i37,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i37);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i38,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i38);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i39);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i39);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i39);
	r1 = string_const("sorry, not implemented: taking address of predicate or function with multiple modes", 83);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i31);
	r1 = string_const("code_util__cons_id_to_tag: ambiguous pred or func", 49);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i28);
	r1 = string_const("code_util__cons_id_to_tag: invalid pred or func", 47);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i22);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__code_util__cons_id_to_tag_4_0_i51,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i51);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i50);
	r3 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i54);
Define_label(mercury__code_util__cons_id_to_tag_4_0_i50);
	r1 = string_const("code_util__cons_id_to_tag: invalid type", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_util__cons_id_to_tag_4_0_i53,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i53);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
Define_label(mercury__code_util__cons_id_to_tag_4_0_i54);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i55,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i55);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_code_util__common_11);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__code_util__cons_id_to_tag_4_0_i56,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i56);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i57,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i57);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i58);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) detstackvar(1);
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	}
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	}
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i58);
	r1 = string_const("code_util__cons_id_to_tag: type is not d.u. type?", 49);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_util__cons_id_to_tag_4_0_i61,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i61);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) r1;
	r1 = (Integer) r3;
	tempr2 = (Integer) r2;
	r2 = (Integer) r4;
	r4 = (Integer) tempr2;
	r3 = (Integer) tempr1;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i8);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i66);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i66);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module16)
	init_entry(mercury__code_util__cannot_stack_flush_1_0);
BEGIN_CODE

/* code for predicate 'code_util__cannot_stack_flush'/1 in mode 0 */
Define_entry(mercury__code_util__cannot_stack_flush_1_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__code_util__cannot_stack_flush_2_1_0),
		ENTRY(mercury__code_util__cannot_stack_flush_1_0));
END_MODULE

BEGIN_MODULE(mercury__code_util_module17)
	init_entry(mercury__code_util__cannot_fail_before_stack_flush_1_0);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i2);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i3);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i10);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1001);
BEGIN_CODE

/* code for predicate 'code_util__cannot_fail_before_stack_flush'/1 in mode 0 */
Define_entry(mercury__code_util__cannot_fail_before_stack_flush_1_0);
	incr_sp_push_msg(2, "code_util__cannot_fail_before_stack_flush");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__code_util__cannot_fail_before_stack_flush_1_0_i2,
		ENTRY(mercury__code_util__cannot_fail_before_stack_flush_1_0));
	}
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__code_util__cannot_fail_before_stack_flush_1_0_i3,
		ENTRY(mercury__code_util__cannot_fail_before_stack_flush_1_0));
	}
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0));
	if (((Integer) r1 == ((Integer) 1)))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0_i10);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1001);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	tailcall(STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0),
		ENTRY(mercury__code_util__cannot_fail_before_stack_flush_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i10);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1001);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module18)
	init_entry(mercury__code_util__choose_local_label_type_7_0);
	init_label(mercury__code_util__choose_local_label_type_7_0_i5);
	init_label(mercury__code_util__choose_local_label_type_7_0_i4);
	init_label(mercury__code_util__choose_local_label_type_7_0_i1007);
BEGIN_CODE

/* code for predicate 'choose_local_label_type'/7 in mode 0 */
Define_static(mercury__code_util__choose_local_label_type_7_0);
	incr_sp_push_msg(1, "choose_local_label_type");
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__code_util__choose_local_label_type_7_0_i5);
	r1 = (Integer) r6;
	GOTO_LABEL(mercury__code_util__choose_local_label_type_7_0_i4);
Define_label(mercury__code_util__choose_local_label_type_7_0_i5);
	if (((Integer) r4 != (Integer) r2))
		GOTO_LABEL(mercury__code_util__choose_local_label_type_7_0_i1007);
	if (((Integer) r5 != (Integer) r3))
		GOTO_LABEL(mercury__code_util__choose_local_label_type_7_0_i1007);
	r1 = (Integer) r6;
Define_label(mercury__code_util__choose_local_label_type_7_0_i4);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__code_util__choose_local_label_type_7_0_i1007);
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r6;
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module19)
	init_entry(mercury__code_util__builtin_4_0);
	init_label(mercury__code_util__builtin_4_0_i2);
	init_label(mercury__code_util__builtin_4_0_i3);
	init_label(mercury__code_util__builtin_4_0_i1002);
BEGIN_CODE

/* code for predicate 'code_util__builtin'/4 in mode 0 */
Define_static(mercury__code_util__builtin_4_0);
	if (((Integer) r4 > ((Integer) 3)))
		GOTO_LABEL(mercury__code_util__builtin_4_0_i1002);
	incr_sp_push_msg(5, "code_util__builtin");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__code_util__builtin_4_0_i2,
		STATIC(mercury__code_util__builtin_4_0));
	}
Define_label(mercury__code_util__builtin_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_4_0));
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__varset__new_vars_4_0);
	call_localret(ENTRY(mercury__varset__new_vars_4_0),
		mercury__code_util__builtin_4_0_i3,
		STATIC(mercury__code_util__builtin_4_0));
	}
Define_label(mercury__code_util__builtin_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__code_util__translate_builtin_6_0),
		STATIC(mercury__code_util__builtin_4_0));
	}
Define_label(mercury__code_util__builtin_4_0_i1002);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module20)
	init_entry(mercury__code_util__goal_may_allocate_heap_2_1_0);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1026);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1025);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1011);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i20);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i24);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i28);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1024);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i32);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i38);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i35);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i2);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1016);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1017);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1018);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1019);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1020);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1021);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1023);
BEGIN_CODE

/* code for predicate 'code_util__goal_may_allocate_heap_2'/1 in mode 0 */
Define_static(mercury__code_util__goal_may_allocate_heap_2_1_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1024);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1017) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1026) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1018) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1019) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1020) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1025) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1016));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1026);
	incr_sp_push_msg(3, "code_util__goal_may_allocate_heap_2");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1011);
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1025);
	incr_sp_push_msg(3, "code_util__goal_may_allocate_heap_2");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i20);
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1011);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	decr_sp_pop_msg(3);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1021);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i20);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		call_localret(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__code_util__goal_may_allocate_heap_2_1_0_i24,
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i24);
	update_prof_current_proc(LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i2);
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__code_util__goal_may_allocate_heap_2_1_0_i28,
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i28);
	update_prof_current_proc(LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i2);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1024);
	incr_sp_push_msg(3, "code_util__goal_may_allocate_heap_2");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i32);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__code_util__goal_list_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i32);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i35);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		mercury__code_util__goal_may_allocate_heap_2_1_0_i38,
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i38);
	update_prof_current_proc(LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1023);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i35);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1016);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1017);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__code_util__cases_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1018);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__code_util__goal_list_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1019);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1020);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		tailcall(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
	}
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1021);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1023);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module21)
	init_entry(mercury__code_util__cases_may_allocate_heap_1_0);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i6);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i3);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i1003);
BEGIN_CODE

/* code for predicate 'code_util__cases_may_allocate_heap'/1 in mode 0 */
Define_static(mercury__code_util__cases_may_allocate_heap_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cases_may_allocate_heap_1_0_i1003);
	incr_sp_push_msg(2, "code_util__cases_may_allocate_heap");
	detstackvar(2) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	{
		call_localret(STATIC(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__code_util__cases_may_allocate_heap_1_0_i6,
		STATIC(mercury__code_util__cases_may_allocate_heap_1_0));
	}
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i6);
	update_prof_current_proc(LABEL(mercury__code_util__cases_may_allocate_heap_1_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__code_util__cases_may_allocate_heap_1_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_util__cases_may_allocate_heap_1_0,
		STATIC(mercury__code_util__cases_may_allocate_heap_1_0));
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module22)
	init_entry(mercury__code_util__cannot_stack_flush_2_1_0);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1016);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i8);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1001);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1015);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i12);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i16);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1010);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1011);
BEGIN_CODE

/* code for predicate 'code_util__cannot_stack_flush_2'/1 in mode 0 */
Define_static(mercury__code_util__cannot_stack_flush_2_1_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1015);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1011) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1016) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1010) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1010) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1010) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1010) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1010));
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1016);
	incr_sp_push_msg(2, "code_util__cannot_stack_flush_2");
	detstackvar(2) = (Integer) succip;
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i8);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1001);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 == ((Integer) 1)))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1);
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1001);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1015);
	incr_sp_push_msg(2, "code_util__cannot_stack_flush_2");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i12);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__code_util__cannot_stack_flush_goals_1_0),
		STATIC(mercury__code_util__cannot_stack_flush_2_1_0));
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__code_util__cannot_stack_flush_2_1_0_i16,
		STATIC(mercury__code_util__cannot_stack_flush_2_1_0));
	}
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i16);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_stack_flush_2_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	tailcall(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		STATIC(mercury__code_util__cannot_stack_flush_2_1_0));
	}
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1011);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__code_util__cannot_stack_flush_cases_1_0),
		STATIC(mercury__code_util__cannot_stack_flush_2_1_0));
END_MODULE

BEGIN_MODULE(mercury__code_util_module23)
	init_entry(mercury__code_util__cannot_stack_flush_goals_1_0);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i4);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1003);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
BEGIN_CODE

/* code for predicate 'code_util__cannot_stack_flush_goals'/1 in mode 0 */
Define_static(mercury__code_util__cannot_stack_flush_goals_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_goals_1_0_i1003);
	incr_sp_push_msg(2, "code_util__cannot_stack_flush_goals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__code_util__cannot_stack_flush_1_0),
		mercury__code_util__cannot_stack_flush_goals_1_0_i4,
		STATIC(mercury__code_util__cannot_stack_flush_goals_1_0));
	}
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_stack_flush_goals_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_util__cannot_stack_flush_goals_1_0,
		STATIC(mercury__code_util__cannot_stack_flush_goals_1_0));
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module24)
	init_entry(mercury__code_util__cannot_stack_flush_cases_1_0);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i4);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1003);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
BEGIN_CODE

/* code for predicate 'code_util__cannot_stack_flush_cases'/1 in mode 0 */
Define_static(mercury__code_util__cannot_stack_flush_cases_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_cases_1_0_i1003);
	incr_sp_push_msg(2, "code_util__cannot_stack_flush_cases");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	{
		call_localret(STATIC(mercury__code_util__cannot_stack_flush_1_0),
		mercury__code_util__cannot_stack_flush_cases_1_0_i4,
		STATIC(mercury__code_util__cannot_stack_flush_cases_1_0));
	}
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_stack_flush_cases_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_util__cannot_stack_flush_cases_1_0,
		STATIC(mercury__code_util__cannot_stack_flush_cases_1_0));
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__code_util_module25)
	init_entry(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1009);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i4);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i9);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i10);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
BEGIN_CODE

/* code for predicate 'code_util__cannot_fail_before_stack_flush_conj'/1 in mode 0 */
Define_static(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1009);
	incr_sp_push_msg(2, "code_util__cannot_fail_before_stack_flush_conj");
	detstackvar(2) = (Integer) succip;
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i4);
	r1 = TRUE;
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i9,
		STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
	}
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i10,
		STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
	}
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i10);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0,
		STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__code_util_bunch_0(void)
{
	mercury__code_util_module0();
	mercury__code_util_module1();
	mercury__code_util_module2();
	mercury__code_util_module3();
	mercury__code_util_module4();
	mercury__code_util_module5();
	mercury__code_util_module6();
	mercury__code_util_module7();
	mercury__code_util_module8();
	mercury__code_util_module9();
	mercury__code_util_module10();
	mercury__code_util_module11();
	mercury__code_util_module12();
	mercury__code_util_module13();
	mercury__code_util_module14();
	mercury__code_util_module15();
	mercury__code_util_module16();
	mercury__code_util_module17();
	mercury__code_util_module18();
	mercury__code_util_module19();
	mercury__code_util_module20();
	mercury__code_util_module21();
	mercury__code_util_module22();
	mercury__code_util_module23();
	mercury__code_util_module24();
	mercury__code_util_module25();
}

#endif

void mercury__code_util__init(void); /* suppress gcc warning */
void mercury__code_util__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__code_util_bunch_0();
#endif
}
