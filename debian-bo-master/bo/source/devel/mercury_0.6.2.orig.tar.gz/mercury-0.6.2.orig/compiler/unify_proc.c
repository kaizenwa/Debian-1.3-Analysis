/*
** Automatically generated from `unify_proc.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__unify_proc__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___unify_proc_unify_requests_0__ua10000_2_0);
Declare_static(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i4);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i5);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i6);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i7);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i8);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i9);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i10);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i11);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i12);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i13);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i14);
Declare_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i1008);
Define_extern_entry(mercury__unify_proc__init_requests_1_0);
Declare_label(mercury__unify_proc__init_requests_1_0_i2);
Declare_label(mercury__unify_proc__init_requests_1_0_i3);
Define_extern_entry(mercury__unify_proc__request_unify_4_0);
Declare_label(mercury__unify_proc__request_unify_4_0_i4);
Declare_label(mercury__unify_proc__request_unify_4_0_i3);
Declare_label(mercury__unify_proc__request_unify_4_0_i6);
Declare_label(mercury__unify_proc__request_unify_4_0_i7);
Declare_label(mercury__unify_proc__request_unify_4_0_i8);
Declare_label(mercury__unify_proc__request_unify_4_0_i9);
Declare_label(mercury__unify_proc__request_unify_4_0_i10);
Declare_label(mercury__unify_proc__request_unify_4_0_i11);
Declare_label(mercury__unify_proc__request_unify_4_0_i12);
Declare_label(mercury__unify_proc__request_unify_4_0_i13);
Declare_label(mercury__unify_proc__request_unify_4_0_i14);
Declare_label(mercury__unify_proc__request_unify_4_0_i15);
Declare_label(mercury__unify_proc__request_unify_4_0_i16);
Declare_label(mercury__unify_proc__request_unify_4_0_i17);
Declare_label(mercury__unify_proc__request_unify_4_0_i18);
Declare_label(mercury__unify_proc__request_unify_4_0_i19);
Declare_label(mercury__unify_proc__request_unify_4_0_i20);
Declare_label(mercury__unify_proc__request_unify_4_0_i21);
Declare_label(mercury__unify_proc__request_unify_4_0_i22);
Declare_label(mercury__unify_proc__request_unify_4_0_i23);
Define_extern_entry(mercury__unify_proc__modecheck_unify_procs_5_0);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i2);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i5);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i7);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i8);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i15);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i12);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i16);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i17);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i18);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i19);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i20);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i21);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i22);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i23);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i24);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i25);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i26);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i9);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i27);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i28);
Declare_label(mercury__unify_proc__modecheck_unify_procs_5_0_i4);
Define_extern_entry(mercury__unify_proc__lookup_mode_num_5_0);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i4);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i1000);
Define_extern_entry(mercury__unify_proc__generate_clause_info_5_0);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i2);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i3);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i4);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i7);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i8);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i9);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i20);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i16);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i21);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i22);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i23);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i24);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i25);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i26);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i27);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i10);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i29);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i36);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i44);
Declare_label(mercury__unify_proc__generate_clause_info_5_0_i51);
Declare_static(mercury__unify_proc__search_mode_num_5_0);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i5);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i7);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i3);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i2);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i9);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i12);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i15);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i16);
Declare_label(mercury__unify_proc__search_mode_num_5_0_i1000);
Declare_static(mercury__unify_proc__modecheck_unification_proc_6_0);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i2);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i3);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i4);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i5);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i6);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i7);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i8);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i9);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i10);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i11);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i12);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i13);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i14);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i15);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i21);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i16);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i22);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i26);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i27);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i28);
Declare_label(mercury__unify_proc__modecheck_unification_proc_6_0_i23);
Declare_static(mercury__unify_proc__generate_index_clauses_6_0);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i1000);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i7);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i8);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i9);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i10);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i11);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i12);
Declare_label(mercury__unify_proc__generate_index_clauses_6_0_i13);
Declare_static(mercury__unify_proc__generate_compare_clauses_7_0);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i10);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i1025);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i6);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i11);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i12);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i13);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i14);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i15);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i16);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i17);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i18);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i1024);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i19);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i20);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i21);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i22);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i23);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i24);
Declare_label(mercury__unify_proc__generate_compare_clauses_7_0_i25);
Declare_static(mercury__unify_proc__generate_term_to_type_clauses_6_0);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i1000);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i7);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i8);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i9);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i10);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i11);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i12);
Declare_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i13);
Declare_static(mercury__unify_proc__generate_type_to_term_clauses_6_0);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i1000);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i7);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i8);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i9);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i10);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i11);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i12);
Declare_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i13);
Declare_static(mercury__unify_proc__generate_du_unify_clauses_6_0);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i4);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i5);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i6);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i7);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i8);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i9);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i10);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i11);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i12);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i13);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i14);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i15);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i16);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i17);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i18);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i1010);
Declare_static(mercury__unify_proc__generate_du_index_clauses_7_0);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i4);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i5);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i6);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i7);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i8);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i9);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i10);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i11);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i12);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i13);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i14);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i15);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i16);
Declare_label(mercury__unify_proc__generate_du_index_clauses_7_0_i1011);
Declare_static(mercury__unify_proc__generate_du_compare_clauses_2_7_0);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i2);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i3);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i4);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i5);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i6);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i7);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i8);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i9);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i10);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i11);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i12);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i13);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i14);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i15);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i16);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i17);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i18);
Declare_static(mercury__unify_proc__generate_compare_cases_7_0);
Declare_label(mercury__unify_proc__generate_compare_cases_7_0_i4);
Declare_label(mercury__unify_proc__generate_compare_cases_7_0_i5);
Declare_label(mercury__unify_proc__generate_compare_cases_7_0_i1002);
Declare_static(mercury__unify_proc__generate_compare_case_7_0);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i2);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i3);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i4);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i5);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i6);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i7);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i8);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i9);
Declare_label(mercury__unify_proc__generate_compare_case_7_0_i10);
Declare_static(mercury__unify_proc__compare_args_6_0);
Declare_label(mercury__unify_proc__compare_args_6_0_i6);
Declare_label(mercury__unify_proc__compare_args_6_0_i7);
Declare_label(mercury__unify_proc__compare_args_6_0_i12);
Declare_label(mercury__unify_proc__compare_args_6_0_i13);
Declare_label(mercury__unify_proc__compare_args_6_0_i14);
Declare_label(mercury__unify_proc__compare_args_6_0_i15);
Declare_label(mercury__unify_proc__compare_args_6_0_i16);
Declare_label(mercury__unify_proc__compare_args_6_0_i17);
Declare_label(mercury__unify_proc__compare_args_6_0_i18);
Declare_label(mercury__unify_proc__compare_args_6_0_i19);
Declare_label(mercury__unify_proc__compare_args_6_0_i5);
Declare_label(mercury__unify_proc__compare_args_6_0_i21);
Declare_label(mercury__unify_proc__compare_args_6_0_i1000);
Declare_label(mercury__unify_proc__compare_args_6_0_i23);
Declare_label(mercury__unify_proc__compare_args_6_0_i25);
Declare_label(mercury__unify_proc__compare_args_6_0_i26);
Declare_static(mercury__unify_proc__generate_du_term_to_type_clauses_6_0);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i4);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i5);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i6);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i7);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i8);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i9);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i10);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i11);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i12);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i13);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i14);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i15);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i16);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i17);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i18);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i19);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i20);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i21);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i22);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i23);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i24);
Declare_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i1015);
Declare_static(mercury__unify_proc__generate_du_term_to_type_recursive_9_0);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i4);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i5);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i6);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i7);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i8);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i3);
Declare_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i9);
Declare_static(mercury__unify_proc__generate_du_type_to_term_clauses_6_0);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i4);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i5);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i6);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i7);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i8);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i9);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i10);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i11);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i12);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i13);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i14);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i15);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i16);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i17);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i18);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i19);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i20);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i21);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i22);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i23);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i24);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i25);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i26);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i27);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i28);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i29);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i30);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i31);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i32);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i33);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i34);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i35);
Declare_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i1026);
Declare_static(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i4);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i5);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i6);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i7);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i8);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i3);
Declare_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i9);
Declare_static(mercury__unify_proc__build_call_5_0);
Declare_label(mercury__unify_proc__build_call_5_0_i2);
Declare_label(mercury__unify_proc__build_call_5_0_i3);
Declare_label(mercury__unify_proc__build_call_5_0_i6);
Declare_label(mercury__unify_proc__build_call_5_0_i9);
Declare_label(mercury__unify_proc__build_call_5_0_i5);
Declare_label(mercury__unify_proc__build_call_5_0_i11);
Declare_label(mercury__unify_proc__build_call_5_0_i12);
Declare_label(mercury__unify_proc__build_call_5_0_i13);
Declare_label(mercury__unify_proc__build_call_5_0_i14);
Declare_label(mercury__unify_proc__build_call_5_0_i15);
Declare_static(mercury__unify_proc__make_fresh_vars_from_types_4_0);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i4);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i1002);
Declare_static(mercury__unify_proc__make_fresh_vars_4_0);
Declare_label(mercury__unify_proc__make_fresh_vars_4_0_i4);
Declare_label(mercury__unify_proc__make_fresh_vars_4_0_i5);
Declare_label(mercury__unify_proc__make_fresh_vars_4_0_i1002);
Declare_static(mercury__unify_proc__unify_var_lists_3_0);
Declare_label(mercury__unify_proc__unify_var_lists_3_0_i6);
Declare_label(mercury__unify_proc__unify_var_lists_3_0_i7);
Declare_label(mercury__unify_proc__unify_var_lists_3_0_i8);
Declare_label(mercury__unify_proc__unify_var_lists_3_0_i1009);
Declare_label(mercury__unify_proc__unify_var_lists_3_0_i1007);
Declare_label(mercury__unify_proc__unify_var_lists_3_0_i1008);
Declare_static(mercury__unify_proc__info_new_var_4_0);
Declare_label(mercury__unify_proc__info_new_var_4_0_i2);
Declare_label(mercury__unify_proc__info_new_var_4_0_i3);
Declare_static(mercury__unify_proc__info_get_varset_3_0);
Declare_static(mercury__unify_proc__info_set_varset_3_0);
Declare_static(mercury__unify_proc__info_get_types_3_0);
Declare_static(mercury__unify_proc__info_set_types_3_0);
Define_extern_entry(mercury____Unify___unify_proc__unify_requests_0_0);
Declare_label(mercury____Unify___unify_proc__unify_requests_0_0_i2);
Declare_label(mercury____Unify___unify_proc__unify_requests_0_0_i1);
Define_extern_entry(mercury____Index___unify_proc__unify_requests_0_0);
Define_extern_entry(mercury____Compare___unify_proc__unify_requests_0_0);
Declare_label(mercury____Compare___unify_proc__unify_requests_0_0_i4);
Declare_label(mercury____Compare___unify_proc__unify_requests_0_0_i3);
Define_extern_entry(mercury____Unify___unify_proc__unify_proc_id_0_0);
Define_extern_entry(mercury____Index___unify_proc__unify_proc_id_0_0);
Define_extern_entry(mercury____Compare___unify_proc__unify_proc_id_0_0);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_unify_proc__base_type_layout_req_map_0[];
Word * mercury_data_unify_proc__base_type_info_req_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_unify_proc__base_type_layout_req_map_0
};

extern Word * mercury_data_unify_proc__base_type_layout_req_queue_0[];
Word * mercury_data_unify_proc__base_type_info_req_queue_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_unify_proc__base_type_layout_req_queue_0
};

extern Word * mercury_data_unify_proc__base_type_layout_unify_proc_id_0[];
Word * mercury_data_unify_proc__base_type_info_unify_proc_id_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___unify_proc__unify_proc_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___unify_proc__unify_proc_id_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___unify_proc__unify_proc_id_0_0),
	(Word *) (Integer) mercury_data_unify_proc__base_type_layout_unify_proc_id_0
};

extern Word * mercury_data_unify_proc__base_type_layout_unify_proc_info_0[];
Word * mercury_data_unify_proc__base_type_info_unify_proc_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_unify_proc__base_type_layout_unify_proc_info_0
};

extern Word * mercury_data_unify_proc__base_type_layout_unify_requests_0[];
Word * mercury_data_unify_proc__base_type_info_unify_requests_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___unify_proc__unify_requests_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___unify_proc__unify_requests_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___unify_proc__unify_requests_0_0),
	(Word *) (Integer) mercury_data_unify_proc__base_type_layout_unify_requests_0
};

extern Word * mercury_data_unify_proc__common_47[];
Word * mercury_data_unify_proc__base_type_layout_unify_requests_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_47),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_unify_proc__common_51[];
Word * mercury_data_unify_proc__base_type_layout_unify_proc_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_51),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_unify_proc__common_52[];
Word * mercury_data_unify_proc__base_type_layout_unify_proc_id_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_52),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_52),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_52),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_52)
};

extern Word * mercury_data_unify_proc__common_53[];
Word * mercury_data_unify_proc__base_type_layout_req_queue_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_53),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_53),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_53),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_53)
};

extern Word * mercury_data_unify_proc__common_54[];
Word * mercury_data_unify_proc__base_type_layout_req_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_54),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_54),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_54),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_unify_proc__common_54)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data___base_type_info_string_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_unify_proc__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_unify_proc__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_unify_proc__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_hlds_goal__base_type_info_uni_mode_0[];
Word * mercury_data_unify_proc__common_3[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_2),
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0
};

extern Word * mercury_data_special_pred__base_type_info_special_pred_id_0[];
Word * mercury_data_unify_proc__common_4[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_special_pred__base_type_info_special_pred_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_2)
};

Word * mercury_data_unify_proc__common_5[] = {
	(Word *) string_const("int", 3)
};

Word * mercury_data_unify_proc__common_6[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_5),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_7[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("comparison_result", 17)
};

Word * mercury_data_unify_proc__common_8[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_7),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_9[] = {
	(Word *) string_const("<", 1)
};

Word * mercury_data_unify_proc__common_10[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_9),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_11[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_10),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_unify_proc__common_12[] = {
	(Word *) string_const(">", 1)
};

Word * mercury_data_unify_proc__common_13[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_12),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_14[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_13),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_unify_proc__common_15[] = {
	(Word *) string_const("=", 1)
};

Word * mercury_data_unify_proc__common_16[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_15),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_17[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_16),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_unify_proc__common_18[] = {
	(Word *) string_const("term__atom", 10)
};

Word * mercury_data_unify_proc__common_19[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_18),
	(Word *) ((Integer) 1)
};

Word * mercury_data_unify_proc__common_20[] = {
	(Word *) string_const("term__functor", 13)
};

Word * mercury_data_unify_proc__common_21[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_20),
	(Word *) ((Integer) 3)
};

Word * mercury_data_unify_proc__common_22[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("const", 5)
};

Word * mercury_data_unify_proc__common_23[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_22),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_24[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("term", 4)
};

Word * mercury_data_unify_proc__common_25[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_24),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_26[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("list", 4)
};

Word * mercury_data_unify_proc__common_27[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_26),
	(Word *) ((Integer) 1)
};

Word * mercury_data_unify_proc__common_28[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("term__context", 13)
};

Word * mercury_data_unify_proc__common_29[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_28),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_30[] = {
	(Word *) string_const("string", 6)
};

Word * mercury_data_unify_proc__common_31[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_30),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_32[] = {
	(Word *) string_const(".", 1)
};

Word * mercury_data_unify_proc__common_33[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_32),
	(Word *) ((Integer) 2)
};

Word * mercury_data_unify_proc__common_34[] = {
	(Word *) string_const("[]", 2)
};

Word * mercury_data_unify_proc__common_35[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_34),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_36[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_35),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_unify_proc__common_37[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_26),
	(Word *) ((Integer) 0)
};

Word * mercury_data_unify_proc__common_38[] = {
	(Word *) string_const("term__context", 13)
};

Word * mercury_data_unify_proc__common_39[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_38),
	(Word *) ((Integer) 2)
};

Word * mercury_data_unify_proc__common_40[] = {
	(Word *) string_const("", 0)
};

Word * mercury_data_unify_proc__common_41[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_unify_proc__common_40),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_unify_proc__common_42[] = {
	((Integer) 0)
};

Word * mercury_data_unify_proc__common_43[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_42),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_unify_proc__common_44[] = {
	(Word *) string_const("'", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_unify_proc__common_45[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3),
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_queue__base_type_info_queue_1[];
Word * mercury_data_unify_proc__common_46[] = {
	(Word *) (Integer) mercury_data_queue__base_type_info_queue_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3)
};

Word * mercury_data_unify_proc__common_47[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_45),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_46),
	(Word *) string_const("unify_requests", 14)
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_unify_proc__common_48[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_unify_proc__common_49[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_hlds_module__base_type_info_module_info_0[];
Word * mercury_data_unify_proc__common_50[] = {
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_module_info_0
};

Word * mercury_data_unify_proc__common_51[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_48),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_49),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_50),
	(Word *) string_const("unify_proc_info", 15)
};

Word * mercury_data_unify_proc__common_52[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3)
};

Word * mercury_data_unify_proc__common_53[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_46)
};

Word * mercury_data_unify_proc__common_54[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_45)
};

BEGIN_MODULE(mercury__unify_proc_module0)
	init_entry(mercury____Index___unify_proc_unify_requests_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___unify_proc_unify_requests_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___unify_proc_unify_requests_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module1)
	init_entry(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i4);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i5);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i6);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i7);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i8);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i9);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i10);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i11);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i12);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i13);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i14);
	init_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i1008);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_term_to_type_disjunctions__ua10000'/12 in mode 0 */
Define_static(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i1008);
	incr_sp_push_msg(11, "unify_proc__generate_du_term_to_type_disjunctions__ua10000");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(9) = (Integer) r2;
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_0);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i4,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i5,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	detstackvar(10) = (Integer) r2;
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i6,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r2 = (Integer) detstackvar(10);
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i7,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i8,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	detstackvar(9) = (Integer) r1;
	call_localret(STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i9,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(9) = (Integer) r2;
	detstackvar(10) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	r3 = (Integer) r6;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i10,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_1);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i11,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	detstackvar(9) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i12,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i13,
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(10);
	localcall(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0,
		LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i14),
		STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r7;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module2)
	init_entry(mercury__unify_proc__init_requests_1_0);
	init_label(mercury__unify_proc__init_requests_1_0_i2);
	init_label(mercury__unify_proc__init_requests_1_0_i3);
BEGIN_CODE

/* code for predicate 'unify_proc__init_requests'/1 in mode 0 */
Define_entry(mercury__unify_proc__init_requests_1_0);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(2, "unify_proc__init_requests");
	detstackvar(2) = (Integer) succip;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__init_requests_1_0_i2,
		ENTRY(mercury__unify_proc__init_requests_1_0));
	}
Define_label(mercury__unify_proc__init_requests_1_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__init_requests_1_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	{
	Declare_entry(mercury__queue__init_1_0);
	call_localret(ENTRY(mercury__queue__init_1_0),
		mercury__unify_proc__init_requests_1_0_i3,
		ENTRY(mercury__unify_proc__init_requests_1_0));
	}
Define_label(mercury__unify_proc__init_requests_1_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__init_requests_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module3)
	init_entry(mercury__unify_proc__request_unify_4_0);
	init_label(mercury__unify_proc__request_unify_4_0_i4);
	init_label(mercury__unify_proc__request_unify_4_0_i3);
	init_label(mercury__unify_proc__request_unify_4_0_i6);
	init_label(mercury__unify_proc__request_unify_4_0_i7);
	init_label(mercury__unify_proc__request_unify_4_0_i8);
	init_label(mercury__unify_proc__request_unify_4_0_i9);
	init_label(mercury__unify_proc__request_unify_4_0_i10);
	init_label(mercury__unify_proc__request_unify_4_0_i11);
	init_label(mercury__unify_proc__request_unify_4_0_i12);
	init_label(mercury__unify_proc__request_unify_4_0_i13);
	init_label(mercury__unify_proc__request_unify_4_0_i14);
	init_label(mercury__unify_proc__request_unify_4_0_i15);
	init_label(mercury__unify_proc__request_unify_4_0_i16);
	init_label(mercury__unify_proc__request_unify_4_0_i17);
	init_label(mercury__unify_proc__request_unify_4_0_i18);
	init_label(mercury__unify_proc__request_unify_4_0_i19);
	init_label(mercury__unify_proc__request_unify_4_0_i20);
	init_label(mercury__unify_proc__request_unify_4_0_i21);
	init_label(mercury__unify_proc__request_unify_4_0_i22);
	init_label(mercury__unify_proc__request_unify_4_0_i23);
BEGIN_CODE

/* code for predicate 'unify_proc__request_unify'/4 in mode 0 */
Define_entry(mercury__unify_proc__request_unify_4_0);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	incr_sp_push_msg(9, "unify_proc__request_unify");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r3;
	r3 = (Integer) tempr1;
	call_localret(STATIC(mercury__unify_proc__search_mode_num_5_0),
		mercury__unify_proc__request_unify_4_0_i4,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__request_unify_4_0_i3);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__request_unify_4_0_i3);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_get_special_pred_map_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_special_pred_map_2_0),
		mercury__unify_proc__request_unify_4_0_i6,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_4);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__request_unify_4_0_i7,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__unify_proc__request_unify_4_0_i8,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r3 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__request_unify_4_0_i9,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) detstackvar(5);
	tag_incr_hp(detstackvar(5), mktag(1), ((Integer) 2));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 1)), ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	field(mktag(1), (Integer) detstackvar(5), ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 1)), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) detstackvar(5), ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__request_unify_4_0_i10,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__make_hlds__add_new_proc_8_0);
	call_localret(ENTRY(mercury__make_hlds__add_new_proc_8_0),
		mercury__unify_proc__request_unify_4_0_i11,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_proc__request_unify_4_0_i12,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__unify_proc__request_unify_4_0_i13,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__request_unify_4_0_i14,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_can_process_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_can_process_3_0),
		mercury__unify_proc__request_unify_4_0_i15,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__clause_to_proc__copy_clauses_to_proc_4_0);
	call_localret(ENTRY(mercury__clause_to_proc__copy_clauses_to_proc_4_0),
		mercury__unify_proc__request_unify_4_0_i16,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__request_unify_4_0_i17,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__unify_proc__request_unify_4_0_i18,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__request_unify_4_0_i19,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__unify_proc__request_unify_4_0_i20,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_get_unify_requests_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_unify_requests_2_0),
		mercury__unify_proc__request_unify_4_0_i21,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__request_unify_4_0_i22,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
Define_label(mercury__unify_proc__request_unify_4_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(3), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	{
	Declare_entry(mercury__queue__put_3_0);
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__unify_proc__request_unify_4_0_i23,
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
	}
Define_label(mercury__unify_proc__request_unify_4_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__hlds_module__module_info_set_unify_requests_3_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_unify_requests_3_0),
		ENTRY(mercury__unify_proc__request_unify_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module4)
	init_entry(mercury__unify_proc__modecheck_unify_procs_5_0);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i2);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i5);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i7);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i8);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i15);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i12);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i16);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i17);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i18);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i19);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i20);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i21);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i22);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i23);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i24);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i25);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i26);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i9);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i27);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i28);
	init_label(mercury__unify_proc__modecheck_unify_procs_5_0_i4);
BEGIN_CODE

/* code for predicate 'modecheck_unify_procs'/5 in mode 0 */
Define_entry(mercury__unify_proc__modecheck_unify_procs_5_0);
	incr_sp_push_msg(9, "modecheck_unify_procs");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_get_unify_requests_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_unify_requests_2_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i2,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	{
	Declare_entry(mercury__queue__get_3_0);
	call_localret(ENTRY(mercury__queue__get_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i5,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__modecheck_unify_procs_5_0_i4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) tempr1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_set_unify_requests_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_unify_requests_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i7,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = ((Integer) 12);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i8,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_proc__modecheck_unify_procs_5_0_i9);
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 0));
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__modecheck_unify_procs_5_0_i12);
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r1;
	r1 = string_const("% Mode-checking, determinism-checking, and unique-mode-checking\n% ", 66);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i15,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r2 = (Integer) r1;
	r1 = string_const("unification proc for type `", 27);
	GOTO_LABEL(mercury__unify_proc__modecheck_unify_procs_5_0_i17);
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i12);
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r1;
	r1 = string_const("% Mode-checking ", 16);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i16,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r2 = (Integer) r1;
	r1 = string_const("unification proc for type `", 27);
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i17);
	detstackvar(1) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i18,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_out__write_type_id_3_0);
	call_localret(ENTRY(mercury__hlds_out__write_type_id_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i19,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) r1;
	r1 = string_const("'\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i20,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) r1;
	r1 = string_const("% with insts `", 14);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i21,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(7), ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i22,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_inst_4_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_inst_4_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i23,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) r1;
	r1 = string_const("', `", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i24,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_inst_4_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_inst_4_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i25,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r2 = (Integer) r1;
	r1 = string_const("'\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i26,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
	}
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__unify_proc__modecheck_unify_procs_5_0_i27);
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i9);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i27);
	detstackvar(1) = (Integer) r1;
	call_localret(STATIC(mercury__unify_proc__modecheck_unification_proc_6_0),
		mercury__unify_proc__modecheck_unify_procs_5_0_i28,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unify_procs_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__unify_proc__modecheck_unify_procs_5_0,
		ENTRY(mercury__unify_proc__modecheck_unify_procs_5_0));
Define_label(mercury__unify_proc__modecheck_unify_procs_5_0_i4);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module5)
	init_entry(mercury__unify_proc__lookup_mode_num_5_0);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i4);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i1000);
BEGIN_CODE

/* code for predicate 'unify_proc__lookup_mode_num'/5 in mode 0 */
Define_entry(mercury__unify_proc__lookup_mode_num_5_0);
	incr_sp_push_msg(1, "unify_proc__lookup_mode_num");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__unify_proc__search_mode_num_5_0),
		mercury__unify_proc__lookup_mode_num_5_0_i4,
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__lookup_mode_num_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i1000);
	r1 = string_const("unify_proc.m: unify_proc__search_num failed", 43);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module6)
	init_entry(mercury__unify_proc__generate_clause_info_5_0);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i2);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i3);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i4);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i7);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i8);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i9);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i20);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i16);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i21);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i22);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i23);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i24);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i25);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i26);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i27);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i10);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i29);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i36);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i44);
	init_label(mercury__unify_proc__generate_clause_info_5_0_i51);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_clause_info'/5 in mode 0 */
Define_entry(mercury__unify_proc__generate_clause_info_5_0);
	incr_sp_push_msg(7, "unify_proc__generate_clause_info");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__unify_proc__generate_clause_info_5_0_i2,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_5_0_i3,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(4);
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i4);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i7);
Define_label(mercury__unify_proc__generate_clause_info_5_0_i4);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
Define_label(mercury__unify_proc__generate_clause_info_5_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__special_pred__special_pred_info_6_0);
	call_localret(ENTRY(mercury__special_pred__special_pred_info_6_0),
		mercury__unify_proc__generate_clause_info_5_0_i8,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0),
		mercury__unify_proc__generate_clause_info_5_0_i9,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	if (((Integer) detstackvar(1) != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i10);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i10);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i10);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i10);
	r4 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i16);
	if (((Integer) field(mktag(1), (Integer) detstackvar(3), ((Integer) 2)) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i16);
	r3 = (Integer) r4;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(3), ((Integer) 0));
	r2 = (Integer) r5;
	call_localret(STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0),
		mercury__unify_proc__generate_clause_info_5_0_i20,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 5));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i16);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_clause_info_5_0_i21,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_clause_info_5_0_i22,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_clause_info_5_0_i23,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_clause_info_5_0_i24,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	r2 = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(6);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_clause_info_5_0_i25,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_clause_info_5_0_i26,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_clause_info_5_0_i27,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_5_0));
	r2 = (Integer) r1;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__unify_proc__generate_clause_info_5_0_i10);
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i29);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i29);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i29);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i29);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__generate_index_clauses_6_0),
		mercury__unify_proc__generate_clause_info_5_0_i20,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i29);
	if (((Integer) detstackvar(1) != ((Integer) 2)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i36);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i36);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i36);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i36);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i36);
	r5 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__generate_compare_clauses_7_0),
		mercury__unify_proc__generate_clause_info_5_0_i20,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i36);
	if (((Integer) detstackvar(1) != ((Integer) 3)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i44);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i44);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i44);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i44);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0),
		mercury__unify_proc__generate_clause_info_5_0_i20,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
Define_label(mercury__unify_proc__generate_clause_info_5_0_i44);
	if (((Integer) detstackvar(1) != ((Integer) 4)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i51);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i51);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i51);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_5_0_i51);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0),
		mercury__unify_proc__generate_clause_info_5_0_i20,
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
Define_label(mercury__unify_proc__generate_clause_info_5_0_i51);
	r1 = string_const("unknown special pred", 20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unify_proc__generate_clause_info_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module7)
	init_entry(mercury__unify_proc__search_mode_num_5_0);
	init_label(mercury__unify_proc__search_mode_num_5_0_i5);
	init_label(mercury__unify_proc__search_mode_num_5_0_i7);
	init_label(mercury__unify_proc__search_mode_num_5_0_i3);
	init_label(mercury__unify_proc__search_mode_num_5_0_i2);
	init_label(mercury__unify_proc__search_mode_num_5_0_i9);
	init_label(mercury__unify_proc__search_mode_num_5_0_i12);
	init_label(mercury__unify_proc__search_mode_num_5_0_i15);
	init_label(mercury__unify_proc__search_mode_num_5_0_i16);
	init_label(mercury__unify_proc__search_mode_num_5_0_i1000);
BEGIN_CODE

/* code for predicate 'unify_proc__search_mode_num'/5 in mode 0 */
Define_static(mercury__unify_proc__search_mode_num_5_0);
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	r6 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	incr_sp_push_msg(6, "unify_proc__search_mode_num");
	detstackvar(6) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__search_mode_num_5_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r5;
	r2 = (Integer) r6;
	{
	Declare_entry(mercury__mode_util__inst_is_ground_2_0);
	call_localret(ENTRY(mercury__mode_util__inst_is_ground_2_0),
		mercury__unify_proc__search_mode_num_5_0_i5,
		STATIC(mercury__unify_proc__search_mode_num_5_0));
	}
Define_label(mercury__unify_proc__search_mode_num_5_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__search_mode_num_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__search_mode_num_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mode_util__inst_is_ground_2_0);
	call_localret(ENTRY(mercury__mode_util__inst_is_ground_2_0),
		mercury__unify_proc__search_mode_num_5_0_i7,
		STATIC(mercury__unify_proc__search_mode_num_5_0));
	}
Define_label(mercury__unify_proc__search_mode_num_5_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__search_mode_num_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__search_mode_num_5_0_i3);
	r2 = ((Integer) 0);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_proc__search_mode_num_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__unify_proc__search_mode_num_5_0_i2);
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__unify_proc__search_mode_num_5_0_i9);
	r2 = ((Integer) 0);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_proc__search_mode_num_5_0_i9);
	if (((Integer) r5 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__unify_proc__search_mode_num_5_0_i12);
	r2 = ((Integer) 0);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_proc__search_mode_num_5_0_i12);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_get_unify_requests_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_unify_requests_2_0),
		mercury__unify_proc__search_mode_num_5_0_i15,
		STATIC(mercury__unify_proc__search_mode_num_5_0));
	}
Define_label(mercury__unify_proc__search_mode_num_5_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__search_mode_num_5_0));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__unify_proc__search_mode_num_5_0_i16,
		STATIC(mercury__unify_proc__search_mode_num_5_0));
	}
Define_label(mercury__unify_proc__search_mode_num_5_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__search_mode_num_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__search_mode_num_5_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__unify_proc__search_mode_num_5_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module8)
	init_entry(mercury__unify_proc__modecheck_unification_proc_6_0);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i2);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i3);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i4);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i5);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i6);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i7);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i8);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i9);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i10);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i11);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i12);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i13);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i14);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i15);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i21);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i16);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i22);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i26);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i27);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i28);
	init_label(mercury__unify_proc__modecheck_unification_proc_6_0_i23);
BEGIN_CODE

/* code for predicate 'modecheck_unification_proc'/6 in mode 0 */
Define_static(mercury__unify_proc__modecheck_unification_proc_6_0);
	incr_sp_push_msg(9, "modecheck_unification_proc");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_get_special_pred_map_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_special_pred_map_2_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i2,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_4);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__modecheck_unification_proc_6_0_i3,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_get_unify_requests_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_unify_requests_2_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i4,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__modecheck_unification_proc_6_0_i5,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i6,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__modecheck_unification_proc_6_0_i7,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i8,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_proc__modecheck_unification_proc_6_0_i9,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_can_process_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_can_process_3_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i10,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__modecheck_unification_proc_6_0_i11,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i12,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__modecheck_unification_proc_6_0_i13,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i14,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__modes__modecheck_proc_7_0);
	call_localret(ENTRY(mercury__modes__modecheck_proc_7_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i15,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__unify_proc__modecheck_unification_proc_6_0_i16);
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r3;
	r1 = string_const("mode error in compiler-generated unification predicate", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i21,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r4 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__unify_proc__modecheck_unification_proc_6_0_i22);
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i16);
	r5 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i22);
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__modecheck_unification_proc_6_0_i23);
	detstackvar(5) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
	call_localret(ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i26,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__cse_detection__detect_cse_in_proc_6_0);
	call_localret(ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i27,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__det_analysis__determinism_check_proc_6_0);
	call_localret(ENTRY(mercury__det_analysis__determinism_check_proc_6_0),
		mercury__unify_proc__modecheck_unification_proc_6_0_i28,
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_unification_proc_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__unique_modes__check_proc_6_0);
	tailcall(ENTRY(mercury__unique_modes__check_proc_6_0),
		STATIC(mercury__unify_proc__modecheck_unification_proc_6_0));
	}
Define_label(mercury__unify_proc__modecheck_unification_proc_6_0_i23);
	r1 = (Integer) r3;
	r2 = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module9)
	init_entry(mercury__unify_proc__generate_index_clauses_6_0);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i1000);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i7);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i8);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i9);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i10);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i11);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i12);
	init_label(mercury__unify_proc__generate_index_clauses_6_0_i13);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_index_clauses'/6 in mode 0 */
Define_static(mercury__unify_proc__generate_index_clauses_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__generate_index_clauses_6_0_i1000);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__generate_index_clauses_6_0_i1000);
	r5 = (Integer) r4;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = ((Integer) 0);
	tailcall(STATIC(mercury__unify_proc__generate_du_index_clauses_7_0),
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i1000);
	incr_sp_push_msg(4, "unify_proc__generate_index_clauses");
	detstackvar(4) = (Integer) succip;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) r1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = string_const("index", 5);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_index_clauses_6_0_i7,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_index_clauses_6_0_i8,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_index_clauses_6_0_i9,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_index_clauses_6_0_i10,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_index_clauses_6_0_i11,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_index_clauses_6_0_i12,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_index_clauses_6_0_i13,
		STATIC(mercury__unify_proc__generate_index_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_index_clauses_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module10)
	init_entry(mercury__unify_proc__generate_compare_clauses_7_0);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i10);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i1025);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i6);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i11);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i12);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i13);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i14);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i15);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i16);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i17);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i18);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i1024);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i19);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i20);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i21);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i22);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i23);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i24);
	init_label(mercury__unify_proc__generate_compare_clauses_7_0_i25);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_compare_clauses'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_compare_clauses_7_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_7_0_i1024);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_7_0_i1024);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r6 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_7_0_i1025);
	incr_sp_push_msg(4, "unify_proc__generate_compare_clauses");
	detstackvar(4) = (Integer) succip;
	if (((Integer) field(mktag(1), (Integer) r6, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_7_0_i6);
	r1 = (Integer) field(mktag(1), (Integer) r6, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__unify_proc__generate_compare_case_7_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i10,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r4 = (Integer) r2;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	r1 = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_7_0_i12);
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i1025);
	incr_sp_push_msg(4, "unify_proc__generate_compare_clauses");
	detstackvar(4) = (Integer) succip;
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) r6;
	call_localret(STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i11,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r4 = (Integer) r2;
	r2 = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	r1 = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i13,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i14,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i15,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i16,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i17,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i18,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i1024);
	incr_sp_push_msg(4, "unify_proc__generate_compare_clauses");
	detstackvar(4) = (Integer) succip;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = string_const("compare", 7);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i19,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i20,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i21,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i22,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i23,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i24,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_compare_clauses_7_0_i25,
		STATIC(mercury__unify_proc__generate_compare_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_7_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module11)
	init_entry(mercury__unify_proc__generate_term_to_type_clauses_6_0);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i1000);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i7);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i8);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i9);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i10);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i11);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i12);
	init_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i13);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_term_to_type_clauses'/6 in mode 0 */
Define_static(mercury__unify_proc__generate_term_to_type_clauses_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0_i1000);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0),
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i1000);
	incr_sp_push_msg(4, "unify_proc__generate_term_to_type_clauses");
	detstackvar(4) = (Integer) succip;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) r1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = string_const("term_to_type", 12);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i7,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i8,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i9,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i10,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i11,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i12,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_term_to_type_clauses_6_0_i13,
		STATIC(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_term_to_type_clauses_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_term_to_type_clauses_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module12)
	init_entry(mercury__unify_proc__generate_type_to_term_clauses_6_0);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i1000);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i7);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i8);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i9);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i10);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i11);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i12);
	init_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i13);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_type_to_term_clauses'/6 in mode 0 */
Define_static(mercury__unify_proc__generate_type_to_term_clauses_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0_i1000);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0),
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i1000);
	incr_sp_push_msg(4, "unify_proc__generate_type_to_term_clauses");
	detstackvar(4) = (Integer) succip;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) r1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r1 = string_const("type_to_term", 12);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i7,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i8,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i9,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i10,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i11,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i12,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_type_to_term_clauses_6_0_i13,
		STATIC(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_type_to_term_clauses_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_type_to_term_clauses_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module13)
	init_entry(mercury__unify_proc__generate_du_unify_clauses_6_0);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i4);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i5);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i6);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i7);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i8);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i9);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i10);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i11);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i12);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i13);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i14);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i15);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i16);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i17);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i18);
	init_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i1010);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_unify_clauses'/6 in mode 0 */
Define_static(mercury__unify_proc__generate_du_unify_clauses_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0_i1010);
	incr_sp_push_msg(9, "unify_proc__generate_du_unify_clauses");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(6) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_0);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i4,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i5,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i6,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i7,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(8) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i8,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i9,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__unify_var_lists_3_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i10,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i11,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i12,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i13,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i14,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	r2 = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(6);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i15,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(6) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i16,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_du_unify_clauses_6_0_i17,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) tempr1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__unify_proc__generate_du_unify_clauses_6_0,
		LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0_i18),
		STATIC(mercury__unify_proc__generate_du_unify_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__generate_du_unify_clauses_6_0_i1010);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module14)
	init_entry(mercury__unify_proc__generate_du_index_clauses_7_0);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i4);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i5);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i6);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i7);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i8);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i9);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i10);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i11);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i12);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i13);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i14);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i15);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i16);
	init_label(mercury__unify_proc__generate_du_index_clauses_7_0_i1011);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_index_clauses'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_du_index_clauses_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_index_clauses_7_0_i1011);
	incr_sp_push_msg(8, "unify_proc__generate_du_index_clauses");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(7) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_0);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i4,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i5,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i6,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(7) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i7,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i8,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r2 = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i9,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i10,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i11,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i12,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	r2 = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(7);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i13,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(7) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i14,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_du_index_clauses_7_0_i15,
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	r5 = (Integer) r1;
	detstackvar(1) = (Integer) tempr1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) detstackvar(3) + ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__unify_proc__generate_du_index_clauses_7_0,
		LABEL(mercury__unify_proc__generate_du_index_clauses_7_0_i16),
		STATIC(mercury__unify_proc__generate_du_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unify_proc__generate_du_index_clauses_7_0_i1011);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module15)
	init_entry(mercury__unify_proc__generate_du_compare_clauses_2_7_0);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i2);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i3);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i4);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i5);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i6);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i7);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i8);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i9);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i10);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i11);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i12);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i13);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i14);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i15);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i16);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i17);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i18);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_compare_clauses_2'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_du_compare_clauses_2_7_0);
	incr_sp_push_msg(14, "unify_proc__generate_du_compare_clauses_2");
	detstackvar(14) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i2,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_6);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i3,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_8);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i4,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i5,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r3 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i6,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i7,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(8) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i8,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r2 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) r1;
	r1 = string_const("index", 5);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i9,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(10) = (Integer) r1;
	r1 = string_const("index", 5);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i10,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(11) = (Integer) r1;
	r1 = string_const("builtin_int_lt", 14);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i11,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("builtin_int_gt", 14);
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i12,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(13) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_11);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i13,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_14);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i14,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i15,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__unify_proc__generate_compare_cases_7_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i16,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i17,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	tag_incr_hp(detstackvar(4), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r1;
	field(mktag(0), (Integer) detstackvar(4), ((Integer) 0)) = (Integer) tempr1;
	r1 = string_const("compare_error", 13);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) detstackvar(4), ((Integer) 1)) = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_compare_clauses_2_7_0_i18,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_7_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(11);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(r9, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r9, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r9, ((Integer) 3)) = (Integer) detstackvar(12);
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(r11, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r11, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) r11, ((Integer) 3)) = (Integer) detstackvar(2);
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	{
	Word tempr1, tempr2, tempr3;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	tempr2 = (Integer) detstackvar(9);
	tempr3 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r9, ((Integer) 4)) = (Integer) r10;
	field(mktag(3), (Integer) r9, ((Integer) 5)) = (Integer) tempr3;
	field(mktag(3), (Integer) r11, ((Integer) 4)) = (Integer) r12;
	field(mktag(3), (Integer) r11, ((Integer) 5)) = (Integer) tempr3;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) tempr3;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) tempr2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = (Integer) tempr2;
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r10, ((Integer) 1)) = (Integer) tempr2;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r12, ((Integer) 1)) = (Integer) tempr2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module16)
	init_entry(mercury__unify_proc__generate_compare_cases_7_0);
	init_label(mercury__unify_proc__generate_compare_cases_7_0_i4);
	init_label(mercury__unify_proc__generate_compare_cases_7_0_i5);
	init_label(mercury__unify_proc__generate_compare_cases_7_0_i1002);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_compare_cases'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_compare_cases_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_compare_cases_7_0_i1002);
	incr_sp_push_msg(5, "unify_proc__generate_compare_cases");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__unify_proc__generate_compare_case_7_0),
		mercury__unify_proc__generate_compare_cases_7_0_i4,
		STATIC(mercury__unify_proc__generate_compare_cases_7_0));
Define_label(mercury__unify_proc__generate_compare_cases_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_7_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__unify_proc__generate_compare_cases_7_0,
		LABEL(mercury__unify_proc__generate_compare_cases_7_0_i5),
		STATIC(mercury__unify_proc__generate_compare_cases_7_0));
Define_label(mercury__unify_proc__generate_compare_cases_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_proc__generate_compare_cases_7_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module17)
	init_entry(mercury__unify_proc__generate_compare_case_7_0);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i2);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i3);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i4);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i5);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i6);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i7);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i8);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i9);
	init_label(mercury__unify_proc__generate_compare_case_7_0_i10);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_compare_case'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_compare_case_7_0);
	incr_sp_push_msg(8, "unify_proc__generate_compare_case");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_0);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_compare_case_7_0_i2,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_case_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_compare_case_7_0_i3,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_case_7_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_compare_case_7_0_i4,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
Define_label(mercury__unify_proc__generate_compare_case_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_compare_case_7_0_i5,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
Define_label(mercury__unify_proc__generate_compare_case_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	detstackvar(7) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_compare_case_7_0_i6,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_case_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_compare_case_7_0_i7,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_case_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__compare_args_6_0),
		mercury__unify_proc__generate_compare_case_7_0_i8,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
Define_label(mercury__unify_proc__generate_compare_case_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	detstackvar(2) = (Integer) r2;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) detstackvar(2), ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_compare_case_7_0_i9,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_case_7_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_compare_case_7_0_i10,
		STATIC(mercury__unify_proc__generate_compare_case_7_0));
	}
Define_label(mercury__unify_proc__generate_compare_case_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_case_7_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module18)
	init_entry(mercury__unify_proc__compare_args_6_0);
	init_label(mercury__unify_proc__compare_args_6_0_i6);
	init_label(mercury__unify_proc__compare_args_6_0_i7);
	init_label(mercury__unify_proc__compare_args_6_0_i12);
	init_label(mercury__unify_proc__compare_args_6_0_i13);
	init_label(mercury__unify_proc__compare_args_6_0_i14);
	init_label(mercury__unify_proc__compare_args_6_0_i15);
	init_label(mercury__unify_proc__compare_args_6_0_i16);
	init_label(mercury__unify_proc__compare_args_6_0_i17);
	init_label(mercury__unify_proc__compare_args_6_0_i18);
	init_label(mercury__unify_proc__compare_args_6_0_i19);
	init_label(mercury__unify_proc__compare_args_6_0_i5);
	init_label(mercury__unify_proc__compare_args_6_0_i21);
	init_label(mercury__unify_proc__compare_args_6_0_i1000);
	init_label(mercury__unify_proc__compare_args_6_0_i23);
	init_label(mercury__unify_proc__compare_args_6_0_i25);
	init_label(mercury__unify_proc__compare_args_6_0_i26);
BEGIN_CODE

/* code for predicate 'unify_proc__compare_args'/6 in mode 0 */
Define_static(mercury__unify_proc__compare_args_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__compare_args_6_0_i1000);
	incr_sp_push_msg(9, "unify_proc__compare_args");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__compare_args_6_0_i5);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__compare_args_6_0_i6,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	if (((Integer) detstackvar(8) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__compare_args_6_0_i7);
	if (((Integer) detstackvar(4) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__compare_args_6_0_i7);
	r1 = string_const("compare", 7);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(2);
	decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__unify_proc__build_call_5_0),
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i7);
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__compare_args_6_0_i12,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_8);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__compare_args_6_0_i13,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__compare_args_6_0_i14,
		STATIC(mercury__unify_proc__compare_args_6_0));
Define_label(mercury__unify_proc__compare_args_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const("compare", 7);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__compare_args_6_0_i15,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_17);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__compare_args_6_0_i16,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(detstackvar(2), mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) detstackvar(2), ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) detstackvar(2), ((Integer) 1)) = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__compare_args_6_0_i17,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(detstackvar(3), mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) detstackvar(3), ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) detstackvar(3), ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__compare_args_6_0_i18,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(7);
	localcall(mercury__unify_proc__compare_args_6_0,
		LABEL(mercury__unify_proc__compare_args_6_0_i19),
		STATIC(mercury__unify_proc__compare_args_6_0));
Define_label(mercury__unify_proc__compare_args_6_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__unify_proc__compare_args_6_0_i5);
	detstackvar(2) = (Integer) r4;
	r1 = string_const("unify_proc__compare_args: length mismatch", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__compare_args_6_0_i21,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__compare_args_6_0_i1000);
	incr_sp_push_msg(9, "unify_proc__compare_args");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__compare_args_6_0_i23);
	detstackvar(2) = (Integer) r4;
	r1 = string_const("unify_proc__compare_args: length mismatch", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__compare_args_6_0_i21,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i23);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__compare_args_6_0_i25,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_17);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__compare_args_6_0_i26,
		STATIC(mercury__unify_proc__compare_args_6_0));
	}
Define_label(mercury__unify_proc__compare_args_6_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_6_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module19)
	init_entry(mercury__unify_proc__generate_du_term_to_type_clauses_6_0);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i4);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i5);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i6);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i7);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i8);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i9);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i10);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i11);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i12);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i13);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i14);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i15);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i16);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i17);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i18);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i19);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i20);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i21);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i22);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i23);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i24);
	init_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i1015);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_term_to_type_clauses'/6 in mode 0 */
Define_static(mercury__unify_proc__generate_du_term_to_type_clauses_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i1015);
	incr_sp_push_msg(12, "unify_proc__generate_du_term_to_type_clauses");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i4,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(11) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_19);
	detstackvar(10) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_21);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_23);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i5,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i6,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_25);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i7,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	detstackvar(9) = (Integer) r1;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_27);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i8,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i9,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_29);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i10,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i11,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(10) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_21);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(7);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i12,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_31);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i13,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i14,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r3;
	detstackvar(10) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_19);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i15,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__unify_proc__generate_du_term_to_type_disjunctions__ua10000_12_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i16,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i17,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__disj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__disj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i18,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i19,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i20,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i21,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	r2 = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i22,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i23,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i24,
		STATIC(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_clauses_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__unify_proc__generate_du_term_to_type_clauses_6_0_i1015);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module20)
	init_entry(mercury__unify_proc__generate_du_term_to_type_recursive_9_0);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i4);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i5);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i6);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i7);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i8);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i3);
	init_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i9);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_term_to_type_recursive'/9 in mode 0 */
Define_static(mercury__unify_proc__generate_du_term_to_type_recursive_9_0);
	incr_sp_push_msg(9, "unify_proc__generate_du_term_to_type_recursive");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	r2 = (Integer) r6;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i4,
		STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i5,
		STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	detstackvar(8) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_33);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i6,
		STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("term_to_type", 12);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i7,
		STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	r3 = (Integer) detstackvar(2);
	r6 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	localcall(mercury__unify_proc__generate_du_term_to_type_recursive_9_0,
		LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i8),
		STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i3);
	detstackvar(1) = (Integer) r6;
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_36);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i9,
		STATIC(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	}
Define_label(mercury__unify_proc__generate_du_term_to_type_recursive_9_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_term_to_type_recursive_9_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module21)
	init_entry(mercury__unify_proc__generate_du_type_to_term_clauses_6_0);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i4);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i5);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i6);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i7);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i8);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i9);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i10);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i11);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i12);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i13);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i14);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i15);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i16);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i17);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i18);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i19);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i20);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i21);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i22);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i23);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i24);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i25);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i26);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i27);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i28);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i29);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i30);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i31);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i32);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i33);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i34);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i35);
	init_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i1026);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_type_to_term_clauses'/6 in mode 0 */
Define_static(mercury__unify_proc__generate_du_type_to_term_clauses_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i1026);
	incr_sp_push_msg(15, "unify_proc__generate_du_type_to_term_clauses");
	detstackvar(15) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i4,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_0);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i5,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r3 = (Integer) detstackvar(7);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i6,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_23);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i7,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_25);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i8,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_37);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i9,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_29);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i10,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_31);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i11,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i12,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(6) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i13,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i14,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r6 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i15,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r3 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i16,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i17,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	detstackvar(13) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_19);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i18,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i19,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i20,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i21,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(12) = (Integer) r1;
	detstackvar(13) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_6);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i22,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i23,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(14) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_39);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(13);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i24,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_41);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i25,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(13);
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_43);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i26,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_21);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i27,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i28,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(11);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(13);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i29,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	call_localret(STATIC(mercury__unify_proc__info_get_varset_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i30,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__unify_proc__info_get_types_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i31,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	r2 = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i32,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i32);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(5) = (Integer) r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i33,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i33);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i34,
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i34);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) tempr1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__unify_proc__generate_du_type_to_term_clauses_6_0,
		LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i35),
		STATIC(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i35);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_clauses_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__unify_proc__generate_du_type_to_term_clauses_6_0_i1026);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module22)
	init_entry(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i4);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i5);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i6);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i7);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i8);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i3);
	init_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i9);
BEGIN_CODE

/* code for predicate 'unify_proc__generate_du_type_to_term_recursive_clauses'/8 in mode 0 */
Define_static(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0);
	incr_sp_push_msg(8, "unify_proc__generate_du_type_to_term_recursive_clauses");
	detstackvar(8) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	r2 = (Integer) r6;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i4,
		STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i5,
		STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("type_to_term", 12);
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_proc__build_call_5_0),
		mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i6,
		STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	r4 = (Integer) detstackvar(7);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	detstackvar(7) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_33);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i7,
		STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	}
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(7);
	localcall(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0,
		LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i8),
		STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i3);
	detstackvar(1) = (Integer) r6;
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_36);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i9,
		STATIC(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_type_to_term_recursive_clauses_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module23)
	init_entry(mercury__unify_proc__build_call_5_0);
	init_label(mercury__unify_proc__build_call_5_0_i2);
	init_label(mercury__unify_proc__build_call_5_0_i3);
	init_label(mercury__unify_proc__build_call_5_0_i6);
	init_label(mercury__unify_proc__build_call_5_0_i9);
	init_label(mercury__unify_proc__build_call_5_0_i5);
	init_label(mercury__unify_proc__build_call_5_0_i11);
	init_label(mercury__unify_proc__build_call_5_0_i12);
	init_label(mercury__unify_proc__build_call_5_0_i13);
	init_label(mercury__unify_proc__build_call_5_0_i14);
	init_label(mercury__unify_proc__build_call_5_0_i15);
BEGIN_CODE

/* code for predicate 'unify_proc__build_call'/5 in mode 0 */
Define_static(mercury__unify_proc__build_call_5_0);
	incr_sp_push_msg(6, "unify_proc__build_call");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__unify_proc__build_call_5_0_i2,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__build_call_5_0_i3,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("mercury_builtin", 15);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_table_search_pred_m_n_a_5_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_pred_m_n_a_5_0),
		mercury__unify_proc__build_call_5_0_i6,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__build_call_5_0_i5);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__build_call_5_0_i5);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__unify_proc__build_call_5_0_i9,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_proc__build_call_5_0_i5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = ((Integer) 0);
	r1 = ((Integer) 1);
	r2 = ((Integer) 1);
	GOTO_LABEL(mercury__unify_proc__build_call_5_0_i13);
Define_label(mercury__unify_proc__build_call_5_0_i5);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unify_proc__build_call: ", 24);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("invalid/ambiguous pred `mercury_builtin:", 40);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_proc__common_44);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__unify_proc__build_call_5_0_i11,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__build_call_5_0_i12,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
Define_label(mercury__unify_proc__build_call_5_0_i13);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_make_builtin_3_0),
		mercury__unify_proc__build_call_5_0_i14,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(1), ((Integer) 6));
	field(mktag(1), (Integer) r3, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 3)) = (Integer) r1;
	field(mktag(1), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 5)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__build_call_5_0_i15,
		STATIC(mercury__unify_proc__build_call_5_0));
	}
Define_label(mercury__unify_proc__build_call_5_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module24)
	init_entry(mercury__unify_proc__make_fresh_vars_from_types_4_0);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i4);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i1002);
BEGIN_CODE

/* code for predicate 'unify_proc__make_fresh_vars_from_types'/4 in mode 0 */
Define_static(mercury__unify_proc__make_fresh_vars_from_types_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0_i1002);
	incr_sp_push_msg(2, "unify_proc__make_fresh_vars_from_types");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__make_fresh_vars_from_types_4_0_i4,
		STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__unify_proc__make_fresh_vars_from_types_4_0,
		LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5),
		STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module25)
	init_entry(mercury__unify_proc__make_fresh_vars_4_0);
	init_label(mercury__unify_proc__make_fresh_vars_4_0_i4);
	init_label(mercury__unify_proc__make_fresh_vars_4_0_i5);
	init_label(mercury__unify_proc__make_fresh_vars_4_0_i1002);
BEGIN_CODE

/* code for predicate 'unify_proc__make_fresh_vars'/4 in mode 0 */
Define_static(mercury__unify_proc__make_fresh_vars_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__make_fresh_vars_4_0_i1002);
	incr_sp_push_msg(2, "unify_proc__make_fresh_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__make_fresh_vars_4_0_i4,
		STATIC(mercury__unify_proc__make_fresh_vars_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__unify_proc__make_fresh_vars_4_0,
		LABEL(mercury__unify_proc__make_fresh_vars_4_0_i5),
		STATIC(mercury__unify_proc__make_fresh_vars_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_4_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__unify_proc__make_fresh_vars_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module26)
	init_entry(mercury__unify_proc__unify_var_lists_3_0);
	init_label(mercury__unify_proc__unify_var_lists_3_0_i6);
	init_label(mercury__unify_proc__unify_var_lists_3_0_i7);
	init_label(mercury__unify_proc__unify_var_lists_3_0_i8);
	init_label(mercury__unify_proc__unify_var_lists_3_0_i1009);
	init_label(mercury__unify_proc__unify_var_lists_3_0_i1007);
	init_label(mercury__unify_proc__unify_var_lists_3_0_i1008);
BEGIN_CODE

/* code for predicate 'unify_proc__unify_var_lists'/3 in mode 0 */
Define_static(mercury__unify_proc__unify_var_lists_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_3_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_3_0_i1007);
	incr_sp_push_msg(5, "unify_proc__unify_var_lists");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__unify_var_lists_3_0_i6,
		STATIC(mercury__unify_proc__unify_var_lists_3_0));
	}
Define_label(mercury__unify_proc__unify_var_lists_3_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_3_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__unify_var_lists_3_0_i7,
		STATIC(mercury__unify_proc__unify_var_lists_3_0));
	}
Define_label(mercury__unify_proc__unify_var_lists_3_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	localcall(mercury__unify_proc__unify_var_lists_3_0,
		LABEL(mercury__unify_proc__unify_var_lists_3_0_i8),
		STATIC(mercury__unify_proc__unify_var_lists_3_0));
Define_label(mercury__unify_proc__unify_var_lists_3_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_proc__unify_var_lists_3_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_3_0_i1008);
	r1 = string_const("unify_proc__unify_var_lists: length mismatch", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__unify_var_lists_3_0));
	}
Define_label(mercury__unify_proc__unify_var_lists_3_0_i1007);
	r1 = string_const("unify_proc__unify_var_lists: length mismatch", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__unify_var_lists_3_0));
	}
Define_label(mercury__unify_proc__unify_var_lists_3_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module27)
	init_entry(mercury__unify_proc__info_new_var_4_0);
	init_label(mercury__unify_proc__info_new_var_4_0_i2);
	init_label(mercury__unify_proc__info_new_var_4_0_i3);
BEGIN_CODE

/* code for predicate 'unify_proc__info_new_var'/4 in mode 0 */
Define_static(mercury__unify_proc__info_new_var_4_0);
	incr_sp_push_msg(4, "unify_proc__info_new_var");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__varset__new_var_3_0);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__unify_proc__info_new_var_4_0_i2,
		STATIC(mercury__unify_proc__info_new_var_4_0));
	}
Define_label(mercury__unify_proc__info_new_var_4_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__info_new_var_4_0));
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__info_new_var_4_0_i3,
		STATIC(mercury__unify_proc__info_new_var_4_0));
	}
Define_label(mercury__unify_proc__info_new_var_4_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__info_new_var_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module28)
	init_entry(mercury__unify_proc__info_get_varset_3_0);
BEGIN_CODE

/* code for predicate 'unify_proc__info_get_varset'/3 in mode 0 */
Define_static(mercury__unify_proc__info_get_varset_3_0);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module29)
	init_entry(mercury__unify_proc__info_set_varset_3_0);
BEGIN_CODE

/* code for predicate 'unify_proc__info_set_varset'/3 in mode 0 */
Define_static(mercury__unify_proc__info_set_varset_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module30)
	init_entry(mercury__unify_proc__info_get_types_3_0);
BEGIN_CODE

/* code for predicate 'unify_proc__info_get_types'/3 in mode 0 */
Define_static(mercury__unify_proc__info_get_types_3_0);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module31)
	init_entry(mercury__unify_proc__info_set_types_3_0);
BEGIN_CODE

/* code for predicate 'unify_proc__info_set_types'/3 in mode 0 */
Define_static(mercury__unify_proc__info_set_types_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module32)
	init_entry(mercury____Unify___unify_proc__unify_requests_0_0);
	init_label(mercury____Unify___unify_proc__unify_requests_0_0_i2);
	init_label(mercury____Unify___unify_proc__unify_requests_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___unify_proc__unify_requests_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___unify_proc__unify_requests_0_0_i2,
		ENTRY(mercury____Unify___unify_proc__unify_requests_0_0));
	}
Define_label(mercury____Unify___unify_proc__unify_requests_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___unify_proc__unify_requests_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___unify_proc__unify_requests_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___queue__queue_1_0);
	tailcall(ENTRY(mercury____Unify___queue__queue_1_0),
		ENTRY(mercury____Unify___unify_proc__unify_requests_0_0));
	}
Define_label(mercury____Unify___unify_proc__unify_requests_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module33)
	init_entry(mercury____Index___unify_proc__unify_requests_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___unify_proc__unify_requests_0_0);
	tailcall(STATIC(mercury____Index___unify_proc_unify_requests_0__ua10000_2_0),
		ENTRY(mercury____Index___unify_proc__unify_requests_0_0));
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module34)
	init_entry(mercury____Compare___unify_proc__unify_requests_0_0);
	init_label(mercury____Compare___unify_proc__unify_requests_0_0_i4);
	init_label(mercury____Compare___unify_proc__unify_requests_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___unify_proc__unify_requests_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___unify_proc__unify_requests_0_0_i4,
		ENTRY(mercury____Compare___unify_proc__unify_requests_0_0));
	}
Define_label(mercury____Compare___unify_proc__unify_requests_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___unify_proc__unify_requests_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___unify_proc__unify_requests_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___unify_proc__unify_requests_0_0_i3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Compare___queue__queue_1_0);
	tailcall(ENTRY(mercury____Compare___queue__queue_1_0),
		ENTRY(mercury____Compare___unify_proc__unify_requests_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module35)
	init_entry(mercury____Unify___unify_proc__unify_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___unify_proc__unify_proc_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_2);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___unify_proc__unify_proc_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module36)
	init_entry(mercury____Index___unify_proc__unify_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___unify_proc__unify_proc_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_2);
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___unify_proc__unify_proc_id_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_proc_module37)
	init_entry(mercury____Compare___unify_proc__unify_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___unify_proc__unify_proc_id_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_proc__common_2);
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_uni_mode_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___unify_proc__unify_proc_id_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__unify_proc_bunch_0(void)
{
	mercury__unify_proc_module0();
	mercury__unify_proc_module1();
	mercury__unify_proc_module2();
	mercury__unify_proc_module3();
	mercury__unify_proc_module4();
	mercury__unify_proc_module5();
	mercury__unify_proc_module6();
	mercury__unify_proc_module7();
	mercury__unify_proc_module8();
	mercury__unify_proc_module9();
	mercury__unify_proc_module10();
	mercury__unify_proc_module11();
	mercury__unify_proc_module12();
	mercury__unify_proc_module13();
	mercury__unify_proc_module14();
	mercury__unify_proc_module15();
	mercury__unify_proc_module16();
	mercury__unify_proc_module17();
	mercury__unify_proc_module18();
	mercury__unify_proc_module19();
	mercury__unify_proc_module20();
	mercury__unify_proc_module21();
	mercury__unify_proc_module22();
	mercury__unify_proc_module23();
	mercury__unify_proc_module24();
	mercury__unify_proc_module25();
	mercury__unify_proc_module26();
	mercury__unify_proc_module27();
	mercury__unify_proc_module28();
	mercury__unify_proc_module29();
	mercury__unify_proc_module30();
	mercury__unify_proc_module31();
	mercury__unify_proc_module32();
	mercury__unify_proc_module33();
	mercury__unify_proc_module34();
	mercury__unify_proc_module35();
	mercury__unify_proc_module36();
	mercury__unify_proc_module37();
}

#endif

void mercury__unify_proc__init(void); /* suppress gcc warning */
void mercury__unify_proc__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__unify_proc_bunch_0();
#endif
}
