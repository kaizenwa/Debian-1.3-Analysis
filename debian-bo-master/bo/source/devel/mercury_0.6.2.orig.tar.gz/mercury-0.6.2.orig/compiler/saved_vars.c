/*
** Automatically generated from `saved_vars.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__saved_vars__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__saved_vars__saved_vars_proc__ua10000_3_0);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i2);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i3);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i4);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i5);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i6);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i7);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i8);
Declare_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i9);
Define_extern_entry(mercury__saved_vars__saved_vars_proc_3_0);
Declare_static(mercury__saved_vars__saved_vars_in_goal_4_0);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1007);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1006);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1005);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1004);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1003);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1002);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i5);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i6);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i8);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i9);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i10);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i11);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i12);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i13);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i14);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i15);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i16);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i17);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1000);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i20);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i21);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i22);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
Declare_label(mercury__saved_vars__saved_vars_in_goal_4_0_i24);
Declare_static(mercury__saved_vars__saved_vars_in_conj_5_0);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i9);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i11);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i14);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i19);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i22);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i21);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i18);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i13);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i29);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i30);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i31);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i32);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i5);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i1012);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i4);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i34);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i35);
Declare_label(mercury__saved_vars__saved_vars_in_conj_5_0_i1010);
Declare_static(mercury__saved_vars__skip_constant_constructs_3_0);
Declare_label(mercury__saved_vars__skip_constant_constructs_3_0_i9);
Declare_label(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
Declare_label(mercury__saved_vars__skip_constant_constructs_3_0_i1006);
Declare_static(mercury__saved_vars__saved_vars_delay_goal_7_0);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i4);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i7);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i12);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i15);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i17);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i14);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i18);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i19);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i21);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i22);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i23);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i24);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i25);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i26);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i27);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i29);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i30);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i31);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i32);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i1035);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i35);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i36);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i37);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i38);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i39);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i41);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i42);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i43);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i44);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i11);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i52);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i51);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i6);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i63);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i3);
Declare_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i1045);
Declare_static(mercury__saved_vars__push_into_goal_6_0);
Declare_label(mercury__saved_vars__push_into_goal_6_0_i2);
Declare_label(mercury__saved_vars__push_into_goal_6_0_i3);
Declare_label(mercury__saved_vars__push_into_goal_6_0_i4);
Declare_label(mercury__saved_vars__push_into_goal_6_0_i5);
Declare_static(mercury__saved_vars__push_into_goal_rename_6_0);
Declare_label(mercury__saved_vars__push_into_goal_rename_6_0_i2);
Declare_label(mercury__saved_vars__push_into_goal_rename_6_0_i5);
Declare_label(mercury__saved_vars__push_into_goal_rename_6_0_i7);
Declare_label(mercury__saved_vars__push_into_goal_rename_6_0_i8);
Declare_label(mercury__saved_vars__push_into_goal_rename_6_0_i9);
Declare_label(mercury__saved_vars__push_into_goal_rename_6_0_i4);
Declare_static(mercury__saved_vars__push_into_goals_rename_6_0);
Declare_label(mercury__saved_vars__push_into_goals_rename_6_0_i4);
Declare_label(mercury__saved_vars__push_into_goals_rename_6_0_i5);
Declare_label(mercury__saved_vars__push_into_goals_rename_6_0_i1002);
Declare_static(mercury__saved_vars__push_into_cases_rename_6_0);
Declare_label(mercury__saved_vars__push_into_cases_rename_6_0_i4);
Declare_label(mercury__saved_vars__push_into_cases_rename_6_0_i5);
Declare_label(mercury__saved_vars__push_into_cases_rename_6_0_i1003);
Declare_static(mercury__saved_vars__saved_vars_in_disj_4_0);
Declare_label(mercury__saved_vars__saved_vars_in_disj_4_0_i4);
Declare_label(mercury__saved_vars__saved_vars_in_disj_4_0_i5);
Declare_label(mercury__saved_vars__saved_vars_in_disj_4_0_i1002);
Declare_static(mercury__saved_vars__saved_vars_in_switch_4_0);
Declare_label(mercury__saved_vars__saved_vars_in_switch_4_0_i4);
Declare_label(mercury__saved_vars__saved_vars_in_switch_4_0_i5);
Declare_label(mercury__saved_vars__saved_vars_in_switch_4_0_i1003);
Declare_static(mercury__saved_vars__rename_var_5_0);
Declare_label(mercury__saved_vars__rename_var_5_0_i2);
Declare_label(mercury__saved_vars__rename_var_5_0_i3);
Declare_label(mercury__saved_vars__rename_var_5_0_i4);
Declare_label(mercury__saved_vars__rename_var_5_0_i5);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_saved_vars__base_type_layout_slot_info_0[];
Word * mercury_data_saved_vars__base_type_info_slot_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_saved_vars__base_type_layout_slot_info_0
};

extern Word * mercury_data_saved_vars__common_3[];
Word * mercury_data_saved_vars__base_type_layout_slot_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_saved_vars__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_saved_vars__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_saved_vars__common_1[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_saved_vars__common_2[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_saved_vars__common_3[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_saved_vars__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_saved_vars__common_2),
	(Word *) string_const("slot_info", 9)
};

BEGIN_MODULE(mercury__saved_vars_module0)
	init_entry(mercury__saved_vars__saved_vars_proc__ua10000_3_0);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i2);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i3);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i4);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i5);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i6);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i7);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i8);
	init_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i9);
BEGIN_CODE

/* code for predicate 'saved_vars_proc__ua10000'/3 in mode 0 */
Define_static(mercury__saved_vars__saved_vars_proc__ua10000_3_0);
	incr_sp_push_msg(5, "saved_vars_proc__ua10000");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i2,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i3,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i3);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i4,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_goal_4_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i5,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i6,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i6);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i7,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i7);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i8,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i8);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_variables_3_0),
		mercury__saved_vars__saved_vars_proc__ua10000_3_0_i9,
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
Define_label(mercury__saved_vars__saved_vars_proc__ua10000_3_0_i9);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module1)
	init_entry(mercury__saved_vars__saved_vars_proc_3_0);
BEGIN_CODE

/* code for predicate 'saved_vars_proc'/3 in mode 0 */
Define_entry(mercury__saved_vars__saved_vars_proc_3_0);
	tailcall(STATIC(mercury__saved_vars__saved_vars_proc__ua10000_3_0),
		ENTRY(mercury__saved_vars__saved_vars_proc_3_0));
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module2)
	init_entry(mercury__saved_vars__saved_vars_in_goal_4_0);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1007);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1006);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1005);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1004);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1003);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1002);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i5);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i6);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i8);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i9);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i10);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i11);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i12);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i13);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i14);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i15);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i16);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i17);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1000);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i20);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i21);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i22);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	init_label(mercury__saved_vars__saved_vars_in_goal_4_0_i24);
BEGIN_CODE

/* code for predicate 'saved_vars_in_goal'/4 in mode 0 */
Define_static(mercury__saved_vars__saved_vars_in_goal_4_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1000);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)),
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1007) AND
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1006) AND
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1005) AND
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1004) AND
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1003) AND
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1002) AND
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i1006));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1007);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i5);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1006);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1005);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i8);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1004);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i10);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1003);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i12);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1002);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i14);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i5);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_switch_4_0),
		mercury__saved_vars__saved_vars_in_goal_4_0_i6,
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i8);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_disj_4_0),
		mercury__saved_vars__saved_vars_in_goal_4_0_i9,
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i10);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	localcall(mercury__saved_vars__saved_vars_in_goal_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i11),
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i11);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i12);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	localcall(mercury__saved_vars__saved_vars_in_goal_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i13),
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i13);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i14);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	localcall(mercury__saved_vars__saved_vars_in_goal_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i15),
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__saved_vars__saved_vars_in_goal_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i16),
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i16);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__saved_vars__saved_vars_in_goal_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i17),
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i17);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i1000);
	incr_sp_push_msg(6, "saved_vars_in_goal");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__saved_vars__saved_vars_in_goal_4_0_i20,
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i20);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_conj_5_0),
		mercury__saved_vars__saved_vars_in_goal_4_0_i21,
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i21);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__saved_vars__saved_vars_in_goal_4_0_i22,
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i22);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(2);
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__f_cut_0_0);
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__saved_vars__saved_vars_in_goal_4_0_i24,
		STATIC(mercury__saved_vars__saved_vars_in_goal_4_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_goal_4_0_i24);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_goal_4_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module3)
	init_entry(mercury__saved_vars__saved_vars_in_conj_5_0);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i9);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i11);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i14);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i19);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i22);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i21);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i18);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i13);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i29);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i30);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i31);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i32);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i5);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i1012);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i4);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i34);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i35);
	init_label(mercury__saved_vars__saved_vars_in_conj_5_0_i1010);
BEGIN_CODE

/* code for predicate 'saved_vars_in_conj'/5 in mode 0 */
Define_static(mercury__saved_vars__saved_vars_in_conj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i1010);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r6 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	if ((tag((Integer) r6) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i1012);
	if (((Integer) field(mktag(3), (Integer) r6, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i1012);
	if ((tag((Integer) field(mktag(3), (Integer) r6, ((Integer) 4))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i1012);
	incr_sp_push_msg(9, "saved_vars_in_conj");
	detstackvar(9) = (Integer) succip;
	if (((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r6, ((Integer) 4)), ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r6, ((Integer) 4)), ((Integer) 0));
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__saved_vars__skip_constant_constructs_3_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i9,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i9);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i5);
	detstackvar(6) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i11,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i11);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i14,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i14);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i13);
	r1 = (Integer) detstackvar(8);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i18);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i19) AND
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i5) AND
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i21) AND
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i21) AND
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i21) AND
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i21) AND
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i5));
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i19);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i22,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i22);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i5);
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i21);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i29);
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i18);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i29);
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i13);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i29);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i30,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i30);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i31,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i31);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	detstackvar(8) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_saved_vars__common_0);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__saved_vars__saved_vars_in_conj_5_0_i32,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
	}
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i32);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__saved_vars__saved_vars_in_conj_5_0,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i4);
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i1012);
	incr_sp_push_msg(9, "saved_vars_in_conj");
	detstackvar(9) = (Integer) succip;
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r5;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_goal_4_0),
		mercury__saved_vars__saved_vars_in_conj_5_0_i34,
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i34);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	localcall(mercury__saved_vars__saved_vars_in_conj_5_0,
		LABEL(mercury__saved_vars__saved_vars_in_conj_5_0_i35),
		STATIC(mercury__saved_vars__saved_vars_in_conj_5_0));
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i35);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_conj_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__saved_vars__saved_vars_in_conj_5_0_i1010);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module4)
	init_entry(mercury__saved_vars__skip_constant_constructs_3_0);
	init_label(mercury__saved_vars__skip_constant_constructs_3_0_i9);
	init_label(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
	init_label(mercury__saved_vars__skip_constant_constructs_3_0_i1006);
BEGIN_CODE

/* code for predicate 'skip_constant_constructs'/3 in mode 0 */
Define_static(mercury__saved_vars__skip_constant_constructs_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__skip_constant_constructs_3_0_i1006);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 4))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
	if (((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r2, ((Integer) 4)), ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
	incr_sp_push_msg(2, "skip_constant_constructs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__saved_vars__skip_constant_constructs_3_0,
		LABEL(mercury__saved_vars__skip_constant_constructs_3_0_i9),
		STATIC(mercury__saved_vars__skip_constant_constructs_3_0));
Define_label(mercury__saved_vars__skip_constant_constructs_3_0_i9);
	update_prof_current_proc(LABEL(mercury__saved_vars__skip_constant_constructs_3_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__saved_vars__skip_constant_constructs_3_0_i1007);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__saved_vars__skip_constant_constructs_3_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module5)
	init_entry(mercury__saved_vars__saved_vars_delay_goal_7_0);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i4);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i7);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i12);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i15);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i17);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i14);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i18);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i19);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i21);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i22);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i23);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i24);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i25);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i26);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i27);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i29);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i30);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i31);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i32);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i1035);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i35);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i36);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i37);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i38);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i39);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i41);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i42);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i43);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i44);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i11);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i52);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i51);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i6);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i63);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i3);
	init_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i1045);
BEGIN_CODE

/* code for predicate 'saved_vars_delay_goal'/7 in mode 0 */
Define_static(mercury__saved_vars__saved_vars_delay_goal_7_0);
	incr_sp_push_msg(13, "saved_vars_delay_goal");
	detstackvar(13) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) tempr1;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(8) = (Integer) r1;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i4,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i7,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i7);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i6);
	r1 = (Integer) detstackvar(7);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i11);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i12) AND
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i21) AND
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i26) AND
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i29) AND
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i35) AND
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i41) AND
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i21));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i12);
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(10) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i15,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i15);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i14);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i17),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i17);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i14);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__saved_vars__push_into_cases_rename_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i18,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i18);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) detstackvar(7);
	tag_incr_hp(detstackvar(7), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	r5 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 1)) = (Integer) detstackvar(8);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i19),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i19);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i21);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__rename_var_5_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i22,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i22);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r1 = (Integer) detstackvar(1);
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r3;
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i23,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i23);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i24,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i24);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r5 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i25),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i25);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i26);
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__saved_vars__push_into_goals_rename_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i27,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i27);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) detstackvar(7);
	tag_incr_hp(detstackvar(7), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	r5 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 1)) = (Integer) detstackvar(8);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i19),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i29);
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__rename_var_5_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i30,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i30);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	detstackvar(9) = (Integer) r2;
	detstackvar(10) = (Integer) r3;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i31,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i31);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i32,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i32);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__saved_vars__push_into_goal_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i1035,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i1035);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	tag_incr_hp(detstackvar(7), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	r5 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 1)) = (Integer) detstackvar(8);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i19),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i35);
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__rename_var_5_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i36,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i36);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	detstackvar(12) = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i37,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i37);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r2 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i38,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i38);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__saved_vars__push_into_goal_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i39,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i39);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) detstackvar(7);
	tag_incr_hp(detstackvar(7), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	r5 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 1)) = (Integer) detstackvar(8);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i19),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i41);
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(10) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__saved_vars__push_into_goal_rename_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i42,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i42);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) tempr1;
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__push_into_goal_rename_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i43,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i43);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	detstackvar(10) = (Integer) tempr1;
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__push_into_goal_rename_6_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i44,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i44);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) detstackvar(7);
	tag_incr_hp(detstackvar(7), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	r5 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) detstackvar(7), ((Integer) 1)) = (Integer) detstackvar(8);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i19),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i11);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i51);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_saved_vars__common_0);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i52,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
	}
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i52);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	localtailcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i51);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i21);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__saved_vars__rename_var_5_0),
		mercury__saved_vars__saved_vars_delay_goal_7_0_i22,
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i6);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	localcall(mercury__saved_vars__saved_vars_delay_goal_7_0,
		LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i63),
		STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0));
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i63);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i3);
	if (((Integer) r4 == ((Integer) 0)))
		GOTO_LABEL(mercury__saved_vars__saved_vars_delay_goal_7_0_i1045);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__saved_vars__saved_vars_delay_goal_7_0_i1045);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module6)
	init_entry(mercury__saved_vars__push_into_goal_6_0);
	init_label(mercury__saved_vars__push_into_goal_6_0_i2);
	init_label(mercury__saved_vars__push_into_goal_6_0_i3);
	init_label(mercury__saved_vars__push_into_goal_6_0_i4);
	init_label(mercury__saved_vars__push_into_goal_6_0_i5);
BEGIN_CODE

/* code for predicate 'push_into_goal'/6 in mode 0 */
Define_static(mercury__saved_vars__push_into_goal_6_0);
	incr_sp_push_msg(5, "push_into_goal");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) r4;
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_goal_4_0),
		mercury__saved_vars__push_into_goal_6_0_i2,
		STATIC(mercury__saved_vars__push_into_goal_6_0));
Define_label(mercury__saved_vars__push_into_goal_6_0_i2);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_6_0));
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__saved_vars__push_into_goal_6_0_i3,
		STATIC(mercury__saved_vars__push_into_goal_6_0));
	}
Define_label(mercury__saved_vars__push_into_goal_6_0_i3);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__saved_vars__saved_vars_delay_goal_7_0),
		mercury__saved_vars__push_into_goal_6_0_i4,
		STATIC(mercury__saved_vars__push_into_goal_6_0));
Define_label(mercury__saved_vars__push_into_goal_6_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_6_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__saved_vars__push_into_goal_6_0_i5,
		STATIC(mercury__saved_vars__push_into_goal_6_0));
	}
Define_label(mercury__saved_vars__push_into_goal_6_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_6_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module7)
	init_entry(mercury__saved_vars__push_into_goal_rename_6_0);
	init_label(mercury__saved_vars__push_into_goal_rename_6_0_i2);
	init_label(mercury__saved_vars__push_into_goal_rename_6_0_i5);
	init_label(mercury__saved_vars__push_into_goal_rename_6_0_i7);
	init_label(mercury__saved_vars__push_into_goal_rename_6_0_i8);
	init_label(mercury__saved_vars__push_into_goal_rename_6_0_i9);
	init_label(mercury__saved_vars__push_into_goal_rename_6_0_i4);
BEGIN_CODE

/* code for predicate 'push_into_goal_rename'/6 in mode 0 */
Define_static(mercury__saved_vars__push_into_goal_rename_6_0);
	incr_sp_push_msg(6, "push_into_goal_rename");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__saved_vars__push_into_goal_rename_6_0_i2,
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
	}
Define_label(mercury__saved_vars__push_into_goal_rename_6_0_i2);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_rename_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__saved_vars__push_into_goal_rename_6_0_i5,
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
	}
Define_label(mercury__saved_vars__push_into_goal_rename_6_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_rename_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__saved_vars__push_into_goal_rename_6_0_i4);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__saved_vars__rename_var_5_0),
		mercury__saved_vars__push_into_goal_rename_6_0_i7,
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
Define_label(mercury__saved_vars__push_into_goal_rename_6_0_i7);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_rename_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	detstackvar(3) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__push_into_goal_rename_6_0_i8,
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
	}
	}
Define_label(mercury__saved_vars__push_into_goal_rename_6_0_i8);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_rename_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__saved_vars__push_into_goal_rename_6_0_i9,
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
	}
Define_label(mercury__saved_vars__push_into_goal_rename_6_0_i9);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goal_rename_6_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__saved_vars__push_into_goal_6_0),
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
Define_label(mercury__saved_vars__push_into_goal_rename_6_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__saved_vars__saved_vars_in_goal_4_0),
		STATIC(mercury__saved_vars__push_into_goal_rename_6_0));
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module8)
	init_entry(mercury__saved_vars__push_into_goals_rename_6_0);
	init_label(mercury__saved_vars__push_into_goals_rename_6_0_i4);
	init_label(mercury__saved_vars__push_into_goals_rename_6_0_i5);
	init_label(mercury__saved_vars__push_into_goals_rename_6_0_i1002);
BEGIN_CODE

/* code for predicate 'push_into_goals_rename'/6 in mode 0 */
Define_static(mercury__saved_vars__push_into_goals_rename_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__push_into_goals_rename_6_0_i1002);
	incr_sp_push_msg(4, "push_into_goals_rename");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__saved_vars__push_into_goal_rename_6_0),
		mercury__saved_vars__push_into_goals_rename_6_0_i4,
		STATIC(mercury__saved_vars__push_into_goals_rename_6_0));
Define_label(mercury__saved_vars__push_into_goals_rename_6_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goals_rename_6_0));
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__saved_vars__push_into_goals_rename_6_0,
		LABEL(mercury__saved_vars__push_into_goals_rename_6_0_i5),
		STATIC(mercury__saved_vars__push_into_goals_rename_6_0));
Define_label(mercury__saved_vars__push_into_goals_rename_6_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_goals_rename_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__saved_vars__push_into_goals_rename_6_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module9)
	init_entry(mercury__saved_vars__push_into_cases_rename_6_0);
	init_label(mercury__saved_vars__push_into_cases_rename_6_0_i4);
	init_label(mercury__saved_vars__push_into_cases_rename_6_0_i5);
	init_label(mercury__saved_vars__push_into_cases_rename_6_0_i1003);
BEGIN_CODE

/* code for predicate 'push_into_cases_rename'/6 in mode 0 */
Define_static(mercury__saved_vars__push_into_cases_rename_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__push_into_cases_rename_6_0_i1003);
	incr_sp_push_msg(5, "push_into_cases_rename");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__saved_vars__push_into_goal_rename_6_0),
		mercury__saved_vars__push_into_cases_rename_6_0_i4,
		STATIC(mercury__saved_vars__push_into_cases_rename_6_0));
	}
Define_label(mercury__saved_vars__push_into_cases_rename_6_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_cases_rename_6_0));
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__saved_vars__push_into_cases_rename_6_0,
		LABEL(mercury__saved_vars__push_into_cases_rename_6_0_i5),
		STATIC(mercury__saved_vars__push_into_cases_rename_6_0));
	}
Define_label(mercury__saved_vars__push_into_cases_rename_6_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__push_into_cases_rename_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__saved_vars__push_into_cases_rename_6_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module10)
	init_entry(mercury__saved_vars__saved_vars_in_disj_4_0);
	init_label(mercury__saved_vars__saved_vars_in_disj_4_0_i4);
	init_label(mercury__saved_vars__saved_vars_in_disj_4_0_i5);
	init_label(mercury__saved_vars__saved_vars_in_disj_4_0_i1002);
BEGIN_CODE

/* code for predicate 'saved_vars_in_disj'/4 in mode 0 */
Define_static(mercury__saved_vars__saved_vars_in_disj_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_disj_4_0_i1002);
	incr_sp_push_msg(2, "saved_vars_in_disj");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_goal_4_0),
		mercury__saved_vars__saved_vars_in_disj_4_0_i4,
		STATIC(mercury__saved_vars__saved_vars_in_disj_4_0));
Define_label(mercury__saved_vars__saved_vars_in_disj_4_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_disj_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__saved_vars__saved_vars_in_disj_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_disj_4_0_i5),
		STATIC(mercury__saved_vars__saved_vars_in_disj_4_0));
Define_label(mercury__saved_vars__saved_vars_in_disj_4_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_disj_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__saved_vars__saved_vars_in_disj_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module11)
	init_entry(mercury__saved_vars__saved_vars_in_switch_4_0);
	init_label(mercury__saved_vars__saved_vars_in_switch_4_0_i4);
	init_label(mercury__saved_vars__saved_vars_in_switch_4_0_i5);
	init_label(mercury__saved_vars__saved_vars_in_switch_4_0_i1003);
BEGIN_CODE

/* code for predicate 'saved_vars_in_switch'/4 in mode 0 */
Define_static(mercury__saved_vars__saved_vars_in_switch_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__saved_vars__saved_vars_in_switch_4_0_i1003);
	incr_sp_push_msg(3, "saved_vars_in_switch");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__saved_vars__saved_vars_in_goal_4_0),
		mercury__saved_vars__saved_vars_in_switch_4_0_i4,
		STATIC(mercury__saved_vars__saved_vars_in_switch_4_0));
Define_label(mercury__saved_vars__saved_vars_in_switch_4_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_switch_4_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__saved_vars__saved_vars_in_switch_4_0,
		LABEL(mercury__saved_vars__saved_vars_in_switch_4_0_i5),
		STATIC(mercury__saved_vars__saved_vars_in_switch_4_0));
Define_label(mercury__saved_vars__saved_vars_in_switch_4_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__saved_vars_in_switch_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__saved_vars__saved_vars_in_switch_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__saved_vars_module12)
	init_entry(mercury__saved_vars__rename_var_5_0);
	init_label(mercury__saved_vars__rename_var_5_0_i2);
	init_label(mercury__saved_vars__rename_var_5_0_i3);
	init_label(mercury__saved_vars__rename_var_5_0_i4);
	init_label(mercury__saved_vars__rename_var_5_0_i5);
BEGIN_CODE

/* code for predicate 'rename_var'/5 in mode 0 */
Define_static(mercury__saved_vars__rename_var_5_0);
	incr_sp_push_msg(5, "rename_var");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__varset__new_var_3_0);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__saved_vars__rename_var_5_0_i2,
		STATIC(mercury__saved_vars__rename_var_5_0));
	}
Define_label(mercury__saved_vars__rename_var_5_0_i2);
	update_prof_current_proc(LABEL(mercury__saved_vars__rename_var_5_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__saved_vars__rename_var_5_0_i3,
		STATIC(mercury__saved_vars__rename_var_5_0));
	}
	}
Define_label(mercury__saved_vars__rename_var_5_0_i3);
	update_prof_current_proc(LABEL(mercury__saved_vars__rename_var_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__saved_vars__rename_var_5_0_i4,
		STATIC(mercury__saved_vars__rename_var_5_0));
	}
Define_label(mercury__saved_vars__rename_var_5_0_i4);
	update_prof_current_proc(LABEL(mercury__saved_vars__rename_var_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__saved_vars__rename_var_5_0_i5,
		STATIC(mercury__saved_vars__rename_var_5_0));
	}
Define_label(mercury__saved_vars__rename_var_5_0_i5);
	update_prof_current_proc(LABEL(mercury__saved_vars__rename_var_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__saved_vars_bunch_0(void)
{
	mercury__saved_vars_module0();
	mercury__saved_vars_module1();
	mercury__saved_vars_module2();
	mercury__saved_vars_module3();
	mercury__saved_vars_module4();
	mercury__saved_vars_module5();
	mercury__saved_vars_module6();
	mercury__saved_vars_module7();
	mercury__saved_vars_module8();
	mercury__saved_vars_module9();
	mercury__saved_vars_module10();
	mercury__saved_vars_module11();
	mercury__saved_vars_module12();
}

#endif

void mercury__saved_vars__init(void); /* suppress gcc warning */
void mercury__saved_vars__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__saved_vars_bunch_0();
#endif
}
