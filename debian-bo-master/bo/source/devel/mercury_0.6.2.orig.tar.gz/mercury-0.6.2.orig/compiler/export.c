/*
** Automatically generated from `export.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__export__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__export__get_pragma_exported_procs_2_0);
Declare_label(mercury__export__get_pragma_exported_procs_2_0_i2);
Declare_label(mercury__export__get_pragma_exported_procs_2_0_i3);
Declare_label(mercury__export__get_pragma_exported_procs_2_0_i4);
Define_extern_entry(mercury__export__produce_header_file_4_0);
Declare_label(mercury__export__produce_header_file_4_0_i2);
Declare_label(mercury__export__produce_header_file_4_0_i6);
Declare_label(mercury__export__produce_header_file_4_0_i7);
Declare_label(mercury__export__produce_header_file_4_0_i8);
Declare_label(mercury__export__produce_header_file_4_0_i9);
Declare_label(mercury__export__produce_header_file_4_0_i13);
Declare_label(mercury__export__produce_header_file_4_0_i14);
Declare_label(mercury__export__produce_header_file_4_0_i15);
Declare_label(mercury__export__produce_header_file_4_0_i16);
Declare_label(mercury__export__produce_header_file_4_0_i17);
Declare_label(mercury__export__produce_header_file_4_0_i18);
Declare_label(mercury__export__produce_header_file_4_0_i19);
Declare_label(mercury__export__produce_header_file_4_0_i20);
Declare_label(mercury__export__produce_header_file_4_0_i10);
Declare_label(mercury__export__produce_header_file_4_0_i22);
Declare_label(mercury__export__produce_header_file_4_0_i23);
Declare_label(mercury__export__produce_header_file_4_0_i24);
Declare_label(mercury__export__produce_header_file_4_0_i25);
Declare_label(mercury__export__produce_header_file_4_0_i26);
Declare_label(mercury__export__produce_header_file_4_0_i27);
Declare_label(mercury__export__produce_header_file_4_0_i3);
Define_extern_entry(mercury__export__term_to_type_string_2_0);
Declare_label(mercury__export__term_to_type_string_2_0_i2);
Declare_label(mercury__export__term_to_type_string_2_0_i8);
Declare_label(mercury__export__term_to_type_string_2_0_i14);
Declare_label(mercury__export__term_to_type_string_2_0_i20);
Declare_static(mercury__export__to_c_4_0);
Declare_label(mercury__export__to_c_4_0_i4);
Declare_label(mercury__export__to_c_4_0_i5);
Declare_label(mercury__export__to_c_4_0_i6);
Declare_label(mercury__export__to_c_4_0_i7);
Declare_label(mercury__export__to_c_4_0_i8);
Declare_label(mercury__export__to_c_4_0_i9);
Declare_label(mercury__export__to_c_4_0_i10);
Declare_label(mercury__export__to_c_4_0_i11);
Declare_label(mercury__export__to_c_4_0_i12);
Declare_label(mercury__export__to_c_4_0_i13);
Declare_label(mercury__export__to_c_4_0_i14);
Declare_label(mercury__export__to_c_4_0_i15);
Declare_label(mercury__export__to_c_4_0_i16);
Declare_label(mercury__export__to_c_4_0_i17);
Declare_label(mercury__export__to_c_4_0_i1018);
Declare_static(mercury__export__make_arg_info_type_list_4_0);
Declare_label(mercury__export__make_arg_info_type_list_4_0_i6);
Declare_label(mercury__export__make_arg_info_type_list_4_0_i7);
Declare_label(mercury__export__make_arg_info_type_list_4_0_i1009);
Declare_label(mercury__export__make_arg_info_type_list_4_0_i1007);
Declare_label(mercury__export__make_arg_info_type_list_4_0_i1008);
Declare_static(mercury__export__get_argument_declarations_2_0);
Declare_label(mercury__export__get_argument_declarations_2_0_i1002);
Declare_static(mercury__export__get_argument_declarations_2_3_0);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i4);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i5);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i6);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i10);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i7);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i11);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i12);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i13);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i17);
Declare_label(mercury__export__get_argument_declarations_2_3_0_i1007);
Declare_static(mercury__export__get_input_args_3_0);
Declare_label(mercury__export__get_input_args_3_0_i6);
Declare_label(mercury__export__get_input_args_3_0_i7);
Declare_label(mercury__export__get_input_args_3_0_i8);
Declare_label(mercury__export__get_input_args_3_0_i15);
Declare_label(mercury__export__get_input_args_3_0_i9);
Declare_label(mercury__export__get_input_args_3_0_i16);
Declare_label(mercury__export__get_input_args_3_0_i24);
Declare_label(mercury__export__get_input_args_3_0_i27);
Declare_label(mercury__export__get_input_args_3_0_i25);
Declare_label(mercury__export__get_input_args_3_0_i28);
Declare_label(mercury__export__get_input_args_3_0_i29);
Declare_label(mercury__export__get_input_args_3_0_i30);
Declare_label(mercury__export__get_input_args_3_0_i5);
Declare_label(mercury__export__get_input_args_3_0_i31);
Declare_label(mercury__export__get_input_args_3_0_i4);
Declare_label(mercury__export__get_input_args_3_0_i32);
Declare_label(mercury__export__get_input_args_3_0_i1024);
Declare_static(mercury__export__copy_output_args_3_0);
Declare_label(mercury__export__copy_output_args_3_0_i1030);
Declare_label(mercury__export__copy_output_args_3_0_i7);
Declare_label(mercury__export__copy_output_args_3_0_i8);
Declare_label(mercury__export__copy_output_args_3_0_i9);
Declare_label(mercury__export__copy_output_args_3_0_i12);
Declare_label(mercury__export__copy_output_args_3_0_i10);
Declare_label(mercury__export__copy_output_args_3_0_i13);
Declare_label(mercury__export__copy_output_args_3_0_i14);
Declare_label(mercury__export__copy_output_args_3_0_i21);
Declare_label(mercury__export__copy_output_args_3_0_i15);
Declare_label(mercury__export__copy_output_args_3_0_i28);
Declare_label(mercury__export__copy_output_args_3_0_i22);
Declare_label(mercury__export__copy_output_args_3_0_i30);
Declare_label(mercury__export__copy_output_args_3_0_i31);
Declare_label(mercury__export__copy_output_args_3_0_i6);
Declare_label(mercury__export__copy_output_args_3_0_i4);
Declare_label(mercury__export__copy_output_args_3_0_i32);
Declare_label(mercury__export__copy_output_args_3_0_i1028);
Declare_static(mercury__export__produce_header_file_2_4_0);
Declare_label(mercury__export__produce_header_file_2_4_0_i4);
Declare_label(mercury__export__produce_header_file_2_4_0_i5);
Declare_label(mercury__export__produce_header_file_2_4_0_i6);
Declare_label(mercury__export__produce_header_file_2_4_0_i7);
Declare_label(mercury__export__produce_header_file_2_4_0_i8);
Declare_label(mercury__export__produce_header_file_2_4_0_i9);
Declare_label(mercury__export__produce_header_file_2_4_0_i10);
Declare_label(mercury__export__produce_header_file_2_4_0_i11);
Declare_label(mercury__export__produce_header_file_2_4_0_i12);
Declare_label(mercury__export__produce_header_file_2_4_0_i13);
Declare_label(mercury__export__produce_header_file_2_4_0_i14);
Declare_label(mercury__export__produce_header_file_2_4_0_i15);
Declare_label(mercury__export__produce_header_file_2_4_0_i16);
Declare_label(mercury__export__produce_header_file_2_4_0_i1002);

Word * mercury_data_export__common_0[] = {
	(Word *) string_const(".  Do not edit.\n*/\n", 19),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_export__common_1[] = {
	(Word *) string_const("\n", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_export__common_2[] = {
	(Word *) string_const("}\n\n", 3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_export__common_3[] = {
	(Word *) string_const("#endif\n", 7),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_2)
};

Word * mercury_data_export__common_4[] = {
	(Word *) string_const("\tsave_registers();\n", 19),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_3)
};

Word * mercury_data_export__common_5[] = {
	(Word *) string_const("#ifndef CONSERVATIVE_GC\n", 24),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_4)
};

Word * mercury_data_export__common_6[] = {
	(Word *) string_const(")", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_export__common_7[] = {
	(Word *) string_const(";\n", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

BEGIN_MODULE(mercury__export_module0)
	init_entry(mercury__export__get_pragma_exported_procs_2_0);
	init_label(mercury__export__get_pragma_exported_procs_2_0_i2);
	init_label(mercury__export__get_pragma_exported_procs_2_0_i3);
	init_label(mercury__export__get_pragma_exported_procs_2_0_i4);
BEGIN_CODE

/* code for predicate 'export__get_pragma_exported_procs'/2 in mode 0 */
Define_entry(mercury__export__get_pragma_exported_procs_2_0);
	incr_sp_push_msg(3, "export__get_pragma_exported_procs");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0),
		mercury__export__get_pragma_exported_procs_2_0_i2,
		ENTRY(mercury__export__get_pragma_exported_procs_2_0));
	}
Define_label(mercury__export__get_pragma_exported_procs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__export__get_pragma_exported_procs_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__export__get_pragma_exported_procs_2_0_i3,
		ENTRY(mercury__export__get_pragma_exported_procs_2_0));
	}
Define_label(mercury__export__get_pragma_exported_procs_2_0_i3);
	update_prof_current_proc(LABEL(mercury__export__get_pragma_exported_procs_2_0));
	{
	Declare_entry(mercury__hlds_module__predicate_table_get_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_get_preds_2_0),
		mercury__export__get_pragma_exported_procs_2_0_i4,
		ENTRY(mercury__export__get_pragma_exported_procs_2_0));
	}
Define_label(mercury__export__get_pragma_exported_procs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__export__get_pragma_exported_procs_2_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__export__to_c_4_0),
		ENTRY(mercury__export__get_pragma_exported_procs_2_0));
END_MODULE

BEGIN_MODULE(mercury__export_module1)
	init_entry(mercury__export__produce_header_file_4_0);
	init_label(mercury__export__produce_header_file_4_0_i2);
	init_label(mercury__export__produce_header_file_4_0_i6);
	init_label(mercury__export__produce_header_file_4_0_i7);
	init_label(mercury__export__produce_header_file_4_0_i8);
	init_label(mercury__export__produce_header_file_4_0_i9);
	init_label(mercury__export__produce_header_file_4_0_i13);
	init_label(mercury__export__produce_header_file_4_0_i14);
	init_label(mercury__export__produce_header_file_4_0_i15);
	init_label(mercury__export__produce_header_file_4_0_i16);
	init_label(mercury__export__produce_header_file_4_0_i17);
	init_label(mercury__export__produce_header_file_4_0_i18);
	init_label(mercury__export__produce_header_file_4_0_i19);
	init_label(mercury__export__produce_header_file_4_0_i20);
	init_label(mercury__export__produce_header_file_4_0_i10);
	init_label(mercury__export__produce_header_file_4_0_i22);
	init_label(mercury__export__produce_header_file_4_0_i23);
	init_label(mercury__export__produce_header_file_4_0_i24);
	init_label(mercury__export__produce_header_file_4_0_i25);
	init_label(mercury__export__produce_header_file_4_0_i26);
	init_label(mercury__export__produce_header_file_4_0_i27);
	init_label(mercury__export__produce_header_file_4_0_i3);
BEGIN_CODE

/* code for predicate 'export__produce_header_file'/4 in mode 0 */
Define_entry(mercury__export__produce_header_file_4_0);
	incr_sp_push_msg(5, "export__produce_header_file");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0),
		mercury__export__produce_header_file_4_0_i2,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i2);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__produce_header_file_4_0_i3);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__export__produce_header_file_4_0_i6,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i6);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	{
	Declare_entry(mercury__hlds_module__predicate_table_get_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_get_preds_2_0),
		mercury__export__produce_header_file_4_0_i7,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i7);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(".h", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__produce_header_file_4_0_i8,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i8);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__io__tell_4_0);
	call_localret(ENTRY(mercury__io__tell_4_0),
		mercury__export__produce_header_file_4_0_i9,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i9);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__produce_header_file_4_0_i10);
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__export__produce_header_file_4_0_i13,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i13);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("/*\n** Automatically generated from `", 36);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".m' by the\n** Mercury compiler, version ", 40);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_0);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__export__produce_header_file_4_0_i14,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
	}
Define_label(mercury__export__produce_header_file_4_0_i14);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = string_const("#include \"imp.h\"\n\n", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i15,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i15);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__to_upper_2_0);
	call_localret(ENTRY(mercury__string__to_upper_2_0),
		mercury__export__produce_header_file_4_0_i16,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i16);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = string_const("_H", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__produce_header_file_4_0_i17,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i17);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("#ifndef ", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("#define ", 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_1);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__export__produce_header_file_4_0_i18,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
	}
Define_label(mercury__export__produce_header_file_4_0_i18);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__export__produce_header_file_2_4_0),
		mercury__export__produce_header_file_4_0_i19,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i19);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = string_const("#endif\n", 7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i20,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i20);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__io__told_2_0);
	tailcall(ENTRY(mercury__io__told_2_0),
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i10);
	r1 = string_const("export.m", 8);
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__export__produce_header_file_4_0_i22,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i22);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i23,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i23);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i24,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i24);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = string_const(": can't open `", 14);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i25,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i25);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i26,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i26);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = string_const("' for output\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i27,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i27);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	tailcall(ENTRY(mercury__io__set_exit_status_3_0),
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i3);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module2)
	init_entry(mercury__export__term_to_type_string_2_0);
	init_label(mercury__export__term_to_type_string_2_0_i2);
	init_label(mercury__export__term_to_type_string_2_0_i8);
	init_label(mercury__export__term_to_type_string_2_0_i14);
	init_label(mercury__export__term_to_type_string_2_0_i20);
BEGIN_CODE

/* code for predicate 'export__term_to_type_string'/2 in mode 0 */
Define_entry(mercury__export__term_to_type_string_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i2);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i2);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), (char *)string_const("int", 3)) !=0))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i2);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i2);
	r1 = string_const("Integer", 7);
	proceed();
Define_label(mercury__export__term_to_type_string_2_0_i2);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i8);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i8);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i8);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i8);
	r1 = string_const("Float", 5);
	proceed();
Define_label(mercury__export__term_to_type_string_2_0_i8);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i14);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i14);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i14);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i14);
	r1 = string_const("String", 6);
	proceed();
Define_label(mercury__export__term_to_type_string_2_0_i14);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i20);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i20);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)), (char *)string_const("character", 9)) !=0))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i20);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__term_to_type_string_2_0_i20);
	r1 = string_const("Char", 4);
	proceed();
Define_label(mercury__export__term_to_type_string_2_0_i20);
	r1 = string_const("Word", 4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module3)
	init_entry(mercury__export__to_c_4_0);
	init_label(mercury__export__to_c_4_0_i4);
	init_label(mercury__export__to_c_4_0_i5);
	init_label(mercury__export__to_c_4_0_i6);
	init_label(mercury__export__to_c_4_0_i7);
	init_label(mercury__export__to_c_4_0_i8);
	init_label(mercury__export__to_c_4_0_i9);
	init_label(mercury__export__to_c_4_0_i10);
	init_label(mercury__export__to_c_4_0_i11);
	init_label(mercury__export__to_c_4_0_i12);
	init_label(mercury__export__to_c_4_0_i13);
	init_label(mercury__export__to_c_4_0_i14);
	init_label(mercury__export__to_c_4_0_i15);
	init_label(mercury__export__to_c_4_0_i16);
	init_label(mercury__export__to_c_4_0_i17);
	init_label(mercury__export__to_c_4_0_i1018);
BEGIN_CODE

/* code for predicate 'export__to_c'/4 in mode 0 */
Define_static(mercury__export__to_c_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__to_c_4_0_i1018);
	incr_sp_push_msg(9, "export__to_c");
	detstackvar(9) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__export__to_c_4_0_i4,
		STATIC(mercury__export__to_c_4_0));
	}
	}
Define_label(mercury__export__to_c_4_0_i4);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__export__to_c_4_0_i5,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i5);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__export__to_c_4_0_i6,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i6);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__export__to_c_4_0_i7,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i7);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__export__to_c_4_0_i8,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i8);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__export__to_c_4_0_i9,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i9);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__export__make_arg_info_type_list_4_0),
		mercury__export__to_c_4_0_i10,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i10);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	detstackvar(7) = (Integer) r1;
	call_localret(STATIC(mercury__export__get_argument_declarations_2_0),
		mercury__export__to_c_4_0_i11,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i11);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__export__get_input_args_3_0),
		mercury__export__to_c_4_0_i12,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i12);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__export__copy_output_args_3_0),
		mercury__export__to_c_4_0_i13,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i13);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_util__make_proc_label_4_0);
	call_localret(ENTRY(mercury__code_util__make_proc_label_4_0),
		mercury__export__to_c_4_0_i14,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i14);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	{
	Declare_entry(mercury__llds_out__get_proc_label_2_0);
	call_localret(ENTRY(mercury__llds_out__get_proc_label_2_0),
		mercury__export__to_c_4_0_i15,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i15);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\nvoid\n", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("(", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(")\n{\n", 4);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\trestore_registers();\n", 22);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const("\tsave_transient_registers();\n", 29);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("\t{\n\tDeclare_entry(", 18);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(");\n", 3);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\tcall_engine(ENTRY(", 19);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const("));\n\t}\n", 7);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("\trestore_transient_registers();\n", 32);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_5);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__to_c_4_0_i16,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i16);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__export__to_c_4_0,
		LABEL(mercury__export__to_c_4_0_i17),
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i17);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__export__to_c_4_0_i1018);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module4)
	init_entry(mercury__export__make_arg_info_type_list_4_0);
	init_label(mercury__export__make_arg_info_type_list_4_0_i6);
	init_label(mercury__export__make_arg_info_type_list_4_0_i7);
	init_label(mercury__export__make_arg_info_type_list_4_0_i1009);
	init_label(mercury__export__make_arg_info_type_list_4_0_i1007);
	init_label(mercury__export__make_arg_info_type_list_4_0_i1008);
BEGIN_CODE

/* code for predicate 'make_arg_info_type_list'/4 in mode 0 */
Define_static(mercury__export__make_arg_info_type_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__make_arg_info_type_list_4_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__make_arg_info_type_list_4_0_i1007);
	incr_sp_push_msg(5, "make_arg_info_type_list");
	detstackvar(5) = (Integer) succip;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__export__make_arg_info_type_list_4_0_i6,
		STATIC(mercury__export__make_arg_info_type_list_4_0));
	}
Define_label(mercury__export__make_arg_info_type_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__export__make_arg_info_type_list_4_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	localcall(mercury__export__make_arg_info_type_list_4_0,
		LABEL(mercury__export__make_arg_info_type_list_4_0_i7),
		STATIC(mercury__export__make_arg_info_type_list_4_0));
	}
Define_label(mercury__export__make_arg_info_type_list_4_0_i7);
	update_prof_current_proc(LABEL(mercury__export__make_arg_info_type_list_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__export__make_arg_info_type_list_4_0_i1009);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__make_arg_info_type_list_4_0_i1008);
	r1 = string_const("list length mismatch in make_var_arg_info_type_list/4", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__export__make_arg_info_type_list_4_0));
	}
Define_label(mercury__export__make_arg_info_type_list_4_0_i1007);
	r1 = string_const("list length mismatch in make_var_arg_info_type_list/4", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__export__make_arg_info_type_list_4_0));
	}
Define_label(mercury__export__make_arg_info_type_list_4_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module5)
	init_entry(mercury__export__get_argument_declarations_2_0);
	init_label(mercury__export__get_argument_declarations_2_0_i1002);
BEGIN_CODE

/* code for predicate 'get_argument_declarations'/2 in mode 0 */
Define_static(mercury__export__get_argument_declarations_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_0_i1002);
	r2 = ((Integer) 0);
	tailcall(STATIC(mercury__export__get_argument_declarations_2_3_0),
		STATIC(mercury__export__get_argument_declarations_2_0));
Define_label(mercury__export__get_argument_declarations_2_0_i1002);
	r1 = string_const("void", 4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module6)
	init_entry(mercury__export__get_argument_declarations_2_3_0);
	init_label(mercury__export__get_argument_declarations_2_3_0_i4);
	init_label(mercury__export__get_argument_declarations_2_3_0_i5);
	init_label(mercury__export__get_argument_declarations_2_3_0_i6);
	init_label(mercury__export__get_argument_declarations_2_3_0_i10);
	init_label(mercury__export__get_argument_declarations_2_3_0_i7);
	init_label(mercury__export__get_argument_declarations_2_3_0_i11);
	init_label(mercury__export__get_argument_declarations_2_3_0_i12);
	init_label(mercury__export__get_argument_declarations_2_3_0_i13);
	init_label(mercury__export__get_argument_declarations_2_3_0_i17);
	init_label(mercury__export__get_argument_declarations_2_3_0_i1007);
BEGIN_CODE

/* code for predicate 'get_argument_declarations_2'/3 in mode 0 */
Define_static(mercury__export__get_argument_declarations_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_3_0_i1007);
	incr_sp_push_msg(5, "get_argument_declarations_2");
	detstackvar(5) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) r2 + ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_argument_declarations_2_3_0_i4,
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_3_0));
	r2 = (Integer) r1;
	r1 = string_const("Mercury__argument", 17);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_argument_declarations_2_3_0_i5,
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_3_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__export__term_to_type_string_2_0),
		mercury__export__get_argument_declarations_2_3_0_i6,
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_3_0));
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_3_0_i7);
	r2 = string_const(" *", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_argument_declarations_2_3_0_i10,
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i10);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_3_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__export__get_argument_declarations_2_3_0_i12);
Define_label(mercury__export__get_argument_declarations_2_3_0_i7);
	r2 = string_const(" ", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_argument_declarations_2_3_0_i11,
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_3_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
Define_label(mercury__export__get_argument_declarations_2_3_0_i12);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_3_0_i13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i13);
	detstackvar(2) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	localcall(mercury__export__get_argument_declarations_2_3_0,
		LABEL(mercury__export__get_argument_declarations_2_3_0_i17),
		STATIC(mercury__export__get_argument_declarations_2_3_0));
Define_label(mercury__export__get_argument_declarations_2_3_0_i17);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__export__get_argument_declarations_2_3_0));
	}
	}
Define_label(mercury__export__get_argument_declarations_2_3_0_i1007);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module7)
	init_entry(mercury__export__get_input_args_3_0);
	init_label(mercury__export__get_input_args_3_0_i6);
	init_label(mercury__export__get_input_args_3_0_i7);
	init_label(mercury__export__get_input_args_3_0_i8);
	init_label(mercury__export__get_input_args_3_0_i15);
	init_label(mercury__export__get_input_args_3_0_i9);
	init_label(mercury__export__get_input_args_3_0_i16);
	init_label(mercury__export__get_input_args_3_0_i24);
	init_label(mercury__export__get_input_args_3_0_i27);
	init_label(mercury__export__get_input_args_3_0_i25);
	init_label(mercury__export__get_input_args_3_0_i28);
	init_label(mercury__export__get_input_args_3_0_i29);
	init_label(mercury__export__get_input_args_3_0_i30);
	init_label(mercury__export__get_input_args_3_0_i5);
	init_label(mercury__export__get_input_args_3_0_i31);
	init_label(mercury__export__get_input_args_3_0_i4);
	init_label(mercury__export__get_input_args_3_0_i32);
	init_label(mercury__export__get_input_args_3_0_i1024);
BEGIN_CODE

/* code for predicate 'get_input_args'/3 in mode 0 */
Define_static(mercury__export__get_input_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i1024);
	incr_sp_push_msg(6, "get_input_args");
	detstackvar(6) = (Integer) succip;
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i5);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = ((Integer) r2 + ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_input_args_3_0_i6,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i6);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_input_args_3_0_i7,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i7);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = (Integer) r1;
	r1 = string_const("Mercury__argument", 17);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_input_args_3_0_i8,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i9);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i9);
	r2 = (Integer) r1;
	r1 = string_const("(Word) ", 7);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_input_args_3_0_i15,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i15);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__export__get_input_args_3_0_i24);
Define_label(mercury__export__get_input_args_3_0_i9);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i16);
	if ((tag((Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i16);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i16);
	if (((Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i16);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("float_to_word(", 14);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_6);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_input_args_3_0_i15,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i16);
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
Define_label(mercury__export__get_input_args_3_0_i24);
	if (((Integer) r2 <= ((Integer) 32)))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i25);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r5;
	detstackvar(4) = (Integer) r3;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("r(", 2);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_6);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_input_args_3_0_i27,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i27);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\t", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(" = ", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_7);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__export__get_input_args_3_0_i29);
	}
Define_label(mercury__export__get_input_args_3_0_i25);
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) r3;
	detstackvar(2) = (Integer) r5;
	r1 = string_const("r", 1);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_input_args_3_0_i28,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i28);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\t", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(" = ", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_7);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__export__get_input_args_3_0_i29);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_input_args_3_0_i30,
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i30);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__export__get_input_args_3_0_i4);
Define_label(mercury__export__get_input_args_3_0_i5);
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i31);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) r2 + ((Integer) 1));
	r3 = string_const("", 0);
	GOTO_LABEL(mercury__export__get_input_args_3_0_i4);
Define_label(mercury__export__get_input_args_3_0_i31);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) r2 + ((Integer) 1));
	r3 = string_const("", 0);
Define_label(mercury__export__get_input_args_3_0_i4);
	detstackvar(1) = (Integer) r3;
	localcall(mercury__export__get_input_args_3_0,
		LABEL(mercury__export__get_input_args_3_0_i32),
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i32);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__export__get_input_args_3_0));
	}
Define_label(mercury__export__get_input_args_3_0_i1024);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module8)
	init_entry(mercury__export__copy_output_args_3_0);
	init_label(mercury__export__copy_output_args_3_0_i1030);
	init_label(mercury__export__copy_output_args_3_0_i7);
	init_label(mercury__export__copy_output_args_3_0_i8);
	init_label(mercury__export__copy_output_args_3_0_i9);
	init_label(mercury__export__copy_output_args_3_0_i12);
	init_label(mercury__export__copy_output_args_3_0_i10);
	init_label(mercury__export__copy_output_args_3_0_i13);
	init_label(mercury__export__copy_output_args_3_0_i14);
	init_label(mercury__export__copy_output_args_3_0_i21);
	init_label(mercury__export__copy_output_args_3_0_i15);
	init_label(mercury__export__copy_output_args_3_0_i28);
	init_label(mercury__export__copy_output_args_3_0_i22);
	init_label(mercury__export__copy_output_args_3_0_i30);
	init_label(mercury__export__copy_output_args_3_0_i31);
	init_label(mercury__export__copy_output_args_3_0_i6);
	init_label(mercury__export__copy_output_args_3_0_i4);
	init_label(mercury__export__copy_output_args_3_0_i32);
	init_label(mercury__export__copy_output_args_3_0_i1028);
BEGIN_CODE

/* code for predicate 'copy_output_args'/3 in mode 0 */
Define_static(mercury__export__copy_output_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i1028);
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i1030);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) r2 + ((Integer) 1));
	r3 = string_const("", 0);
	incr_sp_push_msg(6, "copy_output_args");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__export__copy_output_args_3_0_i4);
Define_label(mercury__export__copy_output_args_3_0_i1030);
	incr_sp_push_msg(6, "copy_output_args");
	detstackvar(6) = (Integer) succip;
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i6);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) r2 + ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__copy_output_args_3_0_i7,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i7);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = (Integer) r1;
	r1 = string_const("Mercury__argument", 17);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__copy_output_args_3_0_i8,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__copy_output_args_3_0_i9,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i9);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	if (((Integer) detstackvar(3) <= ((Integer) 32)))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i10);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("r(", 2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_6);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__copy_output_args_3_0_i12,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i12);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__export__copy_output_args_3_0_i14);
Define_label(mercury__export__copy_output_args_3_0_i10);
	r2 = (Integer) r1;
	r1 = string_const("r", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__copy_output_args_3_0_i13,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i13);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__export__copy_output_args_3_0_i14);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i15);
	r6 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r6) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i15);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r6, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i15);
	r6 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i15);
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = string_const("(String) ", 9);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__copy_output_args_3_0_i21,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i21);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\t*", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(" = ", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_7);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__export__copy_output_args_3_0_i30);
	}
Define_label(mercury__export__copy_output_args_3_0_i15);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i22);
	if ((tag((Integer) field(mktag(0), (Integer) r3, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i22);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i22);
	if (((Integer) field(mktag(0), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i22);
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("word_to_float(", 14);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_6);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__copy_output_args_3_0_i28,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i28);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\t*", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(" = ", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_7);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__export__copy_output_args_3_0_i30);
	}
Define_label(mercury__export__copy_output_args_3_0_i22);
	r6 = (Integer) r2;
	r2 = (Integer) r1;
	r3 = (Integer) r4;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\t*", 2);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(" = ", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_export__common_7);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__export__copy_output_args_3_0_i30);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__copy_output_args_3_0_i31,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i31);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__export__copy_output_args_3_0_i4);
Define_label(mercury__export__copy_output_args_3_0_i6);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) r2 + ((Integer) 1));
	r3 = string_const("", 0);
Define_label(mercury__export__copy_output_args_3_0_i4);
	detstackvar(1) = (Integer) r3;
	localcall(mercury__export__copy_output_args_3_0,
		LABEL(mercury__export__copy_output_args_3_0_i32),
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i32);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i1028);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__export_module9)
	init_entry(mercury__export__produce_header_file_2_4_0);
	init_label(mercury__export__produce_header_file_2_4_0_i4);
	init_label(mercury__export__produce_header_file_2_4_0_i5);
	init_label(mercury__export__produce_header_file_2_4_0_i6);
	init_label(mercury__export__produce_header_file_2_4_0_i7);
	init_label(mercury__export__produce_header_file_2_4_0_i8);
	init_label(mercury__export__produce_header_file_2_4_0_i9);
	init_label(mercury__export__produce_header_file_2_4_0_i10);
	init_label(mercury__export__produce_header_file_2_4_0_i11);
	init_label(mercury__export__produce_header_file_2_4_0_i12);
	init_label(mercury__export__produce_header_file_2_4_0_i13);
	init_label(mercury__export__produce_header_file_2_4_0_i14);
	init_label(mercury__export__produce_header_file_2_4_0_i15);
	init_label(mercury__export__produce_header_file_2_4_0_i16);
	init_label(mercury__export__produce_header_file_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'export__produce_header_file_2'/4 in mode 0 */
Define_static(mercury__export__produce_header_file_2_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__export__produce_header_file_2_4_0_i1002);
	incr_sp_push_msg(7, "export__produce_header_file_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__export__produce_header_file_2_4_0_i4,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
	}
Define_label(mercury__export__produce_header_file_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__export__produce_header_file_2_4_0_i5,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__export__produce_header_file_2_4_0_i6,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__export__produce_header_file_2_4_0_i7,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__export__produce_header_file_2_4_0_i8,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__export__produce_header_file_2_4_0_i9,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__export__make_arg_info_type_list_4_0),
		mercury__export__produce_header_file_2_4_0_i10,
		STATIC(mercury__export__produce_header_file_2_4_0));
Define_label(mercury__export__produce_header_file_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	call_localret(STATIC(mercury__export__get_argument_declarations_2_0),
		mercury__export__produce_header_file_2_4_0_i11,
		STATIC(mercury__export__produce_header_file_2_4_0));
Define_label(mercury__export__produce_header_file_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = string_const("void\n", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_4_0_i12,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_4_0_i13,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("(", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_4_0_i14,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_4_0_i15,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const(");\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_4_0_i16,
		STATIC(mercury__export__produce_header_file_2_4_0));
	}
Define_label(mercury__export__produce_header_file_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__export__produce_header_file_2_4_0,
		STATIC(mercury__export__produce_header_file_2_4_0));
Define_label(mercury__export__produce_header_file_2_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__export_bunch_0(void)
{
	mercury__export_module0();
	mercury__export_module1();
	mercury__export_module2();
	mercury__export_module3();
	mercury__export_module4();
	mercury__export_module5();
	mercury__export_module6();
	mercury__export_module7();
	mercury__export_module8();
	mercury__export_module9();
}

#endif

void mercury__export__init(void); /* suppress gcc warning */
void mercury__export__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__export_bunch_0();
#endif
}
