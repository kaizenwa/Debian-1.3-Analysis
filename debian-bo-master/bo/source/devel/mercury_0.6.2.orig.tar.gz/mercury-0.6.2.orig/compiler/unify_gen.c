/*
** Automatically generated from `unify_gen.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__unify_gen__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__unify_gen__generate_assignment_5_0);
Declare_label(mercury__unify_gen__generate_assignment_5_0_i4);
Declare_label(mercury__unify_gen__generate_assignment_5_0_i6);
Declare_label(mercury__unify_gen__generate_assignment_5_0_i3);
Declare_label(mercury__unify_gen__generate_assignment_5_0_i7);
Define_extern_entry(mercury__unify_gen__generate_construction_7_0);
Declare_label(mercury__unify_gen__generate_construction_7_0_i2);
Define_extern_entry(mercury__unify_gen__generate_det_deconstruction_7_0);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i2);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i10);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i11);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i12);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i14);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i26);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i19);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i1002);
Define_extern_entry(mercury__unify_gen__generate_semi_deconstruction_7_0);
Declare_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i2);
Declare_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i3);
Declare_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i4);
Declare_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i5);
Declare_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i6);
Define_extern_entry(mercury__unify_gen__generate_test_5_0);
Declare_label(mercury__unify_gen__generate_test_5_0_i2);
Declare_label(mercury__unify_gen__generate_test_5_0_i3);
Declare_label(mercury__unify_gen__generate_test_5_0_i4);
Declare_label(mercury__unify_gen__generate_test_5_0_i5);
Declare_label(mercury__unify_gen__generate_test_5_0_i11);
Declare_label(mercury__unify_gen__generate_test_5_0_i18);
Declare_label(mercury__unify_gen__generate_test_5_0_i19);
Define_extern_entry(mercury__unify_gen__generate_tag_test_7_0);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i2);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i6);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i7);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i8);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i12);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i16);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i14);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i13);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i26);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i23);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i9);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i3);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i34);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i35);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i36);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i39);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i40);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i41);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i42);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i38);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i43);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i44);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i45);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i37);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i46);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i49);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i48);
Define_extern_entry(mercury__unify_gen__generate_tag_rval_6_0);
Declare_label(mercury__unify_gen__generate_tag_rval_6_0_i2);
Declare_label(mercury__unify_gen__generate_tag_rval_6_0_i3);
Declare_label(mercury__unify_gen__generate_tag_rval_6_0_i4);
Declare_static(mercury__unify_gen__generate_tag_rval_2_3_0);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1045);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1044);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1043);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1042);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i12);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i14);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1041);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i16);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1038);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1039);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1040);
Declare_static(mercury__unify_gen__generate_construction_2_7_0);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1009);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1008);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1007);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1006);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1005);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1004);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1003);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i5);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i6);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i7);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i8);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i9);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i10);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i11);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i12);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i13);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i14);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i19);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i21);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i20);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i25);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i26);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i27);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i28);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i29);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i30);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i31);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i32);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i33);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i34);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i35);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i16);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i36);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i37);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i38);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i39);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i40);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i41);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i42);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i43);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i44);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i47);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i48);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i49);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i50);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i52);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i53);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i56);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i57);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i59);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i60);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i61);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i62);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i63);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i65);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i66);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i67);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i68);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i69);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i71);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i1002);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i80);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i74);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i73);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i84);
Declare_label(mercury__unify_gen__generate_construction_2_7_0_i86);
Declare_static(mercury__unify_gen__generate_extra_closure_args_6_0);
Declare_label(mercury__unify_gen__generate_extra_closure_args_6_0_i4);
Declare_label(mercury__unify_gen__generate_extra_closure_args_6_0_i5);
Declare_label(mercury__unify_gen__generate_extra_closure_args_6_0_i1015);
Declare_static(mercury__unify_gen__generate_pred_args_3_0);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i1010);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i9);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i10);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i1006);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i1008);
Declare_static(mercury__unify_gen__generate_cons_args_5_0);
Declare_label(mercury__unify_gen__generate_cons_args_5_0_i4);
Declare_label(mercury__unify_gen__generate_cons_args_5_0_i1000);
Declare_static(mercury__unify_gen__generate_cons_args_2_5_0);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i1015);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i10);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i9);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i11);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i12);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i1012);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i1);
Declare_static(mercury__unify_gen__var_types_4_0);
Declare_label(mercury__unify_gen__var_types_4_0_i2);
Declare_label(mercury__unify_gen__var_types_4_0_i3);
Declare_label(mercury__unify_gen__var_types_4_0_i4);
Declare_static(mercury__unify_gen__make_fields_and_argvars_6_0);
Declare_label(mercury__unify_gen__make_fields_and_argvars_6_0_i3);
Declare_label(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
Declare_label(mercury__unify_gen__make_fields_and_argvars_6_0_i1);
Declare_static(mercury__unify_gen__generate_unify_args_7_0);
Declare_label(mercury__unify_gen__generate_unify_args_7_0_i4);
Declare_label(mercury__unify_gen__generate_unify_args_7_0_i1000);
Declare_static(mercury__unify_gen__generate_unify_args_2_7_0);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i1013);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i10);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i11);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i1010);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i1);
Declare_static(mercury__unify_gen__generate_sub_unify_7_0);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i2);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i3);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i4);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i5);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i10);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i15);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i20);
Declare_static(mercury__unify_gen__generate_sub_assign_5_0);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i6);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i7);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i10);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i5);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i12);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i13);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i14);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i1002);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i23);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i25);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i22);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i26);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i20);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i29);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i31);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i28);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i32);
Define_extern_entry(mercury____Unify___unify_gen__test_sense_0_0);
Declare_label(mercury____Unify___unify_gen__test_sense_0_0_i1);
Define_extern_entry(mercury____Index___unify_gen__test_sense_0_0);
Define_extern_entry(mercury____Compare___unify_gen__test_sense_0_0);

extern Word * mercury_data_unify_gen__base_type_layout_test_sense_0[];
Word * mercury_data_unify_gen__base_type_info_test_sense_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___unify_gen__test_sense_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___unify_gen__test_sense_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___unify_gen__test_sense_0_0),
	(Word *) (Integer) mercury_data_unify_gen__base_type_layout_test_sense_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_unify_gen__base_type_layout_uni_val_0[];
Word * mercury_data_unify_gen__base_type_info_uni_val_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_unify_gen__base_type_layout_uni_val_0
};

extern Word * mercury_data_unify_gen__common_9[];
extern Word * mercury_data_unify_gen__common_11[];
Word * mercury_data_unify_gen__base_type_layout_uni_val_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_gen__common_9),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_gen__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_unify_gen__common_12[];
Word * mercury_data_unify_gen__base_type_layout_test_sense_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_12)
};

Word * mercury_data_unify_gen__common_0[] = {
	(Word *) string_const(" (inverted test)", 16),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_unify_gen__common_1[] = {
	((Integer) 0)
};

Word * mercury_data_unify_gen__common_2[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_gen__common_1)
};

Word mercury_data_unify_gen__common_3[] = {
	((Integer) 1),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_unify_gen__common_4[] = {
	((Integer) 1)
};

Word * mercury_data_unify_gen__common_5[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_gen__common_4)
};

Word * mercury_data_unify_gen__common_6[] = {
	(Word *) string_const("build new closure from old closure", 34)
};

Word * mercury_data_unify_gen__common_7[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_unify_gen__common_6),
	(Word *) string_const("", 0)
};

extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_unify_gen__common_8[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_unify_gen__common_9[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_8),
	(Word *) string_const("ref", 3)
};

extern Word * mercury_data_llds__base_type_info_lval_0[];
Word * mercury_data_unify_gen__common_10[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0
};

Word * mercury_data_unify_gen__common_11[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_10),
	(Word *) string_const("lval", 4)
};

Word * mercury_data_unify_gen__common_12[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("branch_on_success", 17),
	(Word *) string_const("branch_on_failure", 17)
};

BEGIN_MODULE(mercury__unify_gen_module0)
	init_entry(mercury__unify_gen__generate_assignment_5_0);
	init_label(mercury__unify_gen__generate_assignment_5_0_i4);
	init_label(mercury__unify_gen__generate_assignment_5_0_i6);
	init_label(mercury__unify_gen__generate_assignment_5_0_i3);
	init_label(mercury__unify_gen__generate_assignment_5_0_i7);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_assignment'/5 in mode 0 */
Define_entry(mercury__unify_gen__generate_assignment_5_0);
	incr_sp_push_msg(4, "unify_gen__generate_assignment");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_is_live_3_0);
	call_localret(ENTRY(mercury__code_info__variable_is_live_3_0),
		mercury__unify_gen__generate_assignment_5_0_i4,
		ENTRY(mercury__unify_gen__generate_assignment_5_0));
	}
Define_label(mercury__unify_gen__generate_assignment_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_assignment_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_assignment_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_assignment_5_0_i6,
		ENTRY(mercury__unify_gen__generate_assignment_5_0));
	}
Define_label(mercury__unify_gen__generate_assignment_5_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_assignment_5_0));
	r2 = (Integer) r1;
	GOTO_LABEL(mercury__unify_gen__generate_assignment_5_0_i7);
Define_label(mercury__unify_gen__generate_assignment_5_0_i3);
	r2 = (Integer) detstackvar(3);
Define_label(mercury__unify_gen__generate_assignment_5_0_i7);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module1)
	init_entry(mercury__unify_gen__generate_construction_7_0);
	init_label(mercury__unify_gen__generate_construction_7_0_i2);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_construction'/7 in mode 0 */
Define_entry(mercury__unify_gen__generate_construction_7_0);
	incr_sp_push_msg(4, "unify_gen__generate_construction");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__cons_id_to_tag_5_0);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_construction_7_0_i2,
		ENTRY(mercury__unify_gen__generate_construction_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_7_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__unify_gen__generate_construction_2_7_0),
		ENTRY(mercury__unify_gen__generate_construction_7_0));
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module2)
	init_entry(mercury__unify_gen__generate_det_deconstruction_7_0);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i2);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i10);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i11);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i12);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i14);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i26);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i19);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i1002);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_det_deconstruction'/7 in mode 0 */
Define_entry(mercury__unify_gen__generate_det_deconstruction_7_0);
	incr_sp_push_msg(4, "unify_gen__generate_det_deconstruction");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__cons_id_to_tag_5_0);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i2,
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i10) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i14) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) tempr1;
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(2);
	r3 = ((Integer) 0);
	call_localret(STATIC(mercury__unify_gen__make_fields_and_argvars_6_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i11,
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__unify_gen__var_types_4_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i12,
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__unify_gen__generate_unify_args_7_0),
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i14);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(1) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	r3 = ((Integer) 1);
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	call_localret(STATIC(mercury__unify_gen__make_fields_and_argvars_6_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i11,
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i19);
	r3 = (Integer) detstackvar(2);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) detstackvar(3);
	if (((Integer) tempr2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
	if (((Integer) field(mktag(1), (Integer) tempr2, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i26,
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r3 = (Integer) r1;
	r5 = (Integer) r2;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__unify_gen__generate_sub_unify_7_0),
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i20);
	r1 = string_const("unify_gen__generate_det_deconstruction: no_tag: arity != 1", 58);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unify_gen__generate_det_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module3)
	init_entry(mercury__unify_gen__generate_semi_deconstruction_7_0);
	init_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i2);
	init_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i3);
	init_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i4);
	init_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i5);
	init_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i6);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_semi_deconstruction'/7 in mode 0 */
Define_entry(mercury__unify_gen__generate_semi_deconstruction_7_0);
	incr_sp_push_msg(8, "unify_gen__generate_semi_deconstruction");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r3 = ((Integer) 0);
	r4 = (Integer) r5;
	{
		call_localret(STATIC(mercury__unify_gen__generate_tag_test_7_0),
		mercury__unify_gen__generate_semi_deconstruction_7_0_i2,
		ENTRY(mercury__unify_gen__generate_semi_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_semi_deconstruction_7_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__unify_gen__generate_semi_deconstruction_7_0_i3,
		ENTRY(mercury__unify_gen__generate_semi_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_semi_deconstruction_7_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__unify_gen__generate_semi_deconstruction_7_0_i4,
		ENTRY(mercury__unify_gen__generate_semi_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_semi_deconstruction_7_0));
	r3 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__unify_gen__generate_semi_deconstruction_7_0_i5,
		ENTRY(mercury__unify_gen__generate_semi_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_semi_deconstruction_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__unify_gen__generate_det_deconstruction_7_0),
		mercury__unify_gen__generate_semi_deconstruction_7_0_i6,
		ENTRY(mercury__unify_gen__generate_semi_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_semi_deconstruction_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_semi_deconstruction_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module4)
	init_entry(mercury__unify_gen__generate_test_5_0);
	init_label(mercury__unify_gen__generate_test_5_0_i2);
	init_label(mercury__unify_gen__generate_test_5_0_i3);
	init_label(mercury__unify_gen__generate_test_5_0_i4);
	init_label(mercury__unify_gen__generate_test_5_0_i5);
	init_label(mercury__unify_gen__generate_test_5_0_i11);
	init_label(mercury__unify_gen__generate_test_5_0_i18);
	init_label(mercury__unify_gen__generate_test_5_0_i19);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_test'/5 in mode 0 */
Define_entry(mercury__unify_gen__generate_test_5_0);
	incr_sp_push_msg(4, "unify_gen__generate_test");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_test_5_0_i2,
		ENTRY(mercury__unify_gen__generate_test_5_0));
	}
Define_label(mercury__unify_gen__generate_test_5_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_test_5_0_i3,
		ENTRY(mercury__unify_gen__generate_test_5_0));
	}
	}
Define_label(mercury__unify_gen__generate_test_5_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) tempr1;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_test_5_0_i4,
		ENTRY(mercury__unify_gen__generate_test_5_0));
	}
	}
Define_label(mercury__unify_gen__generate_test_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 15);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i18);
Define_label(mercury__unify_gen__generate_test_5_0_i5);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i11);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i11);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i11);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i11);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 29);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i18);
Define_label(mercury__unify_gen__generate_test_5_0_i11);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 12);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
Define_label(mercury__unify_gen__generate_test_5_0_i18);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__generate_test_and_fail_4_0);
	call_localret(ENTRY(mercury__code_info__generate_test_and_fail_4_0),
		mercury__unify_gen__generate_test_5_0_i19,
		ENTRY(mercury__unify_gen__generate_test_5_0));
	}
Define_label(mercury__unify_gen__generate_test_5_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module5)
	init_entry(mercury__unify_gen__generate_tag_test_7_0);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i2);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i6);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i7);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i8);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i12);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i16);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i14);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i13);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i26);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i23);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i9);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i3);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i34);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i35);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i36);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i39);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i40);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i41);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i42);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i38);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i43);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i44);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i45);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i37);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i46);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i49);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i48);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_tag_test'/7 in mode 0 */
Define_entry(mercury__unify_gen__generate_tag_test_7_0);
	incr_sp_push_msg(11, "unify_gen__generate_tag_test");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_tag_test_7_0_i2,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i3);
	r4 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	if (((Integer) r4 <= ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i3);
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_tag_test_7_0_i6,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	{
	Declare_entry(mercury__code_aux__lookup_type_defn_4_0);
	call_localret(ENTRY(mercury__code_aux__lookup_type_defn_4_0),
		mercury__unify_gen__generate_tag_test_7_0_i7,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	detstackvar(10) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i8,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i9);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	}
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	}
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i12,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i13);
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__unify_gen__generate_tag_test_7_0_i16,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	{
	Word tempr1, tempr2, tempr3, tempr4;
	tempr1 = (Integer) detstackvar(4);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i14);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i14);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i14);
	tempr4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) tempr4) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i14);
	if (((Integer) field(mktag(0), (Integer) tempr4, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i14);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr4;
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i34);
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i14);
	r1 = (Integer) detstackvar(8);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i13);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i23);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i23);
	detstackvar(5) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__unify_gen__generate_tag_test_7_0_i26,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i23);
	if (((Integer) detstackvar(4) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i23);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i23);
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 1));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i23);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i34);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i23);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i34);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i9);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i34);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i3);
	r5 = (Integer) r1;
	r6 = (Integer) r2;
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i34);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	{
	Declare_entry(mercury__code_info__variable_to_string_4_0);
	call_localret(ENTRY(mercury__code_info__variable_to_string_4_0),
		mercury__unify_gen__generate_tag_test_7_0_i35,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i35);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_out__cons_id_to_string_2_0);
	call_localret(ENTRY(mercury__hlds_out__cons_id_to_string_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i36,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i36);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = (Integer) detstackvar(4);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i38);
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("checking that ", 14);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(" has functor ", 13);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_unify_gen__common_0);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i39,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i39);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = (Integer) detstackvar(9);
	tag_incr_hp(detstackvar(9), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	r1 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) detstackvar(9), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__cons_id_to_tag_5_0);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_tag_test_7_0_i40,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i40);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_gen__generate_tag_rval_2_3_0),
		mercury__unify_gen__generate_tag_test_7_0_i41,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i41);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	{
	Declare_entry(mercury__code_util__neg_rval_2_0);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i42,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i42);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i37);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i38);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("checking that ", 14);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(" has functor ", 13);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i43,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i43);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = (Integer) detstackvar(9);
	tag_incr_hp(detstackvar(9), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	r1 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) detstackvar(9), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__cons_id_to_tag_5_0);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_tag_test_7_0_i44,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i44);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__unify_gen__generate_tag_rval_2_3_0),
		mercury__unify_gen__generate_tag_test_7_0_i45,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i45);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i37);
	detstackvar(3) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__unify_gen__generate_tag_test_7_0_i46,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i46);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (((Integer) detstackvar(3) == ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i48);
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_util__neg_rval_2_0);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i49,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i49);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("tag test", 8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i48);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("tag test", 8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module6)
	init_entry(mercury__unify_gen__generate_tag_rval_6_0);
	init_label(mercury__unify_gen__generate_tag_rval_6_0_i2);
	init_label(mercury__unify_gen__generate_tag_rval_6_0_i3);
	init_label(mercury__unify_gen__generate_tag_rval_6_0_i4);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_tag_rval'/6 in mode 0 */
Define_entry(mercury__unify_gen__generate_tag_rval_6_0);
	incr_sp_push_msg(3, "unify_gen__generate_tag_rval");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_tag_rval_6_0_i2,
		ENTRY(mercury__unify_gen__generate_tag_rval_6_0));
	}
Define_label(mercury__unify_gen__generate_tag_rval_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_rval_6_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tempr2 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr2;
	detstackvar(1) = (Integer) tempr1;
	{
	Declare_entry(mercury__code_info__cons_id_to_tag_5_0);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_tag_rval_6_0_i3,
		ENTRY(mercury__unify_gen__generate_tag_rval_6_0));
	}
	}
Define_label(mercury__unify_gen__generate_tag_rval_6_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_rval_6_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__unify_gen__generate_tag_rval_2_3_0),
		mercury__unify_gen__generate_tag_rval_6_0_i4,
		ENTRY(mercury__unify_gen__generate_tag_rval_6_0));
Define_label(mercury__unify_gen__generate_tag_rval_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_rval_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module7)
	init_entry(mercury__unify_gen__generate_tag_rval_2_3_0);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1045);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1044);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1043);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1042);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i12);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i14);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1041);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i16);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1038);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1039);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1040);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_tag_rval_2'/3 in mode 0 */
Define_static(mercury__unify_gen__generate_tag_rval_2_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1041);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1045) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1038) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1039) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1040) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1044) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1043) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i1042));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1045);
	incr_sp_push_msg(1, "unify_gen__generate_tag_rval_2");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1044);
	incr_sp_push_msg(1, "unify_gen__generate_tag_rval_2");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i12);
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1043);
	incr_sp_push_msg(1, "unify_gen__generate_tag_rval_2");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1042);
	incr_sp_push_msg(1, "unify_gen__generate_tag_rval_2");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i14);
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 12);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(r4, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i12);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 12);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = ((Integer) 0);
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 10);
	tag_incr_hp(r4, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = ((Integer) 12);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 0);
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 3)) = (Integer) r5;
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) r6;
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = ((Integer) 12);
	tag_incr_hp(r5, mktag(0), ((Integer) 1));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 3)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i14);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 12);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(r4, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 3);
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) r5;
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) r6;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1041);
	incr_sp_push_msg(1, "unify_gen__generate_tag_rval_2");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
	r1 = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i16);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 15);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(r4, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i16);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 29);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(r4, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1038);
	r1 = string_const("Attempted higher-order unification", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
	}
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1039);
	r1 = string_const("Attempted code_addr unification", 31);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
	}
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i1040);
	r1 = string_const("Attempted base_type_info unification", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module8)
	init_entry(mercury__unify_gen__generate_construction_2_7_0);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1009);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1008);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1007);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1006);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1005);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1004);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1003);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i5);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i6);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i7);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i8);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i9);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i10);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i11);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i12);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i13);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i14);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i19);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i21);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i20);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i25);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i26);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i27);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i28);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i29);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i30);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i31);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i32);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i33);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i34);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i35);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i16);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i36);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i37);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i38);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i39);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i40);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i41);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i42);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i43);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i44);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i47);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i48);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i49);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i50);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i52);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i53);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i56);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i57);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i59);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i60);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i61);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i62);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i63);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i65);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i66);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i67);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i68);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i69);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i71);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i1002);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i80);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i74);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i73);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i84);
	init_label(mercury__unify_gen__generate_construction_2_7_0_i86);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_construction_2'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_construction_2_7_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i1002);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1009) AND
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1008) AND
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1007) AND
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1006) AND
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1005) AND
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1004) AND
		LABEL(mercury__unify_gen__generate_construction_2_7_0_i1003));
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1009);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i5);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1008);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i7);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1007);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i43);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1006);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i52);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1005);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i59);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1004);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i65);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1003);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i71);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i5);
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i6,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	proceed();
Define_label(mercury__unify_gen__generate_construction_2_7_0_i7);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i8,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(20) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i9,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_gen__generate_construction_2_7_0_i10,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i11,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__unify_gen__generate_construction_2_7_0_i12,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i13,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i14,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(3), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i16);
	r3 = (Integer) detstackvar(2);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i16);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 4));
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i19,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	if (((Integer) detstackvar(3) != (Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i21);
	r1 = (Integer) detstackvar(20);
	r2 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i20);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i21);
	if (((Integer) detstackvar(3) != ((Integer) 2)))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i16);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i16);
	r1 = (Integer) detstackvar(20);
	r2 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i20);
	detstackvar(1) = (Integer) r2;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i25,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i26,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i27,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i28,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i29,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(13) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(12);
	detstackvar(14) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	detstackvar(15) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	detstackvar(16) = (Integer) r3;
	detstackvar(19) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(9);
	detstackvar(17) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_2);
	detstackvar(18) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_5);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i30,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) detstackvar(8);
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	detstackvar(8) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(3), (Integer) detstackvar(8), ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) detstackvar(19);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	detstackvar(19) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = ((Integer) r1 + ((Integer) 2));
	r1 = (Integer) r2;
	field(mktag(3), (Integer) detstackvar(19), ((Integer) 1)) = (Integer) tempr1;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_construction_2_7_0_i31,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r4 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r5 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(15);
	tag_incr_hp(r6, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(16);
	tag_incr_hp(detstackvar(8), mktag(1), ((Integer) 1));
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_unify_gen__common_7);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(r17, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = (Integer) detstackvar(14);
	tag_incr_hp(r18, mktag(0), ((Integer) 1));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("get number of arguments", 23);
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) r18;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r18, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	tag_incr_hp(r17, mktag(0), ((Integer) 2));
	tag_incr_hp(r18, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r18, ((Integer) 0)) = ((Integer) 10);
	field(mktag(3), (Integer) r18, ((Integer) 1)) = (Integer) detstackvar(16);
	field(mktag(3), (Integer) r18, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r19, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r19, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r19, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r19, ((Integer) 3)) = (Integer) detstackvar(19);
	field(mktag(0), (Integer) r17, ((Integer) 1)) = string_const("allocate new closure", 20);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) r18, ((Integer) 3)) = (Integer) r19;
	field(mktag(3), (Integer) r19, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	tag_incr_hp(r18, mktag(0), ((Integer) 2));
	tag_incr_hp(r19, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r19, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r6;
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r19, ((Integer) 1)) = (Integer) r1;
	tag_incr_hp(r20, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r20, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r20, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r20, ((Integer) 3)) = (Integer) r5;
	field(mktag(0), (Integer) r18, ((Integer) 1)) = string_const("set new number of arguments", 27);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) r19, ((Integer) 2)) = (Integer) r20;
	field(mktag(3), (Integer) r20, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(0), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	tag_incr_hp(r19, mktag(0), ((Integer) 2));
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_2);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r7;
	field(mktag(0), (Integer) r19, ((Integer) 1)) = string_const("initialize loop counter", 23);
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	field(mktag(0), (Integer) r19, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	tag_incr_hp(r20, mktag(0), ((Integer) 2));
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r20, ((Integer) 1)) = string_const("start of loop", 13);
	field(mktag(1), (Integer) r19, ((Integer) 0)) = (Integer) r20;
	field(mktag(0), (Integer) r20, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	tag_incr_hp(r21, mktag(0), ((Integer) 2));
	tag_incr_hp(r22, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r22, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r22, ((Integer) 1)) = (Integer) r7;
	tag_incr_hp(r23, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r23, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r23, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r23, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_5);
	field(mktag(0), (Integer) r21, ((Integer) 1)) = string_const("increment loop counter", 22);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r7;
	field(mktag(3), (Integer) r22, ((Integer) 2)) = (Integer) r23;
	field(mktag(3), (Integer) r23, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r20, ((Integer) 0)) = (Integer) r21;
	field(mktag(0), (Integer) r21, ((Integer) 0)) = (Integer) r22;
	tag_incr_hp(r21, mktag(1), ((Integer) 2));
	tag_incr_hp(r22, mktag(0), ((Integer) 2));
	tag_incr_hp(r23, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r23, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r24, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r24, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r24, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r24, ((Integer) 2)) = (Integer) r6;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r7;
	field(mktag(3), (Integer) r23, ((Integer) 1)) = (Integer) r24;
	field(mktag(3), (Integer) r24, ((Integer) 3)) = (Integer) r1;
	tag_incr_hp(r24, mktag(0), ((Integer) 1));
	tag_incr_hp(r25, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r25, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r25, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r25, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r22, ((Integer) 1)) = string_const("copy old field", 14);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r7;
	field(mktag(3), (Integer) r23, ((Integer) 2)) = (Integer) r24;
	field(mktag(3), (Integer) r25, ((Integer) 3)) = (Integer) r1;
	field(mktag(1), (Integer) r21, ((Integer) 0)) = (Integer) r22;
	field(mktag(0), (Integer) r22, ((Integer) 0)) = (Integer) r23;
	field(mktag(0), (Integer) r24, ((Integer) 0)) = (Integer) r25;
	tag_incr_hp(r22, mktag(1), ((Integer) 2));
	tag_incr_hp(r23, mktag(0), ((Integer) 2));
	tag_incr_hp(r24, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r24, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r25, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r25, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r25, ((Integer) 1)) = ((Integer) 23);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r7;
	field(mktag(3), (Integer) r25, ((Integer) 2)) = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(14);
	field(mktag(3), (Integer) r24, ((Integer) 1)) = (Integer) r25;
	field(mktag(3), (Integer) r25, ((Integer) 3)) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r23, ((Integer) 1)) = string_const("repeat the loop?", 16);
	field(mktag(3), (Integer) r24, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r22, ((Integer) 0)) = (Integer) r23;
	field(mktag(0), (Integer) r23, ((Integer) 0)) = (Integer) r24;
	tag_incr_hp(r23, mktag(1), ((Integer) 2));
	tag_incr_hp(r24, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(0), (Integer) r24, ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) r7;
	r3 = (Integer) detstackvar(16);
	detstackvar(10) = (Integer) r6;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) detstackvar(8), ((Integer) 0)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) r21, ((Integer) 1)) = (Integer) r22;
	field(mktag(1), (Integer) r22, ((Integer) 1)) = (Integer) r23;
	field(mktag(1), (Integer) r23, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r23, ((Integer) 0)) = (Integer) r24;
	field(mktag(0), (Integer) r24, ((Integer) 1)) = string_const("end of loop", 11);
	call_localret(STATIC(mercury__unify_gen__generate_extra_closure_args_6_0),
		mercury__unify_gen__generate_construction_2_7_0_i32,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i32);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i33,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i33);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i34,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i34);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i35,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i35);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i41);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i16);
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i36,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i36);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury__code_info__make_entry_label_7_0);
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__unify_gen__generate_construction_2_7_0_i37,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i37);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i38,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i38);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_gen__generate_construction_2_7_0_i39,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i39);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__unify_gen__generate_pred_args_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i40,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
Define_label(mercury__unify_gen__generate_construction_2_7_0_i40);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r2, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = ((Integer) 0);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r2, ((Integer) 2)) = ((Integer) 1);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i41);
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i42,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i42);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	proceed();
Define_label(mercury__unify_gen__generate_construction_2_7_0_i43);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i44);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r5;
	r5 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) r6;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i48);
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i44);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r6;
	detstackvar(4) = (Integer) r4;
	r1 = string_const("unify_gen: address constant has args", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2_7_0_i47,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i47);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i48);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i49,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i49);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r4 = ((Integer) 1);
	{
	Declare_entry(mercury__code_info__make_entry_label_7_0);
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__unify_gen__generate_construction_2_7_0_i50,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i50);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i42,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i52);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i53);
	r6 = (Integer) r1;
	r1 = (Integer) r2;
	r3 = (Integer) r5;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r8, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 2);
	tag_incr_hp(r9, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 2)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i57);
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i53);
	detstackvar(1) = (Integer) r2;
	r1 = string_const("unify_gen: address constant has args", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2_7_0_i56,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i56);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
Define_label(mercury__unify_gen__generate_construction_2_7_0_i57);
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i42,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i59);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i60,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i60);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i61,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i61);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__unify_gen__var_types_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i62,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
Define_label(mercury__unify_gen__generate_construction_2_7_0_i62);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__unify_gen__generate_cons_args_5_0),
		mercury__unify_gen__generate_construction_2_7_0_i63,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i63);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r2, ((Integer) 2)) = ((Integer) 1);
	field(mktag(2), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i6,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i65);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i66,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i66);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2_7_0_i67,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i67);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__unify_gen__var_types_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i68,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
Define_label(mercury__unify_gen__generate_construction_2_7_0_i68);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__unify_gen__generate_cons_args_5_0),
		mercury__unify_gen__generate_construction_2_7_0_i69,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i69);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(2), (Integer) r2, ((Integer) 2)) = ((Integer) 1);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i6,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i71);
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	tag_incr_hp(r4, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = ((Integer) 3);
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r3 = (Integer) r5;
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) r6;
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i6,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i1002);
	incr_sp_push_msg(21, "unify_gen__generate_construction_2");
	detstackvar(21) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i73);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i74);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i74);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i74);
	if (((Integer) field(mktag(1), (Integer) r4, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i74);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i80,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i80);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r3 = (Integer) r1;
	r5 = (Integer) r2;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	tailcall(STATIC(mercury__unify_gen__generate_sub_unify_7_0),
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
Define_label(mercury__unify_gen__generate_construction_2_7_0_i74);
	r1 = string_const("unify_gen__generate_construction_2: no_tag: arity != 1", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2_7_0_i42,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i73);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2_7_0_i84);
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r3 = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i6,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i84);
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2_7_0_i86,
		STATIC(mercury__unify_gen__generate_construction_2_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_construction_2_7_0_i86);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(21);
	decr_sp_pop_msg(21);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module9)
	init_entry(mercury__unify_gen__generate_extra_closure_args_6_0);
	init_label(mercury__unify_gen__generate_extra_closure_args_6_0_i4);
	init_label(mercury__unify_gen__generate_extra_closure_args_6_0_i5);
	init_label(mercury__unify_gen__generate_extra_closure_args_6_0_i1015);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_extra_closure_args'/6 in mode 0 */
Define_static(mercury__unify_gen__generate_extra_closure_args_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_extra_closure_args_6_0_i1015);
	incr_sp_push_msg(4, "unify_gen__generate_extra_closure_args");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_extra_closure_args_6_0_i4,
		STATIC(mercury__unify_gen__generate_extra_closure_args_6_0));
	}
Define_label(mercury__unify_gen__generate_extra_closure_args_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_extra_closure_args_6_0));
	r4 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	detstackvar(1) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) r4;
	tag_incr_hp(r9, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r9, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_unify_gen__common_5);
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("increment argument counter", 26);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) r9;
	field(mktag(3), (Integer) r9, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(r9, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r10, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r10, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r10, ((Integer) 1)) = ((Integer) 0);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r10, ((Integer) 2)) = (Integer) r1;
	field(mktag(3), (Integer) r9, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	r2 = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = (Integer) r3;
	field(mktag(3), (Integer) r10, ((Integer) 3)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(2), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("set new argument field", 22);
	localcall(mercury__unify_gen__generate_extra_closure_args_6_0,
		LABEL(mercury__unify_gen__generate_extra_closure_args_6_0_i5),
		STATIC(mercury__unify_gen__generate_extra_closure_args_6_0));
	}
Define_label(mercury__unify_gen__generate_extra_closure_args_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_extra_closure_args_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_extra_closure_args_6_0_i1015);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module10)
	init_entry(mercury__unify_gen__generate_pred_args_3_0);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i1010);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i9);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i10);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i1006);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i1008);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_pred_args'/3 in mode 0 */
Define_static(mercury__unify_gen__generate_pred_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i1006);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i1008);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i1010);
	r2 = (Integer) r4;
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) r6;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	incr_sp_push_msg(2, "unify_gen__generate_pred_args");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i9);
	}
Define_label(mercury__unify_gen__generate_pred_args_3_0_i1010);
	incr_sp_push_msg(2, "unify_gen__generate_pred_args");
	detstackvar(2) = (Integer) succip;
	r2 = (Integer) r4;
	r1 = (Integer) r3;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__unify_gen__generate_pred_args_3_0_i9);
	detstackvar(1) = (Integer) r3;
	localcall(mercury__unify_gen__generate_pred_args_3_0,
		LABEL(mercury__unify_gen__generate_pred_args_3_0_i10),
		STATIC(mercury__unify_gen__generate_pred_args_3_0));
Define_label(mercury__unify_gen__generate_pred_args_3_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_pred_args_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__unify_gen__generate_pred_args_3_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__unify_gen__generate_pred_args_3_0_i1008);
	r1 = string_const("unify_gen__generate_pred_args: insufficient args", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_pred_args_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module11)
	init_entry(mercury__unify_gen__generate_cons_args_5_0);
	init_label(mercury__unify_gen__generate_cons_args_5_0_i4);
	init_label(mercury__unify_gen__generate_cons_args_5_0_i1000);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_cons_args'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_cons_args_5_0);
	incr_sp_push_msg(1, "unify_gen__generate_cons_args");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__unify_gen__generate_cons_args_2_5_0),
		mercury__unify_gen__generate_cons_args_5_0_i4,
		STATIC(mercury__unify_gen__generate_cons_args_5_0));
Define_label(mercury__unify_gen__generate_cons_args_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_cons_args_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_5_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_5_0_i1000);
	r1 = string_const("unify_gen__generate_cons_args: length mismatch", 46);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_cons_args_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module12)
	init_entry(mercury__unify_gen__generate_cons_args_2_5_0);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i1015);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i10);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i9);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i11);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i12);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i1012);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i1);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_cons_args_2'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_cons_args_2_5_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1015);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1012);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1012);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i1015);
	incr_sp_push_msg(6, "unify_gen__generate_cons_args_2");
	detstackvar(6) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1)), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0)), ((Integer) 1));
	r1 = (Integer) r4;
	detstackvar(1) = (Integer) r4;
	{
	Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__unify_gen__generate_cons_args_2_5_0_i10,
		STATIC(mercury__unify_gen__generate_cons_args_2_5_0));
	}
	}
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_cons_args_2_5_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i9);
	r4 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i11);
	}
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i9);
	r4 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i11);
	detstackvar(2) = (Integer) r5;
	localcall(mercury__unify_gen__generate_cons_args_2_5_0,
		LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i12),
		STATIC(mercury__unify_gen__generate_cons_args_2_5_0));
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_cons_args_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i1012);
	r1 = FALSE;
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module13)
	init_entry(mercury__unify_gen__var_types_4_0);
	init_label(mercury__unify_gen__var_types_4_0_i2);
	init_label(mercury__unify_gen__var_types_4_0_i3);
	init_label(mercury__unify_gen__var_types_4_0_i4);
BEGIN_CODE

/* code for predicate 'unify_gen__var_types'/4 in mode 0 */
Define_static(mercury__unify_gen__var_types_4_0);
	incr_sp_push_msg(3, "unify_gen__var_types");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_proc_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__unify_gen__var_types_4_0_i2,
		STATIC(mercury__unify_gen__var_types_4_0));
	}
Define_label(mercury__unify_gen__var_types_4_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_types_4_0));
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__unify_gen__var_types_4_0_i3,
		STATIC(mercury__unify_gen__var_types_4_0));
	}
Define_label(mercury__unify_gen__var_types_4_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_types_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__apply_to_list_3_0);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__unify_gen__var_types_4_0_i4,
		STATIC(mercury__unify_gen__var_types_4_0));
	}
Define_label(mercury__unify_gen__var_types_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_types_4_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module14)
	init_entry(mercury__unify_gen__make_fields_and_argvars_6_0);
	init_label(mercury__unify_gen__make_fields_and_argvars_6_0_i3);
	init_label(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
	init_label(mercury__unify_gen__make_fields_and_argvars_6_0_i1);
BEGIN_CODE

/* code for predicate 'unify_gen__make_fields_and_argvars'/6 in mode 0 */
Define_static(mercury__unify_gen__make_fields_and_argvars_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__make_fields_and_argvars_6_0_i1);
	r8 = (Integer) sp;
Define_label(mercury__unify_gen__make_fields_and_argvars_6_0_i3);
	incr_sp_push_msg(2, "unify_gen__make_fields_and_argvars");
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) r6;
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(detstackvar(2), mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) detstackvar(2), ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = ((Integer) r3 + ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__make_fields_and_argvars_6_0_i3);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	}
Define_label(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
	while (1) {
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	decr_sp_pop_msg(2);
	if (((Integer) sp > (Integer) r8))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__unify_gen__make_fields_and_argvars_6_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module15)
	init_entry(mercury__unify_gen__generate_unify_args_7_0);
	init_label(mercury__unify_gen__generate_unify_args_7_0_i4);
	init_label(mercury__unify_gen__generate_unify_args_7_0_i1000);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_unify_args'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_unify_args_7_0);
	incr_sp_push_msg(1, "unify_gen__generate_unify_args");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__unify_gen__generate_unify_args_2_7_0),
		mercury__unify_gen__generate_unify_args_7_0_i4,
		STATIC(mercury__unify_gen__generate_unify_args_7_0));
Define_label(mercury__unify_gen__generate_unify_args_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unify_args_7_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_7_0_i1000);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_7_0_i1000);
	r1 = string_const("unify_gen__generate_unify_args: length mismatch", 47);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_unify_args_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module16)
	init_entry(mercury__unify_gen__generate_unify_args_2_7_0);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i1013);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i10);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i11);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i1010);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i1);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_unify_args_2'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_unify_args_2_7_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1013);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1010);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1010);
	if (((Integer) r4 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1010);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i1013);
	incr_sp_push_msg(5, "unify_gen__generate_unify_args_2");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	call_localret(STATIC(mercury__unify_gen__generate_sub_unify_7_0),
		mercury__unify_gen__generate_unify_args_2_7_0_i10,
		STATIC(mercury__unify_gen__generate_unify_args_2_7_0));
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unify_args_2_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	localcall(mercury__unify_gen__generate_unify_args_2_7_0,
		LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i11),
		STATIC(mercury__unify_gen__generate_unify_args_2_7_0));
	}
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unify_args_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module17)
	init_entry(mercury__unify_gen__generate_sub_unify_7_0);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i2);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i3);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i4);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i5);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i10);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i15);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i20);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_sub_unify'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_sub_unify_7_0);
	incr_sp_push_msg(8, "unify_gen__generate_sub_unify");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	tempr2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) r5;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_sub_unify_7_0_i2,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__unify_gen__generate_sub_unify_7_0_i3,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(7);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__unify_gen__generate_sub_unify_7_0_i4,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i5);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i5);
	r1 = string_const("test in arg of [de]construction", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i5);
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i10);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i10);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_gen__generate_sub_assign_5_0),
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i10);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i15);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i15);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_gen__generate_sub_assign_5_0),
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i15);
	if (((Integer) detstackvar(3) != ((Integer) 2)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i20);
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i20);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i20);
	r1 = string_const("unify_gen__generate_sub_unify: some strange unify", 49);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module18)
	init_entry(mercury__unify_gen__generate_sub_assign_5_0);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i6);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i7);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i10);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i5);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i12);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i13);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i14);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i1002);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i23);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i25);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i22);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i26);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i20);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i29);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i31);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i28);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i32);
BEGIN_CODE

/* code for predicate 'unify_gen__generate_sub_assign'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_sub_assign_5_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i1002);
	incr_sp_push_msg(4, "unify_gen__generate_sub_assign");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i5);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__materialize_vars_in_rval_5_0);
	call_localret(ENTRY(mercury__code_info__materialize_vars_in_rval_5_0),
		mercury__unify_gen__generate_sub_assign_5_0_i6,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i7);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) tempr1;
	r2 = (Integer) r3;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("Copy field", 10);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i7);
	detstackvar(1) = (Integer) r3;
	r1 = string_const("unify_gen__generate_sub_assign: lval vanished with lval", 55);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_assign_5_0_i10,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i5);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_sub_assign_5_0_i12,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r4 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__materialize_vars_in_rval_5_0);
	call_localret(ENTRY(mercury__code_info__materialize_vars_in_rval_5_0),
		mercury__unify_gen__generate_sub_assign_5_0_i13,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i14);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	r2 = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("Copy value", 10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i14);
	detstackvar(1) = (Integer) r3;
	r1 = string_const("unify_gen__generate_sub_assign: lval vanished with ref", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_assign_5_0_i10,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i1002);
	incr_sp_push_msg(4, "unify_gen__generate_sub_assign");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i20);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	r2 = (Integer) r3;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_is_live_3_0);
	call_localret(ENTRY(mercury__code_info__variable_is_live_3_0),
		mercury__unify_gen__generate_sub_assign_5_0_i23,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i22);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_sub_assign_5_0_i25,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r2 = (Integer) r1;
	GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i26);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i22);
	r2 = (Integer) detstackvar(1);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i26);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i20);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	r2 = (Integer) r3;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_is_live_3_0);
	call_localret(ENTRY(mercury__code_info__variable_is_live_3_0),
		mercury__unify_gen__generate_sub_assign_5_0_i29,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i28);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_sub_assign_5_0_i31,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r2 = (Integer) r1;
	GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i32);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i28);
	r2 = (Integer) detstackvar(1);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i32);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module19)
	init_entry(mercury____Unify___unify_gen__test_sense_0_0);
	init_label(mercury____Unify___unify_gen__test_sense_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___unify_gen__test_sense_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___unify_gen__test_sense_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___unify_gen__test_sense_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module20)
	init_entry(mercury____Index___unify_gen__test_sense_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___unify_gen__test_sense_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___unify_gen__test_sense_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__unify_gen_module21)
	init_entry(mercury____Compare___unify_gen__test_sense_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___unify_gen__test_sense_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___unify_gen__test_sense_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__unify_gen_bunch_0(void)
{
	mercury__unify_gen_module0();
	mercury__unify_gen_module1();
	mercury__unify_gen_module2();
	mercury__unify_gen_module3();
	mercury__unify_gen_module4();
	mercury__unify_gen_module5();
	mercury__unify_gen_module6();
	mercury__unify_gen_module7();
	mercury__unify_gen_module8();
	mercury__unify_gen_module9();
	mercury__unify_gen_module10();
	mercury__unify_gen_module11();
	mercury__unify_gen_module12();
	mercury__unify_gen_module13();
	mercury__unify_gen_module14();
	mercury__unify_gen_module15();
	mercury__unify_gen_module16();
	mercury__unify_gen_module17();
	mercury__unify_gen_module18();
	mercury__unify_gen_module19();
	mercury__unify_gen_module20();
	mercury__unify_gen_module21();
}

#endif

void mercury__unify_gen__init(void); /* suppress gcc warning */
void mercury__unify_gen__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__unify_gen_bunch_0();
#endif
}
