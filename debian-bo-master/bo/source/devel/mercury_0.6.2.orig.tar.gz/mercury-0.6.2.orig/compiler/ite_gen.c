/*
** Automatically generated from `ite_gen.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__ite_gen__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__ite_gen__generate_det_ite_7_0);
Define_extern_entry(mercury__ite_gen__generate_semidet_ite_7_0);
Define_extern_entry(mercury__ite_gen__generate_nondet_ite_7_0);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i2);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i3);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i6);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i7);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i8);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i11);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i12);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i13);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i14);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i18);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i19);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i15);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i20);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i21);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i24);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i26);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i23);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i28);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i29);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i30);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i31);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i32);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i33);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i34);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i35);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i36);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i40);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i41);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i37);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i42);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i43);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i44);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i45);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i49);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i46);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i50);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i51);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i52);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i53);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i54);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i55);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i56);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i57);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i58);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i59);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i60);
Declare_label(mercury__ite_gen__generate_nondet_ite_7_0_i61);
Declare_static(mercury__ite_gen__generate_basic_ite_8_0);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i2);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i3);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i6);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i7);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i8);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i9);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i10);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i13);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i15);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i12);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i17);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i18);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i19);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i20);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i21);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i22);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i23);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i24);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i25);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i26);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i27);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i28);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i29);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i30);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i31);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i32);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i33);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i34);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i35);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i36);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i37);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i38);
Declare_label(mercury__ite_gen__generate_basic_ite_8_0_i39);

BEGIN_MODULE(mercury__ite_gen_module0)
	init_entry(mercury__ite_gen__generate_det_ite_7_0);
BEGIN_CODE

/* code for predicate 'ite_gen__generate_det_ite'/7 in mode 0 */
Define_entry(mercury__ite_gen__generate_det_ite_7_0);
	r6 = (Integer) r5;
	r5 = ((Integer) 0);
	tailcall(STATIC(mercury__ite_gen__generate_basic_ite_8_0),
		ENTRY(mercury__ite_gen__generate_det_ite_7_0));
END_MODULE

BEGIN_MODULE(mercury__ite_gen_module1)
	init_entry(mercury__ite_gen__generate_semidet_ite_7_0);
BEGIN_CODE

/* code for predicate 'ite_gen__generate_semidet_ite'/7 in mode 0 */
Define_entry(mercury__ite_gen__generate_semidet_ite_7_0);
	r6 = (Integer) r5;
	r5 = ((Integer) 1);
	tailcall(STATIC(mercury__ite_gen__generate_basic_ite_8_0),
		ENTRY(mercury__ite_gen__generate_semidet_ite_7_0));
END_MODULE

BEGIN_MODULE(mercury__ite_gen_module2)
	init_entry(mercury__ite_gen__generate_nondet_ite_7_0);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i2);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i3);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i6);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i7);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i8);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i11);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i12);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i13);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i14);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i18);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i19);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i15);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i20);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i21);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i24);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i26);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i23);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i28);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i29);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i30);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i31);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i32);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i33);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i34);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i35);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i36);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i40);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i41);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i37);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i42);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i43);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i44);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i45);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i49);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i46);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i50);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i51);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i52);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i53);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i54);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i55);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i56);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i57);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i58);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i59);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i60);
	init_label(mercury__ite_gen__generate_nondet_ite_7_0_i61);
BEGIN_CODE

/* code for predicate 'ite_gen__generate_nondet_ite'/7 in mode 0 */
Define_entry(mercury__ite_gen__generate_nondet_ite_7_0);
	incr_sp_push_msg(27, "ite_gen__generate_nondet_ite");
	detstackvar(27) = (Integer) succip;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i2,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i2);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	r7 = ((Integer) 0);
	GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i6);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	r7 = ((Integer) 1);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r7;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i7,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i7);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i8);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) detstackvar(7);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i12);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i8);
	r1 = string_const("condition of an if-then-else has no resume point", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i11,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i11);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r4 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(6);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i12);
	detstackvar(1) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(5) = (Integer) r9;
	detstackvar(6) = (Integer) r10;
	detstackvar(7) = (Integer) r3;
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__make_known_failure_cont_8_0);
	call_localret(ENTRY(mercury__code_info__make_known_failure_cont_8_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i13,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i13);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r1 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_resume_point_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i14,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i14);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	if (((Integer) detstackvar(7) != ((Integer) 0)))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i15);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__unset_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__unset_failure_cont_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i18,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i18);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__save_maxfr_4_0);
	call_localret(ENTRY(mercury__code_info__save_maxfr_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i19,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i19);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r10 = (Integer) r2;
	r12 = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(9);
	tag_incr_hp(r11, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) r12;
	GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i20);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i15);
	r8 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(6);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r10 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r11 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i20);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i21,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i21);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(12) = (Integer) r1;
	detstackvar(26) = (Integer) r2;
	r2 = ((Integer) 69);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_1);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__ite_gen__generate_nondet_ite_7_0_i24,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i24);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i23);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_util__goal_may_allocate_heap_1_0);
	call_localret(ENTRY(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i26,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i26);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i23);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(26);
	GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i28);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i23);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(26);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i28);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(5) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_hp_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i29,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i29);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) r2;
	r1 = (Integer) detstackvar(12);
	r2 = ((Integer) 53);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i30,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i30);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r2 = (Integer) detstackvar(14);
	detstackvar(14) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_ticket_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i31,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i31);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i32,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i32);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__code_info__push_resume_point_vars_3_0);
	call_localret(ENTRY(mercury__code_info__push_resume_point_vars_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i33,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i33);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i34,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i34);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(17) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pop_resume_point_vars_2_0);
	call_localret(ENTRY(mercury__code_info__pop_resume_point_vars_2_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i35,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i35);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	{
	Declare_entry(mercury__code_info__pop_failure_cont_2_0);
	call_localret(ENTRY(mercury__code_info__pop_failure_cont_2_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i36,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i36);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	if (((Integer) detstackvar(11) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i37);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(11), ((Integer) 0));
	{
	Declare_entry(mercury__code_info__do_soft_cut_4_0);
	call_localret(ENTRY(mercury__code_info__do_soft_cut_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i40,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i40);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(18) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__unset_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__unset_failure_cont_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i41,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i41);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r16 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(15);
	r13 = (Integer) detstackvar(16);
	r14 = (Integer) detstackvar(17);
	r15 = (Integer) detstackvar(18);
	GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i42);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i37);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(15);
	r13 = (Integer) detstackvar(16);
	r14 = (Integer) detstackvar(17);
	r15 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r16 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i42);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	detstackvar(13) = (Integer) r10;
	detstackvar(14) = (Integer) r11;
	detstackvar(15) = (Integer) r12;
	detstackvar(16) = (Integer) r13;
	detstackvar(17) = (Integer) r14;
	detstackvar(18) = (Integer) r15;
	detstackvar(19) = (Integer) r16;
	{
	Declare_entry(mercury__code_info__pickup_zombies_3_0);
	call_localret(ENTRY(mercury__code_info__pickup_zombies_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i43,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i43);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i44,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i44);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__maybe_pop_stack_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_pop_stack_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i45,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i45);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	if (((Integer) detstackvar(7) != ((Integer) 0)))
		GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i46);
	detstackvar(20) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__code_info__maybe_pop_stack_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_pop_stack_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i49,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i49);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(15);
	r13 = (Integer) detstackvar(16);
	r14 = (Integer) detstackvar(17);
	r15 = (Integer) detstackvar(18);
	r16 = (Integer) detstackvar(19);
	r17 = (Integer) detstackvar(20);
	r18 = (Integer) r1;
	r1 = ((Integer) 2);
	GOTO_LABEL(mercury__ite_gen__generate_nondet_ite_7_0_i51);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i46);
	detstackvar(20) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__code_info__maybe_discard_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_discard_ticket_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i50,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i50);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(15);
	r13 = (Integer) detstackvar(16);
	r14 = (Integer) detstackvar(17);
	r15 = (Integer) detstackvar(18);
	r16 = (Integer) detstackvar(19);
	r17 = (Integer) detstackvar(20);
	r18 = (Integer) r1;
	r1 = ((Integer) 2);
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i51);
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	detstackvar(13) = (Integer) r10;
	detstackvar(14) = (Integer) r11;
	detstackvar(15) = (Integer) r12;
	detstackvar(16) = (Integer) r13;
	detstackvar(17) = (Integer) r14;
	detstackvar(18) = (Integer) r15;
	detstackvar(19) = (Integer) r16;
	detstackvar(20) = (Integer) r17;
	detstackvar(21) = (Integer) r18;
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i52,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i52);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) r2;
	detstackvar(22) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i53,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i53);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) detstackvar(16);
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i54,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i54);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	{
	Declare_entry(mercury__code_info__restore_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__restore_failure_cont_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i55,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i55);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__maybe_restore_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_hp_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i56,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i56);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) detstackvar(14);
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__maybe_restore_ticket_and_pop_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_ticket_and_pop_4_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i57,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i57);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) r2;
	detstackvar(23) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i58,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i58);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) r2;
	detstackvar(24) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i59,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i59);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	detstackvar(25) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i60,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i60);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r3 = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	detstackvar(4) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(13);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(15);
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(17);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(18);
	tag_incr_hp(r10, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(19);
	tag_incr_hp(r11, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(20);
	tag_incr_hp(r12, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r12, ((Integer) 0)) = (Integer) detstackvar(21);
	tag_incr_hp(r13, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(22);
	tag_incr_hp(r14, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(16);
	tag_incr_hp(r15, mktag(2), ((Integer) 2));
	tag_incr_hp(r16, mktag(1), ((Integer) 1));
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	tag_incr_hp(r18, mktag(0), ((Integer) 2));
	tag_incr_hp(r19, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r19, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r18, ((Integer) 1)) = string_const("Jump to the end of if-then-else", 31);
	field(mktag(3), (Integer) r19, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(0), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	tag_incr_hp(r16, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r16, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r17, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r17, ((Integer) 0)) = (Integer) detstackvar(14);
	tag_incr_hp(r18, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r18, ((Integer) 0)) = (Integer) detstackvar(23);
	tag_incr_hp(r19, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r19, ((Integer) 0)) = (Integer) detstackvar(24);
	tag_incr_hp(r20, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r20, ((Integer) 0)) = (Integer) detstackvar(25);
	tag_incr_hp(r21, mktag(1), ((Integer) 1));
	tag_incr_hp(r22, mktag(1), ((Integer) 2));
	tag_incr_hp(r23, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r23, ((Integer) 0)) = (Integer) r3;
	r1 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) detstackvar(4), ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(2), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(2), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(2), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(2), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(2), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(2), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(2), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(2), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(2), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(2), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(2), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) r21, ((Integer) 0)) = (Integer) r22;
	field(mktag(1), (Integer) r22, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r22, ((Integer) 0)) = (Integer) r23;
	field(mktag(0), (Integer) r23, ((Integer) 1)) = string_const("end of if-then-else", 19);
	{
	Declare_entry(mercury__code_info__remake_with_store_map_3_0);
	call_localret(ENTRY(mercury__code_info__remake_with_store_map_3_0),
		mercury__ite_gen__generate_nondet_ite_7_0_i61,
		ENTRY(mercury__ite_gen__generate_nondet_ite_7_0));
	}
	}
Define_label(mercury__ite_gen__generate_nondet_ite_7_0_i61);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_nondet_ite_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(27);
	decr_sp_pop_msg(27);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ite_gen_module3)
	init_entry(mercury__ite_gen__generate_basic_ite_8_0);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i2);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i3);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i6);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i7);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i8);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i9);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i10);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i13);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i15);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i12);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i17);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i18);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i19);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i20);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i21);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i22);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i23);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i24);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i25);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i26);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i27);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i28);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i29);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i30);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i31);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i32);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i33);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i34);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i35);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i36);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i37);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i38);
	init_label(mercury__ite_gen__generate_basic_ite_8_0_i39);
BEGIN_CODE

/* code for predicate 'ite_gen__generate_basic_ite'/8 in mode 0 */
Define_static(mercury__ite_gen__generate_basic_ite_8_0);
	incr_sp_push_msg(22, "ite_gen__generate_basic_ite");
	detstackvar(22) = (Integer) succip;
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__ite_gen__generate_basic_ite_8_0_i2,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i2);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__ite_gen__generate_basic_ite_8_0_i3);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = ((Integer) 1);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(6);
	r11 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__ite_gen__generate_basic_ite_8_0_i7);
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i3);
	r1 = string_const("condition of an if-then-else has no resume point", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__ite_gen__generate_basic_ite_8_0_i6,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i6);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(4);
	r10 = (Integer) detstackvar(6);
	r11 = (Integer) detstackvar(7);
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i7);
	detstackvar(1) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	detstackvar(6) = (Integer) r10;
	detstackvar(7) = (Integer) r11;
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__make_known_failure_cont_8_0);
	call_localret(ENTRY(mercury__code_info__make_known_failure_cont_8_0),
		mercury__ite_gen__generate_basic_ite_8_0_i8,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i8);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r1 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	detstackvar(5) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_resume_point_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i9,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i9);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i10,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i10);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(21) = (Integer) r2;
	r2 = ((Integer) 69);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_1);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__ite_gen__generate_basic_ite_8_0_i13,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i13);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ite_gen__generate_basic_ite_8_0_i12);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__code_util__goal_may_allocate_heap_1_0);
	call_localret(ENTRY(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__ite_gen__generate_basic_ite_8_0_i15,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i15);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ite_gen__generate_basic_ite_8_0_i12);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(9);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(21);
	GOTO_LABEL(mercury__ite_gen__generate_basic_ite_8_0_i17);
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i12);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(9);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(21);
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i17);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(6) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_hp_4_0),
		mercury__ite_gen__generate_basic_ite_8_0_i18,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i18);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) detstackvar(9);
	r2 = ((Integer) 53);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i19,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i19);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_ticket_4_0),
		mercury__ite_gen__generate_basic_ite_8_0_i20,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i20);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i21,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i21);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__code_info__push_resume_point_vars_3_0);
	call_localret(ENTRY(mercury__code_info__push_resume_point_vars_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i22,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i22);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__ite_gen__generate_basic_ite_8_0_i23,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i23);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pop_resume_point_vars_2_0);
	call_localret(ENTRY(mercury__code_info__pop_resume_point_vars_2_0),
		mercury__ite_gen__generate_basic_ite_8_0_i24,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i24);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	{
	Declare_entry(mercury__code_info__pickup_zombies_3_0);
	call_localret(ENTRY(mercury__code_info__pickup_zombies_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i25,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i25);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i26,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i26);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	{
	Declare_entry(mercury__code_info__pop_failure_cont_2_0);
	call_localret(ENTRY(mercury__code_info__pop_failure_cont_2_0),
		mercury__ite_gen__generate_basic_ite_8_0_i27,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i27);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__maybe_pop_stack_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_pop_stack_4_0),
		mercury__ite_gen__generate_basic_ite_8_0_i28,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i28);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_info__maybe_discard_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_discard_ticket_4_0),
		mercury__ite_gen__generate_basic_ite_8_0_i29,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i29);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) r2;
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__ite_gen__generate_basic_ite_8_0_i30,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i30);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) r2;
	detstackvar(17) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__ite_gen__generate_basic_ite_8_0_i31,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i31);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) detstackvar(13);
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i32,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i32);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	{
	Declare_entry(mercury__code_info__restore_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__restore_failure_cont_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i33,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i33);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__maybe_restore_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_hp_4_0),
		mercury__ite_gen__generate_basic_ite_8_0_i34,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i34);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__maybe_restore_ticket_and_pop_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_ticket_and_pop_4_0),
		mercury__ite_gen__generate_basic_ite_8_0_i35,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i35);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) r2;
	detstackvar(18) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__ite_gen__generate_basic_ite_8_0_i36,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i36);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) r2;
	detstackvar(19) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__ite_gen__generate_basic_ite_8_0_i37,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i37);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	detstackvar(20) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i38,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i38);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r3 = (Integer) detstackvar(5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	detstackvar(5) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(14);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(15);
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(16);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(17);
	tag_incr_hp(r10, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(13);
	tag_incr_hp(r11, mktag(2), ((Integer) 2));
	tag_incr_hp(r12, mktag(1), ((Integer) 1));
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	tag_incr_hp(r15, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r15, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r14, ((Integer) 1)) = string_const("Jump to the end of if-then-else", 31);
	field(mktag(3), (Integer) r15, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	tag_incr_hp(r12, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r12, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r13, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(11);
	tag_incr_hp(r14, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(18);
	tag_incr_hp(r15, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r15, ((Integer) 0)) = (Integer) detstackvar(19);
	tag_incr_hp(r16, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r16, ((Integer) 0)) = (Integer) detstackvar(20);
	tag_incr_hp(r17, mktag(1), ((Integer) 1));
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	tag_incr_hp(r19, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r19, ((Integer) 0)) = (Integer) r3;
	r1 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) detstackvar(5), ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(2), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(2), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(2), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(2), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(2), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(2), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(2), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r19;
	field(mktag(0), (Integer) r19, ((Integer) 1)) = string_const("end of if-then-else", 19);
	{
	Declare_entry(mercury__code_info__remake_with_store_map_3_0);
	call_localret(ENTRY(mercury__code_info__remake_with_store_map_3_0),
		mercury__ite_gen__generate_basic_ite_8_0_i39,
		STATIC(mercury__ite_gen__generate_basic_ite_8_0));
	}
	}
Define_label(mercury__ite_gen__generate_basic_ite_8_0_i39);
	update_prof_current_proc(LABEL(mercury__ite_gen__generate_basic_ite_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(22);
	decr_sp_pop_msg(22);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__ite_gen_bunch_0(void)
{
	mercury__ite_gen_module0();
	mercury__ite_gen_module1();
	mercury__ite_gen_module2();
	mercury__ite_gen_module3();
}

#endif

void mercury__ite_gen__init(void); /* suppress gcc warning */
void mercury__ite_gen__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__ite_gen_bunch_0();
#endif
}
