/*
** Automatically generated from `modecheck_call.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__modecheck_call__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__modecheck_call__modecheck_call_pred_7_0);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i2);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i3);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i4);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i5);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i6);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i7);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i8);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i14);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i16);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i17);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i10);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i9);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i24);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i26);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i27);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i28);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i29);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i30);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i31);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i32);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i33);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i34);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i38);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i39);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i35);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i18);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i41);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i42);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i43);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i44);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i45);
Declare_label(mercury__modecheck_call__modecheck_call_pred_7_0_i46);
Define_extern_entry(mercury__modecheck_call__modecheck_higher_order_call_10_0);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i2);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i3);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i4);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i5);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i6);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i7);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i12);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i13);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i14);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i15);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i16);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i17);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i18);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i21);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i22);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i23);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i20);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i9);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i25);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i26);
Declare_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i27);
Define_extern_entry(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i2);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i3);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i4);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i5);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i6);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i7);
Declare_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i8);
Declare_static(mercury__modecheck_call__modecheck_call_pred_2_10_0);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i4);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i5);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i6);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i7);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i8);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i9);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i10);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i11);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i15);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i16);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i12);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i18);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i19);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i20);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i24);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i25);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i21);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i3);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i28);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i29);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i30);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i33);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i35);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i36);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i32);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i38);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i39);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i40);
Declare_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i41);
Declare_static(mercury__modecheck_call__insert_new_mode_5_0);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i2);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i3);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i4);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i5);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i6);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i7);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i8);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i9);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i10);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i11);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i12);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i13);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i14);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i15);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i16);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i17);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i18);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i19);
Declare_label(mercury__modecheck_call__insert_new_mode_5_0_i20);
Declare_static(mercury__modecheck_call__get_var_insts_and_lives_4_0);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i4);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i5);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i6);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i7);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i8);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i9);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i14);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i16);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i13);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i19);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i20);
Declare_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i1006);

Word mercury_data_modecheck_call__common_0[] = {
	((Integer) 1)
};

Word mercury_data_modecheck_call__common_1[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_modecheck_call__common_2[] = {
	((Integer) 0)
};

BEGIN_MODULE(mercury__modecheck_call_module0)
	init_entry(mercury__modecheck_call__modecheck_call_pred_7_0);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i2);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i3);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i4);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i5);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i6);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i7);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i8);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i14);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i16);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i17);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i10);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i9);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i24);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i26);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i27);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i28);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i29);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i30);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i31);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i32);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i33);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i34);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i38);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i39);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i35);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i18);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i41);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i42);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i43);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i44);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i45);
	init_label(mercury__modecheck_call__modecheck_call_pred_7_0_i46);
BEGIN_CODE

/* code for predicate 'modecheck_call_pred'/7 in mode 0 */
Define_entry(mercury__modecheck_call__modecheck_call_pred_7_0);
	incr_sp_push_msg(11, "modecheck_call_pred");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__mode_info__mode_info_get_preds_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_preds_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i2,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i2);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i3,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i3);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modecheck_call__modecheck_call_pred_7_0_i4,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i4);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	{
	Declare_entry(mercury__clause_to_proc__maybe_add_default_mode_2_0);
	call_localret(ENTRY(mercury__clause_to_proc__maybe_add_default_mode_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i5,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i5);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i6,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i6);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r3 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i7,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i7);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i8,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i8);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	if (((Integer) detstackvar(8) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_7_0_i9);
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_marker_status_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_modecheck_call__common_0);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i14,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i14);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_7_0_i10);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i16,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i16);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_info__mode_info_error_4_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_error_4_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i17,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i17);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r4 = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_modecheck_call__common_1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i10);
	r1 = (Integer) detstackvar(3);
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i9);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(8);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_7_0_i18);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_7_0_i18);
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_marker_status_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_modecheck_call__common_0);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i24,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i24);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_7_0_i18);
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modecheck_call__modecheck_call_pred_7_0_i26,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i26);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i27,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i27);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_arglives_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arglives_3_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i28,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i28);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = ((Integer) 0);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__modes__modecheck_var_list_is_live_5_0);
	call_localret(ENTRY(mercury__modes__modecheck_var_list_is_live_5_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i29,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i29);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i30,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i30);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r4 = (Integer) detstackvar(10);
	r2 = (Integer) r1;
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__modes__modecheck_var_has_inst_list_5_0);
	call_localret(ENTRY(mercury__modes__modecheck_var_has_inst_list_5_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i31,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i31);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__mode_util__mode_list_get_final_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_final_insts_3_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i32,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i32);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__modes__modecheck_set_var_inst_list_7_0);
	call_localret(ENTRY(mercury__modes__modecheck_set_var_inst_list_7_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i33,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i33);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	detstackvar(9) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__proc_info_never_succeeds_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_never_succeeds_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i34,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i34);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_7_0_i35);
	{
	Declare_entry(mercury__instmap__init_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i38,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i38);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i39,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i39);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i35);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i18);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_info__mode_info_get_errors_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_errors_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i41,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i41);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__mode_info__mode_info_set_errors_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_errors_3_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i42,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i42);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i43,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i43);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i44,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i44);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__mode_info__mode_info_get_errors_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_errors_2_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i45,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i45);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mode_errors__base_type_info_mode_error_info_0[];
	r1 = (Integer) mercury_data_mode_errors__base_type_info_mode_error_info_0;
	}
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modecheck_call__modecheck_call_pred_7_0_i46,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_7_0_i46);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_7_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__mode_info__mode_info_set_errors_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_errors_3_0),
		mercury__modecheck_call__modecheck_call_pred_7_0_i39,
		ENTRY(mercury__modecheck_call__modecheck_call_pred_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modecheck_call_module1)
	init_entry(mercury__modecheck_call__modecheck_higher_order_call_10_0);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i2);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i3);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i4);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i5);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i6);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i7);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i12);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i13);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i14);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i15);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i16);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i17);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i18);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i21);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i22);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i23);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i20);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i9);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i25);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i26);
	init_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i27);
BEGIN_CODE

/* code for predicate 'modecheck_higher_order_call'/10 in mode 0 */
Define_entry(mercury__modecheck_call__modecheck_higher_order_call_10_0);
	incr_sp_push_msg(13, "modecheck_higher_order_call");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	r1 = (Integer) r4;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_types_of_vars_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i2,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i2);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i3,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i3);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i4,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i4);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i5,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i5);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(7) = (Integer) r1;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__inst_match__inst_expand_3_0);
	call_localret(ENTRY(mercury__inst_match__inst_expand_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i6,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i6);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(10) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i7,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i7);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	if ((tag((Integer) detstackvar(10)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
	if (((Integer) field(mktag(3), (Integer) detstackvar(10), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(10), ((Integer) 2));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
	if (((Integer) detstackvar(1) != (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 0))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(11) = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i12,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i12);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	if (((Integer) detstackvar(11) != (Integer) r1))
		GOTO_LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0_i9);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__mode_util__get_arg_lives_3_0);
	call_localret(ENTRY(mercury__mode_util__get_arg_lives_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i13,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i13);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__modes__modecheck_var_list_is_live_5_0);
	call_localret(ENTRY(mercury__modes__modecheck_var_list_is_live_5_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i14,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i14);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i15,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i15);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r4 = (Integer) detstackvar(8);
	r2 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	{
	Declare_entry(mercury__modes__modecheck_var_has_inst_list_5_0);
	call_localret(ENTRY(mercury__modes__modecheck_var_has_inst_list_5_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i16,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i16);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mode_util__mode_list_get_final_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_final_insts_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i17,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i17);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__modes__modecheck_set_var_inst_list_7_0);
	call_localret(ENTRY(mercury__modes__modecheck_set_var_inst_list_7_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i18,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i18);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	detstackvar(12) = (Integer) r3;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i21,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i21);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	if ((((Integer) 0) != (Integer) r2))
		GOTO_LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0_i20);
	{
	Declare_entry(mercury__instmap__init_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i22,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i22);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i23,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i23);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i20);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	r6 = (Integer) detstackvar(12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i9);
	r1 = (Integer) detstackvar(11);
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i8);
	detstackvar(11) = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i25,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i25);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__singleton_set_2_1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i26,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i26);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	tag_incr_hp(r2, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(10);
	field(mktag(2), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mode_info__mode_info_error_4_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_error_4_0),
		mercury__modecheck_call__modecheck_higher_order_call_10_0_i27,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_call_10_0_i27);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_call_10_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = ((Integer) 6);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), (Integer) mercury_data_modecheck_call__common_1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modecheck_call_module2)
	init_entry(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i2);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i3);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i4);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i5);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i6);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i7);
	init_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i8);
BEGIN_CODE

/* code for predicate 'modecheck_higher_order_pred_call'/6 in mode 0 */
Define_entry(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0);
	incr_sp_push_msg(5, "modecheck_higher_order_pred_call");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = ((Integer) 0);
	r2 = string_const("higher-order predicate call", 27);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__mode_debug__mode_checkpoint_4_0);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i2,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i2);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(2), (Integer) mercury_data_modecheck_call__common_2);
	{
	Declare_entry(mercury__mode_info__mode_info_set_call_context_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_context_3_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i3,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i3);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i4,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i4);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 0);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__modecheck_call__modecheck_higher_order_call_10_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i5,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i5);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 5));
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) r2;
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) r1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	r2 = (Integer) r5;
	r1 = (Integer) tempr1;
	r5 = (Integer) r4;
	r7 = (Integer) r6;
	detstackvar(1) = (Integer) r6;
	field(mktag(2), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__modes__handle_extra_goals_8_0);
	call_localret(ENTRY(mercury__modes__handle_extra_goals_8_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i6,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i6);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_unset_call_context_2_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i7,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i7);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = string_const("higher-order predicate call", 27);
	{
	Declare_entry(mercury__mode_debug__mode_checkpoint_4_0);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i8,
		ENTRY(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	}
Define_label(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0_i8);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_higher_order_pred_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modecheck_call_module3)
	init_entry(mercury__modecheck_call__modecheck_call_pred_2_10_0);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i4);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i5);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i6);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i7);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i8);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i9);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i10);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i11);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i15);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i16);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i12);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i18);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i19);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i20);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i24);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i25);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i21);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i3);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i28);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i29);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i30);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i33);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i35);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i36);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i32);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i38);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i39);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i40);
	init_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i41);
BEGIN_CODE

/* code for predicate 'modecheck_call_pred_2'/10 in mode 0 */
Define_static(mercury__modecheck_call__modecheck_call_pred_2_10_0);
	incr_sp_push_msg(12, "modecheck_call_pred_2");
	detstackvar(12) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i4,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i4);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i5,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i5);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i6,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i6);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r2 = (Integer) r1;
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_arglives_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arglives_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i7,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i7);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i8,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i8);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(11);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__modes__modecheck_var_list_is_live_5_0);
	call_localret(ENTRY(mercury__modes__modecheck_var_list_is_live_5_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i9,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i9);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__modes__modecheck_var_has_inst_list_5_0);
	call_localret(ENTRY(mercury__modes__modecheck_var_has_inst_list_5_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i10,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i10);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(11) = (Integer) r1;
	{
	Declare_entry(mercury__mode_info__mode_info_get_errors_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_errors_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i11,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i11);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0_i12);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i15,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i15);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__mode_info__mode_info_set_errors_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_errors_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i16,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i16);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__modecheck_call__modecheck_call_pred_2_10_0,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i12);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__mode_util__mode_list_get_final_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_final_insts_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i18,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i18);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__modes__modecheck_set_var_inst_list_7_0);
	call_localret(ENTRY(mercury__modes__modecheck_set_var_inst_list_7_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i19,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i19);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(1) = (Integer) detstackvar(5);
	detstackvar(2) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_never_succeeds_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_never_succeeds_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i20,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i20);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0_i21);
	{
	Declare_entry(mercury__instmap__init_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i24,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i24);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i25,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i25);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i21);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(2) = (Integer) r4;
	detstackvar(5) = (Integer) mkword(mktag(0), (Integer) mercury_data_modecheck_call__common_1);
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r6;
	{
	Declare_entry(mercury__mode_info__mode_info_get_preds_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_preds_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i28,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i28);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i29,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i29);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i30,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i30);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_marker_status_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_modecheck_call__common_0);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i33,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i33);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0_i32);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__modecheck_call__insert_new_mode_5_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i35,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i35);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__instmap__init_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i36,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i36);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i25,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i32);
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i38,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i38);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__instmap__lookup_vars_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_vars_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i39,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i39);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i40,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i40);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	tag_incr_hp(r2, mktag(3), ((Integer) 3));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 4);
	{
	Declare_entry(mercury__mode_info__mode_info_error_4_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_error_4_0),
		mercury__modecheck_call__modecheck_call_pred_2_10_0_i41,
		STATIC(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	}
Define_label(mercury__modecheck_call__modecheck_call_pred_2_10_0_i41);
	update_prof_current_proc(LABEL(mercury__modecheck_call__modecheck_call_pred_2_10_0));
	r4 = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modecheck_call_module4)
	init_entry(mercury__modecheck_call__insert_new_mode_5_0);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i2);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i3);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i4);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i5);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i6);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i7);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i8);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i9);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i10);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i11);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i12);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i13);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i14);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i15);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i16);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i17);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i18);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i19);
	init_label(mercury__modecheck_call__insert_new_mode_5_0_i20);
BEGIN_CODE

/* code for predicate 'insert_new_mode'/5 in mode 0 */
Define_static(mercury__modecheck_call__insert_new_mode_5_0);
	incr_sp_push_msg(10, "insert_new_mode");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0),
		mercury__modecheck_call__insert_new_mode_5_0_i2,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i2);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__modecheck_call__insert_new_mode_5_0_i3,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i3);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__modecheck_call__insert_new_mode_5_0_i4,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i4);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r3 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modecheck_call__insert_new_mode_5_0_i5,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i5);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__modecheck_call__insert_new_mode_5_0_i6,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i6);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__modecheck_call__insert_new_mode_5_0_i7,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i7);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	detstackvar(9) = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_inst_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	}
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	{
	Declare_entry(mercury__list__duplicate_3_0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__modecheck_call__insert_new_mode_5_0_i8,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i8);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__mode_util__inst_lists_to_mode_list_3_0);
	call_localret(ENTRY(mercury__mode_util__inst_lists_to_mode_list_3_0),
		mercury__modecheck_call__insert_new_mode_5_0_i9,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i9);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__make_hlds__add_new_proc_8_0);
	call_localret(ENTRY(mercury__make_hlds__add_new_proc_8_0),
		mercury__modecheck_call__insert_new_mode_5_0_i10,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i10);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__modecheck_call__insert_new_mode_5_0_i11,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i11);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r3 = (Integer) r1;
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modecheck_call__insert_new_mode_5_0_i12,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i12);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__modecheck_call__insert_new_mode_5_0_i13,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i13);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__clause_to_proc__copy_clauses_to_proc_4_0);
	call_localret(ENTRY(mercury__clause_to_proc__copy_clauses_to_proc_4_0),
		mercury__modecheck_call__insert_new_mode_5_0_i14,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i14);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__modecheck_call__insert_new_mode_5_0_i15,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i15);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__modecheck_call__insert_new_mode_5_0_i16,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i16);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__modecheck_call__insert_new_mode_5_0_i17,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i17);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__modecheck_call__insert_new_mode_5_0_i18,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i18);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__mode_info__mode_info_set_module_info_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_module_info_3_0),
		mercury__modecheck_call__insert_new_mode_5_0_i19,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i19);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 0);
	{
	Declare_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_changed_flag_3_0),
		mercury__modecheck_call__insert_new_mode_5_0_i20,
		STATIC(mercury__modecheck_call__insert_new_mode_5_0));
	}
Define_label(mercury__modecheck_call__insert_new_mode_5_0_i20);
	update_prof_current_proc(LABEL(mercury__modecheck_call__insert_new_mode_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modecheck_call_module5)
	init_entry(mercury__modecheck_call__get_var_insts_and_lives_4_0);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i4);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i5);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i6);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i7);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i8);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i9);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i14);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i16);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i13);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i19);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i20);
	init_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i1006);
BEGIN_CODE

/* code for predicate 'get_var_insts_and_lives'/4 in mode 0 */
Define_static(mercury__modecheck_call__get_var_insts_and_lives_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i1006);
	incr_sp_push_msg(5, "get_var_insts_and_lives");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i4,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i4);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i5,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i5);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i6,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i6);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__mode_util__normalise_inst_3_0);
	call_localret(ENTRY(mercury__mode_util__normalise_inst_3_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i7,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i7);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__mode_info__mode_info_var_is_live_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_var_is_live_3_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i8,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i8);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i9);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	GOTO_LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i19);
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i9);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__mode_util__inst_is_ground_2_0);
	call_localret(ENTRY(mercury__mode_util__inst_is_ground_2_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i14,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i14);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i13);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__mode_util__inst_is_unique_2_0);
	call_localret(ENTRY(mercury__mode_util__inst_is_unique_2_0),
		mercury__modecheck_call__get_var_insts_and_lives_4_0_i16,
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	}
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i16);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i13);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	GOTO_LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i19);
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i13);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i19);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	localcall(mercury__modecheck_call__get_var_insts_and_lives_4_0,
		LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0_i20),
		STATIC(mercury__modecheck_call__get_var_insts_and_lives_4_0));
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i20);
	update_prof_current_proc(LABEL(mercury__modecheck_call__get_var_insts_and_lives_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__modecheck_call__get_var_insts_and_lives_4_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__modecheck_call_bunch_0(void)
{
	mercury__modecheck_call_module0();
	mercury__modecheck_call_module1();
	mercury__modecheck_call_module2();
	mercury__modecheck_call_module3();
	mercury__modecheck_call_module4();
	mercury__modecheck_call_module5();
}

#endif

void mercury__modecheck_call__init(void); /* suppress gcc warning */
void mercury__modecheck_call__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__modecheck_call_bunch_0();
#endif
}
