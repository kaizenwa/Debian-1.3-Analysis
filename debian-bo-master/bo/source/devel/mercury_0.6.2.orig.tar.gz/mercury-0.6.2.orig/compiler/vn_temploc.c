/*
** Automatically generated from `vn_temploc.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_temploc__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___vn_temploc_templocs_0__ua10000_2_0);
Define_extern_entry(mercury__vn_temploc__init_templocs_4_0);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i2);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i3);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i4);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i5);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i6);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i7);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i8);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i9);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i10);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i11);
Define_extern_entry(mercury__vn_temploc__next_tempr_3_0);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i1000);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i5);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i10);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i6);
Define_extern_entry(mercury__vn_temploc__next_tempf_3_0);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i1000);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i5);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i10);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i6);
Define_extern_entry(mercury__vn_temploc__no_temploc_3_0);
Declare_label(mercury__vn_temploc__no_temploc_3_0_i2);
Declare_label(mercury__vn_temploc__no_temploc_3_0_i3);
Define_extern_entry(mercury__vn_temploc__reuse_templocs_3_0);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i6);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i5);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i1017);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i15);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i1018);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i8);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i1022);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i19);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i18);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i23);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i16);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i1016);
Define_extern_entry(mercury__vn_temploc__max_tempr_2_0);
Define_extern_entry(mercury__vn_temploc__max_tempf_2_0);
Declare_static(mercury__vn_temploc__find_free_r_regs_5_0);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i1022);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i4);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i7);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i1014);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i11);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i15);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i1020);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i1021);
Declare_static(mercury__vn_temploc__find_free_f_regs_5_0);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i1022);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i4);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i7);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i1014);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i11);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i15);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i1020);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i1021);
Declare_static(mercury__vn_temploc__get_n_r_temps_3_0);
Declare_label(mercury__vn_temploc__get_n_r_temps_3_0_i1000);
Declare_label(mercury__vn_temploc__get_n_r_temps_3_0_i4);
Declare_static(mercury__vn_temploc__get_n_f_temps_3_0);
Declare_label(mercury__vn_temploc__get_n_f_temps_3_0_i1000);
Declare_label(mercury__vn_temploc__get_n_f_temps_3_0_i4);
Define_extern_entry(mercury____Unify___vn_temploc__templocs_0_0);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i2);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i4);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i6);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i1);
Define_extern_entry(mercury____Index___vn_temploc__templocs_0_0);
Define_extern_entry(mercury____Compare___vn_temploc__templocs_0_0);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i4);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i5);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i3);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i10);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i16);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i22);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i28);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i34);

extern Word * mercury_data_vn_temploc__base_type_layout_templocs_0[];
Word * mercury_data_vn_temploc__base_type_info_templocs_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_temploc__templocs_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_temploc__templocs_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_temploc__templocs_0_0),
	(Word *) (Integer) mercury_data_vn_temploc__base_type_layout_templocs_0
};

extern Word * mercury_data_vn_temploc__common_3[];
Word * mercury_data_vn_temploc__base_type_layout_templocs_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_temploc__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_set__base_type_info_set_1[];
extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
Word * mercury_data_vn_temploc__common_0[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_vn_temploc__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_vn_temploc__common_2[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_vn_temploc__common_3[] = {
	(Word *) ((Integer) 7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_temploc__common_2),
	(Word *) string_const("templocs", 8)
};

BEGIN_MODULE(mercury__vn_temploc_module0)
	init_entry(mercury____Index___vn_temploc_templocs_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_temploc_templocs_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___vn_temploc_templocs_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module1)
	init_entry(mercury__vn_temploc__init_templocs_4_0);
	init_label(mercury__vn_temploc__init_templocs_4_0_i2);
	init_label(mercury__vn_temploc__init_templocs_4_0_i3);
	init_label(mercury__vn_temploc__init_templocs_4_0_i4);
	init_label(mercury__vn_temploc__init_templocs_4_0_i5);
	init_label(mercury__vn_temploc__init_templocs_4_0_i6);
	init_label(mercury__vn_temploc__init_templocs_4_0_i7);
	init_label(mercury__vn_temploc__init_templocs_4_0_i8);
	init_label(mercury__vn_temploc__init_templocs_4_0_i9);
	init_label(mercury__vn_temploc__init_templocs_4_0_i10);
	init_label(mercury__vn_temploc__init_templocs_4_0_i11);
BEGIN_CODE

/* code for predicate 'vn_temploc__init_templocs'/4 in mode 0 */
Define_entry(mercury__vn_temploc__init_templocs_4_0);
	incr_sp_push_msg(8, "vn_temploc__init_templocs");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__vn_type__real_r_regs_2_0);
	call_localret(ENTRY(mercury__vn_type__real_r_regs_2_0),
		mercury__vn_temploc__init_templocs_4_0_i2,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
	}
Define_label(mercury__vn_temploc__init_templocs_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_type__real_f_regs_2_0);
	call_localret(ENTRY(mercury__vn_type__real_f_regs_2_0),
		mercury__vn_temploc__init_templocs_4_0_i3,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
	}
Define_label(mercury__vn_temploc__init_templocs_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_type__real_r_temps_2_0);
	call_localret(ENTRY(mercury__vn_type__real_r_temps_2_0),
		mercury__vn_temploc__init_templocs_4_0_i4,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
	}
Define_label(mercury__vn_temploc__init_templocs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_type__real_f_temps_2_0);
	call_localret(ENTRY(mercury__vn_type__real_f_temps_2_0),
		mercury__vn_temploc__init_templocs_4_0_i5,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
	}
Define_label(mercury__vn_temploc__init_templocs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_temploc__get_n_r_temps_3_0),
		mercury__vn_temploc__init_templocs_4_0_i6,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	detstackvar(7) = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__vn_temploc__get_n_f_temps_3_0),
		mercury__vn_temploc__init_templocs_4_0_i7,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_temploc__find_free_r_regs_5_0),
		mercury__vn_temploc__init_templocs_4_0_i8,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 1);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_temploc__find_free_f_regs_5_0),
		mercury__vn_temploc__init_templocs_4_0_i9,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__init_templocs_4_0_i10,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
	}
Define_label(mercury__vn_temploc__init_templocs_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__init_templocs_4_0_i11,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
	}
Define_label(mercury__vn_temploc__init_templocs_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = ((Integer) detstackvar(1) + ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = ((Integer) detstackvar(6) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module2)
	init_entry(mercury__vn_temploc__next_tempr_3_0);
	init_label(mercury__vn_temploc__next_tempr_3_0_i1000);
	init_label(mercury__vn_temploc__next_tempr_3_0_i5);
	init_label(mercury__vn_temploc__next_tempr_3_0_i10);
	init_label(mercury__vn_temploc__next_tempr_3_0_i6);
BEGIN_CODE

/* code for predicate 'vn_temploc__next_tempr'/3 in mode 0 */
Define_entry(mercury__vn_temploc__next_tempr_3_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r7 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if (((Integer) r7 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i1000);
	r3 = (Integer) r8;
	r8 = (Integer) r4;
	r4 = (Integer) r6;
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r5;
	r5 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	r2 = (Integer) field(mktag(1), (Integer) r7, ((Integer) 0));
	r7 = (Integer) field(mktag(1), (Integer) r7, ((Integer) 1));
	incr_sp_push_msg(8, "vn_temploc__next_tempr");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i5);
	}
Define_label(mercury__vn_temploc__next_tempr_3_0_i1000);
	incr_sp_push_msg(8, "vn_temploc__next_tempr");
	detstackvar(8) = (Integer) succip;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	tempr2 = (Integer) r4;
	r4 = (Integer) r6;
	r6 = (Integer) r1;
	r1 = (Integer) r5;
	r5 = (Integer) r3;
	r3 = (Integer) r8;
	r8 = ((Integer) tempr2 + ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__vn_temploc__next_tempr_3_0_i5);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i6);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i6);
	r9 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	if ((tag((Integer) r9) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	r2 = (Integer) field(mktag(0), (Integer) r9, ((Integer) 0));
	{
	Declare_entry(mercury__int__max_3_0);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__vn_temploc__next_tempr_3_0_i10,
		ENTRY(mercury__vn_temploc__next_tempr_3_0));
	}
Define_label(mercury__vn_temploc__next_tempr_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_temploc__next_tempr_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_temploc__next_tempr_3_0_i6);
	r9 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r7;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r9;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r8;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r5;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r6;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module3)
	init_entry(mercury__vn_temploc__next_tempf_3_0);
	init_label(mercury__vn_temploc__next_tempf_3_0_i1000);
	init_label(mercury__vn_temploc__next_tempf_3_0_i5);
	init_label(mercury__vn_temploc__next_tempf_3_0_i10);
	init_label(mercury__vn_temploc__next_tempf_3_0_i6);
BEGIN_CODE

/* code for predicate 'vn_temploc__next_tempf'/3 in mode 0 */
Define_entry(mercury__vn_temploc__next_tempf_3_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r7 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if (((Integer) r6 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i1000);
	r3 = (Integer) r8;
	r4 = (Integer) r7;
	r7 = (Integer) field(mktag(1), (Integer) r6, ((Integer) 1));
	r8 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r6, ((Integer) 0));
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	incr_sp_push_msg(8, "vn_temploc__next_tempf");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i5);
Define_label(mercury__vn_temploc__next_tempf_3_0_i1000);
	incr_sp_push_msg(8, "vn_temploc__next_tempf");
	detstackvar(8) = (Integer) succip;
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1, tempr2, tempr3;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	tempr2 = (Integer) r1;
	r1 = (Integer) r3;
	tempr3 = (Integer) r6;
	r6 = (Integer) r4;
	r4 = (Integer) r7;
	r7 = (Integer) tempr3;
	r3 = (Integer) r8;
	r8 = ((Integer) tempr2 + ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__vn_temploc__next_tempf_3_0_i5);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i6);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i6);
	r9 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	if ((tag((Integer) r9) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	r2 = (Integer) field(mktag(1), (Integer) r9, ((Integer) 0));
	{
	Declare_entry(mercury__int__max_3_0);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__vn_temploc__next_tempf_3_0_i10,
		ENTRY(mercury__vn_temploc__next_tempf_3_0));
	}
Define_label(mercury__vn_temploc__next_tempf_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_temploc__next_tempf_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_temploc__next_tempf_3_0_i6);
	r9 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r7;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r5;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r6;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r9;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module4)
	init_entry(mercury__vn_temploc__no_temploc_3_0);
	init_label(mercury__vn_temploc__no_temploc_3_0_i2);
	init_label(mercury__vn_temploc__no_temploc_3_0_i3);
BEGIN_CODE

/* code for predicate 'vn_temploc__no_temploc'/3 in mode 0 */
Define_entry(mercury__vn_temploc__no_temploc_3_0);
	r3 = (Integer) r1;
	incr_sp_push_msg(8, "vn_temploc__no_temploc");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_temploc__no_temploc_3_0_i2,
		ENTRY(mercury__vn_temploc__no_temploc_3_0));
	}
Define_label(mercury__vn_temploc__no_temploc_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_temploc__no_temploc_3_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_temploc__no_temploc_3_0_i3,
		ENTRY(mercury__vn_temploc__no_temploc_3_0));
	}
Define_label(mercury__vn_temploc__no_temploc_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__no_temploc_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module5)
	init_entry(mercury__vn_temploc__reuse_templocs_3_0);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i6);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i5);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i1017);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i15);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i1018);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i8);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i1022);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i19);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i18);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i23);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i16);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i1016);
BEGIN_CODE

/* code for predicate 'vn_temploc__reuse_templocs'/3 in mode 0 */
Define_entry(mercury__vn_temploc__reuse_templocs_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1016);
	incr_sp_push_msg(11, "vn_temploc__reuse_templocs");
	detstackvar(11) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_temploc__reuse_templocs_3_0_i6,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
	}
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_temploc__reuse_templocs_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_temploc__reuse_templocs_3_0,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i5);
	r1 = (Integer) detstackvar(2);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1017);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1018);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) r1;
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) tempr1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__reuse_templocs_3_0_i15,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
	}
	}
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i1017);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r1 != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i8);
	if ((tag((Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 1))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i8);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) tempr1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__reuse_templocs_3_0_i15,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
	}
	}
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_temploc__reuse_templocs_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_temploc__reuse_templocs_3_0,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i1018);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i19);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i18);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i8);
	r1 = (Integer) detstackvar(2);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1022);
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) r1;
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i18);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i1022);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r1 != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	if ((tag((Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i18);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i19);
	r1 = (Integer) detstackvar(2);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	if ((tag((Integer) field(mktag(3), (Integer) r1, ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) r1;
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i18);
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r11 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__reuse_templocs_3_0_i23,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
	}
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_temploc__reuse_templocs_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(0), ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_temploc__reuse_templocs_3_0,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_temploc__reuse_templocs_3_0,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i1016);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module6)
	init_entry(mercury__vn_temploc__max_tempr_2_0);
BEGIN_CODE

/* code for predicate 'vn_temploc__max_tempr'/2 in mode 0 */
Define_entry(mercury__vn_temploc__max_tempr_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module7)
	init_entry(mercury__vn_temploc__max_tempf_2_0);
BEGIN_CODE

/* code for predicate 'vn_temploc__max_tempf'/2 in mode 0 */
Define_entry(mercury__vn_temploc__max_tempf_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module8)
	init_entry(mercury__vn_temploc__find_free_r_regs_5_0);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i1022);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i4);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i7);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i1014);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i11);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i15);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i1020);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i1021);
BEGIN_CODE

/* code for predicate 'vn_temploc__find_free_r_regs'/5 in mode 0 */
Define_static(mercury__vn_temploc__find_free_r_regs_5_0);
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1022);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i1022);
	incr_sp_push_msg(5, "vn_temploc__find_free_r_regs");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r1 = ((Integer) r1 + ((Integer) 1));
	localcall(mercury__vn_temploc__find_free_r_regs_5_0,
		LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i4),
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_temploc__find_free_r_regs_5_0_i7,
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
	}
	}
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1014);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i1014);
	tag_incr_hp(detstackvar(4), mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__search_assigned_vn_3_0);
	call_localret(ENTRY(mercury__vn_table__search_assigned_vn_3_0),
		mercury__vn_temploc__find_free_r_regs_5_0_i11,
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
	}
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1021);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__search_uses_3_0);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_temploc__find_free_r_regs_5_0_i15,
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
	}
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1020);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1020);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i1020);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i1021);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module9)
	init_entry(mercury__vn_temploc__find_free_f_regs_5_0);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i1022);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i4);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i7);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i1014);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i11);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i15);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i1020);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i1021);
BEGIN_CODE

/* code for predicate 'vn_temploc__find_free_f_regs'/5 in mode 0 */
Define_static(mercury__vn_temploc__find_free_f_regs_5_0);
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1022);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i1022);
	incr_sp_push_msg(5, "vn_temploc__find_free_f_regs");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r1 = ((Integer) r1 + ((Integer) 1));
	localcall(mercury__vn_temploc__find_free_f_regs_5_0,
		LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i4),
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_temploc__find_free_f_regs_5_0_i7,
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
	}
	}
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1014);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i1014);
	tag_incr_hp(detstackvar(4), mktag(1), ((Integer) 1));
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__search_assigned_vn_3_0);
	call_localret(ENTRY(mercury__vn_table__search_assigned_vn_3_0),
		mercury__vn_temploc__find_free_f_regs_5_0_i11,
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
	}
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1021);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__search_uses_3_0);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_temploc__find_free_f_regs_5_0_i15,
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
	}
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1020);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1020);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i1020);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i1021);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module10)
	init_entry(mercury__vn_temploc__get_n_r_temps_3_0);
	init_label(mercury__vn_temploc__get_n_r_temps_3_0_i1000);
	init_label(mercury__vn_temploc__get_n_r_temps_3_0_i4);
BEGIN_CODE

/* code for predicate 'vn_temploc__get_n_r_temps'/3 in mode 0 */
Define_static(mercury__vn_temploc__get_n_r_temps_3_0);
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__get_n_r_temps_3_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_temploc__get_n_r_temps_3_0_i1000);
	incr_sp_push_msg(2, "vn_temploc__get_n_r_temps");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) r1 + ((Integer) 1));
	localcall(mercury__vn_temploc__get_n_r_temps_3_0,
		LABEL(mercury__vn_temploc__get_n_r_temps_3_0_i4),
		STATIC(mercury__vn_temploc__get_n_r_temps_3_0));
Define_label(mercury__vn_temploc__get_n_r_temps_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_temploc__get_n_r_temps_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module11)
	init_entry(mercury__vn_temploc__get_n_f_temps_3_0);
	init_label(mercury__vn_temploc__get_n_f_temps_3_0_i1000);
	init_label(mercury__vn_temploc__get_n_f_temps_3_0_i4);
BEGIN_CODE

/* code for predicate 'vn_temploc__get_n_f_temps'/3 in mode 0 */
Define_static(mercury__vn_temploc__get_n_f_temps_3_0);
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__get_n_f_temps_3_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_temploc__get_n_f_temps_3_0_i1000);
	incr_sp_push_msg(2, "vn_temploc__get_n_f_temps");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) r1 + ((Integer) 1));
	localcall(mercury__vn_temploc__get_n_f_temps_3_0,
		LABEL(mercury__vn_temploc__get_n_f_temps_3_0_i4),
		STATIC(mercury__vn_temploc__get_n_f_temps_3_0));
Define_label(mercury__vn_temploc__get_n_f_temps_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_temploc__get_n_f_temps_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module12)
	init_entry(mercury____Unify___vn_temploc__templocs_0_0);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i2);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i4);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i6);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_temploc__templocs_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(13, "__Unify__");
	detstackvar(13) = (Integer) succip;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___vn_temploc__templocs_0_0_i2,
		ENTRY(mercury____Unify___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___vn_temploc__templocs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___vn_temploc__templocs_0_0_i4,
		ENTRY(mercury____Unify___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___vn_temploc__templocs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___vn_temploc__templocs_0_0_i6,
		ENTRY(mercury____Unify___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___vn_temploc__templocs_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(9)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if (((Integer) detstackvar(4) != (Integer) detstackvar(10)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if (((Integer) detstackvar(5) != (Integer) detstackvar(11)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if (((Integer) detstackvar(6) != (Integer) detstackvar(12)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module13)
	init_entry(mercury____Index___vn_temploc__templocs_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_temploc__templocs_0_0);
	tailcall(STATIC(mercury____Index___vn_temploc_templocs_0__ua10000_2_0),
		ENTRY(mercury____Index___vn_temploc__templocs_0_0));
END_MODULE

BEGIN_MODULE(mercury__vn_temploc_module14)
	init_entry(mercury____Compare___vn_temploc__templocs_0_0);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i4);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i5);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i3);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i10);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i16);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i22);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i28);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i34);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_temploc__templocs_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(13, "__Compare__");
	detstackvar(13) = (Integer) succip;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___vn_temploc__templocs_0_0_i4,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i3);
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___vn_temploc__templocs_0_0_i10,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i5);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___vn_temploc__templocs_0_0_i16,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_temploc__templocs_0_0_i22,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_temploc__templocs_0_0_i28,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_temploc__templocs_0_0_i34,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_temploc_bunch_0(void)
{
	mercury__vn_temploc_module0();
	mercury__vn_temploc_module1();
	mercury__vn_temploc_module2();
	mercury__vn_temploc_module3();
	mercury__vn_temploc_module4();
	mercury__vn_temploc_module5();
	mercury__vn_temploc_module6();
	mercury__vn_temploc_module7();
	mercury__vn_temploc_module8();
	mercury__vn_temploc_module9();
	mercury__vn_temploc_module10();
	mercury__vn_temploc_module11();
	mercury__vn_temploc_module12();
	mercury__vn_temploc_module13();
	mercury__vn_temploc_module14();
}

#endif

void mercury__vn_temploc__init(void); /* suppress gcc warning */
void mercury__vn_temploc__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_temploc_bunch_0();
#endif
}
