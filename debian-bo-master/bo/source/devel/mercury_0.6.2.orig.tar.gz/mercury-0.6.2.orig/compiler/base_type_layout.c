/*
** Automatically generated from `base_type_layout.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__base_type_layout__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___base_type_layout_layout_info_0__ua10000_2_0);
Declare_static(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i4);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i9);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i10);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i11);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i1009);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i13);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i3);
Declare_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i2);
Declare_static(mercury__base_type_layout__LambdaGoal__4_2_0);
Declare_static(mercury__base_type_layout__LambdaGoal__3_3_0);
Declare_label(mercury__base_type_layout__LambdaGoal__3_3_0_i2);
Declare_label(mercury__base_type_layout__LambdaGoal__3_3_0_i3);
Declare_static(mercury__base_type_layout__LambdaGoal__2_2_0);
Declare_label(mercury__base_type_layout__LambdaGoal__2_2_0_i5);
Declare_label(mercury__base_type_layout__LambdaGoal__2_2_0_i1005);
Declare_static(mercury__base_type_layout__LambdaGoal__1_2_0);
Declare_label(mercury__base_type_layout__LambdaGoal__1_2_0_i5);
Declare_label(mercury__base_type_layout__LambdaGoal__1_2_0_i1005);
Define_extern_entry(mercury__base_type_layout__generate_hlds_2_0);
Declare_label(mercury__base_type_layout__generate_hlds_2_0_i2);
Declare_label(mercury__base_type_layout__generate_hlds_2_0_i3);
Declare_label(mercury__base_type_layout__generate_hlds_2_0_i4);
Declare_label(mercury__base_type_layout__generate_hlds_2_0_i5);
Define_extern_entry(mercury__base_type_layout__generate_llds_2_0);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i2);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i3);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i4);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i5);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i6);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i7);
Declare_label(mercury__base_type_layout__generate_llds_2_0_i8);
Declare_static(mercury__base_type_layout__construct_base_type_layouts_3_0);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i4);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i7);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i9);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i10);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i11);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i12);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i17);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i19);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i16);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i14);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i8);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i23);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i25);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i5);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i26);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i29);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i33);
Declare_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i1001);
Declare_static(mercury__base_type_layout__const_value_2_0);
Declare_static(mercury__base_type_layout__tag_value_2_0);
Declare_static(mercury__base_type_layout__encode_mkword_4_0);
Declare_label(mercury__base_type_layout__encode_mkword_4_0_i1013);
Declare_static(mercury__base_type_layout__encode_create_6_0);
Declare_label(mercury__base_type_layout__encode_create_6_0_i1015);
Declare_static(mercury__base_type_layout__construct_enum_4_0);
Declare_label(mercury__base_type_layout__construct_enum_4_0_i4);
Declare_label(mercury__base_type_layout__construct_enum_4_0_i5);
Declare_label(mercury__base_type_layout__construct_enum_4_0_i6);
Declare_label(mercury__base_type_layout__construct_enum_4_0_i7);
Declare_label(mercury__base_type_layout__construct_enum_4_0_i8);
Declare_label(mercury__base_type_layout__construct_enum_4_0_i9);
Declare_static(mercury__base_type_layout__construct_no_tag_type_5_0);
Declare_label(mercury__base_type_layout__construct_no_tag_type_5_0_i4);
Declare_label(mercury__base_type_layout__construct_no_tag_type_5_0_i5);
Declare_label(mercury__base_type_layout__construct_no_tag_type_5_0_i6);
Declare_label(mercury__base_type_layout__construct_no_tag_type_5_0_i7);
Declare_label(mercury__base_type_layout__construct_no_tag_type_5_0_i8);
Declare_label(mercury__base_type_layout__construct_no_tag_type_5_0_i9);
Declare_static(mercury__base_type_layout__construct_eqv_type_4_0);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i2);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i7);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i3);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i9);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i8);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i10);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i11);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i12);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i13);
Declare_label(mercury__base_type_layout__construct_eqv_type_4_0_i14);
Declare_static(mercury__base_type_layout__construct_du_type_4_0);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1008);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1007);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1006);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1005);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1004);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i9);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i10);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i11);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i12);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i13);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i14);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i16);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1001);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i19);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i20);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i18);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i22);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i6);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i24);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i25);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i4);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i26);
Declare_label(mercury__base_type_layout__construct_du_type_4_0_i1000);
Declare_static(mercury__base_type_layout__generate_rvals_5_0);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i1005);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i1004);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i1003);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i1002);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i1001);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i5);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i6);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i7);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i8);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i9);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i11);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i14);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i16);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i15);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i17);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i18);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i19);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i20);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i13);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i21);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i12);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i23);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i25);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i26);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i27);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i28);
Declare_label(mercury__base_type_layout__generate_rvals_5_0_i1000);
Declare_static(mercury__base_type_layout__handle_simple_4_0);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i7);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i4);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i8);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i9);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i10);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i13);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i15);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i12);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i17);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i18);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i19);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i20);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i21);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i22);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i23);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i24);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i1000);
Declare_label(mercury__base_type_layout__handle_simple_4_0_i25);
Declare_static(mercury__base_type_layout__handle_complicated_4_0);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i4);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i5);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i6);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i7);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i8);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i3);
Declare_label(mercury__base_type_layout__handle_complicated_4_0_i9);
Declare_static(mercury__base_type_layout__generate_pseudo_type_infos_4_0);
Declare_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i4);
Declare_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i5);
Declare_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i1002);
Declare_static(mercury__base_type_layout__generate_pseudo_type_info_4_0);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i4);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i8);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i7);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i10);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i11);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i12);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i13);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i14);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i15);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i16);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i3);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i19);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i21);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i22);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i18);
Declare_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i23);
Declare_static(mercury__base_type_layout__remove_creates_2_0);
Declare_label(mercury__base_type_layout__remove_creates_2_0_i10);
Declare_label(mercury__base_type_layout__remove_creates_2_0_i2);
Declare_label(mercury__base_type_layout__remove_creates_2_0_i8);
Declare_label(mercury__base_type_layout__remove_creates_2_0_i11);
Declare_label(mercury__base_type_layout__remove_creates_2_0_i1);
Declare_static(mercury__base_type_layout__gather_tags_3_0);
Declare_label(mercury__base_type_layout__gather_tags_3_0_i1000);
Declare_label(mercury__base_type_layout__gather_tags_3_0_i4);
Declare_label(mercury__base_type_layout__gather_tags_3_0_i5);
Declare_label(mercury__base_type_layout__gather_tags_3_0_i6);
Declare_static(mercury__base_type_layout__get_tags_4_0);
Declare_label(mercury__base_type_layout__get_tags_4_0_i18);
Declare_label(mercury__base_type_layout__get_tags_4_0_i19);
Declare_label(mercury__base_type_layout__get_tags_4_0_i6);
Declare_label(mercury__base_type_layout__get_tags_4_0_i10);
Declare_label(mercury__base_type_layout__get_tags_4_0_i11);
Declare_label(mercury__base_type_layout__get_tags_4_0_i12);
Declare_label(mercury__base_type_layout__get_tags_4_0_i5);
Declare_label(mercury__base_type_layout__get_tags_4_0_i13);
Declare_label(mercury__base_type_layout__get_tags_4_0_i14);
Declare_label(mercury__base_type_layout__get_tags_4_0_i3);
Declare_label(mercury__base_type_layout__get_tags_4_0_i15);
Declare_label(mercury__base_type_layout__get_tags_4_0_i17);
Declare_label(mercury__base_type_layout__get_tags_4_0_i1);
Declare_static(mercury__base_type_layout__incr_next_label_2_0);
Declare_static(mercury____Unify___base_type_layout__layout_info_0_0);
Declare_label(mercury____Unify___base_type_layout__layout_info_0_0_i2);
Declare_label(mercury____Unify___base_type_layout__layout_info_0_0_i4);
Declare_label(mercury____Unify___base_type_layout__layout_info_0_0_i1006);
Declare_label(mercury____Unify___base_type_layout__layout_info_0_0_i1);
Declare_static(mercury____Index___base_type_layout__layout_info_0_0);
Declare_static(mercury____Compare___base_type_layout__layout_info_0_0);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i4);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i5);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i3);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i10);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i16);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i22);
Declare_label(mercury____Compare___base_type_layout__layout_info_0_0_i28);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_base_type_layout__base_type_layout_const_sort_0[];
Word * mercury_data_base_type_layout__base_type_info_const_sort_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_base_type_layout__base_type_layout_const_sort_0
};

extern Word * mercury_data_base_type_layout__base_type_layout_layout_info_0[];
Word * mercury_data_base_type_layout__base_type_info_layout_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___base_type_layout__layout_info_0_0),
	(Word *) (Integer) STATIC(mercury____Index___base_type_layout__layout_info_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___base_type_layout__layout_info_0_0),
	(Word *) (Integer) mercury_data_base_type_layout__base_type_layout_layout_info_0
};

extern Word * mercury_data_base_type_layout__base_type_layout_tag_category_0[];
Word * mercury_data_base_type_layout__base_type_info_tag_category_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_base_type_layout__base_type_layout_tag_category_0
};

extern Word * mercury_data_base_type_layout__common_19[];
Word * mercury_data_base_type_layout__base_type_layout_tag_category_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_19)
};

extern Word * mercury_data_base_type_layout__common_24[];
Word * mercury_data_base_type_layout__base_type_layout_layout_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_24),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_base_type_layout__common_25[];
Word * mercury_data_base_type_layout__base_type_layout_const_sort_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_25),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_25),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_25),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_25)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_base_type_layout__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_base_type_layout__common_1[] = {
	(Word *) string_const("found in base_type_layout", 25),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data_llds__base_type_info_rval_0[];
Word * mercury_data_base_type_layout__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_rval_0
};

Word * mercury_data_base_type_layout__common_3[] = {
	(Word *) string_const("", 0)
};

Word * mercury_data_base_type_layout__common_4[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_3),
	(Word *) ((Integer) 0)
};

extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
Word * mercury_data_base_type_layout__common_5[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0
};

Word * mercury_data_base_type_layout__common_6[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0
};

Word * mercury_data_base_type_layout__common_7[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury__base_type_layout__LambdaGoal__1_2_0)
};

Word mercury_data_base_type_layout__common_8[] = {
	((Integer) 1)
};

Word * mercury_data_base_type_layout__common_9[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_8)
};

Word * mercury_data_base_type_layout__common_10[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_base_type_layout__common_9)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_base_type_layout__common_11[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2)
};

Word mercury_data_base_type_layout__common_12[] = {
	((Integer) 0)
};

Word * mercury_data_base_type_layout__common_13[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_12)
};

Word * mercury_data_base_type_layout__common_14[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_base_type_layout__common_13)
};

Word * mercury_data_base_type_layout__common_15[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury__base_type_layout__LambdaGoal__2_2_0)
};

extern Word * mercury_data_hlds_data__base_type_info_hlds__cons_defn_0[];
Word * mercury_data_base_type_layout__common_16[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_hlds__cons_defn_0
};

Word * mercury_data_base_type_layout__common_17[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11),
	(Word *) (Integer) mercury_data_base_type_layout__base_type_info_layout_info_0
};

Word * mercury_data_base_type_layout__common_18[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury__base_type_layout__LambdaGoal__3_3_0)
};

Word * mercury_data_base_type_layout__common_19[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 5),
	(Word *) string_const("simple", 6),
	(Word *) string_const("complicated", 11),
	(Word *) string_const("comp_const", 10),
	(Word *) string_const("no_tag", 6),
	(Word *) string_const("unused", 6)
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_base_type_layout__common_20[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_base_type_layout__common_21[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_16)
};

Word * mercury_data_base_type_layout__common_22[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_llds__base_type_info_c_module_0[];
Word * mercury_data_base_type_layout__common_23[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_c_module_0
};

Word * mercury_data_base_type_layout__common_24[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_20),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_21),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_23),
	(Word *) string_const("layout_info", 11)
};

Word * mercury_data_base_type_layout__common_25[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 8),
	(Word *) string_const("unassigned", 10),
	(Word *) string_const("unused", 6),
	(Word *) string_const("string", 6),
	(Word *) string_const("float", 5),
	(Word *) string_const("int", 3),
	(Word *) string_const("character", 9),
	(Word *) string_const("univ", 4),
	(Word *) string_const("predicate", 9)
};

BEGIN_MODULE(mercury__base_type_layout_module0)
	init_entry(mercury____Index___base_type_layout_layout_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___base_type_layout_layout_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___base_type_layout_layout_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module1)
	init_entry(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i4);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i9);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i10);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i11);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i1009);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i13);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i3);
	init_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i2);
BEGIN_CODE

/* code for predicate 'base_type_layout__gen_base_gen_layouts__ua10000'/5 in mode 0 */
Define_static(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0);
	incr_sp_push_msg(7, "base_type_layout__gen_base_gen_layouts__ua10000");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0,
		LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i4),
		STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(3), ((Integer) 0));
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i1009);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), (char *)(Integer) detstackvar(2)) !=0))
		GOTO_LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i2);
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) detstackvar(3), ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i9,
		STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	}
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	{
	Declare_entry(mercury__hlds_data__get_type_defn_status_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_status_2_0),
		mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i10,
		STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	}
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i11,
		STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	}
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i11);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 5)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i1009);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unqualified type ", 17);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i13,
		STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	}
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i13);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0));
	}
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i3);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module2)
	init_entry(mercury__base_type_layout__LambdaGoal__4_2_0);
BEGIN_CODE

/* code for predicate 'base_type_layout__LambdaGoal__4'/2 in mode 0 */
Define_static(mercury__base_type_layout__LambdaGoal__4_2_0);
	r3 = (Integer) r1;
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury__base_type_layout__LambdaGoal__4_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module3)
	init_entry(mercury__base_type_layout__LambdaGoal__3_3_0);
	init_label(mercury__base_type_layout__LambdaGoal__3_3_0_i2);
	init_label(mercury__base_type_layout__LambdaGoal__3_3_0_i3);
BEGIN_CODE

/* code for predicate 'base_type_layout__LambdaGoal__3'/3 in mode 0 */
Define_static(mercury__base_type_layout__LambdaGoal__3_3_0);
	incr_sp_push_msg(2, "base_type_layout__LambdaGoal__3");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	call_localret(STATIC(mercury__base_type_layout__handle_simple_4_0),
		mercury__base_type_layout__LambdaGoal__3_3_0_i2,
		STATIC(mercury__base_type_layout__LambdaGoal__3_3_0));
Define_label(mercury__base_type_layout__LambdaGoal__3_3_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_layout__LambdaGoal__3_3_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__LambdaGoal__3_3_0_i3,
		STATIC(mercury__base_type_layout__LambdaGoal__3_3_0));
	}
Define_label(mercury__base_type_layout__LambdaGoal__3_3_0_i3);
	update_prof_current_proc(LABEL(mercury__base_type_layout__LambdaGoal__3_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module4)
	init_entry(mercury__base_type_layout__LambdaGoal__2_2_0);
	init_label(mercury__base_type_layout__LambdaGoal__2_2_0_i5);
	init_label(mercury__base_type_layout__LambdaGoal__2_2_0_i1005);
BEGIN_CODE

/* code for predicate 'base_type_layout__LambdaGoal__2'/2 in mode 0 */
Define_static(mercury__base_type_layout__LambdaGoal__2_2_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__base_type_layout__LambdaGoal__2_2_0_i1005);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(1, "base_type_layout__LambdaGoal__2");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__base_type_layout__LambdaGoal__2_2_0_i5,
		STATIC(mercury__base_type_layout__LambdaGoal__2_2_0));
	}
Define_label(mercury__base_type_layout__LambdaGoal__2_2_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__LambdaGoal__2_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
Define_label(mercury__base_type_layout__LambdaGoal__2_2_0_i1005);
	r1 = string_const("base_type_layout: constant has no constructor", 45);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_type_layout__LambdaGoal__2_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module5)
	init_entry(mercury__base_type_layout__LambdaGoal__1_2_0);
	init_label(mercury__base_type_layout__LambdaGoal__1_2_0_i5);
	init_label(mercury__base_type_layout__LambdaGoal__1_2_0_i1005);
BEGIN_CODE

/* code for predicate 'base_type_layout__LambdaGoal__1'/2 in mode 0 */
Define_static(mercury__base_type_layout__LambdaGoal__1_2_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__base_type_layout__LambdaGoal__1_2_0_i1005);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(1, "base_type_layout__LambdaGoal__1");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__base_type_layout__LambdaGoal__1_2_0_i5,
		STATIC(mercury__base_type_layout__LambdaGoal__1_2_0));
	}
Define_label(mercury__base_type_layout__LambdaGoal__1_2_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__LambdaGoal__1_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
Define_label(mercury__base_type_layout__LambdaGoal__1_2_0_i1005);
	r1 = string_const("base_type_layout: constant has no constructor", 45);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_type_layout__LambdaGoal__1_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module6)
	init_entry(mercury__base_type_layout__generate_hlds_2_0);
	init_label(mercury__base_type_layout__generate_hlds_2_0_i2);
	init_label(mercury__base_type_layout__generate_hlds_2_0_i3);
	init_label(mercury__base_type_layout__generate_hlds_2_0_i4);
	init_label(mercury__base_type_layout__generate_hlds_2_0_i5);
BEGIN_CODE

/* code for predicate 'base_type_layout__generate_hlds'/2 in mode 0 */
Define_entry(mercury__base_type_layout__generate_hlds_2_0);
	incr_sp_push_msg(4, "base_type_layout__generate_hlds");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__base_type_layout__generate_hlds_2_0_i2,
		ENTRY(mercury__base_type_layout__generate_hlds_2_0));
	}
Define_label(mercury__base_type_layout__generate_hlds_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_hlds_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__base_type_layout__generate_hlds_2_0_i3,
		ENTRY(mercury__base_type_layout__generate_hlds_2_0));
	}
Define_label(mercury__base_type_layout__generate_hlds_2_0_i3);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_hlds_2_0));
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__base_type_layout__generate_hlds_2_0_i4,
		ENTRY(mercury__base_type_layout__generate_hlds_2_0));
	}
Define_label(mercury__base_type_layout__generate_hlds_2_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_hlds_2_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__base_type_layout__gen_base_gen_layouts__ua10000_5_0),
		mercury__base_type_layout__generate_hlds_2_0_i5,
		ENTRY(mercury__base_type_layout__generate_hlds_2_0));
Define_label(mercury__base_type_layout__generate_hlds_2_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_hlds_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__hlds_module__module_info_set_base_gen_layouts_3_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_base_gen_layouts_3_0),
		ENTRY(mercury__base_type_layout__generate_hlds_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module7)
	init_entry(mercury__base_type_layout__generate_llds_2_0);
	init_label(mercury__base_type_layout__generate_llds_2_0_i2);
	init_label(mercury__base_type_layout__generate_llds_2_0_i3);
	init_label(mercury__base_type_layout__generate_llds_2_0_i4);
	init_label(mercury__base_type_layout__generate_llds_2_0_i5);
	init_label(mercury__base_type_layout__generate_llds_2_0_i6);
	init_label(mercury__base_type_layout__generate_llds_2_0_i7);
	init_label(mercury__base_type_layout__generate_llds_2_0_i8);
BEGIN_CODE

/* code for predicate 'base_type_layout__generate_llds'/2 in mode 0 */
Define_entry(mercury__base_type_layout__generate_llds_2_0);
	incr_sp_push_msg(4, "base_type_layout__generate_llds");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_base_gen_layouts_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_base_gen_layouts_2_0),
		mercury__base_type_layout__generate_llds_2_0_i2,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
	}
Define_label(mercury__base_type_layout__generate_llds_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_globals_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__base_type_layout__generate_llds_2_0_i3,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
	}
Define_label(mercury__base_type_layout__generate_llds_2_0_i3);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	r2 = ((Integer) 57);
	{
	Declare_entry(mercury__globals__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__base_type_layout__generate_llds_2_0_i4,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
	}
Define_label(mercury__base_type_layout__generate_llds_2_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__int__pow_3_0);
	call_localret(ENTRY(mercury__int__pow_3_0),
		mercury__base_type_layout__generate_llds_2_0_i5,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
	}
Define_label(mercury__base_type_layout__generate_llds_2_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__base_type_layout__generate_llds_2_0_i6,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
	}
Define_label(mercury__base_type_layout__generate_llds_2_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_ctors_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_ctors_2_0),
		mercury__base_type_layout__generate_llds_2_0_i7,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
	}
Define_label(mercury__base_type_layout__generate_llds_2_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_4);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = ((Integer) 0);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0),
		mercury__base_type_layout__generate_llds_2_0_i8,
		ENTRY(mercury__base_type_layout__generate_llds_2_0));
Define_label(mercury__base_type_layout__generate_llds_2_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_llds_2_0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module8)
	init_entry(mercury__base_type_layout__construct_base_type_layouts_3_0);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i4);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i7);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i9);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i10);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i11);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i12);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i17);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i19);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i16);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i14);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i8);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i23);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i25);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i5);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i26);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i29);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i33);
	init_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i1001);
BEGIN_CODE

/* code for predicate 'base_type_layout__construct_base_type_layouts'/3 in mode 0 */
Define_static(mercury__base_type_layout__construct_base_type_layouts_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i1001);
	incr_sp_push_msg(9, "base_type_layout__construct_base_type_layouts");
	detstackvar(9) = (Integer) succip;
	tag_incr_hp(r3, mktag(0), ((Integer) 6));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	field(mktag(0), (Integer) r3, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i4,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i7);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i5);
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i7);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i8);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i9,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	{
	Declare_entry(mercury__assoc_list__reverse_members_2_0);
	call_localret(ENTRY(mercury__assoc_list__reverse_members_2_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i10,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_5);
	{
	Declare_entry(mercury__list__sort_2_0);
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i11,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i11);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	{
	Declare_entry(mercury__assoc_list__reverse_members_2_0);
	call_localret(ENTRY(mercury__assoc_list__reverse_members_2_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i12,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i12);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	if (((Integer) detstackvar(8) == ((Integer) 0)))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i14);
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_is_no_tag_type_3_0);
	call_localret(ENTRY(mercury__type_util__type_is_no_tag_type_3_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i17,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i17);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i16);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__base_type_layout__construct_no_tag_type_5_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i19,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i19);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	r7 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i5);
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i16);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__base_type_layout__construct_du_type_4_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i19,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i14);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__base_type_layout__construct_enum_4_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i19,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i8);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i23);
	r1 = string_const("base_type_layout: undiscriminated union unimplemented\n", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i19,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
	}
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i23);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__base_type_layout__construct_eqv_type_4_0),
		mercury__base_type_layout__construct_base_type_layouts_3_0_i25,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i25);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0));
	r7 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i5);
	if (((Integer) r6 != ((Integer) 5)))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i26);
	r6 = (Integer) r7;
	r7 = ((Integer) 0);
	GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i29);
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i26);
	r6 = (Integer) r7;
	r7 = ((Integer) 1);
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i29);
	if (((Integer) r6 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__construct_base_type_layouts_3_0_i33);
	r8 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r8, ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r8, ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r8, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r8, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r8, ((Integer) 4));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(1), ((Integer) 6));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r8, ((Integer) 5));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r10, ((Integer) 5)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r10, ((Integer) 4)) = (Integer) r6;
	field(mktag(1), (Integer) r10, ((Integer) 3)) = (Integer) r7;
	field(mktag(1), (Integer) r10, ((Integer) 2)) = ((Integer) 0);
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) r9;
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i33);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__base_type_layout__construct_base_type_layouts_3_0,
		STATIC(mercury__base_type_layout__construct_base_type_layouts_3_0));
Define_label(mercury__base_type_layout__construct_base_type_layouts_3_0_i1001);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module9)
	init_entry(mercury__base_type_layout__const_value_2_0);
BEGIN_CODE

/* code for predicate 'base_type_layout__const_value'/2 in mode 0 */
Define_static(mercury__base_type_layout__const_value_2_0);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 1),
		((Integer) 2),
		((Integer) 3),
		((Integer) 4),
		((Integer) 5),
		((Integer) 6),
		((Integer) 7)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module10)
	init_entry(mercury__base_type_layout__tag_value_2_0);
BEGIN_CODE

/* code for predicate 'base_type_layout__tag_value'/2 in mode 0 */
Define_static(mercury__base_type_layout__tag_value_2_0);
	{
	static const Word mercury_const_1[] = {
		((Integer) 1),
		((Integer) 2),
		((Integer) 0),
		((Integer) 3),
		((Integer) 0)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module11)
	init_entry(mercury__base_type_layout__encode_mkword_4_0);
	init_label(mercury__base_type_layout__encode_mkword_4_0_i1013);
BEGIN_CODE

/* code for predicate 'base_type_layout__encode_mkword'/4 in mode 0 */
Define_static(mercury__base_type_layout__encode_mkword_4_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 2)) >= ((Integer) 4)))
		GOTO_LABEL(mercury__base_type_layout__encode_mkword_4_0_i1013);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	proceed();
	}
Define_label(mercury__base_type_layout__encode_mkword_4_0_i1013);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 3);
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module12)
	init_entry(mercury__base_type_layout__encode_create_6_0);
	init_label(mercury__base_type_layout__encode_create_6_0_i1015);
BEGIN_CODE

/* code for predicate 'base_type_layout__encode_create'/6 in mode 0 */
Define_static(mercury__base_type_layout__encode_create_6_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 2)) >= ((Integer) 4)))
		GOTO_LABEL(mercury__base_type_layout__encode_create_6_0_i1015);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(2), ((Integer) 4));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r2;
	field(mktag(2), (Integer) r2, ((Integer) 3)) = (Integer) r5;
	field(mktag(2), (Integer) r2, ((Integer) 2)) = (Integer) r4;
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r2, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	proceed();
	}
Define_label(mercury__base_type_layout__encode_create_6_0_i1015);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 4));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) r5;
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r6;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module13)
	init_entry(mercury__base_type_layout__construct_enum_4_0);
	init_label(mercury__base_type_layout__construct_enum_4_0_i4);
	init_label(mercury__base_type_layout__construct_enum_4_0_i5);
	init_label(mercury__base_type_layout__construct_enum_4_0_i6);
	init_label(mercury__base_type_layout__construct_enum_4_0_i7);
	init_label(mercury__base_type_layout__construct_enum_4_0_i8);
	init_label(mercury__base_type_layout__construct_enum_4_0_i9);
BEGIN_CODE

/* code for predicate 'base_type_layout__construct_enum'/4 in mode 0 */
Define_static(mercury__base_type_layout__construct_enum_4_0);
	r4 = (Integer) r1;
	incr_sp_push_msg(5, "base_type_layout__construct_enum");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_7);
	{
	Declare_entry(mercury__list__map_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__base_type_layout__construct_enum_4_0_i4,
		STATIC(mercury__base_type_layout__construct_enum_4_0));
	}
Define_label(mercury__base_type_layout__construct_enum_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_enum_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	detstackvar(3) = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_10);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_type_layout__construct_enum_4_0_i5,
		STATIC(mercury__base_type_layout__construct_enum_4_0));
	}
Define_label(mercury__base_type_layout__construct_enum_4_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_enum_4_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(detstackvar(2), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) r2;
	field(mktag(1), (Integer) detstackvar(2), ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__construct_enum_4_0_i6,
		STATIC(mercury__base_type_layout__construct_enum_4_0));
	}
Define_label(mercury__base_type_layout__construct_enum_4_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_enum_4_0));
	r4 = (Integer) detstackvar(1);
	r2 = ((Integer) 0);
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__base_type_layout__encode_create_6_0),
		mercury__base_type_layout__construct_enum_4_0_i7,
		STATIC(mercury__base_type_layout__construct_enum_4_0));
	}
Define_label(mercury__base_type_layout__construct_enum_4_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_enum_4_0));
	r3 = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11);
	{
	Declare_entry(mercury__list__duplicate_3_0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__base_type_layout__construct_enum_4_0_i8,
		STATIC(mercury__base_type_layout__construct_enum_4_0));
	}
Define_label(mercury__base_type_layout__construct_enum_4_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_enum_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__base_type_layout__construct_enum_4_0_i9,
		STATIC(mercury__base_type_layout__construct_enum_4_0));
	}
Define_label(mercury__base_type_layout__construct_enum_4_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_enum_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module14)
	init_entry(mercury__base_type_layout__construct_no_tag_type_5_0);
	init_label(mercury__base_type_layout__construct_no_tag_type_5_0_i4);
	init_label(mercury__base_type_layout__construct_no_tag_type_5_0_i5);
	init_label(mercury__base_type_layout__construct_no_tag_type_5_0_i6);
	init_label(mercury__base_type_layout__construct_no_tag_type_5_0_i7);
	init_label(mercury__base_type_layout__construct_no_tag_type_5_0_i8);
	init_label(mercury__base_type_layout__construct_no_tag_type_5_0_i9);
BEGIN_CODE

/* code for predicate 'base_type_layout__construct_no_tag_type'/5 in mode 0 */
Define_static(mercury__base_type_layout__construct_no_tag_type_5_0);
	incr_sp_push_msg(5, "base_type_layout__construct_no_tag_type");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_10);
	call_localret(STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0),
		mercury__base_type_layout__construct_no_tag_type_5_0_i4,
		STATIC(mercury__base_type_layout__construct_no_tag_type_5_0));
Define_label(mercury__base_type_layout__construct_no_tag_type_5_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_no_tag_type_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__base_type_layout__construct_no_tag_type_5_0_i5,
		STATIC(mercury__base_type_layout__construct_no_tag_type_5_0));
	}
Define_label(mercury__base_type_layout__construct_no_tag_type_5_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_no_tag_type_5_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__construct_no_tag_type_5_0_i6,
		STATIC(mercury__base_type_layout__construct_no_tag_type_5_0));
	}
Define_label(mercury__base_type_layout__construct_no_tag_type_5_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_no_tag_type_5_0));
	r4 = (Integer) detstackvar(1);
	r2 = ((Integer) 3);
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = ((Integer) 1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	r5 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__base_type_layout__encode_create_6_0),
		mercury__base_type_layout__construct_no_tag_type_5_0_i7,
		STATIC(mercury__base_type_layout__construct_no_tag_type_5_0));
	}
Define_label(mercury__base_type_layout__construct_no_tag_type_5_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_no_tag_type_5_0));
	r3 = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11);
	{
	Declare_entry(mercury__list__duplicate_3_0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__base_type_layout__construct_no_tag_type_5_0_i8,
		STATIC(mercury__base_type_layout__construct_no_tag_type_5_0));
	}
Define_label(mercury__base_type_layout__construct_no_tag_type_5_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_no_tag_type_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__base_type_layout__construct_no_tag_type_5_0_i9,
		STATIC(mercury__base_type_layout__construct_no_tag_type_5_0));
	}
Define_label(mercury__base_type_layout__construct_no_tag_type_5_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_no_tag_type_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module15)
	init_entry(mercury__base_type_layout__construct_eqv_type_4_0);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i2);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i7);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i3);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i9);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i8);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i10);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i11);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i12);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i13);
	init_label(mercury__base_type_layout__construct_eqv_type_4_0_i14);
BEGIN_CODE

/* code for predicate 'base_type_layout__construct_eqv_type'/4 in mode 0 */
Define_static(mercury__base_type_layout__construct_eqv_type_4_0);
	incr_sp_push_msg(4, "base_type_layout__construct_eqv_type");
	detstackvar(4) = (Integer) succip;
	call_localret(STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0),
		mercury__base_type_layout__construct_eqv_type_4_0_i2,
		STATIC(mercury__base_type_layout__construct_eqv_type_4_0));
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_eqv_type_4_0));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__construct_eqv_type_4_0_i3);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__base_type_layout__construct_eqv_type_4_0_i3);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__base_type_layout__construct_eqv_type_4_0_i3);
	detstackvar(1) = (Integer) r1;
	r2 = ((Integer) 3);
	call_localret(STATIC(mercury__base_type_layout__encode_mkword_4_0),
		mercury__base_type_layout__construct_eqv_type_4_0_i7,
		STATIC(mercury__base_type_layout__construct_eqv_type_4_0));
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_eqv_type_4_0));
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11);
	GOTO_LABEL(mercury__base_type_layout__construct_eqv_type_4_0_i12);
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i3);
	if ((((Integer) 1) == ((Integer) 0)))
		GOTO_LABEL(mercury__base_type_layout__construct_eqv_type_4_0_i9);
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_14);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	GOTO_LABEL(mercury__base_type_layout__construct_eqv_type_4_0_i8);
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i9);
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_10);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i8);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__construct_eqv_type_4_0_i10,
		STATIC(mercury__base_type_layout__construct_eqv_type_4_0));
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_eqv_type_4_0));
	r2 = ((Integer) 3);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__base_type_layout__encode_create_6_0),
		mercury__base_type_layout__construct_eqv_type_4_0_i11,
		STATIC(mercury__base_type_layout__construct_eqv_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i11);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_eqv_type_4_0));
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11);
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i12);
	detstackvar(1) = (Integer) r4;
	{
	Declare_entry(mercury__list__duplicate_3_0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__base_type_layout__construct_eqv_type_4_0_i13,
		STATIC(mercury__base_type_layout__construct_eqv_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i13);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_eqv_type_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__base_type_layout__construct_eqv_type_4_0_i14,
		STATIC(mercury__base_type_layout__construct_eqv_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_eqv_type_4_0_i14);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_eqv_type_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module16)
	init_entry(mercury__base_type_layout__construct_du_type_4_0);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1008);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1007);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1006);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1005);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1004);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i9);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i10);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i11);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i12);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i13);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i14);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i16);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1001);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i19);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i20);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i18);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i22);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i6);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i24);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i25);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i4);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i26);
	init_label(mercury__base_type_layout__construct_du_type_4_0_i1000);
BEGIN_CODE

/* code for predicate 'base_type_layout__construct_du_type'/4 in mode 0 */
Define_static(mercury__base_type_layout__construct_du_type_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i1000);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i1001);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)),
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1008) AND
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1007) AND
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1006) AND
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1005) AND
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1004) AND
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1004) AND
		LABEL(mercury__base_type_layout__construct_du_type_4_0_i1004));
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1008);
	incr_sp_push_msg(4, "base_type_layout__construct_du_type");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i9);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1007);
	incr_sp_push_msg(4, "base_type_layout__construct_du_type");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i12);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1006);
	incr_sp_push_msg(4, "base_type_layout__construct_du_type");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i14);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1005);
	incr_sp_push_msg(4, "base_type_layout__construct_du_type");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i16);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1004);
	incr_sp_push_msg(4, "base_type_layout__construct_du_type");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i4);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i9);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = ((Integer) 4);
	call_localret(STATIC(mercury__base_type_layout__const_value_2_0),
		mercury__base_type_layout__construct_du_type_4_0_i10,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
Define_label(mercury__base_type_layout__construct_du_type_4_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r2 = ((Integer) 0);
	r4 = (Integer) r1;
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	r1 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	call_localret(STATIC(mercury__base_type_layout__encode_mkword_4_0),
		mercury__base_type_layout__construct_du_type_4_0_i11,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i11);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11);
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i6);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i12);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = string_const("base_type_layout: Unexpected tag - pred_closure_tag/2", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__construct_du_type_4_0_i13,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i13);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i6);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i14);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = string_const("base_type_layout: Unexpected constant - code_addr_constant/2", 60);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__construct_du_type_4_0_i13,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i16);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = string_const("base_type_layout: Unexpected constant - base_type_into_constant/3", 65);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__construct_du_type_4_0_i13,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1001);
	incr_sp_push_msg(4, "base_type_layout__construct_du_type");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r4) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i18);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = ((Integer) 2);
	call_localret(STATIC(mercury__base_type_layout__const_value_2_0),
		mercury__base_type_layout__construct_du_type_4_0_i19,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
Define_label(mercury__base_type_layout__construct_du_type_4_0_i19);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 0);
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	call_localret(STATIC(mercury__base_type_layout__encode_mkword_4_0),
		mercury__base_type_layout__construct_du_type_4_0_i20,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i20);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_11);
	GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i6);
Define_label(mercury__base_type_layout__construct_du_type_4_0_i18);
	if ((tag((Integer) r4) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__base_type_layout__construct_du_type_4_0_i4);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = ((Integer) 3);
	call_localret(STATIC(mercury__base_type_layout__const_value_2_0),
		mercury__base_type_layout__construct_du_type_4_0_i22,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
Define_label(mercury__base_type_layout__construct_du_type_4_0_i22);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 0);
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	call_localret(STATIC(mercury__base_type_layout__encode_mkword_4_0),
		mercury__base_type_layout__construct_du_type_4_0_i20,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i6);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__list__duplicate_3_0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__base_type_layout__construct_du_type_4_0_i24,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i24);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__base_type_layout__construct_du_type_4_0_i25,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
Define_label(mercury__base_type_layout__construct_du_type_4_0_i25);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__base_type_layout__construct_du_type_4_0_i4);
	detstackvar(2) = (Integer) r2;
	r2 = ((Integer) r3 - ((Integer) 1));
	call_localret(STATIC(mercury__base_type_layout__gather_tags_3_0),
		mercury__base_type_layout__construct_du_type_4_0_i26,
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
Define_label(mercury__base_type_layout__construct_du_type_4_0_i26);
	update_prof_current_proc(LABEL(mercury__base_type_layout__construct_du_type_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__base_type_layout__generate_rvals_5_0),
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
Define_label(mercury__base_type_layout__construct_du_type_4_0_i1000);
	r1 = string_const("base_type_layout: type with no cons_tag information", 51);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_type_layout__construct_du_type_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module17)
	init_entry(mercury__base_type_layout__generate_rvals_5_0);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i1005);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i1004);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i1003);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i1002);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i1001);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i5);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i6);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i7);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i8);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i9);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i11);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i14);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i16);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i15);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i17);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i18);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i19);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i20);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i13);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i21);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i12);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i23);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i25);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i26);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i27);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i28);
	init_label(mercury__base_type_layout__generate_rvals_5_0_i1000);
BEGIN_CODE

/* code for predicate 'base_type_layout__generate_rvals'/5 in mode 0 */
Define_static(mercury__base_type_layout__generate_rvals_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i1000);
	COMPUTED_GOTO((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)),
		LABEL(mercury__base_type_layout__generate_rvals_5_0_i1005) AND
		LABEL(mercury__base_type_layout__generate_rvals_5_0_i1004) AND
		LABEL(mercury__base_type_layout__generate_rvals_5_0_i1003) AND
		LABEL(mercury__base_type_layout__generate_rvals_5_0_i1002) AND
		LABEL(mercury__base_type_layout__generate_rvals_5_0_i1001));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i1005);
	incr_sp_push_msg(8, "base_type_layout__generate_rvals");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i5);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i1004);
	incr_sp_push_msg(8, "base_type_layout__generate_rvals");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i8);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i1003);
	incr_sp_push_msg(8, "base_type_layout__generate_rvals");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i11);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i1002);
	incr_sp_push_msg(8, "base_type_layout__generate_rvals");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i23);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i1001);
	incr_sp_push_msg(8, "base_type_layout__generate_rvals");
	detstackvar(8) = (Integer) succip;
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i25);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i5);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	call_localret(STATIC(mercury__base_type_layout__handle_simple_4_0),
		mercury__base_type_layout__generate_rvals_5_0_i6,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__generate_rvals_5_0_i7,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__base_type_layout__generate_rvals_5_0,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i8);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	call_localret(STATIC(mercury__base_type_layout__handle_complicated_4_0),
		mercury__base_type_layout__generate_rvals_5_0_i9,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__generate_rvals_5_0_i7,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i11);
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i13);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_type_layout__generate_rvals_5_0_i14,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i14);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	if ((((Integer) 1) == ((Integer) 0)))
		GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i16);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(4);
	tag_incr_hp(r8, mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r2;
	r9 = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_14);
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_15);
	r4 = (Integer) detstackvar(3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i15);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i16);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(4);
	tag_incr_hp(r8, mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r2;
	r9 = (Integer) mkword(mktag(1), (Integer) mercury_data_base_type_layout__common_10);
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_15);
	r4 = (Integer) detstackvar(3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i15);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(5) = (Integer) r9;
	{
	Declare_entry(mercury__list__map_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__base_type_layout__generate_rvals_5_0_i17,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i17);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__generate_rvals_5_0_i18,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i18);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 2);
	call_localret(STATIC(mercury__base_type_layout__tag_value_2_0),
		mercury__base_type_layout__generate_rvals_5_0_i19,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i19);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(7);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__base_type_layout__encode_create_6_0),
		mercury__base_type_layout__generate_rvals_5_0_i20,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i20);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	GOTO_LABEL(mercury__base_type_layout__generate_rvals_5_0_i12);
Define_label(mercury__base_type_layout__generate_rvals_5_0_i13);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const("base_type_layout: no constructors for complicated constant tag", 62);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__generate_rvals_5_0_i21,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i21);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(1);
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i12);
	detstackvar(4) = (Integer) r4;
	detstackvar(1) = (Integer) r5;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__generate_rvals_5_0_i7,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i23);
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const("base_type_layout: unexpected no_tag", 35);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__generate_rvals_5_0_i7,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i25);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = ((Integer) 1);
	call_localret(STATIC(mercury__base_type_layout__const_value_2_0),
		mercury__base_type_layout__generate_rvals_5_0_i26,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i26);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 4);
	call_localret(STATIC(mercury__base_type_layout__tag_value_2_0),
		mercury__base_type_layout__generate_rvals_5_0_i27,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
Define_label(mercury__base_type_layout__generate_rvals_5_0_i27);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__base_type_layout__encode_mkword_4_0),
		mercury__base_type_layout__generate_rvals_5_0_i28,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i28);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_rvals_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__generate_rvals_5_0_i7,
		STATIC(mercury__base_type_layout__generate_rvals_5_0));
	}
Define_label(mercury__base_type_layout__generate_rvals_5_0_i1000);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module18)
	init_entry(mercury__base_type_layout__handle_simple_4_0);
	init_label(mercury__base_type_layout__handle_simple_4_0_i7);
	init_label(mercury__base_type_layout__handle_simple_4_0_i4);
	init_label(mercury__base_type_layout__handle_simple_4_0_i8);
	init_label(mercury__base_type_layout__handle_simple_4_0_i9);
	init_label(mercury__base_type_layout__handle_simple_4_0_i10);
	init_label(mercury__base_type_layout__handle_simple_4_0_i13);
	init_label(mercury__base_type_layout__handle_simple_4_0_i15);
	init_label(mercury__base_type_layout__handle_simple_4_0_i12);
	init_label(mercury__base_type_layout__handle_simple_4_0_i17);
	init_label(mercury__base_type_layout__handle_simple_4_0_i18);
	init_label(mercury__base_type_layout__handle_simple_4_0_i19);
	init_label(mercury__base_type_layout__handle_simple_4_0_i20);
	init_label(mercury__base_type_layout__handle_simple_4_0_i21);
	init_label(mercury__base_type_layout__handle_simple_4_0_i22);
	init_label(mercury__base_type_layout__handle_simple_4_0_i23);
	init_label(mercury__base_type_layout__handle_simple_4_0_i24);
	init_label(mercury__base_type_layout__handle_simple_4_0_i1000);
	init_label(mercury__base_type_layout__handle_simple_4_0_i25);
BEGIN_CODE

/* code for predicate 'base_type_layout__handle_simple'/4 in mode 0 */
Define_static(mercury__base_type_layout__handle_simple_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__handle_simple_4_0_i1000);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	incr_sp_push_msg(7, "base_type_layout__handle_simple");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__base_type_layout__handle_simple_4_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__base_type_layout__handle_simple_4_0_i7,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r5 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r6 = (Integer) r1;
	r3 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 1));
	r7 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 4));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_16);
	GOTO_LABEL(mercury__base_type_layout__handle_simple_4_0_i9);
Define_label(mercury__base_type_layout__handle_simple_4_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = string_const("base_type_layout: simple tag with no constructor", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__handle_simple_4_0_i8,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r7 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r4 = (Integer) r7;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(3);
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i9);
	detstackvar(1) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__base_type_layout__handle_simple_4_0_i10,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_hlds__cons_defn_0;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) STATIC(mercury__base_type_layout__LambdaGoal__4_2_0);
	{
	Declare_entry(mercury__list__filter_3_0);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__base_type_layout__handle_simple_4_0_i13,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i13);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__handle_simple_4_0_i12);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_hlds__cons_defn_0;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__base_type_layout__handle_simple_4_0_i15,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i15);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__base_type_layout__handle_simple_4_0_i12);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	GOTO_LABEL(mercury__base_type_layout__handle_simple_4_0_i18);
Define_label(mercury__base_type_layout__handle_simple_4_0_i12);
	r1 = string_const("base_type_layout: no matching cons definition", 45);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__handle_simple_4_0_i17,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i17);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__base_type_layout__handle_simple_4_0_i18);
	detstackvar(3) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__handle_simple_4_0_i19,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
Define_label(mercury__base_type_layout__handle_simple_4_0_i19);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_type_layout__handle_simple_4_0_i20,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i20);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__base_type_layout__generate_pseudo_type_infos_4_0),
		mercury__base_type_layout__handle_simple_4_0_i21,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
Define_label(mercury__base_type_layout__handle_simple_4_0_i21);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__handle_simple_4_0_i22,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i22);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = ((Integer) 0);
	call_localret(STATIC(mercury__base_type_layout__tag_value_2_0),
		mercury__base_type_layout__handle_simple_4_0_i23,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
Define_label(mercury__base_type_layout__handle_simple_4_0_i23);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__base_type_layout__encode_create_6_0),
		mercury__base_type_layout__handle_simple_4_0_i24,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i24);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__base_type_layout__handle_simple_4_0_i1000);
	incr_sp_push_msg(7, "base_type_layout__handle_simple");
	detstackvar(7) = (Integer) succip;
	r1 = string_const("base_type_layout: no constructors for simple tag", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__handle_simple_4_0_i25,
		STATIC(mercury__base_type_layout__handle_simple_4_0));
	}
Define_label(mercury__base_type_layout__handle_simple_4_0_i25);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_simple_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module19)
	init_entry(mercury__base_type_layout__handle_complicated_4_0);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i4);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i5);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i6);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i7);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i8);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i3);
	init_label(mercury__base_type_layout__handle_complicated_4_0_i9);
BEGIN_CODE

/* code for predicate 'base_type_layout__handle_complicated'/4 in mode 0 */
Define_static(mercury__base_type_layout__handle_complicated_4_0);
	incr_sp_push_msg(5, "base_type_layout__handle_complicated");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__handle_complicated_4_0_i3);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__handle_complicated_4_0_i4,
		STATIC(mercury__base_type_layout__handle_complicated_4_0));
Define_label(mercury__base_type_layout__handle_complicated_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_complicated_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_type_layout__handle_complicated_4_0_i5,
		STATIC(mercury__base_type_layout__handle_complicated_4_0));
	}
Define_label(mercury__base_type_layout__handle_complicated_4_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_complicated_4_0));
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(detstackvar(3), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) r2;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_17);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) detstackvar(3), ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_18);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__foldr_4_0);
	call_localret(ENTRY(mercury__list__foldr_4_0),
		mercury__base_type_layout__handle_complicated_4_0_i6,
		STATIC(mercury__base_type_layout__handle_complicated_4_0));
	}
	}
Define_label(mercury__base_type_layout__handle_complicated_4_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_complicated_4_0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = ((Integer) 1);
	call_localret(STATIC(mercury__base_type_layout__tag_value_2_0),
		mercury__base_type_layout__handle_complicated_4_0_i7,
		STATIC(mercury__base_type_layout__handle_complicated_4_0));
Define_label(mercury__base_type_layout__handle_complicated_4_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_complicated_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__base_type_layout__encode_create_6_0),
		mercury__base_type_layout__handle_complicated_4_0_i8,
		STATIC(mercury__base_type_layout__handle_complicated_4_0));
Define_label(mercury__base_type_layout__handle_complicated_4_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_complicated_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__base_type_layout__handle_complicated_4_0_i3);
	r1 = string_const("base_type_layout: no constructors for complicated tag", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__handle_complicated_4_0_i9,
		STATIC(mercury__base_type_layout__handle_complicated_4_0));
	}
Define_label(mercury__base_type_layout__handle_complicated_4_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_layout__handle_complicated_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module20)
	init_entry(mercury__base_type_layout__generate_pseudo_type_infos_4_0);
	init_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i4);
	init_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i5);
	init_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i1002);
BEGIN_CODE

/* code for predicate 'base_type_layout__generate_pseudo_type_infos'/4 in mode 0 */
Define_static(mercury__base_type_layout__generate_pseudo_type_infos_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i1002);
	incr_sp_push_msg(2, "base_type_layout__generate_pseudo_type_infos");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0),
		mercury__base_type_layout__generate_pseudo_type_infos_4_0_i4,
		STATIC(mercury__base_type_layout__generate_pseudo_type_infos_4_0));
Define_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_infos_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	localcall(mercury__base_type_layout__generate_pseudo_type_infos_4_0,
		LABEL(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i5),
		STATIC(mercury__base_type_layout__generate_pseudo_type_infos_4_0));
Define_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_infos_4_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_layout__generate_pseudo_type_infos_4_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module21)
	init_entry(mercury__base_type_layout__generate_pseudo_type_info_4_0);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i4);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i8);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i7);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i10);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i11);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i12);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i13);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i14);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i15);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i16);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i3);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i19);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i21);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i22);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i18);
	init_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i23);
BEGIN_CODE

/* code for predicate 'base_type_layout__generate_pseudo_type_info'/4 in mode 0 */
Define_static(mercury__base_type_layout__generate_pseudo_type_info_4_0);
	incr_sp_push_msg(11, "base_type_layout__generate_pseudo_type_info");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i4,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0_i3);
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__type_util__type_is_higher_order_3_0);
	call_localret(ENTRY(mercury__type_util__type_is_higher_order_3_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i8,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0_i7);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = string_const("", 0);
	r4 = string_const("pred", 4);
	r5 = ((Integer) 0);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(1), ((Integer) 1));
	tag_incr_hp(r10, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r10, ((Integer) 0)) = ((Integer) 1);
	r7 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) r10, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	GOTO_LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0_i12);
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i7);
	r1 = (Integer) detstackvar(10);
	detstackvar(6) = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__prog_util__unqualify_name_2_0);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i10,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = string_const("", 0);
	{
	Declare_entry(mercury__prog_util__sym_name_get_module_name_3_0);
	call_localret(ENTRY(mercury__prog_util__sym_name_get_module_name_3_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i11,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i11);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r7 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i12);
	detstackvar(4) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	call_localret(STATIC(mercury__base_type_layout__incr_next_label_2_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i13,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i13);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(detstackvar(5), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r4, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 2);
	tag_incr_hp(r5, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) r1;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) detstackvar(5), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r5, ((Integer) 2)) = ((Integer) 0);
	call_localret(STATIC(mercury__base_type_layout__generate_pseudo_type_infos_4_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i14,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i14);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__base_type_layout__remove_creates_2_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i15,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i15);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i16,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i16);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = ((Integer) 0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r4, ((Integer) 3)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) r4, ((Integer) 2)) = ((Integer) 1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i3);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__type_util__var_2_0);
	call_localret(ENTRY(mercury__type_util__var_2_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i19,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i19);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0_i18);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__term__var_to_int_2_0);
	call_localret(ENTRY(mercury__term__var_to_int_2_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i21,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i21);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	{
	Declare_entry(mercury__int__f_less_than_2_0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) ENTRY(mercury__int__f_less_than_2_0);
	}
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = ((Integer) 1024);
	r2 = string_const("base_type_layout: type variable representation exceeds limit", 60);
	{
	Declare_entry(mercury__require__require_2_0);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i22,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i22);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i18);
	r1 = string_const("base_type_layout: type neither var nor non-var", 46);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_type_layout__generate_pseudo_type_info_4_0_i23,
		STATIC(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	}
Define_label(mercury__base_type_layout__generate_pseudo_type_info_4_0_i23);
	update_prof_current_proc(LABEL(mercury__base_type_layout__generate_pseudo_type_info_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module22)
	init_entry(mercury__base_type_layout__remove_creates_2_0);
	init_label(mercury__base_type_layout__remove_creates_2_0_i10);
	init_label(mercury__base_type_layout__remove_creates_2_0_i2);
	init_label(mercury__base_type_layout__remove_creates_2_0_i8);
	init_label(mercury__base_type_layout__remove_creates_2_0_i11);
	init_label(mercury__base_type_layout__remove_creates_2_0_i1);
BEGIN_CODE

/* code for predicate 'base_type_layout__remove_creates'/2 in mode 0 */
Define_static(mercury__base_type_layout__remove_creates_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i1);
	r5 = (Integer) sp;
Define_label(mercury__base_type_layout__remove_creates_2_0_i10);
	incr_sp_push_msg(1, "base_type_layout__remove_creates");
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i2);
	r4 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i2);
	if (((Integer) field(mktag(2), (Integer) r4, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i2);
	if (((Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r4, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i2);
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r4, ((Integer) 1)), ((Integer) 0));
	GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i8);
Define_label(mercury__base_type_layout__remove_creates_2_0_i2);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
Define_label(mercury__base_type_layout__remove_creates_2_0_i8);
	detstackvar(1) = (Integer) r2;
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__remove_creates_2_0_i10);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__base_type_layout__remove_creates_2_0_i11);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r5))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__base_type_layout__remove_creates_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module23)
	init_entry(mercury__base_type_layout__gather_tags_3_0);
	init_label(mercury__base_type_layout__gather_tags_3_0_i1000);
	init_label(mercury__base_type_layout__gather_tags_3_0_i4);
	init_label(mercury__base_type_layout__gather_tags_3_0_i5);
	init_label(mercury__base_type_layout__gather_tags_3_0_i6);
BEGIN_CODE

/* code for predicate 'base_type_layout__gather_tags'/3 in mode 0 */
Define_static(mercury__base_type_layout__gather_tags_3_0);
	if (((Integer) r2 >= ((Integer) 0)))
		GOTO_LABEL(mercury__base_type_layout__gather_tags_3_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__base_type_layout__gather_tags_3_0_i1000);
	incr_sp_push_msg(4, "base_type_layout__gather_tags");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__base_type_layout__get_tags_4_0),
		mercury__base_type_layout__gather_tags_3_0_i4,
		STATIC(mercury__base_type_layout__gather_tags_3_0));
Define_label(mercury__base_type_layout__gather_tags_3_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gather_tags_3_0));
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_6);
	{
	Declare_entry(mercury__list__delete_elems_3_0);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__base_type_layout__gather_tags_3_0_i5,
		STATIC(mercury__base_type_layout__gather_tags_3_0));
	}
Define_label(mercury__base_type_layout__gather_tags_3_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gather_tags_3_0));
	r2 = ((Integer) detstackvar(2) - ((Integer) 1));
	localcall(mercury__base_type_layout__gather_tags_3_0,
		LABEL(mercury__base_type_layout__gather_tags_3_0_i6),
		STATIC(mercury__base_type_layout__gather_tags_3_0));
Define_label(mercury__base_type_layout__gather_tags_3_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_layout__gather_tags_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module24)
	init_entry(mercury__base_type_layout__get_tags_4_0);
	init_label(mercury__base_type_layout__get_tags_4_0_i18);
	init_label(mercury__base_type_layout__get_tags_4_0_i19);
	init_label(mercury__base_type_layout__get_tags_4_0_i6);
	init_label(mercury__base_type_layout__get_tags_4_0_i10);
	init_label(mercury__base_type_layout__get_tags_4_0_i11);
	init_label(mercury__base_type_layout__get_tags_4_0_i12);
	init_label(mercury__base_type_layout__get_tags_4_0_i5);
	init_label(mercury__base_type_layout__get_tags_4_0_i13);
	init_label(mercury__base_type_layout__get_tags_4_0_i14);
	init_label(mercury__base_type_layout__get_tags_4_0_i3);
	init_label(mercury__base_type_layout__get_tags_4_0_i15);
	init_label(mercury__base_type_layout__get_tags_4_0_i17);
	init_label(mercury__base_type_layout__get_tags_4_0_i1);
BEGIN_CODE

/* code for predicate 'base_type_layout__get_tags'/4 in mode 0 */
Define_static(mercury__base_type_layout__get_tags_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i1);
	r7 = (Integer) sp;
Define_label(mercury__base_type_layout__get_tags_4_0_i18);
	while (1) {
	incr_sp_push_msg(3, "base_type_layout__get_tags");
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = ((Integer) 4);
	break; } /* end while */
Define_label(mercury__base_type_layout__get_tags_4_0_i19);
	r3 = (Integer) detstackvar(3);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i5);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)),
		LABEL(mercury__base_type_layout__get_tags_4_0_i6) AND
		LABEL(mercury__base_type_layout__get_tags_4_0_i6) AND
		LABEL(mercury__base_type_layout__get_tags_4_0_i6) AND
		LABEL(mercury__base_type_layout__get_tags_4_0_i6) AND
		LABEL(mercury__base_type_layout__get_tags_4_0_i10) AND
		LABEL(mercury__base_type_layout__get_tags_4_0_i11) AND
		LABEL(mercury__base_type_layout__get_tags_4_0_i12));
Define_label(mercury__base_type_layout__get_tags_4_0_i6);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 4);
	r3 = (Integer) detstackvar(2);
	r6 = ((Integer) -1);
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i3);
Define_label(mercury__base_type_layout__get_tags_4_0_i10);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r6 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i3);
Define_label(mercury__base_type_layout__get_tags_4_0_i11);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r6 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i3);
Define_label(mercury__base_type_layout__get_tags_4_0_i12);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r6 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 2);
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i3);
Define_label(mercury__base_type_layout__get_tags_4_0_i5);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i13);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 3);
	r3 = (Integer) detstackvar(2);
	r6 = ((Integer) -1);
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i3);
Define_label(mercury__base_type_layout__get_tags_4_0_i13);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i14);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 4);
	r3 = (Integer) detstackvar(2);
	r6 = ((Integer) -1);
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i3);
Define_label(mercury__base_type_layout__get_tags_4_0_i14);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 4);
	r3 = (Integer) detstackvar(2);
	r6 = ((Integer) -1);
Define_label(mercury__base_type_layout__get_tags_4_0_i3);
	if (((Integer) r6 != (Integer) r1))
		GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i15);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i17);
Define_label(mercury__base_type_layout__get_tags_4_0_i15);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
Define_label(mercury__base_type_layout__get_tags_4_0_i17);
	decr_sp_pop_msg(3);
	if (((Integer) sp > (Integer) r7))
		GOTO_LABEL(mercury__base_type_layout__get_tags_4_0_i19);
	proceed();
Define_label(mercury__base_type_layout__get_tags_4_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = ((Integer) 4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module25)
	init_entry(mercury__base_type_layout__incr_next_label_2_0);
BEGIN_CODE

/* code for predicate 'base_type_layout__incr_next_label'/2 in mode 0 */
Define_static(mercury__base_type_layout__incr_next_label_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = ((Integer) field(mktag(0), (Integer) r2, ((Integer) 3)) + ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module26)
	init_entry(mercury____Unify___base_type_layout__layout_info_0_0);
	init_label(mercury____Unify___base_type_layout__layout_info_0_0_i2);
	init_label(mercury____Unify___base_type_layout__layout_info_0_0_i4);
	init_label(mercury____Unify___base_type_layout__layout_info_0_0_i1006);
	init_label(mercury____Unify___base_type_layout__layout_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___base_type_layout__layout_info_0_0);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___base_type_layout__layout_info_0_0_i1006);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_16);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___base_type_layout__layout_info_0_0_i2,
		STATIC(mercury____Unify___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Unify___base_type_layout__layout_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___base_type_layout__layout_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___base_type_layout__layout_info_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(5)))
		GOTO_LABEL(mercury____Unify___base_type_layout__layout_info_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(6)))
		GOTO_LABEL(mercury____Unify___base_type_layout__layout_info_0_0_i1);
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___base_type_layout__layout_info_0_0_i4,
		STATIC(mercury____Unify___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Unify___base_type_layout__layout_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___base_type_layout__layout_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___base_type_layout__layout_info_0_0_i1);
	r1 = (Integer) mercury_data_llds__base_type_info_c_module_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		STATIC(mercury____Unify___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Unify___base_type_layout__layout_info_0_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___base_type_layout__layout_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module27)
	init_entry(mercury____Index___base_type_layout__layout_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___base_type_layout__layout_info_0_0);
	tailcall(STATIC(mercury____Index___base_type_layout_layout_info_0__ua10000_2_0),
		STATIC(mercury____Index___base_type_layout__layout_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__base_type_layout_module28)
	init_entry(mercury____Compare___base_type_layout__layout_info_0_0);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i4);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i5);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i3);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i10);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i16);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i22);
	init_label(mercury____Compare___base_type_layout__layout_info_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___base_type_layout__layout_info_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___base_type_layout__layout_info_0_0_i4,
		STATIC(mercury____Compare___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___base_type_layout__layout_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___base_type_layout__layout_info_0_0_i3);
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i3);
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_base_type_layout__common_16);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___base_type_layout__layout_info_0_0_i10,
		STATIC(mercury____Compare___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___base_type_layout__layout_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___base_type_layout__layout_info_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___base_type_layout__layout_info_0_0_i16,
		STATIC(mercury____Compare___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___base_type_layout__layout_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___base_type_layout__layout_info_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___base_type_layout__layout_info_0_0_i22,
		STATIC(mercury____Compare___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___base_type_layout__layout_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___base_type_layout__layout_info_0_0_i5);
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___base_type_layout__layout_info_0_0_i28,
		STATIC(mercury____Compare___base_type_layout__layout_info_0_0));
	}
Define_label(mercury____Compare___base_type_layout__layout_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___base_type_layout__layout_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___base_type_layout__layout_info_0_0_i5);
	r1 = (Integer) mercury_data_llds__base_type_info_c_module_0;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		STATIC(mercury____Compare___base_type_layout__layout_info_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__base_type_layout_bunch_0(void)
{
	mercury__base_type_layout_module0();
	mercury__base_type_layout_module1();
	mercury__base_type_layout_module2();
	mercury__base_type_layout_module3();
	mercury__base_type_layout_module4();
	mercury__base_type_layout_module5();
	mercury__base_type_layout_module6();
	mercury__base_type_layout_module7();
	mercury__base_type_layout_module8();
	mercury__base_type_layout_module9();
	mercury__base_type_layout_module10();
	mercury__base_type_layout_module11();
	mercury__base_type_layout_module12();
	mercury__base_type_layout_module13();
	mercury__base_type_layout_module14();
	mercury__base_type_layout_module15();
	mercury__base_type_layout_module16();
	mercury__base_type_layout_module17();
	mercury__base_type_layout_module18();
	mercury__base_type_layout_module19();
	mercury__base_type_layout_module20();
	mercury__base_type_layout_module21();
	mercury__base_type_layout_module22();
	mercury__base_type_layout_module23();
	mercury__base_type_layout_module24();
	mercury__base_type_layout_module25();
	mercury__base_type_layout_module26();
	mercury__base_type_layout_module27();
	mercury__base_type_layout_module28();
}

#endif

void mercury__base_type_layout__init(void); /* suppress gcc warning */
void mercury__base_type_layout__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__base_type_layout_bunch_0();
#endif
}
