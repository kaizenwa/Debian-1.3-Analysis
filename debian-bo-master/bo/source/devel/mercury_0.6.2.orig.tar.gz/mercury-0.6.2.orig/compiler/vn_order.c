/*
** Automatically generated from `vn_order.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_order__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__vn_order__order_9_0);
Declare_label(mercury__vn_order__order_9_0_i2);
Declare_label(mercury__vn_order__order_9_0_i3);
Declare_label(mercury__vn_order__order_9_0_i4);
Declare_label(mercury__vn_order__order_9_0_i5);
Declare_label(mercury__vn_order__order_9_0_i7);
Declare_label(mercury__vn_order__order_9_0_i8);
Declare_label(mercury__vn_order__order_9_0_i9);
Declare_label(mercury__vn_order__order_9_0_i10);
Declare_label(mercury__vn_order__order_9_0_i11);
Declare_label(mercury__vn_order__order_9_0_i12);
Declare_label(mercury__vn_order__order_9_0_i13);
Declare_label(mercury__vn_order__order_9_0_i14);
Declare_label(mercury__vn_order__order_9_0_i15);
Declare_label(mercury__vn_order__order_9_0_i16);
Declare_label(mercury__vn_order__order_9_0_i17);
Declare_label(mercury__vn_order__order_9_0_i18);
Declare_label(mercury__vn_order__order_9_0_i19);
Declare_label(mercury__vn_order__order_9_0_i20);
Declare_label(mercury__vn_order__order_9_0_i21);
Declare_static(mercury__vn_order__req_order_2_11_0);
Declare_label(mercury__vn_order__req_order_2_11_0_i4);
Declare_label(mercury__vn_order__req_order_2_11_0_i6);
Declare_label(mercury__vn_order__req_order_2_11_0_i9);
Declare_label(mercury__vn_order__req_order_2_11_0_i13);
Declare_label(mercury__vn_order__req_order_2_11_0_i14);
Declare_label(mercury__vn_order__req_order_2_11_0_i18);
Declare_label(mercury__vn_order__req_order_2_11_0_i21);
Declare_label(mercury__vn_order__req_order_2_11_0_i22);
Declare_label(mercury__vn_order__req_order_2_11_0_i23);
Declare_label(mercury__vn_order__req_order_2_11_0_i26);
Declare_label(mercury__vn_order__req_order_2_11_0_i1030);
Declare_label(mercury__vn_order__req_order_2_11_0_i29);
Declare_label(mercury__vn_order__req_order_2_11_0_i28);
Declare_label(mercury__vn_order__req_order_2_11_0_i31);
Declare_label(mercury__vn_order__req_order_2_11_0_i32);
Declare_label(mercury__vn_order__req_order_2_11_0_i35);
Declare_label(mercury__vn_order__req_order_2_11_0_i34);
Declare_label(mercury__vn_order__req_order_2_11_0_i37);
Declare_label(mercury__vn_order__req_order_2_11_0_i39);
Declare_label(mercury__vn_order__req_order_2_11_0_i1033);
Declare_label(mercury__vn_order__req_order_2_11_0_i43);
Declare_label(mercury__vn_order__req_order_2_11_0_i41);
Declare_label(mercury__vn_order__req_order_2_11_0_i3);
Declare_static(mercury__vn_order__record_ctrl_deps_7_0);
Declare_label(mercury__vn_order__record_ctrl_deps_7_0_i1001);
Declare_label(mercury__vn_order__record_ctrl_deps_7_0_i4);
Declare_label(mercury__vn_order__record_ctrl_deps_7_0_i5);
Declare_label(mercury__vn_order__record_ctrl_deps_7_0_i6);
Declare_label(mercury__vn_order__record_ctrl_deps_7_0_i1);
Declare_label(mercury__vn_order__record_ctrl_deps_7_0_i1000);
Declare_static(mercury__vn_order__prod_cons_order_7_0);
Declare_label(mercury__vn_order__prod_cons_order_7_0_i4);
Declare_label(mercury__vn_order__prod_cons_order_7_0_i5);
Declare_label(mercury__vn_order__prod_cons_order_7_0_i6);
Declare_label(mercury__vn_order__prod_cons_order_7_0_i8);
Declare_label(mercury__vn_order__prod_cons_order_7_0_i1003);
Declare_static(mercury__vn_order__ctrl_vn_order_9_0);
Declare_label(mercury__vn_order__ctrl_vn_order_9_0_i2);
Declare_static(mercury__vn_order__ctrl_vn_order_2_12_0);
Declare_label(mercury__vn_order__ctrl_vn_order_2_12_0_i4);
Declare_label(mercury__vn_order__ctrl_vn_order_2_12_0_i6);
Declare_label(mercury__vn_order__ctrl_vn_order_2_12_0_i7);
Declare_label(mercury__vn_order__ctrl_vn_order_2_12_0_i8);
Declare_label(mercury__vn_order__ctrl_vn_order_2_12_0_i9);
Declare_label(mercury__vn_order__ctrl_vn_order_2_12_0_i3);
Declare_static(mercury__vn_order__append_vnlval_nodes_3_0);
Declare_label(mercury__vn_order__append_vnlval_nodes_3_0_i3);
Declare_label(mercury__vn_order__append_vnlval_nodes_3_0_i1);
Declare_static(mercury__vn_order__record_antideps_11_0);
Declare_label(mercury__vn_order__record_antideps_11_0_i1009);
Declare_label(mercury__vn_order__record_antideps_11_0_i6);
Declare_label(mercury__vn_order__record_antideps_11_0_i11);
Declare_label(mercury__vn_order__record_antideps_11_0_i13);
Declare_label(mercury__vn_order__record_antideps_11_0_i14);
Declare_label(mercury__vn_order__record_antideps_11_0_i5);
Declare_label(mercury__vn_order__record_antideps_11_0_i4);
Declare_label(mercury__vn_order__record_antideps_11_0_i1006);
Declare_static(mercury__vn_order__add_computed_links_5_0);
Declare_label(mercury__vn_order__add_computed_links_5_0_i4);
Declare_label(mercury__vn_order__add_computed_links_5_0_i1002);
Declare_static(mercury__vn_order__vn_ctrl_order_8_0);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i4);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i9);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i12);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i13);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i14);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i16);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i1009);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i19);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i21);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i1011);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i24);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i8);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i28);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i29);
Declare_label(mercury__vn_order__vn_ctrl_order_8_0_i3);
Declare_static(mercury__vn_order__use_sinks_before_redef_9_0);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i4);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i8);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i10);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i14);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i13);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i16);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i17);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i18);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i19);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i20);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i23);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i25);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i27);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i22);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i6);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i5);
Declare_label(mercury__vn_order__use_sinks_before_redef_9_0_i1010);
Declare_static(mercury__vn_order__find_access_users_4_0);
Declare_label(mercury__vn_order__find_access_users_4_0_i4);
Declare_label(mercury__vn_order__find_access_users_4_0_i11);
Declare_label(mercury__vn_order__find_access_users_4_0_i10);
Declare_label(mercury__vn_order__find_access_users_4_0_i13);
Declare_label(mercury__vn_order__find_access_users_4_0_i16);
Declare_label(mercury__vn_order__find_access_users_4_0_i17);
Declare_label(mercury__vn_order__find_access_users_4_0_i18);
Declare_label(mercury__vn_order__find_access_users_4_0_i1026);
Declare_label(mercury__vn_order__find_access_users_4_0_i5);
Declare_label(mercury__vn_order__find_access_users_4_0_i1014);
Declare_static(mercury__vn_order__add_users_11_0);
Declare_label(mercury__vn_order__add_users_11_0_i8);
Declare_label(mercury__vn_order__add_users_11_0_i7);
Declare_label(mercury__vn_order__add_users_11_0_i10);
Declare_label(mercury__vn_order__add_users_11_0_i5);
Declare_label(mercury__vn_order__add_users_11_0_i4);
Declare_label(mercury__vn_order__add_users_11_0_i12);
Declare_label(mercury__vn_order__add_users_11_0_i13);
Declare_label(mercury__vn_order__add_users_11_0_i17);
Declare_label(mercury__vn_order__add_users_11_0_i18);
Declare_label(mercury__vn_order__add_users_11_0_i14);
Declare_label(mercury__vn_order__add_users_11_0_i1007);
Declare_static(mercury__vn_order__add_aliases_10_0);
Declare_label(mercury__vn_order__add_aliases_10_0_i6);
Declare_label(mercury__vn_order__add_aliases_10_0_i8);
Declare_label(mercury__vn_order__add_aliases_10_0_i9);
Declare_label(mercury__vn_order__add_aliases_10_0_i5);
Declare_label(mercury__vn_order__add_aliases_10_0_i4);
Declare_label(mercury__vn_order__add_aliases_10_0_i1004);
Declare_label(mercury__vn_order__add_aliases_10_0_i1006);
Declare_static(mercury__vn_order__find_links_8_0);
Declare_label(mercury__vn_order__find_links_8_0_i2);
Declare_label(mercury__vn_order__find_links_8_0_i3);
Declare_label(mercury__vn_order__find_links_8_0_i6);
Declare_label(mercury__vn_order__find_links_8_0_i11);
Declare_label(mercury__vn_order__find_links_8_0_i5);
Declare_label(mercury__vn_order__find_links_8_0_i16);
Declare_label(mercury__vn_order__find_links_8_0_i17);
Declare_label(mercury__vn_order__find_links_8_0_i19);
Declare_label(mercury__vn_order__find_links_8_0_i15);
Declare_label(mercury__vn_order__find_links_8_0_i22);
Declare_label(mercury__vn_order__find_links_8_0_i23);
Declare_label(mercury__vn_order__find_links_8_0_i24);
Declare_label(mercury__vn_order__find_links_8_0_i21);
Declare_label(mercury__vn_order__find_links_8_0_i25);
Declare_static(mercury__vn_order__find_all_links_8_0);
Declare_label(mercury__vn_order__find_all_links_8_0_i4);
Declare_label(mercury__vn_order__find_all_links_8_0_i1002);
Declare_static(mercury__vn_order__add_link_6_0);
Declare_label(mercury__vn_order__add_link_6_0_i4);
Declare_label(mercury__vn_order__add_link_6_0_i3);
Declare_label(mercury__vn_order__add_link_6_0_i8);
Declare_label(mercury__vn_order__add_link_6_0_i12);
Declare_label(mercury__vn_order__add_link_6_0_i11);
Declare_label(mercury__vn_order__add_link_6_0_i14);
Declare_label(mercury__vn_order__add_link_6_0_i15);
Declare_label(mercury__vn_order__add_link_6_0_i7);
Declare_label(mercury__vn_order__add_link_6_0_i16);
Declare_label(mercury__vn_order__add_link_6_0_i17);
Declare_label(mercury__vn_order__add_link_6_0_i20);
Declare_label(mercury__vn_order__add_link_6_0_i19);
Declare_label(mercury__vn_order__add_link_6_0_i22);
Declare_label(mercury__vn_order__add_link_6_0_i23);
Declare_label(mercury__vn_order__add_link_6_0_i26);
Declare_label(mercury__vn_order__add_link_6_0_i30);
Declare_label(mercury__vn_order__add_link_6_0_i29);
Declare_label(mercury__vn_order__add_link_6_0_i32);
Declare_label(mercury__vn_order__add_link_6_0_i33);
Declare_label(mercury__vn_order__add_link_6_0_i25);
Declare_label(mercury__vn_order__add_link_6_0_i34);
Declare_label(mercury__vn_order__add_link_6_0_i35);
Declare_label(mercury__vn_order__add_link_6_0_i38);
Declare_label(mercury__vn_order__add_link_6_0_i37);
Declare_label(mercury__vn_order__add_link_6_0_i40);
Declare_static(mercury__vn_order__pref_order_2_0);
Declare_label(mercury__vn_order__pref_order_2_0_i2);
Declare_label(mercury__vn_order__pref_order_2_0_i3);
Declare_static(mercury__vn_order__classify_nodes_5_0);
Declare_label(mercury__vn_order__classify_nodes_5_0_i7);
Declare_label(mercury__vn_order__classify_nodes_5_0_i6);
Declare_label(mercury__vn_order__classify_nodes_5_0_i9);
Declare_label(mercury__vn_order__classify_nodes_5_0_i8);
Declare_label(mercury__vn_order__classify_nodes_5_0_i11);
Declare_label(mercury__vn_order__classify_nodes_5_0_i10);
Declare_label(mercury__vn_order__classify_nodes_5_0_i12);
Declare_label(mercury__vn_order__classify_nodes_5_0_i1008);
Declare_static(mercury__vn_order__blocks_to_order_6_0);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i2);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i3);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i4);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i5);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i12);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i9);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i13);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i14);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i15);
Declare_label(mercury__vn_order__blocks_to_order_6_0_i16);
Declare_static(mercury__vn_order__find_last_ctrl_4_0);
Declare_label(mercury__vn_order__find_last_ctrl_4_0_i7);
Declare_label(mercury__vn_order__find_last_ctrl_4_0_i8);
Declare_label(mercury__vn_order__find_last_ctrl_4_0_i3);
Declare_label(mercury__vn_order__find_last_ctrl_4_0_i6);
Declare_label(mercury__vn_order__find_last_ctrl_4_0_i1);
Declare_static(mercury__vn_order__order_equal_lists_5_0);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i4);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i5);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i6);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i7);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i8);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i9);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i10);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i11);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i12);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i13);
Declare_label(mercury__vn_order__order_equal_lists_5_0_i1007);
Declare_static(mercury__vn_order__find_ctrls_3_0);
Declare_label(mercury__vn_order__find_ctrls_3_0_i7);
Declare_label(mercury__vn_order__find_ctrls_3_0_i8);
Declare_label(mercury__vn_order__find_ctrls_3_0_i3);
Declare_label(mercury__vn_order__find_ctrls_3_0_i6);
Declare_label(mercury__vn_order__find_ctrls_3_0_i1);
Declare_static(mercury__vn_order__find_noops_4_0);
Declare_label(mercury__vn_order__find_noops_4_0_i4);
Declare_label(mercury__vn_order__find_noops_4_0_i8);
Declare_label(mercury__vn_order__find_noops_4_0_i10);
Declare_label(mercury__vn_order__find_noops_4_0_i6);
Declare_label(mercury__vn_order__find_noops_4_0_i5);
Declare_label(mercury__vn_order__find_noops_4_0_i1007);
Declare_static(mercury__vn_order__find_regs_3_0);
Declare_label(mercury__vn_order__find_regs_3_0_i4);
Declare_label(mercury__vn_order__find_regs_3_0_i9);
Declare_label(mercury__vn_order__find_regs_3_0_i5);
Declare_label(mercury__vn_order__find_regs_3_0_i3);
Declare_label(mercury__vn_order__find_regs_3_0_i11);
Declare_static(mercury__vn_order__find_stackvars_3_0);
Declare_label(mercury__vn_order__find_stackvars_3_0_i4);
Declare_label(mercury__vn_order__find_stackvars_3_0_i9);
Declare_label(mercury__vn_order__find_stackvars_3_0_i8);
Declare_label(mercury__vn_order__find_stackvars_3_0_i11);
Declare_label(mercury__vn_order__find_stackvars_3_0_i5);
Declare_label(mercury__vn_order__find_stackvars_3_0_i3);
Declare_label(mercury__vn_order__find_stackvars_3_0_i13);
Declare_static(mercury__vn_order__reorder_noops_2_4_0);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i4);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i9);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i10);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i12);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i13);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i8);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i6);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i5);
Declare_label(mercury__vn_order__reorder_noops_2_4_0_i1008);
Define_extern_entry(mercury____Unify___vn_order__order_result_0_0);
Declare_label(mercury____Unify___vn_order__order_result_0_0_i5);
Declare_label(mercury____Unify___vn_order__order_result_0_0_i1009);
Declare_label(mercury____Unify___vn_order__order_result_0_0_i1006);
Declare_label(mercury____Unify___vn_order__order_result_0_0_i1);
Declare_label(mercury____Unify___vn_order__order_result_0_0_i1008);
Define_extern_entry(mercury____Index___vn_order__order_result_0_0);
Declare_label(mercury____Index___vn_order__order_result_0_0_i3);
Define_extern_entry(mercury____Compare___vn_order__order_result_0_0);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i2);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i3);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i4);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i6);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i15);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i14);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i11);
Declare_label(mercury____Compare___vn_order__order_result_0_0_i9);

extern Word * mercury_data_vn_order__base_type_layout_order_result_0[];
Word * mercury_data_vn_order__base_type_info_order_result_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_order__order_result_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_order__order_result_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_order__order_result_0_0),
	(Word *) (Integer) mercury_data_vn_order__base_type_layout_order_result_0
};

extern Word * mercury_data_vn_order__common_5[];
extern Word * mercury_data_vn_order__common_7[];
Word * mercury_data_vn_order__base_type_layout_order_result_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_order__common_5),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_order__common_7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_vn_type__base_type_info_vn_node_0[];
Word * mercury_data_vn_order__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vn_node_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_vn_order__common_1[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word mercury_data_vn_order__common_2[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_order__common_3[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_vn_table__base_type_info_vn_tables_0[];
Word * mercury_data_vn_order__common_4[] = {
	(Word *) (Integer) mercury_data_vn_table__base_type_info_vn_tables_0
};

Word * mercury_data_vn_order__common_5[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0),
	(Word *) string_const("success", 7)
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data_llds__base_type_info_label_0[];
Word * mercury_data_vn_order__common_6[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_label_0
};

Word * mercury_data_vn_order__common_7[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_6),
	(Word *) string_const("failure", 7)
};

BEGIN_MODULE(mercury__vn_order_module0)
	init_entry(mercury__vn_order__order_9_0);
	init_label(mercury__vn_order__order_9_0_i2);
	init_label(mercury__vn_order__order_9_0_i3);
	init_label(mercury__vn_order__order_9_0_i4);
	init_label(mercury__vn_order__order_9_0_i5);
	init_label(mercury__vn_order__order_9_0_i7);
	init_label(mercury__vn_order__order_9_0_i8);
	init_label(mercury__vn_order__order_9_0_i9);
	init_label(mercury__vn_order__order_9_0_i10);
	init_label(mercury__vn_order__order_9_0_i11);
	init_label(mercury__vn_order__order_9_0_i12);
	init_label(mercury__vn_order__order_9_0_i13);
	init_label(mercury__vn_order__order_9_0_i14);
	init_label(mercury__vn_order__order_9_0_i15);
	init_label(mercury__vn_order__order_9_0_i16);
	init_label(mercury__vn_order__order_9_0_i17);
	init_label(mercury__vn_order__order_9_0_i18);
	init_label(mercury__vn_order__order_9_0_i19);
	init_label(mercury__vn_order__order_9_0_i20);
	init_label(mercury__vn_order__order_9_0_i21);
BEGIN_CODE

/* code for predicate 'vn_order__order'/9 in mode 0 */
Define_entry(mercury__vn_order__order_9_0);
	incr_sp_push_msg(10, "vn_order__order");
	detstackvar(10) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r5;
	r2 = (Integer) r6;
	r4 = (Integer) r7;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__vn_debug__order_start_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__order_start_msg_5_0),
		mercury__vn_order__order_9_0_i2,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_order__order_9_0_i3,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_order__order_9_0_i4,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r8 = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r7 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__vn_order__req_order_2_11_0),
		mercury__vn_order__order_9_0_i5,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__order_9_0_i7);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_order__order_9_0_i7);
	detstackvar(3) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_order__order_9_0_i8,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__vn_order__prod_cons_order_7_0),
		mercury__vn_order__order_9_0_i9,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r5 = (Integer) r3;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r1;
	r4 = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__vn_ctrl_order_8_0),
		mercury__vn_order__order_9_0_i10,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r3;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__vn_order__order_9_0_i11,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	r6 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__vn_order__use_sinks_before_redef_9_0),
		mercury__vn_order__order_9_0_i12,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r5 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_order__ctrl_vn_order_9_0),
		mercury__vn_order__order_9_0_i13,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__vn_order__add_computed_links_5_0),
		mercury__vn_order__order_9_0_i14,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	r4 = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__vn_debug__order_map_msg_6_0);
	call_localret(ENTRY(mercury__vn_debug__order_map_msg_6_0),
		mercury__vn_order__order_9_0_i15,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_order__pref_order_2_0),
		mercury__vn_order__order_9_0_i16,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r6 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__atsort__atsort_6_0);
	call_localret(ENTRY(mercury__atsort__atsort_6_0),
		mercury__vn_order__order_9_0_i17,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r2 = ((Integer) detstackvar(4) - ((Integer) 1));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__vn_order__blocks_to_order_6_0),
		mercury__vn_order__order_9_0_i18,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__reorder_noops_2_4_0),
		mercury__vn_order__order_9_0_i19,
		ENTRY(mercury__vn_order__order_9_0));
Define_label(mercury__vn_order__order_9_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_order__order_9_0_i20,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__vn_debug__order_order_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__order_order_msg_3_0),
		mercury__vn_order__order_9_0_i21,
		ENTRY(mercury__vn_order__order_9_0));
	}
Define_label(mercury__vn_order__order_9_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_order__order_9_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module1)
	init_entry(mercury__vn_order__req_order_2_11_0);
	init_label(mercury__vn_order__req_order_2_11_0_i4);
	init_label(mercury__vn_order__req_order_2_11_0_i6);
	init_label(mercury__vn_order__req_order_2_11_0_i9);
	init_label(mercury__vn_order__req_order_2_11_0_i13);
	init_label(mercury__vn_order__req_order_2_11_0_i14);
	init_label(mercury__vn_order__req_order_2_11_0_i18);
	init_label(mercury__vn_order__req_order_2_11_0_i21);
	init_label(mercury__vn_order__req_order_2_11_0_i22);
	init_label(mercury__vn_order__req_order_2_11_0_i23);
	init_label(mercury__vn_order__req_order_2_11_0_i26);
	init_label(mercury__vn_order__req_order_2_11_0_i1030);
	init_label(mercury__vn_order__req_order_2_11_0_i29);
	init_label(mercury__vn_order__req_order_2_11_0_i28);
	init_label(mercury__vn_order__req_order_2_11_0_i31);
	init_label(mercury__vn_order__req_order_2_11_0_i32);
	init_label(mercury__vn_order__req_order_2_11_0_i35);
	init_label(mercury__vn_order__req_order_2_11_0_i34);
	init_label(mercury__vn_order__req_order_2_11_0_i37);
	init_label(mercury__vn_order__req_order_2_11_0_i39);
	init_label(mercury__vn_order__req_order_2_11_0_i1033);
	init_label(mercury__vn_order__req_order_2_11_0_i43);
	init_label(mercury__vn_order__req_order_2_11_0_i41);
	init_label(mercury__vn_order__req_order_2_11_0_i3);
BEGIN_CODE

/* code for predicate 'vn_order__req_order_2'/11 in mode 0 */
Define_static(mercury__vn_order__req_order_2_11_0);
	incr_sp_push_msg(13, "vn_order__req_order_2");
	detstackvar(13) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_instr_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	}
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__req_order_2_11_0_i4,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i3);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i6);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i6);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r10 = ((Integer) 0);
	GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i13);
Define_label(mercury__vn_order__req_order_2_11_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i9);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i9);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r10 = ((Integer) 0);
	GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i13);
Define_label(mercury__vn_order__req_order_2_11_0_i9);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r10 = ((Integer) 1);
Define_label(mercury__vn_order__req_order_2_11_0_i13);
	if (((Integer) r6 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i14);
	if (((Integer) r10 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i14);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_order__req_order_2_11_0_i14);
	if ((tag((Integer) r9) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i18);
	if (((Integer) field(mktag(3), (Integer) r9, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i18);
	r8 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) r6;
	r6 = (Integer) r7;
	r7 = (Integer) r2;
	r2 = (Integer) r10;
	r15 = (Integer) r9;
	tag_incr_hp(r9, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r15, ((Integer) 1));
	GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i21);
Define_label(mercury__vn_order__req_order_2_11_0_i18);
	r9 = (Integer) r8;
	r8 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) r6;
	r6 = (Integer) r7;
	r7 = (Integer) r2;
	r2 = (Integer) r10;
Define_label(mercury__vn_order__req_order_2_11_0_i21);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__vn_order__req_order_2_11_0_i22,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_order__req_order_2_11_0_i23,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	if (((Integer) detstackvar(1) <= ((Integer) 0)))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i1030);
	detstackvar(9) = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) detstackvar(1) - ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__req_order_2_11_0_i26,
		STATIC(mercury__vn_order__req_order_2_11_0));
Define_label(mercury__vn_order__req_order_2_11_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	r8 = (Integer) r1;
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i39);
Define_label(mercury__vn_order__req_order_2_11_0_i1030);
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	detstackvar(9) = (Integer) r1;
	detstackvar(12) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__req_order_2_11_0_i29,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i28);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(12);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i32);
Define_label(mercury__vn_order__req_order_2_11_0_i28);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(12);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__req_order_2_11_0_i31,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(12);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(9);
Define_label(mercury__vn_order__req_order_2_11_0_i32);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(8) = (Integer) r3;
	detstackvar(4) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(12) = (Integer) r4;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__req_order_2_11_0_i35,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i34);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i39);
Define_label(mercury__vn_order__req_order_2_11_0_i34);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(12);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__req_order_2_11_0_i37,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i37);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(10);
Define_label(mercury__vn_order__req_order_2_11_0_i39);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(11) = (Integer) r9;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__vn_order__req_order_2_11_0_i1033,
		STATIC(mercury__vn_order__req_order_2_11_0));
	}
Define_label(mercury__vn_order__req_order_2_11_0_i1033);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__vn_order__record_ctrl_deps_7_0),
		mercury__vn_order__req_order_2_11_0_i43,
		STATIC(mercury__vn_order__req_order_2_11_0));
Define_label(mercury__vn_order__req_order_2_11_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_order__req_order_2_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__req_order_2_11_0_i41);
	r7 = (Integer) r2;
	r8 = (Integer) r3;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	localtailcall(mercury__vn_order__req_order_2_11_0,
		STATIC(mercury__vn_order__req_order_2_11_0));
Define_label(mercury__vn_order__req_order_2_11_0_i41);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_order__common_2);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_order__req_order_2_11_0_i3);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module2)
	init_entry(mercury__vn_order__record_ctrl_deps_7_0);
	init_label(mercury__vn_order__record_ctrl_deps_7_0_i1001);
	init_label(mercury__vn_order__record_ctrl_deps_7_0_i4);
	init_label(mercury__vn_order__record_ctrl_deps_7_0_i5);
	init_label(mercury__vn_order__record_ctrl_deps_7_0_i6);
	init_label(mercury__vn_order__record_ctrl_deps_7_0_i1);
	init_label(mercury__vn_order__record_ctrl_deps_7_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_order__record_ctrl_deps'/7 in mode 0 */
Define_static(mercury__vn_order__record_ctrl_deps_7_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__record_ctrl_deps_7_0_i1001);
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_order__record_ctrl_deps_7_0_i1001);
	incr_sp_push_msg(8, "vn_order__record_ctrl_deps");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) r1;
	r2 = string_const("vn_order__record_ctrl_deps", 26);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_order__record_ctrl_deps_7_0_i4,
		STATIC(mercury__vn_order__record_ctrl_deps_7_0));
	}
	}
Define_label(mercury__vn_order__record_ctrl_deps_7_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__record_ctrl_deps_7_0));
	if (((Integer) detstackvar(6) != (Integer) r1))
		GOTO_LABEL(mercury__vn_order__record_ctrl_deps_7_0_i1);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__record_ctrl_deps_7_0_i5,
		STATIC(mercury__vn_order__record_ctrl_deps_7_0));
Define_label(mercury__vn_order__record_ctrl_deps_7_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_order__record_ctrl_deps_7_0));
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__vn_order__record_ctrl_deps_7_0,
		LABEL(mercury__vn_order__record_ctrl_deps_7_0_i6),
		STATIC(mercury__vn_order__record_ctrl_deps_7_0));
Define_label(mercury__vn_order__record_ctrl_deps_7_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_order__record_ctrl_deps_7_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__record_ctrl_deps_7_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_order__record_ctrl_deps_7_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_order__record_ctrl_deps_7_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module3)
	init_entry(mercury__vn_order__prod_cons_order_7_0);
	init_label(mercury__vn_order__prod_cons_order_7_0_i4);
	init_label(mercury__vn_order__prod_cons_order_7_0_i5);
	init_label(mercury__vn_order__prod_cons_order_7_0_i6);
	init_label(mercury__vn_order__prod_cons_order_7_0_i8);
	init_label(mercury__vn_order__prod_cons_order_7_0_i1003);
BEGIN_CODE

/* code for predicate 'vn_order__prod_cons_order'/7 in mode 0 */
Define_static(mercury__vn_order__prod_cons_order_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__prod_cons_order_7_0_i1003);
	incr_sp_push_msg(7, "vn_order__prod_cons_order");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r2 = string_const("vn_order__prod_cons_order", 25);
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_order__prod_cons_order_7_0_i4,
		STATIC(mercury__vn_order__prod_cons_order_7_0));
	}
Define_label(mercury__vn_order__prod_cons_order_7_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__prod_cons_order_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("vn_order__prod_cons_order", 25);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__lookup_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_value_4_0),
		mercury__vn_order__prod_cons_order_7_0_i5,
		STATIC(mercury__vn_order__prod_cons_order_7_0));
	}
Define_label(mercury__vn_order__prod_cons_order_7_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_order__prod_cons_order_7_0));
	if (((Integer) r1 != (Integer) detstackvar(6)))
		GOTO_LABEL(mercury__vn_order__prod_cons_order_7_0_i6);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__vn_order__prod_cons_order_7_0,
		STATIC(mercury__vn_order__prod_cons_order_7_0));
Define_label(mercury__vn_order__prod_cons_order_7_0_i6);
	r1 = (Integer) detstackvar(6);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_order__find_links_8_0),
		mercury__vn_order__prod_cons_order_7_0_i8,
		STATIC(mercury__vn_order__prod_cons_order_7_0));
Define_label(mercury__vn_order__prod_cons_order_7_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__prod_cons_order_7_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__vn_order__prod_cons_order_7_0,
		STATIC(mercury__vn_order__prod_cons_order_7_0));
Define_label(mercury__vn_order__prod_cons_order_7_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module4)
	init_entry(mercury__vn_order__ctrl_vn_order_9_0);
	init_label(mercury__vn_order__ctrl_vn_order_9_0_i2);
BEGIN_CODE

/* code for predicate 'vn_order__ctrl_vn_order'/9 in mode 0 */
Define_static(mercury__vn_order__ctrl_vn_order_9_0);
	incr_sp_push_msg(6, "vn_order__ctrl_vn_order");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__vn_order__ctrl_vn_order_9_0_i2,
		STATIC(mercury__vn_order__ctrl_vn_order_9_0));
	}
Define_label(mercury__vn_order__ctrl_vn_order_9_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_order__ctrl_vn_order_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r8 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__vn_order__ctrl_vn_order_2_12_0),
		STATIC(mercury__vn_order__ctrl_vn_order_9_0));
END_MODULE

BEGIN_MODULE(mercury__vn_order_module5)
	init_entry(mercury__vn_order__ctrl_vn_order_2_12_0);
	init_label(mercury__vn_order__ctrl_vn_order_2_12_0_i4);
	init_label(mercury__vn_order__ctrl_vn_order_2_12_0_i6);
	init_label(mercury__vn_order__ctrl_vn_order_2_12_0_i7);
	init_label(mercury__vn_order__ctrl_vn_order_2_12_0_i8);
	init_label(mercury__vn_order__ctrl_vn_order_2_12_0_i9);
	init_label(mercury__vn_order__ctrl_vn_order_2_12_0_i3);
BEGIN_CODE

/* code for predicate 'vn_order__ctrl_vn_order_2'/12 in mode 0 */
Define_static(mercury__vn_order__ctrl_vn_order_2_12_0);
	incr_sp_push_msg(9, "vn_order__ctrl_vn_order_2");
	detstackvar(9) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_1);
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__ctrl_vn_order_2_12_0_i4,
		STATIC(mercury__vn_order__ctrl_vn_order_2_12_0));
	}
Define_label(mercury__vn_order__ctrl_vn_order_2_12_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__ctrl_vn_order_2_12_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__ctrl_vn_order_2_12_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__vn_order__ctrl_vn_order_2_12_0_i6,
		STATIC(mercury__vn_order__ctrl_vn_order_2_12_0));
	}
Define_label(mercury__vn_order__ctrl_vn_order_2_12_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_order__ctrl_vn_order_2_12_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_order__append_vnlval_nodes_3_0),
		mercury__vn_order__ctrl_vn_order_2_12_0_i7,
		STATIC(mercury__vn_order__ctrl_vn_order_2_12_0));
Define_label(mercury__vn_order__ctrl_vn_order_2_12_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_order__ctrl_vn_order_2_12_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__atsort__closure_3_0);
	call_localret(ENTRY(mercury__atsort__closure_3_0),
		mercury__vn_order__ctrl_vn_order_2_12_0_i8,
		STATIC(mercury__vn_order__ctrl_vn_order_2_12_0));
	}
Define_label(mercury__vn_order__ctrl_vn_order_2_12_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__ctrl_vn_order_2_12_0));
	tag_incr_hp(r3, mktag(3), ((Integer) 1));
	r2 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_order__record_antideps_11_0),
		mercury__vn_order__ctrl_vn_order_2_12_0_i9,
		STATIC(mercury__vn_order__ctrl_vn_order_2_12_0));
Define_label(mercury__vn_order__ctrl_vn_order_2_12_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__ctrl_vn_order_2_12_0));
	r5 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r7 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	r8 = (Integer) r4;
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__vn_order__ctrl_vn_order_2_12_0,
		STATIC(mercury__vn_order__ctrl_vn_order_2_12_0));
Define_label(mercury__vn_order__ctrl_vn_order_2_12_0_i3);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module6)
	init_entry(mercury__vn_order__append_vnlval_nodes_3_0);
	init_label(mercury__vn_order__append_vnlval_nodes_3_0_i3);
	init_label(mercury__vn_order__append_vnlval_nodes_3_0_i1);
BEGIN_CODE

/* code for predicate 'vn_order__append_vnlval_nodes'/3 in mode 0 */
Define_static(mercury__vn_order__append_vnlval_nodes_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__append_vnlval_nodes_3_0_i1);
Define_label(mercury__vn_order__append_vnlval_nodes_3_0_i3);
	r3 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__append_vnlval_nodes_3_0_i3);
	}
Define_label(mercury__vn_order__append_vnlval_nodes_3_0_i1);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module7)
	init_entry(mercury__vn_order__record_antideps_11_0);
	init_label(mercury__vn_order__record_antideps_11_0_i1009);
	init_label(mercury__vn_order__record_antideps_11_0_i6);
	init_label(mercury__vn_order__record_antideps_11_0_i11);
	init_label(mercury__vn_order__record_antideps_11_0_i13);
	init_label(mercury__vn_order__record_antideps_11_0_i14);
	init_label(mercury__vn_order__record_antideps_11_0_i5);
	init_label(mercury__vn_order__record_antideps_11_0_i4);
	init_label(mercury__vn_order__record_antideps_11_0_i1006);
BEGIN_CODE

/* code for predicate 'vn_order__record_antideps'/11 in mode 0 */
Define_static(mercury__vn_order__record_antideps_11_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__record_antideps_11_0_i1006);
	r8 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__record_antideps_11_0_i1009);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	incr_sp_push_msg(10, "vn_order__record_antideps");
	detstackvar(10) = (Integer) succip;
	GOTO_LABEL(mercury__vn_order__record_antideps_11_0_i6);
	}
Define_label(mercury__vn_order__record_antideps_11_0_i1009);
	incr_sp_push_msg(10, "vn_order__record_antideps");
	detstackvar(10) = (Integer) succip;
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__record_antideps_11_0_i4);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	}
Define_label(mercury__vn_order__record_antideps_11_0_i6);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r8;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_order__record_antideps_11_0_i11,
		STATIC(mercury__vn_order__record_antideps_11_0));
	}
Define_label(mercury__vn_order__record_antideps_11_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__record_antideps_11_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_order__record_antideps_11_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__vn_debug__order_antidep_msg_4_0);
	call_localret(ENTRY(mercury__vn_debug__order_antidep_msg_4_0),
		mercury__vn_order__record_antideps_11_0_i13,
		STATIC(mercury__vn_order__record_antideps_11_0));
	}
Define_label(mercury__vn_order__record_antideps_11_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__record_antideps_11_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__record_antideps_11_0_i14,
		STATIC(mercury__vn_order__record_antideps_11_0));
Define_label(mercury__vn_order__record_antideps_11_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_order__record_antideps_11_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	r7 = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__vn_order__record_antideps_11_0,
		STATIC(mercury__vn_order__record_antideps_11_0));
	}
Define_label(mercury__vn_order__record_antideps_11_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(8);
Define_label(mercury__vn_order__record_antideps_11_0_i4);
	r1 = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__vn_order__record_antideps_11_0,
		STATIC(mercury__vn_order__record_antideps_11_0));
Define_label(mercury__vn_order__record_antideps_11_0_i1006);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	r3 = (Integer) r6;
	r4 = (Integer) r7;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module8)
	init_entry(mercury__vn_order__add_computed_links_5_0);
	init_label(mercury__vn_order__add_computed_links_5_0_i4);
	init_label(mercury__vn_order__add_computed_links_5_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_order__add_computed_links'/5 in mode 0 */
Define_static(mercury__vn_order__add_computed_links_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__add_computed_links_5_0_i1002);
	incr_sp_push_msg(2, "vn_order__add_computed_links");
	detstackvar(2) = (Integer) succip;
	r4 = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__add_computed_links_5_0_i4,
		STATIC(mercury__vn_order__add_computed_links_5_0));
	}
Define_label(mercury__vn_order__add_computed_links_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__add_computed_links_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__vn_order__add_computed_links_5_0,
		STATIC(mercury__vn_order__add_computed_links_5_0));
Define_label(mercury__vn_order__add_computed_links_5_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module9)
	init_entry(mercury__vn_order__vn_ctrl_order_8_0);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i4);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i9);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i12);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i13);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i14);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i16);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i1009);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i19);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i21);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i1011);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i24);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i8);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i28);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i29);
	init_label(mercury__vn_order__vn_ctrl_order_8_0_i3);
BEGIN_CODE

/* code for predicate 'vn_order__vn_ctrl_order'/8 in mode 0 */
Define_static(mercury__vn_order__vn_ctrl_order_8_0);
	incr_sp_push_msg(6, "vn_order__vn_ctrl_order");
	detstackvar(6) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_instr_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	}
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__vn_ctrl_order_8_0_i4,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
	}
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__vn_ctrl_order_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__vn_ctrl_order_8_0_i3);
	r1 = tag((Integer) r2);
	if (((Integer) r1 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__vn_ctrl_order_8_0_i8);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)),
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i9) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i9) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i9) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i12) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i14) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i16) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i19) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i21) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i24) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i9) AND
		LABEL(mercury__vn_order__vn_ctrl_order_8_0_i9));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i9);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__vn_order__vn_ctrl_order_8_0,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i12);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_links_8_0),
		mercury__vn_order__vn_ctrl_order_8_0_i13,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__vn_ctrl_order_8_0));
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r5 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__vn_order__vn_ctrl_order_8_0,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_links_8_0),
		mercury__vn_order__vn_ctrl_order_8_0_i13,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i16);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_order__vn_ctrl_order_8_0_i1009,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
	}
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i1009);
	update_prof_current_proc(LABEL(mercury__vn_order__vn_ctrl_order_8_0));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_all_links_8_0),
		mercury__vn_order__vn_ctrl_order_8_0_i13,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i19);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_links_8_0),
		mercury__vn_order__vn_ctrl_order_8_0_i13,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i21);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_order__vn_ctrl_order_8_0_i1011,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
	}
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i1011);
	update_prof_current_proc(LABEL(mercury__vn_order__vn_ctrl_order_8_0));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_all_links_8_0),
		mercury__vn_order__vn_ctrl_order_8_0_i13,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i24);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_links_8_0),
		mercury__vn_order__vn_ctrl_order_8_0_i13,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i8);
	if (((Integer) r1 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__vn_ctrl_order_8_0_i28);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__vn_order__vn_ctrl_order_8_0,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i28);
	if (((Integer) r1 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__vn_ctrl_order_8_0_i29);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__vn_order__vn_ctrl_order_8_0,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i29);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__vn_order__vn_ctrl_order_8_0,
		STATIC(mercury__vn_order__vn_ctrl_order_8_0));
Define_label(mercury__vn_order__vn_ctrl_order_8_0_i3);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module10)
	init_entry(mercury__vn_order__use_sinks_before_redef_9_0);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i4);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i8);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i10);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i14);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i13);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i16);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i17);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i18);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i19);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i20);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i23);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i25);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i27);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i22);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i6);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i5);
	init_label(mercury__vn_order__use_sinks_before_redef_9_0_i1010);
BEGIN_CODE

/* code for predicate 'vn_order__use_sinks_before_redef'/9 in mode 0 */
Define_static(mercury__vn_order__use_sinks_before_redef_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i1010);
	incr_sp_push_msg(15, "vn_order__use_sinks_before_redef");
	detstackvar(15) = (Integer) succip;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) r6;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__vn_debug__order_sink_msg_3_0);
	call_localret(ENTRY(mercury__vn_debug__order_sink_msg_3_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i4,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i5);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(5), ((Integer) 0));
	detstackvar(7) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i8,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i6);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i10,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i6);
	if (((Integer) detstackvar(8) == (Integer) r2))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i6);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__use_sinks_before_redef_9_0_i14,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i13);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(8);
	r10 = (Integer) r2;
	r11 = (Integer) detstackvar(12);
	r2 = string_const("vn_order__use_sink_before_redef", 31);
	GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i16);
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i13);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(8);
	r10 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r11 = (Integer) detstackvar(12);
	r2 = string_const("vn_order__use_sink_before_redef", 31);
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i16);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(12) = (Integer) r11;
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i17,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_order__find_access_users_4_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i18,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_order__use_sinks_before_redef_9_0_i19,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	detstackvar(9) = (Integer) r1;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__vn_order__add_users_11_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i20,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	detstackvar(13) = (Integer) r3;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i23,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i22);
	tag_incr_hp(detstackvar(14), mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) detstackvar(14), ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__use_sinks_before_redef_9_0_i25,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
	}
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__use_sinks_before_redef_9_0_i22);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(14);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__vn_order__add_users_11_0),
		mercury__vn_order__use_sinks_before_redef_9_0_i27,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_order__use_sinks_before_redef_9_0));
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r6 = (Integer) r3;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	localtailcall(mercury__vn_order__use_sinks_before_redef_9_0,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i22);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	localtailcall(mercury__vn_order__use_sinks_before_redef_9_0,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i6);
	r1 = (Integer) detstackvar(12);
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i5);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	localtailcall(mercury__vn_order__use_sinks_before_redef_9_0,
		STATIC(mercury__vn_order__use_sinks_before_redef_9_0));
Define_label(mercury__vn_order__use_sinks_before_redef_9_0_i1010);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	r3 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module11)
	init_entry(mercury__vn_order__find_access_users_4_0);
	init_label(mercury__vn_order__find_access_users_4_0_i4);
	init_label(mercury__vn_order__find_access_users_4_0_i11);
	init_label(mercury__vn_order__find_access_users_4_0_i10);
	init_label(mercury__vn_order__find_access_users_4_0_i13);
	init_label(mercury__vn_order__find_access_users_4_0_i16);
	init_label(mercury__vn_order__find_access_users_4_0_i17);
	init_label(mercury__vn_order__find_access_users_4_0_i18);
	init_label(mercury__vn_order__find_access_users_4_0_i1026);
	init_label(mercury__vn_order__find_access_users_4_0_i5);
	init_label(mercury__vn_order__find_access_users_4_0_i1014);
BEGIN_CODE

/* code for predicate 'vn_order__find_access_users'/4 in mode 0 */
Define_static(mercury__vn_order__find_access_users_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i1014);
	incr_sp_push_msg(7, "vn_order__find_access_users");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__find_access_users_4_0,
		LABEL(mercury__vn_order__find_access_users_4_0_i4),
		STATIC(mercury__vn_order__find_access_users_4_0));
Define_label(mercury__vn_order__find_access_users_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__find_access_users_4_0));
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i5);
	if ((tag((Integer) field(mktag(2), (Integer) detstackvar(3), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i5);
	if (((Integer) field(mktag(3), (Integer) field(mktag(2), (Integer) detstackvar(3), ((Integer) 0)), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i5);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(2), (Integer) detstackvar(3), ((Integer) 0));
	tag_incr_hp(r4, mktag(2), ((Integer) 1));
	detstackvar(4) = (Integer) tempr1;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__find_access_users_4_0_i11,
		STATIC(mercury__vn_order__find_access_users_4_0));
	}
	}
Define_label(mercury__vn_order__find_access_users_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__find_access_users_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i10);
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i13);
Define_label(mercury__vn_order__find_access_users_4_0_i10);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(4);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__vn_order__find_access_users_4_0_i13);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r5;
	r2 = string_const("vn_order__find_access_users", 27);
	{
	Declare_entry(mercury__vn_table__lookup_current_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_current_value_4_0),
		mercury__vn_order__find_access_users_4_0_i16,
		STATIC(mercury__vn_order__find_access_users_4_0));
	}
Define_label(mercury__vn_order__find_access_users_4_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_order__find_access_users_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("vn_order__find_access_users", 27);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_order__find_access_users_4_0_i17,
		STATIC(mercury__vn_order__find_access_users_4_0));
	}
Define_label(mercury__vn_order__find_access_users_4_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_order__find_access_users_4_0));
	if (((Integer) r1 == (Integer) detstackvar(6)))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i1026);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__find_access_users_4_0_i18,
		STATIC(mercury__vn_order__find_access_users_4_0));
	}
Define_label(mercury__vn_order__find_access_users_4_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_order__find_access_users_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__find_access_users_4_0_i1026);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__list__condense_2_0);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__vn_order__find_access_users_4_0));
	}
	}
Define_label(mercury__vn_order__find_access_users_4_0_i1026);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_order__common_3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__list__condense_2_0);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__vn_order__find_access_users_4_0));
	}
Define_label(mercury__vn_order__find_access_users_4_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__vn_order__find_access_users_4_0_i1014);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module12)
	init_entry(mercury__vn_order__add_users_11_0);
	init_label(mercury__vn_order__add_users_11_0_i8);
	init_label(mercury__vn_order__add_users_11_0_i7);
	init_label(mercury__vn_order__add_users_11_0_i10);
	init_label(mercury__vn_order__add_users_11_0_i5);
	init_label(mercury__vn_order__add_users_11_0_i4);
	init_label(mercury__vn_order__add_users_11_0_i12);
	init_label(mercury__vn_order__add_users_11_0_i13);
	init_label(mercury__vn_order__add_users_11_0_i17);
	init_label(mercury__vn_order__add_users_11_0_i18);
	init_label(mercury__vn_order__add_users_11_0_i14);
	init_label(mercury__vn_order__add_users_11_0_i1007);
BEGIN_CODE

/* code for predicate 'vn_order__add_users'/11 in mode 0 */
Define_static(mercury__vn_order__add_users_11_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__add_users_11_0_i1007);
	r9 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r10 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(11, "vn_order__add_users");
	detstackvar(11) = (Integer) succip;
	if ((tag((Integer) r10) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__add_users_11_0_i7);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r10, ((Integer) 0));
	r1 = (Integer) r3;
	r2 = string_const("vn_order__add_user", 18);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_order__add_users_11_0_i8,
		STATIC(mercury__vn_order__add_users_11_0));
	}
Define_label(mercury__vn_order__add_users_11_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__add_users_11_0));
	if (((Integer) detstackvar(10) != (Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_users_11_0_i5);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_order__add_users_11_0,
		STATIC(mercury__vn_order__add_users_11_0));
Define_label(mercury__vn_order__add_users_11_0_i7);
	if ((tag((Integer) r10) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__add_users_11_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r9;
	r1 = (Integer) r3;
	r2 = (Integer) field(mktag(1), (Integer) r10, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___vn_type__vnlval_0_0);
	call_localret(ENTRY(mercury____Unify___vn_type__vnlval_0_0),
		mercury__vn_order__add_users_11_0_i10,
		STATIC(mercury__vn_order__add_users_11_0));
	}
Define_label(mercury__vn_order__add_users_11_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_order__add_users_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_users_11_0_i5);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_order__add_users_11_0,
		STATIC(mercury__vn_order__add_users_11_0));
Define_label(mercury__vn_order__add_users_11_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
Define_label(mercury__vn_order__add_users_11_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r9;
	r1 = (Integer) r10;
	r3 = ((Integer) 0);
	r4 = (Integer) r8;
	{
	Declare_entry(mercury__vn_debug__order_link_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__order_link_msg_5_0),
		mercury__vn_order__add_users_11_0_i12,
		STATIC(mercury__vn_order__add_users_11_0));
	}
Define_label(mercury__vn_order__add_users_11_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__add_users_11_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__add_users_11_0_i13,
		STATIC(mercury__vn_order__add_users_11_0));
Define_label(mercury__vn_order__add_users_11_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__add_users_11_0));
	if ((tag((Integer) detstackvar(8)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__add_users_11_0_i14);
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) detstackvar(8), ((Integer) 0));
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
	call_localret(ENTRY(mercury__vn_table__get_vnlval_vn_list_2_0),
		mercury__vn_order__add_users_11_0_i17,
		STATIC(mercury__vn_order__add_users_11_0));
	}
Define_label(mercury__vn_order__add_users_11_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_order__add_users_11_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__vn_order__add_aliases_10_0),
		mercury__vn_order__add_users_11_0_i18,
		STATIC(mercury__vn_order__add_users_11_0));
Define_label(mercury__vn_order__add_users_11_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_order__add_users_11_0));
	r6 = (Integer) r1;
	r7 = (Integer) r2;
	r8 = (Integer) r3;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_order__add_users_11_0,
		STATIC(mercury__vn_order__add_users_11_0));
Define_label(mercury__vn_order__add_users_11_0_i14);
	r6 = (Integer) r1;
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__vn_order__add_users_11_0,
		STATIC(mercury__vn_order__add_users_11_0));
Define_label(mercury__vn_order__add_users_11_0_i1007);
	r1 = (Integer) r6;
	r2 = (Integer) r7;
	r3 = (Integer) r8;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module13)
	init_entry(mercury__vn_order__add_aliases_10_0);
	init_label(mercury__vn_order__add_aliases_10_0_i6);
	init_label(mercury__vn_order__add_aliases_10_0_i8);
	init_label(mercury__vn_order__add_aliases_10_0_i9);
	init_label(mercury__vn_order__add_aliases_10_0_i5);
	init_label(mercury__vn_order__add_aliases_10_0_i4);
	init_label(mercury__vn_order__add_aliases_10_0_i1004);
	init_label(mercury__vn_order__add_aliases_10_0_i1006);
BEGIN_CODE

/* code for predicate 'vn_order__add_aliases'/10 in mode 0 */
Define_static(mercury__vn_order__add_aliases_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__add_aliases_10_0_i1004);
	r8 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)) != (Integer) r2))
		GOTO_LABEL(mercury__vn_order__add_aliases_10_0_i1006);
	incr_sp_push_msg(9, "vn_order__add_aliases");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r3 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_order__add_aliases_10_0_i6,
		STATIC(mercury__vn_order__add_aliases_10_0));
	}
Define_label(mercury__vn_order__add_aliases_10_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_order__add_aliases_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_aliases_10_0_i5);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__vn_debug__order_link_msg_5_0);
	call_localret(ENTRY(mercury__vn_debug__order_link_msg_5_0),
		mercury__vn_order__add_aliases_10_0_i8,
		STATIC(mercury__vn_order__add_aliases_10_0));
	}
Define_label(mercury__vn_order__add_aliases_10_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__add_aliases_10_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__add_aliases_10_0_i9,
		STATIC(mercury__vn_order__add_aliases_10_0));
Define_label(mercury__vn_order__add_aliases_10_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__add_aliases_10_0));
	r5 = (Integer) r1;
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__vn_order__add_aliases_10_0,
		STATIC(mercury__vn_order__add_aliases_10_0));
Define_label(mercury__vn_order__add_aliases_10_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
Define_label(mercury__vn_order__add_aliases_10_0_i4);
	r1 = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__vn_order__add_aliases_10_0,
		STATIC(mercury__vn_order__add_aliases_10_0));
Define_label(mercury__vn_order__add_aliases_10_0_i1004);
	r1 = (Integer) r5;
	r2 = (Integer) r6;
	r3 = (Integer) r7;
	proceed();
Define_label(mercury__vn_order__add_aliases_10_0_i1006);
	r1 = (Integer) r8;
	localtailcall(mercury__vn_order__add_aliases_10_0,
		STATIC(mercury__vn_order__add_aliases_10_0));
END_MODULE

BEGIN_MODULE(mercury__vn_order_module14)
	init_entry(mercury__vn_order__find_links_8_0);
	init_label(mercury__vn_order__find_links_8_0_i2);
	init_label(mercury__vn_order__find_links_8_0_i3);
	init_label(mercury__vn_order__find_links_8_0_i6);
	init_label(mercury__vn_order__find_links_8_0_i11);
	init_label(mercury__vn_order__find_links_8_0_i5);
	init_label(mercury__vn_order__find_links_8_0_i16);
	init_label(mercury__vn_order__find_links_8_0_i17);
	init_label(mercury__vn_order__find_links_8_0_i19);
	init_label(mercury__vn_order__find_links_8_0_i15);
	init_label(mercury__vn_order__find_links_8_0_i22);
	init_label(mercury__vn_order__find_links_8_0_i23);
	init_label(mercury__vn_order__find_links_8_0_i24);
	init_label(mercury__vn_order__find_links_8_0_i21);
	init_label(mercury__vn_order__find_links_8_0_i25);
BEGIN_CODE

/* code for predicate 'vn_order__find_links'/8 in mode 0 */
Define_static(mercury__vn_order__find_links_8_0);
	incr_sp_push_msg(8, "vn_order__find_links");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	r2 = string_const("vn_order__find_links", 20);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_order__find_links_8_0_i2,
		STATIC(mercury__vn_order__find_links_8_0));
	}
Define_label(mercury__vn_order__find_links_8_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_order__find_links", 20);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_order__find_links_8_0_i3,
		STATIC(mercury__vn_order__find_links_8_0));
	}
Define_label(mercury__vn_order__find_links_8_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	r3 = (Integer) detstackvar(6);
	r2 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_util__is_vn_shared_4_0);
	call_localret(ENTRY(mercury__vn_util__is_vn_shared_4_0),
		mercury__vn_order__find_links_8_0_i6,
		STATIC(mercury__vn_order__find_links_8_0));
	}
Define_label(mercury__vn_order__find_links_8_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i5);
	if ((tag((Integer) detstackvar(2)) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i5);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__find_links_8_0_i11,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	r4 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__vn_order__find_links_8_0,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i15);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_order__find_links_8_0_i16);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i17);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__vn_order__find_links_8_0,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i17);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	localcall(mercury__vn_order__find_links_8_0,
		LABEL(mercury__vn_order__find_links_8_0_i19),
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	r5 = (Integer) r3;
	r3 = (Integer) r1;
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__vn_order__find_links_8_0,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i15);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i21);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_order__find_links_8_0_i22,
		STATIC(mercury__vn_order__find_links_8_0));
	}
Define_label(mercury__vn_order__find_links_8_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__vn_order__find_all_links_8_0),
		mercury__vn_order__find_links_8_0_i23,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	r4 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_order__add_link_6_0),
		mercury__vn_order__find_links_8_0_i24,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_order__find_links_8_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_order__find_links_8_0_i21);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__find_links_8_0_i25);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__vn_order__find_links_8_0,
		STATIC(mercury__vn_order__find_links_8_0));
Define_label(mercury__vn_order__find_links_8_0_i25);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module15)
	init_entry(mercury__vn_order__find_all_links_8_0);
	init_label(mercury__vn_order__find_all_links_8_0_i4);
	init_label(mercury__vn_order__find_all_links_8_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_order__find_all_links'/8 in mode 0 */
Define_static(mercury__vn_order__find_all_links_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_all_links_8_0_i1002);
	incr_sp_push_msg(3, "vn_order__find_all_links");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__vn_order__find_links_8_0),
		mercury__vn_order__find_all_links_8_0_i4,
		STATIC(mercury__vn_order__find_all_links_8_0));
Define_label(mercury__vn_order__find_all_links_8_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__find_all_links_8_0));
	r5 = (Integer) r3;
	r3 = (Integer) r1;
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_order__find_all_links_8_0,
		STATIC(mercury__vn_order__find_all_links_8_0));
Define_label(mercury__vn_order__find_all_links_8_0_i1002);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module16)
	init_entry(mercury__vn_order__add_link_6_0);
	init_label(mercury__vn_order__add_link_6_0_i4);
	init_label(mercury__vn_order__add_link_6_0_i3);
	init_label(mercury__vn_order__add_link_6_0_i8);
	init_label(mercury__vn_order__add_link_6_0_i12);
	init_label(mercury__vn_order__add_link_6_0_i11);
	init_label(mercury__vn_order__add_link_6_0_i14);
	init_label(mercury__vn_order__add_link_6_0_i15);
	init_label(mercury__vn_order__add_link_6_0_i7);
	init_label(mercury__vn_order__add_link_6_0_i16);
	init_label(mercury__vn_order__add_link_6_0_i17);
	init_label(mercury__vn_order__add_link_6_0_i20);
	init_label(mercury__vn_order__add_link_6_0_i19);
	init_label(mercury__vn_order__add_link_6_0_i22);
	init_label(mercury__vn_order__add_link_6_0_i23);
	init_label(mercury__vn_order__add_link_6_0_i26);
	init_label(mercury__vn_order__add_link_6_0_i30);
	init_label(mercury__vn_order__add_link_6_0_i29);
	init_label(mercury__vn_order__add_link_6_0_i32);
	init_label(mercury__vn_order__add_link_6_0_i33);
	init_label(mercury__vn_order__add_link_6_0_i25);
	init_label(mercury__vn_order__add_link_6_0_i34);
	init_label(mercury__vn_order__add_link_6_0_i35);
	init_label(mercury__vn_order__add_link_6_0_i38);
	init_label(mercury__vn_order__add_link_6_0_i37);
	init_label(mercury__vn_order__add_link_6_0_i40);
BEGIN_CODE

/* code for predicate 'vn_order__add_link'/6 in mode 0 */
Define_static(mercury__vn_order__add_link_6_0);
	incr_sp_push_msg(10, "vn_order__add_link");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury____Unify___vn_type__vn_node_0_0);
	call_localret(ENTRY(mercury____Unify___vn_type__vn_node_0_0),
		mercury__vn_order__add_link_6_0_i4,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i3);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_order__add_link_6_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__add_link_6_0_i8,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i7);
	r3 = (Integer) r2;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_order__add_link_6_0_i12,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i11);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	GOTO_LABEL(mercury__vn_order__add_link_6_0_i14);
Define_label(mercury__vn_order__add_link_6_0_i11);
	r4 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(6);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
Define_label(mercury__vn_order__add_link_6_0_i14);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__add_link_6_0_i15,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__vn_order__add_link_6_0_i17);
Define_label(mercury__vn_order__add_link_6_0_i7);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__add_link_6_0_i16,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
Define_label(mercury__vn_order__add_link_6_0_i17);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(5) = (Integer) r2;
	detstackvar(7) = (Integer) r5;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__add_link_6_0_i20,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__vn_order__add_link_6_0_i23);
Define_label(mercury__vn_order__add_link_6_0_i19);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__add_link_6_0_i22,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
Define_label(mercury__vn_order__add_link_6_0_i23);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__add_link_6_0_i26,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i25);
	r3 = (Integer) r2;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_order__add_link_6_0_i30,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i29);
	r6 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(8);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	GOTO_LABEL(mercury__vn_order__add_link_6_0_i32);
Define_label(mercury__vn_order__add_link_6_0_i29);
	r6 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(8);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
Define_label(mercury__vn_order__add_link_6_0_i32);
	detstackvar(1) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r3;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__add_link_6_0_i33,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	r4 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__vn_order__add_link_6_0_i35);
Define_label(mercury__vn_order__add_link_6_0_i25);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__add_link_6_0_i34,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	r4 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
Define_label(mercury__vn_order__add_link_6_0_i35);
	detstackvar(1) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_order__add_link_6_0_i38,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__add_link_6_0_i37);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_order__add_link_6_0_i37);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_order__add_link_6_0_i40,
		STATIC(mercury__vn_order__add_link_6_0));
	}
Define_label(mercury__vn_order__add_link_6_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_order__add_link_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module17)
	init_entry(mercury__vn_order__pref_order_2_0);
	init_label(mercury__vn_order__pref_order_2_0_i2);
	init_label(mercury__vn_order__pref_order_2_0_i3);
BEGIN_CODE

/* code for predicate 'vn_order__pref_order'/2 in mode 0 */
Define_static(mercury__vn_order__pref_order_2_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_order__common_0);
	incr_sp_push_msg(1, "vn_order__pref_order");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__vn_order__pref_order_2_0_i2,
		STATIC(mercury__vn_order__pref_order_2_0));
	}
Define_label(mercury__vn_order__pref_order_2_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_order__pref_order_2_0));
	call_localret(STATIC(mercury__vn_order__classify_nodes_5_0),
		mercury__vn_order__pref_order_2_0_i3,
		STATIC(mercury__vn_order__pref_order_2_0));
Define_label(mercury__vn_order__pref_order_2_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_order__pref_order_2_0));
	r6 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__condense_2_0);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__vn_order__pref_order_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_order_module18)
	init_entry(mercury__vn_order__classify_nodes_5_0);
	init_label(mercury__vn_order__classify_nodes_5_0_i7);
	init_label(mercury__vn_order__classify_nodes_5_0_i6);
	init_label(mercury__vn_order__classify_nodes_5_0_i9);
	init_label(mercury__vn_order__classify_nodes_5_0_i8);
	init_label(mercury__vn_order__classify_nodes_5_0_i11);
	init_label(mercury__vn_order__classify_nodes_5_0_i10);
	init_label(mercury__vn_order__classify_nodes_5_0_i12);
	init_label(mercury__vn_order__classify_nodes_5_0_i1008);
BEGIN_CODE

/* code for predicate 'vn_order__classify_nodes'/5 in mode 0 */
Define_static(mercury__vn_order__classify_nodes_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__classify_nodes_5_0_i1008);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = tag((Integer) r2);
	incr_sp_push_msg(2, "vn_order__classify_nodes");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_order__classify_nodes_5_0_i6);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__classify_nodes_5_0,
		LABEL(mercury__vn_order__classify_nodes_5_0_i7),
		STATIC(mercury__vn_order__classify_nodes_5_0));
Define_label(mercury__vn_order__classify_nodes_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_order__classify_nodes_5_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__vn_order__classify_nodes_5_0_i6);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__classify_nodes_5_0_i8);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__classify_nodes_5_0,
		LABEL(mercury__vn_order__classify_nodes_5_0_i9),
		STATIC(mercury__vn_order__classify_nodes_5_0));
Define_label(mercury__vn_order__classify_nodes_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__classify_nodes_5_0));
	r5 = (Integer) r4;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__classify_nodes_5_0_i8);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_order__classify_nodes_5_0_i10);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__classify_nodes_5_0,
		LABEL(mercury__vn_order__classify_nodes_5_0_i11),
		STATIC(mercury__vn_order__classify_nodes_5_0));
Define_label(mercury__vn_order__classify_nodes_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__classify_nodes_5_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__classify_nodes_5_0_i10);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__classify_nodes_5_0,
		LABEL(mercury__vn_order__classify_nodes_5_0_i12),
		STATIC(mercury__vn_order__classify_nodes_5_0));
Define_label(mercury__vn_order__classify_nodes_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__classify_nodes_5_0));
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__classify_nodes_5_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module19)
	init_entry(mercury__vn_order__blocks_to_order_6_0);
	init_label(mercury__vn_order__blocks_to_order_6_0_i2);
	init_label(mercury__vn_order__blocks_to_order_6_0_i3);
	init_label(mercury__vn_order__blocks_to_order_6_0_i4);
	init_label(mercury__vn_order__blocks_to_order_6_0_i5);
	init_label(mercury__vn_order__blocks_to_order_6_0_i12);
	init_label(mercury__vn_order__blocks_to_order_6_0_i9);
	init_label(mercury__vn_order__blocks_to_order_6_0_i13);
	init_label(mercury__vn_order__blocks_to_order_6_0_i14);
	init_label(mercury__vn_order__blocks_to_order_6_0_i15);
	init_label(mercury__vn_order__blocks_to_order_6_0_i16);
BEGIN_CODE

/* code for predicate 'vn_order__blocks_to_order'/6 in mode 0 */
Define_static(mercury__vn_order__blocks_to_order_6_0);
	incr_sp_push_msg(4, "vn_order__blocks_to_order");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__vn_order__order_equal_lists_5_0),
		mercury__vn_order__blocks_to_order_6_0_i2,
		STATIC(mercury__vn_order__blocks_to_order_6_0));
Define_label(mercury__vn_order__blocks_to_order_6_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_order__blocks_to_order_6_0));
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_order__blocks_to_order_6_0_i3,
		STATIC(mercury__vn_order__blocks_to_order_6_0));
	}
Define_label(mercury__vn_order__blocks_to_order_6_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_order__blocks_to_order_6_0));
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_order__find_last_ctrl_4_0),
		mercury__vn_order__blocks_to_order_6_0_i4,
		STATIC(mercury__vn_order__blocks_to_order_6_0));
Define_label(mercury__vn_order__blocks_to_order_6_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__blocks_to_order_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__blocks_to_order_6_0_i5);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__blocks_to_order_6_0_i5);
	r4 = (Integer) detstackvar(2);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	GOTO_LABEL(mercury__vn_order__blocks_to_order_6_0_i15);
Define_label(mercury__vn_order__blocks_to_order_6_0_i5);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__blocks_to_order_6_0_i9);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = string_const("last ctrl node does not exist", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_order__blocks_to_order_6_0_i12,
		STATIC(mercury__vn_order__blocks_to_order_6_0));
	}
Define_label(mercury__vn_order__blocks_to_order_6_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__blocks_to_order_6_0));
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_order__blocks_to_order_6_0_i14);
Define_label(mercury__vn_order__blocks_to_order_6_0_i9);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = string_const("last ctrl node exists in multiples", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_order__blocks_to_order_6_0_i13,
		STATIC(mercury__vn_order__blocks_to_order_6_0));
	}
Define_label(mercury__vn_order__blocks_to_order_6_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__blocks_to_order_6_0));
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
Define_label(mercury__vn_order__blocks_to_order_6_0_i14);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r4;
	r4 = (Integer) tempr1;
	}
Define_label(mercury__vn_order__blocks_to_order_6_0_i15);
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_order__blocks_to_order_6_0_i16,
		STATIC(mercury__vn_order__blocks_to_order_6_0));
	}
Define_label(mercury__vn_order__blocks_to_order_6_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_order__blocks_to_order_6_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module20)
	init_entry(mercury__vn_order__find_last_ctrl_4_0);
	init_label(mercury__vn_order__find_last_ctrl_4_0_i7);
	init_label(mercury__vn_order__find_last_ctrl_4_0_i8);
	init_label(mercury__vn_order__find_last_ctrl_4_0_i3);
	init_label(mercury__vn_order__find_last_ctrl_4_0_i6);
	init_label(mercury__vn_order__find_last_ctrl_4_0_i1);
BEGIN_CODE

/* code for predicate 'vn_order__find_last_ctrl'/4 in mode 0 */
Define_static(mercury__vn_order__find_last_ctrl_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_last_ctrl_4_0_i1);
	r4 = (Integer) sp;
Define_label(mercury__vn_order__find_last_ctrl_4_0_i7);
	while (1) {
	incr_sp_push_msg(2, "vn_order__find_last_ctrl");
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__vn_order__find_last_ctrl_4_0_i8);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__find_last_ctrl_4_0_i3);
	r3 = (Integer) field(mktag(3), (Integer) detstackvar(2), ((Integer) 0));
	if (((Integer) detstackvar(1) != (Integer) r3))
		GOTO_LABEL(mercury__vn_order__find_last_ctrl_4_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	GOTO_LABEL(mercury__vn_order__find_last_ctrl_4_0_i6);
Define_label(mercury__vn_order__find_last_ctrl_4_0_i3);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
Define_label(mercury__vn_order__find_last_ctrl_4_0_i6);
	decr_sp_pop_msg(2);
	if (((Integer) sp > (Integer) r4))
		GOTO_LABEL(mercury__vn_order__find_last_ctrl_4_0_i8);
	proceed();
Define_label(mercury__vn_order__find_last_ctrl_4_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module21)
	init_entry(mercury__vn_order__order_equal_lists_5_0);
	init_label(mercury__vn_order__order_equal_lists_5_0_i4);
	init_label(mercury__vn_order__order_equal_lists_5_0_i5);
	init_label(mercury__vn_order__order_equal_lists_5_0_i6);
	init_label(mercury__vn_order__order_equal_lists_5_0_i7);
	init_label(mercury__vn_order__order_equal_lists_5_0_i8);
	init_label(mercury__vn_order__order_equal_lists_5_0_i9);
	init_label(mercury__vn_order__order_equal_lists_5_0_i10);
	init_label(mercury__vn_order__order_equal_lists_5_0_i11);
	init_label(mercury__vn_order__order_equal_lists_5_0_i12);
	init_label(mercury__vn_order__order_equal_lists_5_0_i13);
	init_label(mercury__vn_order__order_equal_lists_5_0_i1007);
BEGIN_CODE

/* code for predicate 'vn_order__order_equal_lists'/5 in mode 0 */
Define_static(mercury__vn_order__order_equal_lists_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__order_equal_lists_5_0_i1007);
	incr_sp_push_msg(8, "vn_order__order_equal_lists");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const("\nold order: ", 12);
	{
	Declare_entry(mercury__vn_debug__order_equals_msg_4_0);
	call_localret(ENTRY(mercury__vn_debug__order_equals_msg_4_0),
		mercury__vn_order__order_equal_lists_5_0_i4,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
	}
Define_label(mercury__vn_order__order_equal_lists_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_order__find_ctrls_3_0),
		mercury__vn_order__order_equal_lists_5_0_i5,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
Define_label(mercury__vn_order__order_equal_lists_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_order__find_noops_4_0),
		mercury__vn_order__order_equal_lists_5_0_i6,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
Define_label(mercury__vn_order__order_equal_lists_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_order__find_regs_3_0),
		mercury__vn_order__order_equal_lists_5_0_i7,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
Define_label(mercury__vn_order__order_equal_lists_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_order__order_equal_lists_5_0_i8,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
	}
Define_label(mercury__vn_order__order_equal_lists_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_order__find_stackvars_3_0),
		mercury__vn_order__order_equal_lists_5_0_i9,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
Define_label(mercury__vn_order__order_equal_lists_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_order__order_equal_lists_5_0_i10,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
	}
Define_label(mercury__vn_order__order_equal_lists_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_order__order_equal_lists_5_0_i11,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
	}
Define_label(mercury__vn_order__order_equal_lists_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = string_const("new order: ", 11);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__vn_debug__order_equals_msg_4_0);
	call_localret(ENTRY(mercury__vn_debug__order_equals_msg_4_0),
		mercury__vn_order__order_equal_lists_5_0_i12,
		STATIC(mercury__vn_order__order_equal_lists_5_0));
	}
Define_label(mercury__vn_order__order_equal_lists_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__vn_order__order_equal_lists_5_0,
		LABEL(mercury__vn_order__order_equal_lists_5_0_i13),
		STATIC(mercury__vn_order__order_equal_lists_5_0));
Define_label(mercury__vn_order__order_equal_lists_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__order_equal_lists_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_order__order_equal_lists_5_0_i1007);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module22)
	init_entry(mercury__vn_order__find_ctrls_3_0);
	init_label(mercury__vn_order__find_ctrls_3_0_i7);
	init_label(mercury__vn_order__find_ctrls_3_0_i8);
	init_label(mercury__vn_order__find_ctrls_3_0_i3);
	init_label(mercury__vn_order__find_ctrls_3_0_i6);
	init_label(mercury__vn_order__find_ctrls_3_0_i1);
BEGIN_CODE

/* code for predicate 'vn_order__find_ctrls'/3 in mode 0 */
Define_static(mercury__vn_order__find_ctrls_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_ctrls_3_0_i1);
	r4 = (Integer) sp;
Define_label(mercury__vn_order__find_ctrls_3_0_i7);
	while (1) {
	incr_sp_push_msg(1, "vn_order__find_ctrls");
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__vn_order__find_ctrls_3_0_i8);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__find_ctrls_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	GOTO_LABEL(mercury__vn_order__find_ctrls_3_0_i6);
Define_label(mercury__vn_order__find_ctrls_3_0_i3);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
Define_label(mercury__vn_order__find_ctrls_3_0_i6);
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r4))
		GOTO_LABEL(mercury__vn_order__find_ctrls_3_0_i8);
	proceed();
Define_label(mercury__vn_order__find_ctrls_3_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module23)
	init_entry(mercury__vn_order__find_noops_4_0);
	init_label(mercury__vn_order__find_noops_4_0_i4);
	init_label(mercury__vn_order__find_noops_4_0_i8);
	init_label(mercury__vn_order__find_noops_4_0_i10);
	init_label(mercury__vn_order__find_noops_4_0_i6);
	init_label(mercury__vn_order__find_noops_4_0_i5);
	init_label(mercury__vn_order__find_noops_4_0_i1007);
BEGIN_CODE

/* code for predicate 'vn_order__find_noops'/4 in mode 0 */
Define_static(mercury__vn_order__find_noops_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_noops_4_0_i1007);
	incr_sp_push_msg(6, "vn_order__find_noops");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__find_noops_4_0,
		LABEL(mercury__vn_order__find_noops_4_0_i4),
		STATIC(mercury__vn_order__find_noops_4_0));
Define_label(mercury__vn_order__find_noops_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__find_noops_4_0));
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__find_noops_4_0_i5);
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_order__find_noops_4_0_i8,
		STATIC(mercury__vn_order__find_noops_4_0));
	}
Define_label(mercury__vn_order__find_noops_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_order__find_noops_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__find_noops_4_0_i6);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_order__find_noops_4_0_i10,
		STATIC(mercury__vn_order__find_noops_4_0));
	}
Define_label(mercury__vn_order__find_noops_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_order__find_noops_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__find_noops_4_0_i6);
	if (((Integer) detstackvar(1) != (Integer) r2))
		GOTO_LABEL(mercury__vn_order__find_noops_4_0_i6);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_order__find_noops_4_0_i6);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
Define_label(mercury__vn_order__find_noops_4_0_i5);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_order__find_noops_4_0_i1007);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module24)
	init_entry(mercury__vn_order__find_regs_3_0);
	init_label(mercury__vn_order__find_regs_3_0_i4);
	init_label(mercury__vn_order__find_regs_3_0_i9);
	init_label(mercury__vn_order__find_regs_3_0_i5);
	init_label(mercury__vn_order__find_regs_3_0_i3);
	init_label(mercury__vn_order__find_regs_3_0_i11);
BEGIN_CODE

/* code for predicate 'vn_order__find_regs'/3 in mode 0 */
Define_static(mercury__vn_order__find_regs_3_0);
	incr_sp_push_msg(2, "vn_order__find_regs");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_regs_3_0_i3);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__find_regs_3_0,
		LABEL(mercury__vn_order__find_regs_3_0_i4),
		STATIC(mercury__vn_order__find_regs_3_0));
Define_label(mercury__vn_order__find_regs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__find_regs_3_0));
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__find_regs_3_0_i5);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__find_regs_3_0_i5);
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_order__find_regs_3_0_i9,
		STATIC(mercury__vn_order__find_regs_3_0));
	}
Define_label(mercury__vn_order__find_regs_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__find_regs_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__find_regs_3_0_i5);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__find_regs_3_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__vn_order__find_regs_3_0_i11,
		STATIC(mercury__vn_order__find_regs_3_0));
	}
Define_label(mercury__vn_order__find_regs_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__find_regs_3_0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module25)
	init_entry(mercury__vn_order__find_stackvars_3_0);
	init_label(mercury__vn_order__find_stackvars_3_0_i4);
	init_label(mercury__vn_order__find_stackvars_3_0_i9);
	init_label(mercury__vn_order__find_stackvars_3_0_i8);
	init_label(mercury__vn_order__find_stackvars_3_0_i11);
	init_label(mercury__vn_order__find_stackvars_3_0_i5);
	init_label(mercury__vn_order__find_stackvars_3_0_i3);
	init_label(mercury__vn_order__find_stackvars_3_0_i13);
BEGIN_CODE

/* code for predicate 'vn_order__find_stackvars'/3 in mode 0 */
Define_static(mercury__vn_order__find_stackvars_3_0);
	incr_sp_push_msg(2, "vn_order__find_stackvars");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__find_stackvars_3_0_i3);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__find_stackvars_3_0,
		LABEL(mercury__vn_order__find_stackvars_3_0_i4),
		STATIC(mercury__vn_order__find_stackvars_3_0));
Define_label(mercury__vn_order__find_stackvars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__find_stackvars_3_0));
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__find_stackvars_3_0_i5);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_order__find_stackvars_3_0_i9);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__vn_order__find_stackvars_3_0_i8);
	}
Define_label(mercury__vn_order__find_stackvars_3_0_i9);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_order__find_stackvars_3_0_i5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_order__find_stackvars_3_0_i5);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) detstackvar(1);
	}
Define_label(mercury__vn_order__find_stackvars_3_0_i8);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_order__find_stackvars_3_0_i11,
		STATIC(mercury__vn_order__find_stackvars_3_0));
	}
Define_label(mercury__vn_order__find_stackvars_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_order__find_stackvars_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__find_stackvars_3_0_i5);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_order__find_stackvars_3_0_i3);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__vn_order__find_stackvars_3_0_i13,
		STATIC(mercury__vn_order__find_stackvars_3_0));
	}
Define_label(mercury__vn_order__find_stackvars_3_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__find_stackvars_3_0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module26)
	init_entry(mercury__vn_order__reorder_noops_2_4_0);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i4);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i9);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i10);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i12);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i13);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i8);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i6);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i5);
	init_label(mercury__vn_order__reorder_noops_2_4_0_i1008);
BEGIN_CODE

/* code for predicate 'vn_order__reorder_noops_2'/4 in mode 0 */
Define_static(mercury__vn_order__reorder_noops_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_order__reorder_noops_2_4_0_i1008);
	incr_sp_push_msg(6, "vn_order__reorder_noops_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_order__reorder_noops_2_4_0,
		LABEL(mercury__vn_order__reorder_noops_2_4_0_i4),
		STATIC(mercury__vn_order__reorder_noops_2_4_0));
Define_label(mercury__vn_order__reorder_noops_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_order__reorder_noops_2_4_0));
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_order__reorder_noops_2_4_0_i8);
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	r2 = string_const("vn_order__reorder_noops_2", 25);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_order__reorder_noops_2_4_0_i9,
		STATIC(mercury__vn_order__reorder_noops_2_4_0));
	}
Define_label(mercury__vn_order__reorder_noops_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_order__reorder_noops_2_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_order__reorder_noops_2_4_0_i10,
		STATIC(mercury__vn_order__reorder_noops_2_4_0));
	}
Define_label(mercury__vn_order__reorder_noops_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_order__reorder_noops_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__reorder_noops_2_4_0_i6);
	if (((Integer) detstackvar(1) != (Integer) r2))
		GOTO_LABEL(mercury__vn_order__reorder_noops_2_4_0_i6);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_order__reorder_noops_2_4_0_i12,
		STATIC(mercury__vn_order__reorder_noops_2_4_0));
	}
Define_label(mercury__vn_order__reorder_noops_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_order__reorder_noops_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_order__reorder_noops_2_4_0_i13,
		STATIC(mercury__vn_order__reorder_noops_2_4_0));
	}
Define_label(mercury__vn_order__reorder_noops_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_order__reorder_noops_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_order__reorder_noops_2_4_0_i6);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_order__reorder_noops_2_4_0_i8);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_order__reorder_noops_2_4_0_i5);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_order__reorder_noops_2_4_0_i6);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
Define_label(mercury__vn_order__reorder_noops_2_4_0_i5);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_order__reorder_noops_2_4_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module27)
	init_entry(mercury____Unify___vn_order__order_result_0_0);
	init_label(mercury____Unify___vn_order__order_result_0_0_i5);
	init_label(mercury____Unify___vn_order__order_result_0_0_i1009);
	init_label(mercury____Unify___vn_order__order_result_0_0_i1006);
	init_label(mercury____Unify___vn_order__order_result_0_0_i1);
	init_label(mercury____Unify___vn_order__order_result_0_0_i1008);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_order__order_result_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_order__order_result_0_0_i1009);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_order__order_result_0_0_i1006);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___vn_table__vn_tables_0_0);
	call_localret(ENTRY(mercury____Unify___vn_table__vn_tables_0_0),
		mercury____Unify___vn_order__order_result_0_0_i5,
		ENTRY(mercury____Unify___vn_order__order_result_0_0));
	}
Define_label(mercury____Unify___vn_order__order_result_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___vn_order__order_result_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_order__order_result_0_0_i1);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___vn_order__order_result_0_0));
	}
Define_label(mercury____Unify___vn_order__order_result_0_0_i1009);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_order__order_result_0_0_i1008);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___vn_order__order_result_0_0));
	}
Define_label(mercury____Unify___vn_order__order_result_0_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_order__order_result_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___vn_order__order_result_0_0_i1008);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module28)
	init_entry(mercury____Index___vn_order__order_result_0_0);
	init_label(mercury____Index___vn_order__order_result_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_order__order_result_0_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___vn_order__order_result_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___vn_order__order_result_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_order_module29)
	init_entry(mercury____Compare___vn_order__order_result_0_0);
	init_label(mercury____Compare___vn_order__order_result_0_0_i2);
	init_label(mercury____Compare___vn_order__order_result_0_0_i3);
	init_label(mercury____Compare___vn_order__order_result_0_0_i4);
	init_label(mercury____Compare___vn_order__order_result_0_0_i6);
	init_label(mercury____Compare___vn_order__order_result_0_0_i15);
	init_label(mercury____Compare___vn_order__order_result_0_0_i14);
	init_label(mercury____Compare___vn_order__order_result_0_0_i11);
	init_label(mercury____Compare___vn_order__order_result_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_order__order_result_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___vn_order__order_result_0_0),
		mercury____Compare___vn_order__order_result_0_0_i2,
		ENTRY(mercury____Compare___vn_order__order_result_0_0));
	}
Define_label(mercury____Compare___vn_order__order_result_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___vn_order__order_result_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___vn_order__order_result_0_0),
		mercury____Compare___vn_order__order_result_0_0_i3,
		ENTRY(mercury____Compare___vn_order__order_result_0_0));
	}
Define_label(mercury____Compare___vn_order__order_result_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_order__order_result_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_order__order_result_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_order__order_result_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_order__order_result_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_order__order_result_0_0_i6);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_order__order_result_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_order__order_result_0_0_i9);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___vn_table__vn_tables_0_0);
	call_localret(ENTRY(mercury____Compare___vn_table__vn_tables_0_0),
		mercury____Compare___vn_order__order_result_0_0_i15,
		ENTRY(mercury____Compare___vn_order__order_result_0_0));
	}
	}
Define_label(mercury____Compare___vn_order__order_result_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___vn_order__order_result_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_order__order_result_0_0_i14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_order__order_result_0_0_i14);
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___vn_order__order_result_0_0));
	}
Define_label(mercury____Compare___vn_order__order_result_0_0_i11);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_order__order_result_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___vn_order__order_result_0_0));
	}
	}
Define_label(mercury____Compare___vn_order__order_result_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_order__order_result_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_order_bunch_0(void)
{
	mercury__vn_order_module0();
	mercury__vn_order_module1();
	mercury__vn_order_module2();
	mercury__vn_order_module3();
	mercury__vn_order_module4();
	mercury__vn_order_module5();
	mercury__vn_order_module6();
	mercury__vn_order_module7();
	mercury__vn_order_module8();
	mercury__vn_order_module9();
	mercury__vn_order_module10();
	mercury__vn_order_module11();
	mercury__vn_order_module12();
	mercury__vn_order_module13();
	mercury__vn_order_module14();
	mercury__vn_order_module15();
	mercury__vn_order_module16();
	mercury__vn_order_module17();
	mercury__vn_order_module18();
	mercury__vn_order_module19();
	mercury__vn_order_module20();
	mercury__vn_order_module21();
	mercury__vn_order_module22();
	mercury__vn_order_module23();
	mercury__vn_order_module24();
	mercury__vn_order_module25();
	mercury__vn_order_module26();
	mercury__vn_order_module27();
	mercury__vn_order_module28();
	mercury__vn_order_module29();
}

#endif

void mercury__vn_order__init(void); /* suppress gcc warning */
void mercury__vn_order__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_order_bunch_0();
#endif
}
