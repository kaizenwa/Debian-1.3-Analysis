/*
** Automatically generated from `prog_util.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__prog_util__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__prog_util__unqualify_name_2_0);
Declare_label(mercury__prog_util__unqualify_name_2_0_i3);
Define_extern_entry(mercury__prog_util__sym_name_get_module_name_3_0);
Declare_label(mercury__prog_util__sym_name_get_module_name_3_0_i3);
Define_extern_entry(mercury__prog_util__construct_qualified_term_3_0);
Declare_label(mercury__prog_util__construct_qualified_term_3_0_i2);
Define_extern_entry(mercury__prog_util__construct_qualified_term_4_0);
Declare_label(mercury__prog_util__construct_qualified_term_4_0_i3);
Define_extern_entry(mercury__prog_util__split_types_and_modes_3_0);
Declare_label(mercury__prog_util__split_types_and_modes_3_0_i2);
Declare_label(mercury__prog_util__split_types_and_modes_3_0_i3);
Define_extern_entry(mercury__prog_util__split_type_and_mode_3_0);
Declare_label(mercury__prog_util__split_type_and_mode_3_0_i3);
Define_extern_entry(mercury__prog_util__rename_in_goal_4_0);
Declare_label(mercury__prog_util__rename_in_goal_4_0_i2);
Declare_static(mercury__prog_util__split_types_and_modes_2_5_0);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i5);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i3);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i2);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i6);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i1);
Declare_static(mercury__prog_util__rename_in_goal_expr_4_0);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1010);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1009);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1008);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1007);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1006);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1005);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1004);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1003);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1002);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i5);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i6);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i7);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i8);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i9);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i10);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i11);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i12);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i13);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i14);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i15);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i16);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i17);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i18);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i19);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i20);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i21);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i22);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i23);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i24);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i25);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i26);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i27);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i28);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i29);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i30);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i31);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i32);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1001);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i33);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i36);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i37);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i35);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i38);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i39);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1000);
Declare_static(mercury__prog_util__rename_in_vars_4_0);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i6);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i5);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i8);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i9);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i1003);
Define_extern_entry(mercury____Unify___prog_util__maybe_modes_0_0);
Define_extern_entry(mercury____Index___prog_util__maybe_modes_0_0);
Define_extern_entry(mercury____Compare___prog_util__maybe_modes_0_0);

extern Word * mercury_data_prog_util__base_type_layout_maybe_modes_0[];
Word * mercury_data_prog_util__base_type_info_maybe_modes_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prog_util__maybe_modes_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prog_util__maybe_modes_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prog_util__maybe_modes_0_0),
	(Word *) (Integer) mercury_data_prog_util__base_type_layout_maybe_modes_0
};

extern Word * mercury_data_prog_util__common_4[];
Word * mercury_data_prog_util__base_type_layout_maybe_modes_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prog_util__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prog_util__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prog_util__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prog_util__common_4)
};

Word * mercury_data_prog_util__common_0[] = {
	(Word *) string_const(":", 1)
};

Word mercury_data_prog_util__common_1[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_prog_data__base_type_info_mode_0[];
Word * mercury_data_prog_util__common_2[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_mode_0
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
Word * mercury_data_prog_util__common_3[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_2)
};

Word * mercury_data_prog_util__common_4[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_3)
};

BEGIN_MODULE(mercury__prog_util_module0)
	init_entry(mercury__prog_util__unqualify_name_2_0);
	init_label(mercury__prog_util__unqualify_name_2_0_i3);
BEGIN_CODE

/* code for predicate 'unqualify_name'/2 in mode 0 */
Define_entry(mercury__prog_util__unqualify_name_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__unqualify_name_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__prog_util__unqualify_name_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module1)
	init_entry(mercury__prog_util__sym_name_get_module_name_3_0);
	init_label(mercury__prog_util__sym_name_get_module_name_3_0_i3);
BEGIN_CODE

/* code for predicate 'sym_name_get_module_name'/3 in mode 0 */
Define_entry(mercury__prog_util__sym_name_get_module_name_3_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__sym_name_get_module_name_3_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__prog_util__sym_name_get_module_name_3_0_i3);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module2)
	init_entry(mercury__prog_util__construct_qualified_term_3_0);
	init_label(mercury__prog_util__construct_qualified_term_3_0_i2);
BEGIN_CODE

/* code for predicate 'construct_qualified_term'/3 in mode 0 */
Define_entry(mercury__prog_util__construct_qualified_term_3_0);
	incr_sp_push_msg(3, "construct_qualified_term");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__prog_util__construct_qualified_term_3_0_i2,
		ENTRY(mercury__prog_util__construct_qualified_term_3_0));
	}
Define_label(mercury__prog_util__construct_qualified_term_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__construct_qualified_term_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__prog_util__construct_qualified_term_4_0),
		ENTRY(mercury__prog_util__construct_qualified_term_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prog_util_module3)
	init_entry(mercury__prog_util__construct_qualified_term_4_0);
	init_label(mercury__prog_util__construct_qualified_term_4_0_i3);
BEGIN_CODE

/* code for predicate 'construct_qualified_term'/4 in mode 0 */
Define_entry(mercury__prog_util__construct_qualified_term_4_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__construct_qualified_term_4_0_i3);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_0);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 3));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(0), (Integer) r6, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 3));
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(0), (Integer) r7, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
Define_label(mercury__prog_util__construct_qualified_term_4_0_i3);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__prog_util_module4)
	init_entry(mercury__prog_util__split_types_and_modes_3_0);
	init_label(mercury__prog_util__split_types_and_modes_3_0_i2);
	init_label(mercury__prog_util__split_types_and_modes_3_0_i3);
BEGIN_CODE

/* code for predicate 'split_types_and_modes'/3 in mode 0 */
Define_entry(mercury__prog_util__split_types_and_modes_3_0);
	r2 = ((Integer) 0);
	incr_sp_push_msg(1, "split_types_and_modes");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__prog_util__split_types_and_modes_2_5_0),
		mercury__prog_util__split_types_and_modes_3_0_i2,
		ENTRY(mercury__prog_util__split_types_and_modes_3_0));
Define_label(mercury__prog_util__split_types_and_modes_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__split_types_and_modes_3_0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_3_0_i3);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__prog_util__split_types_and_modes_3_0_i3);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module5)
	init_entry(mercury__prog_util__split_type_and_mode_3_0);
	init_label(mercury__prog_util__split_type_and_mode_3_0_i3);
BEGIN_CODE

/* code for predicate 'split_type_and_mode'/3 in mode 0 */
Define_entry(mercury__prog_util__split_type_and_mode_3_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__split_type_and_mode_3_0_i3);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__prog_util__split_type_and_mode_3_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module6)
	init_entry(mercury__prog_util__rename_in_goal_4_0);
	init_label(mercury__prog_util__rename_in_goal_4_0_i2);
BEGIN_CODE

/* code for predicate 'prog_util__rename_in_goal'/4 in mode 0 */
Define_entry(mercury__prog_util__rename_in_goal_4_0);
	incr_sp_push_msg(2, "prog_util__rename_in_goal");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__prog_util__rename_in_goal_expr_4_0),
		mercury__prog_util__rename_in_goal_4_0_i2,
		ENTRY(mercury__prog_util__rename_in_goal_4_0));
Define_label(mercury__prog_util__rename_in_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module7)
	init_entry(mercury__prog_util__split_types_and_modes_2_5_0);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i5);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i3);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i2);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i6);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i1);
BEGIN_CODE

/* code for predicate 'split_types_and_modes_2'/5 in mode 0 */
Define_static(mercury__prog_util__split_types_and_modes_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i1);
	r6 = (Integer) sp;
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i5);
	incr_sp_push_msg(2, "split_types_and_modes_2");
	if ((tag((Integer) field(mktag(1), (Integer) r1, ((Integer) 0))) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i2);
	}
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i3);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) 1);
	r4 = (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_1);
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i2);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i6);
	r5 = (Integer) r2;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	r1 = (Integer) tempr1;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	decr_sp_pop_msg(2);
	if (((Integer) sp > (Integer) r6))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i6);
	proceed();
	}
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module8)
	init_entry(mercury__prog_util__rename_in_goal_expr_4_0);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1010);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1009);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1008);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1007);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1006);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1005);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1004);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1003);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1002);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i5);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i6);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i7);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i8);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i9);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i10);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i11);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i12);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i13);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i14);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i15);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i16);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i17);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i18);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i19);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i20);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i21);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i22);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i23);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i24);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i25);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i26);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i27);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i28);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i29);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i30);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i31);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i32);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1001);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i33);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i36);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i37);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i35);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i38);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i39);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1000);
BEGIN_CODE

/* code for predicate 'prog_util__rename_in_goal_expr'/4 in mode 0 */
Define_static(mercury__prog_util__rename_in_goal_expr_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1001);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1010) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1009) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1008) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1007) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1006) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1005) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1004) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1003) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1002));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1010);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i5);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1009);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i7);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1008);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i10);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1007);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i13);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1006);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i16);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1005);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i19);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1004);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i23);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1003);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i28);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1002);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i30);
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i5);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i6,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i7);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i8,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i9,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i10);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i11,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i12,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i13);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i14,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i15,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i16);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i17,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i18,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i19);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i20,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i20);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i21,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i21);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i22,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i22);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i23);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i24,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i24);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i25,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i25);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i26,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i26);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i27,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i27);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i28);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r5 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__term__substitute_list_4_0);
	call_localret(ENTRY(mercury__term__substitute_list_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i29,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i29);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i30);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(3) = (Integer) tempr1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__term__substitute_4_0);
	call_localret(ENTRY(mercury__term__substitute_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i31,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i31);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__term__substitute_4_0);
	call_localret(ENTRY(mercury__term__substitute_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i32,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i32);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 8);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1001);
	incr_sp_push_msg(6, "prog_util__rename_in_goal_expr");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i33);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	if ((unmkbody((Integer) r1) != ((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i33);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i35);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i36,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i36);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i37,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i37);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i35);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i38,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i38);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i39,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i39);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module9)
	init_entry(mercury__prog_util__rename_in_vars_4_0);
	init_label(mercury__prog_util__rename_in_vars_4_0_i6);
	init_label(mercury__prog_util__rename_in_vars_4_0_i5);
	init_label(mercury__prog_util__rename_in_vars_4_0_i8);
	init_label(mercury__prog_util__rename_in_vars_4_0_i9);
	init_label(mercury__prog_util__rename_in_vars_4_0_i1003);
BEGIN_CODE

/* code for predicate 'prog_util__rename_in_vars'/4 in mode 0 */
Define_static(mercury__prog_util__rename_in_vars_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__prog_util__rename_in_vars_4_0_i1003);
	incr_sp_push_msg(6, "prog_util__rename_in_vars");
	detstackvar(6) = (Integer) succip;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__prog_util__rename_in_vars_4_0_i6,
		STATIC(mercury__prog_util__rename_in_vars_4_0));
	}
Define_label(mercury__prog_util__rename_in_vars_4_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_vars_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__prog_util__rename_in_vars_4_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) r3;
	GOTO_LABEL(mercury__prog_util__rename_in_vars_4_0_i8);
Define_label(mercury__prog_util__rename_in_vars_4_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
Define_label(mercury__prog_util__rename_in_vars_4_0_i8);
	detstackvar(5) = (Integer) r4;
	localcall(mercury__prog_util__rename_in_vars_4_0,
		LABEL(mercury__prog_util__rename_in_vars_4_0_i9),
		STATIC(mercury__prog_util__rename_in_vars_4_0));
Define_label(mercury__prog_util__rename_in_vars_4_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_vars_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_vars_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prog_util_module10)
	init_entry(mercury____Unify___prog_util__maybe_modes_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_util__maybe_modes_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_2);
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___prog_util__maybe_modes_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prog_util_module11)
	init_entry(mercury____Index___prog_util__maybe_modes_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_util__maybe_modes_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_2);
	{
	Declare_entry(mercury____Index___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Index___std_util__maybe_1_0),
		ENTRY(mercury____Index___prog_util__maybe_modes_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prog_util_module12)
	init_entry(mercury____Compare___prog_util__maybe_modes_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_util__maybe_modes_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_prog_util__common_2);
	{
	Declare_entry(mercury____Compare___std_util__maybe_1_0);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___prog_util__maybe_modes_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__prog_util_bunch_0(void)
{
	mercury__prog_util_module0();
	mercury__prog_util_module1();
	mercury__prog_util_module2();
	mercury__prog_util_module3();
	mercury__prog_util_module4();
	mercury__prog_util_module5();
	mercury__prog_util_module6();
	mercury__prog_util_module7();
	mercury__prog_util_module8();
	mercury__prog_util_module9();
	mercury__prog_util_module10();
	mercury__prog_util_module11();
	mercury__prog_util_module12();
}

#endif

void mercury__prog_util__init(void); /* suppress gcc warning */
void mercury__prog_util__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__prog_util_bunch_0();
#endif
}
