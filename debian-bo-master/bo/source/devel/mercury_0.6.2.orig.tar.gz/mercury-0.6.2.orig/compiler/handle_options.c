/*
** Automatically generated from `handle_options.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__handle_options__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__handle_options__handle_options_5_0);
Declare_label(mercury__handle_options__handle_options_5_0_i2);
Declare_label(mercury__handle_options__handle_options_5_0_i3);
Declare_label(mercury__handle_options__handle_options_5_0_i4);
Declare_label(mercury__handle_options__handle_options_5_0_i5);
Declare_label(mercury__handle_options__handle_options_5_0_i8);
Declare_label(mercury__handle_options__handle_options_5_0_i9);
Declare_label(mercury__handle_options__handle_options_5_0_i10);
Declare_label(mercury__handle_options__handle_options_5_0_i11);
Declare_label(mercury__handle_options__handle_options_5_0_i12);
Declare_label(mercury__handle_options__handle_options_5_0_i13);
Declare_label(mercury__handle_options__handle_options_5_0_i14);
Declare_label(mercury__handle_options__handle_options_5_0_i15);
Declare_label(mercury__handle_options__handle_options_5_0_i16);
Declare_label(mercury__handle_options__handle_options_5_0_i17);
Declare_label(mercury__handle_options__handle_options_5_0_i18);
Declare_label(mercury__handle_options__handle_options_5_0_i19);
Define_extern_entry(mercury__handle_options__usage_error_3_0);
Declare_label(mercury__handle_options__usage_error_3_0_i2);
Declare_label(mercury__handle_options__usage_error_3_0_i3);
Declare_label(mercury__handle_options__usage_error_3_0_i4);
Declare_label(mercury__handle_options__usage_error_3_0_i5);
Declare_label(mercury__handle_options__usage_error_3_0_i6);
Declare_label(mercury__handle_options__usage_error_3_0_i7);
Declare_label(mercury__handle_options__usage_error_3_0_i8);
Define_extern_entry(mercury__handle_options__usage_2_0);
Declare_label(mercury__handle_options__usage_2_0_i2);
Declare_label(mercury__handle_options__usage_2_0_i3);
Declare_label(mercury__handle_options__usage_2_0_i4);
Declare_label(mercury__handle_options__usage_2_0_i5);
Declare_label(mercury__handle_options__usage_2_0_i6);
Declare_label(mercury__handle_options__usage_2_0_i7);
Declare_label(mercury__handle_options__usage_2_0_i8);
Declare_label(mercury__handle_options__usage_2_0_i9);
Declare_label(mercury__handle_options__usage_2_0_i10);
Declare_label(mercury__handle_options__usage_2_0_i11);
Define_extern_entry(mercury__handle_options__long_usage_2_0);
Declare_label(mercury__handle_options__long_usage_2_0_i2);
Declare_label(mercury__handle_options__long_usage_2_0_i3);
Declare_label(mercury__handle_options__long_usage_2_0_i4);
Declare_label(mercury__handle_options__long_usage_2_0_i5);
Declare_label(mercury__handle_options__long_usage_2_0_i6);
Declare_label(mercury__handle_options__long_usage_2_0_i7);
Declare_label(mercury__handle_options__long_usage_2_0_i8);
Declare_label(mercury__handle_options__long_usage_2_0_i9);
Declare_static(mercury__handle_options__postprocess_options_4_0);
Declare_label(mercury__handle_options__postprocess_options_4_0_i3);
Declare_label(mercury__handle_options__postprocess_options_4_0_i4);
Declare_label(mercury__handle_options__postprocess_options_4_0_i10);
Declare_label(mercury__handle_options__postprocess_options_4_0_i12);
Declare_label(mercury__handle_options__postprocess_options_4_0_i9);
Declare_label(mercury__handle_options__postprocess_options_4_0_i13);
Declare_label(mercury__handle_options__postprocess_options_4_0_i14);
Declare_label(mercury__handle_options__postprocess_options_4_0_i17);
Declare_label(mercury__handle_options__postprocess_options_4_0_i19);
Declare_label(mercury__handle_options__postprocess_options_4_0_i16);
Declare_label(mercury__handle_options__postprocess_options_4_0_i20);
Declare_label(mercury__handle_options__postprocess_options_4_0_i21);
Declare_label(mercury__handle_options__postprocess_options_4_0_i24);
Declare_label(mercury__handle_options__postprocess_options_4_0_i23);
Declare_label(mercury__handle_options__postprocess_options_4_0_i28);
Declare_label(mercury__handle_options__postprocess_options_4_0_i27);
Declare_label(mercury__handle_options__postprocess_options_4_0_i31);
Declare_label(mercury__handle_options__postprocess_options_4_0_i34);
Declare_label(mercury__handle_options__postprocess_options_4_0_i33);
Declare_label(mercury__handle_options__postprocess_options_4_0_i35);
Declare_label(mercury__handle_options__postprocess_options_4_0_i37);
Declare_label(mercury__handle_options__postprocess_options_4_0_i32);
Declare_label(mercury__handle_options__postprocess_options_4_0_i38);
Declare_label(mercury__handle_options__postprocess_options_4_0_i40);
Declare_label(mercury__handle_options__postprocess_options_4_0_i44);
Declare_label(mercury__handle_options__postprocess_options_4_0_i46);
Declare_label(mercury__handle_options__postprocess_options_4_0_i50);
Declare_label(mercury__handle_options__postprocess_options_4_0_i52);
Declare_label(mercury__handle_options__postprocess_options_4_0_i56);
Declare_label(mercury__handle_options__postprocess_options_4_0_i58);
Declare_label(mercury__handle_options__postprocess_options_4_0_i62);
Declare_label(mercury__handle_options__postprocess_options_4_0_i64);
Declare_label(mercury__handle_options__postprocess_options_4_0_i68);
Declare_label(mercury__handle_options__postprocess_options_4_0_i70);
Declare_label(mercury__handle_options__postprocess_options_4_0_i66);
Declare_label(mercury__handle_options__postprocess_options_4_0_i60);
Declare_label(mercury__handle_options__postprocess_options_4_0_i54);
Declare_label(mercury__handle_options__postprocess_options_4_0_i48);
Declare_label(mercury__handle_options__postprocess_options_4_0_i42);
Declare_label(mercury__handle_options__postprocess_options_4_0_i6);
Declare_static(mercury__handle_options__postprocess_options_2_8_0);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i4);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i7);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i3);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i8);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i9);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i10);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i14);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i15);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i11);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i16);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i17);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i20);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i21);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i22);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i27);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i30);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i31);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i32);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i33);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i34);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i35);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i28);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i37);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i38);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i42);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i39);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i44);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i48);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i45);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i50);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i51);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i55);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i54);
Declare_label(mercury__handle_options__postprocess_options_2_8_0_i52);
Declare_static(mercury__handle_options__convert_grade_option_2_3_0);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i4);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i5);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i6);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i7);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i8);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i1002);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i10);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i11);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i12);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i9);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i16);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i17);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i18);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i19);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i15);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i22);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i23);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i24);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i21);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i28);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i29);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i27);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i34);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i33);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i40);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i41);
Declare_label(mercury__handle_options__convert_grade_option_2_3_0_i1);
Declare_static(mercury__handle_options__set_bool_opt_4_0);
Declare_static(mercury__handle_options__set_string_opt_4_0);

Declare_entry(mercury__options__short_option_2_0);
Word * mercury_data_handle_options__common_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__short_option_2_0)
};

Declare_entry(mercury__options__long_option_2_0);
Word * mercury_data_handle_options__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__long_option_2_0)
};

Declare_entry(mercury__options__option_defaults_2_0);
Word * mercury_data_handle_options__common_2[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__option_defaults_2_0)
};

Declare_entry(mercury__options__special_handler_4_0);
Word * mercury_data_handle_options__common_3[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__special_handler_4_0)
};

Word * mercury_data_handle_options__common_4[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_handle_options__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_handle_options__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_handle_options__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_handle_options__common_3)
};

Word * mercury_data_handle_options__common_5[] = {
	(Word *) string_const("\n", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_handle_options__common_6[] = {
	(Word *) string_const("Invalid prolog-dialect option (must be `sicstus', `nu', or `default')", 69)
};

Word * mercury_data_handle_options__common_7[] = {
	(Word *) string_const("Invalid type-info option (must be `one-cell', `one-or-two-cell', `shared-one-or-two-cell' or `default')", 103)
};

Word * mercury_data_handle_options__common_8[] = {
	(Word *) string_const("Invalid args option (must be `simple' or `compact')", 51)
};

Word * mercury_data_handle_options__common_9[] = {
	(Word *) string_const("Invalid tags option (must be `none', `low' or `high')", 53)
};

Word * mercury_data_handle_options__common_10[] = {
	(Word *) string_const("Invalid GC option (must be `none', `conservative' or `accurate')", 64)
};

Word * mercury_data_handle_options__common_11[] = {
	(Word *) string_const("Invalid grade option", 20)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_options__base_type_info_option_0[];
extern Word * mercury_data_getopt__base_type_info_option_data_0[];
Word * mercury_data_handle_options__common_12[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_options__base_type_info_option_0,
	(Word *) (Integer) mercury_data_getopt__base_type_info_option_data_0
};

Word mercury_data_handle_options__common_13[] = {
	((Integer) 1)
};

Word mercury_data_handle_options__common_14[] = {
	((Integer) 0)
};

BEGIN_MODULE(mercury__handle_options_module0)
	init_entry(mercury__handle_options__handle_options_5_0);
	init_label(mercury__handle_options__handle_options_5_0_i2);
	init_label(mercury__handle_options__handle_options_5_0_i3);
	init_label(mercury__handle_options__handle_options_5_0_i4);
	init_label(mercury__handle_options__handle_options_5_0_i5);
	init_label(mercury__handle_options__handle_options_5_0_i8);
	init_label(mercury__handle_options__handle_options_5_0_i9);
	init_label(mercury__handle_options__handle_options_5_0_i10);
	init_label(mercury__handle_options__handle_options_5_0_i11);
	init_label(mercury__handle_options__handle_options_5_0_i12);
	init_label(mercury__handle_options__handle_options_5_0_i13);
	init_label(mercury__handle_options__handle_options_5_0_i14);
	init_label(mercury__handle_options__handle_options_5_0_i15);
	init_label(mercury__handle_options__handle_options_5_0_i16);
	init_label(mercury__handle_options__handle_options_5_0_i17);
	init_label(mercury__handle_options__handle_options_5_0_i18);
	init_label(mercury__handle_options__handle_options_5_0_i19);
BEGIN_CODE

/* code for predicate 'handle_options'/5 in mode 0 */
Define_entry(mercury__handle_options__handle_options_5_0);
	incr_sp_push_msg(12, "handle_options");
	detstackvar(12) = (Integer) succip;
	{
	Declare_entry(mercury__io__command_line_arguments_3_0);
	call_localret(ENTRY(mercury__io__command_line_arguments_3_0),
		mercury__handle_options__handle_options_5_0_i2,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_4);
	{
	Declare_entry(mercury__getopt__process_options_4_0);
	call_localret(ENTRY(mercury__getopt__process_options_4_0),
		mercury__handle_options__handle_options_5_0_i3,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__handle_options__postprocess_options_4_0),
		mercury__handle_options__handle_options_5_0_i4,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__handle_options__handle_options_5_0_i5);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__handle_options__handle_options_5_0_i5);
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 23);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i8,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 21);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i9,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 20);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i10,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = ((Integer) 22);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i11,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i11);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = ((Integer) 24);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i12,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i12);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(7) = (Integer) r1;
	r1 = ((Integer) 25);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i13,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i13);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(8) = (Integer) r1;
	r1 = ((Integer) 26);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i14,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i14);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(9) = (Integer) r1;
	r1 = ((Integer) 27);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i15,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i15);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(10) = (Integer) r1;
	r1 = ((Integer) 28);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i16,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i16);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	detstackvar(11) = (Integer) r1;
	r1 = ((Integer) 29);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i17,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i17);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) detstackvar(11);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__bool__or_list_2_0);
	call_localret(ENTRY(mercury__bool__or_list_2_0),
		mercury__handle_options__handle_options_5_0_i18,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i18);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	{
	Declare_entry(mercury__bool__not_2_0);
	call_localret(ENTRY(mercury__bool__not_2_0),
		mercury__handle_options__handle_options_5_0_i19,
		ENTRY(mercury__handle_options__handle_options_5_0));
	}
Define_label(mercury__handle_options__handle_options_5_0_i19);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__handle_options_module1)
	init_entry(mercury__handle_options__usage_error_3_0);
	init_label(mercury__handle_options__usage_error_3_0_i2);
	init_label(mercury__handle_options__usage_error_3_0_i3);
	init_label(mercury__handle_options__usage_error_3_0_i4);
	init_label(mercury__handle_options__usage_error_3_0_i5);
	init_label(mercury__handle_options__usage_error_3_0_i6);
	init_label(mercury__handle_options__usage_error_3_0_i7);
	init_label(mercury__handle_options__usage_error_3_0_i8);
BEGIN_CODE

/* code for predicate 'usage_error'/3 in mode 0 */
Define_entry(mercury__handle_options__usage_error_3_0);
	incr_sp_push_msg(3, "usage_error");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("mercury_compile", 15);
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__handle_options__usage_error_3_0_i2,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__handle_options__usage_error_3_0_i3,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i4,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(": ", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i5,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i6,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i7,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__handle_options__usage_error_3_0_i8,
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
Define_label(mercury__handle_options__usage_error_3_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__handle_options__usage_2_0),
		ENTRY(mercury__handle_options__usage_error_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__handle_options_module2)
	init_entry(mercury__handle_options__usage_2_0);
	init_label(mercury__handle_options__usage_2_0_i2);
	init_label(mercury__handle_options__usage_2_0_i3);
	init_label(mercury__handle_options__usage_2_0_i4);
	init_label(mercury__handle_options__usage_2_0_i5);
	init_label(mercury__handle_options__usage_2_0_i6);
	init_label(mercury__handle_options__usage_2_0_i7);
	init_label(mercury__handle_options__usage_2_0_i8);
	init_label(mercury__handle_options__usage_2_0_i9);
	init_label(mercury__handle_options__usage_2_0_i10);
	init_label(mercury__handle_options__usage_2_0_i11);
BEGIN_CODE

/* code for predicate 'usage'/2 in mode 0 */
Define_entry(mercury__handle_options__usage_2_0);
	r2 = (Integer) r1;
	r1 = string_const("mercury_compile", 15);
	incr_sp_push_msg(4, "usage");
	detstackvar(4) = (Integer) succip;
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__handle_options__usage_2_0_i2,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__handle_options__usage_2_0_i3,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__handle_options__usage_2_0_i4,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("Mercury Compiler, version ", 26);
	r1 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_5);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__handle_options__usage_2_0_i5,
		ENTRY(mercury__handle_options__usage_2_0));
	}
	}
Define_label(mercury__handle_options__usage_2_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("Copyright (C) 1995 University of Melbourne\n", 43);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_2_0_i6,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("Usage: ", 7);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_2_0_i7,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_2_0_i8,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(" [<options>] <module(s)>\n", 25);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_2_0_i9,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("Use `", 5);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_2_0_i10,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_2_0_i11,
		ENTRY(mercury__handle_options__usage_2_0));
	}
Define_label(mercury__handle_options__usage_2_0_i11);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(" --help' for more information.\n", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		ENTRY(mercury__handle_options__usage_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__handle_options_module3)
	init_entry(mercury__handle_options__long_usage_2_0);
	init_label(mercury__handle_options__long_usage_2_0_i2);
	init_label(mercury__handle_options__long_usage_2_0_i3);
	init_label(mercury__handle_options__long_usage_2_0_i4);
	init_label(mercury__handle_options__long_usage_2_0_i5);
	init_label(mercury__handle_options__long_usage_2_0_i6);
	init_label(mercury__handle_options__long_usage_2_0_i7);
	init_label(mercury__handle_options__long_usage_2_0_i8);
	init_label(mercury__handle_options__long_usage_2_0_i9);
BEGIN_CODE

/* code for predicate 'long_usage'/2 in mode 0 */
Define_entry(mercury__handle_options__long_usage_2_0);
	r2 = (Integer) r1;
	r1 = string_const("mercury_compile", 15);
	incr_sp_push_msg(3, "long_usage");
	detstackvar(3) = (Integer) succip;
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__handle_options__long_usage_2_0_i2,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__handle_options__long_usage_2_0_i3,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Mercury Compiler, version ", 26);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__handle_options__long_usage_2_0_i4,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = (Integer) r1;
	r1 = string_const("Copyright (C) 1995 University of Melbourne\n", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i5,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = (Integer) r1;
	r1 = string_const("Usage: ", 7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i6,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i7,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = (Integer) r1;
	r1 = string_const(" [<options>] <module(s)>\n", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i8,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = (Integer) r1;
	r1 = string_const("Options:\n", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i9,
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
Define_label(mercury__handle_options__long_usage_2_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__options__options_help_2_0);
	tailcall(ENTRY(mercury__options__options_help_2_0),
		ENTRY(mercury__handle_options__long_usage_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__handle_options_module4)
	init_entry(mercury__handle_options__postprocess_options_4_0);
	init_label(mercury__handle_options__postprocess_options_4_0_i3);
	init_label(mercury__handle_options__postprocess_options_4_0_i4);
	init_label(mercury__handle_options__postprocess_options_4_0_i10);
	init_label(mercury__handle_options__postprocess_options_4_0_i12);
	init_label(mercury__handle_options__postprocess_options_4_0_i9);
	init_label(mercury__handle_options__postprocess_options_4_0_i13);
	init_label(mercury__handle_options__postprocess_options_4_0_i14);
	init_label(mercury__handle_options__postprocess_options_4_0_i17);
	init_label(mercury__handle_options__postprocess_options_4_0_i19);
	init_label(mercury__handle_options__postprocess_options_4_0_i16);
	init_label(mercury__handle_options__postprocess_options_4_0_i20);
	init_label(mercury__handle_options__postprocess_options_4_0_i21);
	init_label(mercury__handle_options__postprocess_options_4_0_i24);
	init_label(mercury__handle_options__postprocess_options_4_0_i23);
	init_label(mercury__handle_options__postprocess_options_4_0_i28);
	init_label(mercury__handle_options__postprocess_options_4_0_i27);
	init_label(mercury__handle_options__postprocess_options_4_0_i31);
	init_label(mercury__handle_options__postprocess_options_4_0_i34);
	init_label(mercury__handle_options__postprocess_options_4_0_i33);
	init_label(mercury__handle_options__postprocess_options_4_0_i35);
	init_label(mercury__handle_options__postprocess_options_4_0_i37);
	init_label(mercury__handle_options__postprocess_options_4_0_i32);
	init_label(mercury__handle_options__postprocess_options_4_0_i38);
	init_label(mercury__handle_options__postprocess_options_4_0_i40);
	init_label(mercury__handle_options__postprocess_options_4_0_i44);
	init_label(mercury__handle_options__postprocess_options_4_0_i46);
	init_label(mercury__handle_options__postprocess_options_4_0_i50);
	init_label(mercury__handle_options__postprocess_options_4_0_i52);
	init_label(mercury__handle_options__postprocess_options_4_0_i56);
	init_label(mercury__handle_options__postprocess_options_4_0_i58);
	init_label(mercury__handle_options__postprocess_options_4_0_i62);
	init_label(mercury__handle_options__postprocess_options_4_0_i64);
	init_label(mercury__handle_options__postprocess_options_4_0_i68);
	init_label(mercury__handle_options__postprocess_options_4_0_i70);
	init_label(mercury__handle_options__postprocess_options_4_0_i66);
	init_label(mercury__handle_options__postprocess_options_4_0_i60);
	init_label(mercury__handle_options__postprocess_options_4_0_i54);
	init_label(mercury__handle_options__postprocess_options_4_0_i48);
	init_label(mercury__handle_options__postprocess_options_4_0_i42);
	init_label(mercury__handle_options__postprocess_options_4_0_i6);
BEGIN_CODE

/* code for predicate 'postprocess_options'/4 in mode 0 */
Define_static(mercury__handle_options__postprocess_options_4_0);
	incr_sp_push_msg(13, "postprocess_options");
	detstackvar(13) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i3);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r4 = ((Integer) 47);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__handle_options__postprocess_options_4_0_i4,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i6);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i6);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	r2 = string_const(".cnstr", 6);
	{
	Declare_entry(mercury__string__remove_suffix_3_0);
	call_localret(ENTRY(mercury__string__remove_suffix_3_0),
		mercury__handle_options__postprocess_options_4_0_i10,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i9);
	detstackvar(9) = (Integer) r2;
	r1 = ((Integer) 53);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i12,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i12);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i14);
Define_label(mercury__handle_options__postprocess_options_4_0_i9);
	detstackvar(9) = (Integer) detstackvar(3);
	r1 = ((Integer) 53);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i13,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i13);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
Define_label(mercury__handle_options__postprocess_options_4_0_i14);
	detstackvar(1) = (Integer) r2;
	detstackvar(9) = (Integer) r1;
	detstackvar(11) = (Integer) r3;
	r2 = string_const(".prof", 5);
	{
	Declare_entry(mercury__string__remove_suffix_3_0);
	call_localret(ENTRY(mercury__string__remove_suffix_3_0),
		mercury__handle_options__postprocess_options_4_0_i17,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i17);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i16);
	detstackvar(10) = (Integer) r2;
	r1 = ((Integer) 52);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i19,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i19);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i21);
Define_label(mercury__handle_options__postprocess_options_4_0_i16);
	detstackvar(10) = (Integer) detstackvar(9);
	r1 = ((Integer) 52);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i20,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i20);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
Define_label(mercury__handle_options__postprocess_options_4_0_i21);
	detstackvar(1) = (Integer) r2;
	detstackvar(10) = (Integer) r1;
	detstackvar(12) = (Integer) r3;
	r2 = string_const(".gc", 3);
	{
	Declare_entry(mercury__string__remove_suffix_3_0);
	call_localret(ENTRY(mercury__string__remove_suffix_3_0),
		mercury__handle_options__postprocess_options_4_0_i24,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i24);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i23);
	r1 = (Integer) detstackvar(1);
	r4 = ((Integer) 1);
	r3 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i31);
Define_label(mercury__handle_options__postprocess_options_4_0_i23);
	r1 = (Integer) detstackvar(10);
	r2 = string_const(".agc", 4);
	{
	Declare_entry(mercury__string__remove_suffix_3_0);
	call_localret(ENTRY(mercury__string__remove_suffix_3_0),
		mercury__handle_options__postprocess_options_4_0_i28,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i28);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i27);
	r1 = (Integer) detstackvar(1);
	r4 = ((Integer) 2);
	r3 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i31);
Define_label(mercury__handle_options__postprocess_options_4_0_i27);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
	r4 = ((Integer) 0);
	r3 = (Integer) detstackvar(12);
Define_label(mercury__handle_options__postprocess_options_4_0_i31);
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i33);
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 51);
	r2 = string_const("none", 4);
	call_localret(STATIC(mercury__handle_options__set_string_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i34,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i34);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i32);
Define_label(mercury__handle_options__postprocess_options_4_0_i33);
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i35);
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 51);
	r2 = string_const("conservative", 12);
	call_localret(STATIC(mercury__handle_options__set_string_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i34,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i35);
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 51);
	r2 = string_const("accurate", 8);
	call_localret(STATIC(mercury__handle_options__set_string_opt_4_0),
		mercury__handle_options__postprocess_options_4_0_i37,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i37);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
Define_label(mercury__handle_options__postprocess_options_4_0_i32);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__handle_options__convert_grade_option_2_3_0),
		mercury__handle_options__postprocess_options_4_0_i38,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i38);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i6);
	r3 = (Integer) r2;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r4 = ((Integer) 51);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__handle_options__postprocess_options_4_0_i40,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i40);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i42);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i42);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__globals__convert_gc_method_2_0);
	call_localret(ENTRY(mercury__globals__convert_gc_method_2_0),
		mercury__handle_options__postprocess_options_4_0_i44,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i44);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i42);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = ((Integer) 56);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__handle_options__postprocess_options_4_0_i46,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i46);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i48);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i48);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__globals__convert_tags_method_2_0);
	call_localret(ENTRY(mercury__globals__convert_tags_method_2_0),
		mercury__handle_options__postprocess_options_4_0_i50,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i50);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i48);
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = ((Integer) 61);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__handle_options__postprocess_options_4_0_i52,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i52);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i54);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i54);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__globals__convert_args_method_2_0);
	call_localret(ENTRY(mercury__globals__convert_args_method_2_0),
		mercury__handle_options__postprocess_options_4_0_i56,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i56);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i54);
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = ((Integer) 62);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__handle_options__postprocess_options_4_0_i58,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i58);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i60);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i60);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__globals__convert_type_info_method_3_0);
	call_localret(ENTRY(mercury__globals__convert_type_info_method_3_0),
		mercury__handle_options__postprocess_options_4_0_i62,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i62);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i60);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = ((Integer) 33);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__handle_options__postprocess_options_4_0_i64,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i64);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i66);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i66);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__globals__convert_prolog_dialect_2_0);
	call_localret(ENTRY(mercury__globals__convert_prolog_dialect_2_0),
		mercury__handle_options__postprocess_options_4_0_i68,
		STATIC(mercury__handle_options__postprocess_options_4_0));
	}
Define_label(mercury__handle_options__postprocess_options_4_0_i68);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i66);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__handle_options__postprocess_options_2_8_0),
		mercury__handle_options__postprocess_options_4_0_i70,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i70);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i66);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_6);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i60);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_7);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i54);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_8);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i48);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_9);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i42);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_10);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i6);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_11);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__handle_options_module5)
	init_entry(mercury__handle_options__postprocess_options_2_8_0);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i4);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i7);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i3);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i8);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i9);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i10);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i14);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i15);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i11);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i16);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i17);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i20);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i21);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i22);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i27);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i30);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i31);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i32);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i33);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i34);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i35);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i28);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i37);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i38);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i42);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i39);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i44);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i48);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i45);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i50);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i51);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i55);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i54);
	init_label(mercury__handle_options__postprocess_options_2_8_0_i52);
BEGIN_CODE

/* code for predicate 'postprocess_options_2'/8 in mode 0 */
Define_static(mercury__handle_options__postprocess_options_2_8_0);
	incr_sp_push_msg(10, "postprocess_options_2");
	detstackvar(10) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r4 = ((Integer) 140);
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__handle_options__postprocess_options_2_8_0_i4,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i3);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i3);
	r1 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__io__preallocate_heap_space_3_0);
	call_localret(ENTRY(mercury__io__preallocate_heap_space_3_0),
		mercury__handle_options__postprocess_options_2_8_0_i7,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_handle_options__common_12);
	GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i8);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_handle_options__common_12);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i8);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	{
	Declare_entry(mercury__copy_2_1);
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__handle_options__postprocess_options_2_8_0_i9,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__globals__io_init_8_0);
	call_localret(ENTRY(mercury__globals__io_init_8_0),
		mercury__handle_options__postprocess_options_2_8_0_i10,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	if (((Integer) detstackvar(2) != ((Integer) 1)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i11);
	r3 = (Integer) r1;
	r1 = ((Integer) 69);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_13);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i14,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i14);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 70);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_13);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i15,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i15);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i16);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i11);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i16);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i17);
	r3 = ((Integer) 0);
	GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i21);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i17);
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 57);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i20,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i20);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i21);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i22);
	if (((Integer) r3 != ((Integer) -1)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i22);
	r1 = ((Integer) 60);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i27,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i22);
	r1 = (Integer) r3;
Define_label(mercury__handle_options__postprocess_options_2_8_0_i27);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	if (((Integer) r1 >= ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i28);
	r1 = string_const("mercury_compile", 15);
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i30,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i30);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__handle_options__postprocess_options_2_8_0_i31,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i31);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__prog_io__report_warning_3_0);
	call_localret(ENTRY(mercury__prog_io__report_warning_3_0),
		mercury__handle_options__postprocess_options_2_8_0_i32,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i32);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) r1;
	r1 = string_const(": warning: --num-tag-bits invalid or unspecified\n", 49);
	{
	Declare_entry(mercury__prog_io__report_warning_3_0);
	call_localret(ENTRY(mercury__prog_io__report_warning_3_0),
		mercury__handle_options__postprocess_options_2_8_0_i33,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i33);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i34,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i34);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) r1;
	r1 = string_const(": using --num-tag-bits 0 (tags disabled)\n", 41);
	{
	Declare_entry(mercury__prog_io__report_warning_3_0);
	call_localret(ENTRY(mercury__prog_io__report_warning_3_0),
		mercury__handle_options__postprocess_options_2_8_0_i35,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i35);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 57);
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_handle_options__common_14);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i37,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i28);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = ((Integer) 57);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i37,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i37);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 86);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i38,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i38);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i39);
	r1 = ((Integer) 131);
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_handle_options__common_13);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i42,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i42);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 12);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i44,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i39);
	r1 = ((Integer) 12);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i44,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i44);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i45);
	r1 = ((Integer) 11);
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_14);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i48,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i48);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 37);
	{
	Declare_entry(mercury__globals__io_lookup_accumulating_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_accumulating_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i50,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i45);
	r1 = ((Integer) 37);
	{
	Declare_entry(mercury__globals__io_lookup_accumulating_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_accumulating_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i50,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i50);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	detstackvar(8) = (Integer) r1;
	r1 = ((Integer) 14);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_8_0_i51,
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i51);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_8_0));
	if (((Integer) detstackvar(8) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i55);
	r3 = (Integer) r2;
	GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i54);
Define_label(mercury__handle_options__postprocess_options_2_8_0_i55);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_8_0_i52);
	r3 = (Integer) r2;
Define_label(mercury__handle_options__postprocess_options_2_8_0_i54);
	r1 = ((Integer) 66);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_handle_options__common_13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	tailcall(ENTRY(mercury__globals__io_set_option_4_0),
		STATIC(mercury__handle_options__postprocess_options_2_8_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_8_0_i52);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__handle_options_module6)
	init_entry(mercury__handle_options__convert_grade_option_2_3_0);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i4);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i5);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i6);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i7);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i8);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i1002);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i10);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i11);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i12);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i9);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i16);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i17);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i18);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i19);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i15);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i22);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i23);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i24);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i21);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i28);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i29);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i27);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i34);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i33);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i40);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i41);
	init_label(mercury__handle_options__convert_grade_option_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'convert_grade_option_2'/3 in mode 0 */
Define_static(mercury__handle_options__convert_grade_option_2_3_0);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("asm_fast", 8)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i1002);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	incr_sp_push_msg(1, "convert_grade_option_2");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i4,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i5,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 48);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i6,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 49);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i7,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 50);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i8,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i1002);
	incr_sp_push_msg(1, "convert_grade_option_2");
	detstackvar(1) = (Integer) succip;
	if ((strcmp((char *)(Integer) r1, (char *)string_const("asm_jump", 8)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i9);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i10,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i11,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 48);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i12,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i12);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 49);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i7,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i9);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("debug", 5)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i15);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i16,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i16);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i17,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i17);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 48);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i18,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i18);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 49);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i19,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i19);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 50);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i8,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i15);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("fast", 4)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i21);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i22,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i22);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i23,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i23);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 48);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i24,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i24);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 49);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i19,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i21);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("jump", 4)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i27);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i28,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i28);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i29,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i29);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 48);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i18,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i27);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("none", 4)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i33);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i34,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i34);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i17,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i33);
	if ((strcmp((char *)(Integer) r1, (char *)string_const("reg", 3)) !=0))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_2_3_0_i1);
	r1 = ((Integer) 54);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i40,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i40);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 133);
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i41,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i41);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_2_3_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 48);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__handle_options__set_bool_opt_4_0),
		mercury__handle_options__convert_grade_option_2_3_0_i24,
		STATIC(mercury__handle_options__convert_grade_option_2_3_0));
Define_label(mercury__handle_options__convert_grade_option_2_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__handle_options_module7)
	init_entry(mercury__handle_options__set_bool_opt_4_0);
BEGIN_CODE

/* code for predicate 'set_bool_opt'/4 in mode 0 */
Define_static(mercury__handle_options__set_bool_opt_4_0);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	r4 = (Integer) r1;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury__map__set_4_1);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__handle_options__set_bool_opt_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__handle_options_module8)
	init_entry(mercury__handle_options__set_string_opt_4_0);
BEGIN_CODE

/* code for predicate 'set_string_opt'/4 in mode 0 */
Define_static(mercury__handle_options__set_string_opt_4_0);
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	r4 = (Integer) r1;
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__map__set_4_1);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__handle_options__set_string_opt_4_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__handle_options_bunch_0(void)
{
	mercury__handle_options_module0();
	mercury__handle_options_module1();
	mercury__handle_options_module2();
	mercury__handle_options_module3();
	mercury__handle_options_module4();
	mercury__handle_options_module5();
	mercury__handle_options_module6();
	mercury__handle_options_module7();
	mercury__handle_options_module8();
}

#endif

void mercury__handle_options__init(void); /* suppress gcc warning */
void mercury__handle_options__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__handle_options_bunch_0();
#endif
}
