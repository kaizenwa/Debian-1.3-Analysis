/*
** Automatically generated from `call_gen.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__call_gen__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__call_gen__generate_nondet_builtin__ua10000_6_0);
Declare_label(mercury__call_gen__generate_nondet_builtin__ua10000_6_0_i2);
Declare_static(mercury__call_gen__generate_higher_order_call__ua10000_9_0);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i2);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i3);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i4);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i5);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i6);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i7);
Declare_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i8);
Define_extern_entry(mercury__call_gen__generate_higher_order_call_9_0);
Define_extern_entry(mercury__call_gen__generate_det_call_6_0);
Declare_label(mercury__call_gen__generate_det_call_6_0_i2);
Declare_label(mercury__call_gen__generate_det_call_6_0_i3);
Declare_label(mercury__call_gen__generate_det_call_6_0_i4);
Declare_label(mercury__call_gen__generate_det_call_6_0_i5);
Declare_label(mercury__call_gen__generate_det_call_6_0_i6);
Declare_label(mercury__call_gen__generate_det_call_6_0_i7);
Declare_label(mercury__call_gen__generate_det_call_6_0_i8);
Declare_label(mercury__call_gen__generate_det_call_6_0_i9);
Declare_label(mercury__call_gen__generate_det_call_6_0_i10);
Declare_label(mercury__call_gen__generate_det_call_6_0_i11);
Declare_label(mercury__call_gen__generate_det_call_6_0_i12);
Declare_label(mercury__call_gen__generate_det_call_6_0_i13);
Declare_label(mercury__call_gen__generate_det_call_6_0_i14);
Declare_label(mercury__call_gen__generate_det_call_6_0_i15);
Define_extern_entry(mercury__call_gen__generate_semidet_call_6_0);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i2);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i3);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i4);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i5);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i6);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i7);
Declare_label(mercury__call_gen__generate_semidet_call_6_0_i8);
Define_extern_entry(mercury__call_gen__generate_nondet_call_6_0);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i2);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i3);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i4);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i5);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i6);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i7);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i8);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i9);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i10);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i11);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i12);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i13);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i14);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i15);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i16);
Declare_label(mercury__call_gen__generate_nondet_call_6_0_i17);
Define_extern_entry(mercury__call_gen__generate_det_builtin_6_0);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i2);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i3);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i4);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i7);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i9);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i12);
Declare_label(mercury__call_gen__generate_det_builtin_6_0_i6);
Define_extern_entry(mercury__call_gen__generate_semidet_builtin_6_0);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i2);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i3);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i4);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i7);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i13);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i14);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i10);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i18);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i15);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i19);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i21);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i22);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i26);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i23);
Declare_label(mercury__call_gen__generate_semidet_builtin_6_0_i6);
Define_extern_entry(mercury__call_gen__generate_nondet_builtin_6_0);
Declare_label(mercury__call_gen__generate_nondet_builtin_6_0_i2);
Define_extern_entry(mercury__call_gen__input_arg_locs_2_0);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i7);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i8);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i3);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i1);
Define_extern_entry(mercury__call_gen__output_arg_locs_2_0);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i7);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i8);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i3);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i1);
Define_extern_entry(mercury__call_gen__save_variables_4_0);
Declare_label(mercury__call_gen__save_variables_4_0_i2);
Declare_label(mercury__call_gen__save_variables_4_0_i3);
Declare_label(mercury__call_gen__save_variables_4_0_i4);
Declare_label(mercury__call_gen__save_variables_4_0_i5);
Declare_label(mercury__call_gen__save_variables_4_0_i6);
Declare_label(mercury__call_gen__save_variables_4_0_i10);
Declare_label(mercury__call_gen__save_variables_4_0_i11);
Declare_label(mercury__call_gen__save_variables_4_0_i12);
Declare_label(mercury__call_gen__save_variables_4_0_i7);
Declare_label(mercury__call_gen__save_variables_4_0_i13);
Declare_label(mercury__call_gen__save_variables_4_0_i14);
Declare_static(mercury__call_gen__generate_semidet_call_2_6_0);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i2);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i3);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i4);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i5);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i6);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i7);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i8);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i9);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i10);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i11);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i12);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i13);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i14);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i15);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i16);
Declare_label(mercury__call_gen__generate_semidet_call_2_6_0_i17);
Declare_static(mercury__call_gen__save_variables_2_4_0);
Declare_label(mercury__call_gen__save_variables_2_4_0_i4);
Declare_label(mercury__call_gen__save_variables_2_4_0_i5);
Declare_label(mercury__call_gen__save_variables_2_4_0_i1002);
Declare_static(mercury__call_gen__rebuild_registers_3_0);
Declare_label(mercury__call_gen__rebuild_registers_3_0_i2);
Declare_static(mercury__call_gen__rebuild_registers_2_3_0);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i7);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i8);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i1003);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i1005);
Declare_static(mercury__call_gen__generate_builtin_arg_5_0);
Declare_label(mercury__call_gen__generate_builtin_arg_5_0_i5);
Declare_label(mercury__call_gen__generate_builtin_arg_5_0_i1002);
Declare_static(mercury__call_gen__partition_args_3_0);
Declare_label(mercury__call_gen__partition_args_3_0_i7);
Declare_label(mercury__call_gen__partition_args_3_0_i4);
Declare_label(mercury__call_gen__partition_args_3_0_i8);
Declare_label(mercury__call_gen__partition_args_3_0_i1004);
Declare_static(mercury__call_gen__select_out_args_2_0);
Declare_label(mercury__call_gen__select_out_args_2_0_i4);
Declare_label(mercury__call_gen__select_out_args_2_0_i5);
Declare_label(mercury__call_gen__select_out_args_2_0_i1005);
Declare_static(mercury__call_gen__input_args_2_0);
Declare_label(mercury__call_gen__input_args_2_0_i7);
Declare_label(mercury__call_gen__input_args_2_0_i8);
Declare_label(mercury__call_gen__input_args_2_0_i3);
Declare_label(mercury__call_gen__input_args_2_0_i1);
Declare_static(mercury__call_gen__generate_call_livevals_5_0);
Declare_label(mercury__call_gen__generate_call_livevals_5_0_i2);
Declare_label(mercury__call_gen__generate_call_livevals_5_0_i3);
Declare_static(mercury__call_gen__insert_arg_livevals_3_0);
Declare_label(mercury__call_gen__insert_arg_livevals_3_0_i4);
Declare_label(mercury__call_gen__insert_arg_livevals_3_0_i5);
Declare_label(mercury__call_gen__insert_arg_livevals_3_0_i1002);
Declare_static(mercury__call_gen__generate_return_livevals_5_0);
Declare_label(mercury__call_gen__generate_return_livevals_5_0_i2);
Declare_label(mercury__call_gen__generate_return_livevals_5_0_i3);
Declare_label(mercury__call_gen__generate_return_livevals_5_0_i4);
Declare_static(mercury__call_gen__insert_arg_livelvals_6_0);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i7);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i8);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i9);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i10);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i11);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i12);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i13);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i16);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i17);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i18);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i4);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i19);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i20);
Declare_label(mercury__call_gen__insert_arg_livelvals_6_0_i1009);
Declare_static(mercury__call_gen__generate_higher_call_7_0);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i2);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i3);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i4);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i8);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i5);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i9);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i10);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i11);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i12);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i13);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i16);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i17);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i18);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i19);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i20);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i21);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i27);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i28);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i29);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i30);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i32);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i33);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i34);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i31);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i35);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i39);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i40);
Declare_label(mercury__call_gen__generate_higher_call_7_0_i36);
Declare_static(mercury__call_gen__generate_immediate_args_6_0);
Declare_label(mercury__call_gen__generate_immediate_args_6_0_i4);
Declare_label(mercury__call_gen__generate_immediate_args_6_0_i5);
Declare_label(mercury__call_gen__generate_immediate_args_6_0_i1005);
Declare_static(mercury__call_gen__outvars_to_outargs_3_0);
Declare_label(mercury__call_gen__outvars_to_outargs_3_0_i3);
Declare_label(mercury__call_gen__outvars_to_outargs_3_0_i4);
Declare_label(mercury__call_gen__outvars_to_outargs_3_0_i1);

Word mercury_data_call_gen__common_0[] = {
	((Integer) 1)
};

Word * mercury_data_call_gen__common_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_call_gen__common_0)
};

Word * mercury_data_call_gen__common_2[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_1)
};

Word mercury_data_call_gen__common_3[] = {
	((Integer) 1),
	((Integer) 0),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_call_gen__common_4[] = {
	((Integer) 2)
};

Word * mercury_data_call_gen__common_5[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_call_gen__common_4)
};

Word mercury_data_call_gen__common_6[] = {
	((Integer) 3)
};

Word * mercury_data_call_gen__common_7[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_call_gen__common_6)
};

BEGIN_MODULE(mercury__call_gen_module0)
	init_entry(mercury__call_gen__generate_nondet_builtin__ua10000_6_0);
	init_label(mercury__call_gen__generate_nondet_builtin__ua10000_6_0_i2);
BEGIN_CODE

/* code for predicate 'call_gen__generate_nondet_builtin__ua10000'/6 in mode 0 */
Define_static(mercury__call_gen__generate_nondet_builtin__ua10000_6_0);
	incr_sp_push_msg(2, "call_gen__generate_nondet_builtin__ua10000");
	detstackvar(1) = (Integer) r1;
	r1 = string_const("Unknown nondet builtin predicate", 32);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__call_gen__generate_nondet_builtin__ua10000_6_0_i2,
		STATIC(mercury__call_gen__generate_nondet_builtin__ua10000_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_builtin__ua10000_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_builtin__ua10000_6_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module1)
	init_entry(mercury__call_gen__generate_higher_order_call__ua10000_9_0);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i2);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i3);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i4);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i5);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i6);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i7);
	init_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i8);
BEGIN_CODE

/* code for predicate 'call_gen__generate_higher_order_call__ua10000'/9 in mode 0 */
Define_static(mercury__call_gen__generate_higher_order_call__ua10000_9_0);
	incr_sp_push_msg(8, "call_gen__generate_higher_order_call__ua10000");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i2,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	}
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i3,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	}
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i4,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	}
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__globals__get_args_method_2_0);
	call_localret(ENTRY(mercury__globals__get_args_method_2_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i5,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	}
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__arg_info__make_arg_infos_6_0);
	call_localret(ENTRY(mercury__arg_info__make_arg_infos_6_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i6,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	}
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i7,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	}
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	call_localret(STATIC(mercury__call_gen__partition_args_3_0),
		mercury__call_gen__generate_higher_order_call__ua10000_9_0_i8,
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
Define_label(mercury__call_gen__generate_higher_order_call__ua10000_9_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__call_gen__generate_higher_call_7_0),
		STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module2)
	init_entry(mercury__call_gen__generate_higher_order_call_9_0);
BEGIN_CODE

/* code for predicate 'call_gen__generate_higher_order_call'/9 in mode 0 */
Define_entry(mercury__call_gen__generate_higher_order_call_9_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	tailcall(STATIC(mercury__call_gen__generate_higher_order_call__ua10000_9_0),
		ENTRY(mercury__call_gen__generate_higher_order_call_9_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module3)
	init_entry(mercury__call_gen__generate_det_call_6_0);
	init_label(mercury__call_gen__generate_det_call_6_0_i2);
	init_label(mercury__call_gen__generate_det_call_6_0_i3);
	init_label(mercury__call_gen__generate_det_call_6_0_i4);
	init_label(mercury__call_gen__generate_det_call_6_0_i5);
	init_label(mercury__call_gen__generate_det_call_6_0_i6);
	init_label(mercury__call_gen__generate_det_call_6_0_i7);
	init_label(mercury__call_gen__generate_det_call_6_0_i8);
	init_label(mercury__call_gen__generate_det_call_6_0_i9);
	init_label(mercury__call_gen__generate_det_call_6_0_i10);
	init_label(mercury__call_gen__generate_det_call_6_0_i11);
	init_label(mercury__call_gen__generate_det_call_6_0_i12);
	init_label(mercury__call_gen__generate_det_call_6_0_i13);
	init_label(mercury__call_gen__generate_det_call_6_0_i14);
	init_label(mercury__call_gen__generate_det_call_6_0_i15);
BEGIN_CODE

/* code for predicate 'call_gen__generate_det_call'/6 in mode 0 */
Define_entry(mercury__call_gen__generate_det_call_6_0);
	incr_sp_push_msg(11, "call_gen__generate_det_call");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_pred_proc_arginfo_5_0);
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__call_gen__generate_det_call_6_0_i2,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__call_gen__generate_det_call_6_0_i3,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	detstackvar(4) = (Integer) r1;
	call_localret(STATIC(mercury__call_gen__select_out_args_2_0),
		mercury__call_gen__generate_det_call_6_0_i4,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
Define_label(mercury__call_gen__generate_det_call_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
		call_localret(STATIC(mercury__call_gen__save_variables_4_0),
		mercury__call_gen__generate_det_call_6_0_i5,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r3 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__call_gen__generate_det_call_6_0_i6,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_det_call_6_0_i7,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_det_call_6_0_i8,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__call_gen__input_args_2_0),
		mercury__call_gen__generate_det_call_6_0_i9,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
Define_label(mercury__call_gen__generate_det_call_6_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__call_gen__generate_call_livevals_5_0),
		mercury__call_gen__generate_det_call_6_0_i10,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
Define_label(mercury__call_gen__generate_det_call_6_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__call_gen__output_arg_locs_2_0),
		mercury__call_gen__generate_det_call_6_0_i11,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__call_gen__generate_return_livevals_5_0),
		mercury__call_gen__generate_det_call_6_0_i12,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
Define_label(mercury__call_gen__generate_det_call_6_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__make_entry_label_7_0);
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__call_gen__generate_det_call_6_0_i13,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	detstackvar(1) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(r9, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) r9, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r9, ((Integer) 3)) = (Integer) r3;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("branch to det procedure", 23);
	field(mktag(3), (Integer) r9, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) r3;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("Continuation label", 18);
	{
	Declare_entry(mercury__code_info__clear_all_registers_2_0);
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__call_gen__generate_det_call_6_0_i14,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
	}
	}
Define_label(mercury__call_gen__generate_det_call_6_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__call_gen__rebuild_registers_2_3_0),
		mercury__call_gen__generate_det_call_6_0_i15,
		ENTRY(mercury__call_gen__generate_det_call_6_0));
Define_label(mercury__call_gen__generate_det_call_6_0_i15);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module4)
	init_entry(mercury__call_gen__generate_semidet_call_6_0);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i2);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i3);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i4);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i5);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i6);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i7);
	init_label(mercury__call_gen__generate_semidet_call_6_0_i8);
BEGIN_CODE

/* code for predicate 'call_gen__generate_semidet_call'/6 in mode 0 */
Define_entry(mercury__call_gen__generate_semidet_call_6_0);
	incr_sp_push_msg(5, "call_gen__generate_semidet_call");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_semidet_call_6_0_i2,
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_6_0));
	detstackvar(4) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__call_gen__generate_semidet_call_6_0_i3,
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_6_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__call_gen__generate_semidet_call_6_0_i4,
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_6_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__call_gen__generate_semidet_call_6_0_i5,
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__call_gen__generate_semidet_call_6_0_i6,
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_6_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_6_0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__call_gen__generate_semidet_call_6_0_i7,
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_6_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_semidet_call_6_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__call_gen__generate_semidet_call_2_6_0),
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
Define_label(mercury__call_gen__generate_semidet_call_6_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__call_gen__generate_nondet_call_6_0),
		ENTRY(mercury__call_gen__generate_semidet_call_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module5)
	init_entry(mercury__call_gen__generate_nondet_call_6_0);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i2);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i3);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i4);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i5);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i6);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i7);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i8);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i9);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i10);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i11);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i12);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i13);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i14);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i15);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i16);
	init_label(mercury__call_gen__generate_nondet_call_6_0_i17);
BEGIN_CODE

/* code for predicate 'call_gen__generate_nondet_call'/6 in mode 0 */
Define_entry(mercury__call_gen__generate_nondet_call_6_0);
	incr_sp_push_msg(12, "call_gen__generate_nondet_call");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_pred_proc_arginfo_5_0);
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__call_gen__generate_nondet_call_6_0_i2,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__call_gen__generate_nondet_call_6_0_i3,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	detstackvar(4) = (Integer) r1;
	call_localret(STATIC(mercury__call_gen__select_out_args_2_0),
		mercury__call_gen__generate_nondet_call_6_0_i4,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
Define_label(mercury__call_gen__generate_nondet_call_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
		call_localret(STATIC(mercury__call_gen__save_variables_4_0),
		mercury__call_gen__generate_nondet_call_6_0_i5,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__unset_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__unset_failure_cont_3_0),
		mercury__call_gen__generate_nondet_call_6_0_i6,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r3 = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__call_gen__generate_nondet_call_6_0_i7,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_nondet_call_6_0_i8,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_nondet_call_6_0_i9,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__call_gen__input_args_2_0),
		mercury__call_gen__generate_nondet_call_6_0_i10,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
Define_label(mercury__call_gen__generate_nondet_call_6_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__call_gen__generate_call_livevals_5_0),
		mercury__call_gen__generate_nondet_call_6_0_i11,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
Define_label(mercury__call_gen__generate_nondet_call_6_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__call_gen__output_arg_locs_2_0),
		mercury__call_gen__generate_nondet_call_6_0_i12,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__call_gen__generate_return_livevals_5_0),
		mercury__call_gen__generate_nondet_call_6_0_i13,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
Define_label(mercury__call_gen__generate_nondet_call_6_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__make_entry_label_7_0);
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__call_gen__generate_nondet_call_6_0_i14,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__may_use_nondet_tailcall_3_0);
	call_localret(ENTRY(mercury__code_info__may_use_nondet_tailcall_3_0),
		mercury__call_gen__generate_nondet_call_6_0_i15,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i15);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("branch to nondet procedure", 26);
	field(mktag(3), (Integer) r6, ((Integer) 4)) = (Integer) r3;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("Continuation label", 18);
	{
	Declare_entry(mercury__code_info__clear_all_registers_2_0);
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__call_gen__generate_nondet_call_6_0_i16,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
	}
	}
Define_label(mercury__call_gen__generate_nondet_call_6_0_i16);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__call_gen__rebuild_registers_2_3_0),
		mercury__call_gen__generate_nondet_call_6_0_i17,
		ENTRY(mercury__call_gen__generate_nondet_call_6_0));
Define_label(mercury__call_gen__generate_nondet_call_6_0_i17);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_call_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module6)
	init_entry(mercury__call_gen__generate_det_builtin_6_0);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i2);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i3);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i4);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i7);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i9);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i12);
	init_label(mercury__call_gen__generate_det_builtin_6_0_i6);
BEGIN_CODE

/* code for predicate 'call_gen__generate_det_builtin'/6 in mode 0 */
Define_entry(mercury__call_gen__generate_det_builtin_6_0);
	incr_sp_push_msg(6, "call_gen__generate_det_builtin");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_det_builtin_6_0_i2,
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_det_builtin_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_builtin_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_module_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__call_gen__generate_det_builtin_6_0_i3,
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_det_builtin_6_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_builtin_6_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__call_gen__generate_det_builtin_6_0_i4,
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_det_builtin_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_builtin_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_util__translate_builtin_6_0);
	call_localret(ENTRY(mercury__code_util__translate_builtin_6_0),
		mercury__call_gen__generate_det_builtin_6_0_i7,
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_det_builtin_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_builtin_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__call_gen__generate_det_builtin_6_0_i6);
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r2;
	{
	extern Word * mercury_data_llds__base_type_info_rval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_rval_0;
	}
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___std_util__maybe_1_0);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury__call_gen__generate_det_builtin_6_0_i9,
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_det_builtin_6_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_builtin_6_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__call_gen__generate_det_builtin_6_0_i6);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__generate_det_builtin_6_0_i6);
	tempr2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__call_gen__generate_det_builtin_6_0_i12,
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
	}
Define_label(mercury__call_gen__generate_det_builtin_6_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_det_builtin_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__call_gen__generate_det_builtin_6_0_i6);
	r1 = string_const("Unknown builtin predicate", 25);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__call_gen__generate_det_builtin_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module7)
	init_entry(mercury__call_gen__generate_semidet_builtin_6_0);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i2);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i3);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i4);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i7);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i13);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i14);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i10);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i18);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i15);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i19);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i21);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i22);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i26);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i23);
	init_label(mercury__call_gen__generate_semidet_builtin_6_0_i6);
BEGIN_CODE

/* code for predicate 'call_gen__generate_semidet_builtin'/6 in mode 0 */
Define_entry(mercury__call_gen__generate_semidet_builtin_6_0);
	incr_sp_push_msg(6, "call_gen__generate_semidet_builtin");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i2,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_module_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i3,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i4,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_util__translate_builtin_6_0);
	call_localret(ENTRY(mercury__code_util__translate_builtin_6_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i7,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i6);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i6);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i10);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i10);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__call_gen__generate_builtin_arg_5_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i13,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) tempr1;
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__call_gen__generate_builtin_arg_5_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i14,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	r6 = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) tempr1;
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) r6;
	GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i21);
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i10);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i15);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i15);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__call_gen__generate_builtin_arg_5_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i18,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i18);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(1);
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r5;
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r4;
	r4 = (Integer) tempr1;
	GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i21);
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i15);
	detstackvar(1) = (Integer) r3;
	r1 = string_const("Unknown builtin predicate", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i19,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i19);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i21);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__code_info__generate_test_and_fail_4_0);
	call_localret(ENTRY(mercury__code_info__generate_test_and_fail_4_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i22,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i22);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	if (((Integer) detstackvar(1) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__generate_semidet_builtin_6_0_i23);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__call_gen__generate_semidet_builtin_6_0_i26,
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
	}
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i26);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_builtin_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i23);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__call_gen__generate_semidet_builtin_6_0_i6);
	r1 = string_const("Unknown builtin predicate", 25);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__call_gen__generate_semidet_builtin_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module8)
	init_entry(mercury__call_gen__generate_nondet_builtin_6_0);
	init_label(mercury__call_gen__generate_nondet_builtin_6_0_i2);
BEGIN_CODE

/* code for predicate 'call_gen__generate_nondet_builtin'/6 in mode 0 */
Define_entry(mercury__call_gen__generate_nondet_builtin_6_0);
	incr_sp_push_msg(4, "call_gen__generate_nondet_builtin");
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__call_gen__generate_nondet_builtin__ua10000_6_0),
		mercury__call_gen__generate_nondet_builtin_6_0_i2,
		ENTRY(mercury__call_gen__generate_nondet_builtin_6_0));
Define_label(mercury__call_gen__generate_nondet_builtin_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_nondet_builtin_6_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module9)
	init_entry(mercury__call_gen__input_arg_locs_2_0);
	init_label(mercury__call_gen__input_arg_locs_2_0_i7);
	init_label(mercury__call_gen__input_arg_locs_2_0_i8);
	init_label(mercury__call_gen__input_arg_locs_2_0_i3);
	init_label(mercury__call_gen__input_arg_locs_2_0_i1);
BEGIN_CODE

/* code for predicate 'call_gen__input_arg_locs'/2 in mode 0 */
Define_entry(mercury__call_gen__input_arg_locs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__input_arg_locs_2_0_i1);
	r4 = (Integer) sp;
Define_label(mercury__call_gen__input_arg_locs_2_0_i7);
	while (1) {
	incr_sp_push_msg(3, "call_gen__input_arg_locs");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__call_gen__input_arg_locs_2_0_i8);
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__call_gen__input_arg_locs_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__call_gen__input_arg_locs_2_0_i3);
	decr_sp_pop_msg(3);
	if (((Integer) sp > (Integer) r4))
		GOTO_LABEL(mercury__call_gen__input_arg_locs_2_0_i8);
	proceed();
Define_label(mercury__call_gen__input_arg_locs_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module10)
	init_entry(mercury__call_gen__output_arg_locs_2_0);
	init_label(mercury__call_gen__output_arg_locs_2_0_i7);
	init_label(mercury__call_gen__output_arg_locs_2_0_i8);
	init_label(mercury__call_gen__output_arg_locs_2_0_i3);
	init_label(mercury__call_gen__output_arg_locs_2_0_i1);
BEGIN_CODE

/* code for predicate 'call_gen__output_arg_locs'/2 in mode 0 */
Define_entry(mercury__call_gen__output_arg_locs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__output_arg_locs_2_0_i1);
	r4 = (Integer) sp;
Define_label(mercury__call_gen__output_arg_locs_2_0_i7);
	while (1) {
	incr_sp_push_msg(3, "call_gen__output_arg_locs");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__call_gen__output_arg_locs_2_0_i8);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__output_arg_locs_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__call_gen__output_arg_locs_2_0_i3);
	decr_sp_pop_msg(3);
	if (((Integer) sp > (Integer) r4))
		GOTO_LABEL(mercury__call_gen__output_arg_locs_2_0_i8);
	proceed();
Define_label(mercury__call_gen__output_arg_locs_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module11)
	init_entry(mercury__call_gen__save_variables_4_0);
	init_label(mercury__call_gen__save_variables_4_0_i2);
	init_label(mercury__call_gen__save_variables_4_0_i3);
	init_label(mercury__call_gen__save_variables_4_0_i4);
	init_label(mercury__call_gen__save_variables_4_0_i5);
	init_label(mercury__call_gen__save_variables_4_0_i6);
	init_label(mercury__call_gen__save_variables_4_0_i10);
	init_label(mercury__call_gen__save_variables_4_0_i11);
	init_label(mercury__call_gen__save_variables_4_0_i12);
	init_label(mercury__call_gen__save_variables_4_0_i7);
	init_label(mercury__call_gen__save_variables_4_0_i13);
	init_label(mercury__call_gen__save_variables_4_0_i14);
BEGIN_CODE

/* code for predicate 'call_gen__save_variables'/4 in mode 0 */
Define_entry(mercury__call_gen__save_variables_4_0);
	incr_sp_push_msg(3, "call_gen__save_variables");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_live_variables_3_0);
	call_localret(ENTRY(mercury__code_info__get_live_variables_3_0),
		mercury__call_gen__save_variables_4_0_i2,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__call_gen__save_variables_4_0_i3,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__call_gen__save_variables_4_0_i4,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__call_gen__save_variables_4_0_i5,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__globals__get_gc_method_2_0);
	call_localret(ENTRY(mercury__globals__get_gc_method_2_0),
		mercury__call_gen__save_variables_4_0_i6,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__call_gen__save_variables_4_0_i7);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__get_proc_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__call_gen__save_variables_4_0_i10,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0),
		mercury__call_gen__save_variables_4_0_i11,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__call_gen__save_variables_4_0_i12,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(2);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	GOTO_LABEL(mercury__call_gen__save_variables_4_0_i13);
Define_label(mercury__call_gen__save_variables_4_0_i7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
Define_label(mercury__call_gen__save_variables_4_0_i13);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__call_gen__save_variables_4_0_i14,
		ENTRY(mercury__call_gen__save_variables_4_0));
	}
Define_label(mercury__call_gen__save_variables_4_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__call_gen__save_variables_2_4_0),
		ENTRY(mercury__call_gen__save_variables_4_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module12)
	init_entry(mercury__call_gen__generate_semidet_call_2_6_0);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i2);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i3);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i4);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i5);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i6);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i7);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i8);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i9);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i10);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i11);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i12);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i13);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i14);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i15);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i16);
	init_label(mercury__call_gen__generate_semidet_call_2_6_0_i17);
BEGIN_CODE

/* code for predicate 'call_gen__generate_semidet_call_2'/6 in mode 0 */
Define_static(mercury__call_gen__generate_semidet_call_2_6_0);
	incr_sp_push_msg(11, "call_gen__generate_semidet_call_2");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__code_info__get_pred_proc_arginfo_5_0);
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i2,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i3,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	detstackvar(4) = (Integer) r1;
	call_localret(STATIC(mercury__call_gen__select_out_args_2_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i4,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
		call_localret(STATIC(mercury__call_gen__save_variables_4_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i5,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r3 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__setup_call_5_0);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i6,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i7,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i8,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__call_gen__input_args_2_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i9,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__call_gen__generate_call_livevals_5_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i10,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__call_gen__output_arg_locs_2_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i11,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__call_gen__generate_return_livevals_5_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i12,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r5 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__make_entry_label_7_0);
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i13,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) r6, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) r3;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("branch to semidet procedure", 27);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	r1 = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("Continuation label", 18);
	{
	Declare_entry(mercury__code_info__clear_all_registers_2_0);
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i14,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__call_gen__rebuild_registers_2_3_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i15,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i15);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i16,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i16);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_semidet_call_2_6_0_i17,
		STATIC(mercury__call_gen__generate_semidet_call_2_6_0));
	}
Define_label(mercury__call_gen__generate_semidet_call_2_6_0_i17);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_semidet_call_2_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	tag_incr_hp(r10, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r10, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_call_gen__common_2);
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("Test for success", 16);
	field(mktag(3), (Integer) r10, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r8, mktag(1), ((Integer) 1));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module13)
	init_entry(mercury__call_gen__save_variables_2_4_0);
	init_label(mercury__call_gen__save_variables_2_4_0_i4);
	init_label(mercury__call_gen__save_variables_2_4_0_i5);
	init_label(mercury__call_gen__save_variables_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'call_gen__save_variables_2'/4 in mode 0 */
Define_static(mercury__call_gen__save_variables_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__save_variables_2_4_0_i1002);
	incr_sp_push_msg(2, "call_gen__save_variables_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__code_info__save_variable_on_stack_4_0);
	call_localret(ENTRY(mercury__code_info__save_variable_on_stack_4_0),
		mercury__call_gen__save_variables_2_4_0_i4,
		STATIC(mercury__call_gen__save_variables_2_4_0));
	}
Define_label(mercury__call_gen__save_variables_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_2_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__call_gen__save_variables_2_4_0,
		LABEL(mercury__call_gen__save_variables_2_4_0_i5),
		STATIC(mercury__call_gen__save_variables_2_4_0));
Define_label(mercury__call_gen__save_variables_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_2_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__save_variables_2_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module14)
	init_entry(mercury__call_gen__rebuild_registers_3_0);
	init_label(mercury__call_gen__rebuild_registers_3_0_i2);
BEGIN_CODE

/* code for predicate 'call_gen__rebuild_registers'/3 in mode 0 */
Define_static(mercury__call_gen__rebuild_registers_3_0);
	incr_sp_push_msg(2, "call_gen__rebuild_registers");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__clear_all_registers_2_0);
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__call_gen__rebuild_registers_3_0_i2,
		STATIC(mercury__call_gen__rebuild_registers_3_0));
	}
Define_label(mercury__call_gen__rebuild_registers_3_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__rebuild_registers_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__call_gen__rebuild_registers_2_3_0),
		STATIC(mercury__call_gen__rebuild_registers_3_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module15)
	init_entry(mercury__call_gen__rebuild_registers_2_3_0);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i7);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i8);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i1003);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i1005);
BEGIN_CODE

/* code for predicate 'call_gen__rebuild_registers_2'/3 in mode 0 */
Define_static(mercury__call_gen__rebuild_registers_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__rebuild_registers_2_3_0_i1003);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1, tempr2, tempr3;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) tempr3, ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__rebuild_registers_2_3_0_i1005);
	incr_sp_push_msg(4, "call_gen__rebuild_registers_2");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) tempr3, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__code_util__arg_loc_to_register_2_0);
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__call_gen__rebuild_registers_2_3_0_i7,
		STATIC(mercury__call_gen__rebuild_registers_2_3_0));
	}
	}
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__rebuild_registers_2_3_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__set_var_location_4_0);
	call_localret(ENTRY(mercury__code_info__set_var_location_4_0),
		mercury__call_gen__rebuild_registers_2_3_0_i8,
		STATIC(mercury__call_gen__rebuild_registers_2_3_0));
	}
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__rebuild_registers_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__call_gen__rebuild_registers_2_3_0,
		STATIC(mercury__call_gen__rebuild_registers_2_3_0));
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i1005);
	r1 = (Integer) r3;
	localtailcall(mercury__call_gen__rebuild_registers_2_3_0,
		STATIC(mercury__call_gen__rebuild_registers_2_3_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module16)
	init_entry(mercury__call_gen__generate_builtin_arg_5_0);
	init_label(mercury__call_gen__generate_builtin_arg_5_0_i5);
	init_label(mercury__call_gen__generate_builtin_arg_5_0_i1002);
BEGIN_CODE

/* code for predicate 'call_gen__generate_builtin_arg'/5 in mode 0 */
Define_static(mercury__call_gen__generate_builtin_arg_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__call_gen__generate_builtin_arg_5_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(1, "call_gen__generate_builtin_arg");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__call_gen__generate_builtin_arg_5_0_i5,
		STATIC(mercury__call_gen__generate_builtin_arg_5_0));
	}
Define_label(mercury__call_gen__generate_builtin_arg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_arg_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
Define_label(mercury__call_gen__generate_builtin_arg_5_0_i1002);
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module17)
	init_entry(mercury__call_gen__partition_args_3_0);
	init_label(mercury__call_gen__partition_args_3_0_i7);
	init_label(mercury__call_gen__partition_args_3_0_i4);
	init_label(mercury__call_gen__partition_args_3_0_i8);
	init_label(mercury__call_gen__partition_args_3_0_i1004);
BEGIN_CODE

/* code for predicate 'call_gen__partition_args'/3 in mode 0 */
Define_static(mercury__call_gen__partition_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__partition_args_3_0_i1004);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	incr_sp_push_msg(2, "call_gen__partition_args");
	detstackvar(2) = (Integer) succip;
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__call_gen__partition_args_3_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__call_gen__partition_args_3_0,
		LABEL(mercury__call_gen__partition_args_3_0_i7),
		STATIC(mercury__call_gen__partition_args_3_0));
Define_label(mercury__call_gen__partition_args_3_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__partition_args_3_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__partition_args_3_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__call_gen__partition_args_3_0,
		LABEL(mercury__call_gen__partition_args_3_0_i8),
		STATIC(mercury__call_gen__partition_args_3_0));
Define_label(mercury__call_gen__partition_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__partition_args_3_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__partition_args_3_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module18)
	init_entry(mercury__call_gen__select_out_args_2_0);
	init_label(mercury__call_gen__select_out_args_2_0_i4);
	init_label(mercury__call_gen__select_out_args_2_0_i5);
	init_label(mercury__call_gen__select_out_args_2_0_i1005);
BEGIN_CODE

/* code for predicate 'call_gen__select_out_args'/2 in mode 0 */
Define_static(mercury__call_gen__select_out_args_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__select_out_args_2_0_i1005);
	incr_sp_push_msg(3, "call_gen__select_out_args");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r2, ((Integer) 1)), ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__call_gen__select_out_args_2_0,
		LABEL(mercury__call_gen__select_out_args_2_0_i4),
		STATIC(mercury__call_gen__select_out_args_2_0));
Define_label(mercury__call_gen__select_out_args_2_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__select_out_args_2_0));
	if (((Integer) detstackvar(2) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__select_out_args_2_0_i5);
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	tailcall(ENTRY(mercury__set__insert_3_1),
		STATIC(mercury__call_gen__select_out_args_2_0));
	}
Define_label(mercury__call_gen__select_out_args_2_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__call_gen__select_out_args_2_0_i1005);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	tailcall(ENTRY(mercury__set__init_1_0),
		STATIC(mercury__call_gen__select_out_args_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module19)
	init_entry(mercury__call_gen__input_args_2_0);
	init_label(mercury__call_gen__input_args_2_0_i7);
	init_label(mercury__call_gen__input_args_2_0_i8);
	init_label(mercury__call_gen__input_args_2_0_i3);
	init_label(mercury__call_gen__input_args_2_0_i1);
BEGIN_CODE

/* code for predicate 'call_gen__input_args'/2 in mode 0 */
Define_static(mercury__call_gen__input_args_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__input_args_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__call_gen__input_args_2_0_i7);
	while (1) {
	incr_sp_push_msg(2, "call_gen__input_args");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__call_gen__input_args_2_0_i8);
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__call_gen__input_args_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__call_gen__input_args_2_0_i3);
	decr_sp_pop_msg(2);
	if (((Integer) sp > (Integer) r3))
		GOTO_LABEL(mercury__call_gen__input_args_2_0_i8);
	proceed();
Define_label(mercury__call_gen__input_args_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module20)
	init_entry(mercury__call_gen__generate_call_livevals_5_0);
	init_label(mercury__call_gen__generate_call_livevals_5_0_i2);
	init_label(mercury__call_gen__generate_call_livevals_5_0_i3);
BEGIN_CODE

/* code for predicate 'call_gen__generate_call_livevals'/5 in mode 0 */
Define_static(mercury__call_gen__generate_call_livevals_5_0);
	incr_sp_push_msg(2, "call_gen__generate_call_livevals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__generate_stack_livevals_4_0);
	call_localret(ENTRY(mercury__code_info__generate_stack_livevals_4_0),
		mercury__call_gen__generate_call_livevals_5_0_i2,
		STATIC(mercury__call_gen__generate_call_livevals_5_0));
	}
Define_label(mercury__call_gen__generate_call_livevals_5_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_livevals_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__call_gen__insert_arg_livevals_3_0),
		mercury__call_gen__generate_call_livevals_5_0_i3,
		STATIC(mercury__call_gen__generate_call_livevals_5_0));
Define_label(mercury__call_gen__generate_call_livevals_5_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_livevals_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module21)
	init_entry(mercury__call_gen__insert_arg_livevals_3_0);
	init_label(mercury__call_gen__insert_arg_livevals_3_0_i4);
	init_label(mercury__call_gen__insert_arg_livevals_3_0_i5);
	init_label(mercury__call_gen__insert_arg_livevals_3_0_i1002);
BEGIN_CODE

/* code for predicate 'call_gen__insert_arg_livevals'/3 in mode 0 */
Define_static(mercury__call_gen__insert_arg_livevals_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__insert_arg_livevals_3_0_i1002);
	incr_sp_push_msg(3, "call_gen__insert_arg_livevals");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__code_util__arg_loc_to_register_2_0);
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__call_gen__insert_arg_livevals_3_0_i4,
		STATIC(mercury__call_gen__insert_arg_livevals_3_0));
	}
Define_label(mercury__call_gen__insert_arg_livevals_3_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livevals_3_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__call_gen__insert_arg_livevals_3_0_i5,
		STATIC(mercury__call_gen__insert_arg_livevals_3_0));
	}
Define_label(mercury__call_gen__insert_arg_livevals_3_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livevals_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__call_gen__insert_arg_livevals_3_0,
		STATIC(mercury__call_gen__insert_arg_livevals_3_0));
Define_label(mercury__call_gen__insert_arg_livevals_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module22)
	init_entry(mercury__call_gen__generate_return_livevals_5_0);
	init_label(mercury__call_gen__generate_return_livevals_5_0_i2);
	init_label(mercury__call_gen__generate_return_livevals_5_0_i3);
	init_label(mercury__call_gen__generate_return_livevals_5_0_i4);
BEGIN_CODE

/* code for predicate 'call_gen__generate_return_livevals'/5 in mode 0 */
Define_static(mercury__call_gen__generate_return_livevals_5_0);
	incr_sp_push_msg(4, "call_gen__generate_return_livevals");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__generate_stack_livelvals_4_0);
	call_localret(ENTRY(mercury__code_info__generate_stack_livelvals_4_0),
		mercury__call_gen__generate_return_livevals_5_0_i2,
		STATIC(mercury__call_gen__generate_return_livevals_5_0));
	}
Define_label(mercury__call_gen__generate_return_livevals_5_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_return_livevals_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__call_gen__generate_return_livevals_5_0_i3,
		STATIC(mercury__call_gen__generate_return_livevals_5_0));
	}
Define_label(mercury__call_gen__generate_return_livevals_5_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_return_livevals_5_0));
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__globals__get_gc_method_2_0);
	call_localret(ENTRY(mercury__globals__get_gc_method_2_0),
		mercury__call_gen__generate_return_livevals_5_0_i4,
		STATIC(mercury__call_gen__generate_return_livevals_5_0));
	}
Define_label(mercury__call_gen__generate_return_livevals_5_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_return_livevals_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__call_gen__insert_arg_livelvals_6_0),
		STATIC(mercury__call_gen__generate_return_livevals_5_0));
END_MODULE

BEGIN_MODULE(mercury__call_gen_module23)
	init_entry(mercury__call_gen__insert_arg_livelvals_6_0);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i7);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i8);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i9);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i10);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i11);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i12);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i13);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i16);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i17);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i18);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i4);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i19);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i20);
	init_label(mercury__call_gen__insert_arg_livelvals_6_0_i1009);
BEGIN_CODE

/* code for predicate 'call_gen__insert_arg_livelvals'/6 in mode 0 */
Define_static(mercury__call_gen__insert_arg_livelvals_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__insert_arg_livelvals_6_0_i1009);
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r6 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	incr_sp_push_msg(8, "call_gen__insert_arg_livelvals");
	detstackvar(8) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__call_gen__insert_arg_livelvals_6_0_i4);
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r5;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_shapes_3_0);
	call_localret(ENTRY(mercury__code_info__get_shapes_3_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i7,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i8,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i9,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i10,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_call_gen__common_3);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__shapes__request_shape_number_5_0);
	call_localret(ENTRY(mercury__shapes__request_shape_number_5_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i11,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	{
	Declare_entry(mercury__type_util__vars_2_0);
	call_localret(ENTRY(mercury__type_util__vars_2_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i12,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__insert_arg_livelvals_6_0_i13);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__call_gen__insert_arg_livelvals_6_0_i17);
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i13);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__code_info__find_type_infos_4_0);
	call_localret(ENTRY(mercury__code_info__find_type_infos_4_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i16,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i16);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	tag_incr_hp(r8, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i17);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	{
	Declare_entry(mercury__code_info__set_shapes_3_0);
	call_localret(ENTRY(mercury__code_info__set_shapes_3_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i18,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i18);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__call_gen__insert_arg_livelvals_6_0_i19);
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i4);
	r1 = (Integer) r6;
	r7 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = ((Integer) 0);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i19);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	{
	Declare_entry(mercury__code_util__arg_loc_to_register_2_0);
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__call_gen__insert_arg_livelvals_6_0_i20,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i20);
	update_prof_current_proc(LABEL(mercury__call_gen__insert_arg_livelvals_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 3));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	r4 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r5, ((Integer) 2)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__call_gen__insert_arg_livelvals_6_0,
		STATIC(mercury__call_gen__insert_arg_livelvals_6_0));
	}
Define_label(mercury__call_gen__insert_arg_livelvals_6_0_i1009);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module24)
	init_entry(mercury__call_gen__generate_higher_call_7_0);
	init_label(mercury__call_gen__generate_higher_call_7_0_i2);
	init_label(mercury__call_gen__generate_higher_call_7_0_i3);
	init_label(mercury__call_gen__generate_higher_call_7_0_i4);
	init_label(mercury__call_gen__generate_higher_call_7_0_i8);
	init_label(mercury__call_gen__generate_higher_call_7_0_i5);
	init_label(mercury__call_gen__generate_higher_call_7_0_i9);
	init_label(mercury__call_gen__generate_higher_call_7_0_i10);
	init_label(mercury__call_gen__generate_higher_call_7_0_i11);
	init_label(mercury__call_gen__generate_higher_call_7_0_i12);
	init_label(mercury__call_gen__generate_higher_call_7_0_i13);
	init_label(mercury__call_gen__generate_higher_call_7_0_i16);
	init_label(mercury__call_gen__generate_higher_call_7_0_i17);
	init_label(mercury__call_gen__generate_higher_call_7_0_i18);
	init_label(mercury__call_gen__generate_higher_call_7_0_i19);
	init_label(mercury__call_gen__generate_higher_call_7_0_i20);
	init_label(mercury__call_gen__generate_higher_call_7_0_i21);
	init_label(mercury__call_gen__generate_higher_call_7_0_i27);
	init_label(mercury__call_gen__generate_higher_call_7_0_i28);
	init_label(mercury__call_gen__generate_higher_call_7_0_i29);
	init_label(mercury__call_gen__generate_higher_call_7_0_i30);
	init_label(mercury__call_gen__generate_higher_call_7_0_i32);
	init_label(mercury__call_gen__generate_higher_call_7_0_i33);
	init_label(mercury__call_gen__generate_higher_call_7_0_i34);
	init_label(mercury__call_gen__generate_higher_call_7_0_i31);
	init_label(mercury__call_gen__generate_higher_call_7_0_i35);
	init_label(mercury__call_gen__generate_higher_call_7_0_i39);
	init_label(mercury__call_gen__generate_higher_call_7_0_i40);
	init_label(mercury__call_gen__generate_higher_call_7_0_i36);
BEGIN_CODE

/* code for predicate 'call_gen__generate_higher_call'/7 in mode 0 */
Define_static(mercury__call_gen__generate_higher_call_7_0);
	incr_sp_push_msg(12, "call_gen__generate_higher_call");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = ((Integer) 0);
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__code_info__set_succip_used_3_0);
	call_localret(ENTRY(mercury__code_info__set_succip_used_3_0),
		mercury__call_gen__generate_higher_call_7_0_i2,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__call_gen__generate_higher_call_7_0_i3,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
		call_localret(STATIC(mercury__call_gen__save_variables_4_0),
		mercury__call_gen__generate_higher_call_7_0_i4,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	if (((Integer) detstackvar(1) != ((Integer) 2)))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i5);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__unset_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__unset_failure_cont_3_0),
		mercury__call_gen__generate_higher_call_7_0_i8,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r3 = (Integer) r2;
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 4);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i9);
Define_label(mercury__call_gen__generate_higher_call_7_0_i5);
	r3 = (Integer) r2;
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 4);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__call_gen__generate_higher_call_7_0_i9);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	call_localret(STATIC(mercury__call_gen__generate_immediate_args_6_0),
		mercury__call_gen__generate_higher_call_7_0_i10,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
Define_label(mercury__call_gen__generate_higher_call_7_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	detstackvar(8) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__generate_stack_livevals_4_0);
	call_localret(ENTRY(mercury__code_info__generate_stack_livevals_4_0),
		mercury__call_gen__generate_higher_call_7_0_i11,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	detstackvar(11) = (Integer) r2;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_1);
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_7);
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__call_gen__generate_higher_call_7_0_i12,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i13);
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i16);
Define_label(mercury__call_gen__generate_higher_call_7_0_i13);
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(11);
Define_label(mercury__call_gen__generate_higher_call_7_0_i16);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	call_localret(STATIC(mercury__call_gen__outvars_to_outargs_3_0),
		mercury__call_gen__generate_higher_call_7_0_i17,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
Define_label(mercury__call_gen__generate_higher_call_7_0_i17);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	detstackvar(10) = (Integer) r1;
	{
		call_localret(STATIC(mercury__call_gen__output_arg_locs_2_0),
		mercury__call_gen__generate_higher_call_7_0_i18,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i18);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__call_gen__generate_return_livevals_5_0),
		mercury__call_gen__generate_higher_call_7_0_i19,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
Define_label(mercury__call_gen__generate_higher_call_7_0_i19);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__call_gen__generate_higher_call_7_0_i20,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i20);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i21);
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i21);
	if ((tag((Integer) field(mktag(1), (Integer) r4, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i21);
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r4, ((Integer) 0)), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i21);
	r11 = (Integer) r1;
	r13 = (Integer) r3;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(2);
	r12 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i27);
Define_label(mercury__call_gen__generate_higher_call_7_0_i21);
	r13 = (Integer) r2;
	r14 = (Integer) r3;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(2);
	r11 = (Integer) r1;
	tag_incr_hp(r12, mktag(1), ((Integer) 1));
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r13;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_1);
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("Copy pred-term", 14);
	r13 = (Integer) r14;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i27);
	detstackvar(1) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(10) = (Integer) r9;
	detstackvar(2) = (Integer) r10;
	detstackvar(3) = (Integer) r11;
	detstackvar(5) = (Integer) r12;
	detstackvar(11) = (Integer) r13;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__generate_higher_call_7_0_i28,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i28);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__generate_higher_call_7_0_i29,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i29);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(4) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_5);
	tag_incr_hp(r7, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("Assign number of immediate input arguments", 42);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) r7;
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	tag_incr_hp(r7, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_call_gen__common_7);
	tag_incr_hp(r8, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	field(mktag(3), (Integer) r7, ((Integer) 2)) = (Integer) r8;
	field(mktag(2), (Integer) detstackvar(4), ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("Assign number of output arguments", 33);
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_higher_call_7_0_i30,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i30);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	if (((Integer) detstackvar(1) != ((Integer) 0)))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i32);
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(3);
	r8 = (Integer) detstackvar(4);
	tag_incr_hp(r9, mktag(1), ((Integer) 1));
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r12, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	field(mktag(3), (Integer) r14, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r14, ((Integer) 3)) = (Integer) detstackvar(2);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("setup and call higher order pred", 32);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r10;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r14, ((Integer) 1)) = string_const("Continuation label", 18);
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i31);
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i32);
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i33);
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(3);
	r8 = (Integer) detstackvar(4);
	tag_incr_hp(r9, mktag(1), ((Integer) 1));
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r12, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 4)));
	field(mktag(3), (Integer) r14, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	field(mktag(3), (Integer) r14, ((Integer) 3)) = (Integer) detstackvar(2);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("setup and call higher order pred", 32);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r10;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r14, ((Integer) 1)) = string_const("Continuation label", 18);
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i31);
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i33);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__may_use_nondet_tailcall_3_0);
	call_localret(ENTRY(mercury__code_info__may_use_nondet_tailcall_3_0),
		mercury__call_gen__generate_higher_call_7_0_i34,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i34);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(3);
	r8 = (Integer) detstackvar(4);
	tag_incr_hp(r9, mktag(1), ((Integer) 1));
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r12, ((Integer) 1)) = string_const("", 0);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 5)));
	field(mktag(3), (Integer) r14, ((Integer) 3)) = (Integer) detstackvar(2);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("setup and call higher order pred", 32);
	field(mktag(3), (Integer) r14, ((Integer) 4)) = (Integer) tempr1;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r14, ((Integer) 1)) = string_const("Continuation label", 18);
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i31);
	detstackvar(1) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(9) = (Integer) r6;
	detstackvar(3) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	detstackvar(2) = (Integer) r9;
	call_localret(STATIC(mercury__call_gen__rebuild_registers_3_0),
		mercury__call_gen__generate_higher_call_7_0_i35,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
Define_label(mercury__call_gen__generate_higher_call_7_0_i35);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_higher_call_7_0_i36);
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__call_gen__generate_higher_call_7_0_i39,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i39);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_higher_call_7_0_i40,
		STATIC(mercury__call_gen__generate_higher_call_7_0));
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i40);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_higher_call_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	tag_incr_hp(r10, mktag(1), ((Integer) 1));
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	tag_incr_hp(r13, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r13, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r13, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_call_gen__common_2);
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r12, ((Integer) 1)) = string_const("Test for success", 16);
	field(mktag(3), (Integer) r13, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	tag_incr_hp(r10, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r11, mktag(1), ((Integer) 1));
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(2), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("", 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__call_gen__generate_higher_call_7_0_i36);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__call_gen_module25)
	init_entry(mercury__call_gen__generate_immediate_args_6_0);
	init_label(mercury__call_gen__generate_immediate_args_6_0_i4);
	init_label(mercury__call_gen__generate_immediate_args_6_0_i5);
	init_label(mercury__call_gen__generate_immediate_args_6_0_i1005);
BEGIN_CODE

/* code for predicate 'call_gen__generate_immediate_args'/6 in mode 0 */
Define_static(mercury__call_gen__generate_immediate_args_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__generate_immediate_args_6_0_i1005);
	incr_sp_push_msg(4, "call_gen__generate_immediate_args");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	tag_incr_hp(detstackvar(3), mktag(1), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) detstackvar(3), ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) detstackvar(3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__code_info__place_var_5_0);
	call_localret(ENTRY(mercury__code_info__place_var_5_0),
		mercury__call_gen__generate_immediate_args_6_0_i4,
		STATIC(mercury__call_gen__generate_immediate_args_6_0));
	}
	}
Define_label(mercury__call_gen__generate_immediate_args_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_immediate_args_6_0));
	r3 = (Integer) r2;
	r2 = ((Integer) detstackvar(1) + ((Integer) 1));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__call_gen__generate_immediate_args_6_0,
		LABEL(mercury__call_gen__generate_immediate_args_6_0_i5),
		STATIC(mercury__call_gen__generate_immediate_args_6_0));
Define_label(mercury__call_gen__generate_immediate_args_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_immediate_args_6_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__call_gen__generate_immediate_args_6_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__call_gen_module26)
	init_entry(mercury__call_gen__outvars_to_outargs_3_0);
	init_label(mercury__call_gen__outvars_to_outargs_3_0_i3);
	init_label(mercury__call_gen__outvars_to_outargs_3_0_i4);
	init_label(mercury__call_gen__outvars_to_outargs_3_0_i1);
BEGIN_CODE

/* code for predicate 'call_gen__outvars_to_outargs'/3 in mode 0 */
Define_static(mercury__call_gen__outvars_to_outargs_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__call_gen__outvars_to_outargs_3_0_i1);
	r4 = (Integer) sp;
Define_label(mercury__call_gen__outvars_to_outargs_3_0_i3);
	while (1) {
	incr_sp_push_msg(1, "call_gen__outvars_to_outargs");
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = ((Integer) 1);
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = ((Integer) r2 + ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__call_gen__outvars_to_outargs_3_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r4))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__call_gen__outvars_to_outargs_3_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__call_gen_bunch_0(void)
{
	mercury__call_gen_module0();
	mercury__call_gen_module1();
	mercury__call_gen_module2();
	mercury__call_gen_module3();
	mercury__call_gen_module4();
	mercury__call_gen_module5();
	mercury__call_gen_module6();
	mercury__call_gen_module7();
	mercury__call_gen_module8();
	mercury__call_gen_module9();
	mercury__call_gen_module10();
	mercury__call_gen_module11();
	mercury__call_gen_module12();
	mercury__call_gen_module13();
	mercury__call_gen_module14();
	mercury__call_gen_module15();
	mercury__call_gen_module16();
	mercury__call_gen_module17();
	mercury__call_gen_module18();
	mercury__call_gen_module19();
	mercury__call_gen_module20();
	mercury__call_gen_module21();
	mercury__call_gen_module22();
	mercury__call_gen_module23();
	mercury__call_gen_module24();
	mercury__call_gen_module25();
	mercury__call_gen_module26();
}

#endif

void mercury__call_gen__init(void); /* suppress gcc warning */
void mercury__call_gen__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__call_gen_bunch_0();
#endif
}
