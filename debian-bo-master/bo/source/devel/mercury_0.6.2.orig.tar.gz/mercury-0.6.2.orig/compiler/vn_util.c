/*
** Automatically generated from `vn_util.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_util__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__vn_util__find_specials_2_0);
Declare_label(mercury__vn_util__find_specials_2_0_i5);
Declare_label(mercury__vn_util__find_specials_2_0_i6);
Declare_label(mercury__vn_util__find_specials_2_0_i4);
Declare_label(mercury__vn_util__find_specials_2_0_i13);
Declare_label(mercury__vn_util__find_specials_2_0_i14);
Declare_label(mercury__vn_util__find_specials_2_0_i15);
Declare_label(mercury__vn_util__find_specials_2_0_i16);
Declare_label(mercury__vn_util__find_specials_2_0_i17);
Declare_label(mercury__vn_util__find_specials_2_0_i12);
Declare_label(mercury__vn_util__find_specials_2_0_i18);
Define_extern_entry(mercury__vn_util__convert_to_vnlval_and_insert_3_0);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1003);
Define_extern_entry(mercury__vn_util__rval_to_vn_4_0);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i6);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i5);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i8);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i11);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i10);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i13);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i14);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i1000);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i16);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i18);
Define_extern_entry(mercury__vn_util__lval_to_vn_4_0);
Declare_label(mercury__vn_util__lval_to_vn_4_0_i2);
Declare_label(mercury__vn_util__lval_to_vn_4_0_i5);
Declare_label(mercury__vn_util__lval_to_vn_4_0_i4);
Define_extern_entry(mercury__vn_util__lval_to_vnlval_4_0);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i2);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i3);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i9);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i10);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i6);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i14);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1016);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i18);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i15);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i22);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1020);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i26);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i23);
Define_extern_entry(mercury__vn_util__is_const_expr_3_0);
Declare_label(mercury__vn_util__is_const_expr_3_0_i2);
Declare_label(mercury__vn_util__is_const_expr_3_0_i6);
Declare_label(mercury__vn_util__is_const_expr_3_0_i7);
Declare_label(mercury__vn_util__is_const_expr_3_0_i9);
Declare_label(mercury__vn_util__is_const_expr_3_0_i10);
Declare_label(mercury__vn_util__is_const_expr_3_0_i5);
Declare_label(mercury__vn_util__is_const_expr_3_0_i12);
Declare_label(mercury__vn_util__is_const_expr_3_0_i13);
Define_extern_entry(mercury__vn_util__vnlval_access_vns_2_0);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i5);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i6);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i10);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i4);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i18);
Define_extern_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i15);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i16);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i17);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i18);
Define_extern_entry(mercury__vn_util__no_access_lval_to_vnlval_2_0);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1029);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1028);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1027);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i15);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i16);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i17);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i18);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i19);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i20);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1021);
Define_extern_entry(mercury__vn_util__find_sub_vns_2_0);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i1002);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i6);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i1001);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i7);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i9);
Define_extern_entry(mercury__vn_util__find_sub_vns_vnlval_2_0);
Declare_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i5);
Declare_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i6);
Declare_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i10);
Declare_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i4);
Declare_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i18);
Define_extern_entry(mercury__vn_util__find_lvals_in_rval_2_0);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i1002);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i7);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i8);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i10);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i11);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i1001);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i14);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i15);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i13);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i1000);
Define_extern_entry(mercury__vn_util__find_lvals_in_rvals_2_0);
Declare_label(mercury__vn_util__find_lvals_in_rvals_2_0_i4);
Declare_label(mercury__vn_util__find_lvals_in_rvals_2_0_i5);
Declare_label(mercury__vn_util__find_lvals_in_rvals_2_0_i1002);
Define_extern_entry(mercury__vn_util__is_vn_shared_4_0);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i2);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i3);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i7);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i1);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i1000);
Define_extern_entry(mercury__vn_util__real_uses_3_0);
Declare_label(mercury__vn_util__real_uses_3_0_i1037);
Declare_label(mercury__vn_util__real_uses_3_0_i4);
Declare_label(mercury__vn_util__real_uses_3_0_i8);
Declare_label(mercury__vn_util__real_uses_3_0_i7);
Declare_label(mercury__vn_util__real_uses_3_0_i15);
Declare_label(mercury__vn_util__real_uses_3_0_i17);
Declare_label(mercury__vn_util__real_uses_3_0_i14);
Declare_label(mercury__vn_util__real_uses_3_0_i10);
Declare_label(mercury__vn_util__real_uses_3_0_i25);
Declare_label(mercury__vn_util__real_uses_3_0_i27);
Declare_label(mercury__vn_util__real_uses_3_0_i31);
Declare_label(mercury__vn_util__real_uses_3_0_i36);
Declare_label(mercury__vn_util__real_uses_3_0_i38);
Declare_label(mercury__vn_util__real_uses_3_0_i35);
Declare_label(mercury__vn_util__real_uses_3_0_i40);
Declare_label(mercury__vn_util__real_uses_3_0_i42);
Declare_label(mercury__vn_util__real_uses_3_0_i44);
Declare_label(mercury__vn_util__real_uses_3_0_i30);
Declare_label(mercury__vn_util__real_uses_3_0_i1035);
Declare_label(mercury__vn_util__real_uses_3_0_i1);
Define_extern_entry(mercury__vn_util__choose_cheapest_loc_2_0);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_0_i2);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_0_i1000);
Define_extern_entry(mercury__vn_util__classify_loc_cost_2_0);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i5);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i10);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i11);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i4);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i18);
Declare_static(mercury__vn_util__vnrval_to_vn_4_0);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i2);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i5);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i4);
Declare_static(mercury__vn_util__simplify_vnrval_4_0);
Declare_label(mercury__vn_util__simplify_vnrval_4_0_i5);
Declare_label(mercury__vn_util__simplify_vnrval_4_0_i3);
Declare_label(mercury__vn_util__simplify_vnrval_4_0_i1004);
Declare_static(mercury__vn_util__simplify_vnrval_binop_6_0);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i2);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i3);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i5);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i18);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i13);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i32);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i28);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i42);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i47);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i38);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i54);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i59);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i65);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i71);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i66);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i79);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i80);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i89);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i103);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i104);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i112);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i122);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i126);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i139);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i149);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i156);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i160);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i161);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i166);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i169);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i172);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i175);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i178);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i181);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i184);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i187);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i190);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i203);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i198);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i217);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i222);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i213);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i227);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i232);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i235);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i223);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i239);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i244);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i250);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i255);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i264);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i265);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i274);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i282);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i285);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i288);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i291);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i297);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i298);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
Declare_static(mercury__vn_util__const_if_equal_vns_4_0);
Declare_label(mercury__vn_util__const_if_equal_vns_4_0_i1);
Declare_static(mercury__vn_util__choose_cheapest_loc_2_4_0);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1013);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1012);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i10);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i16);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i13);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i18);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1010);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1011);
Define_extern_entry(mercury__vn_util__build_uses_4_0);
Declare_label(mercury__vn_util__build_uses_4_0_i2);
Declare_label(mercury__vn_util__build_uses_4_0_i3);
Declare_static(mercury__vn_util__build_uses_from_ctrl_4_0);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i4);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i9);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i12);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i13);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i14);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i16);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1009);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i19);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i21);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1011);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i24);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i8);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
Declare_static(mercury__vn_util__build_uses_from_livevals_3_0);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i6);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i5);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i8);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i9);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i10);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i11);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i1005);
Declare_static(mercury__vn_util__record_access_3_0);
Declare_label(mercury__vn_util__record_access_3_0_i4);
Declare_label(mercury__vn_util__record_access_3_0_i5);
Declare_label(mercury__vn_util__record_access_3_0_i1002);
Declare_static(mercury__vn_util__record_use_4_0);
Declare_label(mercury__vn_util__record_use_4_0_i2);
Declare_label(mercury__vn_util__record_use_4_0_i3);
Declare_label(mercury__vn_util__record_use_4_0_i7);
Declare_label(mercury__vn_util__record_use_4_0_i11);
Declare_label(mercury__vn_util__record_use_4_0_i12);
Declare_label(mercury__vn_util__record_use_4_0_i14);
Declare_label(mercury__vn_util__record_use_4_0_i10);
Declare_label(mercury__vn_util__record_use_4_0_i16);
Declare_label(mercury__vn_util__record_use_4_0_i18);
Declare_label(mercury__vn_util__record_use_4_0_i20);
Declare_static(mercury__vn_util__record_use_list_4_0);
Declare_label(mercury__vn_util__record_use_list_4_0_i4);
Declare_label(mercury__vn_util__record_use_list_4_0_i1002);

Word mercury_data_vn_util__common_0[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_util__common_1[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_util__common_2[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 2))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_util__common_3[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 3))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_util__common_4[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 4))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_util__common_5[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_vn_util__common_6[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word mercury_data_vn_util__common_7[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 2)))
};

Word mercury_data_vn_util__common_8[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 3)))
};

Word mercury_data_vn_util__common_9[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 4)))
};

Word mercury_data_vn_util__common_10[] = {
	((Integer) 0)
};

Word * mercury_data_vn_util__common_11[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_10)
};

static const Float mercury_float_const_0 = 0;
Word * mercury_data_vn_util__common_12[] = {
	(Word *) (Word)(&mercury_float_const_0)
};

Word * mercury_data_vn_util__common_13[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_12)
};

BEGIN_MODULE(mercury__vn_util_module0)
	init_entry(mercury__vn_util__find_specials_2_0);
	init_label(mercury__vn_util__find_specials_2_0_i5);
	init_label(mercury__vn_util__find_specials_2_0_i6);
	init_label(mercury__vn_util__find_specials_2_0_i4);
	init_label(mercury__vn_util__find_specials_2_0_i13);
	init_label(mercury__vn_util__find_specials_2_0_i14);
	init_label(mercury__vn_util__find_specials_2_0_i15);
	init_label(mercury__vn_util__find_specials_2_0_i16);
	init_label(mercury__vn_util__find_specials_2_0_i17);
	init_label(mercury__vn_util__find_specials_2_0_i12);
	init_label(mercury__vn_util__find_specials_2_0_i18);
BEGIN_CODE

/* code for predicate 'vn_util__find_specials'/2 in mode 0 */
Define_entry(mercury__vn_util__find_specials_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__find_specials_2_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_util__find_specials_2_0_i5) AND
		LABEL(mercury__vn_util__find_specials_2_0_i6) AND
		LABEL(mercury__vn_util__find_specials_2_0_i6) AND
		LABEL(mercury__vn_util__find_specials_2_0_i6) AND
		LABEL(mercury__vn_util__find_specials_2_0_i6) AND
		LABEL(mercury__vn_util__find_specials_2_0_i5) AND
		LABEL(mercury__vn_util__find_specials_2_0_i5));
Define_label(mercury__vn_util__find_specials_2_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__find_specials_2_0_i12);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__vn_util__find_specials_2_0_i13) AND
		LABEL(mercury__vn_util__find_specials_2_0_i14) AND
		LABEL(mercury__vn_util__find_specials_2_0_i15) AND
		LABEL(mercury__vn_util__find_specials_2_0_i16) AND
		LABEL(mercury__vn_util__find_specials_2_0_i17));
Define_label(mercury__vn_util__find_specials_2_0_i13);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_0);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i14);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_1);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i15);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_2);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i16);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_3);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i17);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_4);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__find_specials_2_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module1)
	init_entry(mercury__vn_util__convert_to_vnlval_and_insert_3_0);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1003);
BEGIN_CODE

/* code for predicate 'vn_util__convert_to_vnlval_and_insert'/3 in mode 0 */
Define_entry(mercury__vn_util__convert_to_vnlval_and_insert_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1003);
	incr_sp_push_msg(3, "vn_util__convert_to_vnlval_and_insert");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__vn_util__no_access_lval_to_vnlval_2_0),
		mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4,
		ENTRY(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
	}
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	}
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7,
		ENTRY(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
	}
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_util__convert_to_vnlval_and_insert_3_0,
		ENTRY(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_util__convert_to_vnlval_and_insert_3_0,
		ENTRY(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module2)
	init_entry(mercury__vn_util__rval_to_vn_4_0);
	init_label(mercury__vn_util__rval_to_vn_4_0_i6);
	init_label(mercury__vn_util__rval_to_vn_4_0_i5);
	init_label(mercury__vn_util__rval_to_vn_4_0_i8);
	init_label(mercury__vn_util__rval_to_vn_4_0_i11);
	init_label(mercury__vn_util__rval_to_vn_4_0_i10);
	init_label(mercury__vn_util__rval_to_vn_4_0_i13);
	init_label(mercury__vn_util__rval_to_vn_4_0_i14);
	init_label(mercury__vn_util__rval_to_vn_4_0_i1000);
	init_label(mercury__vn_util__rval_to_vn_4_0_i16);
	init_label(mercury__vn_util__rval_to_vn_4_0_i18);
BEGIN_CODE

/* code for predicate 'vn_util__rval_to_vn'/4 in mode 0 */
Define_entry(mercury__vn_util__rval_to_vn_4_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__rval_to_vn_4_0_i1000);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(3, "vn_util__rval_to_vn");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__rval_to_vn_4_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i6),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i5);
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__rval_to_vn_4_0_i8);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i8);
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__rval_to_vn_4_0_i10);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i11),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i10);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i13),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i14),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i1000);
	incr_sp_push_msg(3, "vn_util__rval_to_vn");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__rval_to_vn_4_0_i16);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__vn_util__lval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
	}
Define_label(mercury__vn_util__rval_to_vn_4_0_i16);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__rval_to_vn_4_0_i18);
	r1 = string_const("value_number should never get rval: var", 39);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
	}
Define_label(mercury__vn_util__rval_to_vn_4_0_i18);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 3));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
END_MODULE

BEGIN_MODULE(mercury__vn_util_module3)
	init_entry(mercury__vn_util__lval_to_vn_4_0);
	init_label(mercury__vn_util__lval_to_vn_4_0_i2);
	init_label(mercury__vn_util__lval_to_vn_4_0_i5);
	init_label(mercury__vn_util__lval_to_vn_4_0_i4);
BEGIN_CODE

/* code for predicate 'vn_util__lval_to_vn'/4 in mode 0 */
Define_entry(mercury__vn_util__lval_to_vn_4_0);
	incr_sp_push_msg(3, "vn_util__lval_to_vn");
	detstackvar(3) = (Integer) succip;
	{
		call_localret(STATIC(mercury__vn_util__lval_to_vnlval_4_0),
		mercury__vn_util__lval_to_vn_4_0_i2,
		ENTRY(mercury__vn_util__lval_to_vn_4_0));
	}
Define_label(mercury__vn_util__lval_to_vn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vn_4_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__lval_to_vn_4_0_i5,
		ENTRY(mercury__vn_util__lval_to_vn_4_0));
	}
Define_label(mercury__vn_util__lval_to_vn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vn_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__lval_to_vn_4_0_i4);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vn_4_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__vn_table__record_first_vnlval_4_0);
	tailcall(ENTRY(mercury__vn_table__record_first_vnlval_4_0),
		ENTRY(mercury__vn_util__lval_to_vn_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_util_module4)
	init_entry(mercury__vn_util__lval_to_vnlval_4_0);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i2);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i3);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i9);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i10);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i6);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i14);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1016);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i18);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i15);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i22);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1020);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i26);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i23);
BEGIN_CODE

/* code for predicate 'vn_util__lval_to_vnlval'/4 in mode 0 */
Define_entry(mercury__vn_util__lval_to_vnlval_4_0);
	incr_sp_push_msg(3, "vn_util__lval_to_vnlval");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_util__no_access_lval_to_vnlval_2_0),
		mercury__vn_util__lval_to_vnlval_4_0_i2,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i3);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i6);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i6);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i9,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i10,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i6);
	r3 = (Integer) detstackvar(1);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1016);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1016);
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i14,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1016);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i15);
	r3 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 5)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i15);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i18,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i15);
	r3 = (Integer) detstackvar(1);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1020);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1020);
	r1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i22,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1020);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i23);
	r3 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i23);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i26,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i23);
	r1 = string_const("unexpected lval in vn_util__lval_to_vnlval", 42);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_util_module5)
	init_entry(mercury__vn_util__is_const_expr_3_0);
	init_label(mercury__vn_util__is_const_expr_3_0_i2);
	init_label(mercury__vn_util__is_const_expr_3_0_i6);
	init_label(mercury__vn_util__is_const_expr_3_0_i7);
	init_label(mercury__vn_util__is_const_expr_3_0_i9);
	init_label(mercury__vn_util__is_const_expr_3_0_i10);
	init_label(mercury__vn_util__is_const_expr_3_0_i5);
	init_label(mercury__vn_util__is_const_expr_3_0_i12);
	init_label(mercury__vn_util__is_const_expr_3_0_i13);
BEGIN_CODE

/* code for predicate 'vn_util__is_const_expr'/3 in mode 0 */
Define_entry(mercury__vn_util__is_const_expr_3_0);
	r3 = (Integer) r2;
	incr_sp_push_msg(3, "vn_util__is_const_expr");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = string_const("vn_util__is_const_expr", 22);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__is_const_expr_3_0_i2,
		ENTRY(mercury__vn_util__is_const_expr_3_0));
	}
Define_label(mercury__vn_util__is_const_expr_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__is_const_expr_3_0));
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i5);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i6);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__is_const_expr_3_0_i6);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i7);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_util__is_const_expr_3_0,
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i7);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) detstackvar(1);
	localcall(mercury__vn_util__is_const_expr_3_0,
		LABEL(mercury__vn_util__is_const_expr_3_0_i9),
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_util__is_const_expr_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__vn_util__is_const_expr_3_0,
		LABEL(mercury__vn_util__is_const_expr_3_0_i10),
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_util__is_const_expr_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__bool__and_3_0);
	tailcall(ENTRY(mercury__bool__and_3_0),
		ENTRY(mercury__vn_util__is_const_expr_3_0));
	}
Define_label(mercury__vn_util__is_const_expr_3_0_i5);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i12);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__is_const_expr_3_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i13);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_util__is_const_expr_3_0,
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i13);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module6)
	init_entry(mercury__vn_util__vnlval_access_vns_2_0);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i5);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i6);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i10);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i4);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i18);
BEGIN_CODE

/* code for predicate 'vn_util__vnlval_access_vns'/2 in mode 0 */
Define_entry(mercury__vn_util__vnlval_access_vns_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__vnlval_access_vns_2_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i5) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i6) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i6) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i6) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i6) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i10) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i5));
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i10);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	proceed();
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i4);
	if (((Integer) r2 == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__vnlval_access_vns_2_0_i5);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__vnlval_access_vns_2_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module7)
	init_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i15);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i16);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i17);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i18);
BEGIN_CODE

/* code for predicate 'vn_util__no_access_vnlval_to_lval'/2 in mode 0 */
Define_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11));
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i15) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i16) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i17));
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_5);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_6);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i15);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_7);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i16);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_8);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i17);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_9);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i18);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i18);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module8)
	init_entry(mercury__vn_util__no_access_lval_to_vnlval_2_0);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1029);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1028);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1027);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i15);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i16);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i17);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i18);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i19);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i20);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1021);
BEGIN_CODE

/* code for predicate 'vn_util__no_access_lval_to_vnlval'/2 in mode 0 */
Define_entry(mercury__vn_util__no_access_lval_to_vnlval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1027);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1029) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1028) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1021));
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1029);
	incr_sp_push_msg(1, "vn_util__no_access_lval_to_vnlval");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1028);
	incr_sp_push_msg(1, "vn_util__no_access_lval_to_vnlval");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1014);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1027);
	incr_sp_push_msg(1, "vn_util__no_access_lval_to_vnlval");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i15) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i16) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i17) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i18) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i19));
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i15);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i16);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i17);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i18);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i19);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_vn_util__common_9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i20);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i20);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i1021);
	r1 = string_const("lvar detected in value_number", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__no_access_lval_to_vnlval_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_util_module9)
	init_entry(mercury__vn_util__find_sub_vns_2_0);
	init_label(mercury__vn_util__find_sub_vns_2_0_i1002);
	init_label(mercury__vn_util__find_sub_vns_2_0_i6);
	init_label(mercury__vn_util__find_sub_vns_2_0_i1001);
	init_label(mercury__vn_util__find_sub_vns_2_0_i7);
	init_label(mercury__vn_util__find_sub_vns_2_0_i9);
BEGIN_CODE

/* code for predicate 'vn_util__find_sub_vns'/2 in mode 0 */
Define_entry(mercury__vn_util__find_sub_vns_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_2_0_i1001);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_2_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i1002);
	incr_sp_push_msg(1, "vn_util__find_sub_vns");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_2_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i1001);
	incr_sp_push_msg(1, "vn_util__find_sub_vns");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_2_0_i7);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__vn_util__find_sub_vns_vnlval_2_0),
		ENTRY(mercury__vn_util__find_sub_vns_2_0));
	}
Define_label(mercury__vn_util__find_sub_vns_2_0_i7);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_2_0_i9);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i9);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module10)
	init_entry(mercury__vn_util__find_sub_vns_vnlval_2_0);
	init_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i5);
	init_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i6);
	init_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i10);
	init_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i4);
	init_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i18);
BEGIN_CODE

/* code for predicate 'vn_util__find_sub_vns_vnlval'/2 in mode 0 */
Define_entry(mercury__vn_util__find_sub_vns_vnlval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i5) AND
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i6) AND
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i6) AND
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i6) AND
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i6) AND
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i10) AND
		LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i5));
Define_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i10);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	proceed();
Define_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i4);
	if (((Integer) r2 == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i5);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__find_sub_vns_vnlval_2_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_util__find_sub_vns_vnlval_2_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module11)
	init_entry(mercury__vn_util__find_lvals_in_rval_2_0);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i1002);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i7);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i8);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i10);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i11);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i1001);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i14);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i15);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i13);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_util__find_lvals_in_rval'/2 in mode 0 */
Define_entry(mercury__vn_util__find_lvals_in_rval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i1001);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i1002);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localtailcall(mercury__vn_util__find_lvals_in_rval_2_0,
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i1002);
	incr_sp_push_msg(2, "vn_util__find_lvals_in_rval");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i7);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i7);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__vn_util__find_lvals_in_rval_2_0,
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_util__find_lvals_in_rval_2_0,
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i10),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__vn_util__find_lvals_in_rval_2_0,
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i11),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__list__append_3_1);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
	}
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i1001);
	incr_sp_push_msg(2, "vn_util__find_lvals_in_rval");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i13);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__opt_util__lval_access_rvals_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_access_rvals_2_0),
		mercury__vn_util__find_lvals_in_rval_2_0_i14,
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
	}
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	{
		call_localret(STATIC(mercury__vn_util__find_lvals_in_rvals_2_0),
		mercury__vn_util__find_lvals_in_rval_2_0_i15,
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
	}
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i1000);
	r1 = string_const("var found in vn_util__find_lvals_in_rval", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
	}
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module12)
	init_entry(mercury__vn_util__find_lvals_in_rvals_2_0);
	init_label(mercury__vn_util__find_lvals_in_rvals_2_0_i4);
	init_label(mercury__vn_util__find_lvals_in_rvals_2_0_i5);
	init_label(mercury__vn_util__find_lvals_in_rvals_2_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_util__find_lvals_in_rvals'/2 in mode 0 */
Define_entry(mercury__vn_util__find_lvals_in_rvals_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rvals_2_0_i1002);
	incr_sp_push_msg(2, "vn_util__find_lvals_in_rvals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__vn_util__find_lvals_in_rval_2_0),
		mercury__vn_util__find_lvals_in_rvals_2_0_i4,
		ENTRY(mercury__vn_util__find_lvals_in_rvals_2_0));
	}
Define_label(mercury__vn_util__find_lvals_in_rvals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rvals_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__vn_util__find_lvals_in_rvals_2_0,
		LABEL(mercury__vn_util__find_lvals_in_rvals_2_0_i5),
		ENTRY(mercury__vn_util__find_lvals_in_rvals_2_0));
Define_label(mercury__vn_util__find_lvals_in_rvals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rvals_2_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__list__append_3_1);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__vn_util__find_lvals_in_rvals_2_0));
	}
Define_label(mercury__vn_util__find_lvals_in_rvals_2_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module13)
	init_entry(mercury__vn_util__is_vn_shared_4_0);
	init_label(mercury__vn_util__is_vn_shared_4_0_i2);
	init_label(mercury__vn_util__is_vn_shared_4_0_i3);
	init_label(mercury__vn_util__is_vn_shared_4_0_i7);
	init_label(mercury__vn_util__is_vn_shared_4_0_i1);
	init_label(mercury__vn_util__is_vn_shared_4_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_util__is_vn_shared'/4 in mode 0 */
Define_entry(mercury__vn_util__is_vn_shared_4_0);
	incr_sp_push_msg(4, "vn_util__is_vn_shared");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r2 = (Integer) r4;
	{
		call_localret(STATIC(mercury__vn_util__is_const_expr_3_0),
		mercury__vn_util__is_vn_shared_4_0_i2,
		ENTRY(mercury__vn_util__is_vn_shared_4_0));
	}
Define_label(mercury__vn_util__is_vn_shared_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__is_vn_shared_4_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i3);
	if (((Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
Define_label(mercury__vn_util__is_vn_shared_4_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__vn_util__real_uses_3_0),
		mercury__vn_util__is_vn_shared_4_0_i7,
		ENTRY(mercury__vn_util__is_vn_shared_4_0));
	}
Define_label(mercury__vn_util__is_vn_shared_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__is_vn_shared_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__is_vn_shared_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_util__is_vn_shared_4_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module14)
	init_entry(mercury__vn_util__real_uses_3_0);
	init_label(mercury__vn_util__real_uses_3_0_i1037);
	init_label(mercury__vn_util__real_uses_3_0_i4);
	init_label(mercury__vn_util__real_uses_3_0_i8);
	init_label(mercury__vn_util__real_uses_3_0_i7);
	init_label(mercury__vn_util__real_uses_3_0_i15);
	init_label(mercury__vn_util__real_uses_3_0_i17);
	init_label(mercury__vn_util__real_uses_3_0_i14);
	init_label(mercury__vn_util__real_uses_3_0_i10);
	init_label(mercury__vn_util__real_uses_3_0_i25);
	init_label(mercury__vn_util__real_uses_3_0_i27);
	init_label(mercury__vn_util__real_uses_3_0_i31);
	init_label(mercury__vn_util__real_uses_3_0_i36);
	init_label(mercury__vn_util__real_uses_3_0_i38);
	init_label(mercury__vn_util__real_uses_3_0_i35);
	init_label(mercury__vn_util__real_uses_3_0_i40);
	init_label(mercury__vn_util__real_uses_3_0_i42);
	init_label(mercury__vn_util__real_uses_3_0_i44);
	init_label(mercury__vn_util__real_uses_3_0_i30);
	init_label(mercury__vn_util__real_uses_3_0_i1035);
	init_label(mercury__vn_util__real_uses_3_0_i1);
BEGIN_CODE

/* code for predicate 'vn_util__real_uses'/3 in mode 0 */
Define_entry(mercury__vn_util__real_uses_3_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1037);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i1037);
	incr_sp_push_msg(5, "vn_util__real_uses");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__vn_util__real_uses_3_0,
		LABEL(mercury__vn_util__real_uses_3_0_i4),
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1);
	r3 = (Integer) r2;
	detstackvar(3) = (Integer) r2;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_util__real_uses_3_0_i8,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i7);
	r2 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i7);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i10);
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__real_uses_3_0_i15,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_util__real_uses_3_0_i17,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	if (((Integer) detstackvar(1) != (Integer) r2))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	r2 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i14);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i10);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1035);
	r1 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__real_uses_3_0_i25,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) field(mktag(2), (Integer) detstackvar(2), ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_current_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_util__real_uses_3_0_i27,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	if (((Integer) detstackvar(4) != (Integer) r2))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_uses_3_0);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_util__real_uses_3_0_i31,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i30);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	localcall(mercury__vn_util__real_uses_3_0,
		LABEL(mercury__vn_util__real_uses_3_0_i36),
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i36);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i35);
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_src_0;
	}
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__vn_util__real_uses_3_0_i38,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i35);
	r1 = TRUE;
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i35);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__search_current_locs_3_0);
	call_localret(ENTRY(mercury__vn_table__search_current_locs_3_0),
		mercury__vn_util__real_uses_3_0_i40,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_util__real_uses_3_0_i42,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_util__real_uses_3_0_i44,
		ENTRY(mercury__vn_util__real_uses_3_0));
	}
Define_label(mercury__vn_util__real_uses_3_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i14);
	r1 = TRUE;
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i30);
	r1 = TRUE;
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i1035);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module15)
	init_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	init_label(mercury__vn_util__choose_cheapest_loc_2_0_i2);
	init_label(mercury__vn_util__choose_cheapest_loc_2_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_util__choose_cheapest_loc'/2 in mode 0 */
Define_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(1, "vn_util__choose_cheapest_loc");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0),
		mercury__vn_util__choose_cheapest_loc_2_0_i2,
		ENTRY(mercury__vn_util__choose_cheapest_loc_2_0));
Define_label(mercury__vn_util__choose_cheapest_loc_2_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__choose_cheapest_loc_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module16)
	init_entry(mercury__vn_util__classify_loc_cost_2_0);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i5);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i10);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i11);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i4);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i18);
BEGIN_CODE

/* code for predicate 'vn_util__classify_loc_cost'/2 in mode 0 */
Define_entry(mercury__vn_util__classify_loc_cost_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__classify_loc_cost_2_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i5) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i5) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i5) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i5) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i5) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i10) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i11));
Define_label(mercury__vn_util__classify_loc_cost_2_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_util__classify_loc_cost_2_0_i10);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury__vn_util__classify_loc_cost_2_0_i11);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__vn_util__classify_loc_cost_2_0_i4);
	if (((Integer) r2 == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__classify_loc_cost_2_0_i11);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__classify_loc_cost_2_0_i18);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__vn_util__classify_loc_cost_2_0_i18);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module17)
	init_entry(mercury__vn_util__vnrval_to_vn_4_0);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i2);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i5);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i4);
BEGIN_CODE

/* code for predicate 'vn_util__vnrval_to_vn'/4 in mode 0 */
Define_static(mercury__vn_util__vnrval_to_vn_4_0);
	incr_sp_push_msg(3, "vn_util__vnrval_to_vn");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__vnrval_to_vn_4_0_i2,
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__vnrval_to_vn_4_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__vn_table__search_assigned_vn_3_0);
	call_localret(ENTRY(mercury__vn_table__search_assigned_vn_3_0),
		mercury__vn_util__vnrval_to_vn_4_0_i5,
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
	}
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__vnrval_to_vn_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__vnrval_to_vn_4_0_i4);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__vn_table__record_first_vnrval_4_0);
	tailcall(ENTRY(mercury__vn_table__record_first_vnrval_4_0),
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_util_module18)
	init_entry(mercury__vn_util__simplify_vnrval_4_0);
	init_label(mercury__vn_util__simplify_vnrval_4_0_i5);
	init_label(mercury__vn_util__simplify_vnrval_4_0_i3);
	init_label(mercury__vn_util__simplify_vnrval_4_0_i1004);
BEGIN_CODE

/* code for predicate 'vn_util__simplify_vnrval'/4 in mode 0 */
Define_static(mercury__vn_util__simplify_vnrval_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_4_0_i1004);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_4_0_i1004);
	incr_sp_push_msg(3, "vn_util__simplify_vnrval");
	detstackvar(3) = (Integer) succip;
	r4 = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_binop_6_0),
		mercury__vn_util__simplify_vnrval_4_0_i5,
		STATIC(mercury__vn_util__simplify_vnrval_4_0));
Define_label(mercury__vn_util__simplify_vnrval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_4_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_4_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_4_0_i1004);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module19)
	init_entry(mercury__vn_util__simplify_vnrval_binop_6_0);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i2);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i3);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i5);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i18);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i13);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i32);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i28);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i42);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i47);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i38);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i54);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i59);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i65);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i71);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i66);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i79);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i80);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i89);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i103);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i104);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i112);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i122);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i126);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i139);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i149);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i156);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i160);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i161);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i166);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i169);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i172);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i175);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i178);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i181);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i184);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i187);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i190);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i203);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i198);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i217);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i222);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i213);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i227);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i232);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i235);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i223);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i239);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i244);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i250);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i255);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i264);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i265);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i274);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i282);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i285);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i288);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i291);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i297);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i298);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
BEGIN_CODE

/* code for predicate 'vn_util__simplify_vnrval_binop'/6 in mode 0 */
Define_static(mercury__vn_util__simplify_vnrval_binop_6_0);
	incr_sp_push_msg(8, "vn_util__simplify_vnrval_binop");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r2;
	r2 = string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i2,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i3,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	COMPUTED_GOTO((Integer) detstackvar(1),
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i5) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i65) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i84) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i89) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i103) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i121) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i139) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i149) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i160) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i163) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i166) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i169) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i172) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i175) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i178) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i181) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i184) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i187) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i190) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i250) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i269) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i274) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i282) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i285) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i288) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i291) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i294) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i297));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i5);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = ((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) + (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)));
	r1 = TRUE;
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	detstackvar(1) = (Integer) r1;
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i18,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i13);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i13);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = ((Integer) detstackvar(7) + (Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r2, ((Integer) 0)), ((Integer) 0)));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i21,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i13);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	r2 = (Integer) detstackvar(5);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	r3 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i22);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i28);
	if (((Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i28);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 1));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i28);
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i32,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = ((Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r3, ((Integer) 0)), ((Integer) 0)) + (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i37,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i29);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i28);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i38);
	if (((Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i38);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 1));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i38);
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i42,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) tempr1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	tempr2 = (Integer) detstackvar(1);
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	r1 = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i47,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i47);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = ((Integer) detstackvar(7) + (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i50,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i37,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i39);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i38);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(5) = (Integer) r1;
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i54,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i59,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i59);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i65);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i66);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i66);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (((Integer) 0) - (Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r2, ((Integer) 0)), ((Integer) 0)));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i70,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i71,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i71);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i66);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	if ((tag((Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	if (((Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0)), ((Integer) 0)) == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	r1 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_11);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i79,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i79);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i80,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i80);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i71,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_11);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
	r2 = (Integer) detstackvar(5);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = ((Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0)), ((Integer) 0)) * (Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r1, ((Integer) 0)), ((Integer) 0)));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i89);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0)), ((Integer) 0));
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = ((Integer) r3 / (Integer) r1);
	r1 = TRUE;
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i103);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i104);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i104);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i104);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i112);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i112);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i112);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i122);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i122);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i122);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i126);
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i126);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i126);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i139);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_5);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r2 = string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i146,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) detstackvar(1) != (Integer) field(mktag(1), (Integer) r1, ((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_5);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i149);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_6);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r2 = string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i156,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i156);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) detstackvar(1) != (Integer) field(mktag(1), (Integer) r1, ((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_6);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i160);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i161);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i166);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i169);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i172);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i175);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i178);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i181);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i184);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i187);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i190);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = float_to_word(word_to_float((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) + word_to_float((Integer) field(mktag(2), (Integer) r3, ((Integer) 0))));
	r1 = TRUE;
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	detstackvar(1) = (Integer) r1;
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i203,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i203);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i198);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i198);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = float_to_word(word_to_float((Integer) detstackvar(7)) + word_to_float((Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) r2, ((Integer) 0)), ((Integer) 0))));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i206,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i198);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	r2 = (Integer) detstackvar(5);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	r3 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i213);
	if (((Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i213);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 1));
	if (((Integer) r2 != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i213);
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i217,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i217);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	r2 = (Integer) field(mktag(2), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = float_to_word(word_to_float((Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) r3, ((Integer) 0)), ((Integer) 0))) + word_to_float((Integer) field(mktag(2), (Integer) r2, ((Integer) 0))));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i222,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i222);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i213);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i223);
	if (((Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i223);
	r2 = (Integer) field(mktag(3), (Integer) detstackvar(5), ((Integer) 1));
	if (((Integer) r2 != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i223);
	detstackvar(1) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i227,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i227);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) tempr1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	tempr2 = (Integer) detstackvar(1);
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1)) != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	r1 = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) tempr1, ((Integer) 0));
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i232,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i232);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = float_to_word(word_to_float((Integer) detstackvar(7)) + word_to_float((Integer) field(mktag(2), (Integer) r3, ((Integer) 0))));
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i235,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i235);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i222,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i224);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i223);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1)) != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 3));
	detstackvar(5) = (Integer) r1;
	r2 = string_const("vn_util__simplify_vnrval", 24);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i239,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i239);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) detstackvar(1), ((Integer) 1)) != ((Integer) 25)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i244,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i244);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i250);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = float_to_word(((Float) 0.00000000000000) - word_to_float((Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) r2, ((Integer) 0)), ((Integer) 0))));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i255,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i255);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i71,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	if ((tag((Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	if ((word_to_float((Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0)), ((Integer) 0))) == ((Float) 0.00000000000000)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i72);
	r1 = (Integer) mkword(mktag(2), (Integer) mercury_data_vn_util__common_13);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i264,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i264);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 26);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i265,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i265);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 25);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i71,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	r2 = (Integer) detstackvar(5);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = float_to_word(word_to_float((Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0)), ((Integer) 0))) * word_to_float((Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) r1, ((Integer) 0)), ((Integer) 0))));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i274);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((tag((Integer) field(mktag(2), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r3 = (Integer) field(mktag(2), (Integer) field(mktag(2), (Integer) detstackvar(5), ((Integer) 0)), ((Integer) 0));
	if ((word_to_float((Integer) r2) == ((Float) 0.00000000000000)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = float_to_word(word_to_float((Integer) r3) / word_to_float((Integer) r1));
	r1 = TRUE;
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i282);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i285);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i288);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i291);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i161,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i297);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i298,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i298);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = (Integer) detstackvar(4);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module20)
	init_entry(mercury__vn_util__const_if_equal_vns_4_0);
	init_label(mercury__vn_util__const_if_equal_vns_4_0_i1);
BEGIN_CODE

/* code for predicate 'vn_util__const_if_equal_vns'/4 in mode 0 */
Define_static(mercury__vn_util__const_if_equal_vns_4_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury__vn_util__const_if_equal_vns_4_0_i1);
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__const_if_equal_vns_4_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module21)
	init_entry(mercury__vn_util__choose_cheapest_loc_2_4_0);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1013);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1012);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i10);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i16);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i13);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i18);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1010);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1011);
BEGIN_CODE

/* code for predicate 'vn_util__choose_cheapest_loc_2'/4 in mode 0 */
Define_static(mercury__vn_util__choose_cheapest_loc_2_4_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1012);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1013);
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1013);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1011);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1012);
	incr_sp_push_msg(5, "vn_util__choose_cheapest_loc_2");
	detstackvar(5) = (Integer) succip;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_util__choose_cheapest_loc_2_4_0_i9,
		STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0));
	}
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i10);
	r2 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i10);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i13);
	r1 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__vn_util__choose_cheapest_loc_2_4_0,
		LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i16),
		STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0));
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i13);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__vn_util__choose_cheapest_loc_2_4_0,
		LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i18),
		STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0));
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1011);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module22)
	init_entry(mercury__vn_util__build_uses_4_0);
	init_label(mercury__vn_util__build_uses_4_0_i2);
	init_label(mercury__vn_util__build_uses_4_0_i3);
BEGIN_CODE

/* code for predicate 'vn_util__build_uses'/4 in mode 0 */
Define_entry(mercury__vn_util__build_uses_4_0);
	incr_sp_push_msg(2, "vn_util__build_uses");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 0);
	call_localret(STATIC(mercury__vn_util__build_uses_from_ctrl_4_0),
		mercury__vn_util__build_uses_4_0_i2,
		ENTRY(mercury__vn_util__build_uses_4_0));
Define_label(mercury__vn_util__build_uses_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	}
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_util__build_uses_4_0_i3,
		ENTRY(mercury__vn_util__build_uses_4_0));
	}
Define_label(mercury__vn_util__build_uses_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__vn_util__build_uses_from_livevals_3_0),
		ENTRY(mercury__vn_util__build_uses_4_0));
END_MODULE

BEGIN_MODULE(mercury__vn_util_module23)
	init_entry(mercury__vn_util__build_uses_from_ctrl_4_0);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i4);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i9);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i12);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i13);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i14);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i16);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1009);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i19);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i21);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1011);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i24);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i8);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
BEGIN_CODE

/* code for predicate 'vn_util__build_uses_from_ctrl'/4 in mode 0 */
Define_static(mercury__vn_util__build_uses_from_ctrl_4_0);
	incr_sp_push_msg(4, "vn_util__build_uses_from_ctrl");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_instr_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	}
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_util__build_uses_from_ctrl_4_0_i4,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
	}
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_ctrl_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
	r1 = tag((Integer) r2);
	if (((Integer) r1 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i8);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)),
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i9) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i9) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i9) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i12) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i14) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i16) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i19) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i21) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i24) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i9) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i9));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i9);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__build_uses_from_ctrl_4_0,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i12);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i13,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_ctrl_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__build_uses_from_ctrl_4_0,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i13,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i16);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
		call_localret(STATIC(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i1009,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
	}
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1009);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_ctrl_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_list_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i13,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i19);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i13,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i21);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
		call_localret(STATIC(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i1011,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
	}
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1011);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_ctrl_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_list_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i13,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i24);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i13,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i8);
	if (((Integer) r1 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__build_uses_from_ctrl_4_0,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
	if (((Integer) r1 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__build_uses_from_ctrl_4_0,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__build_uses_from_ctrl_4_0,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module24)
	init_entry(mercury__vn_util__build_uses_from_livevals_3_0);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i6);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i5);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i8);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i9);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i10);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i11);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i1005);
BEGIN_CODE

/* code for predicate 'vn_util__build_uses_from_livevals'/3 in mode 0 */
Define_static(mercury__vn_util__build_uses_from_livevals_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__build_uses_from_livevals_3_0_i1005);
	incr_sp_push_msg(4, "vn_util__build_uses_from_livevals");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__vn_table__search_desired_value_3_0);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i6,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
	}
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_util__build_uses_from_livevals_3_0_i5);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	r4 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	GOTO_LABEL(mercury__vn_util__build_uses_from_livevals_3_0_i9);
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__record_first_vnlval_4_0);
	call_localret(ENTRY(mercury__vn_table__record_first_vnlval_4_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i8,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
	}
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	r3 = (Integer) r2;
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i9);
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i10,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__vn_util__record_access_3_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i11,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__build_uses_from_livevals_3_0,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i1005);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module25)
	init_entry(mercury__vn_util__record_access_3_0);
	init_label(mercury__vn_util__record_access_3_0_i4);
	init_label(mercury__vn_util__record_access_3_0_i5);
	init_label(mercury__vn_util__record_access_3_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_util__record_access'/3 in mode 0 */
Define_static(mercury__vn_util__record_access_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__record_access_3_0_i1002);
	incr_sp_push_msg(4, "vn_util__record_access");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_util__record_access_3_0_i4,
		STATIC(mercury__vn_util__record_access_3_0));
	}
Define_label(mercury__vn_util__record_access_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__record_access_3_0));
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_util__record_use_list_4_0),
		mercury__vn_util__record_access_3_0_i5,
		STATIC(mercury__vn_util__record_access_3_0));
Define_label(mercury__vn_util__record_access_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__record_access_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__record_access_3_0,
		STATIC(mercury__vn_util__record_access_3_0));
Define_label(mercury__vn_util__record_access_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module26)
	init_entry(mercury__vn_util__record_use_4_0);
	init_label(mercury__vn_util__record_use_4_0_i2);
	init_label(mercury__vn_util__record_use_4_0_i3);
	init_label(mercury__vn_util__record_use_4_0_i7);
	init_label(mercury__vn_util__record_use_4_0_i11);
	init_label(mercury__vn_util__record_use_4_0_i12);
	init_label(mercury__vn_util__record_use_4_0_i14);
	init_label(mercury__vn_util__record_use_4_0_i10);
	init_label(mercury__vn_util__record_use_4_0_i16);
	init_label(mercury__vn_util__record_use_4_0_i18);
	init_label(mercury__vn_util__record_use_4_0_i20);
BEGIN_CODE

/* code for predicate 'vn_util__record_use'/4 in mode 0 */
Define_static(mercury__vn_util__record_use_4_0);
	incr_sp_push_msg(4, "vn_util__record_use");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r2 = string_const("vn_util__record_use", 19);
	{
	Declare_entry(mercury__vn_table__lookup_uses_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_util__record_use_4_0_i2,
		STATIC(mercury__vn_util__record_use_4_0));
	}
Define_label(mercury__vn_util__record_use_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__vn_table__add_new_use_4_0);
	call_localret(ENTRY(mercury__vn_table__add_new_use_4_0),
		mercury__vn_util__record_use_4_0_i3,
		STATIC(mercury__vn_util__record_use_4_0));
	}
Define_label(mercury__vn_util__record_use_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i20);
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("vn_util__record_use", 19);
	{
	Declare_entry(mercury__vn_table__lookup_defn_4_0);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__record_use_4_0_i7,
		STATIC(mercury__vn_util__record_use_4_0));
	}
Define_label(mercury__vn_util__record_use_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i10);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i11);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_util__record_use_4_0_i11);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i12);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__record_use_4_0,
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i12);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(2) = (Integer) tempr1;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_util__record_use_4_0,
		LABEL(mercury__vn_util__record_use_4_0_i14),
		STATIC(mercury__vn_util__record_use_4_0));
	}
Define_label(mercury__vn_util__record_use_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__record_use_4_0,
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i10);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i16);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__vn_util__record_access_3_0),
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i16);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i18);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_util__record_use_4_0,
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i18);
	r1 = (Integer) detstackvar(2);
Define_label(mercury__vn_util__record_use_4_0_i20);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_util_module27)
	init_entry(mercury__vn_util__record_use_list_4_0);
	init_label(mercury__vn_util__record_use_list_4_0_i4);
	init_label(mercury__vn_util__record_use_list_4_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_util__record_use_list'/4 in mode 0 */
Define_static(mercury__vn_util__record_use_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_util__record_use_list_4_0_i1002);
	incr_sp_push_msg(3, "vn_util__record_use_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__record_use_list_4_0_i4,
		STATIC(mercury__vn_util__record_use_list_4_0));
Define_label(mercury__vn_util__record_use_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_list_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_util__record_use_list_4_0,
		STATIC(mercury__vn_util__record_use_list_4_0));
Define_label(mercury__vn_util__record_use_list_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_util_bunch_0(void)
{
	mercury__vn_util_module0();
	mercury__vn_util_module1();
	mercury__vn_util_module2();
	mercury__vn_util_module3();
	mercury__vn_util_module4();
	mercury__vn_util_module5();
	mercury__vn_util_module6();
	mercury__vn_util_module7();
	mercury__vn_util_module8();
	mercury__vn_util_module9();
	mercury__vn_util_module10();
	mercury__vn_util_module11();
	mercury__vn_util_module12();
	mercury__vn_util_module13();
	mercury__vn_util_module14();
	mercury__vn_util_module15();
	mercury__vn_util_module16();
	mercury__vn_util_module17();
	mercury__vn_util_module18();
	mercury__vn_util_module19();
	mercury__vn_util_module20();
	mercury__vn_util_module21();
	mercury__vn_util_module22();
	mercury__vn_util_module23();
	mercury__vn_util_module24();
	mercury__vn_util_module25();
	mercury__vn_util_module26();
	mercury__vn_util_module27();
}

#endif

void mercury__vn_util__init(void); /* suppress gcc warning */
void mercury__vn_util__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_util_bunch_0();
#endif
}
