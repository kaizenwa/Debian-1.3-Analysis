/*
** Automatically generated from `common.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__common__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___common_structure_0__ua10000_2_0);
Define_extern_entry(mercury__common__optimise_common_subexpressions_2_0);
Declare_label(mercury__common__optimise_common_subexpressions_2_0_i2);
Define_extern_entry(mercury__common__optimise_in_proc_4_0);
Declare_label(mercury__common__optimise_in_proc_4_0_i2);
Declare_label(mercury__common__optimise_in_proc_4_0_i3);
Declare_label(mercury__common__optimise_in_proc_4_0_i4);
Declare_label(mercury__common__optimise_in_proc_4_0_i5);
Declare_label(mercury__common__optimise_in_proc_4_0_i6);
Declare_label(mercury__common__optimise_in_proc_4_0_i7);
Declare_label(mercury__common__optimise_in_proc_4_0_i10);
Declare_label(mercury__common__optimise_in_proc_4_0_i9);
Declare_label(mercury__common__optimise_in_proc_4_0_i12);
Declare_label(mercury__common__optimise_in_proc_4_0_i13);
Declare_label(mercury__common__optimise_in_proc_4_0_i14);
Declare_label(mercury__common__optimise_in_proc_4_0_i15);
Declare_label(mercury__common__optimise_in_proc_4_0_i16);
Declare_label(mercury__common__optimise_in_proc_4_0_i17);
Declare_static(mercury__common__optimise_in_preds_3_0);
Declare_label(mercury__common__optimise_in_preds_3_0_i4);
Declare_label(mercury__common__optimise_in_preds_3_0_i5);
Declare_label(mercury__common__optimise_in_preds_3_0_i6);
Declare_label(mercury__common__optimise_in_preds_3_0_i7);
Declare_label(mercury__common__optimise_in_preds_3_0_i1002);
Declare_static(mercury__common__optimise_in_procs_4_0);
Declare_label(mercury__common__optimise_in_procs_4_0_i4);
Declare_label(mercury__common__optimise_in_procs_4_0_i5);
Declare_label(mercury__common__optimise_in_procs_4_0_i6);
Declare_label(mercury__common__optimise_in_procs_4_0_i7);
Declare_label(mercury__common__optimise_in_procs_4_0_i8);
Declare_label(mercury__common__optimise_in_procs_4_0_i9);
Declare_label(mercury__common__optimise_in_procs_4_0_i10);
Declare_label(mercury__common__optimise_in_procs_4_0_i11);
Declare_label(mercury__common__optimise_in_procs_4_0_i12);
Declare_label(mercury__common__optimise_in_procs_4_0_i1002);
Declare_static(mercury__common__optimise_in_goal_pair_4_0);
Declare_label(mercury__common__optimise_in_goal_pair_4_0_i2);
Declare_static(mercury__common__optimise_in_goal_4_0);
Declare_label(mercury__common__optimise_in_goal_4_0_i1025);
Declare_label(mercury__common__optimise_in_goal_4_0_i1024);
Declare_label(mercury__common__optimise_in_goal_4_0_i1023);
Declare_label(mercury__common__optimise_in_goal_4_0_i1022);
Declare_label(mercury__common__optimise_in_goal_4_0_i1021);
Declare_label(mercury__common__optimise_in_goal_4_0_i1020);
Declare_label(mercury__common__optimise_in_goal_4_0_i5);
Declare_label(mercury__common__optimise_in_goal_4_0_i6);
Declare_label(mercury__common__optimise_in_goal_4_0_i7);
Declare_label(mercury__common__optimise_in_goal_4_0_i8);
Declare_label(mercury__common__optimise_in_goal_4_0_i9);
Declare_label(mercury__common__optimise_in_goal_4_0_i10);
Declare_label(mercury__common__optimise_in_goal_4_0_i11);
Declare_label(mercury__common__optimise_in_goal_4_0_i12);
Declare_label(mercury__common__optimise_in_goal_4_0_i13);
Declare_label(mercury__common__optimise_in_goal_4_0_i14);
Declare_label(mercury__common__optimise_in_goal_4_0_i15);
Declare_label(mercury__common__optimise_in_goal_4_0_i16);
Declare_label(mercury__common__optimise_in_goal_4_0_i17);
Declare_label(mercury__common__optimise_in_goal_4_0_i18);
Declare_label(mercury__common__optimise_in_goal_4_0_i19);
Declare_label(mercury__common__optimise_in_goal_4_0_i20);
Declare_label(mercury__common__optimise_in_goal_4_0_i1019);
Declare_label(mercury__common__optimise_in_goal_4_0_i23);
Declare_label(mercury__common__optimise_in_goal_4_0_i24);
Declare_label(mercury__common__optimise_in_goal_4_0_i1016);
Declare_label(mercury__common__optimise_in_goal_4_0_i2);
Declare_static(mercury__common__optimise_over_conjunction_5_0);
Declare_label(mercury__common__optimise_over_conjunction_5_0_i4);
Declare_label(mercury__common__optimise_over_conjunction_5_0_i1002);
Declare_static(mercury__common__optimise_over_disjunction_5_0);
Declare_label(mercury__common__optimise_over_disjunction_5_0_i4);
Declare_label(mercury__common__optimise_over_disjunction_5_0_i1002);
Declare_static(mercury__common__optimise_over_switch_5_0);
Declare_label(mercury__common__optimise_over_switch_5_0_i4);
Declare_label(mercury__common__optimise_over_switch_5_0_i1003);
Declare_static(mercury__common__optimise_unification_8_0);
Declare_label(mercury__common__optimise_unification_8_0_i6);
Declare_label(mercury__common__optimise_unification_8_0_i1001);
Declare_label(mercury__common__optimise_unification_8_0_i10);
Declare_label(mercury__common__optimise_unification_8_0_i12);
Declare_label(mercury__common__optimise_unification_8_0_i14);
Declare_label(mercury__common__optimise_unification_8_0_i9);
Declare_label(mercury__common__optimise_unification_8_0_i15);
Declare_label(mercury__common__optimise_unification_8_0_i7);
Declare_label(mercury__common__optimise_unification_8_0_i17);
Declare_label(mercury__common__optimise_unification_8_0_i19);
Declare_label(mercury__common__optimise_unification_8_0_i1000);
Declare_static(mercury__common__find_matching_cell_2_6_0);
Declare_label(mercury__common__find_matching_cell_2_6_0_i5);
Declare_label(mercury__common__find_matching_cell_2_6_0_i7);
Declare_label(mercury__common__find_matching_cell_2_6_0_i9);
Declare_label(mercury__common__find_matching_cell_2_6_0_i10);
Declare_label(mercury__common__find_matching_cell_2_6_0_i12);
Declare_label(mercury__common__find_matching_cell_2_6_0_i14);
Declare_label(mercury__common__find_matching_cell_2_6_0_i4);
Declare_label(mercury__common__find_matching_cell_2_6_0_i16);
Declare_label(mercury__common__find_matching_cell_2_6_0_i1008);
Declare_label(mercury__common__find_matching_cell_2_6_0_i1010);
Declare_static(mercury__common__vars_are_equivalent_3_0);
Declare_label(mercury__common__vars_are_equivalent_3_0_i1012);
Declare_label(mercury__common__vars_are_equivalent_3_0_i9);
Declare_label(mercury__common__vars_are_equivalent_3_0_i8);
Declare_label(mercury__common__vars_are_equivalent_3_0_i11);
Declare_label(mercury__common__vars_are_equivalent_3_0_i13);
Declare_label(mercury__common__vars_are_equivalent_3_0_i15);
Declare_label(mercury__common__vars_are_equivalent_3_0_i1009);
Declare_label(mercury__common__vars_are_equivalent_3_0_i1);
Declare_static(mercury__common__record_cell_5_0);
Declare_label(mercury__common__record_cell_5_0_i1000);
Declare_label(mercury__common__record_cell_5_0_i7);
Declare_label(mercury__common__record_cell_5_0_i6);
Declare_label(mercury__common__record_cell_5_0_i9);
Declare_label(mercury__common__record_cell_5_0_i10);
Declare_label(mercury__common__record_cell_5_0_i11);
Declare_static(mercury__common__record_equivalance_4_0);
Declare_label(mercury__common__record_equivalance_4_0_i2);
Declare_static(mercury____Unify___common__structure_0_0);
Declare_label(mercury____Unify___common__structure_0_0_i2);
Declare_label(mercury____Unify___common__structure_0_0_i4);
Declare_label(mercury____Unify___common__structure_0_0_i6);
Declare_label(mercury____Unify___common__structure_0_0_i1);
Declare_static(mercury____Index___common__structure_0_0);
Declare_static(mercury____Compare___common__structure_0_0);
Declare_label(mercury____Compare___common__structure_0_0_i4);
Declare_label(mercury____Compare___common__structure_0_0_i5);
Declare_label(mercury____Compare___common__structure_0_0_i3);
Declare_label(mercury____Compare___common__structure_0_0_i10);
Declare_label(mercury____Compare___common__structure_0_0_i16);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_common__base_type_layout_common_info_0[];
Word * mercury_data_common__base_type_info_common_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_common__base_type_layout_common_info_0
};

extern Word * mercury_data_common__base_type_layout_struct_map_0[];
Word * mercury_data_common__base_type_info_struct_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_common__base_type_layout_struct_map_0
};

extern Word * mercury_data_common__base_type_layout_structure_0[];
Word * mercury_data_common__base_type_info_structure_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___common__structure_0_0),
	(Word *) (Integer) STATIC(mercury____Index___common__structure_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___common__structure_0_0),
	(Word *) (Integer) mercury_data_common__base_type_layout_structure_0
};

extern Word * mercury_data_common__common_6[];
Word * mercury_data_common__base_type_layout_structure_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_common__common_6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_common__common_8[];
Word * mercury_data_common__base_type_layout_struct_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_common__common_8),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_common__common_8),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_common__common_8),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_common__common_8)
};

extern Word * mercury_data_common__common_11[];
Word * mercury_data_common__base_type_layout_common_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_common__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_common__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_common__base_type_info_structure_0
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_common__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_common__common_2[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_common__common_3[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
Word * mercury_data_common__common_4[] = {
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0
};

Word * mercury_data_common__common_5[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_common__common_6[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_5),
	(Word *) string_const("structure", 9)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_common__common_7[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_0)
};

Word * mercury_data_common__common_8[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_7)
};

Word * mercury_data_common__common_9[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_eqvclass__base_type_info_eqvclass_1[];
Word * mercury_data_common__common_10[] = {
	(Word *) (Integer) mercury_data_eqvclass__base_type_info_eqvclass_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_common__common_11[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_7),
	(Word *) string_const("common", 6)
};

BEGIN_MODULE(mercury__common_module0)
	init_entry(mercury____Index___common_structure_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___common_structure_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___common_structure_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module1)
	init_entry(mercury__common__optimise_common_subexpressions_2_0);
	init_label(mercury__common__optimise_common_subexpressions_2_0_i2);
BEGIN_CODE

/* code for predicate 'common__optimise_common_subexpressions'/2 in mode 0 */
Define_entry(mercury__common__optimise_common_subexpressions_2_0);
	incr_sp_push_msg(2, "common__optimise_common_subexpressions");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__common__optimise_common_subexpressions_2_0_i2,
		ENTRY(mercury__common__optimise_common_subexpressions_2_0));
	}
Define_label(mercury__common__optimise_common_subexpressions_2_0_i2);
	update_prof_current_proc(LABEL(mercury__common__optimise_common_subexpressions_2_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__common__optimise_in_preds_3_0),
		ENTRY(mercury__common__optimise_common_subexpressions_2_0));
END_MODULE

BEGIN_MODULE(mercury__common_module2)
	init_entry(mercury__common__optimise_in_proc_4_0);
	init_label(mercury__common__optimise_in_proc_4_0_i2);
	init_label(mercury__common__optimise_in_proc_4_0_i3);
	init_label(mercury__common__optimise_in_proc_4_0_i4);
	init_label(mercury__common__optimise_in_proc_4_0_i5);
	init_label(mercury__common__optimise_in_proc_4_0_i6);
	init_label(mercury__common__optimise_in_proc_4_0_i7);
	init_label(mercury__common__optimise_in_proc_4_0_i10);
	init_label(mercury__common__optimise_in_proc_4_0_i9);
	init_label(mercury__common__optimise_in_proc_4_0_i12);
	init_label(mercury__common__optimise_in_proc_4_0_i13);
	init_label(mercury__common__optimise_in_proc_4_0_i14);
	init_label(mercury__common__optimise_in_proc_4_0_i15);
	init_label(mercury__common__optimise_in_proc_4_0_i16);
	init_label(mercury__common__optimise_in_proc_4_0_i17);
BEGIN_CODE

/* code for predicate 'common__optimise_in_proc'/4 in mode 0 */
Define_entry(mercury__common__optimise_in_proc_4_0);
	incr_sp_push_msg(7, "common__optimise_in_proc");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__common__optimise_in_proc_4_0_i2,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__common__optimise_in_proc_4_0_i3,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i3);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__common__optimise_in_proc_4_0_i4,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__eqvclass__init_1_0);
	call_localret(ENTRY(mercury__eqvclass__init_1_0),
		mercury__common__optimise_in_proc_4_0_i5,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__common__optimise_in_proc_4_0_i6,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i6);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_in_proc_4_0_i7,
		ENTRY(mercury__common__optimise_in_proc_4_0));
Define_label(mercury__common__optimise_in_proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	r4 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0;
	r2 = (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__common__optimise_in_proc_4_0_i10,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i10);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__optimise_in_proc_4_0_i9);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_proc_4_0_i9);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__common__optimise_in_proc_4_0_i12,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__common__optimise_in_proc_4_0_i13,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__mode_util__recompute_instmap_delta_4_0);
	call_localret(ENTRY(mercury__mode_util__recompute_instmap_delta_4_0),
		mercury__common__optimise_in_proc_4_0_i14,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
	}
Define_label(mercury__common__optimise_in_proc_4_0_i14);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__common__optimise_in_proc_4_0_i15,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i15);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		mercury__common__optimise_in_proc_4_0_i16,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i16);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_variables_3_0),
		mercury__common__optimise_in_proc_4_0_i17,
		ENTRY(mercury__common__optimise_in_proc_4_0));
	}
Define_label(mercury__common__optimise_in_proc_4_0_i17);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_proc_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module3)
	init_entry(mercury__common__optimise_in_preds_3_0);
	init_label(mercury__common__optimise_in_preds_3_0_i4);
	init_label(mercury__common__optimise_in_preds_3_0_i5);
	init_label(mercury__common__optimise_in_preds_3_0_i6);
	init_label(mercury__common__optimise_in_preds_3_0_i7);
	init_label(mercury__common__optimise_in_preds_3_0_i1002);
BEGIN_CODE

/* code for predicate 'common__optimise_in_preds'/3 in mode 0 */
Define_static(mercury__common__optimise_in_preds_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__optimise_in_preds_3_0_i1002);
	incr_sp_push_msg(4, "common__optimise_in_preds");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__common__optimise_in_preds_3_0_i4,
		STATIC(mercury__common__optimise_in_preds_3_0));
	}
Define_label(mercury__common__optimise_in_preds_3_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_preds_3_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__common__optimise_in_preds_3_0_i5,
		STATIC(mercury__common__optimise_in_preds_3_0));
	}
Define_label(mercury__common__optimise_in_preds_3_0_i5);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_preds_3_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__common__optimise_in_preds_3_0_i6,
		STATIC(mercury__common__optimise_in_preds_3_0));
	}
Define_label(mercury__common__optimise_in_preds_3_0_i6);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_preds_3_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__common__optimise_in_procs_4_0),
		mercury__common__optimise_in_preds_3_0_i7,
		STATIC(mercury__common__optimise_in_preds_3_0));
Define_label(mercury__common__optimise_in_preds_3_0_i7);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_preds_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__common__optimise_in_preds_3_0,
		STATIC(mercury__common__optimise_in_preds_3_0));
Define_label(mercury__common__optimise_in_preds_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module4)
	init_entry(mercury__common__optimise_in_procs_4_0);
	init_label(mercury__common__optimise_in_procs_4_0_i4);
	init_label(mercury__common__optimise_in_procs_4_0_i5);
	init_label(mercury__common__optimise_in_procs_4_0_i6);
	init_label(mercury__common__optimise_in_procs_4_0_i7);
	init_label(mercury__common__optimise_in_procs_4_0_i8);
	init_label(mercury__common__optimise_in_procs_4_0_i9);
	init_label(mercury__common__optimise_in_procs_4_0_i10);
	init_label(mercury__common__optimise_in_procs_4_0_i11);
	init_label(mercury__common__optimise_in_procs_4_0_i12);
	init_label(mercury__common__optimise_in_procs_4_0_i1002);
BEGIN_CODE

/* code for predicate 'common__optimise_in_procs'/4 in mode 0 */
Define_static(mercury__common__optimise_in_procs_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__optimise_in_procs_4_0_i1002);
	incr_sp_push_msg(8, "common__optimise_in_procs");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__common__optimise_in_procs_4_0_i4,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r3 = (Integer) r1;
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__common__optimise_in_procs_4_0_i5,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__common__optimise_in_procs_4_0_i6,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i6);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r3 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__common__optimise_in_procs_4_0_i7,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__common__optimise_in_proc_4_0),
		mercury__common__optimise_in_procs_4_0_i8,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r5 = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__common__optimise_in_procs_4_0_i9,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i9);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__common__optimise_in_procs_4_0_i10,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i10);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__common__optimise_in_procs_4_0_i11,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i11);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__common__optimise_in_procs_4_0_i12,
		STATIC(mercury__common__optimise_in_procs_4_0));
	}
Define_label(mercury__common__optimise_in_procs_4_0_i12);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_procs_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__common__optimise_in_procs_4_0,
		STATIC(mercury__common__optimise_in_procs_4_0));
Define_label(mercury__common__optimise_in_procs_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module5)
	init_entry(mercury__common__optimise_in_goal_pair_4_0);
	init_label(mercury__common__optimise_in_goal_pair_4_0_i2);
BEGIN_CODE

/* code for predicate 'common__optimise_in_goal_pair'/4 in mode 0 */
Define_static(mercury__common__optimise_in_goal_pair_4_0);
	incr_sp_push_msg(2, "common__optimise_in_goal_pair");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__common__optimise_in_goal_4_0),
		mercury__common__optimise_in_goal_pair_4_0_i2,
		STATIC(mercury__common__optimise_in_goal_pair_4_0));
Define_label(mercury__common__optimise_in_goal_pair_4_0_i2);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_pair_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module6)
	init_entry(mercury__common__optimise_in_goal_4_0);
	init_label(mercury__common__optimise_in_goal_4_0_i1025);
	init_label(mercury__common__optimise_in_goal_4_0_i1024);
	init_label(mercury__common__optimise_in_goal_4_0_i1023);
	init_label(mercury__common__optimise_in_goal_4_0_i1022);
	init_label(mercury__common__optimise_in_goal_4_0_i1021);
	init_label(mercury__common__optimise_in_goal_4_0_i1020);
	init_label(mercury__common__optimise_in_goal_4_0_i5);
	init_label(mercury__common__optimise_in_goal_4_0_i6);
	init_label(mercury__common__optimise_in_goal_4_0_i7);
	init_label(mercury__common__optimise_in_goal_4_0_i8);
	init_label(mercury__common__optimise_in_goal_4_0_i9);
	init_label(mercury__common__optimise_in_goal_4_0_i10);
	init_label(mercury__common__optimise_in_goal_4_0_i11);
	init_label(mercury__common__optimise_in_goal_4_0_i12);
	init_label(mercury__common__optimise_in_goal_4_0_i13);
	init_label(mercury__common__optimise_in_goal_4_0_i14);
	init_label(mercury__common__optimise_in_goal_4_0_i15);
	init_label(mercury__common__optimise_in_goal_4_0_i16);
	init_label(mercury__common__optimise_in_goal_4_0_i17);
	init_label(mercury__common__optimise_in_goal_4_0_i18);
	init_label(mercury__common__optimise_in_goal_4_0_i19);
	init_label(mercury__common__optimise_in_goal_4_0_i20);
	init_label(mercury__common__optimise_in_goal_4_0_i1019);
	init_label(mercury__common__optimise_in_goal_4_0_i23);
	init_label(mercury__common__optimise_in_goal_4_0_i24);
	init_label(mercury__common__optimise_in_goal_4_0_i1016);
	init_label(mercury__common__optimise_in_goal_4_0_i2);
BEGIN_CODE

/* code for predicate 'common__optimise_in_goal'/4 in mode 0 */
Define_static(mercury__common__optimise_in_goal_4_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i1019);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__common__optimise_in_goal_4_0_i1025) AND
		LABEL(mercury__common__optimise_in_goal_4_0_i1024) AND
		LABEL(mercury__common__optimise_in_goal_4_0_i1023) AND
		LABEL(mercury__common__optimise_in_goal_4_0_i1022) AND
		LABEL(mercury__common__optimise_in_goal_4_0_i1021) AND
		LABEL(mercury__common__optimise_in_goal_4_0_i1020) AND
		LABEL(mercury__common__optimise_in_goal_4_0_i1016));
Define_label(mercury__common__optimise_in_goal_4_0_i1025);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i5);
Define_label(mercury__common__optimise_in_goal_4_0_i1024);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i8);
Define_label(mercury__common__optimise_in_goal_4_0_i1023);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i10);
Define_label(mercury__common__optimise_in_goal_4_0_i1022);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i13);
Define_label(mercury__common__optimise_in_goal_4_0_i1021);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i15);
Define_label(mercury__common__optimise_in_goal_4_0_i1020);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i17);
Define_label(mercury__common__optimise_in_goal_4_0_i5);
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__common__optimise_over_switch_5_0),
		mercury__common__optimise_in_goal_4_0_i6,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_goal__base_type_info_case_0[];
	r1 = (Integer) mercury_data_hlds_goal__base_type_info_case_0;
	}
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__common__optimise_in_goal_4_0_i7,
		STATIC(mercury__common__optimise_in_goal_4_0));
	}
Define_label(mercury__common__optimise_in_goal_4_0_i7);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i8);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	call_localret(STATIC(mercury__common__optimise_unification_8_0),
		mercury__common__optimise_in_goal_4_0_i9,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r5 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r5;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(2);
	r2 = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i10);
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__common__optimise_over_disjunction_5_0),
		mercury__common__optimise_in_goal_4_0_i11,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i11);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__common__optimise_in_goal_4_0_i12,
		STATIC(mercury__common__optimise_in_goal_4_0));
	}
Define_label(mercury__common__optimise_in_goal_4_0_i12);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i13);
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_in_goal_4_0_i14,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i14);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	r2 = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i15);
	detstackvar(2) = (Integer) r2;
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_in_goal_4_0_i16,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i16);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	r2 = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i17);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_in_goal_4_0_i18,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i18);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_in_goal_4_0_i19,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i19);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_in_goal_4_0_i20,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i20);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	r2 = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i1019);
	incr_sp_push_msg(7, "common__optimise_in_goal");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__common__optimise_in_goal_4_0_i2);
	r3 = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__common__optimise_over_conjunction_5_0),
		mercury__common__optimise_in_goal_4_0_i23,
		STATIC(mercury__common__optimise_in_goal_4_0));
Define_label(mercury__common__optimise_in_goal_4_0_i23);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__common__optimise_in_goal_4_0_i24,
		STATIC(mercury__common__optimise_in_goal_4_0));
	}
Define_label(mercury__common__optimise_in_goal_4_0_i24);
	update_prof_current_proc(LABEL(mercury__common__optimise_in_goal_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i1016);
	proceed();
Define_label(mercury__common__optimise_in_goal_4_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module7)
	init_entry(mercury__common__optimise_over_conjunction_5_0);
	init_label(mercury__common__optimise_over_conjunction_5_0_i4);
	init_label(mercury__common__optimise_over_conjunction_5_0_i1002);
BEGIN_CODE

/* code for predicate 'common__optimise_over_conjunction'/5 in mode 0 */
Define_static(mercury__common__optimise_over_conjunction_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__optimise_over_conjunction_5_0_i1002);
	incr_sp_push_msg(3, "common__optimise_over_conjunction");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_over_conjunction_5_0_i4,
		STATIC(mercury__common__optimise_over_conjunction_5_0));
Define_label(mercury__common__optimise_over_conjunction_5_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_over_conjunction_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__common__optimise_over_conjunction_5_0,
		STATIC(mercury__common__optimise_over_conjunction_5_0));
Define_label(mercury__common__optimise_over_conjunction_5_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module8)
	init_entry(mercury__common__optimise_over_disjunction_5_0);
	init_label(mercury__common__optimise_over_disjunction_5_0_i4);
	init_label(mercury__common__optimise_over_disjunction_5_0_i1002);
BEGIN_CODE

/* code for predicate 'common__optimise_over_disjunction'/5 in mode 0 */
Define_static(mercury__common__optimise_over_disjunction_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__optimise_over_disjunction_5_0_i1002);
	incr_sp_push_msg(4, "common__optimise_over_disjunction");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_over_disjunction_5_0_i4,
		STATIC(mercury__common__optimise_over_disjunction_5_0));
Define_label(mercury__common__optimise_over_disjunction_5_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_over_disjunction_5_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__common__optimise_over_disjunction_5_0,
		STATIC(mercury__common__optimise_over_disjunction_5_0));
Define_label(mercury__common__optimise_over_disjunction_5_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module9)
	init_entry(mercury__common__optimise_over_switch_5_0);
	init_label(mercury__common__optimise_over_switch_5_0_i4);
	init_label(mercury__common__optimise_over_switch_5_0_i1003);
BEGIN_CODE

/* code for predicate 'common__optimise_over_switch'/5 in mode 0 */
Define_static(mercury__common__optimise_over_switch_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__optimise_over_switch_5_0_i1003);
	incr_sp_push_msg(5, "common__optimise_over_switch");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__common__optimise_in_goal_pair_4_0),
		mercury__common__optimise_over_switch_5_0_i4,
		STATIC(mercury__common__optimise_over_switch_5_0));
	}
Define_label(mercury__common__optimise_over_switch_5_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_over_switch_5_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__common__optimise_over_switch_5_0,
		STATIC(mercury__common__optimise_over_switch_5_0));
	}
Define_label(mercury__common__optimise_over_switch_5_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module10)
	init_entry(mercury__common__optimise_unification_8_0);
	init_label(mercury__common__optimise_unification_8_0_i6);
	init_label(mercury__common__optimise_unification_8_0_i1001);
	init_label(mercury__common__optimise_unification_8_0_i10);
	init_label(mercury__common__optimise_unification_8_0_i12);
	init_label(mercury__common__optimise_unification_8_0_i14);
	init_label(mercury__common__optimise_unification_8_0_i9);
	init_label(mercury__common__optimise_unification_8_0_i15);
	init_label(mercury__common__optimise_unification_8_0_i7);
	init_label(mercury__common__optimise_unification_8_0_i17);
	init_label(mercury__common__optimise_unification_8_0_i19);
	init_label(mercury__common__optimise_unification_8_0_i1000);
BEGIN_CODE

/* code for predicate 'common__optimise_unification'/8 in mode 0 */
Define_static(mercury__common__optimise_unification_8_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__common__optimise_unification_8_0_i1001);
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r5 != ((Integer) 0)))
		GOTO_LABEL(mercury__common__optimise_unification_8_0_i1000);
	incr_sp_push_msg(11, "common__optimise_unification");
	detstackvar(11) = (Integer) succip;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__common__record_equivalance_4_0),
		mercury__common__optimise_unification_8_0_i6,
		STATIC(mercury__common__optimise_unification_8_0));
Define_label(mercury__common__optimise_unification_8_0_i6);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__common__optimise_unification_8_0_i1001);
	incr_sp_push_msg(11, "common__optimise_unification");
	detstackvar(11) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__common__optimise_unification_8_0_i7);
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	detstackvar(7) = (Integer) r4;
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) r4;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__optimise_unification_8_0_i10,
		STATIC(mercury__common__optimise_unification_8_0));
	}
Define_label(mercury__common__optimise_unification_8_0_i10);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__optimise_unification_8_0_i9);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__common__find_matching_cell_2_6_0),
		mercury__common__optimise_unification_8_0_i12,
		STATIC(mercury__common__optimise_unification_8_0));
Define_label(mercury__common__optimise_unification_8_0_i12);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__optimise_unification_8_0_i9);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	detstackvar(6) = (Integer) tempr1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(7);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	call_localret(STATIC(mercury__common__record_equivalance_4_0),
		mercury__common__optimise_unification_8_0_i14,
		STATIC(mercury__common__optimise_unification_8_0));
	}
Define_label(mercury__common__optimise_unification_8_0_i14);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__common__optimise_unification_8_0_i9);
	detstackvar(4) = (Integer) detstackvar(1);
	detstackvar(5) = (Integer) detstackvar(2);
	detstackvar(6) = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__common__record_cell_5_0),
		mercury__common__optimise_unification_8_0_i15,
		STATIC(mercury__common__optimise_unification_8_0));
Define_label(mercury__common__optimise_unification_8_0_i15);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__common__optimise_unification_8_0_i7);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__common__optimise_unification_8_0_i17);
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__common__record_cell_5_0),
		mercury__common__optimise_unification_8_0_i6,
		STATIC(mercury__common__optimise_unification_8_0));
Define_label(mercury__common__optimise_unification_8_0_i17);
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r3;
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__common__record_equivalance_4_0),
		mercury__common__optimise_unification_8_0_i19,
		STATIC(mercury__common__optimise_unification_8_0));
Define_label(mercury__common__optimise_unification_8_0_i19);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__common__optimise_unification_8_0_i1000);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module11)
	init_entry(mercury__common__find_matching_cell_2_6_0);
	init_label(mercury__common__find_matching_cell_2_6_0_i5);
	init_label(mercury__common__find_matching_cell_2_6_0_i7);
	init_label(mercury__common__find_matching_cell_2_6_0_i9);
	init_label(mercury__common__find_matching_cell_2_6_0_i10);
	init_label(mercury__common__find_matching_cell_2_6_0_i12);
	init_label(mercury__common__find_matching_cell_2_6_0_i14);
	init_label(mercury__common__find_matching_cell_2_6_0_i4);
	init_label(mercury__common__find_matching_cell_2_6_0_i16);
	init_label(mercury__common__find_matching_cell_2_6_0_i1008);
	init_label(mercury__common__find_matching_cell_2_6_0_i1010);
BEGIN_CODE

/* code for predicate 'common__find_matching_cell_2'/6 in mode 0 */
Define_static(mercury__common__find_matching_cell_2_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i1008);
	incr_sp_push_msg(11, "common__find_matching_cell_2");
	detstackvar(11) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r5, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	r1 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__common__find_matching_cell_2_6_0_i5,
		STATIC(mercury__common__find_matching_cell_2_6_0));
	}
	}
Define_label(mercury__common__find_matching_cell_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i4);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__common__vars_are_equivalent_3_0),
		mercury__common__find_matching_cell_2_6_0_i7,
		STATIC(mercury__common__find_matching_cell_2_6_0));
Define_label(mercury__common__find_matching_cell_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i4);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__common__find_matching_cell_2_6_0_i9,
		STATIC(mercury__common__find_matching_cell_2_6_0));
	}
Define_label(mercury__common__find_matching_cell_2_6_0_i9);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__find_matching_cell_2_6_0_i10,
		STATIC(mercury__common__find_matching_cell_2_6_0));
	}
Define_label(mercury__common__find_matching_cell_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i4);
	r1 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__find_matching_cell_2_6_0_i12,
		STATIC(mercury__common__find_matching_cell_2_6_0));
	}
Define_label(mercury__common__find_matching_cell_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i4);
	r4 = (Integer) r2;
	{
	extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_sym_name_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__common__find_matching_cell_2_6_0_i14,
		STATIC(mercury__common__find_matching_cell_2_6_0));
	}
Define_label(mercury__common__find_matching_cell_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i4);
	r2 = (Integer) detstackvar(6);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__common__find_matching_cell_2_6_0_i4);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	localcall(mercury__common__find_matching_cell_2_6_0,
		LABEL(mercury__common__find_matching_cell_2_6_0_i16),
		STATIC(mercury__common__find_matching_cell_2_6_0));
Define_label(mercury__common__find_matching_cell_2_6_0_i16);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_6_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_6_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury__common__find_matching_cell_2_6_0_i1008);
	r1 = FALSE;
	proceed();
Define_label(mercury__common__find_matching_cell_2_6_0_i1010);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module12)
	init_entry(mercury__common__vars_are_equivalent_3_0);
	init_label(mercury__common__vars_are_equivalent_3_0_i1012);
	init_label(mercury__common__vars_are_equivalent_3_0_i9);
	init_label(mercury__common__vars_are_equivalent_3_0_i8);
	init_label(mercury__common__vars_are_equivalent_3_0_i11);
	init_label(mercury__common__vars_are_equivalent_3_0_i13);
	init_label(mercury__common__vars_are_equivalent_3_0_i15);
	init_label(mercury__common__vars_are_equivalent_3_0_i1009);
	init_label(mercury__common__vars_are_equivalent_3_0_i1);
BEGIN_CODE

/* code for predicate 'common__vars_are_equivalent'/3 in mode 0 */
Define_static(mercury__common__vars_are_equivalent_3_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1012);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1009);
	r1 = FALSE;
	proceed();
Define_label(mercury__common__vars_are_equivalent_3_0_i1012);
	incr_sp_push_msg(6, "common__vars_are_equivalent");
	detstackvar(6) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__common__vars_are_equivalent_3_0_i9,
		STATIC(mercury__common__vars_are_equivalent_3_0));
	}
Define_label(mercury__common__vars_are_equivalent_3_0_i9);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i8);
	r3 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__common__vars_are_equivalent_3_0,
		STATIC(mercury__common__vars_are_equivalent_3_0));
Define_label(mercury__common__vars_are_equivalent_3_0_i8);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__eqvclass__is_member_2_0);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__vars_are_equivalent_3_0_i11,
		STATIC(mercury__common__vars_are_equivalent_3_0));
	}
Define_label(mercury__common__vars_are_equivalent_3_0_i11);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__eqvclass__is_member_2_0);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__vars_are_equivalent_3_0_i13,
		STATIC(mercury__common__vars_are_equivalent_3_0));
	}
Define_label(mercury__common__vars_are_equivalent_3_0_i13);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__eqvclass__same_eqvclass_3_0);
	call_localret(ENTRY(mercury__eqvclass__same_eqvclass_3_0),
		mercury__common__vars_are_equivalent_3_0_i15,
		STATIC(mercury__common__vars_are_equivalent_3_0));
	}
Define_label(mercury__common__vars_are_equivalent_3_0_i15);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1);
	r3 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__common__vars_are_equivalent_3_0,
		STATIC(mercury__common__vars_are_equivalent_3_0));
Define_label(mercury__common__vars_are_equivalent_3_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury__common__vars_are_equivalent_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module13)
	init_entry(mercury__common__record_cell_5_0);
	init_label(mercury__common__record_cell_5_0_i1000);
	init_label(mercury__common__record_cell_5_0_i7);
	init_label(mercury__common__record_cell_5_0_i6);
	init_label(mercury__common__record_cell_5_0_i9);
	init_label(mercury__common__record_cell_5_0_i10);
	init_label(mercury__common__record_cell_5_0_i11);
BEGIN_CODE

/* code for predicate 'common__record_cell'/5 in mode 0 */
Define_static(mercury__common__record_cell_5_0);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__common__record_cell_5_0_i1000);
	r1 = (Integer) r4;
	proceed();
Define_label(mercury__common__record_cell_5_0_i1000);
	incr_sp_push_msg(8, "common__record_cell");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	r3 = (Integer) tempr1;
	detstackvar(6) = (Integer) tempr1;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__record_cell_5_0_i7,
		STATIC(mercury__common__record_cell_5_0));
	}
	}
Define_label(mercury__common__record_cell_5_0_i7);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__common__record_cell_5_0_i6);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	GOTO_LABEL(mercury__common__record_cell_5_0_i9);
Define_label(mercury__common__record_cell_5_0_i6);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
Define_label(mercury__common__record_cell_5_0_i9);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__common__record_cell_5_0_i10,
		STATIC(mercury__common__record_cell_5_0));
	}
Define_label(mercury__common__record_cell_5_0_i10);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_common__common_0);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	r6 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 4));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__common__record_cell_5_0_i11,
		STATIC(mercury__common__record_cell_5_0));
	}
	}
Define_label(mercury__common__record_cell_5_0_i11);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module14)
	init_entry(mercury__common__record_equivalance_4_0);
	init_label(mercury__common__record_equivalance_4_0_i2);
BEGIN_CODE

/* code for predicate 'common__record_equivalance'/4 in mode 0 */
Define_static(mercury__common__record_equivalance_4_0);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	incr_sp_push_msg(3, "common__record_equivalance");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__eqvclass__ensure_equivalence_4_0);
	call_localret(ENTRY(mercury__eqvclass__ensure_equivalence_4_0),
		mercury__common__record_equivalance_4_0_i2,
		STATIC(mercury__common__record_equivalance_4_0));
	}
Define_label(mercury__common__record_equivalance_4_0_i2);
	update_prof_current_proc(LABEL(mercury__common__record_equivalance_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module15)
	init_entry(mercury____Unify___common__structure_0_0);
	init_label(mercury____Unify___common__structure_0_0_i2);
	init_label(mercury____Unify___common__structure_0_0_i4);
	init_label(mercury____Unify___common__structure_0_0_i6);
	init_label(mercury____Unify___common__structure_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___common__structure_0_0);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury____Unify___common__structure_0_0_i2,
		STATIC(mercury____Unify___common__structure_0_0));
	}
Define_label(mercury____Unify___common__structure_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___common__structure_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___common__structure_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term_0_0),
		mercury____Unify___common__structure_0_0_i4,
		STATIC(mercury____Unify___common__structure_0_0));
	}
Define_label(mercury____Unify___common__structure_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___common__structure_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___common__structure_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___common__structure_0_0_i6,
		STATIC(mercury____Unify___common__structure_0_0));
	}
Define_label(mercury____Unify___common__structure_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___common__structure_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___common__structure_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		STATIC(mercury____Unify___common__structure_0_0));
	}
Define_label(mercury____Unify___common__structure_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__common_module16)
	init_entry(mercury____Index___common__structure_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___common__structure_0_0);
	tailcall(STATIC(mercury____Index___common_structure_0__ua10000_2_0),
		STATIC(mercury____Index___common__structure_0_0));
END_MODULE

BEGIN_MODULE(mercury__common_module17)
	init_entry(mercury____Compare___common__structure_0_0);
	init_label(mercury____Compare___common__structure_0_0_i4);
	init_label(mercury____Compare___common__structure_0_0_i5);
	init_label(mercury____Compare___common__structure_0_0_i3);
	init_label(mercury____Compare___common__structure_0_0_i10);
	init_label(mercury____Compare___common__structure_0_0_i16);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___common__structure_0_0);
	incr_sp_push_msg(7, "__Compare__");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__var_0_0),
		mercury____Compare___common__structure_0_0_i4,
		STATIC(mercury____Compare___common__structure_0_0));
	}
Define_label(mercury____Compare___common__structure_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___common__structure_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___common__structure_0_0_i3);
Define_label(mercury____Compare___common__structure_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___common__structure_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term_0_0),
		mercury____Compare___common__structure_0_0_i10,
		STATIC(mercury____Compare___common__structure_0_0));
	}
Define_label(mercury____Compare___common__structure_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___common__structure_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___common__structure_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___common__structure_0_0_i16,
		STATIC(mercury____Compare___common__structure_0_0));
	}
Define_label(mercury____Compare___common__structure_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___common__structure_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___common__structure_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		STATIC(mercury____Compare___common__structure_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__common_bunch_0(void)
{
	mercury__common_module0();
	mercury__common_module1();
	mercury__common_module2();
	mercury__common_module3();
	mercury__common_module4();
	mercury__common_module5();
	mercury__common_module6();
	mercury__common_module7();
	mercury__common_module8();
	mercury__common_module9();
	mercury__common_module10();
	mercury__common_module11();
	mercury__common_module12();
	mercury__common_module13();
	mercury__common_module14();
	mercury__common_module15();
	mercury__common_module16();
	mercury__common_module17();
}

#endif

void mercury__common__init(void); /* suppress gcc warning */
void mercury__common__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__common_bunch_0();
#endif
}
