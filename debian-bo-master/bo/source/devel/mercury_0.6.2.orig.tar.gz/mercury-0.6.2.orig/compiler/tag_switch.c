/*
** Automatically generated from `tag_switch.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__tag_switch__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__tag_switch__generate_9_0);
Declare_label(mercury__tag_switch__generate_9_0_i2);
Declare_label(mercury__tag_switch__generate_9_0_i3);
Declare_label(mercury__tag_switch__generate_9_0_i4);
Declare_label(mercury__tag_switch__generate_9_0_i5);
Declare_label(mercury__tag_switch__generate_9_0_i6);
Declare_label(mercury__tag_switch__generate_9_0_i7);
Declare_label(mercury__tag_switch__generate_9_0_i8);
Declare_label(mercury__tag_switch__generate_9_0_i9);
Declare_label(mercury__tag_switch__generate_9_0_i10);
Declare_label(mercury__tag_switch__generate_9_0_i15);
Declare_label(mercury__tag_switch__generate_9_0_i17);
Declare_label(mercury__tag_switch__generate_9_0_i22);
Declare_label(mercury__tag_switch__generate_9_0_i21);
Declare_label(mercury__tag_switch__generate_9_0_i20);
Declare_label(mercury__tag_switch__generate_9_0_i16);
Declare_label(mercury__tag_switch__generate_9_0_i1028);
Declare_label(mercury__tag_switch__generate_9_0_i11);
Declare_label(mercury__tag_switch__generate_9_0_i24);
Declare_label(mercury__tag_switch__generate_9_0_i25);
Declare_label(mercury__tag_switch__generate_9_0_i27);
Declare_label(mercury__tag_switch__generate_9_0_i28);
Declare_label(mercury__tag_switch__generate_9_0_i26);
Declare_label(mercury__tag_switch__generate_9_0_i29);
Declare_static(mercury__tag_switch__generate_primary_tag_codes_12_0);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i4);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i5);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i7);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i8);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i11);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i16);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i17);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i1036);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i22);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i19);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i9);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i24);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i25);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i26);
Declare_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i1024);
Declare_static(mercury__tag_switch__generate_primary_tag_code_12_0);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i2);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i11);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i12);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i6);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i3);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i17);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i18);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i19);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i20);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i21);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i24);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i27);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i26);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i28);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i29);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i16);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i30);
Declare_label(mercury__tag_switch__generate_primary_tag_code_12_0_i31);
Declare_static(mercury__tag_switch__generate_secondary_tag_chain_10_0);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1024);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i6);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i11);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i12);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i13);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1021);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i18);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i15);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i4);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i20);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i21);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i22);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i23);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1023);
Declare_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i24);
Declare_static(mercury__tag_switch__generate_secondary_tag_table_11_0);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i1028);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i12);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i16);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i17);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i13);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i18);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i19);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i20);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i21);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i22);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i23);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i9);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i24);
Declare_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i1027);
Declare_static(mercury__tag_switch__get_tag_counts_4_0);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i2);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i5);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i4);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i7);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i8);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i9);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i10);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i11);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i12);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i16);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i17);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i13);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i18);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i19);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i20);
Declare_label(mercury__tag_switch__get_tag_counts_4_0_i21);
Declare_static(mercury__tag_switch__get_tag_counts_2_3_0);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i9);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i11);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i8);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i1001);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i4);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i19);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i21);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i24);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i25);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i26);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i18);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i14);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i35);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i37);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i40);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i41);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i42);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i34);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i30);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i46);
Declare_label(mercury__tag_switch__get_tag_counts_2_3_0_i1000);
Declare_static(mercury__tag_switch__group_tags_3_0);
Declare_label(mercury__tag_switch__group_tags_3_0_i9);
Declare_label(mercury__tag_switch__group_tags_3_0_i11);
Declare_label(mercury__tag_switch__group_tags_3_0_i8);
Declare_label(mercury__tag_switch__group_tags_3_0_i12);
Declare_label(mercury__tag_switch__group_tags_3_0_i13);
Declare_label(mercury__tag_switch__group_tags_3_0_i14);
Declare_label(mercury__tag_switch__group_tags_3_0_i15);
Declare_label(mercury__tag_switch__group_tags_3_0_i1001);
Declare_label(mercury__tag_switch__group_tags_3_0_i4);
Declare_label(mercury__tag_switch__group_tags_3_0_i21);
Declare_label(mercury__tag_switch__group_tags_3_0_i23);
Declare_label(mercury__tag_switch__group_tags_3_0_i26);
Declare_label(mercury__tag_switch__group_tags_3_0_i20);
Declare_label(mercury__tag_switch__group_tags_3_0_i28);
Declare_label(mercury__tag_switch__group_tags_3_0_i29);
Declare_label(mercury__tag_switch__group_tags_3_0_i30);
Declare_label(mercury__tag_switch__group_tags_3_0_i16);
Declare_label(mercury__tag_switch__group_tags_3_0_i37);
Declare_label(mercury__tag_switch__group_tags_3_0_i39);
Declare_label(mercury__tag_switch__group_tags_3_0_i42);
Declare_label(mercury__tag_switch__group_tags_3_0_i36);
Declare_label(mercury__tag_switch__group_tags_3_0_i44);
Declare_label(mercury__tag_switch__group_tags_3_0_i45);
Declare_label(mercury__tag_switch__group_tags_3_0_i46);
Declare_label(mercury__tag_switch__group_tags_3_0_i32);
Declare_label(mercury__tag_switch__group_tags_3_0_i48);
Declare_label(mercury__tag_switch__group_tags_3_0_i1000);
Declare_static(mercury__tag_switch__order_tags_3_0);
Declare_label(mercury__tag_switch__order_tags_3_0_i4);
Declare_label(mercury__tag_switch__order_tags_3_0_i8);
Declare_label(mercury__tag_switch__order_tags_3_0_i10);
Declare_label(mercury__tag_switch__order_tags_3_0_i11);
Declare_label(mercury__tag_switch__order_tags_3_0_i7);
Declare_label(mercury__tag_switch__order_tags_3_0_i3);
Declare_label(mercury__tag_switch__order_tags_3_0_i16);
Declare_label(mercury__tag_switch__order_tags_3_0_i1000);
Declare_static(mercury__tag_switch__select_frequent_tag_4_0);
Declare_label(mercury__tag_switch__select_frequent_tag_4_0_i5);
Declare_label(mercury__tag_switch__select_frequent_tag_4_0_i4);
Declare_label(mercury__tag_switch__select_frequent_tag_4_0_i1004);
Declare_static(mercury__tag_switch__cons_list_to_tag_list_2_0);
Declare_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i3);
Declare_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i4);
Declare_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i1);
Declare_static(mercury____Unify___tag_switch__stag_loc_0_0);
Declare_label(mercury____Unify___tag_switch__stag_loc_0_0_i1);
Declare_static(mercury____Index___tag_switch__stag_loc_0_0);
Declare_static(mercury____Compare___tag_switch__stag_loc_0_0);

extern Word * mercury_data_tag_switch__base_type_layout_stag_loc_0[];
Word * mercury_data_tag_switch__base_type_info_stag_loc_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___tag_switch__stag_loc_0_0),
	(Word *) (Integer) STATIC(mercury____Index___tag_switch__stag_loc_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___tag_switch__stag_loc_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_stag_loc_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_tag_switch__base_type_layout_tag_case_list_0[];
Word * mercury_data_tag_switch__base_type_info_tag_case_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_tag_case_list_0
};

extern Word * mercury_data_tag_switch__base_type_layout_tag_case_map_0[];
Word * mercury_data_tag_switch__base_type_info_tag_case_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_tag_case_map_0
};

extern Word * mercury_data_tag_switch__base_type_layout_tag_count_list_0[];
Word * mercury_data_tag_switch__base_type_info_tag_count_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_tag_count_list_0
};

extern Word * mercury_data_tag_switch__base_type_layout_tag_count_map_0[];
Word * mercury_data_tag_switch__base_type_info_tag_count_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_tag_count_map_0
};

extern Word * mercury_data_tag_switch__base_type_layout_tag_goal_list_0[];
Word * mercury_data_tag_switch__base_type_info_tag_goal_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_tag_goal_list_0
};

extern Word * mercury_data_tag_switch__base_type_layout_tag_goal_map_0[];
Word * mercury_data_tag_switch__base_type_info_tag_goal_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_tag_switch__base_type_layout_tag_goal_map_0
};

extern Word * mercury_data_tag_switch__common_9[];
Word * mercury_data_tag_switch__base_type_layout_tag_goal_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_9)
};

extern Word * mercury_data_tag_switch__common_11[];
Word * mercury_data_tag_switch__base_type_layout_tag_goal_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_11),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_11),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_11),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_11)
};

extern Word * mercury_data_tag_switch__common_13[];
Word * mercury_data_tag_switch__base_type_layout_tag_count_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_13),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_13),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_13),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_13)
};

extern Word * mercury_data_tag_switch__common_16[];
Word * mercury_data_tag_switch__base_type_layout_tag_count_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_16)
};

extern Word * mercury_data_tag_switch__common_18[];
Word * mercury_data_tag_switch__base_type_layout_tag_case_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_18),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_18)
};

extern Word * mercury_data_tag_switch__common_21[];
Word * mercury_data_tag_switch__base_type_layout_tag_case_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_21),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_21),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_21),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_21)
};

extern Word * mercury_data_tag_switch__common_22[];
Word * mercury_data_tag_switch__base_type_layout_stag_loc_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_22)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_tag_switch__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_tag_switch__base_type_info_stag_loc_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_tag_switch__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_tag_switch__common_2[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1)
};

Word * mercury_data_tag_switch__common_3[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_tag_switch__base_type_info_stag_loc_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_2)
};

Word mercury_data_tag_switch__common_4[] = {
	((Integer) 0)
};

Word * mercury_data_tag_switch__common_5[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_tag_switch__common_4)
};

Word * mercury_data_tag_switch__common_6[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1)
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
Word * mercury_data_tag_switch__common_7[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word mercury_data_tag_switch__common_8[] = {
	((Integer) 0),
	((Integer) -1)
};

Word * mercury_data_tag_switch__common_9[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_2)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_tag_switch__common_10[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_6)
};

Word * mercury_data_tag_switch__common_11[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_10)
};

Word * mercury_data_tag_switch__common_12[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0)
};

Word * mercury_data_tag_switch__common_13[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_12)
};

Word * mercury_data_tag_switch__common_14[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0)
};

Word * mercury_data_tag_switch__common_15[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_14)
};

Word * mercury_data_tag_switch__common_16[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_15)
};

Word * mercury_data_tag_switch__common_17[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3)
};

Word * mercury_data_tag_switch__common_18[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_17)
};

Word * mercury_data_tag_switch__common_19[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3)
};

Word * mercury_data_tag_switch__common_20[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_19)
};

Word * mercury_data_tag_switch__common_21[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_20)
};

Word * mercury_data_tag_switch__common_22[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("none", 4),
	(Word *) string_const("local", 5),
	(Word *) string_const("remote", 6)
};

BEGIN_MODULE(mercury__tag_switch_module0)
	init_entry(mercury__tag_switch__generate_9_0);
	init_label(mercury__tag_switch__generate_9_0_i2);
	init_label(mercury__tag_switch__generate_9_0_i3);
	init_label(mercury__tag_switch__generate_9_0_i4);
	init_label(mercury__tag_switch__generate_9_0_i5);
	init_label(mercury__tag_switch__generate_9_0_i6);
	init_label(mercury__tag_switch__generate_9_0_i7);
	init_label(mercury__tag_switch__generate_9_0_i8);
	init_label(mercury__tag_switch__generate_9_0_i9);
	init_label(mercury__tag_switch__generate_9_0_i10);
	init_label(mercury__tag_switch__generate_9_0_i15);
	init_label(mercury__tag_switch__generate_9_0_i17);
	init_label(mercury__tag_switch__generate_9_0_i22);
	init_label(mercury__tag_switch__generate_9_0_i21);
	init_label(mercury__tag_switch__generate_9_0_i20);
	init_label(mercury__tag_switch__generate_9_0_i16);
	init_label(mercury__tag_switch__generate_9_0_i1028);
	init_label(mercury__tag_switch__generate_9_0_i11);
	init_label(mercury__tag_switch__generate_9_0_i24);
	init_label(mercury__tag_switch__generate_9_0_i25);
	init_label(mercury__tag_switch__generate_9_0_i27);
	init_label(mercury__tag_switch__generate_9_0_i28);
	init_label(mercury__tag_switch__generate_9_0_i26);
	init_label(mercury__tag_switch__generate_9_0_i29);
BEGIN_CODE

/* code for predicate 'tag_switch__generate'/9 in mode 0 */
Define_entry(mercury__tag_switch__generate_9_0);
	incr_sp_push_msg(13, "tag_switch__generate");
	detstackvar(13) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r2;
	r2 = (Integer) r7;
	call_localret(STATIC(mercury__tag_switch__get_tag_counts_4_0),
		mercury__tag_switch__generate_9_0_i2,
		ENTRY(mercury__tag_switch__generate_9_0));
Define_label(mercury__tag_switch__generate_9_0_i2);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	r3 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__tag_switch__generate_9_0_i3,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i3);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__generate_9_0_i4,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__tag_switch__group_tags_3_0),
		mercury__tag_switch__generate_9_0_i5,
		ENTRY(mercury__tag_switch__generate_9_0));
Define_label(mercury__tag_switch__generate_9_0_i5);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__tag_switch__order_tags_3_0),
		mercury__tag_switch__generate_9_0_i6,
		ENTRY(mercury__tag_switch__generate_9_0));
Define_label(mercury__tag_switch__generate_9_0_i6);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_info__produce_variable_in_reg_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_in_reg_5_0),
		mercury__tag_switch__generate_9_0_i7,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__tag_switch__generate_9_0_i8,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	detstackvar(9) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__tag_switch__generate_9_0_i9,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__tag_switch__generate_9_0_i10,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	if (((Integer) detstackvar(1) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_9_0_i11);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_9_0_i11);
	detstackvar(12) = (Integer) r2;
	r2 = ((Integer) 73);
	{
	Declare_entry(mercury__globals__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_9_0_i15,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i15);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_9_0_i17);
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__tag_switch__generate_9_0_i16);
Define_label(mercury__tag_switch__generate_9_0_i17);
	if ((tag((Integer) detstackvar(9)) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_9_0_i21);
	detstackvar(10) = (Integer) r1;
	r1 = string_const("float reg in tag switch", 23);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_9_0_i22,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__tag_switch__generate_9_0_i20);
Define_label(mercury__tag_switch__generate_9_0_i21);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) r1;
	r12 = (Integer) field(mktag(0), (Integer) r10, ((Integer) 0));
	r1 = (Integer) detstackvar(12);
Define_label(mercury__tag_switch__generate_9_0_i20);
	if (((Integer) r12 <= (Integer) r11))
		GOTO_LABEL(mercury__tag_switch__generate_9_0_i16);
	detstackvar(1) = (Integer) r7;
	detstackvar(2) = (Integer) r8;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r9;
	GOTO_LABEL(mercury__tag_switch__generate_9_0_i1028);
Define_label(mercury__tag_switch__generate_9_0_i16);
	r11 = (Integer) r10;
	tag_incr_hp(r10, mktag(1), ((Integer) 1));
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r11;
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r9;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("compute tag to switch on", 24);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	r12 = (Integer) r11;
	tag_incr_hp(r11, mktag(0), ((Integer) 1));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__tag_switch__generate_9_0_i24);
	}
Define_label(mercury__tag_switch__generate_9_0_i1028);
	r2 = (Integer) r1;
Define_label(mercury__tag_switch__generate_9_0_i11);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r11, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r11, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) r11, ((Integer) 2)) = (Integer) r9;
Define_label(mercury__tag_switch__generate_9_0_i24);
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(1) = (Integer) r7;
	detstackvar(2) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_9_0_i25,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i25);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	if (((Integer) detstackvar(4) == ((Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_9_0_i27);
	r8 = (Integer) r1;
	r10 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r11 = (Integer) detstackvar(2);
	r12 = (Integer) detstackvar(9);
	r13 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__tag_switch__generate_9_0_i26);
Define_label(mercury__tag_switch__generate_9_0_i27);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__tag_switch__generate_9_0_i28,
		ENTRY(mercury__tag_switch__generate_9_0));
	}
Define_label(mercury__tag_switch__generate_9_0_i28);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	r10 = (Integer) r2;
	r14 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(7);
	r11 = (Integer) detstackvar(2);
	r12 = (Integer) detstackvar(9);
	tag_incr_hp(r13, mktag(2), ((Integer) 2));
	tag_incr_hp(r15, mktag(1), ((Integer) 1));
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	tag_incr_hp(r17, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r8;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r17, ((Integer) 1)) = string_const("switch has failed", 17);
	field(mktag(2), (Integer) r13, ((Integer) 0)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r17, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__tag_switch__generate_9_0_i26);
	detstackvar(6) = (Integer) r7;
	detstackvar(2) = (Integer) r11;
	detstackvar(9) = (Integer) r12;
	detstackvar(10) = (Integer) r13;
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0),
		mercury__tag_switch__generate_9_0_i29,
		ENTRY(mercury__tag_switch__generate_9_0));
Define_label(mercury__tag_switch__generate_9_0_i29);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_9_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("end of tag switch", 17);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module1)
	init_entry(mercury__tag_switch__generate_primary_tag_codes_12_0);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i4);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i5);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i7);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i8);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i11);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i16);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i17);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i1036);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i22);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i19);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i9);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i24);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i25);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i26);
	init_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i1024);
BEGIN_CODE

/* code for predicate 'tag_switch__generate_primary_tag_codes'/12 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_tag_codes_12_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i1024);
	incr_sp_push_msg(18, "tag_switch__generate_primary_tag_codes");
	detstackvar(18) = (Integer) succip;
	detstackvar(3) = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(11) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	r3 = (Integer) r9;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i4,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
	}
	}
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) detstackvar(12) != (Integer) field(mktag(0), (Integer) r1, ((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i5);
	r14 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i8);
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i5);
	detstackvar(14) = (Integer) r2;
	r1 = string_const("secondary tag locations differ in tag_switch__generate_primary_tag_codes", 72);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i7,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i8);
	if (((Integer) r10 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i11);
	if (((Integer) r5 != ((Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i9);
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i11);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i16,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i17,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	detstackvar(16) = (Integer) r1;
	tag_incr_hp(detstackvar(17), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r6, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = ((Integer) 13);
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r7, ((Integer) 1)) = ((Integer) 0);
	tag_incr_hp(r8, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(3), (Integer) r6, ((Integer) 3)) = (Integer) r7;
	field(mktag(3), (Integer) r7, ((Integer) 2)) = (Integer) r8;
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("test primary tag only", 21);
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(11);
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) detstackvar(17), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	r3 = (Integer) detstackvar(14);
	r4 = (Integer) detstackvar(12);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_12_0),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i1036,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i1036);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(17);
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	tag_incr_hp(r7, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 6);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("skip to end of tag switch", 25);
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) r1;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(16);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("handle next primary tag", 23);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	if (((Integer) detstackvar(10) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i19);
	r1 = (Integer) detstackvar(15);
	detstackvar(15) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i22,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
	}
	}
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(15);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i25);
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i19);
	r10 = (Integer) r2;
	r11 = (Integer) r3;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i25);
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i9);
	detstackvar(4) = (Integer) r5;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	r9 = (Integer) r8;
	detstackvar(7) = (Integer) r8;
	r8 = (Integer) r7;
	detstackvar(6) = (Integer) r7;
	r7 = (Integer) r6;
	detstackvar(5) = (Integer) r6;
	r5 = (Integer) r3;
	r6 = (Integer) r4;
	r10 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) r13;
	r2 = (Integer) r11;
	r3 = (Integer) r14;
	r4 = (Integer) r12;
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_12_0),
		mercury__tag_switch__generate_primary_tag_codes_12_0_i24,
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i24);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	r10 = (Integer) r2;
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i25);
	detstackvar(15) = (Integer) r11;
	localcall(mercury__tag_switch__generate_primary_tag_codes_12_0,
		LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0_i26),
		STATIC(mercury__tag_switch__generate_primary_tag_codes_12_0));
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i26);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_codes_12_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(15);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(18);
	decr_sp_pop_msg(18);
	proceed();
Define_label(mercury__tag_switch__generate_primary_tag_codes_12_0_i1024);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r10;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module2)
	init_entry(mercury__tag_switch__generate_primary_tag_code_12_0);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i2);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i11);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i12);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i6);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i3);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i17);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i18);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i19);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i20);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i21);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i24);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i27);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i26);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i28);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i29);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i16);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i30);
	init_label(mercury__tag_switch__generate_primary_tag_code_12_0_i31);
BEGIN_CODE

/* code for predicate 'tag_switch__generate_primary_tag_code'/12 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_tag_code_12_0);
	incr_sp_push_msg(14, "tag_switch__generate_primary_tag_code");
	detstackvar(14) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i2,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i2);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i3);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i6);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0)) != ((Integer) -1)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i6);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i6);
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i11,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i12,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i6);
	r1 = string_const("more than one goal for non-shared tag", 37);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i3);
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i17,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	detstackvar(11) = (Integer) r2;
	r2 = ((Integer) 108);
	{
	Declare_entry(mercury__globals__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i18,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	if (((Integer) detstackvar(2) >= (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i16);
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i19,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	detstackvar(11) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i20,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	if (((Integer) detstackvar(3) != ((Integer) 2)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i21);
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(r11, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) r11, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(r12, mktag(0), ((Integer) 1));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_5);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("compute remote sec tag to switch on", 35);
	field(mktag(3), (Integer) r11, ((Integer) 2)) = (Integer) r12;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	r9 = (Integer) r8;
	tag_incr_hp(r8, mktag(0), ((Integer) 1));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i24);
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i21);
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(r11, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) r11, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("compute remote sec tag to switch on", 35);
	field(mktag(3), (Integer) r11, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	r9 = (Integer) r8;
	tag_incr_hp(r8, mktag(0), ((Integer) 1));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i24);
	detstackvar(2) = (Integer) r1;
	detstackvar(5) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(10) = (Integer) r2;
	detstackvar(11) = (Integer) r7;
	detstackvar(12) = (Integer) r8;
	detstackvar(13) = (Integer) r9;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_6);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i27,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i27);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	if ((((Integer) detstackvar(2) + ((Integer) 1)) != (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i26);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(5);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i28);
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i26);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r1 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(12);
	r4 = ((Integer) 0);
	r8 = (Integer) detstackvar(13);
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i28);
	detstackvar(11) = (Integer) r9;
	call_localret(STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i29,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i29);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i16);
	r1 = (Integer) detstackvar(10);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0),
		mercury__tag_switch__generate_primary_tag_code_12_0_i30,
		STATIC(mercury__tag_switch__generate_primary_tag_code_12_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i30);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_12_0));
	if (((Integer) detstackvar(3) != ((Integer) 2)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_12_0_i31);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 7);
	tag_incr_hp(r9, mktag(0), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) r3;
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_tag_switch__common_5);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("switch on secondary tag", 23);
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_12_0_i31);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	tag_incr_hp(r8, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) r3;
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 1)) = string_const("switch on secondary tag", 23);
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module3)
	init_entry(mercury__tag_switch__generate_secondary_tag_chain_10_0);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1024);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i6);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i11);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i12);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i13);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1021);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i18);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i15);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i4);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i20);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i21);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i22);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i23);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1023);
	init_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i24);
BEGIN_CODE

/* code for predicate 'tag_switch__generate_secondary_tag_chain'/10 in mode 0 */
Define_static(mercury__tag_switch__generate_secondary_tag_chain_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1023);
	r9 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r10 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r11 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if (((Integer) r10 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1024);
	r1 = (Integer) r8;
	r8 = (Integer) r10;
	r10 = (Integer) r9;
	r9 = (Integer) r11;
	incr_sp_push_msg(14, "tag_switch__generate_secondary_tag_chain");
	detstackvar(14) = (Integer) succip;
	GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i6);
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1024);
	incr_sp_push_msg(14, "tag_switch__generate_secondary_tag_chain");
	detstackvar(14) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i4);
	r1 = (Integer) r8;
	r8 = (Integer) r10;
	r10 = (Integer) r9;
	r9 = (Integer) r11;
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i11,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i12,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	r3 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) r1;
	tag_incr_hp(detstackvar(12), mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r7, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r7, ((Integer) 1)) = ((Integer) 13);
	field(mktag(3), (Integer) r7, ((Integer) 2)) = (Integer) detstackvar(1);
	tag_incr_hp(r8, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(3), (Integer) r7, ((Integer) 3)) = (Integer) r8;
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	r3 = (Integer) r2;
	field(mktag(3), (Integer) r6, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	field(mktag(1), (Integer) detstackvar(12), ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("test remote sec tag only", 24);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i13,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	r3 = (Integer) r2;
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i1021,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1021);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(13);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(r9, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 6);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("skip to end of tag switch", 25);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) r1;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("handle next secondary tag", 25);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	if (((Integer) detstackvar(8) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i15);
	r1 = (Integer) detstackvar(11);
	detstackvar(9) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i18,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i22);
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i15);
	r8 = (Integer) r2;
	r9 = (Integer) r3;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i22);
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r10;
	r1 = (Integer) r3;
	r2 = (Integer) r9;
	r3 = (Integer) r8;
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i20,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	r3 = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__tag_switch__generate_secondary_tag_chain_10_0_i21,
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	r8 = (Integer) r2;
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) r10;
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i22);
	detstackvar(9) = (Integer) r9;
	localcall(mercury__tag_switch__generate_secondary_tag_chain_10_0,
		LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i23),
		STATIC(mercury__tag_switch__generate_secondary_tag_chain_10_0));
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i1023);
	incr_sp_push_msg(14, "tag_switch__generate_secondary_tag_chain");
	detstackvar(14) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_chain_10_0_i24);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("secondary tag does not match", 28);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	r2 = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_tag_chain_10_0_i24);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module4)
	init_entry(mercury__tag_switch__generate_secondary_tag_table_11_0);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i1028);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i12);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i16);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i17);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i13);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i18);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i19);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i20);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i21);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i22);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i23);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i9);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i24);
	init_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i1027);
BEGIN_CODE

/* code for predicate 'tag_switch__generate_secondary_tag_table'/11 in mode 0 */
Define_static(mercury__tag_switch__generate_secondary_tag_table_11_0);
	if (((Integer) r2 <= (Integer) r3))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i1028);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i1027);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) r8;
	proceed();
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i1028);
	incr_sp_push_msg(12, "tag_switch__generate_secondary_tag_table");
	detstackvar(12) = (Integer) succip;
	r9 = ((Integer) r2 + ((Integer) 1));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i9);
	r10 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if (((Integer) r2 != (Integer) r10))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i9);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r9;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r8;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i12,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) r1;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("start of a case in tag switch", 29);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	if (((Integer) detstackvar(8) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i13);
	detstackvar(10) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i16,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r3 = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i17,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r8 = (Integer) r2;
	r12 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(7);
	tag_incr_hp(r13, mktag(1), ((Integer) 1));
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r15, mktag(0), ((Integer) 2));
	tag_incr_hp(r16, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r16, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r15, ((Integer) 1)) = string_const("branch to end of tag switch", 27);
	field(mktag(3), (Integer) r16, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	field(mktag(0), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	GOTO_LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i22);
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i13);
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i18,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r3 = (Integer) r2;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i19,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r3 = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i20,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r3 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__tag_switch__generate_secondary_tag_table_11_0_i21,
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(7);
	r12 = (Integer) detstackvar(11);
	tag_incr_hp(r13, mktag(1), ((Integer) 1));
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r15, mktag(0), ((Integer) 2));
	tag_incr_hp(r16, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r16, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r15, ((Integer) 1)) = string_const("branch to end of tag switch", 27);
	field(mktag(3), (Integer) r16, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	field(mktag(0), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i22);
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(7) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(1) = (Integer) r13;
	localcall(mercury__tag_switch__generate_secondary_tag_table_11_0,
		LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i23),
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i9);
	detstackvar(5) = (Integer) r7;
	r2 = (Integer) r9;
	localcall(mercury__tag_switch__generate_secondary_tag_table_11_0,
		LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0_i24),
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i24);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_tag_table_11_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_tag_table_11_0_i1027);
	r1 = string_const("caselist not empty when reaching limiting secondary tag", 55);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_secondary_tag_table_11_0));
	}
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module5)
	init_entry(mercury__tag_switch__get_tag_counts_4_0);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i2);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i5);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i4);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i7);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i8);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i9);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i10);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i11);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i12);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i16);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i17);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i13);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i18);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i19);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i20);
	init_label(mercury__tag_switch__get_tag_counts_4_0_i21);
BEGIN_CODE

/* code for predicate 'tag_switch__get_tag_counts'/4 in mode 0 */
Define_static(mercury__tag_switch__get_tag_counts_4_0);
	incr_sp_push_msg(4, "tag_switch__get_tag_counts");
	detstackvar(4) = (Integer) succip;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__tag_switch__get_tag_counts_4_0_i2,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i2);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__tag_switch__get_tag_counts_4_0_i5,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i5);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_4_0_i4);
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__tag_switch__get_tag_counts_4_0_i8);
Define_label(mercury__tag_switch__get_tag_counts_4_0_i4);
	r1 = string_const("unknown type in tag_switch__get_tag_counts", 42);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_tag_counts_4_0_i7,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	r2 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
Define_label(mercury__tag_switch__get_tag_counts_4_0_i8);
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__tag_switch__get_tag_counts_4_0_i9,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__tag_switch__get_tag_counts_4_0_i10,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_7);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__tag_switch__get_tag_counts_4_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__tag_switch__get_tag_counts_4_0_i12,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_4_0_i13);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	}
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	}
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__tag_switch__get_tag_counts_4_0_i16,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	call_localret(STATIC(mercury__tag_switch__cons_list_to_tag_list_2_0),
		mercury__tag_switch__get_tag_counts_4_0_i17,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
Define_label(mercury__tag_switch__get_tag_counts_4_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	GOTO_LABEL(mercury__tag_switch__get_tag_counts_4_0_i19);
Define_label(mercury__tag_switch__get_tag_counts_4_0_i13);
	r1 = string_const("non-du type in tag_switch__get_tag_counts", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_tag_counts_4_0_i18,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
Define_label(mercury__tag_switch__get_tag_counts_4_0_i19);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__get_tag_counts_4_0_i20,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_4_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__tag_switch__get_tag_counts_2_3_0),
		mercury__tag_switch__get_tag_counts_4_0_i21,
		STATIC(mercury__tag_switch__get_tag_counts_4_0));
Define_label(mercury__tag_switch__get_tag_counts_4_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module6)
	init_entry(mercury__tag_switch__get_tag_counts_2_3_0);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i9);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i11);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i8);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i1001);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i4);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i19);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i21);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i24);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i25);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i26);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i18);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i14);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i35);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i37);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i40);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i41);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i42);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i34);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i30);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i46);
	init_label(mercury__tag_switch__get_tag_counts_2_3_0_i1000);
BEGIN_CODE

/* code for predicate 'tag_switch__get_tag_counts_2'/3 in mode 0 */
Define_static(mercury__tag_switch__get_tag_counts_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i1000);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i1001);
	incr_sp_push_msg(8, "tag_switch__get_tag_counts_2");
	detstackvar(8) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i4);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i9,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i8);
	r1 = string_const("simple tag is shared", 20);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_tag_counts_2_3_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__tag_switch__get_tag_counts_2_3_0,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i8);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_8);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i1001);
	incr_sp_push_msg(8, "tag_switch__get_tag_counts_2");
	detstackvar(8) = (Integer) succip;
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i4);
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i14);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i14);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(7) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i19,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i18);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i21);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r5 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i25);
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i21);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("remote tag is shared with non-remote", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_tag_counts_2_3_0_i24,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i24);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i25);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	{
	Declare_entry(mercury__int__max_3_0);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_tag_counts_2_3_0_i26,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i26);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i18);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(7);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i14);
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i30);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i30);
	detstackvar(2) = (Integer) r3;
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(5) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i35,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i35);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i34);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i37);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__tag_switch__get_tag_counts_2_3_0_i41);
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i37);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("local tag is shared with non-local", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_tag_counts_2_3_0_i40,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i40);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i41);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__int__max_3_0);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_tag_counts_2_3_0_i42,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i42);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	r6 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i34);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_0);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__get_tag_counts_2_3_0_i11,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i30);
	detstackvar(2) = (Integer) r3;
	r1 = string_const("non-du tag in tag_switch__get_tag_counts_2", 42);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_tag_counts_2_3_0_i46,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
	}
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i46);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_tag_counts_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__tag_switch__get_tag_counts_2_3_0,
		STATIC(mercury__tag_switch__get_tag_counts_2_3_0));
Define_label(mercury__tag_switch__get_tag_counts_2_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module7)
	init_entry(mercury__tag_switch__group_tags_3_0);
	init_label(mercury__tag_switch__group_tags_3_0_i9);
	init_label(mercury__tag_switch__group_tags_3_0_i11);
	init_label(mercury__tag_switch__group_tags_3_0_i8);
	init_label(mercury__tag_switch__group_tags_3_0_i12);
	init_label(mercury__tag_switch__group_tags_3_0_i13);
	init_label(mercury__tag_switch__group_tags_3_0_i14);
	init_label(mercury__tag_switch__group_tags_3_0_i15);
	init_label(mercury__tag_switch__group_tags_3_0_i1001);
	init_label(mercury__tag_switch__group_tags_3_0_i4);
	init_label(mercury__tag_switch__group_tags_3_0_i21);
	init_label(mercury__tag_switch__group_tags_3_0_i23);
	init_label(mercury__tag_switch__group_tags_3_0_i26);
	init_label(mercury__tag_switch__group_tags_3_0_i20);
	init_label(mercury__tag_switch__group_tags_3_0_i28);
	init_label(mercury__tag_switch__group_tags_3_0_i29);
	init_label(mercury__tag_switch__group_tags_3_0_i30);
	init_label(mercury__tag_switch__group_tags_3_0_i16);
	init_label(mercury__tag_switch__group_tags_3_0_i37);
	init_label(mercury__tag_switch__group_tags_3_0_i39);
	init_label(mercury__tag_switch__group_tags_3_0_i42);
	init_label(mercury__tag_switch__group_tags_3_0_i36);
	init_label(mercury__tag_switch__group_tags_3_0_i44);
	init_label(mercury__tag_switch__group_tags_3_0_i45);
	init_label(mercury__tag_switch__group_tags_3_0_i46);
	init_label(mercury__tag_switch__group_tags_3_0_i32);
	init_label(mercury__tag_switch__group_tags_3_0_i48);
	init_label(mercury__tag_switch__group_tags_3_0_i1000);
BEGIN_CODE

/* code for predicate 'tag_switch__group_tags'/3 in mode 0 */
Define_static(mercury__tag_switch__group_tags_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i1000);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 3));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i1001);
	incr_sp_push_msg(9, "tag_switch__group_tags");
	detstackvar(9) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i4);
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	detstackvar(2) = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__group_tags_3_0_i9,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i8);
	r1 = string_const("simple tag is shared", 20);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_tags_3_0_i11,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i12);
Define_label(mercury__tag_switch__group_tags_3_0_i8);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
Define_label(mercury__tag_switch__group_tags_3_0_i12);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__group_tags_3_0_i13,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
	r4 = ((Integer) -1);
	r5 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__group_tags_3_0_i14,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__group_tags_3_0_i15,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i15);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__tag_switch__group_tags_3_0,
		STATIC(mercury__tag_switch__group_tags_3_0));
Define_label(mercury__tag_switch__group_tags_3_0_i1001);
	incr_sp_push_msg(9, "tag_switch__group_tags");
	detstackvar(9) = (Integer) succip;
Define_label(mercury__tag_switch__group_tags_3_0_i4);
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i16);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i16);
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(8) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	detstackvar(2) = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__group_tags_3_0_i21,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i20);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i23);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r3 = (Integer) r1;
	r8 = (Integer) detstackvar(8);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
	GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i29);
Define_label(mercury__tag_switch__group_tags_3_0_i23);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("remote tag is shared with non-remote", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_tags_3_0_i26,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i26);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i29);
Define_label(mercury__tag_switch__group_tags_3_0_i20);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__group_tags_3_0_i28,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i28);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r3 = (Integer) r1;
	r8 = (Integer) detstackvar(8);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
Define_label(mercury__tag_switch__group_tags_3_0_i29);
	detstackvar(1) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__group_tags_3_0_i30,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i30);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r6 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(8);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__group_tags_3_0_i15,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i16);
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i32);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i32);
	detstackvar(3) = (Integer) r3;
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(6) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	detstackvar(2) = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__group_tags_3_0_i37,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i37);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i36);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i39);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	r8 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
	GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i45);
Define_label(mercury__tag_switch__group_tags_3_0_i39);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("local tag is shared with non-local", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_tags_3_0_i42,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i42);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__tag_switch__group_tags_3_0_i45);
Define_label(mercury__tag_switch__group_tags_3_0_i36);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__group_tags_3_0_i44,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i44);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	r8 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_1);
Define_label(mercury__tag_switch__group_tags_3_0_i45);
	detstackvar(1) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__group_tags_3_0_i46,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i46);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r6 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__tag_switch__group_tags_3_0_i15,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i32);
	detstackvar(2) = (Integer) r5;
	r1 = string_const("non-du tag in tag_switch__group_tags", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_tags_3_0_i48,
		STATIC(mercury__tag_switch__group_tags_3_0));
	}
Define_label(mercury__tag_switch__group_tags_3_0_i48);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_tags_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__tag_switch__group_tags_3_0,
		STATIC(mercury__tag_switch__group_tags_3_0));
Define_label(mercury__tag_switch__group_tags_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module8)
	init_entry(mercury__tag_switch__order_tags_3_0);
	init_label(mercury__tag_switch__order_tags_3_0_i4);
	init_label(mercury__tag_switch__order_tags_3_0_i8);
	init_label(mercury__tag_switch__order_tags_3_0_i10);
	init_label(mercury__tag_switch__order_tags_3_0_i11);
	init_label(mercury__tag_switch__order_tags_3_0_i7);
	init_label(mercury__tag_switch__order_tags_3_0_i3);
	init_label(mercury__tag_switch__order_tags_3_0_i16);
	init_label(mercury__tag_switch__order_tags_3_0_i1000);
BEGIN_CODE

/* code for predicate 'tag_switch__order_tags'/3 in mode 0 */
Define_static(mercury__tag_switch__order_tags_3_0);
	incr_sp_push_msg(5, "tag_switch__order_tags");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__tag_switch__select_frequent_tag_4_0),
		mercury__tag_switch__order_tags_3_0_i4,
		STATIC(mercury__tag_switch__order_tags_3_0));
Define_label(mercury__tag_switch__order_tags_3_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_tags_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__order_tags_3_0_i3);
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__order_tags_3_0_i8,
		STATIC(mercury__tag_switch__order_tags_3_0));
	}
Define_label(mercury__tag_switch__order_tags_3_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_tags_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__order_tags_3_0_i7);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__delete_3_1);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__tag_switch__order_tags_3_0_i10,
		STATIC(mercury__tag_switch__order_tags_3_0));
	}
Define_label(mercury__tag_switch__order_tags_3_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_tags_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	localcall(mercury__tag_switch__order_tags_3_0,
		LABEL(mercury__tag_switch__order_tags_3_0_i11),
		STATIC(mercury__tag_switch__order_tags_3_0));
Define_label(mercury__tag_switch__order_tags_3_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_tags_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__tag_switch__order_tags_3_0_i7);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__tag_switch__order_tags_3_0,
		STATIC(mercury__tag_switch__order_tags_3_0));
Define_label(mercury__tag_switch__order_tags_3_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_tag_switch__common_3);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__is_empty_1_0);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__tag_switch__order_tags_3_0_i16,
		STATIC(mercury__tag_switch__order_tags_3_0));
	}
Define_label(mercury__tag_switch__order_tags_3_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_tags_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__order_tags_3_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__tag_switch__order_tags_3_0_i1000);
	r1 = string_const("TagCaseMap0 is not empty in tag_switch__order_tags", 50);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__order_tags_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module9)
	init_entry(mercury__tag_switch__select_frequent_tag_4_0);
	init_label(mercury__tag_switch__select_frequent_tag_4_0_i5);
	init_label(mercury__tag_switch__select_frequent_tag_4_0_i4);
	init_label(mercury__tag_switch__select_frequent_tag_4_0_i1004);
BEGIN_CODE

/* code for predicate 'tag_switch__select_frequent_tag'/4 in mode 0 */
Define_static(mercury__tag_switch__select_frequent_tag_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__select_frequent_tag_4_0_i1004);
	incr_sp_push_msg(5, "tag_switch__select_frequent_tag");
	detstackvar(5) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r2, ((Integer) 1)), ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__tag_switch__select_frequent_tag_4_0,
		LABEL(mercury__tag_switch__select_frequent_tag_4_0_i5),
		STATIC(mercury__tag_switch__select_frequent_tag_4_0));
Define_label(mercury__tag_switch__select_frequent_tag_4_0_i5);
	update_prof_current_proc(LABEL(mercury__tag_switch__select_frequent_tag_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__tag_switch__select_frequent_tag_4_0_i4);
	if (((Integer) r3 <= (Integer) detstackvar(4)))
		GOTO_LABEL(mercury__tag_switch__select_frequent_tag_4_0_i4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r4 = (Integer) tempr1;
	r1 = TRUE;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__tag_switch__select_frequent_tag_4_0_i4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__tag_switch__select_frequent_tag_4_0_i1004);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module10)
	init_entry(mercury__tag_switch__cons_list_to_tag_list_2_0);
	init_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i3);
	init_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i4);
	init_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'tag_switch__cons_list_to_tag_list'/2 in mode 0 */
Define_static(mercury__tag_switch__cons_list_to_tag_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__tag_switch__cons_list_to_tag_list_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i3);
	while (1) {
	incr_sp_push_msg(1, "tag_switch__cons_list_to_tag_list");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module11)
	init_entry(mercury____Unify___tag_switch__stag_loc_0_0);
	init_label(mercury____Unify___tag_switch__stag_loc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__stag_loc_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___tag_switch__stag_loc_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___tag_switch__stag_loc_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module12)
	init_entry(mercury____Index___tag_switch__stag_loc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__stag_loc_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		STATIC(mercury____Index___tag_switch__stag_loc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__tag_switch_module13)
	init_entry(mercury____Compare___tag_switch__stag_loc_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__stag_loc_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___tag_switch__stag_loc_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__tag_switch_bunch_0(void)
{
	mercury__tag_switch_module0();
	mercury__tag_switch_module1();
	mercury__tag_switch_module2();
	mercury__tag_switch_module3();
	mercury__tag_switch_module4();
	mercury__tag_switch_module5();
	mercury__tag_switch_module6();
	mercury__tag_switch_module7();
	mercury__tag_switch_module8();
	mercury__tag_switch_module9();
	mercury__tag_switch_module10();
	mercury__tag_switch_module11();
	mercury__tag_switch_module12();
	mercury__tag_switch_module13();
}

#endif

void mercury__tag_switch__init(void); /* suppress gcc warning */
void mercury__tag_switch__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__tag_switch_bunch_0();
#endif
}
