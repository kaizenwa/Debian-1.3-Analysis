/*
** Automatically generated from `det_analysis.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__det_analysis__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__det_analysis__det_infer_goal_2__ua10000_10_0);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1023);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1022);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1021);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1020);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1019);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1018);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1017);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i5);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i6);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i7);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i8);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i9);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i10);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i16);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i15);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i17);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i18);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i19);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1011);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1013);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i21);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i23);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i24);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i25);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1015);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i27);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i29);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i30);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i31);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i32);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i33);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i34);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i35);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i36);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i37);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i41);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i42);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i43);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i44);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i45);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i49);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i50);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i46);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i54);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i56);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i57);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i55);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i58);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i59);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i60);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i51);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i61);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i62);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i63);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i65);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i66);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i67);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i68);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i69);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i70);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i71);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i75);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i72);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1016);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i80);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i79);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i82);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i83);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i84);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i81);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i91);
Declare_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i92);
Define_extern_entry(mercury__det_analysis__determinism_pass_4_0);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i2);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i3);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i4);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i5);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i6);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i7);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i8);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i11);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i12);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i13);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i14);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i15);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i16);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i17);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i18);
Declare_label(mercury__det_analysis__determinism_pass_4_0_i19);
Define_extern_entry(mercury__det_analysis__determinism_check_proc_6_0);
Declare_label(mercury__det_analysis__determinism_check_proc_6_0_i2);
Declare_label(mercury__det_analysis__determinism_check_proc_6_0_i3);
Declare_label(mercury__det_analysis__determinism_check_proc_6_0_i4);
Define_extern_entry(mercury__det_analysis__det_conjunction_maxsoln_3_0);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1011);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1001);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1002);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i9);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i10);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i12);
Declare_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1004);
Define_extern_entry(mercury__det_analysis__det_conjunction_canfail_3_0);
Declare_label(mercury__det_analysis__det_conjunction_canfail_3_0_i5);
Declare_label(mercury__det_analysis__det_conjunction_canfail_3_0_i3);
Declare_label(mercury__det_analysis__det_conjunction_canfail_3_0_i7);
Define_extern_entry(mercury__det_analysis__det_disjunction_maxsoln_3_0);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1011);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1010);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1001);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1002);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i9);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i12);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i16);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i18);
Declare_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i20);
Define_extern_entry(mercury__det_analysis__det_disjunction_canfail_3_0);
Declare_label(mercury__det_analysis__det_disjunction_canfail_3_0_i5);
Declare_label(mercury__det_analysis__det_disjunction_canfail_3_0_i3);
Declare_label(mercury__det_analysis__det_disjunction_canfail_3_0_i7);
Define_extern_entry(mercury__det_analysis__det_switch_maxsoln_3_0);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1011);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1010);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1001);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1002);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i9);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i12);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i16);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i18);
Declare_label(mercury__det_analysis__det_switch_maxsoln_3_0_i20);
Define_extern_entry(mercury__det_analysis__det_switch_canfail_3_0);
Declare_label(mercury__det_analysis__det_switch_canfail_3_0_i5);
Declare_label(mercury__det_analysis__det_switch_canfail_3_0_i3);
Declare_label(mercury__det_analysis__det_switch_canfail_3_0_i7);
Define_extern_entry(mercury__det_analysis__det_negation_det_2_0);
Declare_label(mercury__det_analysis__det_negation_det_2_0_i3);
Declare_label(mercury__det_analysis__det_negation_det_2_0_i4);
Declare_label(mercury__det_analysis__det_negation_det_2_0_i5);
Declare_label(mercury__det_analysis__det_negation_det_2_0_i9);
Declare_label(mercury__det_analysis__det_negation_det_2_0_i10);
Declare_static(mercury__det_analysis__global_inference_pass_6_0);
Declare_label(mercury__det_analysis__global_inference_pass_6_0_i2);
Declare_label(mercury__det_analysis__global_inference_pass_6_0_i3);
Declare_label(mercury__det_analysis__global_inference_pass_6_0_i4);
Declare_static(mercury__det_analysis__global_inference_single_pass_10_0);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i4);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i5);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i11);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i12);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i13);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i14);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i15);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i8);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i6);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i20);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i21);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i22);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i23);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i24);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i17);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i26);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i27);
Declare_label(mercury__det_analysis__global_inference_single_pass_10_0_i1005);
Declare_static(mercury__det_analysis__det_infer_proc_8_0);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i2);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i3);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i4);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i5);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i6);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i9);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i11);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i8);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i12);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i13);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i14);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i15);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i16);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i17);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i18);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i19);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i20);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i21);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i22);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i23);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i24);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i25);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i26);
Declare_label(mercury__det_analysis__det_infer_proc_8_0_i27);
Declare_static(mercury__det_analysis__det_infer_goal_7_0);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i2);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i3);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i6);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i5);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i8);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i9);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i10);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i13);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i12);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i15);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i16);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i20);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i19);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i22);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i17);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i23);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i28);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i29);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i30);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i1008);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i1010);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i39);
Declare_label(mercury__det_analysis__det_infer_goal_7_0_i31);
Declare_static(mercury__det_analysis__det_infer_conj_7_0);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i4);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i5);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i6);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i7);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i11);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i12);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i13);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i14);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i15);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i16);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i17);
Declare_label(mercury__det_analysis__det_infer_conj_7_0_i1004);
Declare_static(mercury__det_analysis__det_infer_disj_9_0);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i4);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i5);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i6);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i7);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i8);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i9);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i3);
Declare_label(mercury__det_analysis__det_infer_disj_9_0_i10);
Declare_static(mercury__det_analysis__det_infer_switch_9_0);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i4);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i5);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i6);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i7);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i1003);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i9);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i3);
Declare_label(mercury__det_analysis__det_infer_switch_9_0_i10);
Declare_static(mercury__det_analysis__det_infer_unify_2_0);
Declare_label(mercury__det_analysis__det_infer_unify_2_0_i1009);
Declare_label(mercury__det_analysis__det_infer_unify_2_0_i7);
Declare_label(mercury__det_analysis__det_infer_unify_2_0_i1007);
Declare_label(mercury__det_analysis__det_infer_unify_2_0_i1008);
Declare_static(mercury__det_analysis__get_all_pred_procs_2_4_0);
Declare_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i4);
Declare_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i5);
Declare_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i6);
Declare_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i1002);
Declare_static(mercury__det_analysis__fold_pred_modes_4_0);
Declare_label(mercury__det_analysis__fold_pred_modes_4_0_i3);
Declare_label(mercury__det_analysis__fold_pred_modes_4_0_i1);
Declare_static(mercury__det_analysis__segregate_procs_2_6_0);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i4);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i5);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i6);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i7);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i8);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i10);
Declare_label(mercury__det_analysis__segregate_procs_2_6_0_i1004);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_det_analysis__base_type_layout_soln_context_0[];
Word * mercury_data_det_analysis__base_type_info_soln_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_det_analysis__base_type_layout_soln_context_0
};

extern Word * mercury_data_det_analysis__common_4[];
Word * mercury_data_det_analysis__base_type_layout_soln_context_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_analysis__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_analysis__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_analysis__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_analysis__common_4)
};

Word mercury_data_det_analysis__common_0[] = {
	((Integer) 7)
};

Word mercury_data_det_analysis__common_1[] = {
	((Integer) 1)
};

Word mercury_data_det_analysis__common_2[] = {
	((Integer) 6)
};

Word mercury_data_det_analysis__common_3[] = {
	((Integer) 0)
};

Word * mercury_data_det_analysis__common_4[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("all_solns", 9),
	(Word *) string_const("first_soln", 10)
};

BEGIN_MODULE(mercury__det_analysis_module0)
	init_entry(mercury__det_analysis__det_infer_goal_2__ua10000_10_0);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1023);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1022);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1021);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1020);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1019);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1018);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1017);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i5);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i6);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i7);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i8);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i9);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i10);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i16);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i15);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i17);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i18);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i19);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1011);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1013);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i21);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i23);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i24);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i25);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1015);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i27);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i29);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i30);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i31);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i32);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i33);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i34);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i35);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i36);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i37);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i41);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i42);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i43);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i44);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i45);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i49);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i50);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i46);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i54);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i56);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i57);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i55);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i58);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i59);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i60);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i51);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i61);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i62);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i63);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i65);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i66);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i67);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i68);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i69);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i70);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i71);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i75);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i72);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1016);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i80);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i79);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i82);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i83);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i84);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i81);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i91);
	init_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i92);
BEGIN_CODE

/* code for predicate 'det_infer_goal_2__ua10000'/10 in mode 0 */
Define_static(mercury__det_analysis__det_infer_goal_2__ua10000_10_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1016);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1023) AND
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1022) AND
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1021) AND
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1020) AND
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1019) AND
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1018) AND
		LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1017));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1023);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i5);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1022);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i10);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1021);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i23);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1020);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i25);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1019);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i31);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1018);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i33);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1017);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i69);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = ((Integer) 1);
	r6 = ((Integer) 0);
	call_localret(STATIC(mercury__det_analysis__det_infer_switch_9_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i6,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	detstackvar(5) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i7,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i7);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_canfail_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i8,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i8);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i9,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i9);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i10);
	r9 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	if ((tag((Integer) r8) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1013);
	detstackvar(6) = (Integer) r9;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r4;
	r1 = (Integer) field(mktag(2), (Integer) r8, ((Integer) 3));
	detstackvar(10) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 0));
	detstackvar(11) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 1));
	detstackvar(12) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 2));
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 4));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i16,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i16);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if ((((Integer) 2) != (Integer) r2))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i15);
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i17);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i15);
	r5 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r1 = (Integer) detstackvar(14);
	r3 = ((Integer) 0);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i17);
	detstackvar(1) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i18,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i18);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(5) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__det_report__det_check_lambda_6_0);
	call_localret(ENTRY(mercury__det_report__det_check_lambda_6_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i19,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i19);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1011,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1011);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	tag_incr_hp(r2, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(6);
	r3 = (Integer) r1;
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) r2, ((Integer) 5)) = (Integer) detstackvar(9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 5));
	field(mktag(2), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(13);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(12);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r2, ((Integer) 4)) = (Integer) r1;
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) tempr1;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i21);
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1013);
	tag_incr_hp(r2, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) r2, ((Integer) 2)) = (Integer) r8;
	field(mktag(3), (Integer) r2, ((Integer) 3)) = (Integer) r7;
	field(mktag(3), (Integer) r2, ((Integer) 4)) = (Integer) r6;
	field(mktag(3), (Integer) r2, ((Integer) 5)) = (Integer) r4;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) r6;
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i21);
	detstackvar(5) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	call_localret(STATIC(mercury__det_analysis__det_infer_unify_2_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i9,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i23);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = ((Integer) 0);
	r6 = ((Integer) 0);
	call_localret(STATIC(mercury__det_analysis__det_infer_disj_9_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i24,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i24);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i25);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	r3 = ((Integer) 1);
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1015,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1015);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	detstackvar(5) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	{
		call_localret(STATIC(mercury__det_analysis__det_negation_det_2_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i27,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i27);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i29);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i29);
	r1 = string_const("inappropriate determinism inside a negation", 43);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i30,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i30);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i31);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i32,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i32);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i33);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__det_util__update_instmap_3_0);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i34,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i34);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i35,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i35);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(9) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i36,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i36);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i37);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i37);
	r11 = (Integer) r1;
	r12 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i41);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i37);
	r11 = (Integer) r1;
	r12 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = ((Integer) 0);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(9);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i41);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	detstackvar(1) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(6) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i42,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i42);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(12) = (Integer) r2;
	detstackvar(13) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i43,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i43);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i44,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i44);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r4 = (Integer) detstackvar(5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	detstackvar(5) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i45,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i45);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) detstackvar(2) != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i46);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(11);
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_maxsoln_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i49,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i49);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_canfail_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i50,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i50);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i65);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i46);
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i51);
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(12);
	{
		call_localret(STATIC(mercury__det_analysis__det_negation_det_2_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i54,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i54);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i56);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i55);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i56);
	r1 = string_const("cannot find determinism of negated condition", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i57,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i57);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(3);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i55);
	detstackvar(5) = (Integer) r2;
	detstackvar(9) = (Integer) r3;
	detstackvar(13) = (Integer) r4;
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r7;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i58,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i58);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_maxsoln_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i59,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i59);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_canfail_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i60,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i60);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i65);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i51);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(11);
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_maxsoln_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i61,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i61);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__det_analysis__det_switch_maxsoln_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i62,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i62);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
		call_localret(STATIC(mercury__det_analysis__det_switch_canfail_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i63,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i63);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i65);
	detstackvar(5) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	detstackvar(13) = (Integer) r5;
	detstackvar(1) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i66,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i66);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i67,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i67);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i68,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i68);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i69);
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) r3;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r5;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__det_util__det_lookup_detism_4_0);
	call_localret(ENTRY(mercury__det_util__det_lookup_detism_4_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i70,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i70);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i71,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i71);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i72);
	if (((Integer) detstackvar(3) == ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i72);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i75);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i72);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i1016);
	incr_sp_push_msg(15, "det_infer_goal_2__ua10000");
	detstackvar(15) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i79);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__det_analysis__det_infer_conj_7_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i80,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i80);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i79);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i81);
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) r3;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r5;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__det_util__det_lookup_detism_4_0);
	call_localret(ENTRY(mercury__det_util__det_lookup_detism_4_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i82,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i82);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i83,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i83);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i84);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i75);
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i84);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i81);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i91,
		STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i91);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0));
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i92);
	if (((Integer) detstackvar(3) == ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i92);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 8);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__det_analysis__det_infer_goal_2__ua10000_10_0_i92);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module1)
	init_entry(mercury__det_analysis__determinism_pass_4_0);
	init_label(mercury__det_analysis__determinism_pass_4_0_i2);
	init_label(mercury__det_analysis__determinism_pass_4_0_i3);
	init_label(mercury__det_analysis__determinism_pass_4_0_i4);
	init_label(mercury__det_analysis__determinism_pass_4_0_i5);
	init_label(mercury__det_analysis__determinism_pass_4_0_i6);
	init_label(mercury__det_analysis__determinism_pass_4_0_i7);
	init_label(mercury__det_analysis__determinism_pass_4_0_i8);
	init_label(mercury__det_analysis__determinism_pass_4_0_i11);
	init_label(mercury__det_analysis__determinism_pass_4_0_i12);
	init_label(mercury__det_analysis__determinism_pass_4_0_i13);
	init_label(mercury__det_analysis__determinism_pass_4_0_i14);
	init_label(mercury__det_analysis__determinism_pass_4_0_i15);
	init_label(mercury__det_analysis__determinism_pass_4_0_i16);
	init_label(mercury__det_analysis__determinism_pass_4_0_i17);
	init_label(mercury__det_analysis__determinism_pass_4_0_i18);
	init_label(mercury__det_analysis__determinism_pass_4_0_i19);
BEGIN_CODE

/* code for predicate 'determinism_pass'/4 in mode 0 */
Define_entry(mercury__det_analysis__determinism_pass_4_0);
	incr_sp_push_msg(6, "determinism_pass");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__det_analysis__determinism_pass_4_0_i2,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i2);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_analysis__determinism_pass_4_0_i3,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i3);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__det_analysis__get_all_pred_procs_2_4_0),
		mercury__det_analysis__determinism_pass_4_0_i4,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
Define_label(mercury__det_analysis__determinism_pass_4_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__det_analysis__segregate_procs_2_6_0),
		mercury__det_analysis__determinism_pass_4_0_i5,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
Define_label(mercury__det_analysis__determinism_pass_4_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 11);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__det_analysis__determinism_pass_4_0_i6,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 17);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__det_analysis__determinism_pass_4_0_i7,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i7);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	if (((Integer) detstackvar(3) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__determinism_pass_4_0_i8);
	r3 = (Integer) r2;
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Doing determinism checking...\n", 32);
	r4 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__det_analysis__determinism_pass_4_0_i14);
Define_label(mercury__det_analysis__determinism_pass_4_0_i8);
	r3 = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Doing determinism inference...\n", 33);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__det_analysis__determinism_pass_4_0_i11,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i11);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__det_analysis__global_inference_pass_6_0),
		mercury__det_analysis__determinism_pass_4_0_i12,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
Define_label(mercury__det_analysis__determinism_pass_4_0_i12);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% done.\n", 8);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__det_analysis__determinism_pass_4_0_i13,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i13);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Doing determinism checking...\n", 32);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(1);
Define_label(mercury__det_analysis__determinism_pass_4_0_i14);
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r5;
	detstackvar(1) = (Integer) r6;
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__det_analysis__determinism_pass_4_0_i15,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i15);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	call_localret(STATIC(mercury__det_analysis__global_inference_single_pass_10_0),
		mercury__det_analysis__determinism_pass_4_0_i16,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
Define_label(mercury__det_analysis__determinism_pass_4_0_i16);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__det_report__det_report_and_handle_msgs_5_0);
	call_localret(ENTRY(mercury__det_report__det_report_and_handle_msgs_5_0),
		mercury__det_analysis__determinism_pass_4_0_i17,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i17);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__det_report__global_checking_pass_5_0);
	call_localret(ENTRY(mercury__det_report__global_checking_pass_5_0),
		mercury__det_analysis__determinism_pass_4_0_i18,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i18);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% done.\n", 8);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__det_analysis__determinism_pass_4_0_i19,
		ENTRY(mercury__det_analysis__determinism_pass_4_0));
	}
Define_label(mercury__det_analysis__determinism_pass_4_0_i19);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_pass_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module2)
	init_entry(mercury__det_analysis__determinism_check_proc_6_0);
	init_label(mercury__det_analysis__determinism_check_proc_6_0_i2);
	init_label(mercury__det_analysis__determinism_check_proc_6_0_i3);
	init_label(mercury__det_analysis__determinism_check_proc_6_0_i4);
BEGIN_CODE

/* code for predicate 'determinism_check_proc'/6 in mode 0 */
Define_entry(mercury__det_analysis__determinism_check_proc_6_0);
	incr_sp_push_msg(4, "determinism_check_proc");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = ((Integer) 17);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__det_analysis__determinism_check_proc_6_0_i2,
		ENTRY(mercury__det_analysis__determinism_check_proc_6_0));
	}
Define_label(mercury__det_analysis__determinism_check_proc_6_0_i2);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_check_proc_6_0));
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 2));
	r6 = (Integer) r2;
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	r2 = (Integer) r1;
	tempr2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r1 = (Integer) tempr2;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	field(mktag(1), (Integer) tempr2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__det_analysis__global_inference_single_pass_10_0),
		mercury__det_analysis__determinism_check_proc_6_0_i3,
		ENTRY(mercury__det_analysis__determinism_check_proc_6_0));
	}
Define_label(mercury__det_analysis__determinism_check_proc_6_0_i3);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_check_proc_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__det_report__det_report_and_handle_msgs_5_0);
	call_localret(ENTRY(mercury__det_report__det_report_and_handle_msgs_5_0),
		mercury__det_analysis__determinism_check_proc_6_0_i4,
		ENTRY(mercury__det_analysis__determinism_check_proc_6_0));
	}
	}
Define_label(mercury__det_analysis__determinism_check_proc_6_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__determinism_check_proc_6_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__det_report__global_checking_pass_5_0);
	tailcall(ENTRY(mercury__det_report__global_checking_pass_5_0),
		ENTRY(mercury__det_analysis__determinism_check_proc_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module3)
	init_entry(mercury__det_analysis__det_conjunction_maxsoln_3_0);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1011);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1001);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1002);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i9);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i10);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i12);
	init_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1004);
BEGIN_CODE

/* code for predicate 'det_conjunction_maxsoln'/3 in mode 0 */
Define_entry(mercury__det_analysis__det_conjunction_maxsoln_3_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1001) AND
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1002) AND
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1011) AND
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1004));
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1011);
	incr_sp_push_msg(1, "det_conjunction_maxsoln");
	detstackvar(1) = (Integer) succip;
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i10) AND
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i10) AND
		LABEL(mercury__det_analysis__det_conjunction_maxsoln_3_0_i12));
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1001);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1002);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 1),
		((Integer) 2),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i10);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i12);
	r1 = string_const("det_conjunction_maxsoln: many_cc , many", 39);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__det_analysis__det_conjunction_maxsoln_3_0));
	}
Define_label(mercury__det_analysis__det_conjunction_maxsoln_3_0_i1004);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 3),
		((Integer) 3),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module4)
	init_entry(mercury__det_analysis__det_conjunction_canfail_3_0);
	init_label(mercury__det_analysis__det_conjunction_canfail_3_0_i5);
	init_label(mercury__det_analysis__det_conjunction_canfail_3_0_i3);
	init_label(mercury__det_analysis__det_conjunction_canfail_3_0_i7);
BEGIN_CODE

/* code for predicate 'det_conjunction_canfail'/3 in mode 0 */
Define_entry(mercury__det_analysis__det_conjunction_canfail_3_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_conjunction_canfail_3_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_conjunction_canfail_3_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__det_analysis__det_conjunction_canfail_3_0_i5);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__det_analysis__det_conjunction_canfail_3_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_conjunction_canfail_3_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__det_analysis__det_conjunction_canfail_3_0_i7);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module5)
	init_entry(mercury__det_analysis__det_disjunction_maxsoln_3_0);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1011);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1010);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1001);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1002);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i9);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i12);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i16);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i18);
	init_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i20);
BEGIN_CODE

/* code for predicate 'det_disjunction_maxsoln'/3 in mode 0 */
Define_entry(mercury__det_analysis__det_disjunction_maxsoln_3_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1001) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1002) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1011) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1010));
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1011);
	incr_sp_push_msg(1, "det_disjunction_maxsoln");
	detstackvar(1) = (Integer) succip;
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i12));
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1010);
	incr_sp_push_msg(1, "det_disjunction_maxsoln");
	detstackvar(1) = (Integer) succip;
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i16) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i16) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i18) AND
		LABEL(mercury__det_analysis__det_disjunction_maxsoln_3_0_i20));
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1001);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 1),
		((Integer) 2),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i1002);
	{
	static const Word mercury_const_1[] = {
		((Integer) 1),
		((Integer) 3),
		((Integer) 2),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i9);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i12);
	r1 = string_const("det_disjunction_maxsoln: cc in first case, not cc in second case", 64);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__det_analysis__det_disjunction_maxsoln_3_0));
	}
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i16);
	r1 = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i18);
	r1 = string_const("det_disjunction_maxsoln: cc in second case, not cc in first case", 64);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__det_analysis__det_disjunction_maxsoln_3_0));
	}
Define_label(mercury__det_analysis__det_disjunction_maxsoln_3_0_i20);
	r1 = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module6)
	init_entry(mercury__det_analysis__det_disjunction_canfail_3_0);
	init_label(mercury__det_analysis__det_disjunction_canfail_3_0_i5);
	init_label(mercury__det_analysis__det_disjunction_canfail_3_0_i3);
	init_label(mercury__det_analysis__det_disjunction_canfail_3_0_i7);
BEGIN_CODE

/* code for predicate 'det_disjunction_canfail'/3 in mode 0 */
Define_entry(mercury__det_analysis__det_disjunction_canfail_3_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_disjunction_canfail_3_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_disjunction_canfail_3_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__det_analysis__det_disjunction_canfail_3_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__det_analysis__det_disjunction_canfail_3_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_disjunction_canfail_3_0_i7);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__det_analysis__det_disjunction_canfail_3_0_i7);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module7)
	init_entry(mercury__det_analysis__det_switch_maxsoln_3_0);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1011);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1010);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1001);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1002);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i9);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i12);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i16);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i18);
	init_label(mercury__det_analysis__det_switch_maxsoln_3_0_i20);
BEGIN_CODE

/* code for predicate 'det_switch_maxsoln'/3 in mode 0 */
Define_entry(mercury__det_analysis__det_switch_maxsoln_3_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i1001) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i1002) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i1011) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i1010));
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1011);
	incr_sp_push_msg(1, "det_switch_maxsoln");
	detstackvar(1) = (Integer) succip;
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i9) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i12));
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1010);
	incr_sp_push_msg(1, "det_switch_maxsoln");
	detstackvar(1) = (Integer) succip;
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i16) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i16) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i18) AND
		LABEL(mercury__det_analysis__det_switch_maxsoln_3_0_i20));
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1001);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 1),
		((Integer) 2),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i1002);
	{
	static const Word mercury_const_1[] = {
		((Integer) 1),
		((Integer) 1),
		((Integer) 2),
		((Integer) 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r2);
	}
	proceed();
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i9);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i12);
	r1 = string_const("det_switch_maxsoln: cc in first case, not cc in second case", 59);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__det_analysis__det_switch_maxsoln_3_0));
	}
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i16);
	r1 = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i18);
	r1 = string_const("det_switch_maxsoln: cc in second case, not cc in first case", 59);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__det_analysis__det_switch_maxsoln_3_0));
	}
Define_label(mercury__det_analysis__det_switch_maxsoln_3_0_i20);
	r1 = ((Integer) 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module8)
	init_entry(mercury__det_analysis__det_switch_canfail_3_0);
	init_label(mercury__det_analysis__det_switch_canfail_3_0_i5);
	init_label(mercury__det_analysis__det_switch_canfail_3_0_i3);
	init_label(mercury__det_analysis__det_switch_canfail_3_0_i7);
BEGIN_CODE

/* code for predicate 'det_switch_canfail'/3 in mode 0 */
Define_entry(mercury__det_analysis__det_switch_canfail_3_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_switch_canfail_3_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_switch_canfail_3_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__det_analysis__det_switch_canfail_3_0_i5);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__det_analysis__det_switch_canfail_3_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_switch_canfail_3_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__det_analysis__det_switch_canfail_3_0_i7);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module9)
	init_entry(mercury__det_analysis__det_negation_det_2_0);
	init_label(mercury__det_analysis__det_negation_det_2_0_i3);
	init_label(mercury__det_analysis__det_negation_det_2_0_i4);
	init_label(mercury__det_analysis__det_negation_det_2_0_i5);
	init_label(mercury__det_analysis__det_negation_det_2_0_i9);
	init_label(mercury__det_analysis__det_negation_det_2_0_i10);
BEGIN_CODE

/* code for predicate 'det_negation_det'/2 in mode 0 */
Define_entry(mercury__det_analysis__det_negation_det_2_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__det_analysis__det_negation_det_2_0_i3) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i4) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i5) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i5) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i5) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i5) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i9) AND
		LABEL(mercury__det_analysis__det_negation_det_2_0_i10));
Define_label(mercury__det_analysis__det_negation_det_2_0_i3);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_det_analysis__common_0);
	proceed();
Define_label(mercury__det_analysis__det_negation_det_2_0_i4);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_det_analysis__common_1);
	proceed();
Define_label(mercury__det_analysis__det_negation_det_2_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__det_analysis__det_negation_det_2_0_i9);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_det_analysis__common_2);
	proceed();
Define_label(mercury__det_analysis__det_negation_det_2_0_i10);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_det_analysis__common_3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module10)
	init_entry(mercury__det_analysis__global_inference_pass_6_0);
	init_label(mercury__det_analysis__global_inference_pass_6_0_i2);
	init_label(mercury__det_analysis__global_inference_pass_6_0_i3);
	init_label(mercury__det_analysis__global_inference_pass_6_0_i4);
BEGIN_CODE

/* code for predicate 'global_inference_pass'/6 in mode 0 */
Define_static(mercury__det_analysis__global_inference_pass_6_0);
	incr_sp_push_msg(6, "global_inference_pass");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r6 = (Integer) r4;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	call_localret(STATIC(mercury__det_analysis__global_inference_single_pass_10_0),
		mercury__det_analysis__global_inference_pass_6_0_i2,
		STATIC(mercury__det_analysis__global_inference_pass_6_0));
Define_label(mercury__det_analysis__global_inference_pass_6_0_i2);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_pass_6_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("% Inference pass complete\n", 26);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__det_analysis__global_inference_pass_6_0_i3,
		STATIC(mercury__det_analysis__global_inference_pass_6_0));
	}
Define_label(mercury__det_analysis__global_inference_pass_6_0_i3);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_pass_6_0));
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__global_inference_pass_6_0_i4);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__det_analysis__global_inference_pass_6_0,
		STATIC(mercury__det_analysis__global_inference_pass_6_0));
Define_label(mercury__det_analysis__global_inference_pass_6_0_i4);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__det_report__det_report_and_handle_msgs_5_0);
	tailcall(ENTRY(mercury__det_report__det_report_and_handle_msgs_5_0),
		STATIC(mercury__det_analysis__global_inference_pass_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module11)
	init_entry(mercury__det_analysis__global_inference_single_pass_10_0);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i4);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i5);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i11);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i12);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i13);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i14);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i15);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i8);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i6);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i20);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i21);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i22);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i23);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i24);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i17);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i26);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i27);
	init_label(mercury__det_analysis__global_inference_single_pass_10_0_i1005);
BEGIN_CODE

/* code for predicate 'global_inference_single_pass'/10 in mode 0 */
Define_static(mercury__det_analysis__global_inference_single_pass_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i1005);
	incr_sp_push_msg(10, "global_inference_single_pass");
	detstackvar(10) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) r6;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__globals__io_get_globals_3_0);
	call_localret(ENTRY(mercury__globals__io_get_globals_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i4,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__det_analysis__det_infer_proc_8_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i5,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	if (((Integer) r3 != (Integer) r2))
		GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i6);
	if (((Integer) detstackvar(1) != ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i8);
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	detstackvar(8) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	r1 = string_const("% Inferred old detism ", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i11,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i11);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_det_3_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_det_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i12,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i12);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r2 = (Integer) r1;
	r1 = string_const(" for ", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i13,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i13);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i14,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i14);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i15,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i15);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i26);
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i8);
	r2 = (Integer) r4;
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) r1;
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(2);
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i26);
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i6);
	if (((Integer) detstackvar(1) != ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i17);
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	detstackvar(8) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	r1 = string_const("% Inferred new detism ", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i20,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i20);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_det_3_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_det_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i21,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i21);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r2 = (Integer) r1;
	r1 = string_const(" for ", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i22,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i22);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i23,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i23);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__det_analysis__global_inference_single_pass_10_0_i24,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i24);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(9);
	r7 = ((Integer) 0);
	r8 = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	GOTO_LABEL(mercury__det_analysis__global_inference_single_pass_10_0_i26);
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i17);
	r2 = (Integer) r4;
	r4 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) r1;
	r7 = ((Integer) 0);
	r8 = (Integer) detstackvar(2);
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i26);
	detstackvar(1) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__global_inference_single_pass_10_0_i27,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
	}
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i27);
	update_prof_current_proc(LABEL(mercury__det_analysis__global_inference_single_pass_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__det_analysis__global_inference_single_pass_10_0,
		STATIC(mercury__det_analysis__global_inference_single_pass_10_0));
Define_label(mercury__det_analysis__global_inference_single_pass_10_0_i1005);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	r4 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module12)
	init_entry(mercury__det_analysis__det_infer_proc_8_0);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i2);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i3);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i4);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i5);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i6);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i9);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i11);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i8);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i12);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i13);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i14);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i15);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i16);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i17);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i18);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i19);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i20);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i21);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i22);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i23);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i24);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i25);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i26);
	init_label(mercury__det_analysis__det_infer_proc_8_0_i27);
BEGIN_CODE

/* code for predicate 'det_infer_proc'/8 in mode 0 */
Define_static(mercury__det_analysis__det_infer_proc_8_0);
	incr_sp_push_msg(14, "det_infer_proc");
	detstackvar(14) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_analysis__det_infer_proc_8_0_i2,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i2);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r3 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_analysis__det_infer_proc_8_0_i3,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i3);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	detstackvar(9) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__det_analysis__det_infer_proc_8_0_i4,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r3 = (Integer) r1;
	detstackvar(10) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_analysis__det_infer_proc_8_0_i5,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	detstackvar(11) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_inferred_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_inferred_determinism_2_0),
		mercury__det_analysis__det_infer_proc_8_0_i6,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__det_analysis__det_infer_proc_8_0_i9,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i9);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__det_infer_proc_8_0_i8);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i11,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i11);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	if ((((Integer) 2) != (Integer) r2))
		GOTO_LABEL(mercury__det_analysis__det_infer_proc_8_0_i8);
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	r10 = ((Integer) 1);
	GOTO_LABEL(mercury__det_analysis__det_infer_proc_8_0_i12);
Define_label(mercury__det_analysis__det_infer_proc_8_0_i8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(11);
	r10 = ((Integer) 0);
Define_label(mercury__det_analysis__det_infer_proc_8_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(9) = (Integer) r8;
	detstackvar(10) = (Integer) r9;
	detstackvar(11) = (Integer) r1;
	detstackvar(6) = (Integer) r10;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__det_analysis__det_infer_proc_8_0_i13,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i13);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i14,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i14);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__det_util__det_info_init_5_0);
	call_localret(ENTRY(mercury__det_util__det_info_init_5_0),
		mercury__det_analysis__det_infer_proc_8_0_i15,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i15);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_proc_8_0_i16,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
Define_label(mercury__det_analysis__det_infer_proc_8_0_i16);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	detstackvar(7) = (Integer) r3;
	detstackvar(6) = (Integer) r1;
	detstackvar(12) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i17,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i17);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r3 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) r1;
	detstackvar(13) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i18,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i18);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__det_analysis__det_switch_canfail_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i19,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i19);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	{
		call_localret(STATIC(mercury__det_analysis__det_switch_maxsoln_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i20,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i20);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_proc_8_0_i21,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i21);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i22,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i22);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_inferred_determinism_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i23,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i23);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__det_analysis__det_infer_proc_8_0_i24,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i24);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i25,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i25);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__det_analysis__det_infer_proc_8_0_i26,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i26);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__det_analysis__det_infer_proc_8_0_i27,
		STATIC(mercury__det_analysis__det_infer_proc_8_0));
	}
Define_label(mercury__det_analysis__det_infer_proc_8_0_i27);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_proc_8_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module13)
	init_entry(mercury__det_analysis__det_infer_goal_7_0);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i2);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i3);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i6);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i5);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i8);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i9);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i10);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i13);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i12);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i15);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i16);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i20);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i19);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i22);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i17);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i23);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i28);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i29);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i30);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i1008);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i1010);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i39);
	init_label(mercury__det_analysis__det_infer_goal_7_0_i31);
BEGIN_CODE

/* code for predicate 'det_infer_goal'/7 in mode 0 */
Define_static(mercury__det_analysis__det_infer_goal_7_0);
	incr_sp_push_msg(15, "det_infer_goal");
	detstackvar(15) = (Integer) succip;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__det_analysis__det_infer_goal_7_0_i2,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i2);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__det_analysis__det_infer_goal_7_0_i3,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i3);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	r3 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__det_util__det_no_output_vars_4_0);
	call_localret(ENTRY(mercury__det_util__det_no_output_vars_4_0),
		mercury__det_analysis__det_infer_goal_7_0_i6,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i5);
	r3 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	r7 = ((Integer) 1);
	r4 = ((Integer) 1);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i8);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(8);
	r7 = ((Integer) 0);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i8);
	detstackvar(6) = (Integer) r2;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r4;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_2__ua10000_10_0),
		mercury__det_analysis__det_infer_goal_7_0_i9,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
Define_label(mercury__det_analysis__det_infer_goal_7_0_i9);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(12) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_goal_7_0_i10,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i10);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	detstackvar(13) = (Integer) r1;
	detstackvar(14) = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_unreachable_1_0),
		mercury__det_analysis__det_infer_goal_7_0_i13,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i13);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i12);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
	r1 = (Integer) detstackvar(13);
	r2 = ((Integer) 0);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i15);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i12);
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(14);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i15);
	detstackvar(6) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	detstackvar(11) = (Integer) r6;
	detstackvar(12) = (Integer) r7;
	detstackvar(13) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_goal_7_0_i16,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i16);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	if (((Integer) detstackvar(4) != ((Integer) 2)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i20);
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i19);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i20);
	if (((Integer) detstackvar(4) != ((Integer) 3)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i17);
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(4);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i19);
	if (((Integer) r3 == ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i22);
	detstackvar(6) = (Integer) r2;
	detstackvar(10) = (Integer) r4;
	detstackvar(11) = (Integer) r5;
	detstackvar(12) = (Integer) r6;
	detstackvar(13) = (Integer) r1;
	detstackvar(4) = (Integer) r7;
	r1 = (Integer) r8;
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i17);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i22);
	r3 = (Integer) r2;
	r4 = (Integer) r5;
	r5 = (Integer) r6;
	r6 = (Integer) r8;
	r2 = ((Integer) 1);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i28);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i17);
	if (((Integer) detstackvar(4) != ((Integer) 3)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i23);
	if (((Integer) detstackvar(10) != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i23);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = ((Integer) 2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i28);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i23);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(12);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i28);
	detstackvar(6) = (Integer) r3;
	detstackvar(11) = (Integer) r4;
	detstackvar(12) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_goal_7_0_i29,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i29);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	r2 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_determinism_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_determinism_3_0),
		mercury__det_analysis__det_infer_goal_7_0_i30,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i30);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	if (((Integer) detstackvar(4) == (Integer) detstackvar(7)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i31);
	if ((tag((Integer) detstackvar(11)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i1008);
	if (((Integer) field(mktag(3), (Integer) detstackvar(11), ((Integer) 0)) == ((Integer) 2)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i31);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i1008);
	r2 = (Integer) detstackvar(11);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i1010);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 == ((Integer) 4)))
		GOTO_LABEL(mercury__det_analysis__det_infer_goal_7_0_i31);
Define_label(mercury__det_analysis__det_infer_goal_7_0_i1010);
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_determinism_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_determinism_3_0),
		mercury__det_analysis__det_infer_goal_7_0_i39,
		STATIC(mercury__det_analysis__det_infer_goal_7_0));
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i39);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_goal_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	r2 = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(12);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__det_analysis__det_infer_goal_7_0_i31);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module14)
	init_entry(mercury__det_analysis__det_infer_conj_7_0);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i4);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i5);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i6);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i7);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i11);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i12);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i13);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i14);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i15);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i16);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i17);
	init_label(mercury__det_analysis__det_infer_conj_7_0_i1004);
BEGIN_CODE

/* code for predicate 'det_infer_conj'/7 in mode 0 */
Define_static(mercury__det_analysis__det_infer_conj_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__det_infer_conj_7_0_i1004);
	incr_sp_push_msg(7, "det_infer_conj");
	detstackvar(7) = (Integer) succip;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__det_util__update_instmap_3_0);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__det_analysis__det_infer_conj_7_0_i4,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__det_analysis__det_infer_conj_7_0,
		LABEL(mercury__det_analysis__det_infer_conj_7_0_i5),
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
Define_label(mercury__det_analysis__det_infer_conj_7_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_conj_7_0_i6,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_conj_7_0_i7);
	if (((Integer) detstackvar(2) != ((Integer) 1)))
		GOTO_LABEL(mercury__det_analysis__det_infer_conj_7_0_i7);
	r7 = (Integer) r1;
	r8 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__det_analysis__det_infer_conj_7_0_i11);
Define_label(mercury__det_analysis__det_infer_conj_7_0_i7);
	r7 = (Integer) r1;
	r8 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 0);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
Define_label(mercury__det_analysis__det_infer_conj_7_0_i11);
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_conj_7_0_i12,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
Define_label(mercury__det_analysis__det_infer_conj_7_0_i12);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_conj_7_0_i13,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i13);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_canfail_3_0),
		mercury__det_analysis__det_infer_conj_7_0_i14,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i14);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__det_analysis__det_conjunction_maxsoln_3_0),
		mercury__det_analysis__det_infer_conj_7_0_i15,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i15);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_conj_7_0_i16,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i16);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__det_infer_conj_7_0_i17,
		STATIC(mercury__det_analysis__det_infer_conj_7_0));
	}
Define_label(mercury__det_analysis__det_infer_conj_7_0_i17);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_conj_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__det_analysis__det_infer_conj_7_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = ((Integer) 0);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module15)
	init_entry(mercury__det_analysis__det_infer_disj_9_0);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i4);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i5);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i6);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i7);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i8);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i9);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i3);
	init_label(mercury__det_analysis__det_infer_disj_9_0_i10);
BEGIN_CODE

/* code for predicate 'det_infer_disj'/9 in mode 0 */
Define_static(mercury__det_analysis__det_infer_disj_9_0);
	incr_sp_push_msg(9, "det_infer_disj");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__det_infer_disj_9_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_disj_9_0_i4,
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
Define_label(mercury__det_analysis__det_infer_disj_9_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_disj_9_0_i5,
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
	}
Define_label(mercury__det_analysis__det_infer_disj_9_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__det_analysis__det_disjunction_canfail_3_0),
		mercury__det_analysis__det_infer_disj_9_0_i6,
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
	}
Define_label(mercury__det_analysis__det_infer_disj_9_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__det_analysis__det_disjunction_maxsoln_3_0),
		mercury__det_analysis__det_infer_disj_9_0_i7,
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
	}
Define_label(mercury__det_analysis__det_infer_disj_9_0_i7);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	localcall(mercury__det_analysis__det_infer_disj_9_0,
		LABEL(mercury__det_analysis__det_infer_disj_9_0_i8),
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
Define_label(mercury__det_analysis__det_infer_disj_9_0_i8);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	detstackvar(2) = (Integer) r2;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(8);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__det_infer_disj_9_0_i9,
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_disj_9_0_i9);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__det_analysis__det_infer_disj_9_0_i3);
	r1 = (Integer) r5;
	r2 = (Integer) r6;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_disj_9_0_i10,
		STATIC(mercury__det_analysis__det_infer_disj_9_0));
	}
Define_label(mercury__det_analysis__det_infer_disj_9_0_i10);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_disj_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module16)
	init_entry(mercury__det_analysis__det_infer_switch_9_0);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i4);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i5);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i6);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i7);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i1003);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i9);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i3);
	init_label(mercury__det_analysis__det_infer_switch_9_0_i10);
BEGIN_CODE

/* code for predicate 'det_infer_switch'/9 in mode 0 */
Define_static(mercury__det_analysis__det_infer_switch_9_0);
	incr_sp_push_msg(9, "det_infer_switch");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__det_infer_switch_9_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	call_localret(STATIC(mercury__det_analysis__det_infer_goal_7_0),
		mercury__det_analysis__det_infer_switch_9_0_i4,
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
	}
Define_label(mercury__det_analysis__det_infer_switch_9_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) r2;
	detstackvar(8) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__det_analysis__det_infer_switch_9_0_i5,
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_switch_9_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__det_analysis__det_switch_canfail_3_0),
		mercury__det_analysis__det_infer_switch_9_0_i6,
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
	}
Define_label(mercury__det_analysis__det_infer_switch_9_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__det_analysis__det_switch_maxsoln_3_0),
		mercury__det_analysis__det_infer_switch_9_0_i7,
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
	}
Define_label(mercury__det_analysis__det_infer_switch_9_0_i7);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	localcall(mercury__det_analysis__det_infer_switch_9_0,
		LABEL(mercury__det_analysis__det_infer_switch_9_0_i1003),
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
Define_label(mercury__det_analysis__det_infer_switch_9_0_i1003);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	detstackvar(2) = (Integer) r2;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(8);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__det_analysis__det_infer_switch_9_0_i9,
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
	}
	}
Define_label(mercury__det_analysis__det_infer_switch_9_0_i9);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__det_analysis__det_infer_switch_9_0_i3);
	r1 = (Integer) r5;
	r2 = (Integer) r6;
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__det_analysis__det_infer_switch_9_0_i10,
		STATIC(mercury__det_analysis__det_infer_switch_9_0));
	}
Define_label(mercury__det_analysis__det_infer_switch_9_0_i10);
	update_prof_current_proc(LABEL(mercury__det_analysis__det_infer_switch_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module17)
	init_entry(mercury__det_analysis__det_infer_unify_2_0);
	init_label(mercury__det_analysis__det_infer_unify_2_0_i1009);
	init_label(mercury__det_analysis__det_infer_unify_2_0_i7);
	init_label(mercury__det_analysis__det_infer_unify_2_0_i1007);
	init_label(mercury__det_analysis__det_infer_unify_2_0_i1008);
BEGIN_CODE

/* code for predicate 'det_infer_unify'/2 in mode 0 */
Define_static(mercury__det_analysis__det_infer_unify_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__det_analysis__det_infer_unify_2_0_i1009);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__det_analysis__det_infer_unify_2_0_i1007);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__det_analysis__det_infer_unify_2_0_i1009);
	incr_sp_push_msg(1, "det_infer_unify");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__det_analysis__det_infer_unify_2_0_i7);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__det_analysis__det_infer_unify_2_0_i7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__det_analysis__det_infer_unify_2_0_i1008);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	tailcall(ENTRY(mercury__hlds_data__determinism_components_3_1),
		STATIC(mercury__det_analysis__det_infer_unify_2_0));
	}
Define_label(mercury__det_analysis__det_infer_unify_2_0_i1007);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	tailcall(ENTRY(mercury__hlds_data__determinism_components_3_1),
		STATIC(mercury__det_analysis__det_infer_unify_2_0));
	}
Define_label(mercury__det_analysis__det_infer_unify_2_0_i1008);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module18)
	init_entry(mercury__det_analysis__get_all_pred_procs_2_4_0);
	init_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i4);
	init_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i5);
	init_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i6);
	init_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'get_all_pred_procs_2'/4 in mode 0 */
Define_static(mercury__det_analysis__get_all_pred_procs_2_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__get_all_pred_procs_2_4_0_i1002);
	incr_sp_push_msg(5, "get_all_pred_procs_2");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_analysis__get_all_pred_procs_2_4_0_i4,
		STATIC(mercury__det_analysis__get_all_pred_procs_2_4_0));
	}
Define_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__get_all_pred_procs_2_4_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__det_analysis__get_all_pred_procs_2_4_0_i5,
		STATIC(mercury__det_analysis__get_all_pred_procs_2_4_0));
	}
Define_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__get_all_pred_procs_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__det_analysis__fold_pred_modes_4_0),
		mercury__det_analysis__get_all_pred_procs_2_4_0_i6,
		STATIC(mercury__det_analysis__get_all_pred_procs_2_4_0));
Define_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__get_all_pred_procs_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__det_analysis__get_all_pred_procs_2_4_0,
		STATIC(mercury__det_analysis__get_all_pred_procs_2_4_0));
Define_label(mercury__det_analysis__get_all_pred_procs_2_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module19)
	init_entry(mercury__det_analysis__fold_pred_modes_4_0);
	init_label(mercury__det_analysis__fold_pred_modes_4_0_i3);
	init_label(mercury__det_analysis__fold_pred_modes_4_0_i1);
BEGIN_CODE

/* code for predicate 'fold_pred_modes'/4 in mode 0 */
Define_static(mercury__det_analysis__fold_pred_modes_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__fold_pred_modes_4_0_i1);
Define_label(mercury__det_analysis__fold_pred_modes_4_0_i3);
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r5 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__fold_pred_modes_4_0_i3);
	}
Define_label(mercury__det_analysis__fold_pred_modes_4_0_i1);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_analysis_module20)
	init_entry(mercury__det_analysis__segregate_procs_2_6_0);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i4);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i5);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i6);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i7);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i8);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i10);
	init_label(mercury__det_analysis__segregate_procs_2_6_0_i1004);
BEGIN_CODE

/* code for predicate 'segregate_procs_2'/6 in mode 0 */
Define_static(mercury__det_analysis__segregate_procs_2_6_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__segregate_procs_2_6_0_i1004);
	incr_sp_push_msg(8, "segregate_procs_2");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(7) = (Integer) tempr1;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_analysis__segregate_procs_2_6_0_i4,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
	}
	}
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__det_analysis__segregate_procs_2_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_analysis__segregate_procs_2_6_0_i5,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
	}
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__det_analysis__segregate_procs_2_6_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__det_analysis__segregate_procs_2_6_0_i6,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
	}
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__det_analysis__segregate_procs_2_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_analysis__segregate_procs_2_6_0_i7,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
	}
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__det_analysis__segregate_procs_2_6_0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_declared_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_determinism_2_0),
		mercury__det_analysis__segregate_procs_2_6_0_i8,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
	}
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__det_analysis__segregate_procs_2_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__det_analysis__segregate_procs_2_6_0_i10);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__det_analysis__segregate_procs_2_6_0,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i10);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__det_analysis__segregate_procs_2_6_0,
		STATIC(mercury__det_analysis__segregate_procs_2_6_0));
Define_label(mercury__det_analysis__segregate_procs_2_6_0_i1004);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__det_analysis_bunch_0(void)
{
	mercury__det_analysis_module0();
	mercury__det_analysis_module1();
	mercury__det_analysis_module2();
	mercury__det_analysis_module3();
	mercury__det_analysis_module4();
	mercury__det_analysis_module5();
	mercury__det_analysis_module6();
	mercury__det_analysis_module7();
	mercury__det_analysis_module8();
	mercury__det_analysis_module9();
	mercury__det_analysis_module10();
	mercury__det_analysis_module11();
	mercury__det_analysis_module12();
	mercury__det_analysis_module13();
	mercury__det_analysis_module14();
	mercury__det_analysis_module15();
	mercury__det_analysis_module16();
	mercury__det_analysis_module17();
	mercury__det_analysis_module18();
	mercury__det_analysis_module19();
	mercury__det_analysis_module20();
}

#endif

void mercury__det_analysis__init(void); /* suppress gcc warning */
void mercury__det_analysis__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__det_analysis_bunch_0();
#endif
}
