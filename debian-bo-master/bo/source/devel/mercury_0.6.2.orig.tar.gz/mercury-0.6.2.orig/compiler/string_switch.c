/*
** Automatically generated from `string_switch.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__string_switch__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___string_switch_hash_slot_0__ua10000_2_0);
Declare_static(mercury__string_switch__generate__ua10000_9_0);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i2);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i3);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i4);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i5);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i6);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i7);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i8);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i9);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i10);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i11);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i12);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i13);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i14);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i15);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i16);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i17);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i18);
Declare_label(mercury__string_switch__generate__ua10000_9_0_i19);
Define_extern_entry(mercury__string_switch__generate_9_0);
Declare_static(mercury__string_switch__hash_cases_3_0);
Declare_label(mercury__string_switch__hash_cases_3_0_i4);
Declare_label(mercury__string_switch__hash_cases_3_0_i5);
Declare_label(mercury__string_switch__hash_cases_3_0_i8);
Declare_label(mercury__string_switch__hash_cases_3_0_i9);
Declare_label(mercury__string_switch__hash_cases_3_0_i10);
Declare_label(mercury__string_switch__hash_cases_3_0_i13);
Declare_label(mercury__string_switch__hash_cases_3_0_i12);
Declare_label(mercury__string_switch__hash_cases_3_0_i1006);
Declare_static(mercury__string_switch__calc_hash_slots_3_0);
Declare_label(mercury__string_switch__calc_hash_slots_3_0_i2);
Declare_static(mercury__string_switch__calc_hash_slots_1_6_0);
Declare_label(mercury__string_switch__calc_hash_slots_1_6_0_i4);
Declare_label(mercury__string_switch__calc_hash_slots_1_6_0_i1002);
Declare_static(mercury__string_switch__calc_hash_slots_2_7_0);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i4);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i7);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i9);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i10);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i11);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i12);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i13);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i6);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i14);
Declare_label(mercury__string_switch__calc_hash_slots_2_7_0_i1005);
Declare_static(mercury__string_switch__follow_hash_chain_3_0);
Declare_label(mercury__string_switch__follow_hash_chain_3_0_i2);
Declare_label(mercury__string_switch__follow_hash_chain_3_0_i5);
Declare_label(mercury__string_switch__follow_hash_chain_3_0_i4);
Declare_static(mercury__string_switch__next_free_hash_slot_4_0);
Declare_label(mercury__string_switch__next_free_hash_slot_4_0_i6);
Declare_label(mercury__string_switch__next_free_hash_slot_4_0_i10);
Declare_label(mercury__string_switch__next_free_hash_slot_4_0_i3);
Declare_static(mercury__string_switch__gen_hash_slots_13_0);
Declare_label(mercury__string_switch__gen_hash_slots_13_0_i2);
Declare_label(mercury__string_switch__gen_hash_slots_13_0_i4);
Declare_label(mercury__string_switch__gen_hash_slots_13_0_i5);
Declare_static(mercury__string_switch__gen_hash_slot_13_0);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i4);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i6);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i9);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i10);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i11);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i1019);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i15);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i17);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i18);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i14);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i19);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i20);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i21);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i22);
Declare_label(mercury__string_switch__gen_hash_slot_13_0_i3);
Declare_static(mercury__string_switch__this_is_last_case_3_0);
Declare_label(mercury__string_switch__this_is_last_case_3_0_i6);
Declare_label(mercury__string_switch__this_is_last_case_3_0_i1003);
Declare_label(mercury__string_switch__this_is_last_case_3_0_i1);
Declare_static(mercury____Unify___string_switch__hash_slot_0_0);
Declare_label(mercury____Unify___string_switch__hash_slot_0_0_i2);
Declare_label(mercury____Unify___string_switch__hash_slot_0_0_i1);
Declare_static(mercury____Index___string_switch__hash_slot_0_0);
Declare_static(mercury____Compare___string_switch__hash_slot_0_0);
Declare_label(mercury____Compare___string_switch__hash_slot_0_0_i4);
Declare_label(mercury____Compare___string_switch__hash_slot_0_0_i3);

extern Word * mercury_data_string_switch__base_type_layout_hash_slot_0[];
Word * mercury_data_string_switch__base_type_info_hash_slot_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___string_switch__hash_slot_0_0),
	(Word *) (Integer) STATIC(mercury____Index___string_switch__hash_slot_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___string_switch__hash_slot_0_0),
	(Word *) (Integer) mercury_data_string_switch__base_type_layout_hash_slot_0
};

extern Word * mercury_data_string_switch__common_12[];
Word * mercury_data_string_switch__base_type_layout_hash_slot_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_12),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_switch_gen__base_type_info_extended_case_0[];
Word * mercury_data_string_switch__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_switch_gen__base_type_info_extended_case_0
};

Word * mercury_data_string_switch__common_1[] = {
	(Word *) string_const("hashed string switch", 20)
};

Word * mercury_data_string_switch__common_2[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_1),
	(Word *) string_const("", 0)
};

Word mercury_data_string_switch__common_3[] = {
	((Integer) 0)
};

Word * mercury_data_string_switch__common_4[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_3)
};

Word * mercury_data_string_switch__common_5[] = {
	(Word *) string_const("\"", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_string_switch__common_6[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_string_switch__common_4)
};

Word mercury_data_string_switch__common_7[] = {
	((Integer) -2)
};

Word * mercury_data_string_switch__common_8[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_7)
};

Word * mercury_data_string_switch__common_9[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_string_switch__common_8)
};

Word * mercury_data_string_switch__common_10[] = {
	(Word *) (Integer) mercury_data_switch_gen__base_type_info_extended_case_0
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_string_switch__common_11[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_string_switch__common_12[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_11),
	(Word *) string_const("hash_slot", 9)
};

BEGIN_MODULE(mercury__string_switch_module0)
	init_entry(mercury____Index___string_switch_hash_slot_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___string_switch_hash_slot_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___string_switch_hash_slot_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module1)
	init_entry(mercury__string_switch__generate__ua10000_9_0);
	init_label(mercury__string_switch__generate__ua10000_9_0_i2);
	init_label(mercury__string_switch__generate__ua10000_9_0_i3);
	init_label(mercury__string_switch__generate__ua10000_9_0_i4);
	init_label(mercury__string_switch__generate__ua10000_9_0_i5);
	init_label(mercury__string_switch__generate__ua10000_9_0_i6);
	init_label(mercury__string_switch__generate__ua10000_9_0_i7);
	init_label(mercury__string_switch__generate__ua10000_9_0_i8);
	init_label(mercury__string_switch__generate__ua10000_9_0_i9);
	init_label(mercury__string_switch__generate__ua10000_9_0_i10);
	init_label(mercury__string_switch__generate__ua10000_9_0_i11);
	init_label(mercury__string_switch__generate__ua10000_9_0_i12);
	init_label(mercury__string_switch__generate__ua10000_9_0_i13);
	init_label(mercury__string_switch__generate__ua10000_9_0_i14);
	init_label(mercury__string_switch__generate__ua10000_9_0_i15);
	init_label(mercury__string_switch__generate__ua10000_9_0_i16);
	init_label(mercury__string_switch__generate__ua10000_9_0_i17);
	init_label(mercury__string_switch__generate__ua10000_9_0_i18);
	init_label(mercury__string_switch__generate__ua10000_9_0_i19);
BEGIN_CODE

/* code for predicate 'string_switch__generate__ua10000'/9 in mode 0 */
Define_static(mercury__string_switch__generate__ua10000_9_0);
	incr_sp_push_msg(19, "string_switch__generate__ua10000");
	detstackvar(19) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	r1 = (Integer) r2;
	r2 = (Integer) r6;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__string_switch__generate__ua10000_9_0_i2,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i2);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__string_switch__generate__ua10000_9_0_i3,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i3);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__acquire_reg_3_0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_3_0),
		mercury__string_switch__generate__ua10000_9_0_i4,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i4);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(9) = (Integer) r1;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	detstackvar(10) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__string_switch__generate__ua10000_9_0_i5,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i5);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__string_switch__generate__ua10000_9_0_i6,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i6);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__string_switch__generate__ua10000_9_0_i7,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i7);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__string_switch__generate__ua10000_9_0_i8,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i8);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__string_switch__generate__ua10000_9_0_i9,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i9);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	detstackvar(15) = (Integer) r1;
	detstackvar(18) = (Integer) r2;
	r1 = (Integer) mercury_data_switch_gen__base_type_info_extended_case_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__string_switch__generate__ua10000_9_0_i10,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i10);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	{
	Declare_entry(mercury__int__log2_2_0);
	call_localret(ENTRY(mercury__int__log2_2_0),
		mercury__string_switch__generate__ua10000_9_0_i11,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i11);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__int__pow_3_0);
	call_localret(ENTRY(mercury__int__pow_3_0),
		mercury__string_switch__generate__ua10000_9_0_i12,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i12);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r3 = (((Integer) 2) * (Integer) r1);
	r2 = ((Integer) r3 - ((Integer) 1));
	detstackvar(16) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	call_localret(STATIC(mercury__string_switch__hash_cases_3_0),
		mercury__string_switch__generate__ua10000_9_0_i13,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
Define_label(mercury__string_switch__generate__ua10000_9_0_i13);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r3 = (Integer) r1;
	detstackvar(17) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_0);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__string_switch__generate__ua10000_9_0_i14,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i14);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r2 = (Integer) detstackvar(17);
	call_localret(STATIC(mercury__string_switch__calc_hash_slots_3_0),
		mercury__string_switch__generate__ua10000_9_0_i15,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
Define_label(mercury__string_switch__generate__ua10000_9_0_i15);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__string_switch__generate__ua10000_9_0_i16,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i16);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_info__release_reg_3_0);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__string_switch__generate__ua10000_9_0_i17,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i17);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__string_switch__generate__ua10000_9_0_i18,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
	}
Define_label(mercury__string_switch__generate__ua10000_9_0_i18);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r8 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 0);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__string_switch__gen_hash_slots_13_0),
		mercury__string_switch__generate__ua10000_9_0_i19,
		STATIC(mercury__string_switch__generate__ua10000_9_0));
Define_label(mercury__string_switch__generate__ua10000_9_0_i19);
	update_prof_current_proc(LABEL(mercury__string_switch__generate__ua10000_9_0));
	r6 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	tag_incr_hp(r8, mktag(1), ((Integer) 1));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_2);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(r11, mktag(0), ((Integer) 2));
	tag_incr_hp(r12, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r12, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r12, ((Integer) 1)) = (Integer) detstackvar(8);
	tag_incr_hp(r13, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r13, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r13, ((Integer) 1)) = ((Integer) 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 7);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r13, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r14, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(0), (Integer) r11, ((Integer) 1)) = string_const("compute the hash value of the input string", 42);
	field(mktag(3), (Integer) r12, ((Integer) 2)) = (Integer) r13;
	field(mktag(3), (Integer) r13, ((Integer) 3)) = (Integer) r14;
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r12, ((Integer) 1)) = string_const("begin hash chain loop", 21);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) detstackvar(10);
	tag_incr_hp(r15, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r15, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r15, ((Integer) 1)) = ((Integer) 14);
	tag_incr_hp(tempr1, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(15);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = ((Integer) 1);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r15, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("lookup the string for this hash slot", 36);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) r15;
	field(mktag(3), (Integer) r15, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	tag_incr_hp(r14, mktag(0), ((Integer) 2));
	tag_incr_hp(r15, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r15, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r16, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r16, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r16, ((Integer) 1)) = ((Integer) 10);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) r16, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r17, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = ((Integer) 15);
	field(mktag(3), (Integer) r17, ((Integer) 3)) = (Integer) detstackvar(6);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(3), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(3), (Integer) r16, ((Integer) 3)) = (Integer) r17;
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r14, ((Integer) 1)) = string_const("did we find a match?", 20);
	field(mktag(3), (Integer) r15, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r15, mktag(0), ((Integer) 2));
	tag_incr_hp(r16, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r16, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r16, ((Integer) 1)) = (Integer) detstackvar(8);
	tag_incr_hp(r17, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = ((Integer) 14);
	tag_incr_hp(tempr1, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(14);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = ((Integer) 1);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(0), (Integer) r15, ((Integer) 1)) = string_const("not yet, so get next slot in hash chain", 39);
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r16, ((Integer) 2)) = (Integer) r17;
	field(mktag(3), (Integer) r17, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r15;
	field(mktag(0), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(r17, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 9);
	tag_incr_hp(r18, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r18, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r18, ((Integer) 1)) = ((Integer) 24);
	field(mktag(3), (Integer) r18, ((Integer) 3)) = (Integer) mkword(mktag(3), (Integer) mercury_data_string_switch__common_4);
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(3), (Integer) r18, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("keep searching until we reach the end of the chain", 50);
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) r3;
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	tag_incr_hp(r17, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(12);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r17, ((Integer) 1)) = string_const("no match, so fail", 17);
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	field(mktag(0), (Integer) r17, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	tag_incr_hp(r10, mktag(1), ((Integer) 1));
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	tag_incr_hp(r12, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(13);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r12, ((Integer) 1)) = string_const("we found a match", 16);
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r12, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	tag_incr_hp(r13, mktag(0), ((Integer) 2));
	tag_incr_hp(r14, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r14, ((Integer) 0)) = ((Integer) 7);
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(3), (Integer) r14, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r14, ((Integer) 1)) = (Integer) r3;
	r2 = (Integer) r5;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r13;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r13, ((Integer) 0)) = (Integer) r14;
	field(mktag(0), (Integer) r13, ((Integer) 1)) = string_const("jump to the corresponding code", 30);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__string_switch_module2)
	init_entry(mercury__string_switch__generate_9_0);
BEGIN_CODE

/* code for predicate 'string_switch__generate'/9 in mode 0 */
Define_entry(mercury__string_switch__generate_9_0);
	r4 = (Integer) r5;
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	tailcall(STATIC(mercury__string_switch__generate__ua10000_9_0),
		ENTRY(mercury__string_switch__generate_9_0));
END_MODULE

BEGIN_MODULE(mercury__string_switch_module3)
	init_entry(mercury__string_switch__hash_cases_3_0);
	init_label(mercury__string_switch__hash_cases_3_0_i4);
	init_label(mercury__string_switch__hash_cases_3_0_i5);
	init_label(mercury__string_switch__hash_cases_3_0_i8);
	init_label(mercury__string_switch__hash_cases_3_0_i9);
	init_label(mercury__string_switch__hash_cases_3_0_i10);
	init_label(mercury__string_switch__hash_cases_3_0_i13);
	init_label(mercury__string_switch__hash_cases_3_0_i12);
	init_label(mercury__string_switch__hash_cases_3_0_i1006);
BEGIN_CODE

/* code for predicate 'string_switch__hash_cases'/3 in mode 0 */
Define_static(mercury__string_switch__hash_cases_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__string_switch__hash_cases_3_0_i1006);
	incr_sp_push_msg(4, "string_switch__hash_cases");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__string_switch__hash_cases_3_0,
		LABEL(mercury__string_switch__hash_cases_3_0_i4),
		STATIC(mercury__string_switch__hash_cases_3_0));
Define_label(mercury__string_switch__hash_cases_3_0_i4);
	update_prof_current_proc(LABEL(mercury__string_switch__hash_cases_3_0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__string_switch__hash_cases_3_0_i5);
	r4 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__string_switch__hash_cases_3_0_i9);
Define_label(mercury__string_switch__hash_cases_3_0_i5);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("string_switch__hash_cases: non-string case?", 43);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__string_switch__hash_cases_3_0_i8,
		STATIC(mercury__string_switch__hash_cases_3_0));
	}
Define_label(mercury__string_switch__hash_cases_3_0_i8);
	update_prof_current_proc(LABEL(mercury__string_switch__hash_cases_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
Define_label(mercury__string_switch__hash_cases_3_0_i9);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__string__hash_2_0);
	call_localret(ENTRY(mercury__string__hash_2_0),
		mercury__string_switch__hash_cases_3_0_i10,
		STATIC(mercury__string_switch__hash_cases_3_0));
	}
Define_label(mercury__string_switch__hash_cases_3_0_i10);
	update_prof_current_proc(LABEL(mercury__string_switch__hash_cases_3_0));
	r4 = ((Integer) r1 & (Integer) detstackvar(1));
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_0);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__string_switch__hash_cases_3_0_i13,
		STATIC(mercury__string_switch__hash_cases_3_0));
	}
Define_label(mercury__string_switch__hash_cases_3_0_i13);
	update_prof_current_proc(LABEL(mercury__string_switch__hash_cases_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__string_switch__hash_cases_3_0_i12);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__map__set_4_1);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__string_switch__hash_cases_3_0));
	}
Define_label(mercury__string_switch__hash_cases_3_0_i12);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__map__set_4_1);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__string_switch__hash_cases_3_0));
	}
Define_label(mercury__string_switch__hash_cases_3_0_i1006);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	tailcall(ENTRY(mercury__map__init_1_0),
		STATIC(mercury__string_switch__hash_cases_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__string_switch_module4)
	init_entry(mercury__string_switch__calc_hash_slots_3_0);
	init_label(mercury__string_switch__calc_hash_slots_3_0_i2);
BEGIN_CODE

/* code for predicate 'string_switch__calc_hash_slots'/3 in mode 0 */
Define_static(mercury__string_switch__calc_hash_slots_3_0);
	incr_sp_push_msg(3, "string_switch__calc_hash_slots");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__string_switch__calc_hash_slots_3_0_i2,
		STATIC(mercury__string_switch__calc_hash_slots_3_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_3_0_i2);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__string_switch__calc_hash_slots_1_6_0),
		STATIC(mercury__string_switch__calc_hash_slots_3_0));
END_MODULE

BEGIN_MODULE(mercury__string_switch_module5)
	init_entry(mercury__string_switch__calc_hash_slots_1_6_0);
	init_label(mercury__string_switch__calc_hash_slots_1_6_0_i4);
	init_label(mercury__string_switch__calc_hash_slots_1_6_0_i1002);
BEGIN_CODE

/* code for predicate 'string_switch__calc_hash_slots_1'/6 in mode 0 */
Define_static(mercury__string_switch__calc_hash_slots_1_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__string_switch__calc_hash_slots_1_6_0_i1002);
	incr_sp_push_msg(3, "string_switch__calc_hash_slots_1");
	detstackvar(3) = (Integer) succip;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	call_localret(STATIC(mercury__string_switch__calc_hash_slots_2_7_0),
		mercury__string_switch__calc_hash_slots_1_6_0_i4,
		STATIC(mercury__string_switch__calc_hash_slots_1_6_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_1_6_0_i4);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_1_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__string_switch__calc_hash_slots_1_6_0,
		STATIC(mercury__string_switch__calc_hash_slots_1_6_0));
Define_label(mercury__string_switch__calc_hash_slots_1_6_0_i1002);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module6)
	init_entry(mercury__string_switch__calc_hash_slots_2_7_0);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i4);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i7);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i9);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i10);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i11);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i12);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i13);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i6);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i14);
	init_label(mercury__string_switch__calc_hash_slots_2_7_0_i1005);
BEGIN_CODE

/* code for predicate 'string_switch__calc_hash_slots_2'/7 in mode 0 */
Define_static(mercury__string_switch__calc_hash_slots_2_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__string_switch__calc_hash_slots_2_7_0_i1005);
	incr_sp_push_msg(7, "string_switch__calc_hash_slots_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__string_switch__calc_hash_slots_2_7_0,
		LABEL(mercury__string_switch__calc_hash_slots_2_7_0_i4),
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	r3 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__string_switch__calc_hash_slots_2_7_0_i7,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i7);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__string_switch__calc_hash_slots_2_7_0_i6);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__string_switch__follow_hash_chain_3_0),
		mercury__string_switch__calc_hash_slots_2_7_0_i9,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__string_switch__next_free_hash_slot_4_0),
		mercury__string_switch__calc_hash_slots_2_7_0_i10,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__string_switch__calc_hash_slots_2_7_0_i11,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__string_switch__calc_hash_slots_2_7_0_i12,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = ((Integer) -1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__string_switch__calc_hash_slots_2_7_0_i13,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i6);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = ((Integer) -1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__string_switch__calc_hash_slots_2_7_0_i14,
		STATIC(mercury__string_switch__calc_hash_slots_2_7_0));
	}
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__string_switch__calc_hash_slots_2_7_0));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__string_switch__calc_hash_slots_2_7_0_i1005);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module7)
	init_entry(mercury__string_switch__follow_hash_chain_3_0);
	init_label(mercury__string_switch__follow_hash_chain_3_0_i2);
	init_label(mercury__string_switch__follow_hash_chain_3_0_i5);
	init_label(mercury__string_switch__follow_hash_chain_3_0_i4);
BEGIN_CODE

/* code for predicate 'string_switch__follow_hash_chain'/3 in mode 0 */
Define_static(mercury__string_switch__follow_hash_chain_3_0);
	r3 = (Integer) r1;
	r4 = (Integer) r2;
	incr_sp_push_msg(4, "string_switch__follow_hash_chain");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__string_switch__follow_hash_chain_3_0_i2,
		STATIC(mercury__string_switch__follow_hash_chain_3_0));
	}
Define_label(mercury__string_switch__follow_hash_chain_3_0_i2);
	update_prof_current_proc(LABEL(mercury__string_switch__follow_hash_chain_3_0));
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) < ((Integer) 0)))
		GOTO_LABEL(mercury__string_switch__follow_hash_chain_3_0_i4);
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__string_switch__follow_hash_chain_3_0_i5,
		STATIC(mercury__string_switch__follow_hash_chain_3_0));
	}
Define_label(mercury__string_switch__follow_hash_chain_3_0_i5);
	update_prof_current_proc(LABEL(mercury__string_switch__follow_hash_chain_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__string_switch__follow_hash_chain_3_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__string_switch__follow_hash_chain_3_0,
		STATIC(mercury__string_switch__follow_hash_chain_3_0));
Define_label(mercury__string_switch__follow_hash_chain_3_0_i4);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module8)
	init_entry(mercury__string_switch__next_free_hash_slot_4_0);
	init_label(mercury__string_switch__next_free_hash_slot_4_0_i6);
	init_label(mercury__string_switch__next_free_hash_slot_4_0_i10);
	init_label(mercury__string_switch__next_free_hash_slot_4_0_i3);
BEGIN_CODE

/* code for predicate 'string_switch__next_free_hash_slot'/4 in mode 0 */
Define_static(mercury__string_switch__next_free_hash_slot_4_0);
	r4 = ((Integer) r3 + ((Integer) 1));
	incr_sp_push_msg(4, "string_switch__next_free_hash_slot");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__string_switch__next_free_hash_slot_4_0_i6,
		STATIC(mercury__string_switch__next_free_hash_slot_4_0));
	}
Define_label(mercury__string_switch__next_free_hash_slot_4_0_i6);
	update_prof_current_proc(LABEL(mercury__string_switch__next_free_hash_slot_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__string_switch__next_free_hash_slot_4_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_string_switch__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__string_switch__next_free_hash_slot_4_0_i10,
		STATIC(mercury__string_switch__next_free_hash_slot_4_0));
	}
Define_label(mercury__string_switch__next_free_hash_slot_4_0_i10);
	update_prof_current_proc(LABEL(mercury__string_switch__next_free_hash_slot_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__string_switch__next_free_hash_slot_4_0_i3);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__string_switch__next_free_hash_slot_4_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__string_switch__next_free_hash_slot_4_0,
		STATIC(mercury__string_switch__next_free_hash_slot_4_0));
END_MODULE

BEGIN_MODULE(mercury__string_switch_module9)
	init_entry(mercury__string_switch__gen_hash_slots_13_0);
	init_label(mercury__string_switch__gen_hash_slots_13_0_i2);
	init_label(mercury__string_switch__gen_hash_slots_13_0_i4);
	init_label(mercury__string_switch__gen_hash_slots_13_0_i5);
BEGIN_CODE

/* code for predicate 'string_switch__gen_hash_slots'/13 in mode 0 */
Define_static(mercury__string_switch__gen_hash_slots_13_0);
	incr_sp_push_msg(8, "string_switch__gen_hash_slots");
	detstackvar(8) = (Integer) succip;
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury__string_switch__gen_hash_slots_13_0_i2);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r7;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("end of hashed string switch", 27);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	r5 = (Integer) r8;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__string_switch__gen_hash_slots_13_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	call_localret(STATIC(mercury__string_switch__gen_hash_slot_13_0),
		mercury__string_switch__gen_hash_slots_13_0_i4,
		STATIC(mercury__string_switch__gen_hash_slots_13_0));
Define_label(mercury__string_switch__gen_hash_slots_13_0_i4);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slots_13_0));
	{
	Word tempr1, tempr2, tempr3, tempr4;
	tempr1 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	tempr2 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	tempr3 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	tempr4 = (Integer) r4;
	r4 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) tempr4;
	detstackvar(3) = (Integer) tempr3;
	detstackvar(2) = (Integer) tempr2;
	detstackvar(1) = (Integer) tempr1;
	r8 = (Integer) r5;
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	localcall(mercury__string_switch__gen_hash_slots_13_0,
		LABEL(mercury__string_switch__gen_hash_slots_13_0_i5),
		STATIC(mercury__string_switch__gen_hash_slots_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slots_13_0_i5);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slots_13_0));
	r6 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r6;
	r7 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	r8 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r8;
	r9 = (Integer) r4;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r9;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module10)
	init_entry(mercury__string_switch__gen_hash_slot_13_0);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i4);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i6);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i9);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i10);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i11);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i1019);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i15);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i17);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i18);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i14);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i19);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i20);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i21);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i22);
	init_label(mercury__string_switch__gen_hash_slot_13_0_i3);
BEGIN_CODE

/* code for predicate 'string_switch__gen_hash_slot'/13 in mode 0 */
Define_static(mercury__string_switch__gen_hash_slot_13_0);
	incr_sp_push_msg(14, "string_switch__gen_hash_slot");
	detstackvar(14) = (Integer) succip;
	detstackvar(4) = (Integer) r4;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(9) = (Integer) r8;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__string_switch__gen_hash_slot_13_0_i4,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i4);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__string_switch__gen_hash_slot_13_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), ((Integer) 3));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__string_switch__gen_hash_slot_13_0_i6);
	r10 = (Integer) r2;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	tag_incr_hp(r8, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1, tempr2, tempr3;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r10, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(r9, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 1);
	tempr1 = (Integer) field(mktag(0), (Integer) r10, ((Integer) 0));
	r11 = (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1)), ((Integer) 0));
	tempr2 = (Integer) r10;
	r10 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	tag_incr_hp(tempr3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) tempr3;
	GOTO_LABEL(mercury__string_switch__gen_hash_slot_13_0_i10);
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i6);
	detstackvar(11) = (Integer) r3;
	detstackvar(12) = (Integer) r1;
	r1 = string_const("string_switch__gen_hash_slots: string expected", 46);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__string_switch__gen_hash_slot_13_0_i9,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i9);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r10 = (Integer) detstackvar(12);
	r11 = (Integer) detstackvar(8);
Define_label(mercury__string_switch__gen_hash_slot_13_0_i10);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(11) = (Integer) r9;
	detstackvar(12) = (Integer) r10;
	detstackvar(8) = (Integer) r11;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__string_switch__gen_hash_slot_13_0_i11,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i11);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r3 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	detstackvar(13) = (Integer) r2;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("case \"", 6);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_5);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__string_switch__gen_hash_slot_13_0_i1019,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i1019);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__string_switch__this_is_last_case_3_0),
		mercury__string_switch__gen_hash_slot_13_0_i15,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i15);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__string_switch__gen_hash_slot_13_0_i14);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__string_switch__gen_hash_slot_13_0_i17,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i17);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__string_switch__gen_hash_slot_13_0_i18,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i18);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(10);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(8);
	r5 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	r6 = (Integer) r4;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r9, mktag(1), ((Integer) 1));
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(r11, mktag(0), ((Integer) 2));
	tag_incr_hp(r12, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r12, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r12, ((Integer) 1)) = (Integer) tempr1;
	r5 = (Integer) r6;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) r12;
	field(mktag(0), (Integer) r11, ((Integer) 1)) = string_const("jump to end of switch", 21);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i14);
	r1 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__string_switch__gen_hash_slot_13_0_i19,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i19);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__string_switch__gen_hash_slot_13_0_i20,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i20);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r3 = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__string_switch__gen_hash_slot_13_0_i21,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i21);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__string_switch__gen_hash_slot_13_0_i22,
		STATIC(mercury__string_switch__gen_hash_slot_13_0));
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i22);
	update_prof_current_proc(LABEL(mercury__string_switch__gen_hash_slot_13_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(8);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	r5 = (Integer) r4;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r8, mktag(1), ((Integer) 1));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	tag_incr_hp(r11, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r11, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r10, ((Integer) 1)) = string_const("jump to end of switch", 21);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__string_switch__gen_hash_slot_13_0_i3);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_6);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_string_switch__common_9);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module11)
	init_entry(mercury__string_switch__this_is_last_case_3_0);
	init_label(mercury__string_switch__this_is_last_case_3_0_i6);
	init_label(mercury__string_switch__this_is_last_case_3_0_i1003);
	init_label(mercury__string_switch__this_is_last_case_3_0_i1);
BEGIN_CODE

/* code for predicate 'string_switch__this_is_last_case'/3 in mode 0 */
Define_static(mercury__string_switch__this_is_last_case_3_0);
	r4 = ((Integer) r1 + ((Integer) 1));
	if (((Integer) r4 >= (Integer) r2))
		GOTO_LABEL(mercury__string_switch__this_is_last_case_3_0_i1003);
	incr_sp_push_msg(4, "string_switch__this_is_last_case");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_string_switch__base_type_info_hash_slot_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__string_switch__this_is_last_case_3_0_i6,
		STATIC(mercury__string_switch__this_is_last_case_3_0));
	}
Define_label(mercury__string_switch__this_is_last_case_3_0_i6);
	update_prof_current_proc(LABEL(mercury__string_switch__this_is_last_case_3_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__string_switch__this_is_last_case_3_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__string_switch__this_is_last_case_3_0,
		STATIC(mercury__string_switch__this_is_last_case_3_0));
Define_label(mercury__string_switch__this_is_last_case_3_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__string_switch__this_is_last_case_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module12)
	init_entry(mercury____Unify___string_switch__hash_slot_0_0);
	init_label(mercury____Unify___string_switch__hash_slot_0_0_i2);
	init_label(mercury____Unify___string_switch__hash_slot_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___string_switch__hash_slot_0_0);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___switch_gen__extended_case_0_0);
	call_localret(ENTRY(mercury____Unify___switch_gen__extended_case_0_0),
		mercury____Unify___string_switch__hash_slot_0_0_i2,
		STATIC(mercury____Unify___string_switch__hash_slot_0_0));
	}
Define_label(mercury____Unify___string_switch__hash_slot_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___string_switch__hash_slot_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___string_switch__hash_slot_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___string_switch__hash_slot_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___string_switch__hash_slot_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__string_switch_module13)
	init_entry(mercury____Index___string_switch__hash_slot_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___string_switch__hash_slot_0_0);
	tailcall(STATIC(mercury____Index___string_switch_hash_slot_0__ua10000_2_0),
		STATIC(mercury____Index___string_switch__hash_slot_0_0));
END_MODULE

BEGIN_MODULE(mercury__string_switch_module14)
	init_entry(mercury____Compare___string_switch__hash_slot_0_0);
	init_label(mercury____Compare___string_switch__hash_slot_0_0_i4);
	init_label(mercury____Compare___string_switch__hash_slot_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___string_switch__hash_slot_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___switch_gen__extended_case_0_0);
	call_localret(ENTRY(mercury____Compare___switch_gen__extended_case_0_0),
		mercury____Compare___string_switch__hash_slot_0_0_i4,
		STATIC(mercury____Compare___string_switch__hash_slot_0_0));
	}
Define_label(mercury____Compare___string_switch__hash_slot_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___string_switch__hash_slot_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___string_switch__hash_slot_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___string_switch__hash_slot_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___string_switch__hash_slot_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__string_switch_bunch_0(void)
{
	mercury__string_switch_module0();
	mercury__string_switch_module1();
	mercury__string_switch_module2();
	mercury__string_switch_module3();
	mercury__string_switch_module4();
	mercury__string_switch_module5();
	mercury__string_switch_module6();
	mercury__string_switch_module7();
	mercury__string_switch_module8();
	mercury__string_switch_module9();
	mercury__string_switch_module10();
	mercury__string_switch_module11();
	mercury__string_switch_module12();
	mercury__string_switch_module13();
	mercury__string_switch_module14();
}

#endif

void mercury__string_switch__init(void); /* suppress gcc warning */
void mercury__string_switch__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__string_switch_bunch_0();
#endif
}
