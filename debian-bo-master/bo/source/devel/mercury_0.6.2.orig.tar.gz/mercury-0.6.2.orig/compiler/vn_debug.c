/*
** Automatically generated from `vn_debug.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_debug__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__vn_debug__tuple_msg_5_0);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i2);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i3);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i6);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i9);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i14);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i13);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i15);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i11);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i16);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i10);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i17);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i18);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i19);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i7);
Define_extern_entry(mercury__vn_debug__livemap_msg_3_0);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i2);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i3);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i6);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i9);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i10);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__fragment_msg_3_0);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i2);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i4);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i5);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i6);
Define_extern_entry(mercury__vn_debug__failure_msg_4_0);
Declare_label(mercury__vn_debug__failure_msg_4_0_i2);
Declare_label(mercury__vn_debug__failure_msg_4_0_i3);
Declare_label(mercury__vn_debug__failure_msg_4_0_i6);
Declare_label(mercury__vn_debug__failure_msg_4_0_i9);
Declare_label(mercury__vn_debug__failure_msg_4_0_i10);
Declare_label(mercury__vn_debug__failure_msg_4_0_i11);
Declare_label(mercury__vn_debug__failure_msg_4_0_i12);
Declare_label(mercury__vn_debug__failure_msg_4_0_i13);
Declare_label(mercury__vn_debug__failure_msg_4_0_i14);
Declare_label(mercury__vn_debug__failure_msg_4_0_i7);
Define_extern_entry(mercury__vn_debug__parallel_msgs_3_0);
Declare_label(mercury__vn_debug__parallel_msgs_3_0_i4);
Declare_label(mercury__vn_debug__parallel_msgs_3_0_i1002);
Define_extern_entry(mercury__vn_debug__parallel_msg_3_0);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i2);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i4);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i5);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i6);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i7);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i8);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i9);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i10);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i11);
Define_extern_entry(mercury__vn_debug__computed_goto_msg_5_0);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i2);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i4);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i5);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i6);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i7);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i8);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i9);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i10);
Define_extern_entry(mercury__vn_debug__order_start_msg_5_0);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i2);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i4);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i5);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i6);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i7);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i8);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i9);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i10);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i11);
Define_extern_entry(mercury__vn_debug__order_sink_msg_3_0);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i2);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i4);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i5);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i6);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__order_link_msg_5_0);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i2);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i4);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i7);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i6);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i8);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i5);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i9);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i10);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i11);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i12);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i13);
Define_extern_entry(mercury__vn_debug__order_antidep_msg_4_0);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i2);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i4);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i5);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i6);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i7);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i8);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i9);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i10);
Define_extern_entry(mercury__vn_debug__order_map_msg_6_0);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i2);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i3);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i6);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i9);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i10);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i11);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i12);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i13);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i14);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i15);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i16);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i17);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i18);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i19);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i7);
Define_extern_entry(mercury__vn_debug__order_order_msg_3_0);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i2);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i4);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i5);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i6);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__order_equals_msg_4_0);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i2);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i4);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i5);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i6);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i7);
Define_extern_entry(mercury__vn_debug__cost_header_msg_3_0);
Declare_label(mercury__vn_debug__cost_header_msg_3_0_i2);
Define_extern_entry(mercury__vn_debug__cost_msg_5_0);
Declare_label(mercury__vn_debug__cost_msg_5_0_i2);
Declare_label(mercury__vn_debug__cost_msg_5_0_i4);
Declare_label(mercury__vn_debug__cost_msg_5_0_i5);
Declare_label(mercury__vn_debug__cost_msg_5_0_i6);
Declare_label(mercury__vn_debug__cost_msg_5_0_i7);
Declare_label(mercury__vn_debug__cost_msg_5_0_i8);
Declare_label(mercury__vn_debug__cost_msg_5_0_i9);
Declare_label(mercury__vn_debug__cost_msg_5_0_i10);
Declare_label(mercury__vn_debug__cost_msg_5_0_i11);
Declare_label(mercury__vn_debug__cost_msg_5_0_i12);
Declare_label(mercury__vn_debug__cost_msg_5_0_i13);
Declare_label(mercury__vn_debug__cost_msg_5_0_i16);
Declare_label(mercury__vn_debug__cost_msg_5_0_i14);
Declare_label(mercury__vn_debug__cost_msg_5_0_i17);
Declare_label(mercury__vn_debug__cost_msg_5_0_i18);
Declare_label(mercury__vn_debug__cost_msg_5_0_i1000);
Define_extern_entry(mercury__vn_debug__cost_detail_msg_5_0);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i2);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i4);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i5);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i6);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i7);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i8);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i9);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i10);
Define_extern_entry(mercury__vn_debug__restart_msg_3_0);
Declare_label(mercury__vn_debug__restart_msg_3_0_i2);
Declare_label(mercury__vn_debug__restart_msg_3_0_i4);
Declare_label(mercury__vn_debug__restart_msg_3_0_i5);
Declare_label(mercury__vn_debug__restart_msg_3_0_i6);
Declare_label(mercury__vn_debug__restart_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__divide_msg_3_0);
Declare_label(mercury__vn_debug__divide_msg_3_0_i2);
Declare_label(mercury__vn_debug__divide_msg_3_0_i4);
Declare_label(mercury__vn_debug__divide_msg_3_0_i5);
Declare_label(mercury__vn_debug__divide_msg_3_0_i6);
Declare_label(mercury__vn_debug__divide_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__flush_start_msg_3_0);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i2);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i4);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i5);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i6);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__flush_also_msg_3_0);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i2);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i4);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i5);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i6);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__flush_end_msg_4_0);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i2);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i4);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i5);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i6);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i7);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i8);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i9);
Define_extern_entry(mercury__vn_debug__dump_instrs_3_0);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i2);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i3);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i4);
Declare_static(mercury__vn_debug__tuple_entries_6_0);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i4);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i5);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i6);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i7);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i8);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i9);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i10);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i1002);
Declare_static(mercury__vn_debug__parentry_msg_3_0);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i4);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i5);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i6);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i7);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i8);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i9);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i1002);
Declare_static(mercury__vn_debug__dump_labels_3_0);
Declare_label(mercury__vn_debug__dump_labels_3_0_i4);
Declare_label(mercury__vn_debug__dump_labels_3_0_i5);
Declare_label(mercury__vn_debug__dump_labels_3_0_i6);
Declare_label(mercury__vn_debug__dump_labels_3_0_i1002);
Declare_static(mercury__vn_debug__dump_parallels_3_0);
Declare_label(mercury__vn_debug__dump_parallels_3_0_i4);
Declare_label(mercury__vn_debug__dump_parallels_3_0_i1002);
Declare_static(mercury__vn_debug__dump_label_parallel_pairs_3_0);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i4);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i5);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i6);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i9);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i10);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1003);
Declare_static(mercury__vn_debug__parallel_msg_flag_3_0);
Declare_label(mercury__vn_debug__parallel_msg_flag_3_0_i2);
Declare_label(mercury__vn_debug__parallel_msg_flag_3_0_i1000);
Declare_static(mercury__vn_debug__order_sink_msg_flag_3_0);
Declare_label(mercury__vn_debug__order_sink_msg_flag_3_0_i2);
Declare_label(mercury__vn_debug__order_sink_msg_flag_3_0_i1000);
Declare_static(mercury__vn_debug__order_msg_flag_3_0);
Declare_label(mercury__vn_debug__order_msg_flag_3_0_i2);
Declare_label(mercury__vn_debug__order_msg_flag_3_0_i1000);
Declare_static(mercury__vn_debug__cost_msg_flag_3_0);
Declare_label(mercury__vn_debug__cost_msg_flag_3_0_i2);
Declare_label(mercury__vn_debug__cost_msg_flag_3_0_i1000);
Declare_static(mercury__vn_debug__flush_msg_flag_3_0);
Declare_label(mercury__vn_debug__flush_msg_flag_3_0_i2);
Declare_label(mercury__vn_debug__flush_msg_flag_3_0_i1000);
Declare_static(mercury__vn_debug__start_msg_flag_3_0);
Declare_label(mercury__vn_debug__start_msg_flag_3_0_i2);
Declare_label(mercury__vn_debug__start_msg_flag_3_0_i1000);

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_vn_type__base_type_info_parallel_0[];
Word * mercury_data_vn_debug__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_parallel_0
};

BEGIN_MODULE(mercury__vn_debug_module0)
	init_entry(mercury__vn_debug__tuple_msg_5_0);
	init_label(mercury__vn_debug__tuple_msg_5_0_i2);
	init_label(mercury__vn_debug__tuple_msg_5_0_i3);
	init_label(mercury__vn_debug__tuple_msg_5_0_i6);
	init_label(mercury__vn_debug__tuple_msg_5_0_i9);
	init_label(mercury__vn_debug__tuple_msg_5_0_i14);
	init_label(mercury__vn_debug__tuple_msg_5_0_i13);
	init_label(mercury__vn_debug__tuple_msg_5_0_i15);
	init_label(mercury__vn_debug__tuple_msg_5_0_i11);
	init_label(mercury__vn_debug__tuple_msg_5_0_i16);
	init_label(mercury__vn_debug__tuple_msg_5_0_i10);
	init_label(mercury__vn_debug__tuple_msg_5_0_i17);
	init_label(mercury__vn_debug__tuple_msg_5_0_i18);
	init_label(mercury__vn_debug__tuple_msg_5_0_i19);
	init_label(mercury__vn_debug__tuple_msg_5_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__tuple_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__tuple_msg_5_0);
	incr_sp_push_msg(4, "vn_debug__tuple_msg");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = ((Integer) 19);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__tuple_msg_5_0_i2,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r3 = ((Integer) r1 & ((Integer) 512));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = ((Integer) 1);
	GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i6);
Define_label(mercury__vn_debug__tuple_msg_5_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = ((Integer) 0);
Define_label(mercury__vn_debug__tuple_msg_5_0_i6);
	if (((Integer) r5 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i7);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = string_const("\nTuples from the ", 17);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i9,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	if (((Integer) detstackvar(1) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i11);
	if (((Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)) == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i13);
	r2 = (Integer) r1;
	r1 = string_const("intermediate instruction sequence:\n\n", 36);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i14,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i10);
Define_label(mercury__vn_debug__tuple_msg_5_0_i13);
	r2 = (Integer) r1;
	r1 = string_const("stitched-together instruction sequence:\n\n", 41);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i15,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i10);
Define_label(mercury__vn_debug__tuple_msg_5_0_i11);
	r2 = (Integer) r1;
	r1 = string_const("final instruction sequence:\n\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i16,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__vn_debug__tuple_msg_5_0_i10);
	detstackvar(3) = (Integer) r3;
	{
		call_localret(STATIC(mercury__vn_debug__dump_instrs_3_0),
		mercury__vn_debug__tuple_msg_5_0_i17,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\nTuple data:\n\n", 14);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i18,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r5 = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(3);
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = ((Integer) 0);
	call_localret(STATIC(mercury__vn_debug__tuple_entries_6_0),
		mercury__vn_debug__tuple_msg_5_0_i19,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\nTuple data ends\n\n", 18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module1)
	init_entry(mercury__vn_debug__livemap_msg_3_0);
	init_label(mercury__vn_debug__livemap_msg_3_0_i2);
	init_label(mercury__vn_debug__livemap_msg_3_0_i3);
	init_label(mercury__vn_debug__livemap_msg_3_0_i6);
	init_label(mercury__vn_debug__livemap_msg_3_0_i9);
	init_label(mercury__vn_debug__livemap_msg_3_0_i10);
	init_label(mercury__vn_debug__livemap_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__livemap_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__livemap_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__livemap_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 19);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__livemap_msg_3_0_i2,
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
	}
Define_label(mercury__vn_debug__livemap_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__livemap_msg_3_0));
	r3 = ((Integer) r1 & ((Integer) 256));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__livemap_msg_3_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	GOTO_LABEL(mercury__vn_debug__livemap_msg_3_0_i6);
Define_label(mercury__vn_debug__livemap_msg_3_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 0);
Define_label(mercury__vn_debug__livemap_msg_3_0_i6);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__livemap_msg_3_0_i7);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_livemap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_livemap_2_0),
		mercury__vn_debug__livemap_msg_3_0_i9,
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
	}
Define_label(mercury__vn_debug__livemap_msg_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__livemap_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\n\nLivemap:\n\n", 12);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__livemap_msg_3_0_i10,
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
	}
Define_label(mercury__vn_debug__livemap_msg_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__livemap_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
	}
Define_label(mercury__vn_debug__livemap_msg_3_0_i7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module2)
	init_entry(mercury__vn_debug__fragment_msg_3_0);
	init_label(mercury__vn_debug__fragment_msg_3_0_i2);
	init_label(mercury__vn_debug__fragment_msg_3_0_i4);
	init_label(mercury__vn_debug__fragment_msg_3_0_i5);
	init_label(mercury__vn_debug__fragment_msg_3_0_i6);
BEGIN_CODE

/* code for predicate 'vn_debug__fragment_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__fragment_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__fragment_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__start_msg_flag_3_0),
		mercury__vn_debug__fragment_msg_3_0_i2,
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
Define_label(mercury__vn_debug__fragment_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__fragment_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__fragment_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__fragment_msg_3_0_i4);
	r1 = string_const("\nin value_number__optimize_fragment starting at\n", 48);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__fragment_msg_3_0_i5,
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
	}
Define_label(mercury__vn_debug__fragment_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__fragment_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__llds_out__output_instruction_3_0);
	call_localret(ENTRY(mercury__llds_out__output_instruction_3_0),
		mercury__vn_debug__fragment_msg_3_0_i6,
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
	}
Define_label(mercury__vn_debug__fragment_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__fragment_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module3)
	init_entry(mercury__vn_debug__failure_msg_4_0);
	init_label(mercury__vn_debug__failure_msg_4_0_i2);
	init_label(mercury__vn_debug__failure_msg_4_0_i3);
	init_label(mercury__vn_debug__failure_msg_4_0_i6);
	init_label(mercury__vn_debug__failure_msg_4_0_i9);
	init_label(mercury__vn_debug__failure_msg_4_0_i10);
	init_label(mercury__vn_debug__failure_msg_4_0_i11);
	init_label(mercury__vn_debug__failure_msg_4_0_i12);
	init_label(mercury__vn_debug__failure_msg_4_0_i13);
	init_label(mercury__vn_debug__failure_msg_4_0_i14);
	init_label(mercury__vn_debug__failure_msg_4_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__failure_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__failure_msg_4_0);
	incr_sp_push_msg(3, "vn_debug__failure_msg");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = ((Integer) 19);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__failure_msg_4_0_i2,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r3 = ((Integer) r1 & ((Integer) 1));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__failure_msg_4_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	GOTO_LABEL(mercury__vn_debug__failure_msg_4_0_i6);
Define_label(mercury__vn_debug__failure_msg_4_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
Define_label(mercury__vn_debug__failure_msg_4_0_i6);
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__failure_msg_4_0_i7);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = string_const("FAILURE of VN consistency check ", 32);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i9,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("in fragment starting at\n", 24);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i10,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__llds_out__output_instruction_3_0);
	call_localret(ENTRY(mercury__llds_out__output_instruction_3_0),
		mercury__vn_debug__failure_msg_4_0_i11,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i12,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("Cause: ", 7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i13,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i14,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__failure_msg_4_0));
	}
Define_label(mercury__vn_debug__failure_msg_4_0_i7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module4)
	init_entry(mercury__vn_debug__parallel_msgs_3_0);
	init_label(mercury__vn_debug__parallel_msgs_3_0_i4);
	init_label(mercury__vn_debug__parallel_msgs_3_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_debug__parallel_msgs'/3 in mode 0 */
Define_entry(mercury__vn_debug__parallel_msgs_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__parallel_msgs_3_0_i1002);
	incr_sp_push_msg(2, "vn_debug__parallel_msgs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__vn_debug__parallel_msg_3_0),
		mercury__vn_debug__parallel_msgs_3_0_i4,
		ENTRY(mercury__vn_debug__parallel_msgs_3_0));
	}
Define_label(mercury__vn_debug__parallel_msgs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msgs_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__vn_debug__parallel_msgs_3_0,
		ENTRY(mercury__vn_debug__parallel_msgs_3_0));
Define_label(mercury__vn_debug__parallel_msgs_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module5)
	init_entry(mercury__vn_debug__parallel_msg_3_0);
	init_label(mercury__vn_debug__parallel_msg_3_0_i2);
	init_label(mercury__vn_debug__parallel_msg_3_0_i4);
	init_label(mercury__vn_debug__parallel_msg_3_0_i5);
	init_label(mercury__vn_debug__parallel_msg_3_0_i6);
	init_label(mercury__vn_debug__parallel_msg_3_0_i7);
	init_label(mercury__vn_debug__parallel_msg_3_0_i8);
	init_label(mercury__vn_debug__parallel_msg_3_0_i9);
	init_label(mercury__vn_debug__parallel_msg_3_0_i10);
	init_label(mercury__vn_debug__parallel_msg_3_0_i11);
BEGIN_CODE

/* code for predicate 'vn_debug__parallel_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__parallel_msg_3_0);
	incr_sp_push_msg(5, "vn_debug__parallel_msg");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__parallel_msg_flag_3_0),
		mercury__vn_debug__parallel_msg_3_0_i2,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__parallel_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_debug__parallel_msg_3_0_i4);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_label_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__parallel_msg_3_0_i5,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_label_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__parallel_msg_3_0_i6,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const("\nparallel from ", 15);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i7,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i8,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const(" to ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i9,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i10,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i11,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__vn_debug__parentry_msg_3_0),
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module6)
	init_entry(mercury__vn_debug__computed_goto_msg_5_0);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i2);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i4);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i5);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i6);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i7);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i8);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i9);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i10);
BEGIN_CODE

/* code for predicate 'vn_debug__computed_goto_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__computed_goto_msg_5_0);
	incr_sp_push_msg(4, "vn_debug__computed_goto_msg");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__vn_debug__parallel_msg_flag_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i2,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__computed_goto_msg_5_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i4);
	r1 = string_const("computed goto labels:\n", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i5,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
	}
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__vn_debug__dump_labels_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i6,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("computed goto parallels:\n", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i7,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
	}
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_debug__dump_parallels_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i8,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("computed goto pairs:\n", 21);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i9,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
	}
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i10,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("computed goto message end\n", 26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module7)
	init_entry(mercury__vn_debug__order_start_msg_5_0);
	init_label(mercury__vn_debug__order_start_msg_5_0_i2);
	init_label(mercury__vn_debug__order_start_msg_5_0_i4);
	init_label(mercury__vn_debug__order_start_msg_5_0_i5);
	init_label(mercury__vn_debug__order_start_msg_5_0_i6);
	init_label(mercury__vn_debug__order_start_msg_5_0_i7);
	init_label(mercury__vn_debug__order_start_msg_5_0_i8);
	init_label(mercury__vn_debug__order_start_msg_5_0_i9);
	init_label(mercury__vn_debug__order_start_msg_5_0_i10);
	init_label(mercury__vn_debug__order_start_msg_5_0_i11);
BEGIN_CODE

/* code for predicate 'vn_debug__order_start_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__order_start_msg_5_0);
	incr_sp_push_msg(5, "vn_debug__order_start_msg");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__vn_debug__order_msg_flag_3_0),
		mercury__vn_debug__order_start_msg_5_0_i2,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_start_msg_5_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_debug__order_start_msg_5_0_i4);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_ctrlmap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_ctrlmap_2_0),
		mercury__vn_debug__order_start_msg_5_0_i5,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_flushmap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_flushmap_2_0),
		mercury__vn_debug__order_start_msg_5_0_i6,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__opt_debug__dump_tables_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_tables_2_0),
		mercury__vn_debug__order_start_msg_5_0_i7,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = string_const("\n\n", 2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i8,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i9,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i10,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i11,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
Define_label(mercury__vn_debug__order_start_msg_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module8)
	init_entry(mercury__vn_debug__order_sink_msg_3_0);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i2);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i4);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i5);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i6);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__order_sink_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__order_sink_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__order_sink_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__order_sink_msg_flag_3_0),
		mercury__vn_debug__order_sink_msg_3_0_i2,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
Define_label(mercury__vn_debug__order_sink_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_sink_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__order_sink_msg_3_0_i4);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_node_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_sink_msg_3_0_i5,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
	}
Define_label(mercury__vn_debug__order_sink_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("sink_before_redef for node ", 27);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_sink_msg_3_0_i6,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
	}
Define_label(mercury__vn_debug__order_sink_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_sink_msg_3_0_i7,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
	}
Define_label(mercury__vn_debug__order_sink_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module9)
	init_entry(mercury__vn_debug__order_link_msg_5_0);
	init_label(mercury__vn_debug__order_link_msg_5_0_i2);
	init_label(mercury__vn_debug__order_link_msg_5_0_i4);
	init_label(mercury__vn_debug__order_link_msg_5_0_i7);
	init_label(mercury__vn_debug__order_link_msg_5_0_i6);
	init_label(mercury__vn_debug__order_link_msg_5_0_i8);
	init_label(mercury__vn_debug__order_link_msg_5_0_i5);
	init_label(mercury__vn_debug__order_link_msg_5_0_i9);
	init_label(mercury__vn_debug__order_link_msg_5_0_i10);
	init_label(mercury__vn_debug__order_link_msg_5_0_i11);
	init_label(mercury__vn_debug__order_link_msg_5_0_i12);
	init_label(mercury__vn_debug__order_link_msg_5_0_i13);
BEGIN_CODE

/* code for predicate 'vn_debug__order_link_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__order_link_msg_5_0);
	incr_sp_push_msg(4, "vn_debug__order_link_msg");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__vn_debug__order_sink_msg_flag_3_0),
		mercury__vn_debug__order_link_msg_5_0_i2,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_link_msg_5_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__order_link_msg_5_0_i4);
	if (((Integer) detstackvar(3) == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_link_msg_5_0_i6);
	r1 = string_const("adding alias link from ", 23);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i7,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__vn_debug__order_link_msg_5_0_i5);
Define_label(mercury__vn_debug__order_link_msg_5_0_i6);
	r1 = string_const("adding user link from ", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i8,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
Define_label(mercury__vn_debug__order_link_msg_5_0_i5);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__opt_debug__dump_node_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_link_msg_5_0_i9,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_node_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_link_msg_5_0_i10,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i11,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" to ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i12,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i13,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
Define_label(mercury__vn_debug__order_link_msg_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module10)
	init_entry(mercury__vn_debug__order_antidep_msg_4_0);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i2);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i4);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i5);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i6);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i7);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i8);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i9);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i10);
BEGIN_CODE

/* code for predicate 'vn_debug__order_antidep_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__order_antidep_msg_4_0);
	incr_sp_push_msg(3, "vn_debug__order_antidep_msg");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__vn_debug__order_sink_msg_flag_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i2,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_antidep_msg_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i4);
	r1 = string_const("anti dependency from ", 21);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i5,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_node_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_antidep_msg_4_0_i6,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i7,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" to ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i8,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_node_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_antidep_msg_4_0_i9,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i10,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module11)
	init_entry(mercury__vn_debug__order_map_msg_6_0);
	init_label(mercury__vn_debug__order_map_msg_6_0_i2);
	init_label(mercury__vn_debug__order_map_msg_6_0_i3);
	init_label(mercury__vn_debug__order_map_msg_6_0_i6);
	init_label(mercury__vn_debug__order_map_msg_6_0_i9);
	init_label(mercury__vn_debug__order_map_msg_6_0_i10);
	init_label(mercury__vn_debug__order_map_msg_6_0_i11);
	init_label(mercury__vn_debug__order_map_msg_6_0_i12);
	init_label(mercury__vn_debug__order_map_msg_6_0_i13);
	init_label(mercury__vn_debug__order_map_msg_6_0_i14);
	init_label(mercury__vn_debug__order_map_msg_6_0_i15);
	init_label(mercury__vn_debug__order_map_msg_6_0_i16);
	init_label(mercury__vn_debug__order_map_msg_6_0_i17);
	init_label(mercury__vn_debug__order_map_msg_6_0_i18);
	init_label(mercury__vn_debug__order_map_msg_6_0_i19);
	init_label(mercury__vn_debug__order_map_msg_6_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__order_map_msg'/6 in mode 0 */
Define_entry(mercury__vn_debug__order_map_msg_6_0);
	incr_sp_push_msg(6, "vn_debug__order_map_msg");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = ((Integer) 19);
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_map_msg_6_0_i2,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r3 = ((Integer) r1 & ((Integer) 16));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_map_msg_6_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = ((Integer) 1);
	GOTO_LABEL(mercury__vn_debug__order_map_msg_6_0_i6);
Define_label(mercury__vn_debug__order_map_msg_6_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = ((Integer) 0);
Define_label(mercury__vn_debug__order_map_msg_6_0_i6);
	if (((Integer) r6 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_map_msg_6_0_i7);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_node_relmap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i9,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_node_relmap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i10,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__opt_debug__dump_node_relmap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i11,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__opt_debug__dump_node_relmap_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i12,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = string_const("\nMustSuccmap:\n", 14);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i13,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i14,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\nMustPredmap:\n", 14);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i15,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i16,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\nSuccmap:\n", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i17,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i18,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\nPredmap:\n", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i19,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
	}
Define_label(mercury__vn_debug__order_map_msg_6_0_i7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module12)
	init_entry(mercury__vn_debug__order_order_msg_3_0);
	init_label(mercury__vn_debug__order_order_msg_3_0_i2);
	init_label(mercury__vn_debug__order_order_msg_3_0_i4);
	init_label(mercury__vn_debug__order_order_msg_3_0_i5);
	init_label(mercury__vn_debug__order_order_msg_3_0_i6);
	init_label(mercury__vn_debug__order_order_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__order_order_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__order_order_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__order_order_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__order_msg_flag_3_0),
		mercury__vn_debug__order_order_msg_3_0_i2,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
Define_label(mercury__vn_debug__order_order_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_order_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__order_order_msg_3_0_i4);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_longnodelist_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_longnodelist_2_0),
		mercury__vn_debug__order_order_msg_3_0_i5,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
	}
Define_label(mercury__vn_debug__order_order_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\nOrder:\n", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_order_msg_3_0_i6,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
	}
Define_label(mercury__vn_debug__order_order_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_order_msg_3_0_i7,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
	}
Define_label(mercury__vn_debug__order_order_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module13)
	init_entry(mercury__vn_debug__order_equals_msg_4_0);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i2);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i4);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i5);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i6);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__order_equals_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__order_equals_msg_4_0);
	incr_sp_push_msg(3, "vn_debug__order_equals_msg");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__vn_debug__order_msg_flag_3_0),
		mercury__vn_debug__order_equals_msg_4_0_i2,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
Define_label(mercury__vn_debug__order_equals_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_equals_msg_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_debug__order_equals_msg_4_0_i4);
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_nodelist_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_nodelist_2_0),
		mercury__vn_debug__order_equals_msg_4_0_i5,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
	}
Define_label(mercury__vn_debug__order_equals_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_equals_msg_4_0_i6,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
	}
Define_label(mercury__vn_debug__order_equals_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_equals_msg_4_0_i7,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
	}
Define_label(mercury__vn_debug__order_equals_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module14)
	init_entry(mercury__vn_debug__cost_header_msg_3_0);
	init_label(mercury__vn_debug__cost_header_msg_3_0_i2);
BEGIN_CODE

/* code for predicate 'vn_debug__cost_header_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__cost_header_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__cost_header_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__cost_msg_flag_3_0),
		mercury__vn_debug__cost_header_msg_3_0_i2,
		ENTRY(mercury__vn_debug__cost_header_msg_3_0));
Define_label(mercury__vn_debug__cost_header_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_header_msg_3_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__opt_debug__msg_4_0);
	tailcall(ENTRY(mercury__opt_debug__msg_4_0),
		ENTRY(mercury__vn_debug__cost_header_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module15)
	init_entry(mercury__vn_debug__cost_msg_5_0);
	init_label(mercury__vn_debug__cost_msg_5_0_i2);
	init_label(mercury__vn_debug__cost_msg_5_0_i4);
	init_label(mercury__vn_debug__cost_msg_5_0_i5);
	init_label(mercury__vn_debug__cost_msg_5_0_i6);
	init_label(mercury__vn_debug__cost_msg_5_0_i7);
	init_label(mercury__vn_debug__cost_msg_5_0_i8);
	init_label(mercury__vn_debug__cost_msg_5_0_i9);
	init_label(mercury__vn_debug__cost_msg_5_0_i10);
	init_label(mercury__vn_debug__cost_msg_5_0_i11);
	init_label(mercury__vn_debug__cost_msg_5_0_i12);
	init_label(mercury__vn_debug__cost_msg_5_0_i13);
	init_label(mercury__vn_debug__cost_msg_5_0_i16);
	init_label(mercury__vn_debug__cost_msg_5_0_i14);
	init_label(mercury__vn_debug__cost_msg_5_0_i17);
	init_label(mercury__vn_debug__cost_msg_5_0_i18);
	init_label(mercury__vn_debug__cost_msg_5_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__cost_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__cost_msg_5_0);
	incr_sp_push_msg(6, "vn_debug__cost_msg");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__vn_debug__cost_msg_flag_3_0),
		mercury__vn_debug__cost_msg_5_0_i2,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_debug__cost_msg_5_0_i4);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_msg_5_0_i5,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_msg_5_0_i6,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i7,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("Old cost: ", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i8,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i9,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i10,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("New cost: ", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i11,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i12,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i13,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	if (((Integer) detstackvar(3) >= (Integer) detstackvar(2)))
		GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i14);
	r2 = (Integer) r1;
	r1 = string_const("Result: cost improvement\n", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i16,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i18);
Define_label(mercury__vn_debug__cost_msg_5_0_i14);
	r2 = (Integer) r1;
	r1 = string_const("Result: no cost improvement\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i17,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
Define_label(mercury__vn_debug__cost_msg_5_0_i18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i1000);
	r1 = string_const("Used: yes\n", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_msg_5_0_i1000);
	r1 = string_const("Used: no\n", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__cost_msg_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module16)
	init_entry(mercury__vn_debug__cost_detail_msg_5_0);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i2);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i4);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i5);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i6);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i7);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i8);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i9);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i10);
BEGIN_CODE

/* code for predicate 'vn_debug__cost_detail_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__cost_detail_msg_5_0);
	incr_sp_push_msg(5, "vn_debug__cost_detail_msg");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__vn_debug__cost_msg_flag_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i2,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__cost_detail_msg_5_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i4);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_detail_msg_5_0_i5,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_detail_msg_5_0_i6,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i7,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\t", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i8,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i9,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\t", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i10,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__llds_out__output_instruction_3_0);
	tailcall(ENTRY(mercury__llds_out__output_instruction_3_0),
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module17)
	init_entry(mercury__vn_debug__restart_msg_3_0);
	init_label(mercury__vn_debug__restart_msg_3_0_i2);
	init_label(mercury__vn_debug__restart_msg_3_0_i4);
	init_label(mercury__vn_debug__restart_msg_3_0_i5);
	init_label(mercury__vn_debug__restart_msg_3_0_i6);
	init_label(mercury__vn_debug__restart_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__restart_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__restart_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__restart_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__start_msg_flag_3_0),
		mercury__vn_debug__restart_msg_3_0_i2,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
Define_label(mercury__vn_debug__restart_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__restart_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__restart_msg_3_0_i4);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_fullinstr_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_fullinstr_2_0),
		mercury__vn_debug__restart_msg_3_0_i5,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
	}
Define_label(mercury__vn_debug__restart_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("starting again at ", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__restart_msg_3_0_i6,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
	}
Define_label(mercury__vn_debug__restart_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__restart_msg_3_0_i7,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
	}
Define_label(mercury__vn_debug__restart_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__restart_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module18)
	init_entry(mercury__vn_debug__divide_msg_3_0);
	init_label(mercury__vn_debug__divide_msg_3_0_i2);
	init_label(mercury__vn_debug__divide_msg_3_0_i4);
	init_label(mercury__vn_debug__divide_msg_3_0_i5);
	init_label(mercury__vn_debug__divide_msg_3_0_i6);
	init_label(mercury__vn_debug__divide_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__divide_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__divide_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__divide_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__start_msg_flag_3_0),
		mercury__vn_debug__divide_msg_3_0_i2,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
Define_label(mercury__vn_debug__divide_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__divide_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__divide_msg_3_0_i4);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_fullinstr_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_fullinstr_2_0),
		mercury__vn_debug__divide_msg_3_0_i5,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
	}
Define_label(mercury__vn_debug__divide_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("dividing the block at ", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__divide_msg_3_0_i6,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
	}
Define_label(mercury__vn_debug__divide_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__divide_msg_3_0_i7,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
	}
Define_label(mercury__vn_debug__divide_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__divide_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module19)
	init_entry(mercury__vn_debug__flush_start_msg_3_0);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i2);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i4);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i5);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i6);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__flush_start_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__flush_start_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__flush_start_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__flush_msg_flag_3_0),
		mercury__vn_debug__flush_start_msg_3_0_i2,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
Define_label(mercury__vn_debug__flush_start_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__flush_start_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__flush_start_msg_3_0_i4);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_node_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__flush_start_msg_3_0_i5,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
	}
Define_label(mercury__vn_debug__flush_start_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\nat node ", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_start_msg_3_0_i6,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
	}
Define_label(mercury__vn_debug__flush_start_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_start_msg_3_0_i7,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
	}
Define_label(mercury__vn_debug__flush_start_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module20)
	init_entry(mercury__vn_debug__flush_also_msg_3_0);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i2);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i4);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i5);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i6);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'vn_debug__flush_also_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__flush_also_msg_3_0);
	incr_sp_push_msg(2, "vn_debug__flush_also_msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__flush_msg_flag_3_0),
		mercury__vn_debug__flush_also_msg_3_0_i2,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
Define_label(mercury__vn_debug__flush_also_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__flush_also_msg_3_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__flush_also_msg_3_0_i4);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_vnlval_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_debug__flush_also_msg_3_0_i5,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
	}
Define_label(mercury__vn_debug__flush_also_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("took care of node_lval for ", 27);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_also_msg_3_0_i6,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
	}
Define_label(mercury__vn_debug__flush_also_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_also_msg_3_0_i7,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
	}
Define_label(mercury__vn_debug__flush_also_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module21)
	init_entry(mercury__vn_debug__flush_end_msg_4_0);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i2);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i4);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i5);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i6);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i7);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i8);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i9);
BEGIN_CODE

/* code for predicate 'vn_debug__flush_end_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__flush_end_msg_4_0);
	incr_sp_push_msg(4, "vn_debug__flush_end_msg");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__vn_debug__flush_msg_flag_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i2,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__flush_end_msg_4_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__flush_end_msg_4_0_i4);
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_debug__dump_fullinstrs_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_fullinstrs_2_0),
		mercury__vn_debug__flush_end_msg_4_0_i5,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
	}
Define_label(mercury__vn_debug__flush_end_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_debug__dump_useful_vns_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_useful_vns_2_0),
		mercury__vn_debug__flush_end_msg_4_0_i6,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
	}
Define_label(mercury__vn_debug__flush_end_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const("generated instrs:\n", 18);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i7,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
	}
Define_label(mercury__vn_debug__flush_end_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i8,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
	}
Define_label(mercury__vn_debug__flush_end_msg_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("new use info\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i9,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
	}
Define_label(mercury__vn_debug__flush_end_msg_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module22)
	init_entry(mercury__vn_debug__dump_instrs_3_0);
	init_label(mercury__vn_debug__dump_instrs_3_0_i2);
	init_label(mercury__vn_debug__dump_instrs_3_0_i3);
	init_label(mercury__vn_debug__dump_instrs_3_0_i4);
BEGIN_CODE

/* code for predicate 'vn_debug__dump_instrs'/3 in mode 0 */
Define_entry(mercury__vn_debug__dump_instrs_3_0);
	incr_sp_push_msg(3, "vn_debug__dump_instrs");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__parallel_msg_flag_3_0),
		mercury__vn_debug__dump_instrs_3_0_i2,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_instrs_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__vn_debug__cost_msg_flag_3_0),
		mercury__vn_debug__dump_instrs_3_0_i3,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_instrs_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__vn_debug__dump_instrs_3_0_i4,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
	}
Define_label(mercury__vn_debug__dump_instrs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_instrs_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__opt_debug__dump_instrs_4_0);
	tailcall(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module23)
	init_entry(mercury__vn_debug__tuple_entries_6_0);
	init_label(mercury__vn_debug__tuple_entries_6_0_i4);
	init_label(mercury__vn_debug__tuple_entries_6_0_i5);
	init_label(mercury__vn_debug__tuple_entries_6_0_i6);
	init_label(mercury__vn_debug__tuple_entries_6_0_i7);
	init_label(mercury__vn_debug__tuple_entries_6_0_i8);
	init_label(mercury__vn_debug__tuple_entries_6_0_i9);
	init_label(mercury__vn_debug__tuple_entries_6_0_i10);
	init_label(mercury__vn_debug__tuple_entries_6_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_debug__tuple_entries'/6 in mode 0 */
Define_static(mercury__vn_debug__tuple_entries_6_0);
	if (((Integer) r1 >= (Integer) r2))
		GOTO_LABEL(mercury__vn_debug__tuple_entries_6_0_i1002);
	incr_sp_push_msg(7, "vn_debug__tuple_entries");
	detstackvar(7) = (Integer) succip;
	detstackvar(4) = (Integer) r4;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_instr_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	}
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_debug__tuple_entries_6_0_i4,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	detstackvar(6) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_debug__common_0);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__vn_debug__tuple_entries_6_0_i5,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_vninstr_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_vninstr_2_0),
		mercury__vn_debug__tuple_entries_6_0_i6,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("\n-----------\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_entries_6_0_i7,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_entries_6_0_i8,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = (Integer) r1;
	r1 = string_const(":\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_entries_6_0_i9,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
		call_localret(STATIC(mercury__vn_debug__parallel_msgs_3_0),
		mercury__vn_debug__tuple_entries_6_0_i10,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
	}
Define_label(mercury__vn_debug__tuple_entries_6_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r5 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__vn_debug__tuple_entries_6_0,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i1002);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module24)
	init_entry(mercury__vn_debug__parentry_msg_3_0);
	init_label(mercury__vn_debug__parentry_msg_3_0_i4);
	init_label(mercury__vn_debug__parentry_msg_3_0_i5);
	init_label(mercury__vn_debug__parentry_msg_3_0_i6);
	init_label(mercury__vn_debug__parentry_msg_3_0_i7);
	init_label(mercury__vn_debug__parentry_msg_3_0_i8);
	init_label(mercury__vn_debug__parentry_msg_3_0_i9);
	init_label(mercury__vn_debug__parentry_msg_3_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_debug__parentry_msg'/3 in mode 0 */
Define_static(mercury__vn_debug__parentry_msg_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__parentry_msg_3_0_i1002);
	incr_sp_push_msg(4, "vn_debug__parentry_msg");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_lval_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_lval_2_0),
		mercury__vn_debug__parentry_msg_3_0_i4,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
	}
Define_label(mercury__vn_debug__parentry_msg_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_rvals_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_rvals_2_0),
		mercury__vn_debug__parentry_msg_3_0_i5,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
	}
Define_label(mercury__vn_debug__parentry_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i6,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
	}
Define_label(mercury__vn_debug__parentry_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const(" -> ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i7,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
	}
Define_label(mercury__vn_debug__parentry_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i8,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
	}
Define_label(mercury__vn_debug__parentry_msg_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i9,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
	}
Define_label(mercury__vn_debug__parentry_msg_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_debug__parentry_msg_3_0,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module25)
	init_entry(mercury__vn_debug__dump_labels_3_0);
	init_label(mercury__vn_debug__dump_labels_3_0_i4);
	init_label(mercury__vn_debug__dump_labels_3_0_i5);
	init_label(mercury__vn_debug__dump_labels_3_0_i6);
	init_label(mercury__vn_debug__dump_labels_3_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_debug__dump_labels'/3 in mode 0 */
Define_static(mercury__vn_debug__dump_labels_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__dump_labels_3_0_i1002);
	incr_sp_push_msg(3, "vn_debug__dump_labels");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__opt_debug__dump_label_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__dump_labels_3_0_i4,
		STATIC(mercury__vn_debug__dump_labels_3_0));
	}
Define_label(mercury__vn_debug__dump_labels_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_labels_3_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_labels_3_0_i5,
		STATIC(mercury__vn_debug__dump_labels_3_0));
	}
Define_label(mercury__vn_debug__dump_labels_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_labels_3_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_labels_3_0_i6,
		STATIC(mercury__vn_debug__dump_labels_3_0));
	}
Define_label(mercury__vn_debug__dump_labels_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_labels_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__vn_debug__dump_labels_3_0,
		STATIC(mercury__vn_debug__dump_labels_3_0));
Define_label(mercury__vn_debug__dump_labels_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module26)
	init_entry(mercury__vn_debug__dump_parallels_3_0);
	init_label(mercury__vn_debug__dump_parallels_3_0_i4);
	init_label(mercury__vn_debug__dump_parallels_3_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_debug__dump_parallels'/3 in mode 0 */
Define_static(mercury__vn_debug__dump_parallels_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__dump_parallels_3_0_i1002);
	incr_sp_push_msg(2, "vn_debug__dump_parallels");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__vn_debug__parallel_msg_3_0),
		mercury__vn_debug__dump_parallels_3_0_i4,
		STATIC(mercury__vn_debug__dump_parallels_3_0));
	}
Define_label(mercury__vn_debug__dump_parallels_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_parallels_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__vn_debug__dump_parallels_3_0,
		STATIC(mercury__vn_debug__dump_parallels_3_0));
Define_label(mercury__vn_debug__dump_parallels_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module27)
	init_entry(mercury__vn_debug__dump_label_parallel_pairs_3_0);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i4);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i5);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i6);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i9);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i10);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1003);
BEGIN_CODE

/* code for predicate 'vn_debug__dump_label_parallel_pairs'/3 in mode 0 */
Define_static(mercury__vn_debug__dump_label_parallel_pairs_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1003);
	incr_sp_push_msg(4, "vn_debug__dump_label_parallel_pairs");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_debug__dump_label_2_0);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i4,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	}
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i5,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	}
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = (Integer) r1;
	r1 = string_const(": ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i6,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	}
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	if (((Integer) detstackvar(2) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	{
		call_localret(STATIC(mercury__vn_debug__parallel_msg_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i9,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	}
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_debug__dump_label_parallel_pairs_3_0,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
	r2 = (Integer) r1;
	r1 = string_const("no\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i10,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	}
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__vn_debug__dump_label_parallel_pairs_3_0,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module28)
	init_entry(mercury__vn_debug__parallel_msg_flag_3_0);
	init_label(mercury__vn_debug__parallel_msg_flag_3_0_i2);
	init_label(mercury__vn_debug__parallel_msg_flag_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__parallel_msg_flag'/3 in mode 0 */
Define_static(mercury__vn_debug__parallel_msg_flag_3_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 19);
	incr_sp_push_msg(1, "vn_debug__parallel_msg_flag");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__parallel_msg_flag_3_0_i2,
		STATIC(mercury__vn_debug__parallel_msg_flag_3_0));
	}
Define_label(mercury__vn_debug__parallel_msg_flag_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_flag_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((((Integer) r1 & ((Integer) 128)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__parallel_msg_flag_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_debug__parallel_msg_flag_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module29)
	init_entry(mercury__vn_debug__order_sink_msg_flag_3_0);
	init_label(mercury__vn_debug__order_sink_msg_flag_3_0_i2);
	init_label(mercury__vn_debug__order_sink_msg_flag_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__order_sink_msg_flag'/3 in mode 0 */
Define_static(mercury__vn_debug__order_sink_msg_flag_3_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 19);
	incr_sp_push_msg(1, "vn_debug__order_sink_msg_flag");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_sink_msg_flag_3_0_i2,
		STATIC(mercury__vn_debug__order_sink_msg_flag_3_0));
	}
Define_label(mercury__vn_debug__order_sink_msg_flag_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_flag_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((((Integer) r1 & ((Integer) 64)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_sink_msg_flag_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_debug__order_sink_msg_flag_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module30)
	init_entry(mercury__vn_debug__order_msg_flag_3_0);
	init_label(mercury__vn_debug__order_msg_flag_3_0_i2);
	init_label(mercury__vn_debug__order_msg_flag_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__order_msg_flag'/3 in mode 0 */
Define_static(mercury__vn_debug__order_msg_flag_3_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 19);
	incr_sp_push_msg(1, "vn_debug__order_msg_flag");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_msg_flag_3_0_i2,
		STATIC(mercury__vn_debug__order_msg_flag_3_0));
	}
Define_label(mercury__vn_debug__order_msg_flag_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_msg_flag_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((((Integer) r1 & ((Integer) 32)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__order_msg_flag_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_debug__order_msg_flag_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module31)
	init_entry(mercury__vn_debug__cost_msg_flag_3_0);
	init_label(mercury__vn_debug__cost_msg_flag_3_0_i2);
	init_label(mercury__vn_debug__cost_msg_flag_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__cost_msg_flag'/3 in mode 0 */
Define_static(mercury__vn_debug__cost_msg_flag_3_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 19);
	incr_sp_push_msg(1, "vn_debug__cost_msg_flag");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__cost_msg_flag_3_0_i2,
		STATIC(mercury__vn_debug__cost_msg_flag_3_0));
	}
Define_label(mercury__vn_debug__cost_msg_flag_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_flag_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((((Integer) r1 & ((Integer) 8)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__cost_msg_flag_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_debug__cost_msg_flag_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module32)
	init_entry(mercury__vn_debug__flush_msg_flag_3_0);
	init_label(mercury__vn_debug__flush_msg_flag_3_0_i2);
	init_label(mercury__vn_debug__flush_msg_flag_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__flush_msg_flag'/3 in mode 0 */
Define_static(mercury__vn_debug__flush_msg_flag_3_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 19);
	incr_sp_push_msg(1, "vn_debug__flush_msg_flag");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__flush_msg_flag_3_0_i2,
		STATIC(mercury__vn_debug__flush_msg_flag_3_0));
	}
Define_label(mercury__vn_debug__flush_msg_flag_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_msg_flag_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((((Integer) r1 & ((Integer) 4)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__flush_msg_flag_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_debug__flush_msg_flag_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_debug_module33)
	init_entry(mercury__vn_debug__start_msg_flag_3_0);
	init_label(mercury__vn_debug__start_msg_flag_3_0_i2);
	init_label(mercury__vn_debug__start_msg_flag_3_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_debug__start_msg_flag'/3 in mode 0 */
Define_static(mercury__vn_debug__start_msg_flag_3_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 19);
	incr_sp_push_msg(1, "vn_debug__start_msg_flag");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__start_msg_flag_3_0_i2,
		STATIC(mercury__vn_debug__start_msg_flag_3_0));
	}
Define_label(mercury__vn_debug__start_msg_flag_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__start_msg_flag_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((((Integer) r1 & ((Integer) 2)) != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_debug__start_msg_flag_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__vn_debug__start_msg_flag_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_debug_bunch_0(void)
{
	mercury__vn_debug_module0();
	mercury__vn_debug_module1();
	mercury__vn_debug_module2();
	mercury__vn_debug_module3();
	mercury__vn_debug_module4();
	mercury__vn_debug_module5();
	mercury__vn_debug_module6();
	mercury__vn_debug_module7();
	mercury__vn_debug_module8();
	mercury__vn_debug_module9();
	mercury__vn_debug_module10();
	mercury__vn_debug_module11();
	mercury__vn_debug_module12();
	mercury__vn_debug_module13();
	mercury__vn_debug_module14();
	mercury__vn_debug_module15();
	mercury__vn_debug_module16();
	mercury__vn_debug_module17();
	mercury__vn_debug_module18();
	mercury__vn_debug_module19();
	mercury__vn_debug_module20();
	mercury__vn_debug_module21();
	mercury__vn_debug_module22();
	mercury__vn_debug_module23();
	mercury__vn_debug_module24();
	mercury__vn_debug_module25();
	mercury__vn_debug_module26();
	mercury__vn_debug_module27();
	mercury__vn_debug_module28();
	mercury__vn_debug_module29();
	mercury__vn_debug_module30();
	mercury__vn_debug_module31();
	mercury__vn_debug_module32();
	mercury__vn_debug_module33();
}

#endif

void mercury__vn_debug__init(void); /* suppress gcc warning */
void mercury__vn_debug__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_debug_bunch_0();
#endif
}
