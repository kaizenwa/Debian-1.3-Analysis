/*
** Automatically generated from `opt_debug.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__opt_debug__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__opt_debug__msg_4_0);
Declare_label(mercury__opt_debug__msg_4_0_i1001);
Declare_label(mercury__opt_debug__msg_4_0_i4);
Declare_label(mercury__opt_debug__msg_4_0_i5);
Define_extern_entry(mercury__opt_debug__dump_instrs_4_0);
Declare_label(mercury__opt_debug__dump_instrs_4_0_i1003);
Define_extern_entry(mercury__opt_debug__dump_node_relmap_2_0);
Declare_label(mercury__opt_debug__dump_node_relmap_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_nodemap_2_0);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i4);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i5);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i6);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_nodelist_2_0);
Declare_label(mercury__opt_debug__dump_nodelist_2_0_i4);
Declare_label(mercury__opt_debug__dump_nodelist_2_0_i5);
Declare_label(mercury__opt_debug__dump_nodelist_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_longnodelist_2_0);
Declare_label(mercury__opt_debug__dump_longnodelist_2_0_i4);
Declare_label(mercury__opt_debug__dump_longnodelist_2_0_i5);
Declare_label(mercury__opt_debug__dump_longnodelist_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_node_2_0);
Declare_label(mercury__opt_debug__dump_node_2_0_i5);
Declare_label(mercury__opt_debug__dump_node_2_0_i1000);
Declare_label(mercury__opt_debug__dump_node_2_0_i8);
Declare_label(mercury__opt_debug__dump_node_2_0_i7);
Declare_label(mercury__opt_debug__dump_node_2_0_i11);
Declare_label(mercury__opt_debug__dump_node_2_0_i10);
Declare_label(mercury__opt_debug__dump_node_2_0_i13);
Define_extern_entry(mercury__opt_debug__dump_intlist_2_0);
Declare_label(mercury__opt_debug__dump_intlist_2_0_i4);
Declare_label(mercury__opt_debug__dump_intlist_2_0_i5);
Declare_label(mercury__opt_debug__dump_intlist_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_livemap_2_0);
Declare_label(mercury__opt_debug__dump_livemap_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_livemaplist_2_0);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i4);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i5);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i6);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_livevals_2_0);
Declare_label(mercury__opt_debug__dump_livevals_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_livelist_2_0);
Declare_label(mercury__opt_debug__dump_livelist_2_0_i4);
Declare_label(mercury__opt_debug__dump_livelist_2_0_i5);
Declare_label(mercury__opt_debug__dump_livelist_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_ctrlmap_2_0);
Declare_label(mercury__opt_debug__dump_ctrlmap_2_0_i2);
Declare_label(mercury__opt_debug__dump_ctrlmap_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_ctrl_list_2_0);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i4);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i5);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i6);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_vninstr_2_0);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1042);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1041);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1040);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1039);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1038);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1037);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1036);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1035);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1034);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1033);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1030);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i6);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i7);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i9);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i10);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i12);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i13);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i15);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i16);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i17);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i19);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i20);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i22);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i23);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i25);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i26);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i28);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i29);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i31);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i32);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i34);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i35);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1032);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i37);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i38);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i40);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i41);
Define_extern_entry(mercury__opt_debug__dump_flushmap_2_0);
Declare_label(mercury__opt_debug__dump_flushmap_2_0_i2);
Declare_label(mercury__opt_debug__dump_flushmap_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_flush_list_2_0);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i4);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i5);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i6);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i7);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_flush_entry_2_0);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i4);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i5);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i6);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_useful_vns_2_0);
Declare_label(mercury__opt_debug__dump_useful_vns_2_0_i2);
Declare_label(mercury__opt_debug__dump_useful_vns_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_useful_locs_2_0);
Declare_label(mercury__opt_debug__dump_useful_locs_2_0_i2);
Declare_label(mercury__opt_debug__dump_useful_locs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_vn_locs_2_0);
Declare_label(mercury__opt_debug__dump_vn_locs_2_0_i2);
Declare_label(mercury__opt_debug__dump_vn_locs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_tables_2_0);
Declare_label(mercury__opt_debug__dump_tables_2_0_i2);
Declare_label(mercury__opt_debug__dump_tables_2_0_i3);
Declare_label(mercury__opt_debug__dump_tables_2_0_i4);
Declare_label(mercury__opt_debug__dump_tables_2_0_i5);
Declare_label(mercury__opt_debug__dump_tables_2_0_i6);
Declare_label(mercury__opt_debug__dump_tables_2_0_i7);
Declare_label(mercury__opt_debug__dump_tables_2_0_i8);
Declare_label(mercury__opt_debug__dump_tables_2_0_i9);
Declare_label(mercury__opt_debug__dump_tables_2_0_i10);
Declare_label(mercury__opt_debug__dump_tables_2_0_i11);
Declare_label(mercury__opt_debug__dump_tables_2_0_i12);
Declare_label(mercury__opt_debug__dump_tables_2_0_i13);
Declare_label(mercury__opt_debug__dump_tables_2_0_i14);
Declare_label(mercury__opt_debug__dump_tables_2_0_i15);
Declare_label(mercury__opt_debug__dump_tables_2_0_i16);
Declare_label(mercury__opt_debug__dump_tables_2_0_i17);
Declare_label(mercury__opt_debug__dump_tables_2_0_i18);
Declare_label(mercury__opt_debug__dump_tables_2_0_i19);
Declare_label(mercury__opt_debug__dump_tables_2_0_i20);
Declare_label(mercury__opt_debug__dump_tables_2_0_i21);
Define_extern_entry(mercury__opt_debug__dump_lval_to_vn_2_0);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i4);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i5);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i6);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_rval_to_vn_2_0);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i4);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i5);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i6);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_vn_to_rval_2_0);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i4);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i5);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i6);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_vn_to_uses_3_0);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i4);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i9);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i10);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
Define_extern_entry(mercury__opt_debug__dump_vn_to_locs_2_0);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i4);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i5);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i6);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_uses_list_2_0);
Declare_label(mercury__opt_debug__dump_uses_list_2_0_i4);
Declare_label(mercury__opt_debug__dump_uses_list_2_0_i5);
Declare_label(mercury__opt_debug__dump_uses_list_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_use_2_0);
Declare_label(mercury__opt_debug__dump_use_2_0_i5);
Declare_label(mercury__opt_debug__dump_use_2_0_i1000);
Declare_label(mercury__opt_debug__dump_use_2_0_i8);
Declare_label(mercury__opt_debug__dump_use_2_0_i7);
Declare_label(mercury__opt_debug__dump_use_2_0_i11);
Declare_label(mercury__opt_debug__dump_use_2_0_i10);
Declare_label(mercury__opt_debug__dump_use_2_0_i13);
Define_extern_entry(mercury__opt_debug__dump_vn_2_0);
Define_extern_entry(mercury__opt_debug__dump_vnlvals_2_0);
Declare_label(mercury__opt_debug__dump_vnlvals_2_0_i4);
Declare_label(mercury__opt_debug__dump_vnlvals_2_0_i5);
Declare_label(mercury__opt_debug__dump_vnlvals_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_reg_2_0);
Declare_label(mercury__opt_debug__dump_reg_2_0_i4);
Declare_label(mercury__opt_debug__dump_reg_2_0_i1000);
Declare_label(mercury__opt_debug__dump_reg_2_0_i6);
Define_extern_entry(mercury__opt_debug__dump_vnlval_2_0);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1012);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1011);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1010);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1009);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1008);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1007);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1006);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i5);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i6);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i8);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i9);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i11);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i12);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i14);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i15);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i17);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i18);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i20);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i21);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i22);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i23);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i25);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i26);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i1005);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i29);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i31);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i33);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i35);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i37);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i28);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i40);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i39);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i42);
Define_extern_entry(mercury__opt_debug__dump_vnrval_2_0);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i6);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i7);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i8);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i5);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i11);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i12);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i10);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i14);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i15);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i16);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i1000);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i19);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i18);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i22);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i23);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i21);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i25);
Define_extern_entry(mercury__opt_debug__dump_lval_2_0);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1047);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1046);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1045);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1044);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1043);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1042);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1041);
Declare_label(mercury__opt_debug__dump_lval_2_0_i5);
Declare_label(mercury__opt_debug__dump_lval_2_0_i6);
Declare_label(mercury__opt_debug__dump_lval_2_0_i8);
Declare_label(mercury__opt_debug__dump_lval_2_0_i9);
Declare_label(mercury__opt_debug__dump_lval_2_0_i11);
Declare_label(mercury__opt_debug__dump_lval_2_0_i12);
Declare_label(mercury__opt_debug__dump_lval_2_0_i14);
Declare_label(mercury__opt_debug__dump_lval_2_0_i15);
Declare_label(mercury__opt_debug__dump_lval_2_0_i17);
Declare_label(mercury__opt_debug__dump_lval_2_0_i18);
Declare_label(mercury__opt_debug__dump_lval_2_0_i20);
Declare_label(mercury__opt_debug__dump_lval_2_0_i21);
Declare_label(mercury__opt_debug__dump_lval_2_0_i23);
Declare_label(mercury__opt_debug__dump_lval_2_0_i24);
Declare_label(mercury__opt_debug__dump_lval_2_0_i25);
Declare_label(mercury__opt_debug__dump_lval_2_0_i26);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1040);
Declare_label(mercury__opt_debug__dump_lval_2_0_i31);
Declare_label(mercury__opt_debug__dump_lval_2_0_i33);
Declare_label(mercury__opt_debug__dump_lval_2_0_i35);
Declare_label(mercury__opt_debug__dump_lval_2_0_i37);
Declare_label(mercury__opt_debug__dump_lval_2_0_i39);
Declare_label(mercury__opt_debug__dump_lval_2_0_i30);
Declare_label(mercury__opt_debug__dump_lval_2_0_i42);
Declare_label(mercury__opt_debug__dump_lval_2_0_i41);
Declare_label(mercury__opt_debug__dump_lval_2_0_i44);
Declare_label(mercury__opt_debug__dump_lval_2_0_i1034);
Define_extern_entry(mercury__opt_debug__dump_rval_2_0);
Declare_label(mercury__opt_debug__dump_rval_2_0_i6);
Declare_label(mercury__opt_debug__dump_rval_2_0_i7);
Declare_label(mercury__opt_debug__dump_rval_2_0_i5);
Declare_label(mercury__opt_debug__dump_rval_2_0_i10);
Declare_label(mercury__opt_debug__dump_rval_2_0_i9);
Declare_label(mercury__opt_debug__dump_rval_2_0_i13);
Declare_label(mercury__opt_debug__dump_rval_2_0_i14);
Declare_label(mercury__opt_debug__dump_rval_2_0_i12);
Declare_label(mercury__opt_debug__dump_rval_2_0_i16);
Declare_label(mercury__opt_debug__dump_rval_2_0_i17);
Declare_label(mercury__opt_debug__dump_rval_2_0_i18);
Declare_label(mercury__opt_debug__dump_rval_2_0_i1000);
Declare_label(mercury__opt_debug__dump_rval_2_0_i21);
Declare_label(mercury__opt_debug__dump_rval_2_0_i20);
Declare_label(mercury__opt_debug__dump_rval_2_0_i23);
Declare_label(mercury__opt_debug__dump_rval_2_0_i25);
Declare_label(mercury__opt_debug__dump_rval_2_0_i26);
Declare_label(mercury__opt_debug__dump_rval_2_0_i28);
Declare_label(mercury__opt_debug__dump_rval_2_0_i27);
Declare_label(mercury__opt_debug__dump_rval_2_0_i29);
Define_extern_entry(mercury__opt_debug__dump_rvals_2_0);
Declare_label(mercury__opt_debug__dump_rvals_2_0_i4);
Declare_label(mercury__opt_debug__dump_rvals_2_0_i5);
Declare_label(mercury__opt_debug__dump_rvals_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_const_2_0);
Declare_label(mercury__opt_debug__dump_const_2_0_i1003);
Declare_label(mercury__opt_debug__dump_const_2_0_i8);
Declare_label(mercury__opt_debug__dump_const_2_0_i7);
Declare_label(mercury__opt_debug__dump_const_2_0_i10);
Declare_label(mercury__opt_debug__dump_const_2_0_i1002);
Declare_label(mercury__opt_debug__dump_const_2_0_i12);
Declare_label(mercury__opt_debug__dump_const_2_0_i1000);
Declare_label(mercury__opt_debug__dump_const_2_0_i1001);
Define_extern_entry(mercury__opt_debug__dump_data_name_2_0);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i5);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i1001);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i8);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i7);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i10);
Define_extern_entry(mercury__opt_debug__dump_unop_2_0);
Define_extern_entry(mercury__opt_debug__dump_binop_2_0);
Define_extern_entry(mercury__opt_debug__dump_label_2_0);
Declare_label(mercury__opt_debug__dump_label_2_0_i5);
Declare_label(mercury__opt_debug__dump_label_2_0_i6);
Declare_label(mercury__opt_debug__dump_label_2_0_i4);
Declare_label(mercury__opt_debug__dump_label_2_0_i8);
Declare_label(mercury__opt_debug__dump_label_2_0_i1000);
Define_extern_entry(mercury__opt_debug__dump_labels_2_0);
Declare_label(mercury__opt_debug__dump_labels_2_0_i4);
Declare_label(mercury__opt_debug__dump_labels_2_0_i5);
Declare_label(mercury__opt_debug__dump_labels_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_label_pairs_2_0);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i4);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i5);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i6);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_proclabel_2_0);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i4);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i5);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i6);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i3);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i8);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i9);
Define_extern_entry(mercury__opt_debug__dump_maybe_rvals_3_0);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i9);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i6);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i10);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i11);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i1007);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_code_addr_2_0);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1006);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1007);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1008);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1009);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1010);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1011);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1019);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i11);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i13);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i1018);
Define_extern_entry(mercury__opt_debug__dump_code_addrs_2_0);
Declare_label(mercury__opt_debug__dump_code_addrs_2_0_i4);
Declare_label(mercury__opt_debug__dump_code_addrs_2_0_i5);
Declare_label(mercury__opt_debug__dump_code_addrs_2_0_i1004);
Define_extern_entry(mercury__opt_debug__dump_bool_2_0);
Declare_label(mercury__opt_debug__dump_bool_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_instr_2_0);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1018);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1017);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1016);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1015);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1014);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1013);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1012);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1011);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1010);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1009);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1008);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1007);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1006);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1005);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1004);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1003);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1002);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1001);
Declare_label(mercury__opt_debug__dump_instr_2_0_i5);
Declare_label(mercury__opt_debug__dump_instr_2_0_i6);
Declare_label(mercury__opt_debug__dump_instr_2_0_i7);
Declare_label(mercury__opt_debug__dump_instr_2_0_i9);
Declare_label(mercury__opt_debug__dump_instr_2_0_i10);
Declare_label(mercury__opt_debug__dump_instr_2_0_i11);
Declare_label(mercury__opt_debug__dump_instr_2_0_i13);
Declare_label(mercury__opt_debug__dump_instr_2_0_i14);
Declare_label(mercury__opt_debug__dump_instr_2_0_i15);
Declare_label(mercury__opt_debug__dump_instr_2_0_i17);
Declare_label(mercury__opt_debug__dump_instr_2_0_i18);
Declare_label(mercury__opt_debug__dump_instr_2_0_i19);
Declare_label(mercury__opt_debug__dump_instr_2_0_i21);
Declare_label(mercury__opt_debug__dump_instr_2_0_i22);
Declare_label(mercury__opt_debug__dump_instr_2_0_i24);
Declare_label(mercury__opt_debug__dump_instr_2_0_i25);
Declare_label(mercury__opt_debug__dump_instr_2_0_i27);
Declare_label(mercury__opt_debug__dump_instr_2_0_i28);
Declare_label(mercury__opt_debug__dump_instr_2_0_i30);
Declare_label(mercury__opt_debug__dump_instr_2_0_i31);
Declare_label(mercury__opt_debug__dump_instr_2_0_i32);
Declare_label(mercury__opt_debug__dump_instr_2_0_i34);
Declare_label(mercury__opt_debug__dump_instr_2_0_i36);
Declare_label(mercury__opt_debug__dump_instr_2_0_i37);
Declare_label(mercury__opt_debug__dump_instr_2_0_i38);
Declare_label(mercury__opt_debug__dump_instr_2_0_i40);
Declare_label(mercury__opt_debug__dump_instr_2_0_i41);
Declare_label(mercury__opt_debug__dump_instr_2_0_i44);
Declare_label(mercury__opt_debug__dump_instr_2_0_i43);
Declare_label(mercury__opt_debug__dump_instr_2_0_i42);
Declare_label(mercury__opt_debug__dump_instr_2_0_i45);
Declare_label(mercury__opt_debug__dump_instr_2_0_i47);
Declare_label(mercury__opt_debug__dump_instr_2_0_i48);
Declare_label(mercury__opt_debug__dump_instr_2_0_i50);
Declare_label(mercury__opt_debug__dump_instr_2_0_i51);
Declare_label(mercury__opt_debug__dump_instr_2_0_i53);
Declare_label(mercury__opt_debug__dump_instr_2_0_i54);
Declare_label(mercury__opt_debug__dump_instr_2_0_i56);
Declare_label(mercury__opt_debug__dump_instr_2_0_i57);
Declare_label(mercury__opt_debug__dump_instr_2_0_i59);
Declare_label(mercury__opt_debug__dump_instr_2_0_i60);
Declare_label(mercury__opt_debug__dump_instr_2_0_i62);
Declare_label(mercury__opt_debug__dump_instr_2_0_i63);
Declare_label(mercury__opt_debug__dump_instr_2_0_i65);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1000);
Declare_label(mercury__opt_debug__dump_instr_2_0_i67);
Declare_label(mercury__opt_debug__dump_instr_2_0_i68);
Declare_label(mercury__opt_debug__dump_instr_2_0_i70);
Define_extern_entry(mercury__opt_debug__dump_fullinstr_2_0);
Declare_label(mercury__opt_debug__dump_fullinstr_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_fullinstrs_2_0);
Declare_label(mercury__opt_debug__dump_fullinstrs_2_0_i4);
Declare_label(mercury__opt_debug__dump_fullinstrs_2_0_i5);
Declare_label(mercury__opt_debug__dump_fullinstrs_2_0_i1003);
Define_extern_entry(mercury__opt_debug__dump_code_model_2_0);
Declare_label(mercury__opt_debug__dump_code_model_2_0_i3);
Declare_label(mercury__opt_debug__dump_code_model_2_0_i4);
Declare_static(mercury__opt_debug__dump_instrs_2_3_0);
Declare_label(mercury__opt_debug__dump_instrs_2_3_0_i4);
Declare_label(mercury__opt_debug__dump_instrs_2_3_0_i1002);

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_vn_type__base_type_info_vn_node_0[];
Word * mercury_data_opt_debug__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vn_node_0
};

extern Word * mercury_data_set__base_type_info_set_1[];
extern Word * mercury_data_llds__base_type_info_lval_0[];
Word * mercury_data_opt_debug__common_1[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0
};

Word * mercury_data_opt_debug__common_2[] = {
	(Word *) string_const(")", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_3[] = {
	(Word *) string_const("livevals(...)", 13),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_vn_type__base_type_info_vnlval_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_opt_debug__common_4[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_vn_type__base_type_info_vn_src_0[];
Word * mercury_data_opt_debug__common_5[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vn_src_0
};

Word * mercury_data_opt_debug__common_6[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0
};

Word * mercury_data_opt_debug__common_7[] = {
	(Word *) string_const("vn_succip", 9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_8[] = {
	(Word *) string_const("vn_maxfr", 8),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_9[] = {
	(Word *) string_const("vn_curfr", 8),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_10[] = {
	(Word *) string_const("vn_hp", 5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_11[] = {
	(Word *) string_const("vn_sp", 5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_12[] = {
	(Word *) string_const("succip", 6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_13[] = {
	(Word *) string_const("maxfr", 5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_14[] = {
	(Word *) string_const("curfr", 5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_15[] = {
	(Word *) string_const("hp", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_16[] = {
	(Word *) string_const("sp", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_17[] = {
	(Word *) string_const("lvar(_)", 7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_18[] = {
	(Word *) string_const("var(_)", 6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_19[] = {
	(Word *) string_const("\"", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_20[] = {
	(Word *) string_const(", ...)", 6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_opt_debug__common_21[] = {
	(Word *) string_const("\n", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

BEGIN_MODULE(mercury__opt_debug_module0)
	init_entry(mercury__opt_debug__msg_4_0);
	init_label(mercury__opt_debug__msg_4_0_i1001);
	init_label(mercury__opt_debug__msg_4_0_i4);
	init_label(mercury__opt_debug__msg_4_0_i5);
BEGIN_CODE

/* code for predicate 'opt_debug__msg'/4 in mode 0 */
Define_entry(mercury__opt_debug__msg_4_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__msg_4_0_i1001);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__opt_debug__msg_4_0_i1001);
	incr_sp_push_msg(2, "opt_debug__msg");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r1 = string_const("\n", 1);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__opt_debug__msg_4_0_i4,
		ENTRY(mercury__opt_debug__msg_4_0));
	}
Define_label(mercury__opt_debug__msg_4_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__msg_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__opt_debug__msg_4_0_i5,
		ENTRY(mercury__opt_debug__msg_4_0));
	}
Define_label(mercury__opt_debug__msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__msg_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__opt_debug__msg_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module1)
	init_entry(mercury__opt_debug__dump_instrs_4_0);
	init_label(mercury__opt_debug__dump_instrs_4_0_i1003);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_instrs'/4 in mode 0 */
Define_entry(mercury__opt_debug__dump_instrs_4_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_instrs_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__opt_debug__dump_instrs_4_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__opt_debug__dump_instrs_2_3_0),
		ENTRY(mercury__opt_debug__dump_instrs_4_0));
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module2)
	init_entry(mercury__opt_debug__dump_node_relmap_2_0);
	init_label(mercury__opt_debug__dump_node_relmap_2_0_i2);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_node_relmap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_node_relmap_2_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vn_node_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_0);
	incr_sp_push_msg(1, "opt_debug__dump_node_relmap");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_node_relmap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_node_relmap_2_0));
	}
Define_label(mercury__opt_debug__dump_node_relmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_relmap_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_nodemap_2_0),
		ENTRY(mercury__opt_debug__dump_node_relmap_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module3)
	init_entry(mercury__opt_debug__dump_nodemap_2_0);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i4);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i5);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i6);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_nodemap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_nodemap_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_nodemap_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_nodemap");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_node_2_0),
		mercury__opt_debug__dump_nodemap_2_0_i4,
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
	}
Define_label(mercury__opt_debug__dump_nodemap_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodemap_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_nodelist_2_0),
		mercury__opt_debug__dump_nodemap_2_0_i5,
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
	}
Define_label(mercury__opt_debug__dump_nodemap_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodemap_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_nodemap_2_0,
		LABEL(mercury__opt_debug__dump_nodemap_2_0_i6),
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
Define_label(mercury__opt_debug__dump_nodemap_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodemap_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_nodemap_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module4)
	init_entry(mercury__opt_debug__dump_nodelist_2_0);
	init_label(mercury__opt_debug__dump_nodelist_2_0_i4);
	init_label(mercury__opt_debug__dump_nodelist_2_0_i5);
	init_label(mercury__opt_debug__dump_nodelist_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_nodelist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_nodelist_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_nodelist_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_nodelist");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_node_2_0),
		mercury__opt_debug__dump_nodelist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_nodelist_2_0));
	}
Define_label(mercury__opt_debug__dump_nodelist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodelist_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_nodelist_2_0,
		LABEL(mercury__opt_debug__dump_nodelist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_nodelist_2_0));
Define_label(mercury__opt_debug__dump_nodelist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodelist_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" ", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_nodelist_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_nodelist_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module5)
	init_entry(mercury__opt_debug__dump_longnodelist_2_0);
	init_label(mercury__opt_debug__dump_longnodelist_2_0_i4);
	init_label(mercury__opt_debug__dump_longnodelist_2_0_i5);
	init_label(mercury__opt_debug__dump_longnodelist_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_longnodelist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_longnodelist_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_longnodelist_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_longnodelist");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_node_2_0),
		mercury__opt_debug__dump_longnodelist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_longnodelist_2_0));
	}
Define_label(mercury__opt_debug__dump_longnodelist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_longnodelist_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_longnodelist_2_0,
		LABEL(mercury__opt_debug__dump_longnodelist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_longnodelist_2_0));
Define_label(mercury__opt_debug__dump_longnodelist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_longnodelist_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("\n", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_longnodelist_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_longnodelist_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module6)
	init_entry(mercury__opt_debug__dump_node_2_0);
	init_label(mercury__opt_debug__dump_node_2_0_i5);
	init_label(mercury__opt_debug__dump_node_2_0_i1000);
	init_label(mercury__opt_debug__dump_node_2_0_i8);
	init_label(mercury__opt_debug__dump_node_2_0_i7);
	init_label(mercury__opt_debug__dump_node_2_0_i11);
	init_label(mercury__opt_debug__dump_node_2_0_i10);
	init_label(mercury__opt_debug__dump_node_2_0_i13);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_node'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_node_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_node_2_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(1, "opt_debug__dump_node");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_node_2_0_i5,
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("shared vn ", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i1000);
	incr_sp_push_msg(1, "opt_debug__dump_node");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_node_2_0_i7);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_node_2_0_i8,
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vnlval ", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i7);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__opt_debug__dump_node_2_0_i10);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_node_2_0_i11,
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("orig vnlval ", 12);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_node_2_0_i13,
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
Define_label(mercury__opt_debug__dump_node_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("ctrl ", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module7)
	init_entry(mercury__opt_debug__dump_intlist_2_0);
	init_label(mercury__opt_debug__dump_intlist_2_0_i4);
	init_label(mercury__opt_debug__dump_intlist_2_0_i5);
	init_label(mercury__opt_debug__dump_intlist_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_intlist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_intlist_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_intlist_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_intlist");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_intlist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_intlist_2_0));
	}
Define_label(mercury__opt_debug__dump_intlist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_intlist_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_intlist_2_0,
		LABEL(mercury__opt_debug__dump_intlist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_intlist_2_0));
Define_label(mercury__opt_debug__dump_intlist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_intlist_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_intlist_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_intlist_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module8)
	init_entry(mercury__opt_debug__dump_livemap_2_0);
	init_label(mercury__opt_debug__dump_livemap_2_0_i2);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_livemap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livemap_2_0);
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_1);
	incr_sp_push_msg(1, "opt_debug__dump_livemap");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_livemap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_livemap_2_0));
	}
Define_label(mercury__opt_debug__dump_livemap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemap_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_livemaplist_2_0),
		ENTRY(mercury__opt_debug__dump_livemap_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module9)
	init_entry(mercury__opt_debug__dump_livemaplist_2_0);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i4);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i5);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i6);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_livemaplist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livemaplist_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_livemaplist_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_livemaplist");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_livemaplist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
	}
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_livevals_2_0),
		mercury__opt_debug__dump_livemaplist_2_0_i5,
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
	}
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_livemaplist_2_0,
		LABEL(mercury__opt_debug__dump_livemaplist_2_0_i6),
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" ->", 3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module10)
	init_entry(mercury__opt_debug__dump_livevals_2_0);
	init_label(mercury__opt_debug__dump_livevals_2_0_i2);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_livevals'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livevals_2_0);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	incr_sp_push_msg(1, "opt_debug__dump_livevals");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__opt_debug__dump_livevals_2_0_i2,
		ENTRY(mercury__opt_debug__dump_livevals_2_0));
	}
Define_label(mercury__opt_debug__dump_livevals_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livevals_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_livelist_2_0),
		ENTRY(mercury__opt_debug__dump_livevals_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module11)
	init_entry(mercury__opt_debug__dump_livelist_2_0);
	init_label(mercury__opt_debug__dump_livelist_2_0_i4);
	init_label(mercury__opt_debug__dump_livelist_2_0_i5);
	init_label(mercury__opt_debug__dump_livelist_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_livelist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livelist_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_livelist_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_livelist");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_livelist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_livelist_2_0));
	}
Define_label(mercury__opt_debug__dump_livelist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livelist_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_livelist_2_0,
		LABEL(mercury__opt_debug__dump_livelist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_livelist_2_0));
Define_label(mercury__opt_debug__dump_livelist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livelist_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_livelist_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_livelist_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module12)
	init_entry(mercury__opt_debug__dump_ctrlmap_2_0);
	init_label(mercury__opt_debug__dump_ctrlmap_2_0_i2);
	init_label(mercury__opt_debug__dump_ctrlmap_2_0_i3);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_ctrlmap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_ctrlmap_2_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_vn_type__base_type_info_vn_instr_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	}
	incr_sp_push_msg(1, "opt_debug__dump_ctrlmap");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_ctrlmap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_ctrlmap_2_0));
	}
Define_label(mercury__opt_debug__dump_ctrlmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrlmap_2_0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_ctrl_list_2_0),
		mercury__opt_debug__dump_ctrlmap_2_0_i3,
		ENTRY(mercury__opt_debug__dump_ctrlmap_2_0));
	}
Define_label(mercury__opt_debug__dump_ctrlmap_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrlmap_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\nCtrl map\n", 10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__opt_debug__dump_ctrlmap_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module13)
	init_entry(mercury__opt_debug__dump_ctrl_list_2_0);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i4);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i5);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i6);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_ctrl_list'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_ctrl_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_ctrl_list_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_ctrl_list");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_ctrl_list_2_0_i4,
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
	}
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrl_list_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vninstr_2_0),
		mercury__opt_debug__dump_ctrl_list_2_0_i5,
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
	}
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrl_list_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_ctrl_list_2_0,
		LABEL(mercury__opt_debug__dump_ctrl_list_2_0_i6),
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrl_list_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module14)
	init_entry(mercury__opt_debug__dump_vninstr_2_0);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1042);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1041);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1040);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1039);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1038);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1037);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1036);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1035);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1034);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1033);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1030);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i6);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i7);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i9);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i10);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i12);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i13);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i15);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i16);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i17);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i19);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i20);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i22);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i23);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i25);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i26);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i28);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i29);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i31);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i32);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i34);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i35);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1032);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i37);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i38);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i40);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i41);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vninstr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vninstr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i1032);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1030) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1042) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1041) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1040) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1039) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1038) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1037) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1036) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1035) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1034) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1033));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1042);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i6);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1041);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i9);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1040);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i12);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1039);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i15);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1038);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i19);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1037);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i22);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1036);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i25);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1035);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i28);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1034);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i31);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1033);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i34);
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1030);
	r1 = string_const("mkframe", 7);
	proceed();
Define_label(mercury__opt_debug__dump_vninstr_2_0_i6);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i7,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("label(", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i9);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i10,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("goto(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i12);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i13,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("computed_goto(", 14);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i15);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i16,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i17,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("if_val(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i19);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i20,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("mark_hp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i22);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i23,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("restore_hp(", 11);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i25);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i26,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("store_ticket(", 13);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i28);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i29,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i29);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("restore_ticket(", 15);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i31);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i32,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i32);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("incr_sp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i34);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i35,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i35);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("decr_sp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1032);
	incr_sp_push_msg(2, "opt_debug__dump_vninstr");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i37);
	r1 = string_const("discard_ticket", 14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__dump_vninstr_2_0_i37);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_vninstr_2_0_i38);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i38);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i40,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i40);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i41,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i41);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("call(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module15)
	init_entry(mercury__opt_debug__dump_flushmap_2_0);
	init_label(mercury__opt_debug__dump_flushmap_2_0_i2);
	init_label(mercury__opt_debug__dump_flushmap_2_0_i3);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_flushmap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_flushmap_2_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_4);
	incr_sp_push_msg(1, "opt_debug__dump_flushmap");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_flushmap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_flushmap_2_0));
	}
Define_label(mercury__opt_debug__dump_flushmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flushmap_2_0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_flush_list_2_0),
		mercury__opt_debug__dump_flushmap_2_0_i3,
		ENTRY(mercury__opt_debug__dump_flushmap_2_0));
	}
Define_label(mercury__opt_debug__dump_flushmap_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flushmap_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\nFlush map\n", 11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__opt_debug__dump_flushmap_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module16)
	init_entry(mercury__opt_debug__dump_flush_list_2_0);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i4);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i5);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i6);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i7);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_flush_list'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_flush_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_flush_list_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_flush_list");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_flush_list_2_0_i4,
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_flush_list_2_0_i5,
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_list_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_flush_entry_2_0),
		mercury__opt_debug__dump_flush_list_2_0_i6,
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_flush_list_2_0,
		LABEL(mercury__opt_debug__dump_flush_list_2_0_i7),
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
Define_label(mercury__opt_debug__dump_flush_list_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_flush_list_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module17)
	init_entry(mercury__opt_debug__dump_flush_entry_2_0);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i4);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i5);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i6);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_flush_entry'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_flush_entry_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_flush_entry_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_flush_entry");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_flush_entry_2_0_i4,
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_entry_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_flush_entry_2_0_i5,
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_entry_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_flush_entry_2_0,
		LABEL(mercury__opt_debug__dump_flush_entry_2_0_i6),
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_entry_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("/", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module18)
	init_entry(mercury__opt_debug__dump_useful_vns_2_0);
	init_label(mercury__opt_debug__dump_useful_vns_2_0_i2);
	init_label(mercury__opt_debug__dump_useful_vns_2_0_i3);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_useful_vns'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_useful_vns_2_0);
	incr_sp_push_msg(1, "opt_debug__dump_useful_vns");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_uses_table_2_0),
		mercury__opt_debug__dump_useful_vns_2_0_i2,
		ENTRY(mercury__opt_debug__dump_useful_vns_2_0));
	}
Define_label(mercury__opt_debug__dump_useful_vns_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_vns_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_5);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_useful_vns_2_0_i3,
		ENTRY(mercury__opt_debug__dump_useful_vns_2_0));
	}
Define_label(mercury__opt_debug__dump_useful_vns_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_vns_2_0));
	r2 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_vn_to_uses_3_0),
		ENTRY(mercury__opt_debug__dump_useful_vns_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module19)
	init_entry(mercury__opt_debug__dump_useful_locs_2_0);
	init_label(mercury__opt_debug__dump_useful_locs_2_0_i2);
	init_label(mercury__opt_debug__dump_useful_locs_2_0_i3);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_useful_locs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_useful_locs_2_0);
	incr_sp_push_msg(1, "opt_debug__dump_useful_locs");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_loc_to_vn_table_2_0),
		mercury__opt_debug__dump_useful_locs_2_0_i2,
		ENTRY(mercury__opt_debug__dump_useful_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_useful_locs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_locs_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_useful_locs_2_0_i3,
		ENTRY(mercury__opt_debug__dump_useful_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_useful_locs_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_locs_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_lval_to_vn_2_0),
		ENTRY(mercury__opt_debug__dump_useful_locs_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module20)
	init_entry(mercury__opt_debug__dump_vn_locs_2_0);
	init_label(mercury__opt_debug__dump_vn_locs_2_0_i2);
	init_label(mercury__opt_debug__dump_vn_locs_2_0_i3);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vn_locs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_locs_2_0);
	incr_sp_push_msg(1, "opt_debug__dump_vn_locs");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_locs_table_2_0),
		mercury__opt_debug__dump_vn_locs_2_0_i2,
		ENTRY(mercury__opt_debug__dump_vn_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_locs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_locs_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_6);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_vn_locs_2_0_i3,
		ENTRY(mercury__opt_debug__dump_vn_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_locs_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_locs_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_vn_to_locs_2_0),
		ENTRY(mercury__opt_debug__dump_vn_locs_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module21)
	init_entry(mercury__opt_debug__dump_tables_2_0);
	init_label(mercury__opt_debug__dump_tables_2_0_i2);
	init_label(mercury__opt_debug__dump_tables_2_0_i3);
	init_label(mercury__opt_debug__dump_tables_2_0_i4);
	init_label(mercury__opt_debug__dump_tables_2_0_i5);
	init_label(mercury__opt_debug__dump_tables_2_0_i6);
	init_label(mercury__opt_debug__dump_tables_2_0_i7);
	init_label(mercury__opt_debug__dump_tables_2_0_i8);
	init_label(mercury__opt_debug__dump_tables_2_0_i9);
	init_label(mercury__opt_debug__dump_tables_2_0_i10);
	init_label(mercury__opt_debug__dump_tables_2_0_i11);
	init_label(mercury__opt_debug__dump_tables_2_0_i12);
	init_label(mercury__opt_debug__dump_tables_2_0_i13);
	init_label(mercury__opt_debug__dump_tables_2_0_i14);
	init_label(mercury__opt_debug__dump_tables_2_0_i15);
	init_label(mercury__opt_debug__dump_tables_2_0_i16);
	init_label(mercury__opt_debug__dump_tables_2_0_i17);
	init_label(mercury__opt_debug__dump_tables_2_0_i18);
	init_label(mercury__opt_debug__dump_tables_2_0_i19);
	init_label(mercury__opt_debug__dump_tables_2_0_i20);
	init_label(mercury__opt_debug__dump_tables_2_0_i21);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_tables'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_tables_2_0);
	incr_sp_push_msg(7, "opt_debug__dump_tables");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__vn_table__get_next_vn_2_0);
	call_localret(ENTRY(mercury__vn_table__get_next_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i2,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_lval_to_vn_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i3,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_rval_to_vn_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i4,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_rval_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i5,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_uses_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i6,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_locs_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i7,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
	call_localret(ENTRY(mercury__vn_table__get_loc_to_vn_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i8,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_tables_2_0_i9,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i10,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data_vn_type__base_type_info_vnrval_0[];
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	}
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i11,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_vn_type__base_type_info_vnrval_0[];
	r2 = (Integer) mercury_data_vn_type__base_type_info_vnrval_0;
	}
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i12,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_5);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i13,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_opt_debug__common_6);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i14,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i15,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_to_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i16,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_to_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i17,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r1 = (Integer) detstackvar(6);
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_to_rval_2_0),
		mercury__opt_debug__dump_tables_2_0_i18,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 0);
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_to_uses_3_0),
		mercury__opt_debug__dump_tables_2_0_i19,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_to_locs_2_0),
		mercury__opt_debug__dump_tables_2_0_i20,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_to_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i21,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
Define_label(mercury__opt_debug__dump_tables_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\nNext vn\n", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\nVn to rval\n", 12);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\nVn to uses\n", 12);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const("\nLval to vn\n", 12);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("\nVn to locs\n", 12);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\nLoc to vn\n", 11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module22)
	init_entry(mercury__opt_debug__dump_lval_to_vn_2_0);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i4);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i5);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i6);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_lval_to_vn'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_lval_to_vn_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_lval_to_vn_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_lval_to_vn");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__opt_debug__dump_lval_to_vn_2_0,
		LABEL(mercury__opt_debug__dump_lval_to_vn_2_0_i4),
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_to_vn_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_lval_to_vn_2_0_i5,
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_to_vn_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_lval_to_vn_2_0_i6,
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_to_vn_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module23)
	init_entry(mercury__opt_debug__dump_rval_to_vn_2_0);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i4);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i5);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i6);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_rval_to_vn'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_rval_to_vn_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_rval_to_vn_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_rval_to_vn");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__opt_debug__dump_rval_to_vn_2_0,
		LABEL(mercury__opt_debug__dump_rval_to_vn_2_0_i4),
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_to_vn_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnrval_2_0),
		mercury__opt_debug__dump_rval_to_vn_2_0_i5,
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_to_vn_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_rval_to_vn_2_0_i6,
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_to_vn_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module24)
	init_entry(mercury__opt_debug__dump_vn_to_rval_2_0);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i4);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i5);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i6);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vn_to_rval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_to_rval_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_rval_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_vn_to_rval");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__opt_debug__dump_vn_to_rval_2_0,
		LABEL(mercury__opt_debug__dump_vn_to_rval_2_0_i4),
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_rval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vn_to_rval_2_0_i5,
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_rval_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnrval_2_0),
		mercury__opt_debug__dump_vn_to_rval_2_0_i6,
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module25)
	init_entry(mercury__opt_debug__dump_vn_to_uses_3_0);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i4);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i9);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i10);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vn_to_uses'/3 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_to_uses_3_0);
	incr_sp_push_msg(4, "opt_debug__dump_vn_to_uses");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__opt_debug__dump_vn_to_uses_3_0,
		LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i4),
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_uses_3_0));
	if (((Integer) detstackvar(3) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
	if (((Integer) detstackvar(1) == ((Integer) 1)))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vn_to_uses_3_0_i9,
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_uses_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__opt_debug__dump_uses_list_2_0),
		mercury__opt_debug__dump_vn_to_uses_3_0_i10,
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_uses_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
	r1 = string_const("", 0);
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module26)
	init_entry(mercury__opt_debug__dump_vn_to_locs_2_0);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i4);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i5);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i6);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vn_to_locs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_to_locs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_locs_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_vn_to_locs");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	localcall(mercury__opt_debug__dump_vn_to_locs_2_0,
		LABEL(mercury__opt_debug__dump_vn_to_locs_2_0_i4),
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_locs_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vn_to_locs_2_0_i5,
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_locs_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlvals_2_0),
		mercury__opt_debug__dump_vn_to_locs_2_0_i6,
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_locs_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" -> ", 4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
	}
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module27)
	init_entry(mercury__opt_debug__dump_uses_list_2_0);
	init_label(mercury__opt_debug__dump_uses_list_2_0_i4);
	init_label(mercury__opt_debug__dump_uses_list_2_0_i5);
	init_label(mercury__opt_debug__dump_uses_list_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_uses_list'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_uses_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_uses_list_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_uses_list");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_use_2_0),
		mercury__opt_debug__dump_uses_list_2_0_i4,
		ENTRY(mercury__opt_debug__dump_uses_list_2_0));
	}
Define_label(mercury__opt_debug__dump_uses_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_uses_list_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_uses_list_2_0,
		LABEL(mercury__opt_debug__dump_uses_list_2_0_i5),
		ENTRY(mercury__opt_debug__dump_uses_list_2_0));
Define_label(mercury__opt_debug__dump_uses_list_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_uses_list_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_uses_list_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_uses_list_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module28)
	init_entry(mercury__opt_debug__dump_use_2_0);
	init_label(mercury__opt_debug__dump_use_2_0_i5);
	init_label(mercury__opt_debug__dump_use_2_0_i1000);
	init_label(mercury__opt_debug__dump_use_2_0_i8);
	init_label(mercury__opt_debug__dump_use_2_0_i7);
	init_label(mercury__opt_debug__dump_use_2_0_i11);
	init_label(mercury__opt_debug__dump_use_2_0_i10);
	init_label(mercury__opt_debug__dump_use_2_0_i13);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_use'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_use_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_use_2_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(1, "opt_debug__dump_use");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_use_2_0_i5,
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("src_ctrl(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i1000);
	incr_sp_push_msg(1, "opt_debug__dump_use");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_use_2_0_i7);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_use_2_0_i8,
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("src_liveval(", 12);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i7);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__opt_debug__dump_use_2_0_i10);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_use_2_0_i11,
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("src_access(", 11);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_use_2_0_i13,
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
Define_label(mercury__opt_debug__dump_use_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("src_vn(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module29)
	init_entry(mercury__opt_debug__dump_vn_2_0);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vn'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_2_0);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	tailcall(ENTRY(mercury__string__int_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_vn_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module30)
	init_entry(mercury__opt_debug__dump_vnlvals_2_0);
	init_label(mercury__opt_debug__dump_vnlvals_2_0_i4);
	init_label(mercury__opt_debug__dump_vnlvals_2_0_i5);
	init_label(mercury__opt_debug__dump_vnlvals_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vnlvals'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vnlvals_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_vnlvals_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_vnlvals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vnlvals_2_0_i4,
		ENTRY(mercury__opt_debug__dump_vnlvals_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlvals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlvals_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_vnlvals_2_0,
		LABEL(mercury__opt_debug__dump_vnlvals_2_0_i5),
		ENTRY(mercury__opt_debug__dump_vnlvals_2_0));
Define_label(mercury__opt_debug__dump_vnlvals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlvals_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlvals_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vnlvals_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module31)
	init_entry(mercury__opt_debug__dump_reg_2_0);
	init_label(mercury__opt_debug__dump_reg_2_0_i4);
	init_label(mercury__opt_debug__dump_reg_2_0_i1000);
	init_label(mercury__opt_debug__dump_reg_2_0_i6);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_reg'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_reg_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_reg_2_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(1, "opt_debug__dump_reg");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_reg_2_0_i4,
		ENTRY(mercury__opt_debug__dump_reg_2_0));
	}
Define_label(mercury__opt_debug__dump_reg_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_reg_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("f(", 2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_reg_2_0));
	}
Define_label(mercury__opt_debug__dump_reg_2_0_i1000);
	incr_sp_push_msg(1, "opt_debug__dump_reg");
	detstackvar(1) = (Integer) succip;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_reg_2_0_i6,
		ENTRY(mercury__opt_debug__dump_reg_2_0));
	}
Define_label(mercury__opt_debug__dump_reg_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_reg_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("r(", 2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_reg_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module32)
	init_entry(mercury__opt_debug__dump_vnlval_2_0);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1012);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1011);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1010);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1009);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1008);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1007);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1006);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i5);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i6);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i8);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i9);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i11);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i12);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i14);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i15);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i17);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i18);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i20);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i21);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i22);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i23);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i25);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i26);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i1005);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i29);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i31);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i33);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i35);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i37);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i28);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i40);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i39);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i42);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vnlval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vnlval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i1005);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1012) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1011) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1010) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1009) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1008) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1007) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i1006));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1012);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i5);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1011);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i8);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1010);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i11);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1009);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i14);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1008);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i17);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1007);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i20);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i25);
Define_label(mercury__opt_debug__dump_vnlval_2_0_i5);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i6,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_framevar(", 12);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i9,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_succfr(", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i11);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i12,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_prevfr(", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i15,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_redoip(", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i17);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i18,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_succip(", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i20);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i21,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i22,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i22);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i23,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_field(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i25);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_reg_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_temp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i1005);
	incr_sp_push_msg(3, "opt_debug__dump_vnlval");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i28);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i29) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i31) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i33) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i35) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i37));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i29);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i31);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i33);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i35);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i37);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i28);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i39);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_reg_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i40,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i40);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_reg(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i39);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i42,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i42);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_stackvar(", 12);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module33)
	init_entry(mercury__opt_debug__dump_vnrval_2_0);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i6);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i7);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i8);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i5);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i11);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i12);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i10);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i14);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i15);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i16);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i1000);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i19);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i18);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i22);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i23);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i21);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i25);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_vnrval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vnrval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_vnrval_2_0_i1000);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(3, "opt_debug__dump_vnrval");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_vnrval_2_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i6,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 3);
	{
		call_localret(STATIC(mercury__opt_debug__dump_maybe_rvals_3_0),
		mercury__opt_debug__dump_vnrval_2_0_i7,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i8,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_create(", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__opt_debug__dump_vnrval_2_0_i10);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_unop_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i11,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i12,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_unop(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i10);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_binop_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i14,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i15,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i16,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_binop(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i1000);
	incr_sp_push_msg(3, "opt_debug__dump_vnrval");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vnrval_2_0_i18);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i19,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_origlval(", 12);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i18);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_vnrval_2_0_i21);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i22,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i22);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i23,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_mkword(", 10);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i21);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_const_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i25,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i25);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("vn_const(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module34)
	init_entry(mercury__opt_debug__dump_lval_2_0);
	init_label(mercury__opt_debug__dump_lval_2_0_i1047);
	init_label(mercury__opt_debug__dump_lval_2_0_i1046);
	init_label(mercury__opt_debug__dump_lval_2_0_i1045);
	init_label(mercury__opt_debug__dump_lval_2_0_i1044);
	init_label(mercury__opt_debug__dump_lval_2_0_i1043);
	init_label(mercury__opt_debug__dump_lval_2_0_i1042);
	init_label(mercury__opt_debug__dump_lval_2_0_i1041);
	init_label(mercury__opt_debug__dump_lval_2_0_i5);
	init_label(mercury__opt_debug__dump_lval_2_0_i6);
	init_label(mercury__opt_debug__dump_lval_2_0_i8);
	init_label(mercury__opt_debug__dump_lval_2_0_i9);
	init_label(mercury__opt_debug__dump_lval_2_0_i11);
	init_label(mercury__opt_debug__dump_lval_2_0_i12);
	init_label(mercury__opt_debug__dump_lval_2_0_i14);
	init_label(mercury__opt_debug__dump_lval_2_0_i15);
	init_label(mercury__opt_debug__dump_lval_2_0_i17);
	init_label(mercury__opt_debug__dump_lval_2_0_i18);
	init_label(mercury__opt_debug__dump_lval_2_0_i20);
	init_label(mercury__opt_debug__dump_lval_2_0_i21);
	init_label(mercury__opt_debug__dump_lval_2_0_i23);
	init_label(mercury__opt_debug__dump_lval_2_0_i24);
	init_label(mercury__opt_debug__dump_lval_2_0_i25);
	init_label(mercury__opt_debug__dump_lval_2_0_i26);
	init_label(mercury__opt_debug__dump_lval_2_0_i1040);
	init_label(mercury__opt_debug__dump_lval_2_0_i31);
	init_label(mercury__opt_debug__dump_lval_2_0_i33);
	init_label(mercury__opt_debug__dump_lval_2_0_i35);
	init_label(mercury__opt_debug__dump_lval_2_0_i37);
	init_label(mercury__opt_debug__dump_lval_2_0_i39);
	init_label(mercury__opt_debug__dump_lval_2_0_i30);
	init_label(mercury__opt_debug__dump_lval_2_0_i42);
	init_label(mercury__opt_debug__dump_lval_2_0_i41);
	init_label(mercury__opt_debug__dump_lval_2_0_i44);
	init_label(mercury__opt_debug__dump_lval_2_0_i1034);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_lval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_lval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i1040);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__opt_debug__dump_lval_2_0_i1047) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1046) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1045) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1044) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1043) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1042) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1041) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i1034));
Define_label(mercury__opt_debug__dump_lval_2_0_i1047);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i5);
Define_label(mercury__opt_debug__dump_lval_2_0_i1046);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i8);
Define_label(mercury__opt_debug__dump_lval_2_0_i1045);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i11);
Define_label(mercury__opt_debug__dump_lval_2_0_i1044);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i14);
Define_label(mercury__opt_debug__dump_lval_2_0_i1043);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i17);
Define_label(mercury__opt_debug__dump_lval_2_0_i1042);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i20);
Define_label(mercury__opt_debug__dump_lval_2_0_i1041);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i23);
Define_label(mercury__opt_debug__dump_lval_2_0_i5);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_2_0_i6,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("stackvar(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_2_0_i9,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("framevar(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i11);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i12,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("succip(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i15,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("redoip(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i17);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i18,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("succfr(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i20);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i21,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("prevfr(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i23);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_2_0_i24,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i24);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i25,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i25);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("field(", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i1040);
	incr_sp_push_msg(3, "opt_debug__dump_lval");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i30);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__opt_debug__dump_lval_2_0_i31) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i33) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i35) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i37) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i39));
Define_label(mercury__opt_debug__dump_lval_2_0_i31);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i33);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i35);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i37);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i39);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i30);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i41);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_reg_2_0),
		mercury__opt_debug__dump_lval_2_0_i42,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i42);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("reg(", 4);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i41);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_reg_2_0),
		mercury__opt_debug__dump_lval_2_0_i44,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i44);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("temp(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i1034);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_17);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module35)
	init_entry(mercury__opt_debug__dump_rval_2_0);
	init_label(mercury__opt_debug__dump_rval_2_0_i6);
	init_label(mercury__opt_debug__dump_rval_2_0_i7);
	init_label(mercury__opt_debug__dump_rval_2_0_i5);
	init_label(mercury__opt_debug__dump_rval_2_0_i10);
	init_label(mercury__opt_debug__dump_rval_2_0_i9);
	init_label(mercury__opt_debug__dump_rval_2_0_i13);
	init_label(mercury__opt_debug__dump_rval_2_0_i14);
	init_label(mercury__opt_debug__dump_rval_2_0_i12);
	init_label(mercury__opt_debug__dump_rval_2_0_i16);
	init_label(mercury__opt_debug__dump_rval_2_0_i17);
	init_label(mercury__opt_debug__dump_rval_2_0_i18);
	init_label(mercury__opt_debug__dump_rval_2_0_i1000);
	init_label(mercury__opt_debug__dump_rval_2_0_i21);
	init_label(mercury__opt_debug__dump_rval_2_0_i20);
	init_label(mercury__opt_debug__dump_rval_2_0_i23);
	init_label(mercury__opt_debug__dump_rval_2_0_i25);
	init_label(mercury__opt_debug__dump_rval_2_0_i26);
	init_label(mercury__opt_debug__dump_rval_2_0_i28);
	init_label(mercury__opt_debug__dump_rval_2_0_i27);
	init_label(mercury__opt_debug__dump_rval_2_0_i29);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_rval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_rval_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i1000);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(4, "opt_debug__dump_rval");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i6,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i7),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("mkword(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i9);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_const_2_0),
		mercury__opt_debug__dump_rval_2_0_i10,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("const(", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i9);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i12);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_unop_2_0),
		mercury__opt_debug__dump_rval_2_0_i13,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i14),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unop(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i12);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_binop_2_0),
		mercury__opt_debug__dump_rval_2_0_i16,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i17),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i18),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("binop(", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i1000);
	incr_sp_push_msg(4, "opt_debug__dump_rval");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i20);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_rval_2_0_i21,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("lval(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i20);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i23);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i23);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i25,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i25);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 3);
	{
		call_localret(STATIC(mercury__opt_debug__dump_maybe_rvals_3_0),
		mercury__opt_debug__dump_rval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	if (((Integer) detstackvar(2) == ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i28);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r4 = string_const("no", 2);
	GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i27);
Define_label(mercury__opt_debug__dump_rval_2_0_i28);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r4 = string_const("yes", 3);
Define_label(mercury__opt_debug__dump_rval_2_0_i27);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i29,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i29);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("create(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module36)
	init_entry(mercury__opt_debug__dump_rvals_2_0);
	init_label(mercury__opt_debug__dump_rvals_2_0_i4);
	init_label(mercury__opt_debug__dump_rvals_2_0_i5);
	init_label(mercury__opt_debug__dump_rvals_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_rvals'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_rvals_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_rvals_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_rvals");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_rvals_2_0_i4,
		ENTRY(mercury__opt_debug__dump_rvals_2_0));
	}
Define_label(mercury__opt_debug__dump_rvals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rvals_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_rvals_2_0,
		LABEL(mercury__opt_debug__dump_rvals_2_0_i5),
		ENTRY(mercury__opt_debug__dump_rvals_2_0));
Define_label(mercury__opt_debug__dump_rvals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rvals_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rvals_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_rvals_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module37)
	init_entry(mercury__opt_debug__dump_const_2_0);
	init_label(mercury__opt_debug__dump_const_2_0_i1003);
	init_label(mercury__opt_debug__dump_const_2_0_i8);
	init_label(mercury__opt_debug__dump_const_2_0_i7);
	init_label(mercury__opt_debug__dump_const_2_0_i10);
	init_label(mercury__opt_debug__dump_const_2_0_i1002);
	init_label(mercury__opt_debug__dump_const_2_0_i12);
	init_label(mercury__opt_debug__dump_const_2_0_i1000);
	init_label(mercury__opt_debug__dump_const_2_0_i1001);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_const'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_const_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i1002);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i1003);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("\"", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_19);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
Define_label(mercury__opt_debug__dump_const_2_0_i1003);
	incr_sp_push_msg(2, "opt_debug__dump_const");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i7);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_const_2_0_i8,
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
Define_label(mercury__opt_debug__dump_const_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("code_addr_const(", 16);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
Define_label(mercury__opt_debug__dump_const_2_0_i7);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_data_name_2_0),
		mercury__opt_debug__dump_const_2_0_i10,
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
Define_label(mercury__opt_debug__dump_const_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("data_addr_const(", 16);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_const_2_0_i1002);
	incr_sp_push_msg(2, "opt_debug__dump_const");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if ((unmkbody((Integer) r1) != ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i1000);
	r1 = string_const("true", 4);
	proceed();
Define_label(mercury__opt_debug__dump_const_2_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i1001);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	tailcall(ENTRY(mercury__string__int_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
Define_label(mercury__opt_debug__dump_const_2_0_i1000);
	r1 = string_const("false", 5);
	proceed();
Define_label(mercury__opt_debug__dump_const_2_0_i1001);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__string__float_to_string_2_0);
	tailcall(ENTRY(mercury__string__float_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module38)
	init_entry(mercury__opt_debug__dump_data_name_2_0);
	init_label(mercury__opt_debug__dump_data_name_2_0_i5);
	init_label(mercury__opt_debug__dump_data_name_2_0_i1001);
	init_label(mercury__opt_debug__dump_data_name_2_0_i8);
	init_label(mercury__opt_debug__dump_data_name_2_0_i7);
	init_label(mercury__opt_debug__dump_data_name_2_0_i10);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_data_name'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_data_name_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_data_name_2_0_i1001);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(2, "opt_debug__dump_data_name");
	detstackvar(2) = (Integer) succip;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_data_name_2_0_i5,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
	}
Define_label(mercury__opt_debug__dump_data_name_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = (Integer) r1;
	r1 = string_const("common", 6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
	}
Define_label(mercury__opt_debug__dump_data_name_2_0_i1001);
	incr_sp_push_msg(2, "opt_debug__dump_data_name");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_data_name_2_0_i7);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_data_name_2_0_i8,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
	}
Define_label(mercury__opt_debug__dump_data_name_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("base_type_info_", 15);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("_", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_data_name_2_0_i7);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_data_name_2_0_i10,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
	}
Define_label(mercury__opt_debug__dump_data_name_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("base_type_layout_", 17);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("_", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module39)
	init_entry(mercury__opt_debug__dump_unop_2_0);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_unop'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_unop_2_0);
	{
	static const Word * mercury_const_1[] = {
		(Word *) string_const("mktag", 5),
		(Word *) string_const("tag", 3),
		(Word *) string_const("unmktag", 7),
		(Word *) string_const("mkbody", 6),
		(Word *) string_const("body", 4),
		(Word *) string_const("unmkbody", 8),
		(Word *) string_const("cast_to_unsigned", 16),
		(Word *) string_const("hash_string", 11),
		(Word *) string_const("bitwise_complement", 18),
		(Word *) string_const("not", 3)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) r1);
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module40)
	init_entry(mercury__opt_debug__dump_binop_2_0);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_binop'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_binop_2_0);
	{
	Declare_entry(mercury__llds_out__binary_op_to_string_2_0);
	tailcall(ENTRY(mercury__llds_out__binary_op_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_binop_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module41)
	init_entry(mercury__opt_debug__dump_label_2_0);
	init_label(mercury__opt_debug__dump_label_2_0_i5);
	init_label(mercury__opt_debug__dump_label_2_0_i6);
	init_label(mercury__opt_debug__dump_label_2_0_i4);
	init_label(mercury__opt_debug__dump_label_2_0_i8);
	init_label(mercury__opt_debug__dump_label_2_0_i1000);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_label'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_label_2_0);
	r2 = tag((Integer) r1);
	incr_sp_push_msg(2, "opt_debug__dump_label");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_label_2_0_i4);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		mercury__opt_debug__dump_label_2_0_i5,
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
Define_label(mercury__opt_debug__dump_label_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_label_2_0_i6,
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
Define_label(mercury__opt_debug__dump_label_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("_", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_label_2_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_label_2_0_i8);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
Define_label(mercury__opt_debug__dump_label_2_0_i8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__opt_debug__dump_label_2_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		tailcall(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
Define_label(mercury__opt_debug__dump_label_2_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	{
		tailcall(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module42)
	init_entry(mercury__opt_debug__dump_labels_2_0);
	init_label(mercury__opt_debug__dump_labels_2_0_i4);
	init_label(mercury__opt_debug__dump_labels_2_0_i5);
	init_label(mercury__opt_debug__dump_labels_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_labels'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_labels_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_labels_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_labels");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_labels_2_0_i4,
		ENTRY(mercury__opt_debug__dump_labels_2_0));
	}
Define_label(mercury__opt_debug__dump_labels_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_labels_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_labels_2_0,
		LABEL(mercury__opt_debug__dump_labels_2_0_i5),
		ENTRY(mercury__opt_debug__dump_labels_2_0));
Define_label(mercury__opt_debug__dump_labels_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_labels_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_labels_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_labels_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module43)
	init_entry(mercury__opt_debug__dump_label_pairs_2_0);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i4);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i5);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i6);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_label_pairs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_label_pairs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_label_pairs_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_label_pairs");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_label_pairs_2_0_i4,
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
	}
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_pairs_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_label_pairs_2_0_i5,
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
	}
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_pairs_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_label_pairs_2_0,
		LABEL(mercury__opt_debug__dump_label_pairs_2_0_i6),
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_pairs_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("-", 1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module44)
	init_entry(mercury__opt_debug__dump_proclabel_2_0);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i4);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i5);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i6);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i3);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i8);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i9);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_proclabel'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_proclabel_2_0);
	incr_sp_push_msg(5, "opt_debug__dump_proclabel");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_proclabel_2_0_i3);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i4,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i5,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__llds_out__sym_name_mangle_2_0);
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i6,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("_", 1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("_", 1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("_", 1);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const("_", 1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i3);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i8,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i9,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("_", 1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("_", 1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("_", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module45)
	init_entry(mercury__opt_debug__dump_maybe_rvals_3_0);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i9);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i6);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i10);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i11);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i1007);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i1006);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_maybe_rvals'/3 in mode 0 */
Define_entry(mercury__opt_debug__dump_maybe_rvals_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i1006);
	if (((Integer) r2 <= ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i1007);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	incr_sp_push_msg(3, "opt_debug__dump_maybe_rvals");
	detstackvar(3) = (Integer) succip;
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i6);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_maybe_rvals_3_0_i9,
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
	}
	}
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_maybe_rvals_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) detstackvar(1) - ((Integer) 1));
	GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i10);
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i6);
	r1 = (Integer) r3;
	r3 = string_const("no", 2);
	r2 = ((Integer) r2 - ((Integer) 1));
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i10);
	detstackvar(1) = (Integer) r3;
	localcall(mercury__opt_debug__dump_maybe_rvals_3_0,
		LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i11),
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_maybe_rvals_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
	}
	}
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i1007);
	r1 = string_const("truncated", 9);
	proceed();
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i1006);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module46)
	init_entry(mercury__opt_debug__dump_code_addr_2_0);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1006);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1007);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1008);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1009);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1010);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1011);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1019);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i11);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i13);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i1018);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_code_addr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_code_addr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_code_addr_2_0_i1019);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i1006) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i1007) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i1008) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i1009) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i1010) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i1011));
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1006);
	r1 = string_const("succip", 6);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1007);
	r1 = string_const("do_redo", 7);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1008);
	r1 = string_const("do_fail", 7);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1009);
	r1 = string_const("do_det_closure", 14);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1010);
	r1 = string_const("do_semidet_closure", 18);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1011);
	r1 = string_const("do_nondet_closure", 17);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1019);
	incr_sp_push_msg(1, "opt_debug__dump_code_addr");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_code_addr_2_0_i11);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_label_2_0),
		ENTRY(mercury__opt_debug__dump_code_addr_2_0));
	}
Define_label(mercury__opt_debug__dump_code_addr_2_0_i11);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__opt_debug__dump_code_addr_2_0_i13);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		ENTRY(mercury__opt_debug__dump_code_addr_2_0));
	}
Define_label(mercury__opt_debug__dump_code_addr_2_0_i13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) == ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_code_addr_2_0_i1018);
	r1 = string_const("do_succeed", 10);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i1018);
	r1 = string_const("do_last_succeed", 15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module47)
	init_entry(mercury__opt_debug__dump_code_addrs_2_0);
	init_label(mercury__opt_debug__dump_code_addrs_2_0_i4);
	init_label(mercury__opt_debug__dump_code_addrs_2_0_i5);
	init_label(mercury__opt_debug__dump_code_addrs_2_0_i1004);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_code_addrs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_code_addrs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_code_addrs_2_0_i1004);
	incr_sp_push_msg(2, "opt_debug__dump_code_addrs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_code_addrs_2_0_i4,
		ENTRY(mercury__opt_debug__dump_code_addrs_2_0));
	}
Define_label(mercury__opt_debug__dump_code_addrs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_code_addrs_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_code_addrs_2_0,
		LABEL(mercury__opt_debug__dump_code_addrs_2_0_i5),
		ENTRY(mercury__opt_debug__dump_code_addrs_2_0));
Define_label(mercury__opt_debug__dump_code_addrs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_code_addrs_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_code_addrs_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_code_addrs_2_0_i1004);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module48)
	init_entry(mercury__opt_debug__dump_bool_2_0);
	init_label(mercury__opt_debug__dump_bool_2_0_i3);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_bool'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_bool_2_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_bool_2_0_i3);
	r1 = string_const("no", 2);
	proceed();
Define_label(mercury__opt_debug__dump_bool_2_0_i3);
	r1 = string_const("yes", 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module49)
	init_entry(mercury__opt_debug__dump_instr_2_0);
	init_label(mercury__opt_debug__dump_instr_2_0_i1018);
	init_label(mercury__opt_debug__dump_instr_2_0_i1017);
	init_label(mercury__opt_debug__dump_instr_2_0_i1016);
	init_label(mercury__opt_debug__dump_instr_2_0_i1015);
	init_label(mercury__opt_debug__dump_instr_2_0_i1014);
	init_label(mercury__opt_debug__dump_instr_2_0_i1013);
	init_label(mercury__opt_debug__dump_instr_2_0_i1012);
	init_label(mercury__opt_debug__dump_instr_2_0_i1011);
	init_label(mercury__opt_debug__dump_instr_2_0_i1010);
	init_label(mercury__opt_debug__dump_instr_2_0_i1009);
	init_label(mercury__opt_debug__dump_instr_2_0_i1008);
	init_label(mercury__opt_debug__dump_instr_2_0_i1007);
	init_label(mercury__opt_debug__dump_instr_2_0_i1006);
	init_label(mercury__opt_debug__dump_instr_2_0_i1005);
	init_label(mercury__opt_debug__dump_instr_2_0_i1004);
	init_label(mercury__opt_debug__dump_instr_2_0_i1003);
	init_label(mercury__opt_debug__dump_instr_2_0_i1002);
	init_label(mercury__opt_debug__dump_instr_2_0_i1001);
	init_label(mercury__opt_debug__dump_instr_2_0_i5);
	init_label(mercury__opt_debug__dump_instr_2_0_i6);
	init_label(mercury__opt_debug__dump_instr_2_0_i7);
	init_label(mercury__opt_debug__dump_instr_2_0_i9);
	init_label(mercury__opt_debug__dump_instr_2_0_i10);
	init_label(mercury__opt_debug__dump_instr_2_0_i11);
	init_label(mercury__opt_debug__dump_instr_2_0_i13);
	init_label(mercury__opt_debug__dump_instr_2_0_i14);
	init_label(mercury__opt_debug__dump_instr_2_0_i15);
	init_label(mercury__opt_debug__dump_instr_2_0_i17);
	init_label(mercury__opt_debug__dump_instr_2_0_i18);
	init_label(mercury__opt_debug__dump_instr_2_0_i19);
	init_label(mercury__opt_debug__dump_instr_2_0_i21);
	init_label(mercury__opt_debug__dump_instr_2_0_i22);
	init_label(mercury__opt_debug__dump_instr_2_0_i24);
	init_label(mercury__opt_debug__dump_instr_2_0_i25);
	init_label(mercury__opt_debug__dump_instr_2_0_i27);
	init_label(mercury__opt_debug__dump_instr_2_0_i28);
	init_label(mercury__opt_debug__dump_instr_2_0_i30);
	init_label(mercury__opt_debug__dump_instr_2_0_i31);
	init_label(mercury__opt_debug__dump_instr_2_0_i32);
	init_label(mercury__opt_debug__dump_instr_2_0_i34);
	init_label(mercury__opt_debug__dump_instr_2_0_i36);
	init_label(mercury__opt_debug__dump_instr_2_0_i37);
	init_label(mercury__opt_debug__dump_instr_2_0_i38);
	init_label(mercury__opt_debug__dump_instr_2_0_i40);
	init_label(mercury__opt_debug__dump_instr_2_0_i41);
	init_label(mercury__opt_debug__dump_instr_2_0_i44);
	init_label(mercury__opt_debug__dump_instr_2_0_i43);
	init_label(mercury__opt_debug__dump_instr_2_0_i42);
	init_label(mercury__opt_debug__dump_instr_2_0_i45);
	init_label(mercury__opt_debug__dump_instr_2_0_i47);
	init_label(mercury__opt_debug__dump_instr_2_0_i48);
	init_label(mercury__opt_debug__dump_instr_2_0_i50);
	init_label(mercury__opt_debug__dump_instr_2_0_i51);
	init_label(mercury__opt_debug__dump_instr_2_0_i53);
	init_label(mercury__opt_debug__dump_instr_2_0_i54);
	init_label(mercury__opt_debug__dump_instr_2_0_i56);
	init_label(mercury__opt_debug__dump_instr_2_0_i57);
	init_label(mercury__opt_debug__dump_instr_2_0_i59);
	init_label(mercury__opt_debug__dump_instr_2_0_i60);
	init_label(mercury__opt_debug__dump_instr_2_0_i62);
	init_label(mercury__opt_debug__dump_instr_2_0_i63);
	init_label(mercury__opt_debug__dump_instr_2_0_i65);
	init_label(mercury__opt_debug__dump_instr_2_0_i1000);
	init_label(mercury__opt_debug__dump_instr_2_0_i67);
	init_label(mercury__opt_debug__dump_instr_2_0_i68);
	init_label(mercury__opt_debug__dump_instr_2_0_i70);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_instr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_instr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i1000);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__opt_debug__dump_instr_2_0_i1018) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1017) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1016) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1015) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1014) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1013) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1012) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1011) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1010) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1009) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1008) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1007) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1006) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1005) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1004) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1003) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1002) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i1001));
Define_label(mercury__opt_debug__dump_instr_2_0_i1018);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i5);
Define_label(mercury__opt_debug__dump_instr_2_0_i1017);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i9);
Define_label(mercury__opt_debug__dump_instr_2_0_i1016);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i13);
Define_label(mercury__opt_debug__dump_instr_2_0_i1015);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i17);
Define_label(mercury__opt_debug__dump_instr_2_0_i1014);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i21);
Define_label(mercury__opt_debug__dump_instr_2_0_i1013);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i24);
Define_label(mercury__opt_debug__dump_instr_2_0_i1012);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i27);
Define_label(mercury__opt_debug__dump_instr_2_0_i1011);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i30);
Define_label(mercury__opt_debug__dump_instr_2_0_i1010);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i34);
Define_label(mercury__opt_debug__dump_instr_2_0_i1009);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i36);
Define_label(mercury__opt_debug__dump_instr_2_0_i1008);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i40);
Define_label(mercury__opt_debug__dump_instr_2_0_i1007);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i47);
Define_label(mercury__opt_debug__dump_instr_2_0_i1006);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i50);
Define_label(mercury__opt_debug__dump_instr_2_0_i1005);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i53);
Define_label(mercury__opt_debug__dump_instr_2_0_i1004);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i56);
Define_label(mercury__opt_debug__dump_instr_2_0_i1003);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i59);
Define_label(mercury__opt_debug__dump_instr_2_0_i1002);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i62);
Define_label(mercury__opt_debug__dump_instr_2_0_i1001);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i65);
Define_label(mercury__opt_debug__dump_instr_2_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i6,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i7,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("block(", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_20);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i9);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i10,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i11,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("assign(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i13);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i14,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i15,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("call(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_20);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i17);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i18,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i19,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("mkframe(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i21);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i22,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i22);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("modframe(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i24);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_instr_2_0_i25,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i25);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("label(", 6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i27);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i28,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i28);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("goto(", 5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i30);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i31,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i31);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_labels_2_0),
		mercury__opt_debug__dump_instr_2_0_i32,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i32);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("computed_goto(", 14);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i34);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("c_code(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i36);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i37,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i37);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i38,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i38);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("if_val(", 7);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i40);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i41,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i41);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	if (((Integer) detstackvar(1) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i43);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i44,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i44);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i42);
Define_label(mercury__opt_debug__dump_instr_2_0_i43);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = string_const("no", 2);
Define_label(mercury__opt_debug__dump_instr_2_0_i42);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i45,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i45);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("incr_hp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(", ", 2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(", ", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i47);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i48,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i48);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("mark_hp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i50);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i51,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i51);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("restore_hp(", 11);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i53);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i54,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i54);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("store_ticket(", 13);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i56);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i57,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i57);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("restore_ticket(", 15);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i59);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i60,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i60);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("incr_sp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i62);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i63,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i63);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("decr_sp(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i65);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("pragma_c(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i1000);
	incr_sp_push_msg(3, "opt_debug__dump_instr");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i67);
	r1 = string_const("discard_ticket", 14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__opt_debug__dump_instr_2_0_i67);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i68);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("comment(", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i68);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_livevals_2_0),
		mercury__opt_debug__dump_instr_2_0_i70,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i70);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("livevals(", 9);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module50)
	init_entry(mercury__opt_debug__dump_fullinstr_2_0);
	init_label(mercury__opt_debug__dump_fullinstr_2_0_i2);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_fullinstr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_fullinstr_2_0);
	incr_sp_push_msg(2, "opt_debug__dump_fullinstr");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_instr_2_0),
		mercury__opt_debug__dump_fullinstr_2_0_i2,
		ENTRY(mercury__opt_debug__dump_fullinstr_2_0));
	}
Define_label(mercury__opt_debug__dump_fullinstr_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_fullinstr_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const(" - ", 3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_opt_debug__common_21);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_fullinstr_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module51)
	init_entry(mercury__opt_debug__dump_fullinstrs_2_0);
	init_label(mercury__opt_debug__dump_fullinstrs_2_0_i4);
	init_label(mercury__opt_debug__dump_fullinstrs_2_0_i5);
	init_label(mercury__opt_debug__dump_fullinstrs_2_0_i1003);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_fullinstrs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_fullinstrs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_fullinstrs_2_0_i1003);
	incr_sp_push_msg(2, "opt_debug__dump_fullinstrs");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__opt_debug__dump_fullinstr_2_0),
		mercury__opt_debug__dump_fullinstrs_2_0_i4,
		ENTRY(mercury__opt_debug__dump_fullinstrs_2_0));
	}
Define_label(mercury__opt_debug__dump_fullinstrs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_fullinstrs_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__opt_debug__dump_fullinstrs_2_0,
		LABEL(mercury__opt_debug__dump_fullinstrs_2_0_i5),
		ENTRY(mercury__opt_debug__dump_fullinstrs_2_0));
Define_label(mercury__opt_debug__dump_fullinstrs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_fullinstrs_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_fullinstrs_2_0));
	}
Define_label(mercury__opt_debug__dump_fullinstrs_2_0_i1003);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module52)
	init_entry(mercury__opt_debug__dump_code_model_2_0);
	init_label(mercury__opt_debug__dump_code_model_2_0_i3);
	init_label(mercury__opt_debug__dump_code_model_2_0_i4);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_code_model'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_code_model_2_0);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_code_model_2_0_i3);
	r1 = string_const("model_det", 9);
	proceed();
Define_label(mercury__opt_debug__dump_code_model_2_0_i3);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__opt_debug__dump_code_model_2_0_i4);
	r1 = string_const("model_semi", 10);
	proceed();
Define_label(mercury__opt_debug__dump_code_model_2_0_i4);
	r1 = string_const("model_non", 9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__opt_debug_module53)
	init_entry(mercury__opt_debug__dump_instrs_2_3_0);
	init_label(mercury__opt_debug__dump_instrs_2_3_0_i4);
	init_label(mercury__opt_debug__dump_instrs_2_3_0_i1002);
BEGIN_CODE

/* code for predicate 'opt_debug__dump_instrs_2'/3 in mode 0 */
Define_static(mercury__opt_debug__dump_instrs_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__opt_debug__dump_instrs_2_3_0_i1002);
	incr_sp_push_msg(2, "opt_debug__dump_instrs_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	{
	Declare_entry(mercury__llds_out__output_instruction_3_0);
	call_localret(ENTRY(mercury__llds_out__output_instruction_3_0),
		mercury__opt_debug__dump_instrs_2_3_0_i4,
		STATIC(mercury__opt_debug__dump_instrs_2_3_0));
	}
Define_label(mercury__opt_debug__dump_instrs_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instrs_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__opt_debug__dump_instrs_2_3_0,
		STATIC(mercury__opt_debug__dump_instrs_2_3_0));
Define_label(mercury__opt_debug__dump_instrs_2_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__opt_debug_bunch_0(void)
{
	mercury__opt_debug_module0();
	mercury__opt_debug_module1();
	mercury__opt_debug_module2();
	mercury__opt_debug_module3();
	mercury__opt_debug_module4();
	mercury__opt_debug_module5();
	mercury__opt_debug_module6();
	mercury__opt_debug_module7();
	mercury__opt_debug_module8();
	mercury__opt_debug_module9();
	mercury__opt_debug_module10();
	mercury__opt_debug_module11();
	mercury__opt_debug_module12();
	mercury__opt_debug_module13();
	mercury__opt_debug_module14();
	mercury__opt_debug_module15();
	mercury__opt_debug_module16();
	mercury__opt_debug_module17();
	mercury__opt_debug_module18();
	mercury__opt_debug_module19();
	mercury__opt_debug_module20();
	mercury__opt_debug_module21();
	mercury__opt_debug_module22();
	mercury__opt_debug_module23();
	mercury__opt_debug_module24();
	mercury__opt_debug_module25();
	mercury__opt_debug_module26();
	mercury__opt_debug_module27();
	mercury__opt_debug_module28();
	mercury__opt_debug_module29();
	mercury__opt_debug_module30();
	mercury__opt_debug_module31();
	mercury__opt_debug_module32();
	mercury__opt_debug_module33();
	mercury__opt_debug_module34();
	mercury__opt_debug_module35();
	mercury__opt_debug_module36();
	mercury__opt_debug_module37();
	mercury__opt_debug_module38();
	mercury__opt_debug_module39();
	mercury__opt_debug_module40();
}

static void mercury__opt_debug_bunch_1(void)
{
	mercury__opt_debug_module41();
	mercury__opt_debug_module42();
	mercury__opt_debug_module43();
	mercury__opt_debug_module44();
	mercury__opt_debug_module45();
	mercury__opt_debug_module46();
	mercury__opt_debug_module47();
	mercury__opt_debug_module48();
	mercury__opt_debug_module49();
	mercury__opt_debug_module50();
	mercury__opt_debug_module51();
	mercury__opt_debug_module52();
	mercury__opt_debug_module53();
}

#endif

void mercury__opt_debug__init(void); /* suppress gcc warning */
void mercury__opt_debug__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__opt_debug_bunch_0();
	mercury__opt_debug_bunch_1();
#endif
}
