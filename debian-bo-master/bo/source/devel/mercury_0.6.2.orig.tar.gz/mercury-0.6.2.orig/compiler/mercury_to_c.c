/*
** Automatically generated from `mercury_to_c.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__mercury_to_c__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0);
Declare_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i7);
Declare_static(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0);
Declare_label(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0_i2);
Declare_static(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i4);
Declare_static(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i12);
Define_extern_entry(mercury__mercury_to_c__gen_hlds_4_0);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i2);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i3);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i4);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i5);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i6);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i7);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i8);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i9);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i10);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i11);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i12);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i13);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i14);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i15);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i16);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i17);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i18);
Declare_label(mercury__mercury_to_c__gen_hlds_4_0_i19);
Declare_static(mercury__mercury_to_c__c_gen_preds_2_6_0);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i13);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i17);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i19);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i20);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i21);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i22);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i23);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i24);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i25);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i26);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i27);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i28);
Declare_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i1005);
Declare_static(mercury__mercury_to_c__c_gen_type_3_0);
Declare_label(mercury__mercury_to_c__c_gen_type_3_0_i1001);
Declare_label(mercury__mercury_to_c__c_gen_type_3_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_type_3_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_type_3_0_i23);
Declare_label(mercury__mercury_to_c__c_gen_type_3_0_i1000);
Declare_static(mercury__mercury_to_c__c_gen_procs_2_7_0);
Declare_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i1002);
Declare_static(mercury__mercury_to_c__c_gen_proc_8_0);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i13);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i15);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i17);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i19);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i20);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i21);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i22);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i23);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i24);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i25);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i26);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i27);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i28);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i29);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i30);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i34);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i35);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i36);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i31);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i37);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i38);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i42);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i43);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i44);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i45);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i46);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i47);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i39);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i51);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i48);
Declare_label(mercury__mercury_to_c__c_gen_proc_8_0_i55);
Declare_static(mercury__mercury_to_c__c_gen_prototype_5_0);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i13);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i15);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i23);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i20);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i17);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i26);
Declare_label(mercury__mercury_to_c__c_gen_prototype_5_0_i27);
Declare_static(mercury__mercury_to_c__c_gen_proc_name_5_0);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i13);
Declare_static(mercury__mercury_to_c__c_gen_select_output_vars_4_0);
Declare_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i1001);
Declare_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i6);
Declare_static(mercury__mercury_to_c__c_gen_arg_decls_7_0);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i1001);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i15);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i17);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i19);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i20);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i26);
Declare_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i7);
Declare_static(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i1002);
Declare_static(mercury__mercury_to_c__c_gen_goal_6_0);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i15);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i17);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_goal_6_0_i3);
Declare_static(mercury__mercury_to_c__c_gen_goal_2_6_0);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1008);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1007);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1006);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1005);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1004);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1003);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i15);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i24);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i25);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i26);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i27);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i28);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i29);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i30);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i21);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i34);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i35);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i36);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i37);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i38);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i39);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i40);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i41);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i42);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i43);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i44);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i45);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i47);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i49);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i50);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i51);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i52);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i53);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i54);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i55);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i56);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i57);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i58);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i59);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i60);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i61);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i62);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i63);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i64);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i65);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i66);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i67);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i68);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i72);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i69);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i73);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i74);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i75);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i76);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i78);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1002);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i80);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i83);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i84);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i85);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i86);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i87);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i91);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i88);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i95);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i92);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i97);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i98);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i99);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i100);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i109);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i104);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i110);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i111);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i112);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i113);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i101);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i118);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i115);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i82);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i123);
Declare_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1000);
Declare_static(mercury__mercury_to_c__c_gen_unification_6_0);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i8);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i13);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i1000);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i19);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i20);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i21);
Declare_label(mercury__mercury_to_c__c_gen_unification_6_0_i22);
Declare_static(mercury__mercury_to_c__c_gen_arg_list_6_0);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i1001);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i12);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i16);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i21);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i25);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i20);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i29);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i30);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i31);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i34);
Declare_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i6);
Declare_static(mercury__mercury_to_c__c_gen_var_5_0);
Declare_label(mercury__mercury_to_c__c_gen_var_5_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_var_5_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_var_5_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_var_5_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_var_5_0_i8);
Declare_static(mercury__mercury_to_c__sorry_1_0);
Declare_label(mercury__mercury_to_c__sorry_1_0_i2);
Declare_label(mercury__mercury_to_c__sorry_1_0_i3);
Declare_static(mercury__mercury_to_c__c_gen_conj_6_0);
Declare_label(mercury__mercury_to_c__c_gen_conj_6_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_conj_6_0_i1002);
Declare_static(mercury__mercury_to_c__c_gen_disj_7_0);
Declare_label(mercury__mercury_to_c__c_gen_disj_7_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_disj_7_0_i5);
Declare_label(mercury__mercury_to_c__c_gen_disj_7_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_disj_7_0_i7);
Declare_label(mercury__mercury_to_c__c_gen_disj_7_0_i1002);
Declare_static(mercury__mercury_to_c__c_gen_indent_3_0);
Declare_label(mercury__mercury_to_c__c_gen_indent_3_0_i1000);
Declare_label(mercury__mercury_to_c__c_gen_indent_3_0_i5);
Declare_static(mercury__mercury_to_c__c_gen_label_4_0);
Declare_label(mercury__mercury_to_c__c_gen_label_4_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_label_4_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_label_4_0_i4);
Declare_static(mercury__mercury_to_c__c_gen_failure_5_0);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i4);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i11);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i10);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i9);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i14);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i15);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i13);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i17);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i18);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_failure_5_0_i20);
Declare_static(mercury__mercury_to_c__c_gen_info_init_7_0);
Declare_label(mercury__mercury_to_c__c_gen_info_init_7_0_i2);
Declare_label(mercury__mercury_to_c__c_gen_info_init_7_0_i6);
Declare_label(mercury__mercury_to_c__c_gen_info_init_7_0_i3);
Declare_label(mercury__mercury_to_c__c_gen_info_init_7_0_i7);
Declare_static(mercury__mercury_to_c__c_gen_info_get_code_model_2_0);
Declare_static(mercury__mercury_to_c__c_gen_info_get_module_info_2_0);
Declare_static(mercury__mercury_to_c__c_gen_info_get_failconts_2_0);
Declare_static(mercury__mercury_to_c__c_gen_info_set_failconts_3_0);
Declare_static(mercury__mercury_to_c__c_gen_info_new_label_3_0);
Declare_static(mercury__mercury_to_c__c_gen_info_new_label_func_3_0);
Declare_static(mercury____Unify___mercury_to_c__c_failure_cont_0_0);
Declare_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i5);
Declare_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i4);
Declare_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i8);
Declare_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i2);
Declare_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
Declare_static(mercury____Index___mercury_to_c__c_failure_cont_0_0);
Declare_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i5);
Declare_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i4);
Declare_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i6);
Declare_static(mercury____Compare___mercury_to_c__c_failure_cont_0_0);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i2);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i3);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i4);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i6);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i13);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i12);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i16);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i9);
Declare_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i1000);

extern Word * mercury_data_mercury_to_c__base_type_layout_c_failure_cont_0[];
Word * mercury_data_mercury_to_c__base_type_info_c_failure_cont_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___mercury_to_c__c_failure_cont_0_0),
	(Word *) (Integer) STATIC(mercury____Index___mercury_to_c__c_failure_cont_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0),
	(Word *) (Integer) mercury_data_mercury_to_c__base_type_layout_c_failure_cont_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_mercury_to_c__base_type_layout_c_gen_info_0[];
Word * mercury_data_mercury_to_c__base_type_info_c_gen_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_mercury_to_c__base_type_layout_c_gen_info_0
};

extern Word * mercury_data_mercury_to_c__base_type_layout_c_label_0[];
Word * mercury_data_mercury_to_c__base_type_info_c_label_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_mercury_to_c__base_type_layout_c_label_0
};

extern Word * mercury_data_mercury_to_c__base_type_layout_c_label_func_0[];
Word * mercury_data_mercury_to_c__base_type_info_c_label_func_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_mercury_to_c__base_type_layout_c_label_func_0
};

extern Word * mercury_data_mercury_to_c__base_type_layout_c_success_cont_0[];
Word * mercury_data_mercury_to_c__base_type_info_c_success_cont_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_mercury_to_c__base_type_layout_c_success_cont_0
};

extern Word * mercury_data_mercury_to_c__common_1[];
extern Word * mercury_data_mercury_to_c__common_3[];
Word * mercury_data_mercury_to_c__base_type_layout_c_success_cont_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_to_c__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_to_c__common_4[];
Word * mercury_data_mercury_to_c__base_type_layout_c_label_func_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4)
};

Word * mercury_data_mercury_to_c__base_type_layout_c_label_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_to_c__common_4)
};

extern Word * mercury_data_mercury_to_c__common_10[];
Word * mercury_data_mercury_to_c__base_type_layout_c_gen_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_to_c__common_10),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_to_c__common_11[];
extern Word * mercury_data_mercury_to_c__common_12[];
Word * mercury_data_mercury_to_c__base_type_layout_c_failure_cont_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_11),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_to_c__common_3),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_to_c__common_12),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word mercury_data_mercury_to_c__common_0[] = {
	((Integer) 1)
};

Word * mercury_data_mercury_to_c__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 2),
	(Word *) string_const("semidet_succeed", 15),
	(Word *) string_const("nondet_succeed", 14)
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_mercury_to_c__common_2[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_mercury_to_c__common_3[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2),
	(Word *) string_const("goto", 4)
};

Word * mercury_data_mercury_to_c__common_4[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2)
};

extern Word * mercury_data_llds__base_type_info_code_model_0[];
Word * mercury_data_mercury_to_c__common_5[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_code_model_0
};

extern Word * mercury_data_hlds_module__base_type_info_module_info_0[];
Word * mercury_data_mercury_to_c__common_6[] = {
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_module_info_0
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_mercury_to_c__common_7[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_mercury_to_c__common_8[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_stack__base_type_info_stack_1[];
Word * mercury_data_mercury_to_c__common_9[] = {
	(Word *) (Integer) mercury_data_stack__base_type_info_stack_1,
	(Word *) (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0
};

Word * mercury_data_mercury_to_c__common_10[] = {
	(Word *) ((Integer) 9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2),
	(Word *) string_const("c_gen_info", 10)
};

Word * mercury_data_mercury_to_c__common_11[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 2),
	(Word *) string_const("semidet_fail", 12),
	(Word *) string_const("nondet_fail", 11)
};

Word * mercury_data_mercury_to_c__common_12[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_to_c__common_2),
	(Word *) string_const("call", 4)
};

BEGIN_MODULE(mercury__mercury_to_c_module0)
	init_entry(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0);
	init_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i2);
	init_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i3);
	init_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i4);
	init_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i5);
	init_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i6);
	init_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i7);
BEGIN_CODE

/* code for predicate 'c_gen_insert_label_func__ua10000'/5 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0);
	incr_sp_push_msg(3, "c_gen_insert_label_func__ua10000");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
Define_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const("}\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
Define_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const("void ", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const("MNL_", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = string_const("(void) {\n", 9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module1)
	init_entry(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0);
	init_label(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0_i2);
BEGIN_CODE

/* code for predicate 'c_gen_write_label_func__ua10000'/4 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0);
	incr_sp_push_msg(2, "c_gen_write_label_func__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("MNL_", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_int_3_0);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module2)
	init_entry(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0);
	init_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i2);
	init_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i3);
	init_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i4);
BEGIN_CODE

/* code for predicate 'c_gen_predeclare_label__ua10000'/4 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0);
	incr_sp_push_msg(2, "c_gen_predeclare_label__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("\tauto void ", 11);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = string_const("MNL_", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = string_const("(void);\n", 8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module3)
	init_entry(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i2);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i3);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i4);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i5);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i6);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i7);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i8);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i9);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i10);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i11);
	init_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i12);
BEGIN_CODE

/* code for predicate 'c_gen_predeclare_labels__ua10000'/4 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	incr_sp_push_msg(1, "c_gen_predeclare_labels__ua10000");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 3);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 4);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 5);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 6);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 7);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 8);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i9,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 9);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i10,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 10);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 11);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
Define_label(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_predeclare_label__ua10000_4_0),
		STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module4)
	init_entry(mercury__mercury_to_c__gen_hlds_4_0);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i2);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i3);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i4);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i5);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i6);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i7);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i8);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i9);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i10);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i11);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i12);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i13);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i14);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i15);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i16);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i17);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i18);
	init_label(mercury__mercury_to_c__gen_hlds_4_0_i19);
BEGIN_CODE

/* code for predicate 'mercury_to_c__gen_hlds'/4 in mode 0 */
Define_entry(mercury__mercury_to_c__gen_hlds_4_0);
	incr_sp_push_msg(5, "mercury_to_c__gen_hlds");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__mercury_to_c__gen_hlds_4_0_i2,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i3,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const("/* :- module ", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i4,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i5,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const(". */\n\n", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i6,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i7,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const("#include \"imp.h\"\n\n", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i8,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i9,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__mercury_to_c__gen_hlds_4_0_i10,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r1 = string_const("\n", 1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i11,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__mercury_to_c__gen_hlds_4_0_i12,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__mercury_to_c__gen_hlds_4_0_i13,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0),
		mercury__mercury_to_c__gen_hlds_4_0_i14,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i15,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__mercury_to_c__gen_hlds_4_0_i16,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i17,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const("/* :- end_module ", 17);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i18,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__gen_hlds_4_0_i19,
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
Define_label(mercury__mercury_to_c__gen_hlds_4_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__gen_hlds_4_0));
	r2 = (Integer) r1;
	r1 = string_const(". */\n", 5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__mercury_to_c__gen_hlds_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module5)
	init_entry(mercury__mercury_to_c__c_gen_preds_2_6_0);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i5);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i8);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i7);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i10);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i11);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i12);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i13);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i14);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i17);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i18);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i19);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i20);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i21);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i22);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i23);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i24);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i25);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i26);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i27);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i28);
	init_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i1005);
BEGIN_CODE

/* code for predicate 'c_gen_preds_2'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_preds_2_6_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0_i1005);
	incr_sp_push_msg(12, "c_gen_preds_2");
	detstackvar(12) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) tempr1;
	r3 = (Integer) r4;
	r4 = (Integer) tempr1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0_i7);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__mercury_to_c__c_gen_preds_2_6_0,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i7);
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_3_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i10,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(8) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i13,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__mercury_to_c__c_gen_preds_2_6_0,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i17,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/****\n", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_pred_type_7_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_pred_type_7_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i19,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i20,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = ((Integer) 38);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i21,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r3 = (Integer) r2;
	detstackvar(10) = (Integer) r1;
	r1 = ((Integer) 38);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_to_c__common_0);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i22,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i23,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i23);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r9 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_out__write_clauses_10_0);
	call_localret(ENTRY(mercury__hlds_out__write_clauses_10_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i24,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) 38);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i25,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("****/\n", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i26,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i27,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_procs_2_7_0),
		mercury__mercury_to_c__c_gen_preds_2_6_0_i28,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i28);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_preds_2_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__mercury_to_c__c_gen_preds_2_6_0,
		STATIC(mercury__mercury_to_c__c_gen_preds_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_preds_2_6_0_i1005);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module6)
	init_entry(mercury__mercury_to_c__c_gen_type_3_0);
	init_label(mercury__mercury_to_c__c_gen_type_3_0_i1001);
	init_label(mercury__mercury_to_c__c_gen_type_3_0_i9);
	init_label(mercury__mercury_to_c__c_gen_type_3_0_i16);
	init_label(mercury__mercury_to_c__c_gen_type_3_0_i23);
	init_label(mercury__mercury_to_c__c_gen_type_3_0_i1000);
BEGIN_CODE

/* code for predicate 'c_gen_type'/3 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_type_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i1001);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i1001);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("character", 9)) !=0))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i1001);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i1001);
	r1 = string_const("char", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_type_3_0));
	}
Define_label(mercury__mercury_to_c__c_gen_type_3_0_i1001);
	incr_sp_push_msg(1, "c_gen_type");
	detstackvar(1) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i9);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i9);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("int", 3)) !=0))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i9);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i9);
	r1 = string_const("int", 3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_type_3_0));
	}
Define_label(mercury__mercury_to_c__c_gen_type_3_0_i9);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i16);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i16);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r3, ((Integer) 0)), (char *)string_const("string", 6)) !=0))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i16);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i16);
	r1 = string_const("String", 6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_type_3_0));
	}
Define_label(mercury__mercury_to_c__c_gen_type_3_0_i16);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i23);
	if ((tag((Integer) field(mktag(0), (Integer) r1, ((Integer) 0))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i23);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), ((Integer) 0)), (char *)string_const("float", 5)) !=0))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i23);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_type_3_0_i1000);
	r1 = string_const("Float", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_type_3_0));
	}
Define_label(mercury__mercury_to_c__c_gen_type_3_0_i23);
	r1 = string_const("Word", 4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_type_3_0));
	}
Define_label(mercury__mercury_to_c__c_gen_type_3_0_i1000);
	r1 = string_const("Word", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_type_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module7)
	init_entry(mercury__mercury_to_c__c_gen_procs_2_7_0);
	init_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i4);
	init_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i5);
	init_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i6);
	init_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i1002);
BEGIN_CODE

/* code for predicate 'c_gen_procs_2'/7 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_procs_2_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_procs_2_7_0_i1002);
	incr_sp_push_msg(8, "c_gen_procs_2");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__mercury_to_c__c_gen_procs_2_7_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_procs_2_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_procs_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__mercury_to_c__c_gen_procs_2_7_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_procs_2_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_procs_2_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_proc_8_0),
		mercury__mercury_to_c__c_gen_procs_2_7_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_procs_2_7_0));
Define_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_procs_2_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__mercury_to_c__c_gen_procs_2_7_0,
		STATIC(mercury__mercury_to_c__c_gen_procs_2_7_0));
Define_label(mercury__mercury_to_c__c_gen_procs_2_7_0_i1002);
	r1 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module8)
	init_entry(mercury__mercury_to_c__c_gen_proc_8_0);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i2);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i3);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i4);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i5);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i6);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i7);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i8);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i9);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i10);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i11);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i12);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i13);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i14);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i15);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i16);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i17);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i18);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i19);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i20);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i21);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i22);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i23);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i24);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i25);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i26);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i27);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i28);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i29);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i30);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i34);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i35);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i36);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i31);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i37);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i38);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i42);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i43);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i44);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i45);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i46);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i47);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i39);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i51);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i48);
	init_label(mercury__mercury_to_c__c_gen_proc_8_0_i55);
BEGIN_CODE

/* code for predicate 'c_gen_proc'/8 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_proc_8_0);
	incr_sp_push_msg(15, "c_gen_proc");
	detstackvar(15) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	r1 = (Integer) r6;
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i9,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(13) = ((Integer) r1 + ((Integer) 1));
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i10,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("/*\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("** ", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i13,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(14) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i14,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(12);
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_pred_mode_decl_7_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_pred_mode_decl_7_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i15,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i16,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("*/\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i17,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_prototype_5_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i19,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i20,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i21,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("{\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i22,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__quantification__goal_vars_2_0);
	call_localret(ENTRY(mercury__quantification__goal_vars_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i23,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i23);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i24,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__list__delete_elems_3_0);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i25,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(13);
	r5 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i26,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i27,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i28,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i28);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_select_output_vars_4_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i29,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i29);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_init_7_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) detstackvar(13);
	if (((Integer) detstackvar(5) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_proc_8_0_i31);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_predeclare_labels__ua10000_4_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i34,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i35,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("void MNL_0(void) {\n", 19);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i36,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_proc_8_0_i37);
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i31);
	r5 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i37);
	detstackvar(1) = (Integer) r5;
	detstackvar(13) = (Integer) r2;
	detstackvar(5) = (Integer) r6;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i38,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i38);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	if (((Integer) detstackvar(5) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_proc_8_0_i39);
	r1 = ((Integer) detstackvar(13) + ((Integer) 1));
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i42,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i42);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("cont();\n", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i43,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i43);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i44,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i44);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("}\n\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i45,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i45);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i46,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i46);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("MNL_0();\n", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i47,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i47);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i55,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i39);
	if (((Integer) detstackvar(5) != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_proc_8_0_i48);
	r1 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i51,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i51);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("return TRUE;\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i47,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i48);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_proc_8_0_i55,
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
Define_label(mercury__mercury_to_c__c_gen_proc_8_0_i55);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_8_0));
	r2 = (Integer) r1;
	r1 = string_const("}\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_proc_8_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module9)
	init_entry(mercury__mercury_to_c__c_gen_prototype_5_0);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i2);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i3);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i4);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i5);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i6);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i7);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i11);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i8);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i12);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i13);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i14);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i15);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i16);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i23);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i20);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i17);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i26);
	init_label(mercury__mercury_to_c__c_gen_prototype_5_0_i27);
BEGIN_CODE

/* code for predicate 'c_gen_prototype'/5 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_prototype_5_0);
	incr_sp_push_msg(9, "c_gen_prototype");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__pred_info_arg_types_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r1 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	if (((Integer) detstackvar(7) != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_prototype_5_0_i8);
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("bool", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_prototype_5_0_i13);
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i8);
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("void", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	r10 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i13);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	detstackvar(6) = (Integer) r9;
	detstackvar(4) = (Integer) r10;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i14,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i15,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r2 = (Integer) r1;
	r1 = string_const("(", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i16,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	if (((Integer) detstackvar(5) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_prototype_5_0_i17);
	if (((Integer) detstackvar(7) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_prototype_5_0_i20);
	r2 = (Integer) r1;
	r1 = string_const("Cont cont", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i23,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i23);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i20);
	r2 = (Integer) r1;
	r1 = string_const("void", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i23,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i17);
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i26,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_prototype_5_0));
	if (((Integer) detstackvar(7) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_prototype_5_0_i27);
	r2 = (Integer) r1;
	r1 = string_const(", Cont cont", 11);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_prototype_5_0_i23,
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_prototype_5_0_i27);
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_prototype_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module10)
	init_entry(mercury__mercury_to_c__c_gen_proc_name_5_0);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i2);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i3);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i4);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i5);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i6);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i7);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i8);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i9);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i10);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i11);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i12);
	init_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i13);
BEGIN_CODE

/* code for predicate 'c_gen_proc_name'/5 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_proc_name_5_0);
	incr_sp_push_msg(6, "c_gen_proc_name");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__predicate_module_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__predicate_arity_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_arity_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__llds_out__name_mangle_2_0);
	call_localret(ENTRY(mercury__llds_out__name_mangle_2_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const("MP_", 3);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = string_const("_", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = string_const("__", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i9,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i10,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = string_const("_", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = string_const("_", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_proc_name_5_0_i13,
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_proc_name_5_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_proc_name_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(3) % ((Integer) 10000));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_int_3_0);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module11)
	init_entry(mercury__mercury_to_c__c_gen_select_output_vars_4_0);
	init_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i1001);
	init_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i12);
	init_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i14);
	init_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i11);
	init_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i6);
BEGIN_CODE

/* code for predicate 'c_gen_select_output_vars'/4 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_select_output_vars_4_0);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i1001);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i1001);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i1001);
	incr_sp_push_msg(5, "c_gen_select_output_vars");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i6);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i6);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__mode_util__mode_is_output_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__mercury_to_c__c_gen_select_output_vars_4_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_select_output_vars_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i11);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	localcall(mercury__mercury_to_c__c_gen_select_output_vars_4_0,
		LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i14),
		STATIC(mercury__mercury_to_c__c_gen_select_output_vars_4_0));
Define_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_select_output_vars_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i11);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__mercury_to_c__c_gen_select_output_vars_4_0,
		STATIC(mercury__mercury_to_c__c_gen_select_output_vars_4_0));
Define_label(mercury__mercury_to_c__c_gen_select_output_vars_4_0_i6);
	r1 = string_const("c_gen_select_output_vars: length mismatch", 41);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__mercury_to_c__c_gen_select_output_vars_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module12)
	init_entry(mercury__mercury_to_c__c_gen_arg_decls_7_0);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i1001);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i12);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i15);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i17);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i14);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i18);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i19);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i20);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i26);
	init_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i7);
BEGIN_CODE

/* code for predicate 'c_gen_arg_decls'/7 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_arg_decls_7_0);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i1001);
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i1001);
	if (((Integer) r4 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i1001);
	r1 = (Integer) r6;
	proceed();
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i1001);
	incr_sp_push_msg(9, "c_gen_arg_decls");
	detstackvar(9) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i7);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i7);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r2 = (Integer) r6;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_type_3_0),
		mercury__mercury_to_c__c_gen_arg_decls_7_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__mode_util__mode_is_output_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__mercury_to_c__c_gen_arg_decls_7_0_i15,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i14);
	r1 = string_const("* ", 2);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_arg_decls_7_0_i17,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	r4 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i19);
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i14);
	r1 = string_const(" ", 1);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_arg_decls_7_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	r4 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i19);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_var_4_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_var_4_0),
		mercury__mercury_to_c__c_gen_arg_decls_7_0_i20,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	if (((Integer) detstackvar(4) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0_i26);
	r2 = (Integer) r1;
	r1 = string_const(", ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_arg_decls_7_0_i26,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__mercury_to_c__c_gen_arg_decls_7_0,
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
Define_label(mercury__mercury_to_c__c_gen_arg_decls_7_0_i7);
	r1 = string_const("c_gen_arg_decls: length mismatch", 32);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__mercury_to_c__c_gen_arg_decls_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module13)
	init_entry(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i4);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i5);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i6);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i7);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i8);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i9);
	init_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i1002);
BEGIN_CODE

/* code for predicate 'c_gen_local_var_decls_2'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i1002);
	incr_sp_push_msg(7, "c_gen_local_var_decls_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_type_3_0),
		mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_var_4_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_var_4_0),
		mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const(";\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i9,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0,
		STATIC(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_local_var_decls_2_6_0_i1002);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module14)
	init_entry(mercury__mercury_to_c__c_gen_goal_6_0);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i2);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i6);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i7);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i8);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i14);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i15);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i16);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i17);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i18);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i9);
	init_label(mercury__mercury_to_c__c_gen_goal_6_0_i3);
BEGIN_CODE

/* code for predicate 'c_gen_goal'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_goal_6_0);
	incr_sp_push_msg(7, "c_gen_goal");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) 34);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_6_0_i3);
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_file_2_0);
	call_localret(ENTRY(mercury__term__context_file_2_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__term__context_line_2_0);
	call_localret(ENTRY(mercury__term__context_line_2_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	if ((strcmp((char *)(Integer) detstackvar(4), (char *)string_const("", 0)) ==0))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_6_0_i9);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("#line ", 6);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i14,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i15,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	r2 = (Integer) r1;
	r1 = string_const(" \"", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i16,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i17,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	r2 = (Integer) r1;
	r1 = string_const("\"\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_6_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i9);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_6_0_i3);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_6_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module15)
	init_entry(mercury__mercury_to_c__c_gen_goal_2_6_0);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1008);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1007);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1006);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1005);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1004);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1003);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i5);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i6);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i9);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i10);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i11);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i14);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i15);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i16);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i24);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i25);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i26);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i27);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i28);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i29);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i30);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i21);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i34);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i35);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i36);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i37);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i38);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i39);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i40);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i41);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i42);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i43);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i44);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i45);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i47);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i49);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i50);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i51);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i52);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i53);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i54);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i55);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i56);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i57);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i58);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i59);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i60);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i61);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i62);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i63);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i64);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i65);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i66);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i67);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i68);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i72);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i69);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i73);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i74);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i75);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i76);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i78);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1002);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i80);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i83);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i84);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i85);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i86);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i87);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i91);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i88);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i95);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i92);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i97);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i98);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i99);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i100);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i109);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i104);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i110);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i111);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i112);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i113);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i101);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i118);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i115);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i82);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i123);
	init_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1000);
BEGIN_CODE

/* code for predicate 'c_gen_goal_2'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_goal_2_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1002);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1008) AND
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1000) AND
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1007) AND
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1006) AND
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1005) AND
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1004) AND
		LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i1003));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1008);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i5);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1007);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i9);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1006);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i34);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1005);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i47);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1004);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i49);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1003);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i78);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i5);
	r1 = ((Integer) 7);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i9);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_get_code_model_2_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i10,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i11);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i15);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i11);
	r1 = ((Integer) 5);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i14,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i15);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i16);
	r5 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 1));
	if (((Integer) r5 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i16);
	r1 = ((Integer) 12);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i16);
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i21);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r4;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i24,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* disjunction */\n", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i25,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_new_label_func_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i26,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) r2;
	r5 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_disj_7_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i27,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i28,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i28);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i29,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i29);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* end disjunction */\n", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i21);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_failure_5_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i34);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_new_label_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i35,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_get_failconts_2_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i36,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	r2 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__stack__push_3_0);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i37,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i37);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_set_failconts_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i38,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i38);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i39,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i39);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* not */\n", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i40,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i40);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) detstackvar(1) + ((Integer) 1));
	r3 = (Integer) detstackvar(3);
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i41,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i41);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_set_failconts_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i42,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i42);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_failure_5_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i43,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i43);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) detstackvar(1) + ((Integer) 1));
	call_localret(STATIC(mercury__mercury_to_c__c_gen_label_4_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i44,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i44);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i45,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i45);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* end not */\n", 14);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i47);
	r1 = ((Integer) 8);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i49);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_new_label_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i50,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i50);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_get_failconts_2_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i51,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i51);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__stack__push_3_0);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i52,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i52);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_set_failconts_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i53,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i53);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i54,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i54);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* if */\n", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i55,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i55);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) detstackvar(1) + ((Integer) 1));
	r3 = (Integer) detstackvar(3);
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i56,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i56);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_set_failconts_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i57,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i57);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i58,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i58);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* then */\n", 11);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i59,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i59);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i60,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i60);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i61,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i61);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_new_label_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i62,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i62);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("goto ML_", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i63,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i63);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i64,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i64);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const(";\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i65,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i65);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_label_4_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i66,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i66);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i67,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i67);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* else */\n", 11);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i68,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i68);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i69);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i69);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i72,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i72);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r1;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i74);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i69);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i73,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i73);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r1;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i74);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_label_4_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i75,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i75);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i76,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i76);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("/* end if */\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i78);
	r1 = ((Integer) 4);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1002);
	incr_sp_push_msg(9, "c_gen_goal_2");
	detstackvar(9) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i80);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_conj_6_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i80);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i82);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_get_module_info_2_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i83,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i83);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	detstackvar(7) = (Integer) r1;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i84,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i84);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r1 = (Integer) r2;
	detstackvar(8) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i85,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i85);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i86,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i86);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i87,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i87);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	if (((Integer) detstackvar(8) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i88);
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_info_new_label_func_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i91,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i91);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r9 = (Integer) r1;
	r10 = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i97);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i88);
	if (((Integer) detstackvar(8) != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i92);
	r2 = (Integer) r1;
	r1 = string_const("if (!", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i95,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i95);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r5 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(3);
	r9 = ((Integer) 0);
	r10 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i97);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i92);
	r5 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(3);
	r9 = ((Integer) 0);
	r10 = (Integer) detstackvar(2);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i97);
	detstackvar(1) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	detstackvar(2) = (Integer) r10;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_proc_name_5_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i98,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i98);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const("(", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i99,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i99);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i100,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i100);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	if (((Integer) detstackvar(8) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i101);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i104);
	detstackvar(3) = (Integer) r1;
	r1 = string_const(", ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i109,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i109);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i110);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i104);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i110);
	detstackvar(1) = (Integer) r3;
	detstackvar(4) = (Integer) r1;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_write_label_func__ua10000_4_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i111,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i111);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = string_const(");\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i112,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i112);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_failure_5_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i113,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i113);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_insert_label_func__ua10000_5_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i101);
	if (((Integer) detstackvar(8) != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0_i115);
	detstackvar(3) = (Integer) r1;
	r1 = string_const("))\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i118,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i118);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_failure_5_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i115);
	detstackvar(2) = (Integer) r1;
	r1 = string_const(");\n", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i82);
	detstackvar(1) = (Integer) r4;
	r1 = string_const("mercury_to_c: higher_order_call not implemented", 47);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mercury_to_c__c_gen_goal_2_6_0_i123,
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i123);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_goal_2_6_0));
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_goal_2_6_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	tailcall(STATIC(mercury__mercury_to_c__c_gen_unification_6_0),
		STATIC(mercury__mercury_to_c__c_gen_goal_2_6_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module16)
	init_entry(mercury__mercury_to_c__c_gen_unification_6_0);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i6);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i7);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i8);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i9);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i10);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i11);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i5);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i13);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i1000);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i14);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i16);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i18);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i19);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i20);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i21);
	init_label(mercury__mercury_to_c__c_gen_unification_6_0_i22);
BEGIN_CODE

/* code for predicate 'c_gen_unification'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_unification_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_unification_6_0_i1000);
	incr_sp_push_msg(5, "c_gen_unification");
	detstackvar(5) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_unification_6_0_i5);
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r4;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r2 = (Integer) r1;
	r1 = string_const("if (", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_var_5_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const(" == ", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i9,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_var_5_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i10,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const(")\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r3 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + ((Integer) 1));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__mercury_to_c__c_gen_failure_5_0),
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i5);
	detstackvar(1) = (Integer) r3;
	r1 = ((Integer) 3);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i13,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i1000);
	incr_sp_push_msg(5, "c_gen_unification");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_unification_6_0_i14);
	detstackvar(1) = (Integer) r3;
	r1 = ((Integer) 1);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i13,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i14);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_unification_6_0_i16);
	detstackvar(1) = (Integer) r3;
	r1 = ((Integer) 2);
	call_localret(STATIC(mercury__mercury_to_c__sorry_1_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i13,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i16);
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	r2 = (Integer) r4;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_var_5_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i19,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = string_const(" = ", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i20,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_var_5_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i21,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = string_const(";\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_unification_6_0_i22,
		STATIC(mercury__mercury_to_c__c_gen_unification_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_unification_6_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_unification_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module17)
	init_entry(mercury__mercury_to_c__c_gen_arg_list_6_0);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i1001);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i12);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i16);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i18);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i11);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i21);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i25);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i20);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i29);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i30);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i31);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i34);
	init_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i6);
BEGIN_CODE

/* code for predicate 'c_gen_arg_list'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_arg_list_6_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i1001);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i1001);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i1001);
	incr_sp_push_msg(10, "c_gen_arg_list");
	detstackvar(10) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i6);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i6);
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) r3;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	detstackvar(9) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i12,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i11);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mode_util__mode_is_output_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i16,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i11);
	r1 = ((Integer) 42);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i29);
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i11);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mode_util__mode_is_output_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i21,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i20);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i25,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i20);
	r1 = ((Integer) 38);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i20);
	r4 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(2);
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i29);
	detstackvar(1) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_var_4_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_var_4_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i30,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i30);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	if (((Integer) detstackvar(4) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0_i31);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__mercury_to_c__c_gen_arg_list_6_0,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i31);
	r2 = (Integer) r1;
	r1 = string_const(", ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_arg_list_6_0_i34,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_arg_list_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__mercury_to_c__c_gen_arg_list_6_0,
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
Define_label(mercury__mercury_to_c__c_gen_arg_list_6_0_i6);
	r1 = string_const("c_gen_arg_list: length mismatch", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__mercury_to_c__c_gen_arg_list_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module18)
	init_entry(mercury__mercury_to_c__c_gen_var_5_0);
	init_label(mercury__mercury_to_c__c_gen_var_5_0_i4);
	init_label(mercury__mercury_to_c__c_gen_var_5_0_i6);
	init_label(mercury__mercury_to_c__c_gen_var_5_0_i3);
	init_label(mercury__mercury_to_c__c_gen_var_5_0_i7);
	init_label(mercury__mercury_to_c__c_gen_var_5_0_i8);
BEGIN_CODE

/* code for predicate 'c_gen_var'/5 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_var_5_0);
	incr_sp_push_msg(5, "c_gen_var");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__mercury_to_c__c_gen_var_5_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_var_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_var_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_var_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_var_5_0_i3);
	r1 = ((Integer) 42);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_c__c_gen_var_5_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_var_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_var_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_var_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__mercury_to_c__c_gen_var_5_0_i7);
Define_label(mercury__mercury_to_c__c_gen_var_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__mercury_to_c__c_gen_var_5_0_i7);
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__mercury_to_mercury__mercury_output_var_4_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_var_4_0),
		mercury__mercury_to_c__c_gen_var_5_0_i8,
		STATIC(mercury__mercury_to_c__c_gen_var_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_var_5_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_var_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module19)
	init_entry(mercury__mercury_to_c__sorry_1_0);
	init_label(mercury__mercury_to_c__sorry_1_0_i2);
	init_label(mercury__mercury_to_c__sorry_1_0_i3);
BEGIN_CODE

/* code for predicate 'sorry'/1 in mode 0 */
Define_static(mercury__mercury_to_c__sorry_1_0);
	r3 = (Integer) r1;
	r1 = string_const("Sorry, not implemented [%d]", 27);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	incr_sp_push_msg(1, "sorry");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__mercury_to_c__sorry_1_0_i2,
		STATIC(mercury__mercury_to_c__sorry_1_0));
	}
	}
Define_label(mercury__mercury_to_c__sorry_1_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__sorry_1_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mercury_to_c__sorry_1_0_i3,
		STATIC(mercury__mercury_to_c__sorry_1_0));
	}
Define_label(mercury__mercury_to_c__sorry_1_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__sorry_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module20)
	init_entry(mercury__mercury_to_c__c_gen_conj_6_0);
	init_label(mercury__mercury_to_c__c_gen_conj_6_0_i4);
	init_label(mercury__mercury_to_c__c_gen_conj_6_0_i1002);
BEGIN_CODE

/* code for predicate 'c_gen_conj'/6 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_conj_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_conj_6_0_i1002);
	incr_sp_push_msg(3, "c_gen_conj");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_conj_6_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_conj_6_0));
Define_label(mercury__mercury_to_c__c_gen_conj_6_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_conj_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__mercury_to_c__c_gen_conj_6_0,
		STATIC(mercury__mercury_to_c__c_gen_conj_6_0));
Define_label(mercury__mercury_to_c__c_gen_conj_6_0_i1002);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module21)
	init_entry(mercury__mercury_to_c__c_gen_disj_7_0);
	init_label(mercury__mercury_to_c__c_gen_disj_7_0_i4);
	init_label(mercury__mercury_to_c__c_gen_disj_7_0_i5);
	init_label(mercury__mercury_to_c__c_gen_disj_7_0_i6);
	init_label(mercury__mercury_to_c__c_gen_disj_7_0_i7);
	init_label(mercury__mercury_to_c__c_gen_disj_7_0_i1002);
BEGIN_CODE

/* code for predicate 'c_gen_disj'/7 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_disj_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_disj_7_0_i1002);
	incr_sp_push_msg(5, "c_gen_disj");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_goal_6_0),
		mercury__mercury_to_c__c_gen_disj_7_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_disj_7_0));
Define_label(mercury__mercury_to_c__c_gen_disj_7_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_disj_7_0));
	detstackvar(4) = (Integer) r1;
	r1 = string_const("MNL_", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_disj_7_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_disj_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_disj_7_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_disj_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_disj_7_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_disj_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_disj_7_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_disj_7_0));
	r2 = (Integer) r1;
	r1 = string_const("();\n", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_disj_7_0_i7,
		STATIC(mercury__mercury_to_c__c_gen_disj_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_disj_7_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_disj_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__mercury_to_c__c_gen_disj_7_0,
		STATIC(mercury__mercury_to_c__c_gen_disj_7_0));
Define_label(mercury__mercury_to_c__c_gen_disj_7_0_i1002);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module22)
	init_entry(mercury__mercury_to_c__c_gen_indent_3_0);
	init_label(mercury__mercury_to_c__c_gen_indent_3_0_i1000);
	init_label(mercury__mercury_to_c__c_gen_indent_3_0_i5);
BEGIN_CODE

/* code for predicate 'c_gen_indent'/3 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_indent_3_0);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_indent_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__mercury_to_c__c_gen_indent_3_0_i1000);
	incr_sp_push_msg(2, "c_gen_indent");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 9);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_to_c__c_gen_indent_3_0_i5,
		STATIC(mercury__mercury_to_c__c_gen_indent_3_0));
	}
Define_label(mercury__mercury_to_c__c_gen_indent_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_indent_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) - ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__mercury_to_c__c_gen_indent_3_0,
		STATIC(mercury__mercury_to_c__c_gen_indent_3_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module23)
	init_entry(mercury__mercury_to_c__c_gen_label_4_0);
	init_label(mercury__mercury_to_c__c_gen_label_4_0_i2);
	init_label(mercury__mercury_to_c__c_gen_label_4_0_i3);
	init_label(mercury__mercury_to_c__c_gen_label_4_0_i4);
BEGIN_CODE

/* code for predicate 'c_gen_label'/4 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_label_4_0);
	incr_sp_push_msg(2, "c_gen_label");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) r2 - ((Integer) 1));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_label_4_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_label_4_0));
Define_label(mercury__mercury_to_c__c_gen_label_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_label_4_0));
	r2 = (Integer) r1;
	r1 = string_const("ML_", 3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_label_4_0_i3,
		STATIC(mercury__mercury_to_c__c_gen_label_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_label_4_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_label_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_label_4_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_label_4_0));
	}
Define_label(mercury__mercury_to_c__c_gen_label_4_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_label_4_0));
	r2 = (Integer) r1;
	r1 = string_const(":\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__mercury_to_c__c_gen_label_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module24)
	init_entry(mercury__mercury_to_c__c_gen_failure_5_0);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i4);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i6);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i11);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i10);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i9);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i14);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i15);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i13);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i17);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i18);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i3);
	init_label(mercury__mercury_to_c__c_gen_failure_5_0_i20);
BEGIN_CODE

/* code for predicate 'c_gen_failure'/5 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_failure_5_0);
	incr_sp_push_msg(4, "c_gen_failure");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0;
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	{
	Declare_entry(mercury__stack__top_2_0);
	call_localret(ENTRY(mercury__stack__top_2_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i4,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_failure_5_0_i3);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__mercury_to_c__c_gen_indent_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = tag((Integer) r2);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_failure_5_0_i9);
	r3 = unmkbody((Integer) r2);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_failure_5_0_i10);
	r2 = (Integer) r1;
	r1 = string_const("return FALSE;\n", 14);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i10);
	r2 = (Integer) r1;
	r1 = string_const("return;\n", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i9);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_failure_5_0_i13);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r1;
	r1 = string_const("goto ML_", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i14,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i15,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) r1;
	r1 = string_const(";\n", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i13);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r1;
	r1 = string_const("MNL_", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i17,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i18,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) r1;
	r1 = string_const("();\n", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i11,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i3);
	r1 = string_const("c_gen_failure: missing failure continuation", 43);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mercury_to_c__c_gen_failure_5_0_i20,
		STATIC(mercury__mercury_to_c__c_gen_failure_5_0));
	}
Define_label(mercury__mercury_to_c__c_gen_failure_5_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_failure_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module25)
	init_entry(mercury__mercury_to_c__c_gen_info_init_7_0);
	init_label(mercury__mercury_to_c__c_gen_info_init_7_0_i2);
	init_label(mercury__mercury_to_c__c_gen_info_init_7_0_i6);
	init_label(mercury__mercury_to_c__c_gen_info_init_7_0_i3);
	init_label(mercury__mercury_to_c__c_gen_info_init_7_0_i7);
BEGIN_CODE

/* code for predicate 'c_gen_info_init'/7 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_init_7_0);
	incr_sp_push_msg(7, "c_gen_info_init");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0;
	{
	Declare_entry(mercury__stack__init_1_0);
	call_localret(ENTRY(mercury__stack__init_1_0),
		mercury__mercury_to_c__c_gen_info_init_7_0_i2,
		STATIC(mercury__mercury_to_c__c_gen_info_init_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_info_init_7_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_info_init_7_0));
	if (((Integer) detstackvar(5) != ((Integer) 2)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_info_init_7_0_i3);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	{
	Declare_entry(mercury__stack__push_3_0);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__mercury_to_c__c_gen_info_init_7_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_info_init_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_info_init_7_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_to_c__c_gen_info_init_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__mercury_to_c__c_gen_info_init_7_0_i3);
	if (((Integer) detstackvar(5) != ((Integer) 1)))
		GOTO_LABEL(mercury__mercury_to_c__c_gen_info_init_7_0_i7);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_to_c__base_type_info_c_failure_cont_0;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__stack__push_3_0);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__mercury_to_c__c_gen_info_init_7_0_i6,
		STATIC(mercury__mercury_to_c__c_gen_info_init_7_0));
	}
Define_label(mercury__mercury_to_c__c_gen_info_init_7_0_i7);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module26)
	init_entry(mercury__mercury_to_c__c_gen_info_get_code_model_2_0);
BEGIN_CODE

/* code for predicate 'c_gen_info_get_code_model'/2 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_get_code_model_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module27)
	init_entry(mercury__mercury_to_c__c_gen_info_get_module_info_2_0);
BEGIN_CODE

/* code for predicate 'c_gen_info_get_module_info'/2 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_get_module_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module28)
	init_entry(mercury__mercury_to_c__c_gen_info_get_failconts_2_0);
BEGIN_CODE

/* code for predicate 'c_gen_info_get_failconts'/2 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_get_failconts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module29)
	init_entry(mercury__mercury_to_c__c_gen_info_set_failconts_3_0);
BEGIN_CODE

/* code for predicate 'c_gen_info_set_failconts'/3 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_set_failconts_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module30)
	init_entry(mercury__mercury_to_c__c_gen_info_new_label_3_0);
BEGIN_CODE

/* code for predicate 'c_gen_info_new_label'/3 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_new_label_3_0);
	tag_incr_hp(r2, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) field(mktag(0), (Integer) r1, ((Integer) 7)) + ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) r1;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module31)
	init_entry(mercury__mercury_to_c__c_gen_info_new_label_func_3_0);
BEGIN_CODE

/* code for predicate 'c_gen_info_new_label_func'/3 in mode 0 */
Define_static(mercury__mercury_to_c__c_gen_info_new_label_func_3_0);
	tag_incr_hp(r2, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r2, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	field(mktag(0), (Integer) r2, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = ((Integer) field(mktag(0), (Integer) r1, ((Integer) 8)) + ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 8)) = (Integer) r1;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module32)
	init_entry(mercury____Unify___mercury_to_c__c_failure_cont_0_0);
	init_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i5);
	init_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i4);
	init_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i8);
	init_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i2);
	init_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___mercury_to_c__c_failure_cont_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i4);
	if ((unmkbody((Integer) r1) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i5);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i5);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
Define_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_to_c__c_failure_cont_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module33)
	init_entry(mercury____Index___mercury_to_c__c_failure_cont_0_0);
	init_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i5);
	init_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i4);
	init_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___mercury_to_c__c_failure_cont_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___mercury_to_c__c_failure_cont_0_0_i4);
	if ((unmkbody((Integer) r1) != ((Integer) 0)))
		GOTO_LABEL(mercury____Index___mercury_to_c__c_failure_cont_0_0_i5);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___mercury_to_c__c_failure_cont_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___mercury_to_c__c_failure_cont_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_to_c_module34)
	init_entry(mercury____Compare___mercury_to_c__c_failure_cont_0_0);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i2);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i3);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i4);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i6);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i13);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i12);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i16);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i9);
	init_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___mercury_to_c__c_failure_cont_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury____Index___mercury_to_c__c_failure_cont_0_0),
		mercury____Compare___mercury_to_c__c_failure_cont_0_0_i2,
		STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury____Index___mercury_to_c__c_failure_cont_0_0),
		mercury____Compare___mercury_to_c__c_failure_cont_0_0_i3,
		STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i12);
	if ((unmkbody((Integer) r1) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i13);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i13);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i16);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
	}
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i16);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
	}
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
	}
Define_label(mercury____Compare___mercury_to_c__c_failure_cont_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___mercury_to_c__c_failure_cont_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__mercury_to_c_bunch_0(void)
{
	mercury__mercury_to_c_module0();
	mercury__mercury_to_c_module1();
	mercury__mercury_to_c_module2();
	mercury__mercury_to_c_module3();
	mercury__mercury_to_c_module4();
	mercury__mercury_to_c_module5();
	mercury__mercury_to_c_module6();
	mercury__mercury_to_c_module7();
	mercury__mercury_to_c_module8();
	mercury__mercury_to_c_module9();
	mercury__mercury_to_c_module10();
	mercury__mercury_to_c_module11();
	mercury__mercury_to_c_module12();
	mercury__mercury_to_c_module13();
	mercury__mercury_to_c_module14();
	mercury__mercury_to_c_module15();
	mercury__mercury_to_c_module16();
	mercury__mercury_to_c_module17();
	mercury__mercury_to_c_module18();
	mercury__mercury_to_c_module19();
	mercury__mercury_to_c_module20();
	mercury__mercury_to_c_module21();
	mercury__mercury_to_c_module22();
	mercury__mercury_to_c_module23();
	mercury__mercury_to_c_module24();
	mercury__mercury_to_c_module25();
	mercury__mercury_to_c_module26();
	mercury__mercury_to_c_module27();
	mercury__mercury_to_c_module28();
	mercury__mercury_to_c_module29();
	mercury__mercury_to_c_module30();
	mercury__mercury_to_c_module31();
	mercury__mercury_to_c_module32();
	mercury__mercury_to_c_module33();
	mercury__mercury_to_c_module34();
}

#endif

void mercury__mercury_to_c__init(void); /* suppress gcc warning */
void mercury__mercury_to_c__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__mercury_to_c_bunch_0();
#endif
}
