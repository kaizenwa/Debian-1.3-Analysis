/*
** Automatically generated from `switch_detection.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__switch_detection__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__switch_detection__detect_switches_4_0);
Declare_label(mercury__switch_detection__detect_switches_4_0_i2);
Define_extern_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i2);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i3);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i7);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i8);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i9);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i10);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i11);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i12);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i13);
Declare_static(mercury__switch_detection__detect_switches_in_preds_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i7);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
Declare_static(mercury__switch_detection__detect_switches_in_procs_4_0);
Declare_label(mercury__switch_detection__detect_switches_in_procs_4_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_procs_4_0_i1002);
Declare_static(mercury__switch_detection__detect_switches_in_goal_5_0);
Declare_static(mercury__switch_detection__detect_switches_in_goal_1_6_0);
Declare_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i2);
Declare_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_goal_2_6_0);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1034);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1033);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1032);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1031);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1030);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1029);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i7);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i12);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i13);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i14);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i15);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1025);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i21);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i22);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i30);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i31);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i32);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1028);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1020);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
Declare_static(mercury__switch_detection__detect_switches_in_disj_10_0);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i7);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i9);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i10);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i14);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i24);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i25);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i26);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i27);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i28);
Declare_static(mercury__switch_detection__select_best_switch_3_0);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i6);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i7);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i5);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i1003);
Declare_static(mercury__switch_detection__detect_sub_switches_in_disj_5_0);
Declare_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4);
Declare_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5);
Declare_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i1002);
Declare_static(mercury__switch_detection__detect_switches_in_cases_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_cases_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_cases_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_cases_5_0_i1003);
Declare_static(mercury__switch_detection__detect_switches_in_conj_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i1002);
Declare_static(mercury__switch_detection__partition_disj_trial_6_0);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i4);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i5);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i6);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i9);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i12);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i11);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i14);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i15);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i8);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i1006);
Declare_static(mercury__switch_detection__find_bind_var_for_switch_6_0);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i7);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i8);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i11);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i4);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i19);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i21);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i23);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i17);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i16);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i27);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i26);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i29);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i30);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i1050);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i1026);
Declare_static(mercury__switch_detection__cases_to_switch_8_0);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i2);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i5);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i7);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i8);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i9);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i12);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i11);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i4);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i15);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i25);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i20);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i19);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i26);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i28);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i29);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i31);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i33);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i34);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i18);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i17);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i37);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i38);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i39);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i41);
Declare_label(mercury__switch_detection__cases_to_switch_8_0_i42);
Declare_static(mercury__switch_detection__delete_unreachable_cases_3_0);
Declare_label(mercury__switch_detection__delete_unreachable_cases_3_0_i8);
Declare_label(mercury__switch_detection__delete_unreachable_cases_3_0_i10);
Declare_label(mercury__switch_detection__delete_unreachable_cases_3_0_i7);
Declare_label(mercury__switch_detection__delete_unreachable_cases_3_0_i13);
Declare_label(mercury__switch_detection__delete_unreachable_cases_3_0_i12);
Declare_label(mercury__switch_detection__delete_unreachable_cases_3_0_i1006);
Declare_static(mercury__switch_detection__functors_to_cons_ids_2_0);
Declare_label(mercury__switch_detection__functors_to_cons_ids_2_0_i3);
Declare_label(mercury__switch_detection__functors_to_cons_ids_2_0_i4);
Declare_label(mercury__switch_detection__functors_to_cons_ids_2_0_i1);
Declare_static(mercury__switch_detection__fix_case_list_3_0);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i4);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i5);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i1003);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_switch_detection__base_type_layout_again_0[];
Word * mercury_data_switch_detection__base_type_info_again_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_switch_detection__base_type_layout_again_0
};

extern Word * mercury_data_switch_detection__base_type_layout_cases_0[];
Word * mercury_data_switch_detection__base_type_info_cases_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_switch_detection__base_type_layout_cases_0
};

extern Word * mercury_data_switch_detection__base_type_layout_sorted_case_list_0[];
Word * mercury_data_switch_detection__base_type_info_sorted_case_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_switch_detection__base_type_layout_sorted_case_list_0
};

extern Word * mercury_data_switch_detection__common_5[];
Word * mercury_data_switch_detection__base_type_layout_sorted_case_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_5),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_5)
};

extern Word * mercury_data_switch_detection__common_7[];
Word * mercury_data_switch_detection__base_type_layout_cases_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_7),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_switch_detection__common_7)
};

extern Word * mercury_data_switch_detection__common_9[];
Word * mercury_data_switch_detection__base_type_layout_again_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_switch_detection__common_9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_switch_detection__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_switch_detection__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_0)
};

extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
Word * mercury_data_switch_detection__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1)
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_switch_detection__common_3[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_switch_detection__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_2)
};

Word * mercury_data_switch_detection__common_5[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_4)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_switch_detection__common_6[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_hlds_data__base_type_info_cons_id_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1)
};

Word * mercury_data_switch_detection__common_7[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_6)
};

extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_switch_detection__common_8[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_switch_detection__common_9[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_4),
	(Word *) string_const("again", 5)
};

BEGIN_MODULE(mercury__switch_detection_module0)
	init_entry(mercury__switch_detection__detect_switches_4_0);
	init_label(mercury__switch_detection__detect_switches_4_0_i2);
BEGIN_CODE

/* code for predicate 'detect_switches'/4 in mode 0 */
Define_entry(mercury__switch_detection__detect_switches_4_0);
	incr_sp_push_msg(3, "detect_switches");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__switch_detection__detect_switches_4_0_i2,
		ENTRY(mercury__switch_detection__detect_switches_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_4_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__switch_detection__detect_switches_in_preds_5_0),
		ENTRY(mercury__switch_detection__detect_switches_4_0));
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module1)
	init_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i2);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i3);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i7);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i8);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i9);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i10);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i11);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i12);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i13);
BEGIN_CODE

/* code for predicate 'detect_switches_in_proc'/4 in mode 0 */
Define_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
	incr_sp_push_msg(10, "detect_switches_in_proc");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i2,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r3 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__switch_detection__detect_switches_in_proc_4_0_i3,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i3);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i4,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r3 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__switch_detection__detect_switches_in_proc_4_0_i5,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i6,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i7,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i8,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i9,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i10,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__switch_detection__detect_switches_in_proc_4_0_i11,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i12,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__switch_detection__detect_switches_in_proc_4_0_i13,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module2)
	init_entry(mercury__switch_detection__detect_switches_in_preds_5_0);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i7);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
BEGIN_CODE

/* code for predicate 'detect_switches_in_preds'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_preds_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
	incr_sp_push_msg(5, "detect_switches_in_preds");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__switch_detection__detect_switches_in_preds_5_0_i5,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i6,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_procs_4_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i7,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__switch_detection__detect_switches_in_preds_5_0,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module3)
	init_entry(mercury__switch_detection__detect_switches_in_procs_4_0);
	init_label(mercury__switch_detection__detect_switches_in_procs_4_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_procs_4_0_i1002);
BEGIN_CODE

/* code for predicate 'detect_switches_in_procs'/4 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_procs_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_procs_4_0_i1002);
	incr_sp_push_msg(3, "detect_switches_in_procs");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__switch_detection__detect_switches_in_proc_4_0),
		mercury__switch_detection__detect_switches_in_procs_4_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_procs_4_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_procs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_procs_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__switch_detection__detect_switches_in_procs_4_0,
		STATIC(mercury__switch_detection__detect_switches_in_procs_4_0));
Define_label(mercury__switch_detection__detect_switches_in_procs_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module4)
	init_entry(mercury__switch_detection__detect_switches_in_goal_5_0);
BEGIN_CODE

/* code for predicate 'detect_switches_in_goal'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_goal_5_0);
	tailcall(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		STATIC(mercury__switch_detection__detect_switches_in_goal_5_0));
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module5)
	init_entry(mercury__switch_detection__detect_switches_in_goal_1_6_0);
	init_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i2);
	init_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_goal_1'/6 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_goal_1_6_0);
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	incr_sp_push_msg(4, "detect_switches_in_goal_1");
	detstackvar(4) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0),
		mercury__switch_detection__detect_switches_in_goal_1_6_0_i2,
		STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_1_6_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r2 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__det_util__update_instmap_3_0);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__switch_detection__detect_switches_in_goal_1_6_0_i3,
		STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i3);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_1_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module6)
	init_entry(mercury__switch_detection__detect_switches_in_goal_2_6_0);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1034);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1033);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1032);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1031);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1030);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1029);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i7);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i12);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i13);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i14);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i15);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1025);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i21);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i22);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i30);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i31);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i32);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1028);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1020);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
BEGIN_CODE

/* code for predicate 'detect_switches_in_goal_2'/6 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_goal_2_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1028);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1034) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1033) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1032) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1031) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1030) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1029) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1020));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1034);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1033);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i7);
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1032);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1031);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1030);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1029);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i6,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i7);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r8 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r9 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) r8) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1025);
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) field(mktag(2), (Integer) r8, ((Integer) 2));
	detstackvar(12) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 3));
	detstackvar(10) = (Integer) r1;
	detstackvar(9) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r8, ((Integer) 0));
	r2 = (Integer) r5;
	detstackvar(1) = (Integer) r9;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r6;
	{
	Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i11,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_prog_data__base_type_info_inst_0[];
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	}
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i12,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	{
	Declare_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_from_assoc_list_2_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i13,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i14,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i15,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(2), ((Integer) 5));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(10);
	field(mktag(2), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(11);
	field(mktag(2), (Integer) r3, ((Integer) 4)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1025);
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r9;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r8;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r7;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r6;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r7 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r6;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i21,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i21);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i22,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i22);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) r1;
	r8 = (Integer) detstackvar(4);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	tailcall(STATIC(mercury__switch_detection__detect_switches_in_disj_10_0),
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i26,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i28,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i30,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i30);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i31,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i31);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i32,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i32);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1028);
	incr_sp_push_msg(13, "detect_switches_in_goal_2");
	detstackvar(13) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_conj_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i35,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1020);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module7)
	init_entry(mercury__switch_detection__detect_switches_in_disj_10_0);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i7);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i9);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i10);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i14);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i24);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i25);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i26);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i27);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i28);
BEGIN_CODE

/* code for predicate 'detect_switches_in_disj'/10 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_disj_10_0);
	incr_sp_push_msg(12, "detect_switches_in_disj");
	detstackvar(12) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(9) = (Integer) tempr1;
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r5;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i6,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__mode_util__inst_is_bound_2_0);
	call_localret(ENTRY(mercury__mode_util__inst_is_bound_2_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i7,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i9,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__switch_detection__partition_disj_trial_6_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i10,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r3 = (Integer) r2;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1);
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i11,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	if (((Integer) detstackvar(11) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i14);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__switch_detection__cases_to_switch_8_0),
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i14);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r10;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__switch_detection__detect_switches_in_disj_10_0,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__switch_detection__detect_switches_in_disj_10_0,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
	if (((Integer) r9 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	r1 = (Integer) field(mktag(1), (Integer) r9, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) r9, ((Integer) 0));
	call_localret(STATIC(mercury__switch_detection__select_best_switch_3_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i24,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i24);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__switch_detection__cases_to_switch_8_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i25,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i25);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) r1;
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__switch_detection__detect_switches_in_disj_10_0,
		LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i26),
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i26);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_goal__goal_to_disj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_disj_list_2_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i27,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i27);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) r2;
	r2 = (Integer) r5;
	r3 = (Integer) r6;
	r4 = (Integer) r8;
	call_localret(STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i28,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i28);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module8)
	init_entry(mercury__switch_detection__select_best_switch_3_0);
	init_label(mercury__switch_detection__select_best_switch_3_0_i6);
	init_label(mercury__switch_detection__select_best_switch_3_0_i7);
	init_label(mercury__switch_detection__select_best_switch_3_0_i5);
	init_label(mercury__switch_detection__select_best_switch_3_0_i1003);
BEGIN_CODE

/* code for predicate 'select_best_switch'/3 in mode 0 */
Define_static(mercury__switch_detection__select_best_switch_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__select_best_switch_3_0_i1003);
	incr_sp_push_msg(5, "select_best_switch");
	detstackvar(5) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_detection__select_best_switch_3_0_i6,
		STATIC(mercury__switch_detection__select_best_switch_3_0));
	}
Define_label(mercury__switch_detection__select_best_switch_3_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__select_best_switch_3_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_detection__select_best_switch_3_0_i7,
		STATIC(mercury__switch_detection__select_best_switch_3_0));
	}
Define_label(mercury__switch_detection__select_best_switch_3_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__select_best_switch_3_0));
	if (((Integer) detstackvar(4) >= (Integer) r1))
		GOTO_LABEL(mercury__switch_detection__select_best_switch_3_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__switch_detection__select_best_switch_3_0,
		STATIC(mercury__switch_detection__select_best_switch_3_0));
Define_label(mercury__switch_detection__select_best_switch_3_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__switch_detection__select_best_switch_3_0,
		STATIC(mercury__switch_detection__select_best_switch_3_0));
Define_label(mercury__switch_detection__select_best_switch_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module9)
	init_entry(mercury__switch_detection__detect_sub_switches_in_disj_5_0);
	init_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4);
	init_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5);
	init_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i1002);
BEGIN_CODE

/* code for predicate 'detect_sub_switches_in_disj'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_sub_switches_in_disj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i1002);
	incr_sp_push_msg(5, "detect_sub_switches_in_disj");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4,
		STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
Define_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__switch_detection__detect_sub_switches_in_disj_5_0,
		LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5),
		STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
Define_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module10)
	init_entry(mercury__switch_detection__detect_switches_in_cases_5_0);
	init_label(mercury__switch_detection__detect_switches_in_cases_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_cases_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_cases_5_0_i1003);
BEGIN_CODE

/* code for predicate 'detect_switches_in_cases'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_cases_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_cases_5_0_i1003);
	incr_sp_push_msg(6, "detect_switches_in_cases");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_cases_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_cases_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_cases_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_cases_5_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	localcall(mercury__switch_detection__detect_switches_in_cases_5_0,
		LABEL(mercury__switch_detection__detect_switches_in_cases_5_0_i5),
		STATIC(mercury__switch_detection__detect_switches_in_cases_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_cases_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_cases_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_cases_5_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module11)
	init_entry(mercury__switch_detection__detect_switches_in_conj_5_0);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i1002);
BEGIN_CODE

/* code for predicate 'detect_switches_in_conj'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_conj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_conj_5_0_i1002);
	incr_sp_push_msg(4, "detect_switches_in_conj");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_conj_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_conj_5_0));
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_conj_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__switch_detection__detect_switches_in_conj_5_0,
		LABEL(mercury__switch_detection__detect_switches_in_conj_5_0_i5),
		STATIC(mercury__switch_detection__detect_switches_in_conj_5_0));
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_conj_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module12)
	init_entry(mercury__switch_detection__partition_disj_trial_6_0);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i4);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i5);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i6);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i9);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i12);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i11);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i14);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i15);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i8);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i1006);
BEGIN_CODE

/* code for predicate 'partition_disj_trial'/6 in mode 0 */
Define_static(mercury__switch_detection__partition_disj_trial_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i1006);
	incr_sp_push_msg(8, "partition_disj_trial");
	detstackvar(8) = (Integer) succip;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__switch_detection__partition_disj_trial_6_0_i4,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
	}
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) field(mktag(0), (Integer) detstackvar(4), ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__partition_disj_trial_6_0_i5,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
	}
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0),
		mercury__switch_detection__partition_disj_trial_6_0_i6,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i8);
	detstackvar(4) = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__switch_detection__partition_disj_trial_6_0_i9,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
	}
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__switch_detection__partition_disj_trial_6_0_i12,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
	}
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i11);
	r6 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1);
	GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i14);
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i11);
	r6 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_1);
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i14);
	detstackvar(1) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__switch_detection__partition_disj_trial_6_0_i15,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
	}
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__switch_detection__partition_disj_trial_6_0,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i8);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	r4 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__switch_detection__partition_disj_trial_6_0,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i1006);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module13)
	init_entry(mercury__switch_detection__find_bind_var_for_switch_6_0);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i7);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i8);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i11);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i4);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i19);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i21);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i23);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i17);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i16);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i27);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i26);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i29);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i30);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i1050);
	init_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i1026);
BEGIN_CODE

/* code for predicate 'find_bind_var_for_switch'/6 in mode 0 */
Define_static(mercury__switch_detection__find_bind_var_for_switch_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i1026);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r6 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	incr_sp_push_msg(15, "find_bind_var_for_switch");
	detstackvar(15) = (Integer) succip;
	if ((tag((Integer) r6) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i4);
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	r1 = (Integer) field(mktag(0), (Integer) r6, ((Integer) 0));
	detstackvar(2) = (Integer) r3;
	localcall(mercury__switch_detection__find_bind_var_for_switch_6_0,
		LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i7),
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	tag_incr_hp(r4, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r1;
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i8);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i8);
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__switch_detection__find_bind_var_for_switch_6_0,
		LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i11),
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i4);
	if ((tag((Integer) r6) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i1050);
	if (((Integer) field(mktag(3), (Integer) r6, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i1050);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	r7 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	if ((tag((Integer) tempr2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i16);
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 5));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	detstackvar(12) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 2));
	detstackvar(11) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	detstackvar(13) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__term__apply_rec_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__switch_detection__find_bind_var_for_switch_6_0_i19,
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
	}
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i19);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i17);
	detstackvar(14) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__term__apply_rec_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__switch_detection__find_bind_var_for_switch_6_0_i21,
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i21);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i17);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__switch_detection__find_bind_var_for_switch_6_0_i23,
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i23);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i17);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(8);
	field(mktag(3), (Integer) r3, ((Integer) 5)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 5));
	field(mktag(1), (Integer) tempr1, ((Integer) 4)) = ((Integer) 1);
	field(mktag(1), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(13);
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(12);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r3, ((Integer) 4)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i17);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r1 = (Integer) detstackvar(7);
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i16);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r7;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r4;
	{
	Declare_entry(mercury__det_util__interpret_unify_4_0);
	call_localret(ENTRY(mercury__det_util__interpret_unify_4_0),
		mercury__switch_detection__find_bind_var_for_switch_6_0_i27,
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i27);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i26);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i29);
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i26);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i29);
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	localcall(mercury__switch_detection__find_bind_var_for_switch_6_0,
		LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0_i30),
		STATIC(mercury__switch_detection__find_bind_var_for_switch_6_0));
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i30);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_6_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i1050);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__find_bind_var_for_switch_6_0_i1026);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module14)
	init_entry(mercury__switch_detection__cases_to_switch_8_0);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i2);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i5);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i7);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i8);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i9);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i12);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i11);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i4);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i15);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i25);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i20);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i19);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i26);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i28);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i29);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i31);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i33);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i34);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i18);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i17);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i37);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i38);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i39);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i41);
	init_label(mercury__switch_detection__cases_to_switch_8_0_i42);
BEGIN_CODE

/* code for predicate 'cases_to_switch'/8 in mode 0 */
Define_static(mercury__switch_detection__cases_to_switch_8_0);
	incr_sp_push_msg(10, "cases_to_switch");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	r1 = (Integer) r6;
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__switch_detection__cases_to_switch_8_0_i2,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__mode_util__inst_is_bound_to_functors_3_0);
	call_localret(ENTRY(mercury__mode_util__inst_is_bound_to_functors_3_0),
		mercury__switch_detection__cases_to_switch_8_0_i5,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i4);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__switch_detection__functors_to_cons_ids_2_0),
		mercury__switch_detection__cases_to_switch_8_0_i7,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
Define_label(mercury__switch_detection__cases_to_switch_8_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	{
	Declare_entry(mercury__list__sort_2_0);
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__switch_detection__cases_to_switch_8_0_i8,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__switch_detection__delete_unreachable_cases_3_0),
		mercury__switch_detection__cases_to_switch_8_0_i9,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
Define_label(mercury__switch_detection__cases_to_switch_8_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_bound_inst_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_bound_inst_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_2);
	{
	Declare_entry(mercury__list__same_length_2_2);
	call_localret(ENTRY(mercury__list__same_length_2_2),
		mercury__switch_detection__cases_to_switch_8_0_i12,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i11);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(8);
	r8 = ((Integer) 1);
	GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i37);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i11);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(8);
	r8 = ((Integer) 0);
	GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i37);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i4);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__switch_detection__cases_to_switch_8_0_i15,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i19);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i19);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0)), (char *)string_const("character", 9)) !=0))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i19);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i19);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_detection__cases_to_switch_8_0_i25,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i25);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if ((((Integer) 127) != (Integer) r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i20);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i18);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i20);
	r1 = (Integer) detstackvar(8);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i19);
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__switch_detection__cases_to_switch_8_0_i26,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i26);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i17);
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__switch_detection__cases_to_switch_8_0_i28,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i28);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_3);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__switch_detection__cases_to_switch_8_0_i29,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i29);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i17);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__switch_detection__cases_to_switch_8_0_i31,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i31);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i17);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	}
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__switch_detection__cases_to_switch_8_0_i33,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i33);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_switch_detection__common_2);
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__same_length_2_2);
	call_localret(ENTRY(mercury__list__same_length_2_2),
		mercury__switch_detection__cases_to_switch_8_0_i34,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i34);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i17);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i18);
	r8 = ((Integer) 1);
	GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i37);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i17);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(1);
	r8 = ((Integer) 0);
Define_label(mercury__switch_detection__cases_to_switch_8_0_i37);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(9) = (Integer) r8;
	call_localret(STATIC(mercury__switch_detection__fix_case_list_3_0),
		mercury__switch_detection__cases_to_switch_8_0_i38,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
Define_label(mercury__switch_detection__cases_to_switch_8_0_i38);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__cases_to_switch_8_0_i39,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
Define_label(mercury__switch_detection__cases_to_switch_8_0_i39);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch_8_0_i41);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(9);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__switch_detection__cases_to_switch_8_0_i41);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__cases_to_switch_8_0_i42,
		STATIC(mercury__switch_detection__cases_to_switch_8_0));
	}
Define_label(mercury__switch_detection__cases_to_switch_8_0_i42);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module15)
	init_entry(mercury__switch_detection__delete_unreachable_cases_3_0);
	init_label(mercury__switch_detection__delete_unreachable_cases_3_0_i8);
	init_label(mercury__switch_detection__delete_unreachable_cases_3_0_i10);
	init_label(mercury__switch_detection__delete_unreachable_cases_3_0_i7);
	init_label(mercury__switch_detection__delete_unreachable_cases_3_0_i13);
	init_label(mercury__switch_detection__delete_unreachable_cases_3_0_i12);
	init_label(mercury__switch_detection__delete_unreachable_cases_3_0_i1006);
BEGIN_CODE

/* code for predicate 'delete_unreachable_cases'/3 in mode 0 */
Define_static(mercury__switch_detection__delete_unreachable_cases_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__delete_unreachable_cases_3_0_i1006);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__delete_unreachable_cases_3_0_i1006);
	incr_sp_push_msg(8, "delete_unreachable_cases");
	detstackvar(8) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(7) = (Integer) r3;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__switch_detection__delete_unreachable_cases_3_0_i8,
		STATIC(mercury__switch_detection__delete_unreachable_cases_3_0));
	}
Define_label(mercury__switch_detection__delete_unreachable_cases_3_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_detection__delete_unreachable_cases_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__switch_detection__delete_unreachable_cases_3_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	localcall(mercury__switch_detection__delete_unreachable_cases_3_0,
		LABEL(mercury__switch_detection__delete_unreachable_cases_3_0_i10),
		STATIC(mercury__switch_detection__delete_unreachable_cases_3_0));
Define_label(mercury__switch_detection__delete_unreachable_cases_3_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_detection__delete_unreachable_cases_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__switch_detection__delete_unreachable_cases_3_0_i7);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury__switch_detection__delete_unreachable_cases_3_0_i13,
		STATIC(mercury__switch_detection__delete_unreachable_cases_3_0));
	}
Define_label(mercury__switch_detection__delete_unreachable_cases_3_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__delete_unreachable_cases_3_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__switch_detection__delete_unreachable_cases_3_0_i12);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__switch_detection__delete_unreachable_cases_3_0,
		STATIC(mercury__switch_detection__delete_unreachable_cases_3_0));
Define_label(mercury__switch_detection__delete_unreachable_cases_3_0_i12);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__switch_detection__delete_unreachable_cases_3_0,
		STATIC(mercury__switch_detection__delete_unreachable_cases_3_0));
Define_label(mercury__switch_detection__delete_unreachable_cases_3_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module16)
	init_entry(mercury__switch_detection__functors_to_cons_ids_2_0);
	init_label(mercury__switch_detection__functors_to_cons_ids_2_0_i3);
	init_label(mercury__switch_detection__functors_to_cons_ids_2_0_i4);
	init_label(mercury__switch_detection__functors_to_cons_ids_2_0_i1);
BEGIN_CODE

/* code for predicate 'functors_to_cons_ids'/2 in mode 0 */
Define_static(mercury__switch_detection__functors_to_cons_ids_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__functors_to_cons_ids_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__switch_detection__functors_to_cons_ids_2_0_i3);
	while (1) {
	incr_sp_push_msg(1, "functors_to_cons_ids");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__switch_detection__functors_to_cons_ids_2_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__switch_detection__functors_to_cons_ids_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__switch_detection_module17)
	init_entry(mercury__switch_detection__fix_case_list_3_0);
	init_label(mercury__switch_detection__fix_case_list_3_0_i4);
	init_label(mercury__switch_detection__fix_case_list_3_0_i5);
	init_label(mercury__switch_detection__fix_case_list_3_0_i1003);
BEGIN_CODE

/* code for predicate 'fix_case_list'/3 in mode 0 */
Define_static(mercury__switch_detection__fix_case_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__switch_detection__fix_case_list_3_0_i1003);
	incr_sp_push_msg(4, "fix_case_list");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__disj_list_to_goal_3_0);
	call_localret(ENTRY(mercury__hlds_goal__disj_list_to_goal_3_0),
		mercury__switch_detection__fix_case_list_3_0_i4,
		STATIC(mercury__switch_detection__fix_case_list_3_0));
	}
Define_label(mercury__switch_detection__fix_case_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__fix_case_list_3_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	localcall(mercury__switch_detection__fix_case_list_3_0,
		LABEL(mercury__switch_detection__fix_case_list_3_0_i5),
		STATIC(mercury__switch_detection__fix_case_list_3_0));
Define_label(mercury__switch_detection__fix_case_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__fix_case_list_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__switch_detection__fix_case_list_3_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__switch_detection_bunch_0(void)
{
	mercury__switch_detection_module0();
	mercury__switch_detection_module1();
	mercury__switch_detection_module2();
	mercury__switch_detection_module3();
	mercury__switch_detection_module4();
	mercury__switch_detection_module5();
	mercury__switch_detection_module6();
	mercury__switch_detection_module7();
	mercury__switch_detection_module8();
	mercury__switch_detection_module9();
	mercury__switch_detection_module10();
	mercury__switch_detection_module11();
	mercury__switch_detection_module12();
	mercury__switch_detection_module13();
	mercury__switch_detection_module14();
	mercury__switch_detection_module15();
	mercury__switch_detection_module16();
	mercury__switch_detection_module17();
}

#endif

void mercury__switch_detection__init(void); /* suppress gcc warning */
void mercury__switch_detection__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__switch_detection_bunch_0();
#endif
}
