/*
** Automatically generated from `inlining.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__inlining__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__inlining__inlining_4_0);
Declare_label(mercury__inlining__inlining_4_0_i2);
Declare_label(mercury__inlining__inlining_4_0_i3);
Declare_label(mercury__inlining__inlining_4_0_i4);
Declare_label(mercury__inlining__inlining_4_0_i5);
Declare_label(mercury__inlining__inlining_4_0_i6);
Declare_label(mercury__inlining__inlining_4_0_i10);
Declare_label(mercury__inlining__inlining_4_0_i13);
Declare_label(mercury__inlining__inlining_4_0_i9);
Declare_label(mercury__inlining__inlining_4_0_i14);
Declare_label(mercury__inlining__inlining_4_0_i8);
Declare_label(mercury__inlining__inlining_4_0_i15);
Declare_label(mercury__inlining__inlining_4_0_i16);
Declare_label(mercury__inlining__inlining_4_0_i17);
Declare_label(mercury__inlining__inlining_4_0_i18);
Declare_label(mercury__inlining__inlining_4_0_i19);
Declare_label(mercury__inlining__inlining_4_0_i20);
Declare_label(mercury__inlining__inlining_4_0_i21);
Define_extern_entry(mercury__inlining__is_simple_goal_2_0);
Declare_label(mercury__inlining__is_simple_goal_2_0_i2);
Declare_label(mercury__inlining__is_simple_goal_2_0_i3);
Declare_label(mercury__inlining__is_simple_goal_2_0_i1);
Declare_static(mercury__inlining__do_inlining_8_0);
Declare_label(mercury__inlining__do_inlining_8_0_i4);
Declare_label(mercury__inlining__do_inlining_8_0_i5);
Declare_label(mercury__inlining__do_inlining_8_0_i6);
Declare_label(mercury__inlining__do_inlining_8_0_i7);
Declare_label(mercury__inlining__do_inlining_8_0_i8);
Declare_label(mercury__inlining__do_inlining_8_0_i9);
Declare_label(mercury__inlining__do_inlining_8_0_i10);
Declare_label(mercury__inlining__do_inlining_8_0_i11);
Declare_label(mercury__inlining__do_inlining_8_0_i12);
Declare_label(mercury__inlining__do_inlining_8_0_i13);
Declare_label(mercury__inlining__do_inlining_8_0_i14);
Declare_label(mercury__inlining__do_inlining_8_0_i15);
Declare_label(mercury__inlining__do_inlining_8_0_i16);
Declare_label(mercury__inlining__do_inlining_8_0_i17);
Declare_label(mercury__inlining__do_inlining_8_0_i18);
Declare_label(mercury__inlining__do_inlining_8_0_i19);
Declare_label(mercury__inlining__do_inlining_8_0_i20);
Declare_label(mercury__inlining__do_inlining_8_0_i1002);
Declare_static(mercury__inlining__mark_predproc_8_0);
Declare_label(mercury__inlining__mark_predproc_8_0_i4);
Declare_label(mercury__inlining__mark_predproc_8_0_i5);
Declare_label(mercury__inlining__mark_predproc_8_0_i6);
Declare_label(mercury__inlining__mark_predproc_8_0_i7);
Declare_label(mercury__inlining__mark_predproc_8_0_i12);
Declare_label(mercury__inlining__mark_predproc_8_0_i10);
Declare_label(mercury__inlining__mark_predproc_8_0_i9);
Declare_label(mercury__inlining__mark_predproc_8_0_i16);
Declare_label(mercury__inlining__mark_predproc_8_0_i17);
Declare_label(mercury__inlining__mark_predproc_8_0_i20);
Declare_label(mercury__inlining__mark_predproc_8_0_i15);
Declare_label(mercury__inlining__mark_predproc_8_0_i22);
Declare_label(mercury__inlining__mark_predproc_8_0_i8);
Declare_label(mercury__inlining__mark_predproc_8_0_i28);
Declare_label(mercury__inlining__mark_predproc_8_0_i30);
Declare_label(mercury__inlining__mark_predproc_8_0_i31);
Declare_label(mercury__inlining__mark_predproc_8_0_i34);
Declare_label(mercury__inlining__mark_predproc_8_0_i33);
Declare_label(mercury__inlining__mark_predproc_8_0_i36);
Declare_label(mercury__inlining__mark_predproc_8_0_i3);
Declare_static(mercury__inlining__is_flat_simple_goal_1_0);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i1015);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i12);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i1006);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i1005);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i1010);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i1011);
Declare_label(mercury__inlining__is_flat_simple_goal_1_0_i1014);
Declare_static(mercury__inlining__is_flat_simple_goal_list_1_0);
Declare_label(mercury__inlining__is_flat_simple_goal_list_1_0_i4);
Declare_label(mercury__inlining__is_flat_simple_goal_list_1_0_i1003);
Declare_label(mercury__inlining__is_flat_simple_goal_list_1_0_i1);
Declare_static(mercury__inlining__inlining_in_goal_10_0);
Declare_label(mercury__inlining__inlining_in_goal_10_0_i2);
Declare_static(mercury__inlining__inlining_in_goal_2_10_0);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1022);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1021);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1020);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1019);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1018);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i5);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i6);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i8);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i9);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i10);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i11);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i12);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i13);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i14);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i15);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i16);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i17);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1017);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i20);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i19);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i24);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i26);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i27);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i28);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i29);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i30);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i31);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i32);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i33);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i34);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i35);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i36);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i37);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i38);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i39);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i42);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i44);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i41);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i45);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i46);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i47);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i48);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i49);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i23);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i1014);
Declare_label(mercury__inlining__inlining_in_goal_2_10_0_i2);
Declare_static(mercury__inlining__inlining_in_disj_10_0);
Declare_label(mercury__inlining__inlining_in_disj_10_0_i4);
Declare_label(mercury__inlining__inlining_in_disj_10_0_i5);
Declare_label(mercury__inlining__inlining_in_disj_10_0_i1002);
Declare_static(mercury__inlining__inlining_in_cases_10_0);
Declare_label(mercury__inlining__inlining_in_cases_10_0_i4);
Declare_label(mercury__inlining__inlining_in_cases_10_0_i5);
Declare_label(mercury__inlining__inlining_in_cases_10_0_i1003);
Declare_static(mercury__inlining__inlining_in_conj_10_0);
Declare_label(mercury__inlining__inlining_in_conj_10_0_i4);
Declare_label(mercury__inlining__inlining_in_conj_10_0_i5);
Declare_label(mercury__inlining__inlining_in_conj_10_0_i6);
Declare_label(mercury__inlining__inlining_in_conj_10_0_i7);
Declare_label(mercury__inlining__inlining_in_conj_10_0_i1002);
Declare_static(mercury__inlining__should_inline_proc_5_0);
Declare_label(mercury__inlining__should_inline_proc_5_0_i4);
Declare_label(mercury__inlining__should_inline_proc_5_0_i6);
Declare_label(mercury__inlining__should_inline_proc_5_0_i9);
Declare_label(mercury__inlining__should_inline_proc_5_0_i13);
Declare_label(mercury__inlining__should_inline_proc_5_0_i12);
Declare_label(mercury__inlining__should_inline_proc_5_0_i19);
Declare_label(mercury__inlining__should_inline_proc_5_0_i16);
Declare_label(mercury__inlining__should_inline_proc_5_0_i1);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_inlining__base_type_layout_inline_params_0[];
Word * mercury_data_inlining__base_type_info_inline_params_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_inlining__base_type_layout_inline_params_0
};

extern Word * mercury_data_inlining__common_4[];
Word * mercury_data_inlining__base_type_layout_inline_params_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_inlining__common_4),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_inlining__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_inlining__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_inlining__common_2[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_inlining__common_3[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_inlining__common_4[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_3),
	(Word *) string_const("params", 6)
};

BEGIN_MODULE(mercury__inlining_module0)
	init_entry(mercury__inlining__inlining_4_0);
	init_label(mercury__inlining__inlining_4_0_i2);
	init_label(mercury__inlining__inlining_4_0_i3);
	init_label(mercury__inlining__inlining_4_0_i4);
	init_label(mercury__inlining__inlining_4_0_i5);
	init_label(mercury__inlining__inlining_4_0_i6);
	init_label(mercury__inlining__inlining_4_0_i10);
	init_label(mercury__inlining__inlining_4_0_i13);
	init_label(mercury__inlining__inlining_4_0_i9);
	init_label(mercury__inlining__inlining_4_0_i14);
	init_label(mercury__inlining__inlining_4_0_i8);
	init_label(mercury__inlining__inlining_4_0_i15);
	init_label(mercury__inlining__inlining_4_0_i16);
	init_label(mercury__inlining__inlining_4_0_i17);
	init_label(mercury__inlining__inlining_4_0_i18);
	init_label(mercury__inlining__inlining_4_0_i19);
	init_label(mercury__inlining__inlining_4_0_i20);
	init_label(mercury__inlining__inlining_4_0_i21);
BEGIN_CODE

/* code for predicate 'inlining'/4 in mode 0 */
Define_entry(mercury__inlining__inlining_4_0);
	incr_sp_push_msg(7, "inlining");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 88);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__inlining__inlining_4_0_i2,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i2);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 89);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__inlining__inlining_4_0_i3,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i3);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 90);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__inlining__inlining_4_0_i4,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 91);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__inlining__inlining_4_0_i5,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i5);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = ((Integer) 92);
	{
	Declare_entry(mercury__globals__io_lookup_int_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__inlining__inlining_4_0_i6,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i6);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) r1;
	r4 = (Integer) r3;
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__inlining__inlining_4_0_i10);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	r1 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__inlining__inlining_4_0_i9);
	}
Define_label(mercury__inlining__inlining_4_0_i10);
	if (((Integer) detstackvar(4) > ((Integer) 0)))
		GOTO_LABEL(mercury__inlining__inlining_4_0_i13);
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r2;
	GOTO_LABEL(mercury__inlining__inlining_4_0_i8);
Define_label(mercury__inlining__inlining_4_0_i13);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	r2 = (Integer) r4;
Define_label(mercury__inlining__inlining_4_0_i9);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	{
	Declare_entry(mercury__dead_proc_elim__analyze_2_0);
	call_localret(ENTRY(mercury__dead_proc_elim__analyze_2_0),
		mercury__inlining__inlining_4_0_i14,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i14);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__inlining__inlining_4_0_i16);
Define_label(mercury__inlining__inlining_4_0_i8);
	{
	extern Word * mercury_data_dead_proc_elim__base_type_info_entity_0[];
	r1 = (Integer) mercury_data_dead_proc_elim__base_type_info_entity_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__inlining__inlining_4_0_i15,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i15);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
Define_label(mercury__inlining__inlining_4_0_i16);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	{
	Declare_entry(mercury__dependency_graph__module_info_ensure_dependency_info_2_0);
	call_localret(ENTRY(mercury__dependency_graph__module_info_ensure_dependency_info_2_0),
		mercury__inlining__inlining_4_0_i17,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i17);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_dependency_info_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_dependency_info_2_0),
		mercury__inlining__inlining_4_0_i18,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i18);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	{
	Declare_entry(mercury__hlds_module__hlds__dependency_info_get_dependency_ordering_2_0);
	call_localret(ENTRY(mercury__hlds_module__hlds__dependency_info_get_dependency_ordering_2_0),
		mercury__inlining__inlining_4_0_i19,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i19);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__inlining__inlining_4_0_i20,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i20);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__inlining__inlining_4_0_i21,
		ENTRY(mercury__inlining__inlining_4_0));
	}
Define_label(mercury__inlining__inlining_4_0_i21);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__inlining__do_inlining_8_0),
		ENTRY(mercury__inlining__inlining_4_0));
END_MODULE

BEGIN_MODULE(mercury__inlining_module1)
	init_entry(mercury__inlining__is_simple_goal_2_0);
	init_label(mercury__inlining__is_simple_goal_2_0_i2);
	init_label(mercury__inlining__is_simple_goal_2_0_i3);
	init_label(mercury__inlining__is_simple_goal_2_0_i1);
BEGIN_CODE

/* code for predicate 'inlining__is_simple_goal'/2 in mode 0 */
Define_entry(mercury__inlining__is_simple_goal_2_0);
	incr_sp_push_msg(3, "inlining__is_simple_goal");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__goal_util__goal_size_2_0);
	call_localret(ENTRY(mercury__goal_util__goal_size_2_0),
		mercury__inlining__is_simple_goal_2_0_i2,
		ENTRY(mercury__inlining__is_simple_goal_2_0));
	}
Define_label(mercury__inlining__is_simple_goal_2_0_i2);
	update_prof_current_proc(LABEL(mercury__inlining__is_simple_goal_2_0));
	r2 = (Integer) detstackvar(2);
	if (((Integer) r1 < (Integer) r2))
		GOTO_LABEL(mercury__inlining__is_simple_goal_2_0_i3);
	if (((Integer) r1 >= ((Integer) r2 * ((Integer) 3))))
		GOTO_LABEL(mercury__inlining__is_simple_goal_2_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__inlining__is_flat_simple_goal_1_0),
		ENTRY(mercury__inlining__is_simple_goal_2_0));
Define_label(mercury__inlining__is_simple_goal_2_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__inlining__is_simple_goal_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module2)
	init_entry(mercury__inlining__do_inlining_8_0);
	init_label(mercury__inlining__do_inlining_8_0_i4);
	init_label(mercury__inlining__do_inlining_8_0_i5);
	init_label(mercury__inlining__do_inlining_8_0_i6);
	init_label(mercury__inlining__do_inlining_8_0_i7);
	init_label(mercury__inlining__do_inlining_8_0_i8);
	init_label(mercury__inlining__do_inlining_8_0_i9);
	init_label(mercury__inlining__do_inlining_8_0_i10);
	init_label(mercury__inlining__do_inlining_8_0_i11);
	init_label(mercury__inlining__do_inlining_8_0_i12);
	init_label(mercury__inlining__do_inlining_8_0_i13);
	init_label(mercury__inlining__do_inlining_8_0_i14);
	init_label(mercury__inlining__do_inlining_8_0_i15);
	init_label(mercury__inlining__do_inlining_8_0_i16);
	init_label(mercury__inlining__do_inlining_8_0_i17);
	init_label(mercury__inlining__do_inlining_8_0_i18);
	init_label(mercury__inlining__do_inlining_8_0_i19);
	init_label(mercury__inlining__do_inlining_8_0_i20);
	init_label(mercury__inlining__do_inlining_8_0_i1002);
BEGIN_CODE

/* code for predicate 'inlining__do_inlining'/8 in mode 0 */
Define_static(mercury__inlining__do_inlining_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__do_inlining_8_0_i1002);
	incr_sp_push_msg(18, "inlining__do_inlining");
	detstackvar(18) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) tempr1;
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r1 = (Integer) r5;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__inlining__do_inlining_8_0_i4,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
	}
Define_label(mercury__inlining__do_inlining_8_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r3 = (Integer) r1;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__inlining__do_inlining_8_0_i5,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i5);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	detstackvar(12) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__inlining__do_inlining_8_0_i6,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i6);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r3 = (Integer) r1;
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__inlining__do_inlining_8_0_i7,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i7);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__inlining__do_inlining_8_0_i8,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i8);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__inlining__do_inlining_8_0_i9,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i9);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__inlining__do_inlining_8_0_i10,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i10);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	detstackvar(17) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__inlining__do_inlining_8_0_i11,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i11);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(16);
	r2 = (Integer) detstackvar(17);
	r4 = (Integer) detstackvar(15);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__do_inlining_8_0_i12,
		STATIC(mercury__inlining__do_inlining_8_0));
Define_label(mercury__inlining__do_inlining_8_0_i12);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	detstackvar(14) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_variables_3_0),
		mercury__inlining__do_inlining_8_0_i13,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i13);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		mercury__inlining__do_inlining_8_0_i14,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i14);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__inlining__do_inlining_8_0_i15,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i15);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r3 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__inlining__do_inlining_8_0_i16,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i16);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__inlining__do_inlining_8_0_i17,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i17);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__inlining__do_inlining_8_0_i18,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i18);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__inlining__do_inlining_8_0_i19,
		STATIC(mercury__inlining__do_inlining_8_0));
	}
Define_label(mercury__inlining__do_inlining_8_0_i19);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r5 = (Integer) detstackvar(3);
	r4 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__inlining__mark_predproc_8_0),
		mercury__inlining__do_inlining_8_0_i20,
		STATIC(mercury__inlining__do_inlining_8_0));
Define_label(mercury__inlining__do_inlining_8_0_i20);
	update_prof_current_proc(LABEL(mercury__inlining__do_inlining_8_0));
	r4 = (Integer) r1;
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(18);
	decr_sp_pop_msg(18);
	localtailcall(mercury__inlining__do_inlining_8_0,
		STATIC(mercury__inlining__do_inlining_8_0));
Define_label(mercury__inlining__do_inlining_8_0_i1002);
	r1 = (Integer) r5;
	r2 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module3)
	init_entry(mercury__inlining__mark_predproc_8_0);
	init_label(mercury__inlining__mark_predproc_8_0_i4);
	init_label(mercury__inlining__mark_predproc_8_0_i5);
	init_label(mercury__inlining__mark_predproc_8_0_i6);
	init_label(mercury__inlining__mark_predproc_8_0_i7);
	init_label(mercury__inlining__mark_predproc_8_0_i12);
	init_label(mercury__inlining__mark_predproc_8_0_i10);
	init_label(mercury__inlining__mark_predproc_8_0_i9);
	init_label(mercury__inlining__mark_predproc_8_0_i16);
	init_label(mercury__inlining__mark_predproc_8_0_i17);
	init_label(mercury__inlining__mark_predproc_8_0_i20);
	init_label(mercury__inlining__mark_predproc_8_0_i15);
	init_label(mercury__inlining__mark_predproc_8_0_i22);
	init_label(mercury__inlining__mark_predproc_8_0_i8);
	init_label(mercury__inlining__mark_predproc_8_0_i28);
	init_label(mercury__inlining__mark_predproc_8_0_i30);
	init_label(mercury__inlining__mark_predproc_8_0_i31);
	init_label(mercury__inlining__mark_predproc_8_0_i34);
	init_label(mercury__inlining__mark_predproc_8_0_i33);
	init_label(mercury__inlining__mark_predproc_8_0_i36);
	init_label(mercury__inlining__mark_predproc_8_0_i3);
BEGIN_CODE

/* code for predicate 'inlining__mark_predproc'/8 in mode 0 */
Define_static(mercury__inlining__mark_predproc_8_0);
	incr_sp_push_msg(12, "inlining__mark_predproc");
	detstackvar(12) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(10) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r1 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__inlining__mark_predproc_8_0_i4,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__inlining__mark_predproc_8_0_i5,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i5);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__inlining__mark_predproc_8_0_i6,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__inlining__mark_predproc_8_0_i7,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i7);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(11);
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i9);
	detstackvar(6) = (Integer) r1;
	r3 = (Integer) detstackvar(9);
	detstackvar(9) = (Integer) r2;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__inlining__is_simple_goal_2_0),
		mercury__inlining__mark_predproc_8_0_i12,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i12);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i8);
Define_label(mercury__inlining__mark_predproc_8_0_i10);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(9);
Define_label(mercury__inlining__mark_predproc_8_0_i9);
	if (((Integer) detstackvar(8) > ((Integer) 0)))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i16);
	detstackvar(6) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i15);
Define_label(mercury__inlining__mark_predproc_8_0_i16);
	r4 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	{
	extern Word * mercury_data_dead_proc_elim__base_type_info_entity_0[];
	r1 = (Integer) mercury_data_dead_proc_elim__base_type_info_entity_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_0);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__inlining__mark_predproc_8_0_i17,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i17);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i15);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i15);
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__goal_util__goal_size_2_0);
	call_localret(ENTRY(mercury__goal_util__goal_size_2_0),
		mercury__inlining__mark_predproc_8_0_i20,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i20);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	if ((((Integer) r1 * (Integer) detstackvar(10)) > (Integer) detstackvar(8)))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i15);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i8);
Define_label(mercury__inlining__mark_predproc_8_0_i15);
	if (((Integer) detstackvar(7) != ((Integer) 0)))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i3);
	{
	extern Word * mercury_data_dead_proc_elim__base_type_info_entity_0[];
	r1 = (Integer) mercury_data_dead_proc_elim__base_type_info_entity_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__inlining__mark_predproc_8_0_i22,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i22);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i3);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i3);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(6);
Define_label(mercury__inlining__mark_predproc_8_0_i8);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__goal_util__goal_calls_2_0);
	call_localret(ENTRY(mercury__goal_util__goal_calls_2_0),
		mercury__inlining__mark_predproc_8_0_i28,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i28);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i3);
	r3 = (Integer) detstackvar(1);
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__inlining__mark_predproc_8_0_i30,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i30);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__inlining__mark_predproc_8_0_i31,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i31);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_inlined_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_inlined_1_0),
		mercury__inlining__mark_predproc_8_0_i34,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i34);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__mark_predproc_8_0_i33);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__inlining__mark_predproc_8_0_i33);
	r1 = string_const("% Inlining ", 11);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__passes_aux__write_proc_progress_message_6_0);
	call_localret(ENTRY(mercury__passes_aux__write_proc_progress_message_6_0),
		mercury__inlining__mark_predproc_8_0_i36,
		STATIC(mercury__inlining__mark_predproc_8_0));
	}
Define_label(mercury__inlining__mark_predproc_8_0_i36);
	update_prof_current_proc(LABEL(mercury__inlining__mark_predproc_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__inlining__mark_predproc_8_0_i3);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module4)
	init_entry(mercury__inlining__is_flat_simple_goal_1_0);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i1015);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i12);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i1006);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i1005);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i1010);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i1011);
	init_label(mercury__inlining__is_flat_simple_goal_1_0_i1014);
BEGIN_CODE

/* code for predicate 'inlining__is_flat_simple_goal'/1 in mode 0 */
Define_static(mercury__inlining__is_flat_simple_goal_1_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r3 = tag((Integer) r2);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1015);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)),
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1005) AND
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1006) AND
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1005) AND
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1010) AND
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1011) AND
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1005) AND
		LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1005));
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i1015);
	incr_sp_push_msg(1, "inlining__is_flat_simple_goal");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__inlining__is_flat_simple_goal_1_0_i12);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__inlining__is_flat_simple_goal_list_1_0),
		STATIC(mercury__inlining__is_flat_simple_goal_1_0));
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__inlining__is_flat_simple_goal_1_0_i1014);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	tailcall(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		STATIC(mercury__inlining__is_flat_simple_goal_1_0));
	}
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i1010);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	localtailcall(mercury__inlining__is_flat_simple_goal_1_0,
		STATIC(mercury__inlining__is_flat_simple_goal_1_0));
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i1011);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	localtailcall(mercury__inlining__is_flat_simple_goal_1_0,
		STATIC(mercury__inlining__is_flat_simple_goal_1_0));
Define_label(mercury__inlining__is_flat_simple_goal_1_0_i1014);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module5)
	init_entry(mercury__inlining__is_flat_simple_goal_list_1_0);
	init_label(mercury__inlining__is_flat_simple_goal_list_1_0_i4);
	init_label(mercury__inlining__is_flat_simple_goal_list_1_0_i1003);
	init_label(mercury__inlining__is_flat_simple_goal_list_1_0_i1);
BEGIN_CODE

/* code for predicate 'inlining__is_flat_simple_goal_list'/1 in mode 0 */
Define_static(mercury__inlining__is_flat_simple_goal_list_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__is_flat_simple_goal_list_1_0_i1003);
	incr_sp_push_msg(2, "inlining__is_flat_simple_goal_list");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__inlining__is_flat_simple_goal_1_0),
		mercury__inlining__is_flat_simple_goal_list_1_0_i4,
		STATIC(mercury__inlining__is_flat_simple_goal_list_1_0));
Define_label(mercury__inlining__is_flat_simple_goal_list_1_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__is_flat_simple_goal_list_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__is_flat_simple_goal_list_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__inlining__is_flat_simple_goal_list_1_0,
		STATIC(mercury__inlining__is_flat_simple_goal_list_1_0));
Define_label(mercury__inlining__is_flat_simple_goal_list_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__inlining__is_flat_simple_goal_list_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module6)
	init_entry(mercury__inlining__inlining_in_goal_10_0);
	init_label(mercury__inlining__inlining_in_goal_10_0_i2);
BEGIN_CODE

/* code for predicate 'inlining__inlining_in_goal'/10 in mode 0 */
Define_static(mercury__inlining__inlining_in_goal_10_0);
	incr_sp_push_msg(2, "inlining__inlining_in_goal");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__inlining__inlining_in_goal_2_10_0),
		mercury__inlining__inlining_in_goal_10_0_i2,
		STATIC(mercury__inlining__inlining_in_goal_10_0));
Define_label(mercury__inlining__inlining_in_goal_10_0_i2);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_10_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__inlining_module7)
	init_entry(mercury__inlining__inlining_in_goal_2_10_0);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1022);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1021);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1020);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1019);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1018);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i5);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i6);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i8);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i9);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i10);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i11);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i12);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i13);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i14);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i15);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i16);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i17);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1017);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i20);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i19);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i24);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i26);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i27);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i28);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i29);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i30);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i31);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i32);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i33);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i34);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i35);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i36);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i37);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i38);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i39);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i42);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i44);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i41);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i45);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i46);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i47);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i48);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i49);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i23);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i1014);
	init_label(mercury__inlining__inlining_in_goal_2_10_0_i2);
BEGIN_CODE

/* code for predicate 'inlining__inlining_in_goal_2'/10 in mode 0 */
Define_static(mercury__inlining__inlining_in_goal_2_10_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1017);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1022) AND
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1014) AND
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1021) AND
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1020) AND
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1019) AND
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1018) AND
		LABEL(mercury__inlining__inlining_in_goal_2_10_0_i1014));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1022);
	incr_sp_push_msg(11, "inlining__inlining_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i5);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1021);
	incr_sp_push_msg(11, "inlining__inlining_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i8);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1020);
	incr_sp_push_msg(11, "inlining__inlining_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i10);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1019);
	incr_sp_push_msg(11, "inlining__inlining_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i12);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1018);
	incr_sp_push_msg(11, "inlining__inlining_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i14);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__inlining__inlining_in_cases_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i6,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i6);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__inlining__inlining_in_disj_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i9,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i9);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i11,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i11);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i12);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i13,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i13);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i14);
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(1) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i15,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i15);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) tempr1;
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i16,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i16);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r6 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i17,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i17);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r4;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1017);
	incr_sp_push_msg(11, "inlining__inlining_in_goal_2");
	detstackvar(11) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i19);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__inlining__inlining_in_conj_10_0),
		mercury__inlining__inlining_in_goal_2_10_0_i20,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i20);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i19);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i2);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r2 = (Integer) tempr1;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r1;
	detstackvar(8) = (Integer) tempr1;
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) r1;
	r4 = (Integer) r6;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r7;
	call_localret(STATIC(mercury__inlining__should_inline_proc_5_0),
		mercury__inlining__inlining_in_goal_2_10_0_i24,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i24);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i23);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__varset__vars_2_0);
	call_localret(ENTRY(mercury__varset__vars_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i26,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i26);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i27,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i27);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__inlining__inlining_in_goal_2_10_0_i28,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i28);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i29,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i29);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(10) = (Integer) r1;
	{
	Declare_entry(mercury__varset__vars_2_0);
	call_localret(ENTRY(mercury__varset__vars_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i30,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i30);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i31,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i31);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	if ((((Integer) detstackvar(5) + (Integer) r1) > (Integer) detstackvar(6)))
		GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i23);
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i32,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i32);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i33,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i33);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i34,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i34);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i35,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i35);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__varset__merge_subst_4_0);
	call_localret(ENTRY(mercury__varset__merge_subst_4_0),
		mercury__inlining__inlining_in_goal_2_10_0_i36,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i36);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
	call_localret(ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i37,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i37);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	detstackvar(8) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__apply_to_list_3_0);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i38,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i38);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__apply_to_list_3_0);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i39,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i39);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__type_util__type_list_subsumes_3_0);
	call_localret(ENTRY(mercury__type_util__type_list_subsumes_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i42,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i42);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i41);
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
	call_localret(ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i44,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i44);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r7 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__inlining__inlining_in_goal_2_10_0_i45);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i41);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(9);
	r1 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i45);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	detstackvar(10) = (Integer) r1;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	{
	Declare_entry(mercury__varset__vars_2_0);
	call_localret(ENTRY(mercury__varset__vars_2_0),
		mercury__inlining__inlining_in_goal_2_10_0_i46,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i46);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__map__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i47,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i47);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__goal_util__create_variables_9_0);
	call_localret(ENTRY(mercury__goal_util__create_variables_9_0),
		mercury__inlining__inlining_in_goal_2_10_0_i48,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i48);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__goal_util__must_rename_vars_in_goal_3_0);
	call_localret(ENTRY(mercury__goal_util__must_rename_vars_in_goal_3_0),
		mercury__inlining__inlining_in_goal_2_10_0_i49,
		STATIC(mercury__inlining__inlining_in_goal_2_10_0));
	}
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i49);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_goal_2_10_0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i23);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i1014);
	proceed();
Define_label(mercury__inlining__inlining_in_goal_2_10_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module8)
	init_entry(mercury__inlining__inlining_in_disj_10_0);
	init_label(mercury__inlining__inlining_in_disj_10_0_i4);
	init_label(mercury__inlining__inlining_in_disj_10_0_i5);
	init_label(mercury__inlining__inlining_in_disj_10_0_i1002);
BEGIN_CODE

/* code for predicate 'inlining__inlining_in_disj'/10 in mode 0 */
Define_static(mercury__inlining__inlining_in_disj_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__inlining_in_disj_10_0_i1002);
	incr_sp_push_msg(6, "inlining__inlining_in_disj");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_disj_10_0_i4,
		STATIC(mercury__inlining__inlining_in_disj_10_0));
Define_label(mercury__inlining__inlining_in_disj_10_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_disj_10_0));
	r4 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	localcall(mercury__inlining__inlining_in_disj_10_0,
		LABEL(mercury__inlining__inlining_in_disj_10_0_i5),
		STATIC(mercury__inlining__inlining_in_disj_10_0));
Define_label(mercury__inlining__inlining_in_disj_10_0_i5);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_disj_10_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__inlining__inlining_in_disj_10_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module9)
	init_entry(mercury__inlining__inlining_in_cases_10_0);
	init_label(mercury__inlining__inlining_in_cases_10_0_i4);
	init_label(mercury__inlining__inlining_in_cases_10_0_i5);
	init_label(mercury__inlining__inlining_in_cases_10_0_i1003);
BEGIN_CODE

/* code for predicate 'inlining__inlining_in_cases'/10 in mode 0 */
Define_static(mercury__inlining__inlining_in_cases_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__inlining_in_cases_10_0_i1003);
	incr_sp_push_msg(7, "inlining__inlining_in_cases");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_cases_10_0_i4,
		STATIC(mercury__inlining__inlining_in_cases_10_0));
	}
Define_label(mercury__inlining__inlining_in_cases_10_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_cases_10_0));
	r4 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	localcall(mercury__inlining__inlining_in_cases_10_0,
		LABEL(mercury__inlining__inlining_in_cases_10_0_i5),
		STATIC(mercury__inlining__inlining_in_cases_10_0));
	}
Define_label(mercury__inlining__inlining_in_cases_10_0_i5);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_cases_10_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__inlining__inlining_in_cases_10_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module10)
	init_entry(mercury__inlining__inlining_in_conj_10_0);
	init_label(mercury__inlining__inlining_in_conj_10_0_i4);
	init_label(mercury__inlining__inlining_in_conj_10_0_i5);
	init_label(mercury__inlining__inlining_in_conj_10_0_i6);
	init_label(mercury__inlining__inlining_in_conj_10_0_i7);
	init_label(mercury__inlining__inlining_in_conj_10_0_i1002);
BEGIN_CODE

/* code for predicate 'inlining__inlining_in_conj'/10 in mode 0 */
Define_static(mercury__inlining__inlining_in_conj_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__inlining__inlining_in_conj_10_0_i1002);
	incr_sp_push_msg(8, "inlining__inlining_in_conj");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__inlining__inlining_in_goal_10_0),
		mercury__inlining__inlining_in_conj_10_0_i4,
		STATIC(mercury__inlining__inlining_in_conj_10_0));
Define_label(mercury__inlining__inlining_in_conj_10_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_conj_10_0));
	detstackvar(6) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__inlining__inlining_in_conj_10_0_i5,
		STATIC(mercury__inlining__inlining_in_conj_10_0));
	}
Define_label(mercury__inlining__inlining_in_conj_10_0_i5);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_conj_10_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	localcall(mercury__inlining__inlining_in_conj_10_0,
		LABEL(mercury__inlining__inlining_in_conj_10_0_i6),
		STATIC(mercury__inlining__inlining_in_conj_10_0));
Define_label(mercury__inlining__inlining_in_conj_10_0_i6);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_conj_10_0));
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_inlining__common_1);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__inlining__inlining_in_conj_10_0_i7,
		STATIC(mercury__inlining__inlining_in_conj_10_0));
	}
	}
Define_label(mercury__inlining__inlining_in_conj_10_0_i7);
	update_prof_current_proc(LABEL(mercury__inlining__inlining_in_conj_10_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__inlining__inlining_in_conj_10_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__inlining_module11)
	init_entry(mercury__inlining__should_inline_proc_5_0);
	init_label(mercury__inlining__should_inline_proc_5_0_i4);
	init_label(mercury__inlining__should_inline_proc_5_0_i6);
	init_label(mercury__inlining__should_inline_proc_5_0_i9);
	init_label(mercury__inlining__should_inline_proc_5_0_i13);
	init_label(mercury__inlining__should_inline_proc_5_0_i12);
	init_label(mercury__inlining__should_inline_proc_5_0_i19);
	init_label(mercury__inlining__should_inline_proc_5_0_i16);
	init_label(mercury__inlining__should_inline_proc_5_0_i1);
BEGIN_CODE

/* code for predicate 'inlining__should_inline_proc'/5 in mode 0 */
Define_static(mercury__inlining__should_inline_proc_5_0);
	incr_sp_push_msg(5, "inlining__should_inline_proc");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__inlining__should_inline_proc_5_0_i4,
		STATIC(mercury__inlining__should_inline_proc_5_0));
	}
Define_label(mercury__inlining__should_inline_proc_5_0_i4);
	update_prof_current_proc(LABEL(mercury__inlining__should_inline_proc_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__inlining__should_inline_proc_5_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__inlining__should_inline_proc_5_0_i6,
		STATIC(mercury__inlining__should_inline_proc_5_0));
	}
Define_label(mercury__inlining__should_inline_proc_5_0_i6);
	update_prof_current_proc(LABEL(mercury__inlining__should_inline_proc_5_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__inlining__should_inline_proc_5_0_i9,
		STATIC(mercury__inlining__should_inline_proc_5_0));
	}
Define_label(mercury__inlining__should_inline_proc_5_0_i9);
	update_prof_current_proc(LABEL(mercury__inlining__should_inline_proc_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__inlining__should_inline_proc_5_0_i1);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0),
		mercury__inlining__should_inline_proc_5_0_i13,
		STATIC(mercury__inlining__should_inline_proc_5_0));
	}
Define_label(mercury__inlining__should_inline_proc_5_0_i13);
	update_prof_current_proc(LABEL(mercury__inlining__should_inline_proc_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__inlining__should_inline_proc_5_0_i12);
	if (((Integer) detstackvar(2) == ((Integer) 0)))
		GOTO_LABEL(mercury__inlining__should_inline_proc_5_0_i1);
Define_label(mercury__inlining__should_inline_proc_5_0_i12);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__pred_info_is_inlined_1_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_inlined_1_0),
		mercury__inlining__should_inline_proc_5_0_i19,
		STATIC(mercury__inlining__should_inline_proc_5_0));
	}
Define_label(mercury__inlining__should_inline_proc_5_0_i19);
	update_prof_current_proc(LABEL(mercury__inlining__should_inline_proc_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__inlining__should_inline_proc_5_0_i16);
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_proc_id_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_pred_proc_id_0;
	}
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__set__member_2_0);
	tailcall(ENTRY(mercury__set__member_2_0),
		STATIC(mercury__inlining__should_inline_proc_5_0));
	}
Define_label(mercury__inlining__should_inline_proc_5_0_i16);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__inlining__should_inline_proc_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__inlining_bunch_0(void)
{
	mercury__inlining_module0();
	mercury__inlining_module1();
	mercury__inlining_module2();
	mercury__inlining_module3();
	mercury__inlining_module4();
	mercury__inlining_module5();
	mercury__inlining_module6();
	mercury__inlining_module7();
	mercury__inlining_module8();
	mercury__inlining_module9();
	mercury__inlining_module10();
	mercury__inlining_module11();
}

#endif

void mercury__inlining__init(void); /* suppress gcc warning */
void mercury__inlining__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__inlining_bunch_0();
#endif
}
