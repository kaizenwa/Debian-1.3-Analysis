/*
** Automatically generated from `vn_type.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_type__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___vn_type_vn_params_0__ua10000_2_0);
Declare_static(mercury____Index___vn_type_vn_ctrl_tuple_0__ua10000_2_0);
Declare_static(mercury____Index___vn_type_parallel_0__ua10000_2_0);
Define_extern_entry(mercury__vn_type__vnlval_type_2_0);
Declare_label(mercury__vn_type__vnlval_type_2_0_i5);
Declare_label(mercury__vn_type__vnlval_type_2_0_i1003);
Declare_label(mercury__vn_type__vnlval_type_2_0_i1000);
Declare_label(mercury__vn_type__vnlval_type_2_0_i1001);
Declare_label(mercury__vn_type__vnlval_type_2_0_i1002);
Define_extern_entry(mercury__vn_type__vnrval_type_2_0);
Declare_label(mercury__vn_type__vnrval_type_2_0_i1003);
Declare_label(mercury__vn_type__vnrval_type_2_0_i1002);
Declare_label(mercury__vn_type__vnrval_type_2_0_i9);
Declare_label(mercury__vn_type__vnrval_type_2_0_i1000);
Declare_label(mercury__vn_type__vnrval_type_2_0_i1001);
Define_extern_entry(mercury__vn_type__init_params_2_0);
Declare_label(mercury__vn_type__init_params_2_0_i2);
Declare_label(mercury__vn_type__init_params_2_0_i3);
Declare_label(mercury__vn_type__init_params_2_0_i4);
Declare_label(mercury__vn_type__init_params_2_0_i5);
Declare_label(mercury__vn_type__init_params_2_0_i6);
Define_extern_entry(mercury__vn_type__bytes_per_word_2_0);
Define_extern_entry(mercury__vn_type__real_r_regs_2_0);
Define_extern_entry(mercury__vn_type__real_f_regs_2_0);
Define_extern_entry(mercury__vn_type__real_r_temps_2_0);
Define_extern_entry(mercury__vn_type__real_f_temps_2_0);
Define_extern_entry(mercury__vn_type__costof_assign_2_0);
Define_extern_entry(mercury__vn_type__costof_intops_2_0);
Define_extern_entry(mercury__vn_type__costof_stackref_2_0);
Define_extern_entry(mercury__vn_type__costof_heapref_2_0);
Define_extern_entry(mercury____Unify___vn_type__vn_0_0);
Declare_label(mercury____Unify___vn_type__vn_0_0_i1);
Define_extern_entry(mercury____Index___vn_type__vn_0_0);
Define_extern_entry(mercury____Compare___vn_type__vn_0_0);
Define_extern_entry(mercury____Unify___vn_type__vnlval_0_0);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1050);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1049);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1048);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1047);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1046);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1045);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1044);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1034);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1035);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1036);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1037);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1038);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1039);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1040);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1043);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i22);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i24);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i26);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i28);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i30);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i21);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i32);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1041);
Declare_label(mercury____Unify___vn_type__vnlval_0_0_i1042);
Define_extern_entry(mercury____Index___vn_type__vnlval_0_0);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i5);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i6);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i7);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i8);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i9);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i10);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i11);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i4);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i13);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i14);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i15);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i16);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i17);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i12);
Declare_label(mercury____Index___vn_type__vnlval_0_0_i18);
Define_extern_entry(mercury____Compare___vn_type__vnlval_0_0);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i2);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i3);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i4);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i6);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i13);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i16);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i19);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i22);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i25);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i28);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i32);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i33);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i31);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i38);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i45);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i12);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i49);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i51);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i53);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i55);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i57);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i48);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i59);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i9);
Declare_label(mercury____Compare___vn_type__vnlval_0_0_i1001);
Define_extern_entry(mercury____Unify___vn_type__vnrval_0_0);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i7);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i9);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i1032);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i11);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i1031);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i14);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i18);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i1028);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i1);
Declare_label(mercury____Unify___vn_type__vnrval_0_0_i1030);
Define_extern_entry(mercury____Index___vn_type__vnrval_0_0);
Declare_label(mercury____Index___vn_type__vnrval_0_0_i5);
Declare_label(mercury____Index___vn_type__vnrval_0_0_i6);
Declare_label(mercury____Index___vn_type__vnrval_0_0_i4);
Declare_label(mercury____Index___vn_type__vnrval_0_0_i7);
Declare_label(mercury____Index___vn_type__vnrval_0_0_i8);
Define_extern_entry(mercury____Compare___vn_type__vnrval_0_0);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i2);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i3);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i4);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i6);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i17);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i18);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i16);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i23);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i29);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i13);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i41);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i37);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i50);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i56);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i12);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i63);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i70);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i66);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i9);
Declare_label(mercury____Compare___vn_type__vnrval_0_0_i1001);
Define_extern_entry(mercury____Unify___vn_type__vn_src_0_0);
Declare_label(mercury____Unify___vn_type__vn_src_0_0_i1013);
Declare_label(mercury____Unify___vn_type__vn_src_0_0_i6);
Declare_label(mercury____Unify___vn_type__vn_src_0_0_i10);
Declare_label(mercury____Unify___vn_type__vn_src_0_0_i1010);
Declare_label(mercury____Unify___vn_type__vn_src_0_0_i1);
Declare_label(mercury____Unify___vn_type__vn_src_0_0_i1012);
Define_extern_entry(mercury____Index___vn_type__vn_src_0_0);
Declare_label(mercury____Index___vn_type__vn_src_0_0_i4);
Declare_label(mercury____Index___vn_type__vn_src_0_0_i5);
Declare_label(mercury____Index___vn_type__vn_src_0_0_i6);
Define_extern_entry(mercury____Compare___vn_type__vn_src_0_0);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i2);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i3);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i4);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i6);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i12);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i15);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i18);
Declare_label(mercury____Compare___vn_type__vn_src_0_0_i1000);
Define_extern_entry(mercury____Unify___vn_type__vn_node_0_0);
Declare_label(mercury____Unify___vn_type__vn_node_0_0_i1013);
Declare_label(mercury____Unify___vn_type__vn_node_0_0_i6);
Declare_label(mercury____Unify___vn_type__vn_node_0_0_i10);
Declare_label(mercury____Unify___vn_type__vn_node_0_0_i1010);
Declare_label(mercury____Unify___vn_type__vn_node_0_0_i1);
Declare_label(mercury____Unify___vn_type__vn_node_0_0_i1012);
Define_extern_entry(mercury____Index___vn_type__vn_node_0_0);
Declare_label(mercury____Index___vn_type__vn_node_0_0_i4);
Declare_label(mercury____Index___vn_type__vn_node_0_0_i5);
Declare_label(mercury____Index___vn_type__vn_node_0_0_i6);
Define_extern_entry(mercury____Compare___vn_type__vn_node_0_0);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i2);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i3);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i4);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i6);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i12);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i15);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i18);
Declare_label(mercury____Compare___vn_type__vn_node_0_0_i1000);
Define_extern_entry(mercury____Unify___vn_type__vn_instr_0_0);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1066);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1065);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1064);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1063);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1062);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1061);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1060);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1059);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1058);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1057);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1056);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1042);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1043);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1044);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1045);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1046);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1047);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1048);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1049);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1050);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1051);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1052);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1055);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i41);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i43);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i48);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i50);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i52);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1053);
Declare_label(mercury____Unify___vn_type__vn_instr_0_0_i1054);
Define_extern_entry(mercury____Index___vn_type__vn_instr_0_0);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i5);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i6);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i7);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i8);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i9);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i10);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i11);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i12);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i13);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i14);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i15);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i4);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i16);
Declare_label(mercury____Index___vn_type__vn_instr_0_0_i17);
Define_extern_entry(mercury____Compare___vn_type__vn_instr_0_0);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i2);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i3);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i4);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i6);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i13);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i17);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i18);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i16);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i23);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i30);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i33);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i36);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i40);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i46);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i50);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i56);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i59);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i62);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i65);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i68);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i72);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i78);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i12);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i81);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i83);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i89);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i95);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i101);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i9);
Declare_label(mercury____Compare___vn_type__vn_instr_0_0_i1001);
Define_extern_entry(mercury____Unify___vn_type__parentry_0_0);
Define_extern_entry(mercury____Index___vn_type__parentry_0_0);
Define_extern_entry(mercury____Compare___vn_type__parentry_0_0);
Define_extern_entry(mercury____Unify___vn_type__parallel_0_0);
Declare_label(mercury____Unify___vn_type__parallel_0_0_i2);
Declare_label(mercury____Unify___vn_type__parallel_0_0_i4);
Declare_label(mercury____Unify___vn_type__parallel_0_0_i1);
Define_extern_entry(mercury____Index___vn_type__parallel_0_0);
Define_extern_entry(mercury____Compare___vn_type__parallel_0_0);
Declare_label(mercury____Compare___vn_type__parallel_0_0_i4);
Declare_label(mercury____Compare___vn_type__parallel_0_0_i5);
Declare_label(mercury____Compare___vn_type__parallel_0_0_i3);
Declare_label(mercury____Compare___vn_type__parallel_0_0_i10);
Define_extern_entry(mercury____Unify___vn_type__vnlvalset_0_0);
Define_extern_entry(mercury____Index___vn_type__vnlvalset_0_0);
Define_extern_entry(mercury____Compare___vn_type__vnlvalset_0_0);
Define_extern_entry(mercury____Unify___vn_type__ctrlmap_0_0);
Define_extern_entry(mercury____Index___vn_type__ctrlmap_0_0);
Define_extern_entry(mercury____Compare___vn_type__ctrlmap_0_0);
Define_extern_entry(mercury____Unify___vn_type__flushmap_0_0);
Define_extern_entry(mercury____Index___vn_type__flushmap_0_0);
Define_extern_entry(mercury____Compare___vn_type__flushmap_0_0);
Define_extern_entry(mercury____Unify___vn_type__flushmapentry_0_0);
Define_extern_entry(mercury____Index___vn_type__flushmapentry_0_0);
Define_extern_entry(mercury____Compare___vn_type__flushmapentry_0_0);
Define_extern_entry(mercury____Unify___vn_type__parmap_0_0);
Define_extern_entry(mercury____Index___vn_type__parmap_0_0);
Define_extern_entry(mercury____Compare___vn_type__parmap_0_0);
Define_extern_entry(mercury____Unify___vn_type__vn_ctrl_tuple_0_0);
Declare_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i2);
Declare_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i4);
Declare_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1005);
Declare_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1);
Define_extern_entry(mercury____Index___vn_type__vn_ctrl_tuple_0_0);
Define_extern_entry(mercury____Compare___vn_type__vn_ctrl_tuple_0_0);
Declare_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i4);
Declare_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i5);
Declare_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i3);
Declare_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i10);
Declare_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i16);
Declare_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i22);
Define_extern_entry(mercury____Unify___vn_type__vn_params_0_0);
Declare_label(mercury____Unify___vn_type__vn_params_0_0_i1);
Define_extern_entry(mercury____Index___vn_type__vn_params_0_0);
Define_extern_entry(mercury____Compare___vn_type__vn_params_0_0);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i4);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i5);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i3);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i10);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i16);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i22);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i28);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i34);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i40);
Declare_label(mercury____Compare___vn_type__vn_params_0_0_i46);

extern Word * mercury_data_vn_type__base_type_layout_ctrlmap_0[];
Word * mercury_data_vn_type__base_type_info_ctrlmap_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__ctrlmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__ctrlmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__ctrlmap_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_ctrlmap_0
};

extern Word * mercury_data_vn_type__base_type_layout_flushmap_0[];
Word * mercury_data_vn_type__base_type_info_flushmap_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__flushmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__flushmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__flushmap_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_flushmap_0
};

extern Word * mercury_data_vn_type__base_type_layout_flushmapentry_0[];
Word * mercury_data_vn_type__base_type_info_flushmapentry_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__flushmapentry_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__flushmapentry_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__flushmapentry_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_flushmapentry_0
};

extern Word * mercury_data_vn_type__base_type_layout_parallel_0[];
Word * mercury_data_vn_type__base_type_info_parallel_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__parallel_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__parallel_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__parallel_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_parallel_0
};

extern Word * mercury_data_vn_type__base_type_layout_parentry_0[];
Word * mercury_data_vn_type__base_type_info_parentry_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__parentry_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__parentry_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__parentry_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_parentry_0
};

extern Word * mercury_data_vn_type__base_type_layout_parmap_0[];
Word * mercury_data_vn_type__base_type_info_parmap_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__parmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__parmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__parmap_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_parmap_0
};

extern Word * mercury_data_vn_type__base_type_layout_vn_0[];
Word * mercury_data_vn_type__base_type_info_vn_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vn_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vn_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vn_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vn_0
};

extern Word * mercury_data_vn_type__base_type_layout_vn_ctrl_tuple_0[];
Word * mercury_data_vn_type__base_type_info_vn_ctrl_tuple_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vn_ctrl_tuple_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vn_ctrl_tuple_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vn_ctrl_tuple_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vn_ctrl_tuple_0
};

extern Word * mercury_data_vn_type__base_type_layout_vn_instr_0[];
Word * mercury_data_vn_type__base_type_info_vn_instr_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vn_instr_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vn_instr_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vn_instr_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vn_instr_0
};

extern Word * mercury_data_vn_type__base_type_layout_vn_node_0[];
Word * mercury_data_vn_type__base_type_info_vn_node_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vn_node_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vn_node_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vn_node_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vn_node_0
};

extern Word * mercury_data_vn_type__base_type_layout_vn_params_0[];
Word * mercury_data_vn_type__base_type_info_vn_params_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vn_params_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vn_params_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vn_params_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vn_params_0
};

extern Word * mercury_data_vn_type__base_type_layout_vn_src_0[];
Word * mercury_data_vn_type__base_type_info_vn_src_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vn_src_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vn_src_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vn_src_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vn_src_0
};

extern Word * mercury_data_vn_type__base_type_layout_vnlval_0[];
Word * mercury_data_vn_type__base_type_info_vnlval_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vnlval_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vnlval_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vnlval_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vnlval_0
};

extern Word * mercury_data_vn_type__base_type_layout_vnlvalset_0[];
Word * mercury_data_vn_type__base_type_info_vnlvalset_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vnlvalset_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vnlvalset_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vnlvalset_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vnlvalset_0
};

extern Word * mercury_data_vn_type__base_type_layout_vnrval_0[];
Word * mercury_data_vn_type__base_type_info_vnrval_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___vn_type__vnrval_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___vn_type__vnrval_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___vn_type__vnrval_0_0),
	(Word *) (Integer) mercury_data_vn_type__base_type_layout_vnrval_0
};

extern Word * mercury_data_vn_type__common_6[];
extern Word * mercury_data_vn_type__common_8[];
extern Word * mercury_data_vn_type__common_10[];
extern Word * mercury_data_vn_type__common_18[];
Word * mercury_data_vn_type__base_type_layout_vnrval_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_6),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_8),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_10),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_vn_type__common_18)
};

extern Word * mercury_data_vn_type__common_20[];
Word * mercury_data_vn_type__base_type_layout_vnlvalset_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_20),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_20),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_20),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_20)
};

extern Word * mercury_data_vn_type__common_21[];
extern Word * mercury_data_vn_type__common_23[];
extern Word * mercury_data_vn_type__common_24[];
extern Word * mercury_data_vn_type__common_32[];
Word * mercury_data_vn_type__base_type_layout_vnlval_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_21),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_23),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_24),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_vn_type__common_32)
};

extern Word * mercury_data_vn_type__common_33[];
extern Word * mercury_data_vn_type__common_34[];
extern Word * mercury_data_vn_type__common_35[];
extern Word * mercury_data_vn_type__common_36[];
Word * mercury_data_vn_type__base_type_layout_vn_src_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_33),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_34),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_35),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_36)
};

extern Word * mercury_data_vn_type__common_37[];
Word * mercury_data_vn_type__base_type_layout_vn_params_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_37),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_vn_type__common_38[];
extern Word * mercury_data_vn_type__common_39[];
extern Word * mercury_data_vn_type__common_40[];
extern Word * mercury_data_vn_type__common_41[];
Word * mercury_data_vn_type__base_type_layout_vn_node_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_38),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_39),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_40),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_41)
};

extern Word * mercury_data_vn_type__common_42[];
extern Word * mercury_data_vn_type__common_44[];
extern Word * mercury_data_vn_type__common_48[];
extern Word * mercury_data_vn_type__common_63[];
Word * mercury_data_vn_type__base_type_layout_vn_instr_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_42),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_44),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_48),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_vn_type__common_63)
};

extern Word * mercury_data_vn_type__common_67[];
Word * mercury_data_vn_type__base_type_layout_vn_ctrl_tuple_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_67),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_vn_type__common_68[];
Word * mercury_data_vn_type__base_type_layout_vn_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_68),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_68),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_68),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_68)
};

extern Word * mercury_data_vn_type__common_69[];
Word * mercury_data_vn_type__base_type_layout_parmap_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_69),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_69),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_69),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_69)
};

extern Word * mercury_data_vn_type__common_70[];
Word * mercury_data_vn_type__base_type_layout_parentry_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_70),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_70),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_70),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_70)
};

extern Word * mercury_data_vn_type__common_72[];
Word * mercury_data_vn_type__base_type_layout_parallel_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_72),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_vn_type__common_73[];
Word * mercury_data_vn_type__base_type_layout_flushmapentry_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_73),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_73),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_73),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_73)
};

extern Word * mercury_data_vn_type__common_74[];
Word * mercury_data_vn_type__base_type_layout_flushmap_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_74),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_74),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_74),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_74)
};

extern Word * mercury_data_vn_type__common_75[];
Word * mercury_data_vn_type__base_type_layout_ctrlmap_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_75),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_75),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_75),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_vn_type__common_75)
};

extern Word * mercury_data_std_util__base_type_info_maybe_1[];
extern Word * mercury_data_llds__base_type_info_rval_0[];
Word * mercury_data_vn_type__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_maybe_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_rval_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_vn_type__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_rval_0
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_lval_0[];
Word * mercury_data_vn_type__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_1)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_vn_type__common_3[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_vn_type__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_parallel_0
};

Word * mercury_data_vn_type__common_5[] = {
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0
};

Word * mercury_data_vn_type__common_6[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("vn_origlval", 11)
};

Word * mercury_data_vn_type__common_7[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_vn_type__common_8[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_mkword", 9)
};

extern Word * mercury_data_llds__base_type_info_rval_const_0[];
Word * mercury_data_vn_type__common_9[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_rval_const_0
};

Word * mercury_data_vn_type__common_10[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_9),
	(Word *) string_const("vn_const", 8)
};

Word * mercury_data_vn_type__common_11[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_0)
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_vn_type__common_12[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_vn_type__common_13[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_create", 9)
};

extern Word * mercury_data_llds__base_type_info_unary_op_0[];
Word * mercury_data_vn_type__common_14[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_unary_op_0
};

Word * mercury_data_vn_type__common_15[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_14),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_unop", 7)
};

extern Word * mercury_data_llds__base_type_info_binary_op_0[];
Word * mercury_data_vn_type__common_16[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_binary_op_0
};

Word * mercury_data_vn_type__common_17[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_16),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_binop", 8)
};

Word * mercury_data_vn_type__common_18[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_13),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_15),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_17)
};

extern Word * mercury_data_set__base_type_info_set_1[];
Word * mercury_data_vn_type__common_19[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vnlval_0
};

Word * mercury_data_vn_type__common_20[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_19)
};

Word * mercury_data_vn_type__common_21[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 5),
	(Word *) string_const("vn_succip", 9),
	(Word *) string_const("vn_maxfr", 8),
	(Word *) string_const("vn_curfr", 8),
	(Word *) string_const("vn_hp", 5),
	(Word *) string_const("vn_sp", 5)
};

extern Word * mercury_data_llds__base_type_info_reg_0[];
Word * mercury_data_vn_type__common_22[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_reg_0
};

Word * mercury_data_vn_type__common_23[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_22),
	(Word *) string_const("vn_reg", 6)
};

Word * mercury_data_vn_type__common_24[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_stackvar", 11)
};

Word * mercury_data_vn_type__common_25[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_framevar", 11)
};

Word * mercury_data_vn_type__common_26[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_succfr", 9)
};

Word * mercury_data_vn_type__common_27[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_prevfr", 9)
};

Word * mercury_data_vn_type__common_28[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_redoip", 9)
};

Word * mercury_data_vn_type__common_29[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_succip", 9)
};

Word * mercury_data_vn_type__common_30[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_field", 8)
};

Word * mercury_data_vn_type__common_31[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_22),
	(Word *) string_const("vn_temp", 7)
};

Word * mercury_data_vn_type__common_32[] = {
	(Word *) ((Integer) 7),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_25),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_26),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_27),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_28),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_29),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_30),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_31)
};

Word * mercury_data_vn_type__common_33[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("src_ctrl", 8)
};

Word * mercury_data_vn_type__common_34[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("src_liveval", 11)
};

Word * mercury_data_vn_type__common_35[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("src_access", 10)
};

Word * mercury_data_vn_type__common_36[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("src_vn", 6)
};

Word * mercury_data_vn_type__common_37[] = {
	(Word *) ((Integer) 9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_params", 9)
};

Word * mercury_data_vn_type__common_38[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("node_shared", 11)
};

Word * mercury_data_vn_type__common_39[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("node_lval", 9)
};

Word * mercury_data_vn_type__common_40[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("node_origlval", 13)
};

Word * mercury_data_vn_type__common_41[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("node_ctrl", 9)
};

Word * mercury_data_vn_type__common_42[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("vn_discard_ticket", 17)
};

Word * mercury_data_vn_type__common_43[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0
};

Word * mercury_data_vn_type__common_44[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_43),
	(Word *) string_const("vn_livevals", 11)
};

extern Word * mercury_data_llds__base_type_info_code_addr_0[];
Word * mercury_data_vn_type__common_45[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_code_addr_0
};

extern Word * mercury_data_llds__base_type_info_liveinfo_0[];
Word * mercury_data_vn_type__common_46[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_liveinfo_0
};

extern Word * mercury_data_llds__base_type_info_call_model_0[];
Word * mercury_data_vn_type__common_47[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_call_model_0
};

Word * mercury_data_vn_type__common_48[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_45),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_45),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_46),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_47),
	(Word *) string_const("vn_call", 7)
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_vn_type__common_49[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_vn_type__common_50[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_49),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_45),
	(Word *) string_const("vn_mkframe", 10)
};

extern Word * mercury_data_llds__base_type_info_label_0[];
Word * mercury_data_vn_type__common_51[] = {
	(Word *) (Integer) mercury_data_llds__base_type_info_label_0
};

Word * mercury_data_vn_type__common_52[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_51),
	(Word *) string_const("vn_label", 8)
};

Word * mercury_data_vn_type__common_53[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_45),
	(Word *) string_const("vn_goto", 7)
};

Word * mercury_data_vn_type__common_54[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_label_0
};

Word * mercury_data_vn_type__common_55[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_54),
	(Word *) string_const("vn_computed_goto", 16)
};

Word * mercury_data_vn_type__common_56[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_45),
	(Word *) string_const("vn_if_val", 9)
};

Word * mercury_data_vn_type__common_57[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("vn_mark_hp", 10)
};

Word * mercury_data_vn_type__common_58[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_restore_hp", 13)
};

Word * mercury_data_vn_type__common_59[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_5),
	(Word *) string_const("vn_store_ticket", 15)
};

Word * mercury_data_vn_type__common_60[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_restore_ticket", 17)
};

Word * mercury_data_vn_type__common_61[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_49),
	(Word *) string_const("vn_incr_sp", 10)
};

Word * mercury_data_vn_type__common_62[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) string_const("vn_decr_sp", 10)
};

Word * mercury_data_vn_type__common_63[] = {
	(Word *) ((Integer) 11),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_50),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_52),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_53),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_55),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_56),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_57),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_58),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_59),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_60),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_61),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_vn_type__common_62)
};

Word * mercury_data_vn_type__common_64[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data_vn_type__base_type_info_vn_instr_0
};

Word * mercury_data_vn_type__common_65[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3)
};

Word * mercury_data_vn_type__common_66[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_4)
};

Word * mercury_data_vn_type__common_67[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_64),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_65),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_66),
	(Word *) string_const("tuple", 5)
};

Word * mercury_data_vn_type__common_68[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_7)
};

Word * mercury_data_vn_type__common_69[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_66)
};

Word * mercury_data_vn_type__common_70[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_2)
};

Word * mercury_data_vn_type__common_71[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_2)
};

Word * mercury_data_vn_type__common_72[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_51),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_51),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_71),
	(Word *) string_const("parallel", 8)
};

Word * mercury_data_vn_type__common_73[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3)
};

Word * mercury_data_vn_type__common_74[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_65)
};

Word * mercury_data_vn_type__common_75[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_64)
};

BEGIN_MODULE(mercury__vn_type_module0)
	init_entry(mercury____Index___vn_type_vn_params_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_type_vn_params_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___vn_type_vn_params_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module1)
	init_entry(mercury____Index___vn_type_vn_ctrl_tuple_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_type_vn_ctrl_tuple_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___vn_type_vn_ctrl_tuple_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module2)
	init_entry(mercury____Index___vn_type_parallel_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_type_parallel_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___vn_type_parallel_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module3)
	init_entry(mercury__vn_type__vnlval_type_2_0);
	init_label(mercury__vn_type__vnlval_type_2_0_i5);
	init_label(mercury__vn_type__vnlval_type_2_0_i1003);
	init_label(mercury__vn_type__vnlval_type_2_0_i1000);
	init_label(mercury__vn_type__vnlval_type_2_0_i1001);
	init_label(mercury__vn_type__vnlval_type_2_0_i1002);
BEGIN_CODE

/* code for predicate 'vn_type__vnlval_type'/2 in mode 0 */
Define_entry(mercury__vn_type__vnlval_type_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_type__vnlval_type_2_0_i1003);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_type__vnlval_type_2_0_i1000) AND
		LABEL(mercury__vn_type__vnlval_type_2_0_i1000) AND
		LABEL(mercury__vn_type__vnlval_type_2_0_i1000) AND
		LABEL(mercury__vn_type__vnlval_type_2_0_i1000) AND
		LABEL(mercury__vn_type__vnlval_type_2_0_i1000) AND
		LABEL(mercury__vn_type__vnlval_type_2_0_i1000) AND
		LABEL(mercury__vn_type__vnlval_type_2_0_i1001));
Define_label(mercury__vn_type__vnlval_type_2_0_i5);
	r1 = ((Integer) 4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_type__vnlval_type_2_0_i1003);
	incr_sp_push_msg(1, "vn_type__vnlval_type");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_type__vnlval_type_2_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_type__vnlval_type_2_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__llds__register_type_2_0);
	tailcall(ENTRY(mercury__llds__register_type_2_0),
		ENTRY(mercury__vn_type__vnlval_type_2_0));
	}
Define_label(mercury__vn_type__vnlval_type_2_0_i1000);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury__vn_type__vnlval_type_2_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__llds__register_type_2_0);
	tailcall(ENTRY(mercury__llds__register_type_2_0),
		ENTRY(mercury__vn_type__vnlval_type_2_0));
	}
Define_label(mercury__vn_type__vnlval_type_2_0_i1002);
	r1 = ((Integer) 4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module4)
	init_entry(mercury__vn_type__vnrval_type_2_0);
	init_label(mercury__vn_type__vnrval_type_2_0_i1003);
	init_label(mercury__vn_type__vnrval_type_2_0_i1002);
	init_label(mercury__vn_type__vnrval_type_2_0_i9);
	init_label(mercury__vn_type__vnrval_type_2_0_i1000);
	init_label(mercury__vn_type__vnrval_type_2_0_i1001);
BEGIN_CODE

/* code for predicate 'vn_type__vnrval_type'/2 in mode 0 */
Define_entry(mercury__vn_type__vnrval_type_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_type__vnrval_type_2_0_i1002);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_type__vnrval_type_2_0_i1003);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury__vn_type__vnrval_type_2_0_i1003);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_type__vnrval_type_2_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__llds__unop_return_type_2_0);
	tailcall(ENTRY(mercury__llds__unop_return_type_2_0),
		ENTRY(mercury__vn_type__vnrval_type_2_0));
	}
Define_label(mercury__vn_type__vnrval_type_2_0_i1002);
	incr_sp_push_msg(1, "vn_type__vnrval_type");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_type__vnrval_type_2_0_i9);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__vn_type__vnlval_type_2_0),
		ENTRY(mercury__vn_type__vnrval_type_2_0));
	}
Define_label(mercury__vn_type__vnrval_type_2_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_type__vnrval_type_2_0_i1001);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury__vn_type__vnrval_type_2_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__llds__binop_return_type_2_0);
	tailcall(ENTRY(mercury__llds__binop_return_type_2_0),
		ENTRY(mercury__vn_type__vnrval_type_2_0));
	}
Define_label(mercury__vn_type__vnrval_type_2_0_i1001);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__llds__const_type_2_0);
	tailcall(ENTRY(mercury__llds__const_type_2_0),
		ENTRY(mercury__vn_type__vnrval_type_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module5)
	init_entry(mercury__vn_type__init_params_2_0);
	init_label(mercury__vn_type__init_params_2_0_i2);
	init_label(mercury__vn_type__init_params_2_0_i3);
	init_label(mercury__vn_type__init_params_2_0_i4);
	init_label(mercury__vn_type__init_params_2_0_i5);
	init_label(mercury__vn_type__init_params_2_0_i6);
BEGIN_CODE

/* code for predicate 'vn_type__init_params'/2 in mode 0 */
Define_entry(mercury__vn_type__init_params_2_0);
	r2 = (Integer) r1;
	incr_sp_push_msg(5, "vn_type__init_params");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r3 = ((Integer) 73);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__vn_type__init_params_2_0_i2,
		ENTRY(mercury__vn_type__init_params_2_0));
	}
Define_label(mercury__vn_type__init_params_2_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_type__init_params_2_0));
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 74);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__vn_type__init_params_2_0_i3,
		ENTRY(mercury__vn_type__init_params_2_0));
	}
Define_label(mercury__vn_type__init_params_2_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_type__init_params_2_0));
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 75);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__vn_type__init_params_2_0_i4,
		ENTRY(mercury__vn_type__init_params_2_0));
	}
Define_label(mercury__vn_type__init_params_2_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_type__init_params_2_0));
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 76);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__vn_type__init_params_2_0_i5,
		ENTRY(mercury__vn_type__init_params_2_0));
	}
Define_label(mercury__vn_type__init_params_2_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_type__init_params_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r3 = ((Integer) 59);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__vn_type__init_params_2_0_i6,
		ENTRY(mercury__vn_type__init_params_2_0));
	}
Define_label(mercury__vn_type__init_params_2_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_type__init_params_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = ((Integer) 1);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = ((Integer) 1);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = ((Integer) 2);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module6)
	init_entry(mercury__vn_type__bytes_per_word_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__bytes_per_word'/2 in mode 0 */
Define_entry(mercury__vn_type__bytes_per_word_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module7)
	init_entry(mercury__vn_type__real_r_regs_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__real_r_regs'/2 in mode 0 */
Define_entry(mercury__vn_type__real_r_regs_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module8)
	init_entry(mercury__vn_type__real_f_regs_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__real_f_regs'/2 in mode 0 */
Define_entry(mercury__vn_type__real_f_regs_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module9)
	init_entry(mercury__vn_type__real_r_temps_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__real_r_temps'/2 in mode 0 */
Define_entry(mercury__vn_type__real_r_temps_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module10)
	init_entry(mercury__vn_type__real_f_temps_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__real_f_temps'/2 in mode 0 */
Define_entry(mercury__vn_type__real_f_temps_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module11)
	init_entry(mercury__vn_type__costof_assign_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__costof_assign'/2 in mode 0 */
Define_entry(mercury__vn_type__costof_assign_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module12)
	init_entry(mercury__vn_type__costof_intops_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__costof_intops'/2 in mode 0 */
Define_entry(mercury__vn_type__costof_intops_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module13)
	init_entry(mercury__vn_type__costof_stackref_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__costof_stackref'/2 in mode 0 */
Define_entry(mercury__vn_type__costof_stackref_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module14)
	init_entry(mercury__vn_type__costof_heapref_2_0);
BEGIN_CODE

/* code for predicate 'vn_type__costof_heapref'/2 in mode 0 */
Define_entry(mercury__vn_type__costof_heapref_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module15)
	init_entry(mercury____Unify___vn_type__vn_0_0);
	init_label(mercury____Unify___vn_type__vn_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vn_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___vn_type__vn_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module16)
	init_entry(mercury____Index___vn_type__vn_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vn_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___vn_type__vn_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module17)
	init_entry(mercury____Compare___vn_type__vn_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vn_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module18)
	init_entry(mercury____Unify___vn_type__vnlval_0_0);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1050);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1049);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1048);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1047);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1046);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1045);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1044);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1034);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1035);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1036);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1037);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1038);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1039);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1040);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1043);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i22);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i24);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i26);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i28);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i30);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i21);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i32);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1041);
	init_label(mercury____Unify___vn_type__vnlval_0_0_i1042);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vnlval_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1043);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1050) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1049) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1048) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1047) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1046) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1045) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i1044));
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1050);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1034);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1049);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1035);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1048);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1036);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1047);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1037);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1046);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1038);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1045);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1039);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1044);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1040);
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1034);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1035);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1036);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1037);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 3)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1038);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 4)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1039);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 5)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 3)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1040);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	decr_sp_pop_msg(1);
	if (((Integer) r3 != ((Integer) 6)))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___llds__reg_0_0);
	tailcall(ENTRY(mercury____Unify___llds__reg_0_0),
		ENTRY(mercury____Unify___vn_type__vnlval_0_0));
	}
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1043);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i21);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i22) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i24) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i26) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i28) AND
		LABEL(mercury____Unify___vn_type__vnlval_0_0_i30));
Define_label(mercury____Unify___vn_type__vnlval_0_0_i22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1041);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i24);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1041);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1041);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i28);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1041);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i30);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1041);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i21);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i32);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__reg_0_0);
	tailcall(ENTRY(mercury____Unify___llds__reg_0_0),
		ENTRY(mercury____Unify___vn_type__vnlval_0_0));
	}
Define_label(mercury____Unify___vn_type__vnlval_0_0_i32);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vnlval_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1041);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnlval_0_0_i1042);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module19)
	init_entry(mercury____Index___vn_type__vnlval_0_0);
	init_label(mercury____Index___vn_type__vnlval_0_0_i5);
	init_label(mercury____Index___vn_type__vnlval_0_0_i6);
	init_label(mercury____Index___vn_type__vnlval_0_0_i7);
	init_label(mercury____Index___vn_type__vnlval_0_0_i8);
	init_label(mercury____Index___vn_type__vnlval_0_0_i9);
	init_label(mercury____Index___vn_type__vnlval_0_0_i10);
	init_label(mercury____Index___vn_type__vnlval_0_0_i11);
	init_label(mercury____Index___vn_type__vnlval_0_0_i4);
	init_label(mercury____Index___vn_type__vnlval_0_0_i13);
	init_label(mercury____Index___vn_type__vnlval_0_0_i14);
	init_label(mercury____Index___vn_type__vnlval_0_0_i15);
	init_label(mercury____Index___vn_type__vnlval_0_0_i16);
	init_label(mercury____Index___vn_type__vnlval_0_0_i17);
	init_label(mercury____Index___vn_type__vnlval_0_0_i12);
	init_label(mercury____Index___vn_type__vnlval_0_0_i18);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vnlval_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___vn_type__vnlval_0_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Index___vn_type__vnlval_0_0_i5) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i6) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i7) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i8) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i9) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i10) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i11));
Define_label(mercury____Index___vn_type__vnlval_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i6);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i7);
	r1 = ((Integer) 7);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i8);
	r1 = ((Integer) 8);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i9);
	r1 = ((Integer) 9);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i10);
	r1 = ((Integer) 12);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i11);
	r1 = ((Integer) 13);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___vn_type__vnlval_0_0_i12);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Index___vn_type__vnlval_0_0_i13) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i14) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i15) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i16) AND
		LABEL(mercury____Index___vn_type__vnlval_0_0_i17));
Define_label(mercury____Index___vn_type__vnlval_0_0_i13);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i14);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i15);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i16);
	r1 = ((Integer) 10);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i17);
	r1 = ((Integer) 11);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___vn_type__vnlval_0_0_i18);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___vn_type__vnlval_0_0_i18);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module20)
	init_entry(mercury____Compare___vn_type__vnlval_0_0);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i2);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i3);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i4);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i6);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i13);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i16);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i19);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i22);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i25);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i28);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i32);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i33);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i31);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i38);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i45);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i12);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i49);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i51);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i53);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i55);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i57);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i48);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i59);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i9);
	init_label(mercury____Compare___vn_type__vnlval_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vnlval_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___vn_type__vnlval_0_0),
		mercury____Compare___vn_type__vnlval_0_0_i2,
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnlval_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___vn_type__vnlval_0_0),
		mercury____Compare___vn_type__vnlval_0_0_i3,
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnlval_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i12);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i13) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i16) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i19) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i22) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i25) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i28) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i45));
Define_label(mercury____Compare___vn_type__vnlval_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i16);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i19);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i22);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i25);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i28);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnlval_0_0_i32,
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i32);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnlval_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i31);
Define_label(mercury____Compare___vn_type__vnlval_0_0_i33);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i31);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnlval_0_0_i38,
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i38);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnlval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i33);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i45);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___llds__reg_0_0);
	tailcall(ENTRY(mercury____Compare___llds__reg_0_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i48);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i49) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i51) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i53) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i55) AND
		LABEL(mercury____Compare___vn_type__vnlval_0_0_i57));
Define_label(mercury____Compare___vn_type__vnlval_0_0_i49);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i51);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i53);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i55);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i57);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__vnlval_0_0_i48);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i59);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___llds__reg_0_0);
	tailcall(ENTRY(mercury____Compare___llds__reg_0_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i59);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vnlval_0_0_i1001);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnlval_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vnlval_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module21)
	init_entry(mercury____Unify___vn_type__vnrval_0_0);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i7);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i9);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i1032);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i11);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i1031);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i14);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i18);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i1028);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i1);
	init_label(mercury____Unify___vn_type__vnrval_0_0_i1030);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vnrval_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1031);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1032);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1028);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1028);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1028);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 4));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_0);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___vn_type__vnrval_0_0_i7,
		ENTRY(mercury____Unify___vn_type__vnrval_0_0));
	}
Define_label(mercury____Unify___vn_type__vnrval_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vnrval_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___bool__bool_0_0);
	call_localret(ENTRY(mercury____Unify___bool__bool_0_0),
		mercury____Unify___vn_type__vnrval_0_0_i9,
		ENTRY(mercury____Unify___vn_type__vnrval_0_0));
	}
Define_label(mercury____Unify___vn_type__vnrval_0_0_i9);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vnrval_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___vn_type__vnrval_0_0_i1032);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i11);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1030);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnrval_0_0_i11);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 3)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1030);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnrval_0_0_i1031);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1030);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vnrval_0_0));
	}
Define_label(mercury____Unify___vn_type__vnrval_0_0_i14);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i18);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1030);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vnrval_0_0_i18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vnrval_0_0_i1030);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__rval_const_0_0);
	tailcall(ENTRY(mercury____Unify___llds__rval_const_0_0),
		ENTRY(mercury____Unify___vn_type__vnrval_0_0));
	}
Define_label(mercury____Unify___vn_type__vnrval_0_0_i1028);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vnrval_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___vn_type__vnrval_0_0_i1030);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module22)
	init_entry(mercury____Index___vn_type__vnrval_0_0);
	init_label(mercury____Index___vn_type__vnrval_0_0_i5);
	init_label(mercury____Index___vn_type__vnrval_0_0_i6);
	init_label(mercury____Index___vn_type__vnrval_0_0_i4);
	init_label(mercury____Index___vn_type__vnrval_0_0_i7);
	init_label(mercury____Index___vn_type__vnrval_0_0_i8);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vnrval_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___vn_type__vnrval_0_0_i4);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Index___vn_type__vnrval_0_0_i5);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___vn_type__vnrval_0_0_i5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury____Index___vn_type__vnrval_0_0_i6);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___vn_type__vnrval_0_0_i6);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___vn_type__vnrval_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___vn_type__vnrval_0_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___vn_type__vnrval_0_0_i7);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___vn_type__vnrval_0_0_i8);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___vn_type__vnrval_0_0_i8);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module23)
	init_entry(mercury____Compare___vn_type__vnrval_0_0);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i2);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i3);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i4);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i6);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i17);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i18);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i16);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i23);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i29);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i13);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i41);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i37);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i50);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i56);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i12);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i63);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i70);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i66);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i9);
	init_label(mercury____Compare___vn_type__vnrval_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vnrval_0_0);
	incr_sp_push_msg(7, "__Compare__");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___vn_type__vnrval_0_0),
		mercury____Compare___vn_type__vnrval_0_0_i2,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___vn_type__vnrval_0_0),
		mercury____Compare___vn_type__vnrval_0_0_i3,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vnrval_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vnrval_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i12);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnrval_0_0_i17,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i17);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i16);
Define_label(mercury____Compare___vn_type__vnrval_0_0_i18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vnrval_0_0_i16);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_0);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___vn_type__vnrval_0_0_i23,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i18);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___bool__bool_0_0);
	call_localret(ENTRY(mercury____Compare___bool__bool_0_0),
		mercury____Compare___vn_type__vnrval_0_0_i29,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i29);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i18);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i13);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i37);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnrval_0_0_i41,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i41);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i37);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnrval_0_0_i50,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i50);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnrval_0_0_i56,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i56);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i18);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i63);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i1001);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i63);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i66);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vnrval_0_0_i70,
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i70);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vnrval_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i66);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vnrval_0_0_i1001);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___llds__rval_const_0_0);
	tailcall(ENTRY(mercury____Compare___llds__rval_const_0_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
Define_label(mercury____Compare___vn_type__vnrval_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vnrval_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module24)
	init_entry(mercury____Unify___vn_type__vn_src_0_0);
	init_label(mercury____Unify___vn_type__vn_src_0_0_i1013);
	init_label(mercury____Unify___vn_type__vn_src_0_0_i6);
	init_label(mercury____Unify___vn_type__vn_src_0_0_i10);
	init_label(mercury____Unify___vn_type__vn_src_0_0_i1010);
	init_label(mercury____Unify___vn_type__vn_src_0_0_i1);
	init_label(mercury____Unify___vn_type__vn_src_0_0_i1012);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vn_src_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1013);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1010);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_src_0_0_i1013);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1012);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vn_src_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_src_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1012);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vn_src_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_src_0_0_i10);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_src_0_0_i1012);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_src_0_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_src_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___vn_type__vn_src_0_0_i1012);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module25)
	init_entry(mercury____Index___vn_type__vn_src_0_0);
	init_label(mercury____Index___vn_type__vn_src_0_0_i4);
	init_label(mercury____Index___vn_type__vn_src_0_0_i5);
	init_label(mercury____Index___vn_type__vn_src_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vn_src_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___vn_type__vn_src_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___vn_type__vn_src_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___vn_type__vn_src_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___vn_type__vn_src_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___vn_type__vn_src_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___vn_type__vn_src_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module26)
	init_entry(mercury____Compare___vn_type__vn_src_0_0);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i2);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i3);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i4);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i6);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i12);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i15);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i18);
	init_label(mercury____Compare___vn_type__vn_src_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vn_src_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___vn_type__vn_src_0_0),
		mercury____Compare___vn_type__vn_src_0_0_i2,
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_src_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_src_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___vn_type__vn_src_0_0),
		mercury____Compare___vn_type__vn_src_0_0_i3,
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_src_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_src_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_type__vn_src_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_type__vn_src_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i12);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_src_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i15);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_src_0_0_i15);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i18);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_src_0_0_i18);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_src_0_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_src_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vn_src_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module27)
	init_entry(mercury____Unify___vn_type__vn_node_0_0);
	init_label(mercury____Unify___vn_type__vn_node_0_0_i1013);
	init_label(mercury____Unify___vn_type__vn_node_0_0_i6);
	init_label(mercury____Unify___vn_type__vn_node_0_0_i10);
	init_label(mercury____Unify___vn_type__vn_node_0_0_i1010);
	init_label(mercury____Unify___vn_type__vn_node_0_0_i1);
	init_label(mercury____Unify___vn_type__vn_node_0_0_i1012);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vn_node_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1013);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1010);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_node_0_0_i1013);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1012);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vn_node_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_node_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1012);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vn_node_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_node_0_0_i10);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_node_0_0_i1012);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_node_0_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_node_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___vn_type__vn_node_0_0_i1012);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module28)
	init_entry(mercury____Index___vn_type__vn_node_0_0);
	init_label(mercury____Index___vn_type__vn_node_0_0_i4);
	init_label(mercury____Index___vn_type__vn_node_0_0_i5);
	init_label(mercury____Index___vn_type__vn_node_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vn_node_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___vn_type__vn_node_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___vn_type__vn_node_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___vn_type__vn_node_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___vn_type__vn_node_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___vn_type__vn_node_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___vn_type__vn_node_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module29)
	init_entry(mercury____Compare___vn_type__vn_node_0_0);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i2);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i3);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i4);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i6);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i12);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i15);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i18);
	init_label(mercury____Compare___vn_type__vn_node_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vn_node_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___vn_type__vn_node_0_0),
		mercury____Compare___vn_type__vn_node_0_0_i2,
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_node_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_node_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___vn_type__vn_node_0_0),
		mercury____Compare___vn_type__vn_node_0_0_i3,
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_node_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_node_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_type__vn_node_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___vn_type__vn_node_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i12);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_node_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i15);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_node_0_0_i15);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i18);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_node_0_0_i18);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_node_0_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_node_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vn_node_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module30)
	init_entry(mercury____Unify___vn_type__vn_instr_0_0);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1066);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1065);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1064);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1063);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1062);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1061);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1060);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1059);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1058);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1057);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1056);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1042);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1043);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1044);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1045);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1046);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1047);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1048);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1049);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1050);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1051);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1052);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1055);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i41);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i43);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i48);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i50);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i52);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1053);
	init_label(mercury____Unify___vn_type__vn_instr_0_0_i1054);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vn_instr_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1055);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1066) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1065) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1064) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1063) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1062) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1061) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1060) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1059) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1058) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1057) AND
		LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1056));
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1066);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1042);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1065);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1043);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1064);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1044);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1063);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1045);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1062);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1046);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1061);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1047);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1060);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1048);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1059);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1049);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1058);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1050);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1057);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1051);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1056);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1052);
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1042);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) !=0))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	tailcall(ENTRY(mercury____Unify___llds__code_addr_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1043);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	decr_sp_pop_msg(7);
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	tailcall(ENTRY(mercury____Unify___llds__label_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1044);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	decr_sp_pop_msg(7);
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	tailcall(ENTRY(mercury____Unify___llds__code_addr_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1045);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1046);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 4)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	tailcall(ENTRY(mercury____Unify___llds__code_addr_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1047);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	decr_sp_pop_msg(7);
	if (((Integer) r3 != ((Integer) 5)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1048);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 6)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1049);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	decr_sp_pop_msg(7);
	if (((Integer) r3 != ((Integer) 7)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	{
		tailcall(STATIC(mercury____Unify___vn_type__vnlval_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1050);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 8)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1051);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 9)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 2))) !=0))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1052);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 10)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1055);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i41);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1053);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i41);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i43);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i43);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	call_localret(ENTRY(mercury____Unify___llds__code_addr_0_0),
		mercury____Unify___vn_type__vn_instr_0_0_i48,
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i48);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vn_instr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___llds__code_addr_0_0);
	call_localret(ENTRY(mercury____Unify___llds__code_addr_0_0),
		mercury____Unify___vn_type__vn_instr_0_0_i50,
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i50);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vn_instr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r1 = (Integer) mercury_data_llds__base_type_info_liveinfo_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___vn_type__vn_instr_0_0_i52,
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i52);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vn_instr_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Unify___llds__call_model_0_0);
	tailcall(ENTRY(mercury____Unify___llds__call_model_0_0),
		ENTRY(mercury____Unify___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1053);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_instr_0_0_i1054);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module31)
	init_entry(mercury____Index___vn_type__vn_instr_0_0);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i5);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i6);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i7);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i8);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i9);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i10);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i11);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i12);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i13);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i14);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i15);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i4);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i16);
	init_label(mercury____Index___vn_type__vn_instr_0_0_i17);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vn_instr_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___vn_type__vn_instr_0_0_i4);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i5) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i6) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i7) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i8) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i9) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i10) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i11) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i12) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i13) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i14) AND
		LABEL(mercury____Index___vn_type__vn_instr_0_0_i15));
Define_label(mercury____Index___vn_type__vn_instr_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i7);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i8);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i9);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i10);
	r1 = ((Integer) 7);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i11);
	r1 = ((Integer) 8);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i12);
	r1 = ((Integer) 9);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i13);
	r1 = ((Integer) 10);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i14);
	r1 = ((Integer) 12);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i15);
	r1 = ((Integer) 13);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___vn_type__vn_instr_0_0_i16);
	r1 = ((Integer) 11);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i16);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___vn_type__vn_instr_0_0_i17);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___vn_type__vn_instr_0_0_i17);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module32)
	init_entry(mercury____Compare___vn_type__vn_instr_0_0);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i2);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i3);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i4);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i6);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i13);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i17);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i18);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i16);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i23);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i30);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i33);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i36);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i40);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i46);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i50);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i56);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i59);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i62);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i65);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i68);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i72);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i78);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i12);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i81);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i83);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i89);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i95);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i101);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i9);
	init_label(mercury____Compare___vn_type__vn_instr_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vn_instr_0_0);
	incr_sp_push_msg(7, "__Compare__");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___vn_type__vn_instr_0_0),
		mercury____Compare___vn_type__vn_instr_0_0_i2,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___vn_type__vn_instr_0_0),
		mercury____Compare___vn_type__vn_instr_0_0_i3,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i12);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i13) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i30) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i33) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i36) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i46) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i56) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i59) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i62) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i65) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i68) AND
		LABEL(mercury____Compare___vn_type__vn_instr_0_0_i78));
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i13);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___vn_type__vn_instr_0_0_i17,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i17);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i16);
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_instr_0_0_i23,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Compare___llds__code_addr_0_0);
	tailcall(ENTRY(mercury____Compare___llds__code_addr_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i30);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___llds__label_0_0);
	tailcall(ENTRY(mercury____Compare___llds__label_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i33);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___llds__code_addr_0_0);
	tailcall(ENTRY(mercury____Compare___llds__code_addr_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i36);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_instr_0_0_i40,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i46);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_instr_0_0_i50,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i50);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Compare___llds__code_addr_0_0);
	tailcall(ENTRY(mercury____Compare___llds__code_addr_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i56);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i59);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 6)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i62);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 7)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
		tailcall(STATIC(mercury____Compare___vn_type__vnlval_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i65);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 8)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i68);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 9)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_instr_0_0_i72,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i72);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i78);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 10)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i81);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i81);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i83);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if ((tag((Integer) tempr1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i83);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___llds__code_addr_0_0);
	call_localret(ENTRY(mercury____Compare___llds__code_addr_0_0),
		mercury____Compare___vn_type__vn_instr_0_0_i89,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i89);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Compare___llds__code_addr_0_0);
	call_localret(ENTRY(mercury____Compare___llds__code_addr_0_0),
		mercury____Compare___vn_type__vn_instr_0_0_i95,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i95);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) mercury_data_llds__base_type_info_liveinfo_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___vn_type__vn_instr_0_0_i101,
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i101);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_instr_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_instr_0_0_i18);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Compare___llds__call_model_0_0);
	tailcall(ENTRY(mercury____Compare___llds__call_model_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_instr_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___vn_type__vn_instr_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module33)
	init_entry(mercury____Unify___vn_type__parentry_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__parentry_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_1);
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___vn_type__parentry_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module34)
	init_entry(mercury____Index___vn_type__parentry_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__parentry_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_1);
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___vn_type__parentry_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module35)
	init_entry(mercury____Compare___vn_type__parentry_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__parentry_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_1);
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___vn_type__parentry_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module36)
	init_entry(mercury____Unify___vn_type__parallel_0_0);
	init_label(mercury____Unify___vn_type__parallel_0_0_i2);
	init_label(mercury____Unify___vn_type__parallel_0_0_i4);
	init_label(mercury____Unify___vn_type__parallel_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__parallel_0_0);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury____Unify___vn_type__parallel_0_0_i2,
		ENTRY(mercury____Unify___vn_type__parallel_0_0));
	}
Define_label(mercury____Unify___vn_type__parallel_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__parallel_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__parallel_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury____Unify___vn_type__parallel_0_0_i4,
		ENTRY(mercury____Unify___vn_type__parallel_0_0));
	}
Define_label(mercury____Unify___vn_type__parallel_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__parallel_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__parallel_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_2);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___vn_type__parallel_0_0));
	}
Define_label(mercury____Unify___vn_type__parallel_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module37)
	init_entry(mercury____Index___vn_type__parallel_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__parallel_0_0);
	tailcall(STATIC(mercury____Index___vn_type_parallel_0__ua10000_2_0),
		ENTRY(mercury____Index___vn_type__parallel_0_0));
END_MODULE

BEGIN_MODULE(mercury__vn_type_module38)
	init_entry(mercury____Compare___vn_type__parallel_0_0);
	init_label(mercury____Compare___vn_type__parallel_0_0_i4);
	init_label(mercury____Compare___vn_type__parallel_0_0_i5);
	init_label(mercury____Compare___vn_type__parallel_0_0_i3);
	init_label(mercury____Compare___vn_type__parallel_0_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__parallel_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___llds__label_0_0);
	call_localret(ENTRY(mercury____Compare___llds__label_0_0),
		mercury____Compare___vn_type__parallel_0_0_i4,
		ENTRY(mercury____Compare___vn_type__parallel_0_0));
	}
Define_label(mercury____Compare___vn_type__parallel_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__parallel_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__parallel_0_0_i3);
Define_label(mercury____Compare___vn_type__parallel_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___vn_type__parallel_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___llds__label_0_0);
	call_localret(ENTRY(mercury____Compare___llds__label_0_0),
		mercury____Compare___vn_type__parallel_0_0_i10,
		ENTRY(mercury____Compare___vn_type__parallel_0_0));
	}
Define_label(mercury____Compare___vn_type__parallel_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__parallel_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__parallel_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_2);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___vn_type__parallel_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module39)
	init_entry(mercury____Unify___vn_type__vnlvalset_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vnlvalset_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury____Unify___set__set_1_0);
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		ENTRY(mercury____Unify___vn_type__vnlvalset_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module40)
	init_entry(mercury____Index___vn_type__vnlvalset_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vnlvalset_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury____Index___set__set_1_0);
	tailcall(ENTRY(mercury____Index___set__set_1_0),
		ENTRY(mercury____Index___vn_type__vnlvalset_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module41)
	init_entry(mercury____Compare___vn_type__vnlvalset_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vnlvalset_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	{
	Declare_entry(mercury____Compare___set__set_1_0);
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		ENTRY(mercury____Compare___vn_type__vnlvalset_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module42)
	init_entry(mercury____Unify___vn_type__ctrlmap_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__ctrlmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_type__ctrlmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module43)
	init_entry(mercury____Index___vn_type__ctrlmap_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__ctrlmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_type__ctrlmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module44)
	init_entry(mercury____Compare___vn_type__ctrlmap_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__ctrlmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_type__ctrlmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module45)
	init_entry(mercury____Unify___vn_type__flushmap_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__flushmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_type__flushmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module46)
	init_entry(mercury____Index___vn_type__flushmap_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__flushmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3);
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_type__flushmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module47)
	init_entry(mercury____Compare___vn_type__flushmap_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__flushmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_type__flushmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module48)
	init_entry(mercury____Unify___vn_type__flushmapentry_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__flushmapentry_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_type__flushmapentry_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module49)
	init_entry(mercury____Index___vn_type__flushmapentry_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__flushmapentry_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_type__flushmapentry_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module50)
	init_entry(mercury____Compare___vn_type__flushmapentry_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__flushmapentry_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_vn_type__base_type_info_vnlval_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_type__flushmapentry_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module51)
	init_entry(mercury____Unify___vn_type__parmap_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__parmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_4);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_type__parmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module52)
	init_entry(mercury____Index___vn_type__parmap_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__parmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_4);
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_type__parmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module53)
	init_entry(mercury____Compare___vn_type__parmap_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__parmap_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_4);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_type__parmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module54)
	init_entry(mercury____Unify___vn_type__vn_ctrl_tuple_0_0);
	init_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i2);
	init_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i4);
	init_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1005);
	init_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vn_ctrl_tuple_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1005);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i2,
		ENTRY(mercury____Unify___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vn_ctrl_tuple_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i4,
		ENTRY(mercury____Unify___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___vn_type__vn_ctrl_tuple_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(5)))
		GOTO_LABEL(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_4);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_ctrl_tuple_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module55)
	init_entry(mercury____Index___vn_type__vn_ctrl_tuple_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vn_ctrl_tuple_0_0);
	tailcall(STATIC(mercury____Index___vn_type_vn_ctrl_tuple_0__ua10000_2_0),
		ENTRY(mercury____Index___vn_type__vn_ctrl_tuple_0_0));
END_MODULE

BEGIN_MODULE(mercury__vn_type_module56)
	init_entry(mercury____Compare___vn_type__vn_ctrl_tuple_0_0);
	init_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i4);
	init_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i5);
	init_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i3);
	init_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i10);
	init_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i16);
	init_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vn_ctrl_tuple_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i4,
		ENTRY(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i3);
Define_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_vn_type__base_type_info_vn_instr_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i10,
		ENTRY(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i16,
		ENTRY(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i22,
		ENTRY(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_ctrl_tuple_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_vn_type__common_4);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_type__vn_ctrl_tuple_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_type_module57)
	init_entry(mercury____Unify___vn_type__vn_params_0_0);
	init_label(mercury____Unify___vn_type__vn_params_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_type__vn_params_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 3)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 3))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 4)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 4))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 5)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 5))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 6)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 6))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 7)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 7))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 8)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 8))))
		GOTO_LABEL(mercury____Unify___vn_type__vn_params_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_type__vn_params_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_type_module58)
	init_entry(mercury____Index___vn_type__vn_params_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_type__vn_params_0_0);
	tailcall(STATIC(mercury____Index___vn_type_vn_params_0__ua10000_2_0),
		ENTRY(mercury____Index___vn_type__vn_params_0_0));
END_MODULE

BEGIN_MODULE(mercury__vn_type_module59)
	init_entry(mercury____Compare___vn_type__vn_params_0_0);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i4);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i5);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i3);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i10);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i16);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i22);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i28);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i34);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i40);
	init_label(mercury____Compare___vn_type__vn_params_0_0_i46);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_type__vn_params_0_0);
	incr_sp_push_msg(17, "__Compare__");
	detstackvar(17) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i4,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i3);
Define_label(mercury____Compare___vn_type__vn_params_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury____Compare___vn_type__vn_params_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i10,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i16,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i22,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i28,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i34,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i40,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_type__vn_params_0_0_i46,
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
Define_label(mercury____Compare___vn_type__vn_params_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___vn_type__vn_params_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___vn_type__vn_params_0_0_i5);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_type__vn_params_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_type_bunch_0(void)
{
	mercury__vn_type_module0();
	mercury__vn_type_module1();
	mercury__vn_type_module2();
	mercury__vn_type_module3();
	mercury__vn_type_module4();
	mercury__vn_type_module5();
	mercury__vn_type_module6();
	mercury__vn_type_module7();
	mercury__vn_type_module8();
	mercury__vn_type_module9();
	mercury__vn_type_module10();
	mercury__vn_type_module11();
	mercury__vn_type_module12();
	mercury__vn_type_module13();
	mercury__vn_type_module14();
	mercury__vn_type_module15();
	mercury__vn_type_module16();
	mercury__vn_type_module17();
	mercury__vn_type_module18();
	mercury__vn_type_module19();
	mercury__vn_type_module20();
	mercury__vn_type_module21();
	mercury__vn_type_module22();
	mercury__vn_type_module23();
	mercury__vn_type_module24();
	mercury__vn_type_module25();
	mercury__vn_type_module26();
	mercury__vn_type_module27();
	mercury__vn_type_module28();
	mercury__vn_type_module29();
	mercury__vn_type_module30();
	mercury__vn_type_module31();
	mercury__vn_type_module32();
	mercury__vn_type_module33();
	mercury__vn_type_module34();
	mercury__vn_type_module35();
	mercury__vn_type_module36();
	mercury__vn_type_module37();
	mercury__vn_type_module38();
	mercury__vn_type_module39();
	mercury__vn_type_module40();
}

static void mercury__vn_type_bunch_1(void)
{
	mercury__vn_type_module41();
	mercury__vn_type_module42();
	mercury__vn_type_module43();
	mercury__vn_type_module44();
	mercury__vn_type_module45();
	mercury__vn_type_module46();
	mercury__vn_type_module47();
	mercury__vn_type_module48();
	mercury__vn_type_module49();
	mercury__vn_type_module50();
	mercury__vn_type_module51();
	mercury__vn_type_module52();
	mercury__vn_type_module53();
	mercury__vn_type_module54();
	mercury__vn_type_module55();
	mercury__vn_type_module56();
	mercury__vn_type_module57();
	mercury__vn_type_module58();
	mercury__vn_type_module59();
}

#endif

void mercury__vn_type__init(void); /* suppress gcc warning */
void mercury__vn_type__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_type_bunch_0();
	mercury__vn_type_bunch_1();
#endif
}
