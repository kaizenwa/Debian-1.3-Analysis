/*
** Automatically generated from `lambda.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__lambda__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__lambda__process_pred_3_0);
Declare_label(mercury__lambda__process_pred_3_0_i2);
Declare_label(mercury__lambda__process_pred_3_0_i3);
Define_extern_entry(mercury__lambda__transform_lambda_15_0);
Declare_label(mercury__lambda__transform_lambda_15_0_i1052);
Declare_label(mercury__lambda__transform_lambda_15_0_i5);
Declare_label(mercury__lambda__transform_lambda_15_0_i6);
Declare_label(mercury__lambda__transform_lambda_15_0_i7);
Declare_label(mercury__lambda__transform_lambda_15_0_i8);
Declare_label(mercury__lambda__transform_lambda_15_0_i9);
Declare_label(mercury__lambda__transform_lambda_15_0_i13);
Declare_label(mercury__lambda__transform_lambda_15_0_i15);
Declare_label(mercury__lambda__transform_lambda_15_0_i16);
Declare_label(mercury__lambda__transform_lambda_15_0_i17);
Declare_label(mercury__lambda__transform_lambda_15_0_i19);
Declare_label(mercury__lambda__transform_lambda_15_0_i18);
Declare_label(mercury__lambda__transform_lambda_15_0_i23);
Declare_label(mercury__lambda__transform_lambda_15_0_i24);
Declare_label(mercury__lambda__transform_lambda_15_0_i25);
Declare_label(mercury__lambda__transform_lambda_15_0_i32);
Declare_label(mercury__lambda__transform_lambda_15_0_i35);
Declare_label(mercury__lambda__transform_lambda_15_0_i31);
Declare_label(mercury__lambda__transform_lambda_15_0_i38);
Declare_label(mercury__lambda__transform_lambda_15_0_i40);
Declare_label(mercury__lambda__transform_lambda_15_0_i11);
Declare_label(mercury__lambda__transform_lambda_15_0_i10);
Declare_label(mercury__lambda__transform_lambda_15_0_i41);
Declare_label(mercury__lambda__transform_lambda_15_0_i42);
Declare_label(mercury__lambda__transform_lambda_15_0_i43);
Declare_label(mercury__lambda__transform_lambda_15_0_i44);
Declare_label(mercury__lambda__transform_lambda_15_0_i45);
Declare_label(mercury__lambda__transform_lambda_15_0_i1051);
Declare_label(mercury__lambda__transform_lambda_15_0_i47);
Declare_label(mercury__lambda__transform_lambda_15_0_i48);
Declare_label(mercury__lambda__transform_lambda_15_0_i49);
Declare_label(mercury__lambda__transform_lambda_15_0_i50);
Declare_label(mercury__lambda__transform_lambda_15_0_i51);
Declare_label(mercury__lambda__transform_lambda_15_0_i52);
Declare_label(mercury__lambda__transform_lambda_15_0_i53);
Declare_label(mercury__lambda__transform_lambda_15_0_i54);
Declare_label(mercury__lambda__transform_lambda_15_0_i55);
Declare_label(mercury__lambda__transform_lambda_15_0_i56);
Declare_label(mercury__lambda__transform_lambda_15_0_i57);
Declare_label(mercury__lambda__transform_lambda_15_0_i58);
Declare_label(mercury__lambda__transform_lambda_15_0_i59);
Declare_label(mercury__lambda__transform_lambda_15_0_i60);
Declare_label(mercury__lambda__transform_lambda_15_0_i61);
Declare_label(mercury__lambda__transform_lambda_15_0_i62);
Declare_label(mercury__lambda__transform_lambda_15_0_i63);
Declare_label(mercury__lambda__transform_lambda_15_0_i64);
Declare_static(mercury__lambda__process_procs_4_0);
Declare_label(mercury__lambda__process_procs_4_0_i4);
Declare_label(mercury__lambda__process_procs_4_0_i5);
Declare_label(mercury__lambda__process_procs_4_0_i6);
Declare_label(mercury__lambda__process_procs_4_0_i7);
Declare_label(mercury__lambda__process_procs_4_0_i8);
Declare_label(mercury__lambda__process_procs_4_0_i9);
Declare_label(mercury__lambda__process_procs_4_0_i10);
Declare_label(mercury__lambda__process_procs_4_0_i11);
Declare_label(mercury__lambda__process_procs_4_0_i12);
Declare_label(mercury__lambda__process_procs_4_0_i13);
Declare_label(mercury__lambda__process_procs_4_0_i14);
Declare_label(mercury__lambda__process_procs_4_0_i15);
Declare_label(mercury__lambda__process_procs_4_0_i16);
Declare_label(mercury__lambda__process_procs_4_0_i17);
Declare_label(mercury__lambda__process_procs_4_0_i18);
Declare_label(mercury__lambda__process_procs_4_0_i19);
Declare_label(mercury__lambda__process_procs_4_0_i20);
Declare_label(mercury__lambda__process_procs_4_0_i21);
Declare_label(mercury__lambda__process_procs_4_0_i22);
Declare_label(mercury__lambda__process_procs_4_0_i23);
Declare_label(mercury__lambda__process_procs_4_0_i24);
Declare_label(mercury__lambda__process_procs_4_0_i1002);
Declare_static(mercury__lambda__process_goal_4_0);
Declare_static(mercury__lambda__process_goal_2_5_0);
Declare_label(mercury__lambda__process_goal_2_5_0_i1007);
Declare_label(mercury__lambda__process_goal_2_5_0_i1006);
Declare_label(mercury__lambda__process_goal_2_5_0_i1005);
Declare_label(mercury__lambda__process_goal_2_5_0_i1004);
Declare_label(mercury__lambda__process_goal_2_5_0_i1003);
Declare_label(mercury__lambda__process_goal_2_5_0_i1002);
Declare_label(mercury__lambda__process_goal_2_5_0_i1001);
Declare_label(mercury__lambda__process_goal_2_5_0_i5);
Declare_label(mercury__lambda__process_goal_2_5_0_i6);
Declare_label(mercury__lambda__process_goal_2_5_0_i7);
Declare_label(mercury__lambda__process_goal_2_5_0_i11);
Declare_label(mercury__lambda__process_goal_2_5_0_i12);
Declare_label(mercury__lambda__process_goal_2_5_0_i8);
Declare_label(mercury__lambda__process_goal_2_5_0_i14);
Declare_label(mercury__lambda__process_goal_2_5_0_i15);
Declare_label(mercury__lambda__process_goal_2_5_0_i16);
Declare_label(mercury__lambda__process_goal_2_5_0_i17);
Declare_label(mercury__lambda__process_goal_2_5_0_i18);
Declare_label(mercury__lambda__process_goal_2_5_0_i19);
Declare_label(mercury__lambda__process_goal_2_5_0_i20);
Declare_label(mercury__lambda__process_goal_2_5_0_i21);
Declare_label(mercury__lambda__process_goal_2_5_0_i22);
Declare_label(mercury__lambda__process_goal_2_5_0_i23);
Declare_label(mercury__lambda__process_goal_2_5_0_i1000);
Declare_label(mercury__lambda__process_goal_2_5_0_i26);
Declare_label(mercury__lambda__process_goal_2_5_0_i25);
Declare_label(mercury__lambda__process_goal_2_5_0_i27);
Declare_static(mercury__lambda__process_goal_list_4_0);
Declare_label(mercury__lambda__process_goal_list_4_0_i4);
Declare_label(mercury__lambda__process_goal_list_4_0_i5);
Declare_label(mercury__lambda__process_goal_list_4_0_i1002);
Declare_static(mercury__lambda__process_cases_4_0);
Declare_label(mercury__lambda__process_cases_4_0_i4);
Declare_label(mercury__lambda__process_cases_4_0_i5);
Declare_label(mercury__lambda__process_cases_4_0_i1003);
Declare_static(mercury__lambda__process_lambda_11_0);
Declare_label(mercury__lambda__process_lambda_11_0_i2);
Declare_static(mercury__lambda__uni_modes_to_modes_2_0);
Declare_label(mercury__lambda__uni_modes_to_modes_2_0_i3);
Declare_label(mercury__lambda__uni_modes_to_modes_2_0_i4);
Declare_label(mercury__lambda__uni_modes_to_modes_2_0_i1);
Declare_static(mercury__lambda__inputs_precede_outputs_2_0);
Declare_label(mercury__lambda__inputs_precede_outputs_2_0_i6);
Declare_label(mercury__lambda__inputs_precede_outputs_2_0_i5);
Declare_label(mercury__lambda__inputs_precede_outputs_2_0_i15);
Declare_label(mercury__lambda__inputs_precede_outputs_2_0_i16);
Declare_label(mercury__lambda__inputs_precede_outputs_2_0_i14);
Declare_label(mercury__lambda__inputs_precede_outputs_2_0_i1016);
Declare_static(mercury__lambda__permute_argvars_5_0);
Declare_label(mercury__lambda__permute_argvars_5_0_i4);
Declare_label(mercury__lambda__permute_argvars_5_0_i6);
Declare_label(mercury__lambda__permute_argvars_5_0_i7);
Declare_label(mercury__lambda__permute_argvars_5_0_i3);
Declare_label(mercury__lambda__permute_argvars_5_0_i8);
Declare_static(mercury__lambda__split_argvars_7_0);
Declare_label(mercury__lambda__split_argvars_7_0_i1013);
Declare_label(mercury__lambda__split_argvars_7_0_i6);
Declare_label(mercury__lambda__split_argvars_7_0_i10);
Declare_label(mercury__lambda__split_argvars_7_0_i9);
Declare_label(mercury__lambda__split_argvars_7_0_i1010);
Declare_label(mercury__lambda__split_argvars_7_0_i1);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_lambda__base_type_layout_lambda_info_0[];
Word * mercury_data_lambda__base_type_info_lambda_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_lambda__base_type_layout_lambda_info_0
};

extern Word * mercury_data_lambda__common_6[];
Word * mercury_data_lambda__base_type_layout_lambda_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_lambda__common_6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_lambda__common_0[] = {
	(Word *) string_const("mercury_builtin", 15),
	(Word *) string_const("in", 2)
};

Word * mercury_data_lambda__common_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_lambda__common_0),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_lambda__common_2[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_lambda__common_3[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_lambda__common_4[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

extern Word * mercury_data_hlds_module__base_type_info_module_info_0[];
Word * mercury_data_lambda__common_5[] = {
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_module_info_0
};

Word * mercury_data_lambda__common_6[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lambda__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lambda__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lambda__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lambda__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lambda__common_5),
	(Word *) string_const("lambda_info", 11)
};

BEGIN_MODULE(mercury__lambda_module0)
	init_entry(mercury__lambda__process_pred_3_0);
	init_label(mercury__lambda__process_pred_3_0_i2);
	init_label(mercury__lambda__process_pred_3_0_i3);
BEGIN_CODE

/* code for predicate 'lambda__process_pred'/3 in mode 0 */
Define_entry(mercury__lambda__process_pred_3_0);
	incr_sp_push_msg(3, "lambda__process_pred");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__lambda__process_pred_3_0_i2,
		ENTRY(mercury__lambda__process_pred_3_0));
	}
Define_label(mercury__lambda__process_pred_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lambda__process_pred_3_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__lambda__process_pred_3_0_i3,
		ENTRY(mercury__lambda__process_pred_3_0));
	}
Define_label(mercury__lambda__process_pred_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lambda__process_pred_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__lambda__process_procs_4_0),
		ENTRY(mercury__lambda__process_pred_3_0));
END_MODULE

BEGIN_MODULE(mercury__lambda_module1)
	init_entry(mercury__lambda__transform_lambda_15_0);
	init_label(mercury__lambda__transform_lambda_15_0_i1052);
	init_label(mercury__lambda__transform_lambda_15_0_i5);
	init_label(mercury__lambda__transform_lambda_15_0_i6);
	init_label(mercury__lambda__transform_lambda_15_0_i7);
	init_label(mercury__lambda__transform_lambda_15_0_i8);
	init_label(mercury__lambda__transform_lambda_15_0_i9);
	init_label(mercury__lambda__transform_lambda_15_0_i13);
	init_label(mercury__lambda__transform_lambda_15_0_i15);
	init_label(mercury__lambda__transform_lambda_15_0_i16);
	init_label(mercury__lambda__transform_lambda_15_0_i17);
	init_label(mercury__lambda__transform_lambda_15_0_i19);
	init_label(mercury__lambda__transform_lambda_15_0_i18);
	init_label(mercury__lambda__transform_lambda_15_0_i23);
	init_label(mercury__lambda__transform_lambda_15_0_i24);
	init_label(mercury__lambda__transform_lambda_15_0_i25);
	init_label(mercury__lambda__transform_lambda_15_0_i32);
	init_label(mercury__lambda__transform_lambda_15_0_i35);
	init_label(mercury__lambda__transform_lambda_15_0_i31);
	init_label(mercury__lambda__transform_lambda_15_0_i38);
	init_label(mercury__lambda__transform_lambda_15_0_i40);
	init_label(mercury__lambda__transform_lambda_15_0_i11);
	init_label(mercury__lambda__transform_lambda_15_0_i10);
	init_label(mercury__lambda__transform_lambda_15_0_i41);
	init_label(mercury__lambda__transform_lambda_15_0_i42);
	init_label(mercury__lambda__transform_lambda_15_0_i43);
	init_label(mercury__lambda__transform_lambda_15_0_i44);
	init_label(mercury__lambda__transform_lambda_15_0_i45);
	init_label(mercury__lambda__transform_lambda_15_0_i1051);
	init_label(mercury__lambda__transform_lambda_15_0_i47);
	init_label(mercury__lambda__transform_lambda_15_0_i48);
	init_label(mercury__lambda__transform_lambda_15_0_i49);
	init_label(mercury__lambda__transform_lambda_15_0_i50);
	init_label(mercury__lambda__transform_lambda_15_0_i51);
	init_label(mercury__lambda__transform_lambda_15_0_i52);
	init_label(mercury__lambda__transform_lambda_15_0_i53);
	init_label(mercury__lambda__transform_lambda_15_0_i54);
	init_label(mercury__lambda__transform_lambda_15_0_i55);
	init_label(mercury__lambda__transform_lambda_15_0_i56);
	init_label(mercury__lambda__transform_lambda_15_0_i57);
	init_label(mercury__lambda__transform_lambda_15_0_i58);
	init_label(mercury__lambda__transform_lambda_15_0_i59);
	init_label(mercury__lambda__transform_lambda_15_0_i60);
	init_label(mercury__lambda__transform_lambda_15_0_i61);
	init_label(mercury__lambda__transform_lambda_15_0_i62);
	init_label(mercury__lambda__transform_lambda_15_0_i63);
	init_label(mercury__lambda__transform_lambda_15_0_i64);
BEGIN_CODE

/* code for predicate 'lambda__transform_lambda'/15 in mode 0 */
Define_entry(mercury__lambda__transform_lambda_15_0);
	if ((tag((Integer) r7) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i1052);
	r13 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 0));
	r14 = (Integer) field(mktag(0), (Integer) r7, ((Integer) 3));
	r7 = (Integer) r6;
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r6, ((Integer) 1));
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) tempr1;
	incr_sp_push_msg(25, "lambda__transform_lambda");
	detstackvar(25) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i6);
	}
Define_label(mercury__lambda__transform_lambda_15_0_i1052);
	incr_sp_push_msg(25, "lambda__transform_lambda");
	detstackvar(25) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	r1 = string_const("polymorphism__transform_lambda: wierd unification", 49);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lambda__transform_lambda_15_0_i5,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	r1 = (Integer) detstackvar(15);
Define_label(mercury__lambda__transform_lambda_15_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(15) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__lambda__transform_lambda_15_0_i7,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i7);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__lambda__transform_lambda_15_0_i8,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i8);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__lambda__transform_lambda_15_0_i9,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i9);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(6), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i10);
	detstackvar(16) = (Integer) r1;
	detstackvar(17) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(18) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(19) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__remove_suffix_3_0);
	call_localret(ENTRY(mercury__list__remove_suffix_3_0),
		mercury__lambda__transform_lambda_15_0_i13,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i13);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i11);
	detstackvar(20) = (Integer) r2;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__lambda__transform_lambda_15_0_i15,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r1 = (Integer) r2;
	detstackvar(12) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__lambda__transform_lambda_15_0_i16,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i16);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(21) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__lambda__transform_lambda_15_0_i17,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i17);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	if (((Integer) r1 != (Integer) detstackvar(21)))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i19);
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	r15 = (Integer) detstackvar(15);
	r16 = (Integer) detstackvar(16);
	r17 = (Integer) detstackvar(17);
	r18 = (Integer) detstackvar(18);
	r19 = (Integer) detstackvar(19);
	r20 = (Integer) detstackvar(20);
	GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i18);
Define_label(mercury__lambda__transform_lambda_15_0_i19);
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i11);
	if (((Integer) detstackvar(21) != ((Integer) 0)))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	r15 = (Integer) detstackvar(15);
	r16 = (Integer) detstackvar(16);
	r17 = (Integer) detstackvar(17);
	r18 = (Integer) detstackvar(18);
	r19 = (Integer) detstackvar(19);
	r20 = (Integer) detstackvar(20);
	r1 = (Integer) detstackvar(12);
Define_label(mercury__lambda__transform_lambda_15_0_i18);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(15) = (Integer) r15;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r17;
	detstackvar(18) = (Integer) r18;
	detstackvar(19) = (Integer) r19;
	detstackvar(20) = (Integer) r20;
	{
	Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__lambda__transform_lambda_15_0_i23,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i23);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lambda__transform_lambda_15_0_i24,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i24);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__list__split_list_4_0);
	call_localret(ENTRY(mercury__list__split_list_4_0),
		mercury__lambda__transform_lambda_15_0_i25,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i25);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i11);
	detstackvar(22) = (Integer) curfr;
	detstackvar(23) = (Integer) maxfr;
	detstackvar(24) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__lambda__transform_lambda_15_0_i31);
	detstackvar(12) = (Integer) r3;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	{
	Declare_entry(mercury__list__member_2_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lambda__transform_lambda_15_0_i32,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i32);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__mode_util__mode_is_input_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_input_2_0),
		mercury__lambda__transform_lambda_15_0_i35,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i35);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	{
	Declare_entry(do_redo);
	if ((Integer) r1)
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(23);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(24);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(22);
	GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i11);
Define_label(mercury__lambda__transform_lambda_15_0_i31);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(22);
	r3 = (Integer) detstackvar(12);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(24);
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(11);
	call_localret(STATIC(mercury__lambda__inputs_precede_outputs_2_0),
		mercury__lambda__transform_lambda_15_0_i38,
		ENTRY(mercury__lambda__transform_lambda_15_0));
Define_label(mercury__lambda__transform_lambda_15_0_i38);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__transform_lambda_15_0_i11);
	detstackvar(12) = (Integer) detstackvar(11);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lambda__transform_lambda_15_0_i40,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i40);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(20);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(19);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r2, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(13);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) detstackvar(11);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(18);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(17);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(20);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(25);
	decr_sp_pop_msg(25);
	proceed();
	}
Define_label(mercury__lambda__transform_lambda_15_0_i11);
	r1 = (Integer) detstackvar(16);
Define_label(mercury__lambda__transform_lambda_15_0_i10);
	r2 = (Integer) r1;
	detstackvar(16) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lambda__transform_lambda_15_0_i41,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i41);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__lambda__transform_lambda_15_0_i42,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i42);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_next_lambda_count_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_next_lambda_count_3_0),
		mercury__lambda__transform_lambda_15_0_i43,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i43);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(17) = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__lambda__transform_lambda_15_0_i44,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i44);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = string_const("__LambdaGoal__", 14);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__lambda__transform_lambda_15_0_i45,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i45);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__lambda__transform_lambda_15_0_i1051,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i1051);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	detstackvar(19) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(15);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__lambda__transform_lambda_15_0_i47,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i47);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	call_localret(STATIC(mercury__lambda__uni_modes_to_modes_2_0),
		mercury__lambda__transform_lambda_15_0_i48,
		ENTRY(mercury__lambda__transform_lambda_15_0));
Define_label(mercury__lambda__transform_lambda_15_0_i48);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(18) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lambda__transform_lambda_15_0_i49,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i49);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	detstackvar(20) = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_lambda__common_1);
	{
	Declare_entry(mercury__list__duplicate_3_0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__lambda__transform_lambda_15_0_i50,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i50);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r3 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__map__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__lambda__transform_lambda_15_0_i51,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i51);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__delete_list_3_0);
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__lambda__transform_lambda_15_0_i52,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i52);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__lambda__transform_lambda_15_0_i53,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i53);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r4 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__map__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__lambda__transform_lambda_15_0_i54,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i54);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__overlay_3_0);
	call_localret(ENTRY(mercury__map__overlay_3_0),
		mercury__lambda__transform_lambda_15_0_i55,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i55);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r2 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	{
	Declare_entry(mercury__map__values_2_0);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__lambda__transform_lambda_15_0_i56,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i56);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lambda__transform_lambda_15_0_i57,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i57);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(17);
	call_localret(STATIC(mercury__lambda__permute_argvars_5_0),
		mercury__lambda__transform_lambda_15_0_i58,
		ENTRY(mercury__lambda__transform_lambda_15_0));
Define_label(mercury__lambda__transform_lambda_15_0_i58);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__map__apply_to_list_3_0);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__lambda__transform_lambda_15_0_i59,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i59);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(15);
	r8 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__hlds_pred__proc_info_create_9_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_create_9_0),
		mercury__lambda__transform_lambda_15_0_i60,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i60);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(19);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(15);
	r7 = ((Integer) 8);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r9 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__pred_info_create_12_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_create_12_0),
		mercury__lambda__transform_lambda_15_0_i61,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i61);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__lambda__transform_lambda_15_0_i62,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i62);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_table_insert_4_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_insert_4_0),
		mercury__lambda__transform_lambda_15_0_i63,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i63);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury__hlds_module__module_info_set_predicate_table_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_predicate_table_3_0),
		mercury__lambda__transform_lambda_15_0_i64,
		ENTRY(mercury__lambda__transform_lambda_15_0));
	}
Define_label(mercury__lambda__transform_lambda_15_0_i64);
	update_prof_current_proc(LABEL(mercury__lambda__transform_lambda_15_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(19);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(20);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(16);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(13);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(16);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(25);
	decr_sp_pop_msg(25);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__lambda_module2)
	init_entry(mercury__lambda__process_procs_4_0);
	init_label(mercury__lambda__process_procs_4_0_i4);
	init_label(mercury__lambda__process_procs_4_0_i5);
	init_label(mercury__lambda__process_procs_4_0_i6);
	init_label(mercury__lambda__process_procs_4_0_i7);
	init_label(mercury__lambda__process_procs_4_0_i8);
	init_label(mercury__lambda__process_procs_4_0_i9);
	init_label(mercury__lambda__process_procs_4_0_i10);
	init_label(mercury__lambda__process_procs_4_0_i11);
	init_label(mercury__lambda__process_procs_4_0_i12);
	init_label(mercury__lambda__process_procs_4_0_i13);
	init_label(mercury__lambda__process_procs_4_0_i14);
	init_label(mercury__lambda__process_procs_4_0_i15);
	init_label(mercury__lambda__process_procs_4_0_i16);
	init_label(mercury__lambda__process_procs_4_0_i17);
	init_label(mercury__lambda__process_procs_4_0_i18);
	init_label(mercury__lambda__process_procs_4_0_i19);
	init_label(mercury__lambda__process_procs_4_0_i20);
	init_label(mercury__lambda__process_procs_4_0_i21);
	init_label(mercury__lambda__process_procs_4_0_i22);
	init_label(mercury__lambda__process_procs_4_0_i23);
	init_label(mercury__lambda__process_procs_4_0_i24);
	init_label(mercury__lambda__process_procs_4_0_i1002);
BEGIN_CODE

/* code for predicate 'lambda__process_procs'/4 in mode 0 */
Define_static(mercury__lambda__process_procs_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__process_procs_4_0_i1002);
	incr_sp_push_msg(11, "lambda__process_procs");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__lambda__process_procs_4_0_i4,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__lambda__process_procs_4_0_i5,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__lambda__process_procs_4_0_i6,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__lambda__process_procs_4_0_i7,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__lambda__process_procs_4_0_i8,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__lambda__process_procs_4_0_i9,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i9);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__lambda__process_procs_4_0_i10,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i10);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__lambda__process_procs_4_0_i11,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i11);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0),
		mercury__lambda__process_procs_4_0_i12,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i12);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_procs_4_0_i13,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i13);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__lambda__process_procs_4_0_i14,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i14);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_variables_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_variables_3_0),
		mercury__lambda__process_procs_4_0_i15,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		mercury__lambda__process_procs_4_0_i16,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i16);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0),
		mercury__lambda__process_procs_4_0_i17,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i17);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_typevarset_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_typevarset_3_0),
		mercury__lambda__process_procs_4_0_i18,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i18);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__lambda__process_procs_4_0_i19,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i19);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lambda__process_procs_4_0_i20,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i20);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__lambda__process_procs_4_0_i21,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i21);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__lambda__process_procs_4_0_i22,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i22);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lambda__process_procs_4_0_i23,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i23);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__lambda__process_procs_4_0_i24,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i24);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__lambda__process_procs_4_0,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module3)
	init_entry(mercury__lambda__process_goal_4_0);
BEGIN_CODE

/* code for predicate 'lambda__process_goal'/4 in mode 0 */
Define_static(mercury__lambda__process_goal_4_0);
	r3 = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__lambda__process_goal_2_5_0),
		STATIC(mercury__lambda__process_goal_4_0));
END_MODULE

BEGIN_MODULE(mercury__lambda_module4)
	init_entry(mercury__lambda__process_goal_2_5_0);
	init_label(mercury__lambda__process_goal_2_5_0_i1007);
	init_label(mercury__lambda__process_goal_2_5_0_i1006);
	init_label(mercury__lambda__process_goal_2_5_0_i1005);
	init_label(mercury__lambda__process_goal_2_5_0_i1004);
	init_label(mercury__lambda__process_goal_2_5_0_i1003);
	init_label(mercury__lambda__process_goal_2_5_0_i1002);
	init_label(mercury__lambda__process_goal_2_5_0_i1001);
	init_label(mercury__lambda__process_goal_2_5_0_i5);
	init_label(mercury__lambda__process_goal_2_5_0_i6);
	init_label(mercury__lambda__process_goal_2_5_0_i7);
	init_label(mercury__lambda__process_goal_2_5_0_i11);
	init_label(mercury__lambda__process_goal_2_5_0_i12);
	init_label(mercury__lambda__process_goal_2_5_0_i8);
	init_label(mercury__lambda__process_goal_2_5_0_i14);
	init_label(mercury__lambda__process_goal_2_5_0_i15);
	init_label(mercury__lambda__process_goal_2_5_0_i16);
	init_label(mercury__lambda__process_goal_2_5_0_i17);
	init_label(mercury__lambda__process_goal_2_5_0_i18);
	init_label(mercury__lambda__process_goal_2_5_0_i19);
	init_label(mercury__lambda__process_goal_2_5_0_i20);
	init_label(mercury__lambda__process_goal_2_5_0_i21);
	init_label(mercury__lambda__process_goal_2_5_0_i22);
	init_label(mercury__lambda__process_goal_2_5_0_i23);
	init_label(mercury__lambda__process_goal_2_5_0_i1000);
	init_label(mercury__lambda__process_goal_2_5_0_i26);
	init_label(mercury__lambda__process_goal_2_5_0_i25);
	init_label(mercury__lambda__process_goal_2_5_0_i27);
BEGIN_CODE

/* code for predicate 'lambda__process_goal_2'/5 in mode 0 */
Define_static(mercury__lambda__process_goal_2_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i1000);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__lambda__process_goal_2_5_0_i1007) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i1006) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i1005) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i1004) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i1003) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i1002) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i1001));
Define_label(mercury__lambda__process_goal_2_5_0_i1007);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i5);
Define_label(mercury__lambda__process_goal_2_5_0_i1006);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i7);
Define_label(mercury__lambda__process_goal_2_5_0_i1005);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i14);
Define_label(mercury__lambda__process_goal_2_5_0_i1004);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i16);
Define_label(mercury__lambda__process_goal_2_5_0_i1003);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i18);
Define_label(mercury__lambda__process_goal_2_5_0_i1002);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i20);
Define_label(mercury__lambda__process_goal_2_5_0_i1001);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i8);
Define_label(mercury__lambda__process_goal_2_5_0_i5);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_cases_4_0),
		mercury__lambda__process_goal_2_5_0_i6,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i7);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	if ((tag((Integer) r4) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i8);
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(2), (Integer) r4, ((Integer) 4));
	detstackvar(9) = (Integer) field(mktag(2), (Integer) r4, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r4, ((Integer) 0));
	detstackvar(10) = (Integer) field(mktag(2), (Integer) r4, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r4, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(11) = (Integer) tempr1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__lambda__process_goal_2_5_0_i11,
		STATIC(mercury__lambda__process_goal_2_5_0));
	}
	}
Define_label(mercury__lambda__process_goal_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__lambda__process_lambda_11_0),
		mercury__lambda__process_goal_2_5_0_i12,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	r2 = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i8);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__lambda__process_goal_2_5_0_i14);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_list_4_0),
		mercury__lambda__process_goal_2_5_0_i15,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i16);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i17,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i18);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i19,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i20);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i21,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i21);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i22,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i23,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) tempr1, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i1000);
	incr_sp_push_msg(12, "lambda__process_goal_2");
	detstackvar(12) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i25);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__lambda__process_goal_list_4_0),
		mercury__lambda__process_goal_2_5_0_i26,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i25);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i27);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__lambda__process_goal_2_5_0_i27);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module5)
	init_entry(mercury__lambda__process_goal_list_4_0);
	init_label(mercury__lambda__process_goal_list_4_0_i4);
	init_label(mercury__lambda__process_goal_list_4_0_i5);
	init_label(mercury__lambda__process_goal_list_4_0_i1002);
BEGIN_CODE

/* code for predicate 'lambda__process_goal_list'/4 in mode 0 */
Define_static(mercury__lambda__process_goal_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__process_goal_list_4_0_i1002);
	incr_sp_push_msg(2, "lambda__process_goal_list");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_list_4_0_i4,
		STATIC(mercury__lambda__process_goal_list_4_0));
Define_label(mercury__lambda__process_goal_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_list_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r3;
	localcall(mercury__lambda__process_goal_list_4_0,
		LABEL(mercury__lambda__process_goal_list_4_0_i5),
		STATIC(mercury__lambda__process_goal_list_4_0));
Define_label(mercury__lambda__process_goal_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_list_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__lambda__process_goal_list_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module6)
	init_entry(mercury__lambda__process_cases_4_0);
	init_label(mercury__lambda__process_cases_4_0_i4);
	init_label(mercury__lambda__process_cases_4_0_i5);
	init_label(mercury__lambda__process_cases_4_0_i1003);
BEGIN_CODE

/* code for predicate 'lambda__process_cases'/4 in mode 0 */
Define_static(mercury__lambda__process_cases_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__process_cases_4_0_i1003);
	incr_sp_push_msg(3, "lambda__process_cases");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_cases_4_0_i4,
		STATIC(mercury__lambda__process_cases_4_0));
Define_label(mercury__lambda__process_cases_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_cases_4_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__lambda__process_cases_4_0,
		LABEL(mercury__lambda__process_cases_4_0_i5),
		STATIC(mercury__lambda__process_cases_4_0));
Define_label(mercury__lambda__process_cases_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_cases_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lambda__process_cases_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module7)
	init_entry(mercury__lambda__process_lambda_11_0);
	init_label(mercury__lambda__process_lambda_11_0_i2);
BEGIN_CODE

/* code for predicate 'lambda__process_lambda'/11 in mode 0 */
Define_static(mercury__lambda__process_lambda_11_0);
	r11 = (Integer) field(mktag(0), (Integer) r8, ((Integer) 3));
	r10 = (Integer) field(mktag(0), (Integer) r8, ((Integer) 2));
	r9 = (Integer) field(mktag(0), (Integer) r8, ((Integer) 1));
	incr_sp_push_msg(5, "lambda__process_lambda");
	detstackvar(5) = (Integer) succip;
	detstackvar(4) = (Integer) r11;
	detstackvar(3) = (Integer) r10;
	detstackvar(2) = (Integer) r9;
	r12 = (Integer) field(mktag(0), (Integer) r8, ((Integer) 4));
	r8 = (Integer) field(mktag(0), (Integer) r8, ((Integer) 0));
	detstackvar(1) = (Integer) r8;
	{
		call_localret(STATIC(mercury__lambda__transform_lambda_15_0),
		mercury__lambda__process_lambda_11_0_i2,
		STATIC(mercury__lambda__process_lambda_11_0));
	}
Define_label(mercury__lambda__process_lambda_11_0_i2);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_11_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	r3 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__lambda_module8)
	init_entry(mercury__lambda__uni_modes_to_modes_2_0);
	init_label(mercury__lambda__uni_modes_to_modes_2_0_i3);
	init_label(mercury__lambda__uni_modes_to_modes_2_0_i4);
	init_label(mercury__lambda__uni_modes_to_modes_2_0_i1);
BEGIN_CODE

/* code for predicate 'lambda__uni_modes_to_modes'/2 in mode 0 */
Define_static(mercury__lambda__uni_modes_to_modes_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__uni_modes_to_modes_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__lambda__uni_modes_to_modes_2_0_i3);
	while (1) {
	incr_sp_push_msg(1, "lambda__uni_modes_to_modes");
	tag_incr_hp(detstackvar(1), mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1));
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__lambda__uni_modes_to_modes_2_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lambda__uni_modes_to_modes_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module9)
	init_entry(mercury__lambda__inputs_precede_outputs_2_0);
	init_label(mercury__lambda__inputs_precede_outputs_2_0_i6);
	init_label(mercury__lambda__inputs_precede_outputs_2_0_i5);
	init_label(mercury__lambda__inputs_precede_outputs_2_0_i15);
	init_label(mercury__lambda__inputs_precede_outputs_2_0_i16);
	init_label(mercury__lambda__inputs_precede_outputs_2_0_i14);
	init_label(mercury__lambda__inputs_precede_outputs_2_0_i1016);
BEGIN_CODE

/* code for predicate 'inputs_precede_outputs'/2 in mode 0 */
Define_static(mercury__lambda__inputs_precede_outputs_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__inputs_precede_outputs_2_0_i1016);
	incr_sp_push_msg(6, "inputs_precede_outputs");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__mode_util__mode_is_input_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_input_2_0),
		mercury__lambda__inputs_precede_outputs_2_0_i6,
		STATIC(mercury__lambda__inputs_precede_outputs_2_0));
	}
Define_label(mercury__lambda__inputs_precede_outputs_2_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__inputs_precede_outputs_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__inputs_precede_outputs_2_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__lambda__inputs_precede_outputs_2_0,
		STATIC(mercury__lambda__inputs_precede_outputs_2_0));
Define_label(mercury__lambda__inputs_precede_outputs_2_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	detstackvar(3) = (Integer) curfr;
	detstackvar(4) = (Integer) maxfr;
	detstackvar(5) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__lambda__inputs_precede_outputs_2_0_i14);
	detstackvar(1) = (Integer) r2;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__list__member_2_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lambda__inputs_precede_outputs_2_0_i15,
		STATIC(mercury__lambda__inputs_precede_outputs_2_0));
	}
Define_label(mercury__lambda__inputs_precede_outputs_2_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__inputs_precede_outputs_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__mode_util__mode_is_input_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_input_2_0),
		mercury__lambda__inputs_precede_outputs_2_0_i16,
		STATIC(mercury__lambda__inputs_precede_outputs_2_0));
	}
Define_label(mercury__lambda__inputs_precede_outputs_2_0_i16);
	update_prof_current_proc(LABEL(mercury__lambda__inputs_precede_outputs_2_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(3);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lambda__inputs_precede_outputs_2_0_i14);
	update_prof_current_proc(LABEL(mercury__lambda__inputs_precede_outputs_2_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lambda__inputs_precede_outputs_2_0_i1016);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module10)
	init_entry(mercury__lambda__permute_argvars_5_0);
	init_label(mercury__lambda__permute_argvars_5_0_i4);
	init_label(mercury__lambda__permute_argvars_5_0_i6);
	init_label(mercury__lambda__permute_argvars_5_0_i7);
	init_label(mercury__lambda__permute_argvars_5_0_i3);
	init_label(mercury__lambda__permute_argvars_5_0_i8);
BEGIN_CODE

/* code for predicate 'permute_argvars'/5 in mode 0 */
Define_static(mercury__lambda__permute_argvars_5_0);
	incr_sp_push_msg(3, "permute_argvars");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__lambda__split_argvars_7_0),
		mercury__lambda__permute_argvars_5_0_i4,
		STATIC(mercury__lambda__permute_argvars_5_0));
Define_label(mercury__lambda__permute_argvars_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__permute_argvars_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__permute_argvars_5_0_i3);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r5;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lambda__permute_argvars_5_0_i6,
		STATIC(mercury__lambda__permute_argvars_5_0));
	}
Define_label(mercury__lambda__permute_argvars_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__permute_argvars_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_prog_data__base_type_info_mode_0[];
	r1 = (Integer) mercury_data_prog_data__base_type_info_mode_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lambda__permute_argvars_5_0_i7,
		STATIC(mercury__lambda__permute_argvars_5_0));
	}
Define_label(mercury__lambda__permute_argvars_5_0_i7);
	update_prof_current_proc(LABEL(mercury__lambda__permute_argvars_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lambda__permute_argvars_5_0_i3);
	r1 = string_const("lambda.m: permute_argvars: split_argvars failed", 47);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lambda__permute_argvars_5_0_i8,
		STATIC(mercury__lambda__permute_argvars_5_0));
	}
Define_label(mercury__lambda__permute_argvars_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lambda__permute_argvars_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lambda_module11)
	init_entry(mercury__lambda__split_argvars_7_0);
	init_label(mercury__lambda__split_argvars_7_0_i1013);
	init_label(mercury__lambda__split_argvars_7_0_i6);
	init_label(mercury__lambda__split_argvars_7_0_i10);
	init_label(mercury__lambda__split_argvars_7_0_i9);
	init_label(mercury__lambda__split_argvars_7_0_i1010);
	init_label(mercury__lambda__split_argvars_7_0_i1);
BEGIN_CODE

/* code for predicate 'split_argvars'/7 in mode 0 */
Define_static(mercury__lambda__split_argvars_7_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__split_argvars_7_0_i1013);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__split_argvars_7_0_i1010);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__lambda__split_argvars_7_0_i1013);
	incr_sp_push_msg(7, "split_argvars");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lambda__split_argvars_7_0_i1);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	localcall(mercury__lambda__split_argvars_7_0,
		LABEL(mercury__lambda__split_argvars_7_0_i6),
		STATIC(mercury__lambda__split_argvars_7_0));
Define_label(mercury__lambda__split_argvars_7_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__split_argvars_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__split_argvars_7_0_i1);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__mode_util__mode_is_input_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_input_2_0),
		mercury__lambda__split_argvars_7_0_i10,
		STATIC(mercury__lambda__split_argvars_7_0));
	}
Define_label(mercury__lambda__split_argvars_7_0_i10);
	update_prof_current_proc(LABEL(mercury__lambda__split_argvars_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lambda__split_argvars_7_0_i9);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__lambda__split_argvars_7_0_i9);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r1;
	r6 = (Integer) r5;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__lambda__split_argvars_7_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury__lambda__split_argvars_7_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__lambda_bunch_0(void)
{
	mercury__lambda_module0();
	mercury__lambda_module1();
	mercury__lambda_module2();
	mercury__lambda_module3();
	mercury__lambda_module4();
	mercury__lambda_module5();
	mercury__lambda_module6();
	mercury__lambda_module7();
	mercury__lambda_module8();
	mercury__lambda_module9();
	mercury__lambda_module10();
	mercury__lambda_module11();
}

#endif

void mercury__lambda__init(void); /* suppress gcc warning */
void mercury__lambda__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__lambda_bunch_0();
#endif
}
