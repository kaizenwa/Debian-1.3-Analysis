/*
** Automatically generated from `vn_filter.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__vn_filter__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__vn_filter__block_2_0);
Declare_label(mercury__vn_filter__block_2_0_i8);
Declare_label(mercury__vn_filter__block_2_0_i9);
Declare_label(mercury__vn_filter__block_2_0_i5);
Declare_label(mercury__vn_filter__block_2_0_i1008);
Declare_label(mercury__vn_filter__block_2_0_i4);
Declare_label(mercury__vn_filter__block_2_0_i12);
Declare_label(mercury__vn_filter__block_2_0_i1006);
Declare_static(mercury__vn_filter__can_substitute_5_0);
Declare_label(mercury__vn_filter__can_substitute_5_0_i1001);
Declare_label(mercury__vn_filter__can_substitute_5_0_i6);
Declare_label(mercury__vn_filter__can_substitute_5_0_i8);
Declare_label(mercury__vn_filter__can_substitute_5_0_i9);
Declare_label(mercury__vn_filter__can_substitute_5_0_i13);
Declare_label(mercury__vn_filter__can_substitute_5_0_i17);
Declare_label(mercury__vn_filter__can_substitute_5_0_i19);
Declare_label(mercury__vn_filter__can_substitute_5_0_i20);
Declare_label(mercury__vn_filter__can_substitute_5_0_i16);
Declare_label(mercury__vn_filter__can_substitute_5_0_i22);
Declare_label(mercury__vn_filter__can_substitute_5_0_i23);
Declare_label(mercury__vn_filter__can_substitute_5_0_i5);
Declare_label(mercury__vn_filter__can_substitute_5_0_i27);
Declare_label(mercury__vn_filter__can_substitute_5_0_i31);
Declare_label(mercury__vn_filter__can_substitute_5_0_i30);
Declare_label(mercury__vn_filter__can_substitute_5_0_i35);
Declare_label(mercury__vn_filter__can_substitute_5_0_i39);
Declare_label(mercury__vn_filter__can_substitute_5_0_i40);
Declare_label(mercury__vn_filter__can_substitute_5_0_i44);
Declare_label(mercury__vn_filter__can_substitute_5_0_i38);
Declare_label(mercury__vn_filter__can_substitute_5_0_i49);
Declare_label(mercury__vn_filter__can_substitute_5_0_i26);
Declare_label(mercury__vn_filter__can_substitute_5_0_i54);
Declare_label(mercury__vn_filter__can_substitute_5_0_i1);
Declare_static(mercury__vn_filter__user_instr_2_0);
Declare_label(mercury__vn_filter__user_instr_2_0_i1018);
Declare_label(mercury__vn_filter__user_instr_2_0_i1016);
Declare_label(mercury__vn_filter__user_instr_2_0_i1008);
Declare_label(mercury__vn_filter__user_instr_2_0_i1009);
Declare_label(mercury__vn_filter__user_instr_2_0_i13);
Declare_label(mercury__vn_filter__user_instr_2_0_i17);
Declare_label(mercury__vn_filter__user_instr_2_0_i1013);
Declare_label(mercury__vn_filter__user_instr_2_0_i26);
Declare_label(mercury__vn_filter__user_instr_2_0_i1010);
Declare_label(mercury__vn_filter__user_instr_2_0_i1012);
Declare_static(mercury__vn_filter__replace_in_user_instr_4_0);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1022);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1021);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1020);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1019);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1018);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1017);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i7);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i8);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i19);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i20);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i23);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i24);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i25);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i26);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i29);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i30);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i33);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i34);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1016);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i41);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1013);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1014);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1015);
Declare_static(mercury__vn_filter__defining_instr_2_0);
Declare_label(mercury__vn_filter__defining_instr_2_0_i1006);
Declare_label(mercury__vn_filter__defining_instr_2_0_i1007);
Declare_label(mercury__vn_filter__defining_instr_2_0_i1011);
Declare_label(mercury__vn_filter__defining_instr_2_0_i26);
Declare_label(mercury__vn_filter__defining_instr_2_0_i1008);
Declare_label(mercury__vn_filter__defining_instr_2_0_i1010);
Declare_static(mercury__vn_filter__replace_in_defining_instr_4_0);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1018);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1017);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1016);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1015);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i7);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i8);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i25);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i26);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i27);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i28);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i32);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1014);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i41);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1011);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1012);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1013);
Declare_static(mercury__vn_filter__replace_in_lval_4_0);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1029);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1028);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1027);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1026);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1025);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i7);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i8);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i9);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i10);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i11);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i12);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i13);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i14);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i15);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i16);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i17);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1024);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i21);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i22);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i23);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i24);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i25);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1008);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i2);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1016);
Declare_static(mercury__vn_filter__replace_in_rval_4_0);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i6);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i5);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i9);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i8);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i10);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i11);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i1001);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i15);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i14);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i17);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i12);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i2);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i1000);
Declare_static(mercury__vn_filter__instrs_free_of_lval_2_0);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i8);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i5);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i10);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i13);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i17);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i19);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i20);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1007);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1);

BEGIN_MODULE(mercury__vn_filter_module0)
	init_entry(mercury__vn_filter__block_2_0);
	init_label(mercury__vn_filter__block_2_0_i8);
	init_label(mercury__vn_filter__block_2_0_i9);
	init_label(mercury__vn_filter__block_2_0_i5);
	init_label(mercury__vn_filter__block_2_0_i1008);
	init_label(mercury__vn_filter__block_2_0_i4);
	init_label(mercury__vn_filter__block_2_0_i12);
	init_label(mercury__vn_filter__block_2_0_i1006);
BEGIN_CODE

/* code for predicate 'vn_filter__block'/2 in mode 0 */
Define_entry(mercury__vn_filter__block_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i1006);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i1008);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i1008);
	incr_sp_push_msg(5, "vn_filter__block");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) field(mktag(3), (Integer) r4, ((Integer) 1))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i4);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__opt_util__lvals_in_rval_2_0);
	call_localret(ENTRY(mercury__opt_util__lvals_in_rval_2_0),
		mercury__vn_filter__block_2_0_i8,
		ENTRY(mercury__vn_filter__block_2_0));
	}
Define_label(mercury__vn_filter__block_2_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__block_2_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__vn_filter__can_substitute_5_0),
		mercury__vn_filter__block_2_0_i9,
		ENTRY(mercury__vn_filter__block_2_0));
Define_label(mercury__vn_filter__block_2_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_filter__block_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i5);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__vn_filter__block_2_0,
		ENTRY(mercury__vn_filter__block_2_0));
Define_label(mercury__vn_filter__block_2_0_i5);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__vn_filter__block_2_0_i4);
Define_label(mercury__vn_filter__block_2_0_i1008);
	incr_sp_push_msg(5, "vn_filter__block");
	detstackvar(5) = (Integer) succip;
Define_label(mercury__vn_filter__block_2_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	localcall(mercury__vn_filter__block_2_0,
		LABEL(mercury__vn_filter__block_2_0_i12),
		ENTRY(mercury__vn_filter__block_2_0));
Define_label(mercury__vn_filter__block_2_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_filter__block_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__block_2_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module1)
	init_entry(mercury__vn_filter__can_substitute_5_0);
	init_label(mercury__vn_filter__can_substitute_5_0_i1001);
	init_label(mercury__vn_filter__can_substitute_5_0_i6);
	init_label(mercury__vn_filter__can_substitute_5_0_i8);
	init_label(mercury__vn_filter__can_substitute_5_0_i9);
	init_label(mercury__vn_filter__can_substitute_5_0_i13);
	init_label(mercury__vn_filter__can_substitute_5_0_i17);
	init_label(mercury__vn_filter__can_substitute_5_0_i19);
	init_label(mercury__vn_filter__can_substitute_5_0_i20);
	init_label(mercury__vn_filter__can_substitute_5_0_i16);
	init_label(mercury__vn_filter__can_substitute_5_0_i22);
	init_label(mercury__vn_filter__can_substitute_5_0_i23);
	init_label(mercury__vn_filter__can_substitute_5_0_i5);
	init_label(mercury__vn_filter__can_substitute_5_0_i27);
	init_label(mercury__vn_filter__can_substitute_5_0_i31);
	init_label(mercury__vn_filter__can_substitute_5_0_i30);
	init_label(mercury__vn_filter__can_substitute_5_0_i35);
	init_label(mercury__vn_filter__can_substitute_5_0_i39);
	init_label(mercury__vn_filter__can_substitute_5_0_i40);
	init_label(mercury__vn_filter__can_substitute_5_0_i44);
	init_label(mercury__vn_filter__can_substitute_5_0_i38);
	init_label(mercury__vn_filter__can_substitute_5_0_i49);
	init_label(mercury__vn_filter__can_substitute_5_0_i26);
	init_label(mercury__vn_filter__can_substitute_5_0_i54);
	init_label(mercury__vn_filter__can_substitute_5_0_i1);
BEGIN_CODE

/* code for predicate 'vn_filter__can_substitute'/5 in mode 0 */
Define_static(mercury__vn_filter__can_substitute_5_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1001);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i1001);
	incr_sp_push_msg(10, "vn_filter__can_substitute");
	detstackvar(10) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(6) = (Integer) tempr1;
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(8) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	call_localret(STATIC(mercury__vn_filter__user_instr_2_0),
		mercury__vn_filter__can_substitute_5_0_i6,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i5);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__opt_util__lvals_in_rval_2_0);
	call_localret(ENTRY(mercury__opt_util__lvals_in_rval_2_0),
		mercury__vn_filter__can_substitute_5_0_i8,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_filter__can_substitute_5_0_i9,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i5);
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i13,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_filter__defining_instr_2_0),
		mercury__vn_filter__can_substitute_5_0_i17,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i16);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__opt_util__lvals_in_lval_2_0);
	call_localret(ENTRY(mercury__opt_util__lvals_in_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i19,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i20,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
Define_label(mercury__vn_filter__can_substitute_5_0_i16);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_filter__replace_in_user_instr_4_0),
		mercury__vn_filter__can_substitute_5_0_i22,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	tag_incr_hp(detstackvar(5), mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r1 = (Integer) tempr1;
	r2 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__vn_filter__instrs_free_of_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i23,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
	r2 = (Integer) detstackvar(5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i5);
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__vn_filter__defining_instr_2_0),
		mercury__vn_filter__can_substitute_5_0_i27,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i26);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury____Unify___llds__lval_0_0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__vn_filter__can_substitute_5_0_i31,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i30);
	r2 = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i30);
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i35,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__opt_util__lvals_in_lval_2_0);
	call_localret(ENTRY(mercury__opt_util__lvals_in_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i39,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_filter__can_substitute_5_0_i40,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i38);
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i44,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__vn_filter__replace_in_defining_instr_4_0),
		mercury__vn_filter__can_substitute_5_0_i22,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i38);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	localcall(mercury__vn_filter__can_substitute_5_0,
		LABEL(mercury__vn_filter__can_substitute_5_0_i49),
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i26);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	localcall(mercury__vn_filter__can_substitute_5_0,
		LABEL(mercury__vn_filter__can_substitute_5_0_i54),
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module2)
	init_entry(mercury__vn_filter__user_instr_2_0);
	init_label(mercury__vn_filter__user_instr_2_0_i1018);
	init_label(mercury__vn_filter__user_instr_2_0_i1016);
	init_label(mercury__vn_filter__user_instr_2_0_i1008);
	init_label(mercury__vn_filter__user_instr_2_0_i1009);
	init_label(mercury__vn_filter__user_instr_2_0_i13);
	init_label(mercury__vn_filter__user_instr_2_0_i17);
	init_label(mercury__vn_filter__user_instr_2_0_i1013);
	init_label(mercury__vn_filter__user_instr_2_0_i26);
	init_label(mercury__vn_filter__user_instr_2_0_i1010);
	init_label(mercury__vn_filter__user_instr_2_0_i1012);
BEGIN_CODE

/* code for predicate 'vn_filter__user_instr'/2 in mode 0 */
Define_static(mercury__vn_filter__user_instr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__user_instr_2_0_i1013);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_filter__user_instr_2_0_i1010) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1008) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1018) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1010) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1018) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1016) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1018) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1018) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1009) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i1010));
Define_label(mercury__vn_filter__user_instr_2_0_i1018);
	incr_sp_push_msg(1, "vn_filter__user_instr");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__user_instr_2_0_i13);
Define_label(mercury__vn_filter__user_instr_2_0_i1016);
	incr_sp_push_msg(1, "vn_filter__user_instr");
	detstackvar(1) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__user_instr_2_0_i17);
Define_label(mercury__vn_filter__user_instr_2_0_i1008);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i1009);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i13);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i17);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 3));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i1013);
	incr_sp_push_msg(1, "vn_filter__user_instr");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__user_instr_2_0_i26);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_filter__user_instr_2_0_i1012);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i1010);
	r1 = string_const("inappropriate instruction in vn__filter", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__user_instr_2_0));
	}
Define_label(mercury__vn_filter__user_instr_2_0_i1012);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module3)
	init_entry(mercury__vn_filter__replace_in_user_instr_4_0);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1022);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1021);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1020);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1019);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1018);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1017);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i7);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i8);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i19);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i20);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i23);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i24);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i25);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i26);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i29);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i30);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i33);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i34);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1016);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i41);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1013);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1014);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1015);
BEGIN_CODE

/* code for predicate 'vn_filter__replace_in_user_instr'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_user_instr_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1016);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1013) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1022) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1021) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1013) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1020) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1019) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1018) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1017) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1014) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1013));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1022);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i7);
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1021);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i19);
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1020);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i23);
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1019);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i25);
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1018);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i29);
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1017);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i33);
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i7);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i8,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i19);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i20,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i23);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i24,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i25);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i26,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 10);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i29);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i30,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 12);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i33);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i34,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 14);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1016);
	incr_sp_push_msg(3, "vn_filter__replace_in_user_instr");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i41);
	r1 = string_const("non-user instruction in vn_filter__replace_in_user_instr", 56);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i41);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1015);
	r1 = string_const("non-user instruction in vn_filter__replace_in_user_instr", 56);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1013);
	r1 = string_const("inappropriate instruction in vn__filter", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1014);
	r1 = string_const("non-user instruction in vn_filter__replace_in_user_instr", 56);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1015);
	r1 = string_const("non-user instruction in vn_filter__replace_in_user_instr", 56);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module4)
	init_entry(mercury__vn_filter__defining_instr_2_0);
	init_label(mercury__vn_filter__defining_instr_2_0_i1006);
	init_label(mercury__vn_filter__defining_instr_2_0_i1007);
	init_label(mercury__vn_filter__defining_instr_2_0_i1011);
	init_label(mercury__vn_filter__defining_instr_2_0_i26);
	init_label(mercury__vn_filter__defining_instr_2_0_i1008);
	init_label(mercury__vn_filter__defining_instr_2_0_i1010);
BEGIN_CODE

/* code for predicate 'vn_filter__defining_instr'/2 in mode 0 */
Define_static(mercury__vn_filter__defining_instr_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__defining_instr_2_0_i1011);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_filter__defining_instr_2_0_i1008) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1006) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1008) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1006) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1006) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1006) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1007) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i1008));
Define_label(mercury__vn_filter__defining_instr_2_0_i1006);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	proceed();
Define_label(mercury__vn_filter__defining_instr_2_0_i1007);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_filter__defining_instr_2_0_i1011);
	incr_sp_push_msg(1, "vn_filter__defining_instr");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__defining_instr_2_0_i26);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_filter__defining_instr_2_0_i26);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_filter__defining_instr_2_0_i1010);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__vn_filter__defining_instr_2_0_i1008);
	r1 = string_const("inappropriate instruction in vn__filter", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__defining_instr_2_0));
	}
Define_label(mercury__vn_filter__defining_instr_2_0_i1010);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module5)
	init_entry(mercury__vn_filter__replace_in_defining_instr_4_0);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1018);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1017);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1016);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1015);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i7);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i8);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i25);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i26);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i27);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i28);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i32);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1014);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i41);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1011);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1012);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1013);
BEGIN_CODE

/* code for predicate 'vn_filter__replace_in_defining_instr'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_defining_instr_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1014);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1011) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1018) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1011) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1017) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1016) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1015) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1012) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1011));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1018);
	incr_sp_push_msg(3, "vn_filter__replace_in_defining_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i7);
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1017);
	incr_sp_push_msg(3, "vn_filter__replace_in_defining_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i25);
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1016);
	incr_sp_push_msg(3, "vn_filter__replace_in_defining_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i27);
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1015);
	incr_sp_push_msg(3, "vn_filter__replace_in_defining_instr");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i7);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i8,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i25);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i26,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 10);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i27);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i28,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 11);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i32,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 13);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1014);
	incr_sp_push_msg(3, "vn_filter__replace_in_defining_instr");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i41);
	r1 = string_const("non-def instruction in vn_filter__replace_in_defining_instr", 59);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i41);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1013);
	r1 = string_const("non-def instruction in vn_filter__replace_in_defining_instr", 59);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1011);
	r1 = string_const("inappropriate instruction in vn__filter", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1012);
	r1 = string_const("non-def instruction in vn_filter__replace_in_defining_instr", 59);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
	}
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1013);
	r1 = string_const("non-def instruction in vn_filter__replace_in_defining_instr", 59);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module6)
	init_entry(mercury__vn_filter__replace_in_lval_4_0);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1029);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1028);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1027);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1026);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1025);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i7);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i8);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i9);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i10);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i11);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i12);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i13);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i14);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i15);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i16);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i17);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1024);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i21);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i22);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i23);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i24);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i25);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1008);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i2);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1016);
BEGIN_CODE

/* code for predicate 'vn_filter__replace_in_lval'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_lval_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i1024);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1008) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1008) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1029) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1028) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1027) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1026) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1025) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1016));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1029);
	incr_sp_push_msg(5, "vn_filter__replace_in_lval");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i7);
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1028);
	incr_sp_push_msg(5, "vn_filter__replace_in_lval");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i9);
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1027);
	incr_sp_push_msg(5, "vn_filter__replace_in_lval");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i11);
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1026);
	incr_sp_push_msg(5, "vn_filter__replace_in_lval");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i13);
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1025);
	incr_sp_push_msg(5, "vn_filter__replace_in_lval");
	detstackvar(5) = (Integer) succip;
	GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i15);
Define_label(mercury__vn_filter__replace_in_lval_4_0_i7);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i8,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i9);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i10,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i11);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i12,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i13);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i14,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i15);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i16,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i17,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1024);
	incr_sp_push_msg(5, "vn_filter__replace_in_lval");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__replace_in_lval_4_0_i2);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i21) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i22) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i23) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i24) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i25));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i21);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i22);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i23);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i24);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i25);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 4)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1008);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1016);
	r1 = string_const("found lvar in vn_filter__replace_in_lval", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module7)
	init_entry(mercury__vn_filter__replace_in_rval_4_0);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i6);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i5);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i9);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i8);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i10);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i11);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i1001);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i15);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i14);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i17);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i12);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i2);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i1000);
BEGIN_CODE

/* code for predicate 'vn_filter__replace_in_rval'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_rval_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i1001);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(5, "vn_filter__replace_in_rval");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i6),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i5);
	if (((Integer) r4 == ((Integer) 1)))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i2);
	if (((Integer) r4 != ((Integer) 2)))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i8);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i9),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i8);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i10),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i11),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i1001);
	incr_sp_push_msg(5, "vn_filter__replace_in_rval");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i12);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury____Unify___llds__lval_0_0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__vn_filter__replace_in_rval_4_0_i15,
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
	}
Define_label(mercury__vn_filter__replace_in_rval_4_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i14);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i14);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_rval_4_0_i17,
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i1000);
	r1 = string_const("found var in vn_filter__replace_in_rval", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
	}
Define_label(mercury__vn_filter__replace_in_rval_4_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i1000);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__vn_filter_module8)
	init_entry(mercury__vn_filter__instrs_free_of_lval_2_0);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i8);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i5);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i10);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i13);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i17);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i19);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i20);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1007);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
BEGIN_CODE

/* code for predicate 'vn_filter__instrs_free_of_lval'/2 in mode 0 */
Define_static(mercury__vn_filter__instrs_free_of_lval_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1007);
	incr_sp_push_msg(5, "vn_filter__instrs_free_of_lval");
	detstackvar(5) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__vn_filter__user_instr_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i6,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i5);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_util__rval_free_of_lval_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_free_of_lval_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i8,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
	}
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i10);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i5);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i10);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	call_localret(STATIC(mercury__vn_filter__defining_instr_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i13,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury____Unify___llds__lval_0_0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i17,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
	}
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__opt_util__lval_access_rvals_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_access_rvals_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i19,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
	}
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__opt_util__rvals_free_of_lval_2_0);
	call_localret(ENTRY(mercury__opt_util__rvals_free_of_lval_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i20,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
	}
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__vn_filter__instrs_free_of_lval_2_0,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__vn_filter__instrs_free_of_lval_2_0,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1007);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__vn_filter_bunch_0(void)
{
	mercury__vn_filter_module0();
	mercury__vn_filter_module1();
	mercury__vn_filter_module2();
	mercury__vn_filter_module3();
	mercury__vn_filter_module4();
	mercury__vn_filter_module5();
	mercury__vn_filter_module6();
	mercury__vn_filter_module7();
	mercury__vn_filter_module8();
}

#endif

void mercury__vn_filter__init(void); /* suppress gcc warning */
void mercury__vn_filter__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__vn_filter_bunch_0();
#endif
}
