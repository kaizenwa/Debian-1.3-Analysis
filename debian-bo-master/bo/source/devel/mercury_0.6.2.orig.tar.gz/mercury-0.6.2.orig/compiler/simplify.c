/*
** Automatically generated from `simplify.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__simplify__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__simplify__proc_9_0);
Declare_label(mercury__simplify__proc_9_0_i2);
Declare_label(mercury__simplify__proc_9_0_i3);
Declare_label(mercury__simplify__proc_9_0_i4);
Declare_label(mercury__simplify__proc_9_0_i5);
Declare_label(mercury__simplify__proc_9_0_i6);
Declare_label(mercury__simplify__proc_9_0_i7);
Declare_label(mercury__simplify__proc_9_0_i8);
Declare_label(mercury__simplify__proc_9_0_i9);
Declare_static(mercury__simplify__goal_5_0);
Declare_label(mercury__simplify__goal_5_0_i2);
Declare_label(mercury__simplify__goal_5_0_i6);
Declare_label(mercury__simplify__goal_5_0_i7);
Declare_label(mercury__simplify__goal_5_0_i4);
Declare_label(mercury__simplify__goal_5_0_i3);
Declare_label(mercury__simplify__goal_5_0_i10);
Declare_label(mercury__simplify__goal_5_0_i11);
Declare_label(mercury__simplify__goal_5_0_i15);
Declare_label(mercury__simplify__goal_5_0_i16);
Declare_label(mercury__simplify__goal_5_0_i17);
Declare_label(mercury__simplify__goal_5_0_i9);
Declare_label(mercury__simplify__goal_5_0_i19);
Declare_static(mercury__simplify__goal_2_6_0);
Declare_label(mercury__simplify__goal_2_6_0_i1101);
Declare_label(mercury__simplify__goal_2_6_0_i1100);
Declare_label(mercury__simplify__goal_2_6_0_i1099);
Declare_label(mercury__simplify__goal_2_6_0_i1098);
Declare_label(mercury__simplify__goal_2_6_0_i1097);
Declare_label(mercury__simplify__goal_2_6_0_i1096);
Declare_label(mercury__simplify__goal_2_6_0_i5);
Declare_label(mercury__simplify__goal_2_6_0_i6);
Declare_label(mercury__simplify__goal_2_6_0_i7);
Declare_label(mercury__simplify__goal_2_6_0_i11);
Declare_label(mercury__simplify__goal_2_6_0_i1050);
Declare_label(mercury__simplify__goal_2_6_0_i13);
Declare_label(mercury__simplify__goal_2_6_0_i14);
Declare_label(mercury__simplify__goal_2_6_0_i21);
Declare_label(mercury__simplify__goal_2_6_0_i17);
Declare_label(mercury__simplify__goal_2_6_0_i22);
Declare_label(mercury__simplify__goal_2_6_0_i25);
Declare_label(mercury__simplify__goal_2_6_0_i26);
Declare_label(mercury__simplify__goal_2_6_0_i31);
Declare_label(mercury__simplify__goal_2_6_0_i27);
Declare_label(mercury__simplify__goal_2_6_0_i32);
Declare_label(mercury__simplify__goal_2_6_0_i38);
Declare_label(mercury__simplify__goal_2_6_0_i42);
Declare_label(mercury__simplify__goal_2_6_0_i39);
Declare_label(mercury__simplify__goal_2_6_0_i44);
Declare_label(mercury__simplify__goal_2_6_0_i47);
Declare_label(mercury__simplify__goal_2_6_0_i48);
Declare_label(mercury__simplify__goal_2_6_0_i52);
Declare_label(mercury__simplify__goal_2_6_0_i53);
Declare_label(mercury__simplify__goal_2_6_0_i54);
Declare_label(mercury__simplify__goal_2_6_0_i55);
Declare_label(mercury__simplify__goal_2_6_0_i49);
Declare_label(mercury__simplify__goal_2_6_0_i60);
Declare_label(mercury__simplify__goal_2_6_0_i61);
Declare_label(mercury__simplify__goal_2_6_0_i62);
Declare_label(mercury__simplify__goal_2_6_0_i56);
Declare_label(mercury__simplify__goal_2_6_0_i64);
Declare_label(mercury__simplify__goal_2_6_0_i65);
Declare_label(mercury__simplify__goal_2_6_0_i66);
Declare_label(mercury__simplify__goal_2_6_0_i67);
Declare_label(mercury__simplify__goal_2_6_0_i68);
Declare_label(mercury__simplify__goal_2_6_0_i69);
Declare_label(mercury__simplify__goal_2_6_0_i1095);
Declare_label(mercury__simplify__goal_2_6_0_i74);
Declare_label(mercury__simplify__goal_2_6_0_i79);
Declare_label(mercury__simplify__goal_2_6_0_i80);
Declare_label(mercury__simplify__goal_2_6_0_i83);
Declare_label(mercury__simplify__goal_2_6_0_i84);
Declare_label(mercury__simplify__goal_2_6_0_i86);
Declare_label(mercury__simplify__goal_2_6_0_i87);
Declare_label(mercury__simplify__goal_2_6_0_i1091);
Declare_label(mercury__simplify__goal_2_6_0_i73);
Declare_label(mercury__simplify__goal_2_6_0_i91);
Declare_label(mercury__simplify__goal_2_6_0_i92);
Declare_label(mercury__simplify__goal_2_6_0_i93);
Declare_label(mercury__simplify__goal_2_6_0_i96);
Declare_label(mercury__simplify__goal_2_6_0_i95);
Declare_label(mercury__simplify__goal_2_6_0_i90);
Declare_label(mercury__simplify__goal_2_6_0_i1093);
Declare_static(mercury__simplify__conj_5_0);
Declare_label(mercury__simplify__conj_5_0_i1008);
Declare_label(mercury__simplify__conj_5_0_i9);
Declare_label(mercury__simplify__conj_5_0_i10);
Declare_label(mercury__simplify__conj_5_0_i13);
Declare_label(mercury__simplify__conj_5_0_i12);
Declare_label(mercury__simplify__conj_5_0_i15);
Declare_label(mercury__simplify__conj_5_0_i16);
Declare_label(mercury__simplify__conj_5_0_i1006);
Declare_static(mercury__simplify__disj_5_0);
Declare_label(mercury__simplify__disj_5_0_i4);
Declare_label(mercury__simplify__disj_5_0_i5);
Declare_label(mercury__simplify__disj_5_0_i6);
Declare_label(mercury__simplify__disj_5_0_i9);
Declare_label(mercury__simplify__disj_5_0_i10);
Declare_label(mercury__simplify__disj_5_0_i8);
Declare_label(mercury__simplify__disj_5_0_i1005);
Declare_static(mercury__simplify__switch_5_0);
Declare_label(mercury__simplify__switch_5_0_i4);
Declare_label(mercury__simplify__switch_5_0_i5);
Declare_label(mercury__simplify__switch_5_0_i6);
Declare_label(mercury__simplify__switch_5_0_i1003);
Declare_static(mercury__simplify__contains_multisoln_goal_1_0);
Declare_label(mercury__simplify__contains_multisoln_goal_1_0_i4);
Declare_label(mercury__simplify__contains_multisoln_goal_1_0_i5);
Declare_label(mercury__simplify__contains_multisoln_goal_1_0_i6);
Declare_label(mercury__simplify__contains_multisoln_goal_1_0_i3);

Word mercury_data_simplify__common_0[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0[];
extern Word * mercury_data_hlds_goal__base_type_info_hlds__goal_info_0[];
Word * mercury_data_simplify__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_expr_0,
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_hlds__goal_info_0
};

Word mercury_data_simplify__common_2[] = {
	((Integer) 2)
};

BEGIN_MODULE(mercury__simplify_module0)
	init_entry(mercury__simplify__proc_9_0);
	init_label(mercury__simplify__proc_9_0_i2);
	init_label(mercury__simplify__proc_9_0_i3);
	init_label(mercury__simplify__proc_9_0_i4);
	init_label(mercury__simplify__proc_9_0_i5);
	init_label(mercury__simplify__proc_9_0_i6);
	init_label(mercury__simplify__proc_9_0_i7);
	init_label(mercury__simplify__proc_9_0_i8);
	init_label(mercury__simplify__proc_9_0_i9);
BEGIN_CODE

/* code for predicate 'simplify__proc'/9 in mode 0 */
Define_entry(mercury__simplify__proc_9_0);
	incr_sp_push_msg(7, "simplify__proc");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__globals__io_get_globals_3_0);
	call_localret(ENTRY(mercury__globals__io_get_globals_3_0),
		mercury__simplify__proc_9_0_i2,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i2);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__det_util__det_info_init_5_0);
	call_localret(ENTRY(mercury__det_util__det_info_init_5_0),
		mercury__simplify__proc_9_0_i3,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i3);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__simplify__proc_9_0_i4,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i4);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__simplify__proc_9_0_i5,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i5);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const("% Simplifying ", 14);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__passes_aux__write_pred_progress_message_5_0);
	call_localret(ENTRY(mercury__passes_aux__write_pred_progress_message_5_0),
		mercury__simplify__proc_9_0_i6,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i6);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__proc_9_0_i7,
		ENTRY(mercury__simplify__proc_9_0));
Define_label(mercury__simplify__proc_9_0_i7);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__simplify__proc_9_0_i8,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i8);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__det_report__det_report_msgs_6_0);
	call_localret(ENTRY(mercury__det_report__det_report_msgs_6_0),
		mercury__simplify__proc_9_0_i9,
		ENTRY(mercury__simplify__proc_9_0));
	}
Define_label(mercury__simplify__proc_9_0_i9);
	update_prof_current_proc(LABEL(mercury__simplify__proc_9_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__simplify_module1)
	init_entry(mercury__simplify__goal_5_0);
	init_label(mercury__simplify__goal_5_0_i2);
	init_label(mercury__simplify__goal_5_0_i6);
	init_label(mercury__simplify__goal_5_0_i7);
	init_label(mercury__simplify__goal_5_0_i4);
	init_label(mercury__simplify__goal_5_0_i3);
	init_label(mercury__simplify__goal_5_0_i10);
	init_label(mercury__simplify__goal_5_0_i11);
	init_label(mercury__simplify__goal_5_0_i15);
	init_label(mercury__simplify__goal_5_0_i16);
	init_label(mercury__simplify__goal_5_0_i17);
	init_label(mercury__simplify__goal_5_0_i9);
	init_label(mercury__simplify__goal_5_0_i19);
BEGIN_CODE

/* code for predicate 'simplify__goal'/5 in mode 0 */
Define_static(mercury__simplify__goal_5_0);
	incr_sp_push_msg(6, "simplify__goal");
	detstackvar(6) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__simplify__goal_5_0_i2,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i2);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	if (((Integer) r1 != ((Integer) 7)))
		GOTO_LABEL(mercury__simplify__goal_5_0_i3);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__det_util__det_info_get_fully_strict_2_0);
	call_localret(ENTRY(mercury__det_util__det_info_get_fully_strict_2_0),
		mercury__simplify__goal_5_0_i6,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i6);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__simplify__goal_5_0_i4);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__simplify__goal_5_0_i7,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i7);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__simplify__goal_5_0_i4);
	r1 = (Integer) detstackvar(5);
Define_label(mercury__simplify__goal_5_0_i3);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__simplify__goal_5_0_i10,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i10);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__simplify__goal_5_0_i9);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__det_util__det_info_get_fully_strict_2_0);
	call_localret(ENTRY(mercury__det_util__det_info_get_fully_strict_2_0),
		mercury__simplify__goal_5_0_i11,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i11);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__simplify__goal_5_0_i9);
	if (((Integer) detstackvar(5) == ((Integer) 0)))
		GOTO_LABEL(mercury__simplify__goal_5_0_i9);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__simplify__goal_5_0_i15,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i15);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__simplify__goal_5_0_i16,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i16);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__det_util__det_no_output_vars_4_0);
	call_localret(ENTRY(mercury__det_util__det_no_output_vars_4_0),
		mercury__simplify__goal_5_0_i17,
		STATIC(mercury__simplify__goal_5_0));
	}
Define_label(mercury__simplify__goal_5_0_i17);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__simplify__goal_5_0_i9);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_simplify__common_0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__simplify__goal_5_0_i9);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__simplify__goal_2_6_0),
		mercury__simplify__goal_5_0_i19,
		STATIC(mercury__simplify__goal_5_0));
Define_label(mercury__simplify__goal_5_0_i19);
	update_prof_current_proc(LABEL(mercury__simplify__goal_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__simplify_module2)
	init_entry(mercury__simplify__goal_2_6_0);
	init_label(mercury__simplify__goal_2_6_0_i1101);
	init_label(mercury__simplify__goal_2_6_0_i1100);
	init_label(mercury__simplify__goal_2_6_0_i1099);
	init_label(mercury__simplify__goal_2_6_0_i1098);
	init_label(mercury__simplify__goal_2_6_0_i1097);
	init_label(mercury__simplify__goal_2_6_0_i1096);
	init_label(mercury__simplify__goal_2_6_0_i5);
	init_label(mercury__simplify__goal_2_6_0_i6);
	init_label(mercury__simplify__goal_2_6_0_i7);
	init_label(mercury__simplify__goal_2_6_0_i11);
	init_label(mercury__simplify__goal_2_6_0_i1050);
	init_label(mercury__simplify__goal_2_6_0_i13);
	init_label(mercury__simplify__goal_2_6_0_i14);
	init_label(mercury__simplify__goal_2_6_0_i21);
	init_label(mercury__simplify__goal_2_6_0_i17);
	init_label(mercury__simplify__goal_2_6_0_i22);
	init_label(mercury__simplify__goal_2_6_0_i25);
	init_label(mercury__simplify__goal_2_6_0_i26);
	init_label(mercury__simplify__goal_2_6_0_i31);
	init_label(mercury__simplify__goal_2_6_0_i27);
	init_label(mercury__simplify__goal_2_6_0_i32);
	init_label(mercury__simplify__goal_2_6_0_i38);
	init_label(mercury__simplify__goal_2_6_0_i42);
	init_label(mercury__simplify__goal_2_6_0_i39);
	init_label(mercury__simplify__goal_2_6_0_i44);
	init_label(mercury__simplify__goal_2_6_0_i47);
	init_label(mercury__simplify__goal_2_6_0_i48);
	init_label(mercury__simplify__goal_2_6_0_i52);
	init_label(mercury__simplify__goal_2_6_0_i53);
	init_label(mercury__simplify__goal_2_6_0_i54);
	init_label(mercury__simplify__goal_2_6_0_i55);
	init_label(mercury__simplify__goal_2_6_0_i49);
	init_label(mercury__simplify__goal_2_6_0_i60);
	init_label(mercury__simplify__goal_2_6_0_i61);
	init_label(mercury__simplify__goal_2_6_0_i62);
	init_label(mercury__simplify__goal_2_6_0_i56);
	init_label(mercury__simplify__goal_2_6_0_i64);
	init_label(mercury__simplify__goal_2_6_0_i65);
	init_label(mercury__simplify__goal_2_6_0_i66);
	init_label(mercury__simplify__goal_2_6_0_i67);
	init_label(mercury__simplify__goal_2_6_0_i68);
	init_label(mercury__simplify__goal_2_6_0_i69);
	init_label(mercury__simplify__goal_2_6_0_i1095);
	init_label(mercury__simplify__goal_2_6_0_i74);
	init_label(mercury__simplify__goal_2_6_0_i79);
	init_label(mercury__simplify__goal_2_6_0_i80);
	init_label(mercury__simplify__goal_2_6_0_i83);
	init_label(mercury__simplify__goal_2_6_0_i84);
	init_label(mercury__simplify__goal_2_6_0_i86);
	init_label(mercury__simplify__goal_2_6_0_i87);
	init_label(mercury__simplify__goal_2_6_0_i1091);
	init_label(mercury__simplify__goal_2_6_0_i73);
	init_label(mercury__simplify__goal_2_6_0_i91);
	init_label(mercury__simplify__goal_2_6_0_i92);
	init_label(mercury__simplify__goal_2_6_0_i93);
	init_label(mercury__simplify__goal_2_6_0_i96);
	init_label(mercury__simplify__goal_2_6_0_i95);
	init_label(mercury__simplify__goal_2_6_0_i90);
	init_label(mercury__simplify__goal_2_6_0_i1093);
BEGIN_CODE

/* code for predicate 'simplify__goal_2'/6 in mode 0 */
Define_static(mercury__simplify__goal_2_6_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i1095);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__simplify__goal_2_6_0_i1101) AND
		LABEL(mercury__simplify__goal_2_6_0_i1100) AND
		LABEL(mercury__simplify__goal_2_6_0_i1099) AND
		LABEL(mercury__simplify__goal_2_6_0_i1098) AND
		LABEL(mercury__simplify__goal_2_6_0_i1097) AND
		LABEL(mercury__simplify__goal_2_6_0_i1096) AND
		LABEL(mercury__simplify__goal_2_6_0_i1093));
Define_label(mercury__simplify__goal_2_6_0_i1101);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__simplify__goal_2_6_0_i5);
Define_label(mercury__simplify__goal_2_6_0_i1100);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__simplify__goal_2_6_0_i7);
Define_label(mercury__simplify__goal_2_6_0_i1099);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__simplify__goal_2_6_0_i13);
Define_label(mercury__simplify__goal_2_6_0_i1098);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__simplify__goal_2_6_0_i25);
Define_label(mercury__simplify__goal_2_6_0_i1097);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	GOTO_LABEL(mercury__simplify__goal_2_6_0_i38);
Define_label(mercury__simplify__goal_2_6_0_i1096);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) tempr1;
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(7) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__simplify__goal_2_6_0_i47,
		STATIC(mercury__simplify__goal_2_6_0));
	}
	}
Define_label(mercury__simplify__goal_2_6_0_i5);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__switch_5_0),
		mercury__simplify__goal_2_6_0_i6,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i7);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r7 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r8 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) r7) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i1050);
	detstackvar(1) = (Integer) r8;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r7, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r7, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(2), (Integer) r7, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r7, ((Integer) 3));
	r1 = (Integer) field(mktag(2), (Integer) r7, ((Integer) 4));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i11,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__simplify__goal_2_6_0_i1050);
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r8;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r7;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r6;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r5;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i13);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	if (((Integer) r5 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i14);
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i14);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i17);
	r1 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i17);
	r1 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i21,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i21);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i17);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) r5;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__disj_5_0),
		mercury__simplify__goal_2_6_0_i22,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i22);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i25);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i26,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i26);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i27);
	if (((Integer) field(mktag(0), (Integer) r3, ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i27);
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__simplify__goal_2_6_0_i31,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i31);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 4);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i27);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i32);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i32);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i32);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_simplify__common_0);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__simplify__goal_2_6_0_i32);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i38);
	r5 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r6 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	if ((tag((Integer) r7) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i39);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i39);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r7, ((Integer) 2));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) r6;
	r3 = (Integer) field(mktag(3), (Integer) r7, ((Integer) 1));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__goal_2_6_0_i42,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i42);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i21,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i39);
	detstackvar(1) = (Integer) r6;
	r1 = (Integer) r5;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i44,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i44);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i47);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__simplify__goal_2_6_0_i48,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i48);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i49);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__simplify__goal_2_6_0_i52,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i52);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__simplify__goal_2_6_0_i53,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i53);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_simplify__common_1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__goal_2_6_0_i54,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i54);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i55,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i55);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i49);
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(7), ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i56);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i56);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i56);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__simplify__goal_2_6_0_i60,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i60);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__simplify__goal_2_6_0_i61,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i61);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_simplify__common_1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__goal_2_6_0_i62,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i62);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i21,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i56);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__det_util__update_instmap_3_0);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__simplify__goal_2_6_0_i64,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i64);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i65,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i65);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i66,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i66);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i67,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i67);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__goal_2_6_0_i68,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i68);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__goal_2_6_0_i69,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i69);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i1095);
	incr_sp_push_msg(9, "simplify__goal_2");
	detstackvar(9) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i73);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i74);
	r6 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 1));
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i74);
	r1 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__goal_2_6_0_i21,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i74);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) r5;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__simplify__conj_5_0),
		mercury__simplify__goal_2_6_0_i79,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i79);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__simplify__goal_2_6_0_i80,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i80);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__simplify__goal_2_6_0_i83,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i83);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	if ((((Integer) 0) != (Integer) r2))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i1091);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__simplify__contains_multisoln_goal_1_0),
		mercury__simplify__goal_2_6_0_i84,
		STATIC(mercury__simplify__goal_2_6_0));
Define_label(mercury__simplify__goal_2_6_0_i84);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i1091);
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 3);
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_1);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_1),
		mercury__simplify__goal_2_6_0_i86,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i86);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_determinism_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_determinism_3_0),
		mercury__simplify__goal_2_6_0_i87,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i87);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__simplify__goal_2_6_0_i1091);
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i73);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i90);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__det_util__det_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__det_util__det_info_get_module_info_2_0),
		mercury__simplify__goal_2_6_0_i91,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i91);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__simplify__goal_2_6_0_i92,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i92);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_get_marker_list_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_marker_list_2_0),
		mercury__simplify__goal_2_6_0_i93,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i93);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_marker_status_0[];
	r1 = (Integer) mercury_data_hlds_pred__base_type_info_marker_status_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_simplify__common_2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__simplify__goal_2_6_0_i96,
		STATIC(mercury__simplify__goal_2_6_0));
	}
Define_label(mercury__simplify__goal_2_6_0_i96);
	update_prof_current_proc(LABEL(mercury__simplify__goal_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__simplify__goal_2_6_0_i95);
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i95);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i90);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__simplify__goal_2_6_0_i1093);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__simplify_module3)
	init_entry(mercury__simplify__conj_5_0);
	init_label(mercury__simplify__conj_5_0_i1008);
	init_label(mercury__simplify__conj_5_0_i9);
	init_label(mercury__simplify__conj_5_0_i10);
	init_label(mercury__simplify__conj_5_0_i13);
	init_label(mercury__simplify__conj_5_0_i12);
	init_label(mercury__simplify__conj_5_0_i15);
	init_label(mercury__simplify__conj_5_0_i16);
	init_label(mercury__simplify__conj_5_0_i1006);
BEGIN_CODE

/* code for predicate 'simplify__conj'/5 in mode 0 */
Define_static(mercury__simplify__conj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__conj_5_0_i1006);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r6 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	if ((tag((Integer) r6) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__simplify__conj_5_0_i1008);
	if (((Integer) field(mktag(0), (Integer) r6, ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__conj_5_0_i1008);
	r1 = (Integer) r4;
	localtailcall(mercury__simplify__conj_5_0,
		STATIC(mercury__simplify__conj_5_0));
Define_label(mercury__simplify__conj_5_0_i1008);
	incr_sp_push_msg(6, "simplify__conj");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r5;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__conj_5_0_i9,
		STATIC(mercury__simplify__conj_5_0));
Define_label(mercury__simplify__conj_5_0_i9);
	update_prof_current_proc(LABEL(mercury__simplify__conj_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__det_util__update_instmap_3_0);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__simplify__conj_5_0_i10,
		STATIC(mercury__simplify__conj_5_0));
	}
Define_label(mercury__simplify__conj_5_0_i10);
	update_prof_current_proc(LABEL(mercury__simplify__conj_5_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__instmap__is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__simplify__conj_5_0_i13,
		STATIC(mercury__simplify__conj_5_0));
	}
Define_label(mercury__simplify__conj_5_0_i13);
	update_prof_current_proc(LABEL(mercury__simplify__conj_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__simplify__conj_5_0_i12);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__simplify__conj_5_0_i12);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__simplify__conj_5_0,
		LABEL(mercury__simplify__conj_5_0_i15),
		STATIC(mercury__simplify__conj_5_0));
Define_label(mercury__simplify__conj_5_0_i15);
	update_prof_current_proc(LABEL(mercury__simplify__conj_5_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__conj_5_0_i16,
		STATIC(mercury__simplify__conj_5_0));
	}
	}
Define_label(mercury__simplify__conj_5_0_i16);
	update_prof_current_proc(LABEL(mercury__simplify__conj_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__simplify__conj_5_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__simplify_module4)
	init_entry(mercury__simplify__disj_5_0);
	init_label(mercury__simplify__disj_5_0_i4);
	init_label(mercury__simplify__disj_5_0_i5);
	init_label(mercury__simplify__disj_5_0_i6);
	init_label(mercury__simplify__disj_5_0_i9);
	init_label(mercury__simplify__disj_5_0_i10);
	init_label(mercury__simplify__disj_5_0_i8);
	init_label(mercury__simplify__disj_5_0_i1005);
BEGIN_CODE

/* code for predicate 'simplify__disj'/5 in mode 0 */
Define_static(mercury__simplify__disj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__disj_5_0_i1005);
	incr_sp_push_msg(4, "simplify__disj");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__disj_5_0_i4,
		STATIC(mercury__simplify__disj_5_0));
Define_label(mercury__simplify__disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__simplify__disj_5_0));
	r3 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	localcall(mercury__simplify__disj_5_0,
		LABEL(mercury__simplify__disj_5_0_i5),
		STATIC(mercury__simplify__disj_5_0));
	}
Define_label(mercury__simplify__disj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__simplify__disj_5_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__disj_5_0_i6,
		STATIC(mercury__simplify__disj_5_0));
	}
	}
Define_label(mercury__simplify__disj_5_0_i6);
	update_prof_current_proc(LABEL(mercury__simplify__disj_5_0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	detstackvar(3) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__simplify__disj_5_0_i9,
		STATIC(mercury__simplify__disj_5_0));
	}
Define_label(mercury__simplify__disj_5_0_i9);
	update_prof_current_proc(LABEL(mercury__simplify__disj_5_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__simplify__disj_5_0_i10,
		STATIC(mercury__simplify__disj_5_0));
	}
Define_label(mercury__simplify__disj_5_0_i10);
	update_prof_current_proc(LABEL(mercury__simplify__disj_5_0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__simplify__disj_5_0_i8);
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__simplify__disj_5_0_i8);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__simplify__disj_5_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__simplify_module5)
	init_entry(mercury__simplify__switch_5_0);
	init_label(mercury__simplify__switch_5_0_i4);
	init_label(mercury__simplify__switch_5_0_i5);
	init_label(mercury__simplify__switch_5_0_i6);
	init_label(mercury__simplify__switch_5_0_i1003);
BEGIN_CODE

/* code for predicate 'simplify__switch'/5 in mode 0 */
Define_static(mercury__simplify__switch_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__simplify__switch_5_0_i1003);
	incr_sp_push_msg(5, "simplify__switch");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__simplify__goal_5_0),
		mercury__simplify__switch_5_0_i4,
		STATIC(mercury__simplify__switch_5_0));
	}
Define_label(mercury__simplify__switch_5_0_i4);
	update_prof_current_proc(LABEL(mercury__simplify__switch_5_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	localcall(mercury__simplify__switch_5_0,
		LABEL(mercury__simplify__switch_5_0_i5),
		STATIC(mercury__simplify__switch_5_0));
	}
Define_label(mercury__simplify__switch_5_0_i5);
	update_prof_current_proc(LABEL(mercury__simplify__switch_5_0));
	r3 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	{
	extern Word * mercury_data_det_report__base_type_info_det_msg_0[];
	r1 = (Integer) mercury_data_det_report__base_type_info_det_msg_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__simplify__switch_5_0_i6,
		STATIC(mercury__simplify__switch_5_0));
	}
	}
Define_label(mercury__simplify__switch_5_0_i6);
	update_prof_current_proc(LABEL(mercury__simplify__switch_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__simplify__switch_5_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__simplify_module6)
	init_entry(mercury__simplify__contains_multisoln_goal_1_0);
	init_label(mercury__simplify__contains_multisoln_goal_1_0_i4);
	init_label(mercury__simplify__contains_multisoln_goal_1_0_i5);
	init_label(mercury__simplify__contains_multisoln_goal_1_0_i6);
	init_label(mercury__simplify__contains_multisoln_goal_1_0_i3);
BEGIN_CODE

/* code for predicate 'simplify__contains_multisoln_goal'/1 in mode 0 */
Define_static(mercury__simplify__contains_multisoln_goal_1_0);
	incr_sp_push_msg(4, "simplify__contains_multisoln_goal");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) curfr;
	detstackvar(2) = (Integer) maxfr;
	detstackvar(3) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__simplify__contains_multisoln_goal_1_0_i3);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_simplify__common_1);
	{
	Declare_entry(mercury__list__member_2_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__simplify__contains_multisoln_goal_1_0_i4,
		STATIC(mercury__simplify__contains_multisoln_goal_1_0));
	}
Define_label(mercury__simplify__contains_multisoln_goal_1_0_i4);
	update_prof_current_proc(LABEL(mercury__simplify__contains_multisoln_goal_1_0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__simplify__contains_multisoln_goal_1_0_i5,
		STATIC(mercury__simplify__contains_multisoln_goal_1_0));
	}
Define_label(mercury__simplify__contains_multisoln_goal_1_0_i5);
	update_prof_current_proc(LABEL(mercury__simplify__contains_multisoln_goal_1_0));
	{
	Declare_entry(mercury__hlds_data__determinism_components_3_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__simplify__contains_multisoln_goal_1_0_i6,
		STATIC(mercury__simplify__contains_multisoln_goal_1_0));
	}
Define_label(mercury__simplify__contains_multisoln_goal_1_0_i6);
	update_prof_current_proc(LABEL(mercury__simplify__contains_multisoln_goal_1_0));
	{
	Declare_entry(do_redo);
	if ((((Integer) 3) != (Integer) r2))
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__simplify__contains_multisoln_goal_1_0_i3);
	update_prof_current_proc(LABEL(mercury__simplify__contains_multisoln_goal_1_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(3);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__simplify_bunch_0(void)
{
	mercury__simplify_module0();
	mercury__simplify_module1();
	mercury__simplify_module2();
	mercury__simplify_module3();
	mercury__simplify_module4();
	mercury__simplify_module5();
	mercury__simplify_module6();
}

#endif

void mercury__simplify__init(void); /* suppress gcc warning */
void mercury__simplify__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__simplify_bunch_0();
#endif
}
