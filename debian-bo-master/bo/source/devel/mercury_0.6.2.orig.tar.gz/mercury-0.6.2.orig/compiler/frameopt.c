/*
** Automatically generated from `frameopt.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__frameopt__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__frameopt__main_5_0);
Declare_label(mercury__frameopt__main_5_0_i2);
Declare_label(mercury__frameopt__main_5_0_i6);
Declare_label(mercury__frameopt__main_5_0_i9);
Declare_label(mercury__frameopt__main_5_0_i11);
Declare_label(mercury__frameopt__main_5_0_i13);
Declare_label(mercury__frameopt__main_5_0_i14);
Declare_label(mercury__frameopt__main_5_0_i15);
Declare_label(mercury__frameopt__main_5_0_i16);
Declare_label(mercury__frameopt__main_5_0_i17);
Declare_label(mercury__frameopt__main_5_0_i18);
Declare_label(mercury__frameopt__main_5_0_i19);
Declare_label(mercury__frameopt__main_5_0_i20);
Declare_label(mercury__frameopt__main_5_0_i21);
Declare_label(mercury__frameopt__main_5_0_i22);
Declare_label(mercury__frameopt__main_5_0_i23);
Declare_label(mercury__frameopt__main_5_0_i26);
Declare_label(mercury__frameopt__main_5_0_i25);
Declare_label(mercury__frameopt__main_5_0_i4);
Declare_label(mercury__frameopt__main_5_0_i29);
Define_extern_entry(mercury__frameopt__is_succip_restored_1_0);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i8);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i1014);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i7);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i5);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i4);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i1011);
Declare_label(mercury__frameopt__is_succip_restored_1_0_i1012);
Define_extern_entry(mercury__frameopt__dont_save_succip_2_0);
Declare_label(mercury__frameopt__dont_save_succip_2_0_i10);
Declare_label(mercury__frameopt__dont_save_succip_2_0_i11);
Declare_label(mercury__frameopt__dont_save_succip_2_0_i3);
Declare_label(mercury__frameopt__dont_save_succip_2_0_i9);
Declare_label(mercury__frameopt__dont_save_succip_2_0_i1);
Declare_static(mercury__frameopt__repeat_build_sets_8_0);
Declare_label(mercury__frameopt__repeat_build_sets_8_0_i2);
Declare_label(mercury__frameopt__repeat_build_sets_8_0_i5);
Declare_label(mercury__frameopt__repeat_build_sets_8_0_i7);
Declare_label(mercury__frameopt__repeat_build_sets_8_0_i4);
Declare_static(mercury__frameopt__build_sets_11_0);
Declare_label(mercury__frameopt__build_sets_11_0_i6);
Declare_label(mercury__frameopt__build_sets_11_0_i5);
Declare_label(mercury__frameopt__build_sets_11_0_i12);
Declare_label(mercury__frameopt__build_sets_11_0_i13);
Declare_label(mercury__frameopt__build_sets_11_0_i15);
Declare_label(mercury__frameopt__build_sets_11_0_i16);
Declare_label(mercury__frameopt__build_sets_11_0_i17);
Declare_label(mercury__frameopt__build_sets_11_0_i18);
Declare_label(mercury__frameopt__build_sets_11_0_i19);
Declare_label(mercury__frameopt__build_sets_11_0_i21);
Declare_label(mercury__frameopt__build_sets_11_0_i22);
Declare_label(mercury__frameopt__build_sets_11_0_i23);
Declare_label(mercury__frameopt__build_sets_11_0_i25);
Declare_label(mercury__frameopt__build_sets_11_0_i26);
Declare_label(mercury__frameopt__build_sets_11_0_i27);
Declare_label(mercury__frameopt__build_sets_11_0_i29);
Declare_label(mercury__frameopt__build_sets_11_0_i33);
Declare_label(mercury__frameopt__build_sets_11_0_i34);
Declare_label(mercury__frameopt__build_sets_11_0_i35);
Declare_label(mercury__frameopt__build_sets_11_0_i36);
Declare_label(mercury__frameopt__build_sets_11_0_i37);
Declare_label(mercury__frameopt__build_sets_11_0_i39);
Declare_label(mercury__frameopt__build_sets_11_0_i40);
Declare_label(mercury__frameopt__build_sets_11_0_i43);
Declare_label(mercury__frameopt__build_sets_11_0_i44);
Declare_label(mercury__frameopt__build_sets_11_0_i47);
Declare_label(mercury__frameopt__build_sets_11_0_i49);
Declare_label(mercury__frameopt__build_sets_11_0_i51);
Declare_label(mercury__frameopt__build_sets_11_0_i52);
Declare_label(mercury__frameopt__build_sets_11_0_i57);
Declare_label(mercury__frameopt__build_sets_11_0_i61);
Declare_label(mercury__frameopt__build_sets_11_0_i73);
Declare_label(mercury__frameopt__build_sets_11_0_i75);
Declare_label(mercury__frameopt__build_sets_11_0_i78);
Declare_label(mercury__frameopt__build_sets_11_0_i77);
Declare_label(mercury__frameopt__build_sets_11_0_i84);
Declare_label(mercury__frameopt__build_sets_11_0_i11);
Declare_label(mercury__frameopt__build_sets_11_0_i86);
Declare_label(mercury__frameopt__build_sets_11_0_i1018);
Declare_label(mercury__frameopt__build_sets_11_0_i1024);
Declare_static(mercury__frameopt__setup_if_13_0);
Declare_label(mercury__frameopt__setup_if_13_0_i1007);
Declare_label(mercury__frameopt__setup_if_13_0_i1006);
Declare_label(mercury__frameopt__setup_if_13_0_i1005);
Declare_label(mercury__frameopt__setup_if_13_0_i1004);
Declare_label(mercury__frameopt__setup_if_13_0_i1003);
Declare_label(mercury__frameopt__setup_if_13_0_i1002);
Declare_label(mercury__frameopt__setup_if_13_0_i5);
Declare_label(mercury__frameopt__setup_if_13_0_i6);
Declare_label(mercury__frameopt__setup_if_13_0_i10);
Declare_label(mercury__frameopt__setup_if_13_0_i11);
Declare_label(mercury__frameopt__setup_if_13_0_i14);
Declare_label(mercury__frameopt__setup_if_13_0_i23);
Declare_label(mercury__frameopt__setup_if_13_0_i32);
Declare_label(mercury__frameopt__setup_if_13_0_i41);
Declare_label(mercury__frameopt__setup_if_13_0_i50);
Declare_label(mercury__frameopt__setup_if_13_0_i1001);
Declare_label(mercury__frameopt__setup_if_13_0_i60);
Declare_label(mercury__frameopt__setup_if_13_0_i65);
Declare_label(mercury__frameopt__setup_if_13_0_i66);
Declare_label(mercury__frameopt__setup_if_13_0_i62);
Declare_label(mercury__frameopt__setup_if_13_0_i61);
Declare_label(mercury__frameopt__setup_if_13_0_i73);
Declare_label(mercury__frameopt__setup_if_13_0_i74);
Declare_label(mercury__frameopt__setup_if_13_0_i70);
Declare_label(mercury__frameopt__setup_if_13_0_i69);
Declare_label(mercury__frameopt__setup_if_13_0_i76);
Declare_label(mercury__frameopt__setup_if_13_0_i82);
Declare_label(mercury__frameopt__setup_if_13_0_i84);
Declare_label(mercury__frameopt__setup_if_13_0_i78);
Declare_label(mercury__frameopt__setup_if_13_0_i77);
Declare_label(mercury__frameopt__setup_if_13_0_i91);
Declare_label(mercury__frameopt__setup_if_13_0_i87);
Declare_label(mercury__frameopt__setup_if_13_0_i86);
Declare_label(mercury__frameopt__setup_if_13_0_i95);
Declare_label(mercury__frameopt__setup_if_13_0_i96);
Declare_label(mercury__frameopt__setup_if_13_0_i97);
Declare_label(mercury__frameopt__setup_if_13_0_i59);
Declare_label(mercury__frameopt__setup_if_13_0_i1000);
Declare_static(mercury__frameopt__delay_slot_6_0);
Declare_label(mercury__frameopt__delay_slot_6_0_i2);
Declare_label(mercury__frameopt__delay_slot_6_0_i9);
Declare_label(mercury__frameopt__delay_slot_6_0_i8);
Declare_label(mercury__frameopt__delay_slot_6_0_i6);
Declare_label(mercury__frameopt__delay_slot_6_0_i21);
Declare_label(mercury__frameopt__delay_slot_6_0_i24);
Declare_label(mercury__frameopt__delay_slot_6_0_i26);
Declare_label(mercury__frameopt__delay_slot_6_0_i1);
Declare_static(mercury__frameopt__prev_instrs_fill_slot_2_0);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_0_i2);
Declare_static(mercury__frameopt__prev_instrs_fill_slot_2_2_0);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1013);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i6);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i9);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i11);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i12);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i8);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009);
Declare_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004);
Declare_static(mercury__frameopt__setup_label_use_5_0);
Declare_label(mercury__frameopt__setup_label_use_5_0_i7);
Declare_label(mercury__frameopt__setup_label_use_5_0_i6);
Declare_label(mercury__frameopt__setup_label_use_5_0_i9);
Declare_label(mercury__frameopt__setup_label_use_5_0_i2);
Declare_label(mercury__frameopt__setup_label_use_5_0_i13);
Declare_label(mercury__frameopt__setup_label_use_5_0_i12);
Declare_static(mercury__frameopt__setup_use_5_0);
Declare_label(mercury__frameopt__setup_use_5_0_i2);
Declare_static(mercury__frameopt__targeting_code_addr_4_0);
Declare_label(mercury__frameopt__targeting_code_addr_4_0_i1002);
Declare_static(mercury__frameopt__targeting_label_4_0);
Declare_label(mercury__frameopt__targeting_label_4_0_i7);
Declare_label(mercury__frameopt__targeting_label_4_0_i6);
Declare_label(mercury__frameopt__targeting_label_4_0_i1003);
Declare_static(mercury__frameopt__targeting_labels_4_0);
Declare_label(mercury__frameopt__targeting_labels_4_0_i1002);
Declare_static(mercury__frameopt__setup_liveval_use_4_0);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i9);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i11);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i12);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i6);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i4);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i14);
Declare_label(mercury__frameopt__setup_liveval_use_4_0_i2);
Declare_static(mercury__frameopt__dup_teardown_labels_9_0);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i7);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i11);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i13);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i14);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i10);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i15);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i16);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i17);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i18);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i19);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i5);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i4);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i1017);
Declare_label(mercury__frameopt__dup_teardown_labels_9_0_i1019);
Declare_static(mercury__frameopt__doit_17_0);
Declare_label(mercury__frameopt__doit_17_0_i6);
Declare_label(mercury__frameopt__doit_17_0_i8);
Declare_label(mercury__frameopt__doit_17_0_i12);
Declare_label(mercury__frameopt__doit_17_0_i9);
Declare_label(mercury__frameopt__doit_17_0_i5);
Declare_label(mercury__frameopt__doit_17_0_i18);
Declare_label(mercury__frameopt__doit_17_0_i19);
Declare_label(mercury__frameopt__doit_17_0_i20);
Declare_label(mercury__frameopt__doit_17_0_i21);
Declare_label(mercury__frameopt__doit_17_0_i22);
Declare_label(mercury__frameopt__doit_17_0_i23);
Declare_label(mercury__frameopt__doit_17_0_i24);
Declare_label(mercury__frameopt__doit_17_0_i25);
Declare_label(mercury__frameopt__doit_17_0_i26);
Declare_label(mercury__frameopt__doit_17_0_i27);
Declare_label(mercury__frameopt__doit_17_0_i29);
Declare_label(mercury__frameopt__doit_17_0_i30);
Declare_label(mercury__frameopt__doit_17_0_i31);
Declare_label(mercury__frameopt__doit_17_0_i33);
Declare_label(mercury__frameopt__doit_17_0_i35);
Declare_label(mercury__frameopt__doit_17_0_i36);
Declare_label(mercury__frameopt__doit_17_0_i37);
Declare_label(mercury__frameopt__doit_17_0_i38);
Declare_label(mercury__frameopt__doit_17_0_i39);
Declare_label(mercury__frameopt__doit_17_0_i40);
Declare_label(mercury__frameopt__doit_17_0_i41);
Declare_label(mercury__frameopt__doit_17_0_i43);
Declare_label(mercury__frameopt__doit_17_0_i47);
Declare_label(mercury__frameopt__doit_17_0_i48);
Declare_label(mercury__frameopt__doit_17_0_i49);
Declare_label(mercury__frameopt__doit_17_0_i44);
Declare_label(mercury__frameopt__doit_17_0_i50);
Declare_label(mercury__frameopt__doit_17_0_i51);
Declare_label(mercury__frameopt__doit_17_0_i53);
Declare_label(mercury__frameopt__doit_17_0_i54);
Declare_label(mercury__frameopt__doit_17_0_i55);
Declare_label(mercury__frameopt__doit_17_0_i57);
Declare_label(mercury__frameopt__doit_17_0_i59);
Declare_label(mercury__frameopt__doit_17_0_i61);
Declare_label(mercury__frameopt__doit_17_0_i62);
Declare_label(mercury__frameopt__doit_17_0_i63);
Declare_label(mercury__frameopt__doit_17_0_i64);
Declare_label(mercury__frameopt__doit_17_0_i65);
Declare_label(mercury__frameopt__doit_17_0_i66);
Declare_label(mercury__frameopt__doit_17_0_i67);
Declare_label(mercury__frameopt__doit_17_0_i69);
Declare_label(mercury__frameopt__doit_17_0_i70);
Declare_label(mercury__frameopt__doit_17_0_i71);
Declare_label(mercury__frameopt__doit_17_0_i72);
Declare_label(mercury__frameopt__doit_17_0_i73);
Declare_label(mercury__frameopt__doit_17_0_i75);
Declare_label(mercury__frameopt__doit_17_0_i76);
Declare_label(mercury__frameopt__doit_17_0_i77);
Declare_label(mercury__frameopt__doit_17_0_i78);
Declare_label(mercury__frameopt__doit_17_0_i79);
Declare_label(mercury__frameopt__doit_17_0_i81);
Declare_label(mercury__frameopt__doit_17_0_i82);
Declare_label(mercury__frameopt__doit_17_0_i83);
Declare_label(mercury__frameopt__doit_17_0_i84);
Declare_label(mercury__frameopt__doit_17_0_i85);
Declare_label(mercury__frameopt__doit_17_0_i87);
Declare_label(mercury__frameopt__doit_17_0_i88);
Declare_label(mercury__frameopt__doit_17_0_i89);
Declare_label(mercury__frameopt__doit_17_0_i90);
Declare_label(mercury__frameopt__doit_17_0_i91);
Declare_label(mercury__frameopt__doit_17_0_i93);
Declare_label(mercury__frameopt__doit_17_0_i95);
Declare_label(mercury__frameopt__doit_17_0_i97);
Declare_label(mercury__frameopt__doit_17_0_i17);
Declare_label(mercury__frameopt__doit_17_0_i99);
Declare_label(mercury__frameopt__doit_17_0_i101);
Declare_label(mercury__frameopt__doit_17_0_i1001);
Declare_static(mercury__frameopt__generate_if_20_0);
Declare_label(mercury__frameopt__generate_if_20_0_i2);
Declare_label(mercury__frameopt__generate_if_20_0_i8);
Declare_label(mercury__frameopt__generate_if_20_0_i10);
Declare_label(mercury__frameopt__generate_if_20_0_i14);
Declare_label(mercury__frameopt__generate_if_20_0_i13);
Declare_label(mercury__frameopt__generate_if_20_0_i16);
Declare_label(mercury__frameopt__generate_if_20_0_i17);
Declare_label(mercury__frameopt__generate_if_20_0_i18);
Declare_label(mercury__frameopt__generate_if_20_0_i19);
Declare_label(mercury__frameopt__generate_if_20_0_i4);
Declare_label(mercury__frameopt__generate_if_20_0_i3);
Declare_label(mercury__frameopt__generate_if_20_0_i27);
Declare_label(mercury__frameopt__generate_if_20_0_i29);
Declare_label(mercury__frameopt__generate_if_20_0_i32);
Declare_label(mercury__frameopt__generate_if_20_0_i34);
Declare_label(mercury__frameopt__generate_if_20_0_i35);
Declare_label(mercury__frameopt__generate_if_20_0_i21);
Declare_label(mercury__frameopt__generate_if_20_0_i20);
Declare_label(mercury__frameopt__generate_if_20_0_i37);
Declare_label(mercury__frameopt__generate_if_20_0_i43);
Declare_label(mercury__frameopt__generate_if_20_0_i46);
Declare_label(mercury__frameopt__generate_if_20_0_i39);
Declare_label(mercury__frameopt__generate_if_20_0_i38);
Declare_label(mercury__frameopt__generate_if_20_0_i53);
Declare_label(mercury__frameopt__generate_if_20_0_i49);
Declare_label(mercury__frameopt__generate_if_20_0_i48);
Declare_label(mercury__frameopt__generate_if_20_0_i57);
Declare_label(mercury__frameopt__generate_if_20_0_i58);
Declare_label(mercury__frameopt__generate_if_20_0_i59);
Declare_label(mercury__frameopt__generate_if_20_0_i62);
Declare_label(mercury__frameopt__generate_if_20_0_i67);
Declare_label(mercury__frameopt__generate_if_20_0_i69);
Declare_label(mercury__frameopt__generate_if_20_0_i64);
Declare_label(mercury__frameopt__generate_if_20_0_i63);
Declare_label(mercury__frameopt__generate_if_20_0_i73);
Declare_label(mercury__frameopt__generate_if_20_0_i74);
Declare_label(mercury__frameopt__generate_if_20_0_i75);
Declare_label(mercury__frameopt__generate_if_20_0_i76);
Declare_label(mercury__frameopt__generate_if_20_0_i81);
Declare_label(mercury__frameopt__generate_if_20_0_i85);
Declare_label(mercury__frameopt__generate_if_20_0_i84);
Declare_label(mercury__frameopt__generate_if_20_0_i87);
Declare_label(mercury__frameopt__generate_if_20_0_i88);
Declare_label(mercury__frameopt__generate_if_20_0_i80);
Declare_label(mercury__frameopt__generate_if_20_0_i90);
Declare_label(mercury__frameopt__generate_if_20_0_i91);
Declare_label(mercury__frameopt__generate_if_20_0_i70);
Declare_label(mercury__frameopt__generate_if_20_0_i96);
Declare_label(mercury__frameopt__generate_if_20_0_i99);
Declare_label(mercury__frameopt__generate_if_20_0_i102);
Declare_label(mercury__frameopt__generate_if_20_0_i104);
Declare_label(mercury__frameopt__generate_if_20_0_i98);
Declare_label(mercury__frameopt__generate_if_20_0_i105);
Declare_label(mercury__frameopt__generate_if_20_0_i106);
Declare_static(mercury__frameopt__label_without_frame_4_0);
Declare_label(mercury__frameopt__label_without_frame_4_0_i4);
Declare_label(mercury__frameopt__label_without_frame_4_0_i6);
Declare_label(mercury__frameopt__label_without_frame_4_0_i3);
Declare_label(mercury__frameopt__label_without_frame_4_0_i1000);
Declare_static(mercury__frameopt__generate_setup_7_0);
Declare_label(mercury__frameopt__generate_setup_7_0_i6);
Declare_label(mercury__frameopt__generate_setup_7_0_i1022);
Declare_label(mercury__frameopt__generate_setup_7_0_i2);
Declare_label(mercury__frameopt__generate_setup_7_0_i12);
Declare_label(mercury__frameopt__generate_setup_7_0_i8);
Declare_label(mercury__frameopt__generate_setup_7_0_i17);
Declare_label(mercury__frameopt__generate_setup_7_0_i1019);
Declare_label(mercury__frameopt__generate_setup_7_0_i14);
Declare_label(mercury__frameopt__generate_setup_7_0_i25);
Declare_label(mercury__frameopt__generate_setup_7_0_i1020);
Declare_static(mercury__frameopt__generate_labels_13_0);
Declare_label(mercury__frameopt__generate_labels_13_0_i4);
Declare_label(mercury__frameopt__generate_labels_13_0_i8);
Declare_label(mercury__frameopt__generate_labels_13_0_i6);
Declare_label(mercury__frameopt__generate_labels_13_0_i5);
Declare_label(mercury__frameopt__generate_labels_13_0_i10);
Declare_label(mercury__frameopt__generate_labels_13_0_i11);
Declare_label(mercury__frameopt__generate_labels_13_0_i12);
Declare_label(mercury__frameopt__generate_labels_13_0_i13);
Declare_label(mercury__frameopt__generate_labels_13_0_i16);
Declare_label(mercury__frameopt__generate_labels_13_0_i1019);
Declare_static(mercury__frameopt__detstack_setup_2_3_0);
Declare_label(mercury__frameopt__detstack_setup_2_3_0_i1018);
Declare_label(mercury__frameopt__detstack_setup_2_3_0_i12);
Declare_label(mercury__frameopt__detstack_setup_2_3_0_i9);
Declare_label(mercury__frameopt__detstack_setup_2_3_0_i15);
Declare_label(mercury__frameopt__detstack_setup_2_3_0_i1015);
Declare_label(mercury__frameopt__detstack_setup_2_3_0_i1);
Declare_static(mercury__frameopt__detstack_teardown_6_0);
Declare_label(mercury__frameopt__detstack_teardown_6_0_i2);
Declare_label(mercury__frameopt__detstack_teardown_6_0_i1000);
Declare_static(mercury__frameopt__detstack_teardown_2_10_0);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i2);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i7);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i15);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i8);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i17);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i18);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i19);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i23);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i26);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i27);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i28);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i6);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i1);
Declare_label(mercury__frameopt__detstack_teardown_2_10_0_i1000);
Declare_static(mercury__frameopt__insert_late_setups_4_0);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i4);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i8);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i10);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i12);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i11);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i13);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i14);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i6);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i5);
Declare_label(mercury__frameopt__insert_late_setups_4_0_i1015);
Declare_static(mercury__frameopt__insert_late_setups_list_3_0);
Declare_label(mercury__frameopt__insert_late_setups_list_3_0_i4);
Declare_label(mercury__frameopt__insert_late_setups_list_3_0_i1026);
Declare_label(mercury__frameopt__insert_late_setups_list_3_0_i1018);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_frameopt__base_type_layout_insertmap_0[];
Word * mercury_data_frameopt__base_type_info_insertmap_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_frameopt__base_type_layout_insertmap_0
};

extern Word * mercury_data_frameopt__common_14[];
Word * mercury_data_frameopt__base_type_layout_insertmap_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_frameopt__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_frameopt__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_frameopt__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_frameopt__common_14)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_llds__base_type_info_instr_0[];
extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_frameopt__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_instr_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_frameopt__common_1[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_llds__base_type_info_label_0[];
Word * mercury_data_frameopt__common_2[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1),
	(Word *) (Integer) mercury_data_llds__base_type_info_label_0
};

Word * mercury_data_frameopt__common_3[] = {
	(Word *) string_const("", 0)
};

extern Word * mercury_data_set__base_type_info_set_1[];
extern Word * mercury_data_llds__base_type_info_lval_0[];
Word * mercury_data_frameopt__common_4[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_lval_0
};

Word * mercury_data_frameopt__common_5[] = {
	(Word *) string_const("teardown omitted here", 21)
};

Word * mercury_data_frameopt__common_6[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_frameopt__common_5),
	(Word *) string_const("", 0)
};

Word * mercury_data_frameopt__common_7[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_frameopt__common_8[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_frameopt__common_9[] = {
	((Integer) 0),
	((Integer) 0)
};

Word * mercury_data_frameopt__common_10[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_frameopt__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_8)
};

Word * mercury_data_frameopt__common_11[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_frameopt__common_10),
	(Word *) string_const("late save", 9)
};

Word * mercury_data_frameopt__common_12[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_frameopt__common_13[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_llds__base_type_info_label_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_2)
};

Word * mercury_data_frameopt__common_14[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_13)
};

BEGIN_MODULE(mercury__frameopt_module0)
	init_entry(mercury__frameopt__main_5_0);
	init_label(mercury__frameopt__main_5_0_i2);
	init_label(mercury__frameopt__main_5_0_i6);
	init_label(mercury__frameopt__main_5_0_i9);
	init_label(mercury__frameopt__main_5_0_i11);
	init_label(mercury__frameopt__main_5_0_i13);
	init_label(mercury__frameopt__main_5_0_i14);
	init_label(mercury__frameopt__main_5_0_i15);
	init_label(mercury__frameopt__main_5_0_i16);
	init_label(mercury__frameopt__main_5_0_i17);
	init_label(mercury__frameopt__main_5_0_i18);
	init_label(mercury__frameopt__main_5_0_i19);
	init_label(mercury__frameopt__main_5_0_i20);
	init_label(mercury__frameopt__main_5_0_i21);
	init_label(mercury__frameopt__main_5_0_i22);
	init_label(mercury__frameopt__main_5_0_i23);
	init_label(mercury__frameopt__main_5_0_i26);
	init_label(mercury__frameopt__main_5_0_i25);
	init_label(mercury__frameopt__main_5_0_i4);
	init_label(mercury__frameopt__main_5_0_i29);
BEGIN_CODE

/* code for predicate 'frameopt__main'/5 in mode 0 */
Define_entry(mercury__frameopt__main_5_0);
	incr_sp_push_msg(15, "frameopt__main");
	detstackvar(15) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__get_prologue_4_0);
	call_localret(ENTRY(mercury__opt_util__get_prologue_4_0),
		mercury__frameopt__main_5_0_i2,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__main_5_0_i4);
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__frameopt__main_5_0_i6,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__main_5_0_i4);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__main_5_0_i4);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 15)))
		GOTO_LABEL(mercury__frameopt__main_5_0_i4);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__frameopt__detstack_setup_2_3_0),
		mercury__frameopt__main_5_0_i9,
		ENTRY(mercury__frameopt__main_5_0));
Define_label(mercury__frameopt__main_5_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__main_5_0_i4);
	detstackvar(9) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__livemap__build_2_0);
	call_localret(ENTRY(mercury__livemap__build_2_0),
		mercury__frameopt__main_5_0_i11,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__main_5_0_i4);
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__frameopt__main_5_0_i13,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i13);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__frameopt__main_5_0_i14,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__frameopt__repeat_build_sets_8_0),
		mercury__frameopt__main_5_0_i15,
		ENTRY(mercury__frameopt__main_5_0));
Define_label(mercury__frameopt__main_5_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(12) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 1000);
	{
	Declare_entry(mercury__opt_util__new_label_no_3_0);
	call_localret(ENTRY(mercury__opt_util__new_label_no_3_0),
		mercury__frameopt__main_5_0_i16,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__frameopt__main_5_0_i17,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i17);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(11);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__frameopt__dup_teardown_labels_9_0),
		mercury__frameopt__main_5_0_i18,
		ENTRY(mercury__frameopt__main_5_0));
Define_label(mercury__frameopt__main_5_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(13) = (Integer) r2;
	detstackvar(14) = (Integer) r3;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_2);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__frameopt__main_5_0_i19,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r11 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(12);
	r9 = (Integer) detstackvar(10);
	r10 = (Integer) detstackvar(3);
	r12 = (Integer) detstackvar(4);
	r13 = (Integer) detstackvar(2);
	r14 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__frameopt__doit_17_0),
		mercury__frameopt__main_5_0_i20,
		ENTRY(mercury__frameopt__main_5_0));
Define_label(mercury__frameopt__main_5_0_i20);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_frameopt__common_3);
	call_localret(STATIC(mercury__frameopt__insert_late_setups_4_0),
		mercury__frameopt__main_5_0_i21,
		ENTRY(mercury__frameopt__main_5_0));
Define_label(mercury__frameopt__main_5_0_i21);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r3 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__main_5_0_i22,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__main_5_0_i23,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__frameopt__main_5_0_i26,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__main_5_0_i25);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__frameopt__main_5_0_i25);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__frameopt__main_5_0_i4);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__frameopt__main_5_0_i29,
		ENTRY(mercury__frameopt__main_5_0));
	}
Define_label(mercury__frameopt__main_5_0_i29);
	update_prof_current_proc(LABEL(mercury__frameopt__main_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module1)
	init_entry(mercury__frameopt__is_succip_restored_1_0);
	init_label(mercury__frameopt__is_succip_restored_1_0_i8);
	init_label(mercury__frameopt__is_succip_restored_1_0_i1014);
	init_label(mercury__frameopt__is_succip_restored_1_0_i7);
	init_label(mercury__frameopt__is_succip_restored_1_0_i5);
	init_label(mercury__frameopt__is_succip_restored_1_0_i4);
	init_label(mercury__frameopt__is_succip_restored_1_0_i1011);
	init_label(mercury__frameopt__is_succip_restored_1_0_i1012);
BEGIN_CODE

/* code for predicate 'frameopt__is_succip_restored'/1 in mode 0 */
Define_entry(mercury__frameopt__is_succip_restored_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i1011);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i1014);
	incr_sp_push_msg(2, "frameopt__is_succip_restored");
	detstackvar(2) = (Integer) succip;
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i7);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 3));
	localcall(mercury__frameopt__is_succip_restored_1_0,
		LABEL(mercury__frameopt__is_succip_restored_1_0_i8),
		ENTRY(mercury__frameopt__is_succip_restored_1_0));
Define_label(mercury__frameopt__is_succip_restored_1_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__is_succip_restored_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__frameopt__is_succip_restored_1_0_i1014);
	incr_sp_push_msg(2, "frameopt__is_succip_restored");
	detstackvar(2) = (Integer) succip;
Define_label(mercury__frameopt__is_succip_restored_1_0_i7);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i4);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i4);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i4);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i4);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__is_succip_restored_1_0_i1012);
	r1 = (Integer) r2;
	r1 = TRUE;
	proceed();
Define_label(mercury__frameopt__is_succip_restored_1_0_i5);
	r2 = (Integer) detstackvar(1);
Define_label(mercury__frameopt__is_succip_restored_1_0_i4);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__frameopt__is_succip_restored_1_0,
		ENTRY(mercury__frameopt__is_succip_restored_1_0));
Define_label(mercury__frameopt__is_succip_restored_1_0_i1011);
	r1 = FALSE;
	proceed();
Define_label(mercury__frameopt__is_succip_restored_1_0_i1012);
	r1 = (Integer) r2;
	localtailcall(mercury__frameopt__is_succip_restored_1_0,
		ENTRY(mercury__frameopt__is_succip_restored_1_0));
END_MODULE

BEGIN_MODULE(mercury__frameopt_module2)
	init_entry(mercury__frameopt__dont_save_succip_2_0);
	init_label(mercury__frameopt__dont_save_succip_2_0_i10);
	init_label(mercury__frameopt__dont_save_succip_2_0_i11);
	init_label(mercury__frameopt__dont_save_succip_2_0_i3);
	init_label(mercury__frameopt__dont_save_succip_2_0_i9);
	init_label(mercury__frameopt__dont_save_succip_2_0_i1);
BEGIN_CODE

/* code for predicate 'frameopt__dont_save_succip'/2 in mode 0 */
Define_entry(mercury__frameopt__dont_save_succip_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__frameopt__dont_save_succip_2_0_i10);
	while (1) {
	incr_sp_push_msg(1, "frameopt__dont_save_succip");
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__frameopt__dont_save_succip_2_0_i11);
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i3);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i3);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i3);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r2, ((Integer) 1)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i3);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 2))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i3);
	if (((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r2, ((Integer) 2)), ((Integer) 0)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i9);
Define_label(mercury__frameopt__dont_save_succip_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
Define_label(mercury__frameopt__dont_save_succip_2_0_i9);
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		GOTO_LABEL(mercury__frameopt__dont_save_succip_2_0_i11);
	proceed();
Define_label(mercury__frameopt__dont_save_succip_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module3)
	init_entry(mercury__frameopt__repeat_build_sets_8_0);
	init_label(mercury__frameopt__repeat_build_sets_8_0_i2);
	init_label(mercury__frameopt__repeat_build_sets_8_0_i5);
	init_label(mercury__frameopt__repeat_build_sets_8_0_i7);
	init_label(mercury__frameopt__repeat_build_sets_8_0_i4);
BEGIN_CODE

/* code for predicate 'frameopt__repeat_build_sets'/8 in mode 0 */
Define_static(mercury__frameopt__repeat_build_sets_8_0);
	incr_sp_push_msg(8, "frameopt__repeat_build_sets");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = ((Integer) 1);
	r7 = ((Integer) 1);
	r8 = (Integer) detstackvar(5);
	r9 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__build_sets_11_0),
		mercury__frameopt__repeat_build_sets_8_0_i2,
		STATIC(mercury__frameopt__repeat_build_sets_8_0));
Define_label(mercury__frameopt__repeat_build_sets_8_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__repeat_build_sets_8_0));
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) r1;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__equal_2_0);
	call_localret(ENTRY(mercury__set__equal_2_0),
		mercury__frameopt__repeat_build_sets_8_0_i5,
		STATIC(mercury__frameopt__repeat_build_sets_8_0));
	}
Define_label(mercury__frameopt__repeat_build_sets_8_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__repeat_build_sets_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__repeat_build_sets_8_0_i4);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__equal_2_0);
	call_localret(ENTRY(mercury__set__equal_2_0),
		mercury__frameopt__repeat_build_sets_8_0_i7,
		STATIC(mercury__frameopt__repeat_build_sets_8_0));
	}
Define_label(mercury__frameopt__repeat_build_sets_8_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__repeat_build_sets_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__repeat_build_sets_8_0_i4);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__frameopt__repeat_build_sets_8_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__frameopt__repeat_build_sets_8_0,
		STATIC(mercury__frameopt__repeat_build_sets_8_0));
END_MODULE

BEGIN_MODULE(mercury__frameopt_module4)
	init_entry(mercury__frameopt__build_sets_11_0);
	init_label(mercury__frameopt__build_sets_11_0_i6);
	init_label(mercury__frameopt__build_sets_11_0_i5);
	init_label(mercury__frameopt__build_sets_11_0_i12);
	init_label(mercury__frameopt__build_sets_11_0_i13);
	init_label(mercury__frameopt__build_sets_11_0_i15);
	init_label(mercury__frameopt__build_sets_11_0_i16);
	init_label(mercury__frameopt__build_sets_11_0_i17);
	init_label(mercury__frameopt__build_sets_11_0_i18);
	init_label(mercury__frameopt__build_sets_11_0_i19);
	init_label(mercury__frameopt__build_sets_11_0_i21);
	init_label(mercury__frameopt__build_sets_11_0_i22);
	init_label(mercury__frameopt__build_sets_11_0_i23);
	init_label(mercury__frameopt__build_sets_11_0_i25);
	init_label(mercury__frameopt__build_sets_11_0_i26);
	init_label(mercury__frameopt__build_sets_11_0_i27);
	init_label(mercury__frameopt__build_sets_11_0_i29);
	init_label(mercury__frameopt__build_sets_11_0_i33);
	init_label(mercury__frameopt__build_sets_11_0_i34);
	init_label(mercury__frameopt__build_sets_11_0_i35);
	init_label(mercury__frameopt__build_sets_11_0_i36);
	init_label(mercury__frameopt__build_sets_11_0_i37);
	init_label(mercury__frameopt__build_sets_11_0_i39);
	init_label(mercury__frameopt__build_sets_11_0_i40);
	init_label(mercury__frameopt__build_sets_11_0_i43);
	init_label(mercury__frameopt__build_sets_11_0_i44);
	init_label(mercury__frameopt__build_sets_11_0_i47);
	init_label(mercury__frameopt__build_sets_11_0_i49);
	init_label(mercury__frameopt__build_sets_11_0_i51);
	init_label(mercury__frameopt__build_sets_11_0_i52);
	init_label(mercury__frameopt__build_sets_11_0_i57);
	init_label(mercury__frameopt__build_sets_11_0_i61);
	init_label(mercury__frameopt__build_sets_11_0_i73);
	init_label(mercury__frameopt__build_sets_11_0_i75);
	init_label(mercury__frameopt__build_sets_11_0_i78);
	init_label(mercury__frameopt__build_sets_11_0_i77);
	init_label(mercury__frameopt__build_sets_11_0_i84);
	init_label(mercury__frameopt__build_sets_11_0_i11);
	init_label(mercury__frameopt__build_sets_11_0_i86);
	init_label(mercury__frameopt__build_sets_11_0_i1018);
	init_label(mercury__frameopt__build_sets_11_0_i1024);
BEGIN_CODE

/* code for predicate 'frameopt__build_sets'/11 in mode 0 */
Define_static(mercury__frameopt__build_sets_11_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i1018);
	incr_sp_push_msg(12, "frameopt__build_sets");
	detstackvar(12) = (Integer) succip;
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__build_sets_11_0_i6,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i5);
	r1 = (Integer) r5;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = ((Integer) 1);
	r7 = ((Integer) 1);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i5);
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(9), ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(10);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i11);
	r11 = (Integer) detstackvar(9);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__frameopt__build_sets_11_0_i12) AND
		LABEL(mercury__frameopt__build_sets_11_0_i15) AND
		LABEL(mercury__frameopt__build_sets_11_0_i21) AND
		LABEL(mercury__frameopt__build_sets_11_0_i25) AND
		LABEL(mercury__frameopt__build_sets_11_0_i29) AND
		LABEL(mercury__frameopt__build_sets_11_0_i33) AND
		LABEL(mercury__frameopt__build_sets_11_0_i39) AND
		LABEL(mercury__frameopt__build_sets_11_0_i43) AND
		LABEL(mercury__frameopt__build_sets_11_0_i47) AND
		LABEL(mercury__frameopt__build_sets_11_0_i49) AND
		LABEL(mercury__frameopt__build_sets_11_0_i51) AND
		LABEL(mercury__frameopt__build_sets_11_0_i57) AND
		LABEL(mercury__frameopt__build_sets_11_0_i61) AND
		LABEL(mercury__frameopt__build_sets_11_0_i57) AND
		LABEL(mercury__frameopt__build_sets_11_0_i61) AND
		LABEL(mercury__frameopt__build_sets_11_0_i73) AND
		LABEL(mercury__frameopt__build_sets_11_0_i75) AND
		LABEL(mercury__frameopt__build_sets_11_0_i84));
Define_label(mercury__frameopt__build_sets_11_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	localcall(mercury__frameopt__build_sets_11_0,
		LABEL(mercury__frameopt__build_sets_11_0_i13),
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i13);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	r8 = (Integer) r1;
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r6 = ((Integer) 1);
	r7 = ((Integer) 1);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i15);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__build_sets_11_0_i16,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__build_sets_11_0_i17,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i17);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__frameopt__build_sets_11_0_i18,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__build_sets_11_0_i19,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r6 = (Integer) r1;
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i21);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) r1;
	r2 = ((Integer) 0);
	r3 = (Integer) r8;
	detstackvar(3) = (Integer) r4;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i22,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i23,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = ((Integer) 1);
	r7 = ((Integer) 1);
	r8 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i25);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) r6;
	r3 = (Integer) r8;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i26,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i27,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	r9 = (Integer) r6;
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i29);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) r6;
	r3 = (Integer) r8;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i26,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i33);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) r6;
	r3 = (Integer) r8;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	call_localret(STATIC(mercury__frameopt__setup_label_use_5_0),
		mercury__frameopt__build_sets_11_0_i34,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i34);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__setup_label_use_5_0),
		mercury__frameopt__build_sets_11_0_i35,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i35);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__setup_liveval_use_4_0),
		mercury__frameopt__build_sets_11_0_i36,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i36);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_liveval_use_4_0),
		mercury__frameopt__build_sets_11_0_i37,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i37);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i39);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) r6;
	r3 = (Integer) r8;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i40,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i40);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__targeting_code_addr_4_0),
		mercury__frameopt__build_sets_11_0_i23,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i43);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) r6;
	r3 = (Integer) r8;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	call_localret(STATIC(mercury__frameopt__targeting_labels_4_0),
		mercury__frameopt__build_sets_11_0_i44,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i44);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__targeting_labels_4_0),
		mercury__frameopt__build_sets_11_0_i23,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i47);
	r1 = (Integer) r10;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i49);
	r11 = (Integer) r9;
	r9 = (Integer) r7;
	r7 = (Integer) r5;
	r5 = (Integer) r3;
	r3 = (Integer) r10;
	r10 = (Integer) r8;
	r8 = (Integer) r6;
	r6 = (Integer) r4;
	r4 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__frameopt__setup_if_13_0),
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i51);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__build_sets_11_0_i52,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i52);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__build_sets_11_0_i17,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i57);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__build_sets_11_0_i18,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i61);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r10;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__build_sets_11_0_i18,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i73);
	r1 = string_const("incr_sp in frameopt__build_sets", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i75);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r10;
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__frameopt__build_sets_11_0_i78,
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i78);
	update_prof_current_proc(LABEL(mercury__frameopt__build_sets_11_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i77);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i77);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 15)))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i77);
	if (((Integer) detstackvar(9) != (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i77);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i77);
	r1 = string_const("decr_sp in frameopt__build_sets", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__build_sets_11_0));
	}
Define_label(mercury__frameopt__build_sets_11_0_i84);
	r1 = (Integer) r10;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i11);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i86);
	r1 = (Integer) r10;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i86);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__build_sets_11_0_i1024);
	r1 = (Integer) r10;
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
Define_label(mercury__frameopt__build_sets_11_0_i1018);
	r1 = (Integer) r8;
	r2 = (Integer) r9;
	proceed();
Define_label(mercury__frameopt__build_sets_11_0_i1024);
	r1 = (Integer) r10;
	localtailcall(mercury__frameopt__build_sets_11_0,
		STATIC(mercury__frameopt__build_sets_11_0));
END_MODULE

BEGIN_MODULE(mercury__frameopt_module5)
	init_entry(mercury__frameopt__setup_if_13_0);
	init_label(mercury__frameopt__setup_if_13_0_i1007);
	init_label(mercury__frameopt__setup_if_13_0_i1006);
	init_label(mercury__frameopt__setup_if_13_0_i1005);
	init_label(mercury__frameopt__setup_if_13_0_i1004);
	init_label(mercury__frameopt__setup_if_13_0_i1003);
	init_label(mercury__frameopt__setup_if_13_0_i1002);
	init_label(mercury__frameopt__setup_if_13_0_i5);
	init_label(mercury__frameopt__setup_if_13_0_i6);
	init_label(mercury__frameopt__setup_if_13_0_i10);
	init_label(mercury__frameopt__setup_if_13_0_i11);
	init_label(mercury__frameopt__setup_if_13_0_i14);
	init_label(mercury__frameopt__setup_if_13_0_i23);
	init_label(mercury__frameopt__setup_if_13_0_i32);
	init_label(mercury__frameopt__setup_if_13_0_i41);
	init_label(mercury__frameopt__setup_if_13_0_i50);
	init_label(mercury__frameopt__setup_if_13_0_i1001);
	init_label(mercury__frameopt__setup_if_13_0_i60);
	init_label(mercury__frameopt__setup_if_13_0_i65);
	init_label(mercury__frameopt__setup_if_13_0_i66);
	init_label(mercury__frameopt__setup_if_13_0_i62);
	init_label(mercury__frameopt__setup_if_13_0_i61);
	init_label(mercury__frameopt__setup_if_13_0_i73);
	init_label(mercury__frameopt__setup_if_13_0_i74);
	init_label(mercury__frameopt__setup_if_13_0_i70);
	init_label(mercury__frameopt__setup_if_13_0_i69);
	init_label(mercury__frameopt__setup_if_13_0_i76);
	init_label(mercury__frameopt__setup_if_13_0_i82);
	init_label(mercury__frameopt__setup_if_13_0_i84);
	init_label(mercury__frameopt__setup_if_13_0_i78);
	init_label(mercury__frameopt__setup_if_13_0_i77);
	init_label(mercury__frameopt__setup_if_13_0_i91);
	init_label(mercury__frameopt__setup_if_13_0_i87);
	init_label(mercury__frameopt__setup_if_13_0_i86);
	init_label(mercury__frameopt__setup_if_13_0_i95);
	init_label(mercury__frameopt__setup_if_13_0_i96);
	init_label(mercury__frameopt__setup_if_13_0_i97);
	init_label(mercury__frameopt__setup_if_13_0_i59);
	init_label(mercury__frameopt__setup_if_13_0_i1000);
BEGIN_CODE

/* code for predicate 'frameopt__setup_if'/13 in mode 0 */
Define_static(mercury__frameopt__setup_if_13_0);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i1001);
	COMPUTED_GOTO(unmkbody((Integer) r2),
		LABEL(mercury__frameopt__setup_if_13_0_i1007) AND
		LABEL(mercury__frameopt__setup_if_13_0_i1006) AND
		LABEL(mercury__frameopt__setup_if_13_0_i1005) AND
		LABEL(mercury__frameopt__setup_if_13_0_i1004) AND
		LABEL(mercury__frameopt__setup_if_13_0_i1003) AND
		LABEL(mercury__frameopt__setup_if_13_0_i1002));
Define_label(mercury__frameopt__setup_if_13_0_i1007);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i5);
Define_label(mercury__frameopt__setup_if_13_0_i1006);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i14);
Define_label(mercury__frameopt__setup_if_13_0_i1005);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i23);
Define_label(mercury__frameopt__setup_if_13_0_i1004);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i32);
Define_label(mercury__frameopt__setup_if_13_0_i1003);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i41);
Define_label(mercury__frameopt__setup_if_13_0_i1002);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i50);
Define_label(mercury__frameopt__setup_if_13_0_i5);
	if (((Integer) r8 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i6);
	r1 = string_const("proceed without teardown in frameopt__setup_if", 46);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i6);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__setup_if_13_0_i10,
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__setup_if_13_0_i11,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	r6 = (Integer) r1;
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	tailcall(STATIC(mercury__frameopt__build_sets_11_0),
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i14);
	if (((Integer) r8 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i6);
	r1 = string_const("redo without stack frame in frameopt__setup_if", 46);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i23);
	if (((Integer) r8 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i6);
	r1 = string_const("fail without stack frame in frameopt__setup_if", 46);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i32);
	if (((Integer) r8 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i6);
	r1 = string_const("det_closure without teardown in frameopt__setup_if", 50);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i41);
	if (((Integer) r8 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i6);
	r1 = string_const("det_closure without teardown in frameopt__setup_if", 50);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i50);
	if (((Integer) r8 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i6);
	r1 = string_const("det_closure without teardown in frameopt__setup_if", 50);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i1001);
	incr_sp_push_msg(15, "frameopt__setup_if");
	detstackvar(15) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i59);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__setup_if_13_0_i60,
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i60);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if (((Integer) detstackvar(7) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i61);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i61);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__setup_if_13_0_i65,
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i65);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i62);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__setup_if_13_0_i66,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i66);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i62);
	r1 = (Integer) r5;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = ((Integer) 1);
	r7 = ((Integer) 1);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	tailcall(STATIC(mercury__frameopt__build_sets_11_0),
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i62);
	r1 = (Integer) detstackvar(12);
Define_label(mercury__frameopt__setup_if_13_0_i61);
	if (((Integer) detstackvar(7) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i69);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i69);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__setup_if_13_0_i73,
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i73);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i70);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__frameopt__setup_if_13_0_i74,
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i74);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i70);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = ((Integer) 0);
	r7 = ((Integer) 0);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	tailcall(STATIC(mercury__frameopt__build_sets_11_0),
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i70);
	r1 = (Integer) detstackvar(12);
Define_label(mercury__frameopt__setup_if_13_0_i69);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__setup_if_13_0_i76,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i76);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i77);
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__prev_instrs_fill_slot_2_0),
		mercury__frameopt__setup_if_13_0_i82,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i82);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i78);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__frameopt__delay_slot_6_0),
		mercury__frameopt__setup_if_13_0_i84,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i84);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i78);
	r9 = (Integer) r3;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i95);
Define_label(mercury__frameopt__setup_if_13_0_i78);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__frameopt__setup_if_13_0_i77);
	if (((Integer) detstackvar(5) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i86);
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__prev_instrs_fill_slot_2_0),
		mercury__frameopt__setup_if_13_0_i91,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i91);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i87);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i86);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(9);
	r7 = (Integer) detstackvar(10);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r8 = ((Integer) 0);
	r9 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__frameopt__setup_if_13_0_i95);
Define_label(mercury__frameopt__setup_if_13_0_i87);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__frameopt__setup_if_13_0_i86);
	r8 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(2);
Define_label(mercury__frameopt__setup_if_13_0_i95);
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(10) = (Integer) r7;
	detstackvar(11) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	detstackvar(12) = (Integer) r8;
	detstackvar(13) = (Integer) r9;
	call_localret(STATIC(mercury__frameopt__targeting_label_4_0),
		mercury__frameopt__setup_if_13_0_i96,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i96);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__frameopt__targeting_label_4_0),
		mercury__frameopt__setup_if_13_0_i97,
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i97);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_if_13_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	tailcall(STATIC(mercury__frameopt__build_sets_11_0),
		STATIC(mercury__frameopt__setup_if_13_0));
Define_label(mercury__frameopt__setup_if_13_0_i59);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__frameopt__setup_if_13_0_i1000);
	r1 = string_const("imported label in frameopt__setup_if", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
Define_label(mercury__frameopt__setup_if_13_0_i1000);
	r1 = string_const("succeed in frameopt__setup_if", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__setup_if_13_0));
	}
END_MODULE

BEGIN_MODULE(mercury__frameopt_module6)
	init_entry(mercury__frameopt__delay_slot_6_0);
	init_label(mercury__frameopt__delay_slot_6_0_i2);
	init_label(mercury__frameopt__delay_slot_6_0_i9);
	init_label(mercury__frameopt__delay_slot_6_0_i8);
	init_label(mercury__frameopt__delay_slot_6_0_i6);
	init_label(mercury__frameopt__delay_slot_6_0_i21);
	init_label(mercury__frameopt__delay_slot_6_0_i24);
	init_label(mercury__frameopt__delay_slot_6_0_i26);
	init_label(mercury__frameopt__delay_slot_6_0_i1);
BEGIN_CODE

/* code for predicate 'frameopt__delay_slot'/6 in mode 0 */
Define_static(mercury__frameopt__delay_slot_6_0);
	incr_sp_push_msg(5, "frameopt__delay_slot");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__frameopt__delay_slot_6_0_i2,
		STATIC(mercury__frameopt__delay_slot_6_0));
	}
Define_label(mercury__frameopt__delay_slot_6_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_slot_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i8);
	r4 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	if (((Integer) r4 != ((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i9);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r8 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 1),
		((Integer) 0),
		((Integer) 1)
	};
	if ((((Integer) 0) != (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) field(mktag(3), (Integer) r3, ((Integer) 1)))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	}
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_4);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i6);
	}
Define_label(mercury__frameopt__delay_slot_6_0_i9);
	if (((Integer) r4 != ((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) r3, ((Integer) 2))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r3, ((Integer) 2)), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(3), (Integer) r3, ((Integer) 3))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r3, ((Integer) 3)), ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r5 = (Integer) r4;
	r4 = (Integer) detstackvar(2);
	r6 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	r5 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 1));
	r9 = (Integer) r6;
	r6 = (Integer) field(mktag(3), (Integer) r7, ((Integer) 1));
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 0),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 0),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 0),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1),
		((Integer) 1)
	};
	r7 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), (Integer) field(mktag(3), (Integer) r9, ((Integer) 1)));
	}
	if ((((Integer) 0) != (Integer) r7))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r7 = (Integer) r5;
	r5 = (Integer) r1;
	r8 = (Integer) r6;
	r6 = (Integer) r2;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_4);
	GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i6);
Define_label(mercury__frameopt__delay_slot_6_0_i8);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	if ((tag((Integer) field(mktag(0), (Integer) r3, ((Integer) 0))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r5 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_4);
Define_label(mercury__frameopt__delay_slot_6_0_i6);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__frameopt__delay_slot_6_0_i21,
		STATIC(mercury__frameopt__delay_slot_6_0));
	}
Define_label(mercury__frameopt__delay_slot_6_0_i21);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_slot_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__delay_slot_6_0_i24,
		STATIC(mercury__frameopt__delay_slot_6_0));
	}
Define_label(mercury__frameopt__delay_slot_6_0_i24);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_slot_6_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__opt_util__rval_free_of_lval_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_free_of_lval_2_0),
		mercury__frameopt__delay_slot_6_0_i26,
		STATIC(mercury__frameopt__delay_slot_6_0));
	}
Define_label(mercury__frameopt__delay_slot_6_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_slot_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__delay_slot_6_0_i1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__frameopt__delay_slot_6_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module7)
	init_entry(mercury__frameopt__prev_instrs_fill_slot_2_0);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_0_i2);
BEGIN_CODE

/* code for predicate 'frameopt__prev_instrs_fill_slot'/2 in mode 0 */
Define_static(mercury__frameopt__prev_instrs_fill_slot_2_0);
	incr_sp_push_msg(2, "frameopt__prev_instrs_fill_slot");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__lvals_in_rval_2_0);
	call_localret(ENTRY(mercury__opt_util__lvals_in_rval_2_0),
		mercury__frameopt__prev_instrs_fill_slot_2_0_i2,
		STATIC(mercury__frameopt__prev_instrs_fill_slot_2_0));
	}
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__prev_instrs_fill_slot_2_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__frameopt__prev_instrs_fill_slot_2_2_0),
		STATIC(mercury__frameopt__prev_instrs_fill_slot_2_0));
END_MODULE

BEGIN_MODULE(mercury__frameopt_module8)
	init_entry(mercury__frameopt__prev_instrs_fill_slot_2_2_0);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1013);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i6);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i9);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i11);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i12);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i8);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009);
	init_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004);
BEGIN_CODE

/* code for predicate 'frameopt__prev_instrs_fill_slot_2'/2 in mode 0 */
Define_static(mercury__frameopt__prev_instrs_fill_slot_2_2_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004);
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)),
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1013) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009) AND
		LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004));
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1013);
	incr_sp_push_msg(4, "frameopt__prev_instrs_fill_slot_2");
	detstackvar(4) = (Integer) succip;
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i6);
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__frameopt__prev_instrs_fill_slot_2_2_0_i9,
		STATIC(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
	}
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i8);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__opt_util__lvals_in_rval_2_0);
	call_localret(ENTRY(mercury__opt_util__lvals_in_rval_2_0),
		mercury__frameopt__prev_instrs_fill_slot_2_2_0_i11,
		STATIC(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
	}
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__prev_instrs_fill_slot_2_2_0_i12,
		STATIC(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
	}
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__frameopt__prev_instrs_fill_slot_2_2_0,
		STATIC(mercury__frameopt__prev_instrs_fill_slot_2_2_0));
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i8);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury__frameopt__prev_instrs_fill_slot_2_2_0_i1004);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module9)
	init_entry(mercury__frameopt__setup_label_use_5_0);
	init_label(mercury__frameopt__setup_label_use_5_0_i7);
	init_label(mercury__frameopt__setup_label_use_5_0_i6);
	init_label(mercury__frameopt__setup_label_use_5_0_i9);
	init_label(mercury__frameopt__setup_label_use_5_0_i2);
	init_label(mercury__frameopt__setup_label_use_5_0_i13);
	init_label(mercury__frameopt__setup_label_use_5_0_i12);
BEGIN_CODE

/* code for predicate 'frameopt__setup_label_use'/5 in mode 0 */
Define_static(mercury__frameopt__setup_label_use_5_0);
	incr_sp_push_msg(4, "frameopt__setup_label_use");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_label_use_5_0_i2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__setup_label_use_5_0_i7,
		STATIC(mercury__frameopt__setup_label_use_5_0));
	}
Define_label(mercury__frameopt__setup_label_use_5_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_label_use_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_label_use_5_0_i6);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frameopt__setup_label_use_5_0_i6);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__frameopt__setup_label_use_5_0_i9,
		STATIC(mercury__frameopt__setup_label_use_5_0));
	}
Define_label(mercury__frameopt__setup_label_use_5_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_label_use_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frameopt__setup_label_use_5_0_i2);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__setup_label_use_5_0_i13,
		STATIC(mercury__frameopt__setup_label_use_5_0));
	}
Define_label(mercury__frameopt__setup_label_use_5_0_i13);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_label_use_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__setup_label_use_5_0_i12);
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frameopt__setup_label_use_5_0_i12);
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module10)
	init_entry(mercury__frameopt__setup_use_5_0);
	init_label(mercury__frameopt__setup_use_5_0_i2);
BEGIN_CODE

/* code for predicate 'frameopt__setup_use'/5 in mode 0 */
Define_static(mercury__frameopt__setup_use_5_0);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__setup_use_5_0_i2);
	r1 = ((Integer) 0);
	r2 = ((Integer) 0);
	proceed();
Define_label(mercury__frameopt__setup_use_5_0_i2);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module11)
	init_entry(mercury__frameopt__targeting_code_addr_4_0);
	init_label(mercury__frameopt__targeting_code_addr_4_0_i1002);
BEGIN_CODE

/* code for predicate 'frameopt__targeting_code_addr'/4 in mode 0 */
Define_static(mercury__frameopt__targeting_code_addr_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__targeting_code_addr_4_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__frameopt__targeting_label_4_0),
		STATIC(mercury__frameopt__targeting_code_addr_4_0));
Define_label(mercury__frameopt__targeting_code_addr_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module12)
	init_entry(mercury__frameopt__targeting_label_4_0);
	init_label(mercury__frameopt__targeting_label_4_0_i7);
	init_label(mercury__frameopt__targeting_label_4_0_i6);
	init_label(mercury__frameopt__targeting_label_4_0_i1003);
BEGIN_CODE

/* code for predicate 'frameopt__targeting_label'/4 in mode 0 */
Define_static(mercury__frameopt__targeting_label_4_0);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__targeting_label_4_0_i1003);
	incr_sp_push_msg(3, "frameopt__targeting_label");
	detstackvar(3) = (Integer) succip;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__targeting_label_4_0_i7,
		STATIC(mercury__frameopt__targeting_label_4_0));
	}
Define_label(mercury__frameopt__targeting_label_4_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__targeting_label_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__targeting_label_4_0_i6);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__frameopt__targeting_label_4_0_i6);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	tailcall(ENTRY(mercury__set__insert_3_1),
		STATIC(mercury__frameopt__targeting_label_4_0));
	}
Define_label(mercury__frameopt__targeting_label_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module13)
	init_entry(mercury__frameopt__targeting_labels_4_0);
	init_label(mercury__frameopt__targeting_labels_4_0_i1002);
BEGIN_CODE

/* code for predicate 'frameopt__targeting_labels'/4 in mode 0 */
Define_static(mercury__frameopt__targeting_labels_4_0);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__targeting_labels_4_0_i1002);
	r2 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__insert_list_3_0);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__frameopt__targeting_labels_4_0));
	}
Define_label(mercury__frameopt__targeting_labels_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module14)
	init_entry(mercury__frameopt__setup_liveval_use_4_0);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i9);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i11);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i12);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i6);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i4);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i14);
	init_label(mercury__frameopt__setup_liveval_use_4_0_i2);
BEGIN_CODE

/* code for predicate 'frameopt__setup_liveval_use'/4 in mode 0 */
Define_static(mercury__frameopt__setup_liveval_use_4_0);
	incr_sp_push_msg(7, "frameopt__setup_liveval_use");
	detstackvar(7) = (Integer) succip;
	detstackvar(4) = (Integer) curfr;
	detstackvar(5) = (Integer) maxfr;
	detstackvar(6) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__frameopt__setup_liveval_use_4_0_i6);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__setup_liveval_use_4_0_i9,
		STATIC(mercury__frameopt__setup_liveval_use_4_0));
	}
Define_label(mercury__frameopt__setup_liveval_use_4_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_liveval_use_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__setup_liveval_use_4_0_i4);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__frameopt__setup_liveval_use_4_0_i11,
		STATIC(mercury__frameopt__setup_liveval_use_4_0));
	}
Define_label(mercury__frameopt__setup_liveval_use_4_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_liveval_use_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	{
	Declare_entry(mercury__set__member_2_1);
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__frameopt__setup_liveval_use_4_0_i12,
		STATIC(mercury__frameopt__setup_liveval_use_4_0));
	}
Define_label(mercury__frameopt__setup_liveval_use_4_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_liveval_use_4_0));
	{
	Declare_entry(do_redo);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO(ENTRY(do_redo));
	}
	{
	Declare_entry(do_redo);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__frameopt__setup_liveval_use_4_0_i14);
Define_label(mercury__frameopt__setup_liveval_use_4_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__setup_liveval_use_4_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(4);
Define_label(mercury__frameopt__setup_liveval_use_4_0_i4);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__frameopt__setup_liveval_use_4_0_i2);
Define_label(mercury__frameopt__setup_liveval_use_4_0_i14);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__set__insert_3_1);
	tailcall(ENTRY(mercury__set__insert_3_1),
		STATIC(mercury__frameopt__setup_liveval_use_4_0));
	}
Define_label(mercury__frameopt__setup_liveval_use_4_0_i2);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module15)
	init_entry(mercury__frameopt__dup_teardown_labels_9_0);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i7);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i11);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i13);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i14);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i10);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i15);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i16);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i17);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i18);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i19);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i5);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i4);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i1017);
	init_label(mercury__frameopt__dup_teardown_labels_9_0_i1019);
BEGIN_CODE

/* code for predicate 'frameopt__dup_teardown_labels'/9 in mode 0 */
Define_static(mercury__frameopt__dup_teardown_labels_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__dup_teardown_labels_9_0_i1017);
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__dup_teardown_labels_9_0_i1019);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__frameopt__dup_teardown_labels_9_0_i1019);
	incr_sp_push_msg(17, "frameopt__dup_teardown_labels");
	detstackvar(17) = (Integer) succip;
	detstackvar(9) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	r1 = (Integer) r7;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__dup_teardown_labels_9_0_i7,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__dup_teardown_labels_9_0_i5);
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(6);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	detstackvar(10) = (Integer) r2;
	detstackvar(11) = (Integer) r3;
	detstackvar(12) = (Integer) r4;
	detstackvar(13) = (Integer) r5;
	detstackvar(14) = ((Integer) detstackvar(6) + ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = string_const("non-teardown parallel label", 27);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(2);
	detstackvar(15) = (Integer) r6;
	detstackvar(16) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r6;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__dup_teardown_labels_9_0_i11,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__dup_teardown_labels_9_0_i10);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__dup_teardown_labels_9_0_i13,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i13);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__bimap__set_4_0);
	call_localret(ENTRY(mercury__bimap__set_4_0),
		mercury__frameopt__dup_teardown_labels_9_0_i14,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(14);
	r7 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__frameopt__dup_teardown_labels_9_0_i17);
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i10);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__dup_teardown_labels_9_0_i15,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(15);
	r5 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__bimap__set_4_0);
	call_localret(ENTRY(mercury__bimap__set_4_0),
		mercury__frameopt__dup_teardown_labels_9_0_i16,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r6 = (Integer) detstackvar(14);
	r7 = (Integer) detstackvar(4);
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i17);
	detstackvar(4) = (Integer) r7;
	localcall(mercury__frameopt__dup_teardown_labels_9_0,
		LABEL(mercury__frameopt__dup_teardown_labels_9_0_i18),
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__dup_teardown_labels_9_0_i19,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
	}
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__dup_teardown_labels_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(8);
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i4);
	r1 = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	localtailcall(mercury__frameopt__dup_teardown_labels_9_0,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i1017);
	r1 = (Integer) r4;
	r2 = (Integer) r6;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__frameopt__dup_teardown_labels_9_0_i1019);
	r1 = (Integer) r7;
	localtailcall(mercury__frameopt__dup_teardown_labels_9_0,
		STATIC(mercury__frameopt__dup_teardown_labels_9_0));
END_MODULE

BEGIN_MODULE(mercury__frameopt_module16)
	init_entry(mercury__frameopt__doit_17_0);
	init_label(mercury__frameopt__doit_17_0_i6);
	init_label(mercury__frameopt__doit_17_0_i8);
	init_label(mercury__frameopt__doit_17_0_i12);
	init_label(mercury__frameopt__doit_17_0_i9);
	init_label(mercury__frameopt__doit_17_0_i5);
	init_label(mercury__frameopt__doit_17_0_i18);
	init_label(mercury__frameopt__doit_17_0_i19);
	init_label(mercury__frameopt__doit_17_0_i20);
	init_label(mercury__frameopt__doit_17_0_i21);
	init_label(mercury__frameopt__doit_17_0_i22);
	init_label(mercury__frameopt__doit_17_0_i23);
	init_label(mercury__frameopt__doit_17_0_i24);
	init_label(mercury__frameopt__doit_17_0_i25);
	init_label(mercury__frameopt__doit_17_0_i26);
	init_label(mercury__frameopt__doit_17_0_i27);
	init_label(mercury__frameopt__doit_17_0_i29);
	init_label(mercury__frameopt__doit_17_0_i30);
	init_label(mercury__frameopt__doit_17_0_i31);
	init_label(mercury__frameopt__doit_17_0_i33);
	init_label(mercury__frameopt__doit_17_0_i35);
	init_label(mercury__frameopt__doit_17_0_i36);
	init_label(mercury__frameopt__doit_17_0_i37);
	init_label(mercury__frameopt__doit_17_0_i38);
	init_label(mercury__frameopt__doit_17_0_i39);
	init_label(mercury__frameopt__doit_17_0_i40);
	init_label(mercury__frameopt__doit_17_0_i41);
	init_label(mercury__frameopt__doit_17_0_i43);
	init_label(mercury__frameopt__doit_17_0_i47);
	init_label(mercury__frameopt__doit_17_0_i48);
	init_label(mercury__frameopt__doit_17_0_i49);
	init_label(mercury__frameopt__doit_17_0_i44);
	init_label(mercury__frameopt__doit_17_0_i50);
	init_label(mercury__frameopt__doit_17_0_i51);
	init_label(mercury__frameopt__doit_17_0_i53);
	init_label(mercury__frameopt__doit_17_0_i54);
	init_label(mercury__frameopt__doit_17_0_i55);
	init_label(mercury__frameopt__doit_17_0_i57);
	init_label(mercury__frameopt__doit_17_0_i59);
	init_label(mercury__frameopt__doit_17_0_i61);
	init_label(mercury__frameopt__doit_17_0_i62);
	init_label(mercury__frameopt__doit_17_0_i63);
	init_label(mercury__frameopt__doit_17_0_i64);
	init_label(mercury__frameopt__doit_17_0_i65);
	init_label(mercury__frameopt__doit_17_0_i66);
	init_label(mercury__frameopt__doit_17_0_i67);
	init_label(mercury__frameopt__doit_17_0_i69);
	init_label(mercury__frameopt__doit_17_0_i70);
	init_label(mercury__frameopt__doit_17_0_i71);
	init_label(mercury__frameopt__doit_17_0_i72);
	init_label(mercury__frameopt__doit_17_0_i73);
	init_label(mercury__frameopt__doit_17_0_i75);
	init_label(mercury__frameopt__doit_17_0_i76);
	init_label(mercury__frameopt__doit_17_0_i77);
	init_label(mercury__frameopt__doit_17_0_i78);
	init_label(mercury__frameopt__doit_17_0_i79);
	init_label(mercury__frameopt__doit_17_0_i81);
	init_label(mercury__frameopt__doit_17_0_i82);
	init_label(mercury__frameopt__doit_17_0_i83);
	init_label(mercury__frameopt__doit_17_0_i84);
	init_label(mercury__frameopt__doit_17_0_i85);
	init_label(mercury__frameopt__doit_17_0_i87);
	init_label(mercury__frameopt__doit_17_0_i88);
	init_label(mercury__frameopt__doit_17_0_i89);
	init_label(mercury__frameopt__doit_17_0_i90);
	init_label(mercury__frameopt__doit_17_0_i91);
	init_label(mercury__frameopt__doit_17_0_i93);
	init_label(mercury__frameopt__doit_17_0_i95);
	init_label(mercury__frameopt__doit_17_0_i97);
	init_label(mercury__frameopt__doit_17_0_i17);
	init_label(mercury__frameopt__doit_17_0_i99);
	init_label(mercury__frameopt__doit_17_0_i101);
	init_label(mercury__frameopt__doit_17_0_i1001);
BEGIN_CODE

/* code for predicate 'frameopt__doit'/17 in mode 0 */
Define_static(mercury__frameopt__doit_17_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i1001);
	incr_sp_push_msg(19, "frameopt__doit");
	detstackvar(19) = (Integer) succip;
	detstackvar(17) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(16) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__doit_17_0_i6,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i5);
	detstackvar(11) = (Integer) r2;
	detstackvar(15) = (Integer) r3;
	detstackvar(18) = (Integer) r4;
	r1 = (Integer) r5;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i8),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	if (((Integer) detstackvar(4) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i9);
	r5 = (Integer) detstackvar(15);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) tempr1;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(18);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
	}
Define_label(mercury__frameopt__doit_17_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__frameopt__doit_17_0_i9);
	r4 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	detstackvar(15) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_frameopt__common_7);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(18);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
	}
Define_label(mercury__frameopt__doit_17_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	r16 = (Integer) detstackvar(16);
	r15 = (Integer) detstackvar(17);
	r1 = (Integer) field(mktag(0), (Integer) r16, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i17);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__frameopt__doit_17_0_i18) AND
		LABEL(mercury__frameopt__doit_17_0_i21) AND
		LABEL(mercury__frameopt__doit_17_0_i29) AND
		LABEL(mercury__frameopt__doit_17_0_i33) AND
		LABEL(mercury__frameopt__doit_17_0_i35) AND
		LABEL(mercury__frameopt__doit_17_0_i37) AND
		LABEL(mercury__frameopt__doit_17_0_i43) AND
		LABEL(mercury__frameopt__doit_17_0_i53) AND
		LABEL(mercury__frameopt__doit_17_0_i57) AND
		LABEL(mercury__frameopt__doit_17_0_i59) AND
		LABEL(mercury__frameopt__doit_17_0_i61) AND
		LABEL(mercury__frameopt__doit_17_0_i69) AND
		LABEL(mercury__frameopt__doit_17_0_i75) AND
		LABEL(mercury__frameopt__doit_17_0_i81) AND
		LABEL(mercury__frameopt__doit_17_0_i87) AND
		LABEL(mercury__frameopt__doit_17_0_i93) AND
		LABEL(mercury__frameopt__doit_17_0_i95) AND
		LABEL(mercury__frameopt__doit_17_0_i97));
Define_label(mercury__frameopt__doit_17_0_i18);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r16, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i19),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r5 = (Integer) r1;
	r6 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	r11 = (Integer) r5;
	r14 = (Integer) r6;
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i20),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i20);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r4 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
	}
Define_label(mercury__frameopt__doit_17_0_i21);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i22,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i23,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__frameopt__doit_17_0_i24,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i24);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__doit_17_0_i25,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i25);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i26,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i27),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i29);
	r1 = (Integer) r5;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r6;
	r6 = (Integer) detstackvar(2);
	r5 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = ((Integer) 0);
	r4 = ((Integer) 0);
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i30,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i30);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i31),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i31);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i33);
	r1 = string_const("mkframe in frameopt__doit", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i35);
	detstackvar(16) = (Integer) r16;
	r1 = (Integer) r15;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r16;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i36),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i36);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r4 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__frameopt__doit_17_0_i37);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) r7;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__doit_17_0_i38,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i38);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__doit_17_0_i39,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i39);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r4;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i40,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i40);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i41),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i41);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i43);
	if ((tag((Integer) field(mktag(3), (Integer) r1, ((Integer) 1))) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i44);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) field(mktag(1), (Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), ((Integer) 0));
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) r7;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__doit_17_0_i47,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i47);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__doit_17_0_i48,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i48);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i49,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i49);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r16 = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	r15 = (Integer) detstackvar(16);
	GOTO_LABEL(mercury__frameopt__doit_17_0_i50);
Define_label(mercury__frameopt__doit_17_0_i44);
	r1 = (Integer) r15;
	r15 = (Integer) r16;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r16 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__frameopt__doit_17_0_i50);
	detstackvar(16) = (Integer) r15;
	detstackvar(1) = (Integer) r16;
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i51),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i51);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i53);
	detstackvar(8) = (Integer) r9;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r5;
	r5 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r6;
	r6 = (Integer) r7;
	detstackvar(6) = (Integer) r7;
	r7 = (Integer) r8;
	detstackvar(7) = (Integer) r8;
	r8 = (Integer) r10;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) r10;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r16, ((Integer) 1));
	r9 = (Integer) r12;
	r10 = (Integer) r14;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(17) = (Integer) r15;
	call_localret(STATIC(mercury__frameopt__generate_labels_13_0),
		mercury__frameopt__doit_17_0_i54,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i54);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	tempr2 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) tempr2;
	detstackvar(1) = (Integer) tempr1;
	r14 = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i55),
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i55);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	detstackvar(15) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
	}
Define_label(mercury__frameopt__doit_17_0_i57);
	detstackvar(16) = (Integer) r16;
	r1 = (Integer) r15;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i36),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i59);
	r17 = (Integer) r14;
	r14 = (Integer) r11;
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r16, ((Integer) 1));
	r16 = (Integer) r13;
	r13 = (Integer) r10;
	r10 = (Integer) r7;
	r7 = (Integer) r4;
	r4 = (Integer) r15;
	r15 = (Integer) r12;
	r12 = (Integer) r9;
	r9 = (Integer) r6;
	r6 = (Integer) tempr1;
	r11 = (Integer) r8;
	r8 = (Integer) r5;
	r5 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	tailcall(STATIC(mercury__frameopt__generate_if_20_0),
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i61);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	detstackvar(11) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i62,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i62);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i63,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i63);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__bool__or_3_0);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__frameopt__doit_17_0_i64,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i64);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__doit_17_0_i65,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i65);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i66,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i66);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i67),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i67);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i69);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i70,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i70);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__doit_17_0_i71,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i71);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i72,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i72);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i73),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i73);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i75);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i76,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i76);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__doit_17_0_i77,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i77);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i78,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i78);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i79),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i79);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i81);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i82,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i82);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__doit_17_0_i83,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i83);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i84,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i84);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i85),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i85);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i87);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r15;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__doit_17_0_i88,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i88);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__doit_17_0_i89,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i89);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__doit_17_0_i90,
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i90);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(17);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(12);
	r13 = (Integer) detstackvar(13);
	r14 = (Integer) detstackvar(14);
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i91),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i91);
	update_prof_current_proc(LABEL(mercury__frameopt__doit_17_0));
	detstackvar(11) = (Integer) r1;
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(1);
	r6 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i93);
	r1 = string_const("incr_sp in frameopt__doit", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i95);
	r1 = string_const("decr_sp in frameopt__doit", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__doit_17_0_i12,
		STATIC(mercury__frameopt__doit_17_0));
	}
Define_label(mercury__frameopt__doit_17_0_i97);
	detstackvar(16) = (Integer) r16;
	r1 = (Integer) r15;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i36),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i17);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i99);
	r1 = (Integer) r15;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	detstackvar(16) = (Integer) r16;
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i36),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i99);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__doit_17_0_i101);
	detstackvar(16) = (Integer) r16;
	r1 = (Integer) r15;
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i36),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i101);
	detstackvar(16) = (Integer) r16;
	r1 = (Integer) r15;
	localcall(mercury__frameopt__doit_17_0,
		LABEL(mercury__frameopt__doit_17_0_i36),
		STATIC(mercury__frameopt__doit_17_0));
Define_label(mercury__frameopt__doit_17_0_i1001);
	r1 = (Integer) r11;
	r2 = (Integer) r14;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module17)
	init_entry(mercury__frameopt__generate_if_20_0);
	init_label(mercury__frameopt__generate_if_20_0_i2);
	init_label(mercury__frameopt__generate_if_20_0_i8);
	init_label(mercury__frameopt__generate_if_20_0_i10);
	init_label(mercury__frameopt__generate_if_20_0_i14);
	init_label(mercury__frameopt__generate_if_20_0_i13);
	init_label(mercury__frameopt__generate_if_20_0_i16);
	init_label(mercury__frameopt__generate_if_20_0_i17);
	init_label(mercury__frameopt__generate_if_20_0_i18);
	init_label(mercury__frameopt__generate_if_20_0_i19);
	init_label(mercury__frameopt__generate_if_20_0_i4);
	init_label(mercury__frameopt__generate_if_20_0_i3);
	init_label(mercury__frameopt__generate_if_20_0_i27);
	init_label(mercury__frameopt__generate_if_20_0_i29);
	init_label(mercury__frameopt__generate_if_20_0_i32);
	init_label(mercury__frameopt__generate_if_20_0_i34);
	init_label(mercury__frameopt__generate_if_20_0_i35);
	init_label(mercury__frameopt__generate_if_20_0_i21);
	init_label(mercury__frameopt__generate_if_20_0_i20);
	init_label(mercury__frameopt__generate_if_20_0_i37);
	init_label(mercury__frameopt__generate_if_20_0_i43);
	init_label(mercury__frameopt__generate_if_20_0_i46);
	init_label(mercury__frameopt__generate_if_20_0_i39);
	init_label(mercury__frameopt__generate_if_20_0_i38);
	init_label(mercury__frameopt__generate_if_20_0_i53);
	init_label(mercury__frameopt__generate_if_20_0_i49);
	init_label(mercury__frameopt__generate_if_20_0_i48);
	init_label(mercury__frameopt__generate_if_20_0_i57);
	init_label(mercury__frameopt__generate_if_20_0_i58);
	init_label(mercury__frameopt__generate_if_20_0_i59);
	init_label(mercury__frameopt__generate_if_20_0_i62);
	init_label(mercury__frameopt__generate_if_20_0_i67);
	init_label(mercury__frameopt__generate_if_20_0_i69);
	init_label(mercury__frameopt__generate_if_20_0_i64);
	init_label(mercury__frameopt__generate_if_20_0_i63);
	init_label(mercury__frameopt__generate_if_20_0_i73);
	init_label(mercury__frameopt__generate_if_20_0_i74);
	init_label(mercury__frameopt__generate_if_20_0_i75);
	init_label(mercury__frameopt__generate_if_20_0_i76);
	init_label(mercury__frameopt__generate_if_20_0_i81);
	init_label(mercury__frameopt__generate_if_20_0_i85);
	init_label(mercury__frameopt__generate_if_20_0_i84);
	init_label(mercury__frameopt__generate_if_20_0_i87);
	init_label(mercury__frameopt__generate_if_20_0_i88);
	init_label(mercury__frameopt__generate_if_20_0_i80);
	init_label(mercury__frameopt__generate_if_20_0_i90);
	init_label(mercury__frameopt__generate_if_20_0_i91);
	init_label(mercury__frameopt__generate_if_20_0_i70);
	init_label(mercury__frameopt__generate_if_20_0_i96);
	init_label(mercury__frameopt__generate_if_20_0_i99);
	init_label(mercury__frameopt__generate_if_20_0_i102);
	init_label(mercury__frameopt__generate_if_20_0_i104);
	init_label(mercury__frameopt__generate_if_20_0_i98);
	init_label(mercury__frameopt__generate_if_20_0_i105);
	init_label(mercury__frameopt__generate_if_20_0_i106);
BEGIN_CODE

/* code for predicate 'frameopt__generate_if'/20 in mode 0 */
Define_static(mercury__frameopt__generate_if_20_0);
	incr_sp_push_msg(32, "frameopt__generate_if");
	detstackvar(32) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	detstackvar(12) = (Integer) r12;
	detstackvar(13) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(16) = (Integer) r15;
	detstackvar(17) = (Integer) r16;
	detstackvar(18) = (Integer) r17;
	tag_incr_hp(detstackvar(20), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) detstackvar(20), ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 9);
	field(mktag(0), (Integer) detstackvar(20), ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__generate_if_20_0_i2,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
	}
Define_label(mercury__frameopt__generate_if_20_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (((Integer) detstackvar(8) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i3);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i3);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i3);
	detstackvar(21) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	detstackvar(15) = (Integer) r1;
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__frameopt__label_without_frame_4_0),
		mercury__frameopt__generate_if_20_0_i8,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i4);
	detstackvar(22) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__generate_if_20_0_i10,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i4);
	detstackvar(23) = (Integer) r2;
	detstackvar(24) = (Integer) r3;
	detstackvar(25) = (Integer) r4;
	detstackvar(26) = (Integer) r5;
	r1 = (Integer) detstackvar(22);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___llds__label_0_0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__frameopt__generate_if_20_0_i14,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i13);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(16);
	r13 = (Integer) detstackvar(17);
	r14 = (Integer) detstackvar(18);
	r15 = (Integer) detstackvar(23);
	r16 = (Integer) detstackvar(24);
	r17 = (Integer) detstackvar(25);
	r1 = (Integer) detstackvar(26);
	r18 = (Integer) detstackvar(20);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i17);
Define_label(mercury__frameopt__generate_if_20_0_i13);
	r1 = (Integer) detstackvar(3);
	r2 = string_const(" (teardown redirect)", 20);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__frameopt__generate_if_20_0_i16,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(16);
	r13 = (Integer) detstackvar(17);
	r14 = (Integer) detstackvar(18);
	r15 = (Integer) detstackvar(23);
	r16 = (Integer) detstackvar(24);
	r17 = (Integer) detstackvar(25);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(26);
	tag_incr_hp(r18, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(1);
	r6 = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(22);
	field(mktag(0), (Integer) r18, ((Integer) 1)) = (Integer) r4;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(0), (Integer) r18, ((Integer) 0)) = (Integer) r5;
	r5 = ((Integer) 1);
	}
Define_label(mercury__frameopt__generate_if_20_0_i17);
	detstackvar(23) = (Integer) r15;
	detstackvar(24) = (Integer) r16;
	detstackvar(25) = (Integer) r17;
	detstackvar(15) = (Integer) r18;
	call_localret(STATIC(mercury__frameopt__doit_17_0),
		mercury__frameopt__generate_if_20_0_i18,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r4 = (Integer) detstackvar(15);
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	detstackvar(19) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(24);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(23);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(25);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__generate_if_20_0_i19,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
	}
Define_label(mercury__frameopt__generate_if_20_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(15);
	r2 = (Integer) detstackvar(19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(32);
	decr_sp_pop_msg(32);
	proceed();
Define_label(mercury__frameopt__generate_if_20_0_i4);
	r1 = (Integer) detstackvar(21);
Define_label(mercury__frameopt__generate_if_20_0_i3);
	if (((Integer) detstackvar(8) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i20);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i20);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i20);
	detstackvar(21) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(13);
	call_localret(STATIC(mercury__frameopt__label_without_frame_4_0),
		mercury__frameopt__generate_if_20_0_i27,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i21);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__frameopt__generate_if_20_0_i29,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i29);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i21);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__generate_if_20_0_i32,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i32);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i21);
	r1 = (Integer) detstackvar(8);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(9);
	r4 = ((Integer) 0);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__generate_if_20_0_i34,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i34);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 0);
	r6 = ((Integer) 0);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(14);
	r12 = (Integer) detstackvar(16);
	r13 = (Integer) detstackvar(17);
	r14 = (Integer) detstackvar(18);
	call_localret(STATIC(mercury__frameopt__doit_17_0),
		mercury__frameopt__generate_if_20_0_i35,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i35);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r4 = (Integer) detstackvar(15);
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	detstackvar(19) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(20);
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__generate_if_20_0_i19,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
	}
Define_label(mercury__frameopt__generate_if_20_0_i21);
	r1 = (Integer) detstackvar(21);
Define_label(mercury__frameopt__generate_if_20_0_i20);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	call_localret(STATIC(mercury__frameopt__setup_use_5_0),
		mercury__frameopt__generate_if_20_0_i37,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i37);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (((Integer) detstackvar(17) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i38);
	detstackvar(21) = (Integer) r1;
	detstackvar(22) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__frameopt__prev_instrs_fill_slot_2_0),
		mercury__frameopt__generate_if_20_0_i43,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i43);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i39);
	r1 = (Integer) detstackvar(21);
	r2 = (Integer) detstackvar(22);
	if ((tag((Integer) detstackvar(2)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i38);
	detstackvar(21) = (Integer) r1;
	detstackvar(22) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0));
	r4 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__frameopt__delay_slot_6_0),
		mercury__frameopt__generate_if_20_0_i46,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i46);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i39);
	r4 = (Integer) r3;
	r21 = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(21);
	r3 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(4);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(13);
	r15 = (Integer) detstackvar(14);
	r16 = (Integer) detstackvar(16);
	r17 = (Integer) detstackvar(17);
	r18 = (Integer) detstackvar(18);
	r19 = (Integer) detstackvar(20);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = (Integer) r21;
	r21 = (Integer) r4;
	r4 = (Integer) detstackvar(22);
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i57);
Define_label(mercury__frameopt__generate_if_20_0_i39);
	r1 = (Integer) detstackvar(21);
	r2 = (Integer) detstackvar(22);
Define_label(mercury__frameopt__generate_if_20_0_i38);
	if (((Integer) detstackvar(17) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i48);
	detstackvar(21) = (Integer) r1;
	detstackvar(22) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__frameopt__prev_instrs_fill_slot_2_0),
		mercury__frameopt__generate_if_20_0_i53,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i53);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i49);
	r1 = (Integer) detstackvar(21);
	r2 = (Integer) detstackvar(22);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i48);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(13);
	r15 = (Integer) detstackvar(14);
	r16 = (Integer) detstackvar(16);
	r17 = (Integer) detstackvar(17);
	r18 = (Integer) detstackvar(18);
	r19 = (Integer) detstackvar(20);
	r20 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = ((Integer) 0);
	r21 = (Integer) r10;
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i57);
Define_label(mercury__frameopt__generate_if_20_0_i49);
	r1 = (Integer) detstackvar(21);
	r2 = (Integer) detstackvar(22);
Define_label(mercury__frameopt__generate_if_20_0_i48);
	r4 = (Integer) r2;
	r21 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) r21;
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(13);
	r15 = (Integer) detstackvar(14);
	r16 = (Integer) detstackvar(16);
	r17 = (Integer) detstackvar(17);
	r18 = (Integer) detstackvar(18);
	r19 = (Integer) detstackvar(20);
	r20 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__frameopt__generate_if_20_0_i57);
	detstackvar(1) = (Integer) r7;
	detstackvar(2) = (Integer) r8;
	detstackvar(3) = (Integer) r9;
	detstackvar(4) = (Integer) r10;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(13) = (Integer) r14;
	detstackvar(14) = (Integer) r15;
	detstackvar(16) = (Integer) r16;
	detstackvar(17) = (Integer) r17;
	detstackvar(18) = (Integer) r18;
	detstackvar(20) = (Integer) r19;
	detstackvar(21) = (Integer) r2;
	detstackvar(15) = (Integer) r20;
	detstackvar(23) = (Integer) r4;
	detstackvar(19) = (Integer) r21;
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__generate_if_20_0_i58,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i58);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i59);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(13);
	r10 = (Integer) detstackvar(14);
	r11 = (Integer) detstackvar(16);
	r12 = (Integer) detstackvar(17);
	r13 = (Integer) detstackvar(18);
	r14 = (Integer) detstackvar(20);
	r15 = (Integer) detstackvar(21);
	r16 = (Integer) detstackvar(23);
	r17 = (Integer) detstackvar(15);
	r18 = (Integer) detstackvar(19);
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i62);
Define_label(mercury__frameopt__generate_if_20_0_i59);
	r17 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(13);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(14);
	r11 = (Integer) detstackvar(16);
	r12 = (Integer) detstackvar(17);
	r13 = (Integer) detstackvar(18);
	r14 = (Integer) detstackvar(20);
	r15 = (Integer) detstackvar(21);
	r16 = (Integer) detstackvar(23);
	r18 = (Integer) detstackvar(4);
Define_label(mercury__frameopt__generate_if_20_0_i62);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i63);
	if (((Integer) r15 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i63);
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(10) = (Integer) r7;
	detstackvar(11) = (Integer) r8;
	detstackvar(12) = (Integer) r9;
	detstackvar(13) = (Integer) r3;
	detstackvar(14) = (Integer) r10;
	detstackvar(16) = (Integer) r11;
	detstackvar(17) = (Integer) r12;
	detstackvar(18) = (Integer) r13;
	detstackvar(20) = (Integer) r14;
	detstackvar(21) = (Integer) r15;
	detstackvar(23) = (Integer) r16;
	detstackvar(24) = (Integer) r17;
	detstackvar(25) = (Integer) r18;
	{
	Declare_entry(mercury__bimap__search_3_0);
	call_localret(ENTRY(mercury__bimap__search_3_0),
		mercury__frameopt__generate_if_20_0_i67,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i67);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i64);
	detstackvar(15) = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(" (teardown redirect)", 20);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__frameopt__generate_if_20_0_i69,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i69);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r15 = (Integer) r1;
	r1 = (Integer) detstackvar(25);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(16);
	r9 = (Integer) detstackvar(17);
	r10 = (Integer) detstackvar(21);
	r11 = (Integer) detstackvar(23);
	r12 = (Integer) detstackvar(24);
	r13 = (Integer) detstackvar(18);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(r17, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r16, ((Integer) 1)) = (Integer) r15;
	r15 = (Integer) detstackvar(14);
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i96);
	}
Define_label(mercury__frameopt__generate_if_20_0_i64);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(13);
	r10 = (Integer) detstackvar(14);
	r11 = (Integer) detstackvar(16);
	r12 = (Integer) detstackvar(17);
	r13 = (Integer) detstackvar(18);
	r14 = (Integer) detstackvar(20);
	r15 = (Integer) detstackvar(21);
	r16 = (Integer) detstackvar(23);
	r17 = (Integer) detstackvar(24);
	r18 = (Integer) detstackvar(25);
Define_label(mercury__frameopt__generate_if_20_0_i63);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i70);
	detstackvar(13) = (Integer) r3;
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(31) = (Integer) r2;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) r7;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(10) = (Integer) r7;
	detstackvar(11) = (Integer) r8;
	detstackvar(12) = (Integer) r9;
	detstackvar(14) = (Integer) r10;
	detstackvar(16) = (Integer) r11;
	detstackvar(17) = (Integer) r12;
	detstackvar(18) = (Integer) r13;
	detstackvar(20) = (Integer) r14;
	detstackvar(21) = (Integer) r15;
	detstackvar(23) = (Integer) r16;
	detstackvar(24) = (Integer) r17;
	detstackvar(25) = (Integer) r18;
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__generate_if_20_0_i73,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i73);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(31);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__generate_if_20_0_i74,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i74);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(21);
	r2 = (Integer) detstackvar(15);
	r3 = (Integer) detstackvar(23);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__generate_if_20_0_i75,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i75);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i76);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(16);
	r9 = (Integer) detstackvar(17);
	r10 = (Integer) detstackvar(21);
	r11 = (Integer) detstackvar(23);
	r12 = (Integer) detstackvar(24);
	r1 = (Integer) detstackvar(25);
	r13 = (Integer) detstackvar(18);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(20);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r15 = (Integer) detstackvar(14);
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i96);
Define_label(mercury__frameopt__generate_if_20_0_i76);
	detstackvar(29) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_2);
	r3 = (Integer) detstackvar(14);
	r4 = (Integer) detstackvar(31);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__generate_if_20_0_i81,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i81);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i80);
	r3 = (Integer) r2;
	detstackvar(30) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1);
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r4 = (Integer) detstackvar(29);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__generate_if_20_0_i85,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i85);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i84);
	r15 = (Integer) r2;
	r1 = (Integer) detstackvar(25);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(16);
	r9 = (Integer) detstackvar(17);
	r10 = (Integer) detstackvar(21);
	r11 = (Integer) detstackvar(23);
	r12 = (Integer) detstackvar(24);
	r13 = (Integer) detstackvar(18);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(r17, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r15;
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("jump to setup", 13);
	r15 = (Integer) detstackvar(14);
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i96);
	}
Define_label(mercury__frameopt__generate_if_20_0_i84);
	detstackvar(26) = ((Integer) detstackvar(18) + ((Integer) 1));
	tag_incr_hp(detstackvar(15), mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) detstackvar(15), ((Integer) 0)) = (Integer) detstackvar(16);
	field(mktag(0), (Integer) detstackvar(15), ((Integer) 1)) = (Integer) detstackvar(18);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1);
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(30);
	r4 = (Integer) detstackvar(29);
	r5 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__generate_if_20_0_i87,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i87);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_2);
	r3 = (Integer) detstackvar(14);
	r4 = (Integer) detstackvar(31);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__frameopt__generate_if_20_0_i88,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i88);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r15 = (Integer) r1;
	r1 = (Integer) detstackvar(25);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(16);
	r9 = (Integer) detstackvar(17);
	r10 = (Integer) detstackvar(21);
	r11 = (Integer) detstackvar(23);
	r12 = (Integer) detstackvar(24);
	r13 = (Integer) detstackvar(26);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	tag_incr_hp(r16, mktag(0), ((Integer) 2));
	tag_incr_hp(r17, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r17, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r17, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r16, ((Integer) 1)) = string_const("jump to setup", 13);
	field(mktag(3), (Integer) r17, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r16;
	field(mktag(0), (Integer) r16, ((Integer) 0)) = (Integer) r17;
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i96);
	}
Define_label(mercury__frameopt__generate_if_20_0_i80);
	detstackvar(26) = ((Integer) detstackvar(18) + ((Integer) 1));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	detstackvar(15) = (Integer) r3;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1);
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(18);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__frameopt__generate_if_20_0_i90,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i90);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1);
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r4 = (Integer) detstackvar(29);
	r5 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__generate_if_20_0_i91,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i91);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_2);
	r3 = (Integer) detstackvar(14);
	r4 = (Integer) detstackvar(31);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__frameopt__generate_if_20_0_i88,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i70);
	r2 = (Integer) r5;
	r4 = (Integer) r7;
	r24 = (Integer) r10;
	r5 = (Integer) r8;
	r7 = (Integer) r3;
	r3 = (Integer) r6;
	r6 = (Integer) r9;
	r8 = (Integer) r11;
	r9 = (Integer) r12;
	r1 = (Integer) r18;
	r10 = (Integer) r15;
	r11 = (Integer) r16;
	r12 = (Integer) r17;
	r28 = (Integer) r14;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r28;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r15 = (Integer) r24;
Define_label(mercury__frameopt__generate_if_20_0_i96);
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	detstackvar(10) = (Integer) r4;
	detstackvar(11) = (Integer) r5;
	detstackvar(12) = (Integer) r6;
	detstackvar(13) = (Integer) r7;
	detstackvar(16) = (Integer) r8;
	detstackvar(17) = (Integer) r9;
	detstackvar(21) = (Integer) r10;
	detstackvar(23) = (Integer) r11;
	detstackvar(24) = (Integer) r12;
	detstackvar(25) = (Integer) r1;
	detstackvar(26) = (Integer) r13;
	detstackvar(27) = (Integer) r14;
	detstackvar(28) = (Integer) r15;
	{
	Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__frameopt__generate_if_20_0_i99,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
Define_label(mercury__frameopt__generate_if_20_0_i99);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i98);
	r1 = (Integer) detstackvar(25);
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__frameopt__detstack_teardown_6_0),
		mercury__frameopt__generate_if_20_0_i102,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i102);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__generate_if_20_0_i98);
	detstackvar(15) = ((Integer) 0);
	detstackvar(19) = ((Integer) 0);
	r1 = (Integer) detstackvar(21);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(23);
	r4 = ((Integer) 0);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__generate_if_20_0_i104,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i104);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r17 = (Integer) r1;
	r1 = (Integer) detstackvar(25);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = ((Integer) 0);
	r6 = ((Integer) 0);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r11 = (Integer) detstackvar(28);
	r12 = (Integer) detstackvar(16);
	r13 = (Integer) detstackvar(17);
	r14 = (Integer) detstackvar(26);
	r15 = (Integer) detstackvar(24);
	r16 = (Integer) detstackvar(27);
	GOTO_LABEL(mercury__frameopt__generate_if_20_0_i105);
Define_label(mercury__frameopt__generate_if_20_0_i98);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
	r10 = (Integer) detstackvar(13);
	r12 = (Integer) detstackvar(16);
	r13 = (Integer) detstackvar(17);
	r15 = (Integer) detstackvar(24);
	r1 = (Integer) detstackvar(25);
	r14 = (Integer) detstackvar(26);
	r16 = (Integer) detstackvar(27);
	r11 = (Integer) detstackvar(28);
	r5 = (Integer) detstackvar(21);
	r6 = (Integer) detstackvar(23);
	r17 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__frameopt__generate_if_20_0_i105);
	detstackvar(24) = (Integer) r15;
	detstackvar(27) = (Integer) r16;
	detstackvar(15) = (Integer) r17;
	call_localret(STATIC(mercury__frameopt__doit_17_0),
		mercury__frameopt__generate_if_20_0_i106,
		STATIC(mercury__frameopt__generate_if_20_0));
Define_label(mercury__frameopt__generate_if_20_0_i106);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_if_20_0));
	r4 = (Integer) detstackvar(15);
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	detstackvar(19) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(24);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(27);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__generate_if_20_0_i19,
		STATIC(mercury__frameopt__generate_if_20_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__frameopt_module18)
	init_entry(mercury__frameopt__label_without_frame_4_0);
	init_label(mercury__frameopt__label_without_frame_4_0_i4);
	init_label(mercury__frameopt__label_without_frame_4_0_i6);
	init_label(mercury__frameopt__label_without_frame_4_0_i3);
	init_label(mercury__frameopt__label_without_frame_4_0_i1000);
BEGIN_CODE

/* code for predicate 'frameopt__label_without_frame'/4 in mode 0 */
Define_static(mercury__frameopt__label_without_frame_4_0);
	incr_sp_push_msg(3, "frameopt__label_without_frame");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__label_without_frame_4_0_i4,
		STATIC(mercury__frameopt__label_without_frame_4_0));
	}
Define_label(mercury__frameopt__label_without_frame_4_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__label_without_frame_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__label_without_frame_4_0_i3);
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__bimap__search_3_0);
	call_localret(ENTRY(mercury__bimap__search_3_0),
		mercury__frameopt__label_without_frame_4_0_i6,
		STATIC(mercury__frameopt__label_without_frame_4_0));
	}
Define_label(mercury__frameopt__label_without_frame_4_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__label_without_frame_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__label_without_frame_4_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__frameopt__label_without_frame_4_0_i3);
	r2 = (Integer) detstackvar(1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__frameopt__label_without_frame_4_0_i1000);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module19)
	init_entry(mercury__frameopt__generate_setup_7_0);
	init_label(mercury__frameopt__generate_setup_7_0_i6);
	init_label(mercury__frameopt__generate_setup_7_0_i1022);
	init_label(mercury__frameopt__generate_setup_7_0_i2);
	init_label(mercury__frameopt__generate_setup_7_0_i12);
	init_label(mercury__frameopt__generate_setup_7_0_i8);
	init_label(mercury__frameopt__generate_setup_7_0_i17);
	init_label(mercury__frameopt__generate_setup_7_0_i1019);
	init_label(mercury__frameopt__generate_setup_7_0_i14);
	init_label(mercury__frameopt__generate_setup_7_0_i25);
	init_label(mercury__frameopt__generate_setup_7_0_i1020);
BEGIN_CODE

/* code for predicate 'frameopt__generate_setup'/7 in mode 0 */
Define_static(mercury__frameopt__generate_setup_7_0);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i1022);
	incr_sp_push_msg(7, "frameopt__generate_setup");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = string_const("requirement for frame without succip in generate_setup", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__generate_setup_7_0_i6,
		STATIC(mercury__frameopt__generate_setup_7_0));
	}
Define_label(mercury__frameopt__generate_setup_7_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_setup_7_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i2);
Define_label(mercury__frameopt__generate_setup_7_0_i1022);
	incr_sp_push_msg(7, "frameopt__generate_setup");
	detstackvar(7) = (Integer) succip;
Define_label(mercury__frameopt__generate_setup_7_0_i2);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i8);
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i8);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = string_const("existing frame without succip in generate_setup", 47);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__generate_setup_7_0_i12,
		STATIC(mercury__frameopt__generate_setup_7_0));
	}
Define_label(mercury__frameopt__generate_setup_7_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_setup_7_0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
Define_label(mercury__frameopt__generate_setup_7_0_i8);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i14);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i17);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__frameopt__generate_setup_7_0_i17);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i1019);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 15);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r6;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = string_const("late setup after succip", 23);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__frameopt__generate_setup_7_0_i1019);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 15);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r6;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = string_const("late setup", 10);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	tag_incr_hp(r4, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_8);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r5;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = string_const("late save", 9);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__frameopt__generate_setup_7_0_i14);
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i25);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__generate_setup_7_0_i1020);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__frameopt__generate_setup_7_0_i25);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__frameopt__generate_setup_7_0_i1020);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_frameopt__common_12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module20)
	init_entry(mercury__frameopt__generate_labels_13_0);
	init_label(mercury__frameopt__generate_labels_13_0_i4);
	init_label(mercury__frameopt__generate_labels_13_0_i8);
	init_label(mercury__frameopt__generate_labels_13_0_i6);
	init_label(mercury__frameopt__generate_labels_13_0_i5);
	init_label(mercury__frameopt__generate_labels_13_0_i10);
	init_label(mercury__frameopt__generate_labels_13_0_i11);
	init_label(mercury__frameopt__generate_labels_13_0_i12);
	init_label(mercury__frameopt__generate_labels_13_0_i13);
	init_label(mercury__frameopt__generate_labels_13_0_i16);
	init_label(mercury__frameopt__generate_labels_13_0_i1019);
BEGIN_CODE

/* code for predicate 'frameopt__generate_labels'/13 in mode 0 */
Define_static(mercury__frameopt__generate_labels_13_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__generate_labels_13_0_i1019);
	incr_sp_push_msg(12, "frameopt__generate_labels");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__frameopt__generate_labels_13_0,
		LABEL(mercury__frameopt__generate_labels_13_0_i4),
		STATIC(mercury__frameopt__generate_labels_13_0));
Define_label(mercury__frameopt__generate_labels_13_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_labels_13_0));
	if (((Integer) detstackvar(1) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__generate_labels_13_0_i5);
	detstackvar(11) = (Integer) r3;
	r3 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r2;
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__bimap__search_3_0);
	call_localret(ENTRY(mercury__bimap__search_3_0),
		mercury__frameopt__generate_labels_13_0_i8,
		STATIC(mercury__frameopt__generate_labels_13_0));
	}
Define_label(mercury__frameopt__generate_labels_13_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_labels_13_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__generate_labels_13_0_i6);
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__frameopt__generate_labels_13_0_i6);
	r2 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(11);
Define_label(mercury__frameopt__generate_labels_13_0_i5);
	detstackvar(7) = (Integer) r2;
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r3;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__generate_labels_13_0_i10,
		STATIC(mercury__frameopt__generate_labels_13_0));
	}
Define_label(mercury__frameopt__generate_labels_13_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_labels_13_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__is_member_3_0);
	call_localret(ENTRY(mercury__set__is_member_3_0),
		mercury__frameopt__generate_labels_13_0_i11,
		STATIC(mercury__frameopt__generate_labels_13_0));
	}
Define_label(mercury__frameopt__generate_labels_13_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_labels_13_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__frameopt__generate_setup_7_0),
		mercury__frameopt__generate_labels_13_0_i12,
		STATIC(mercury__frameopt__generate_labels_13_0));
Define_label(mercury__frameopt__generate_labels_13_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_labels_13_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__generate_labels_13_0_i13);
	r1 = (Integer) detstackvar(10);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__frameopt__generate_labels_13_0_i13);
	detstackvar(1) = ((Integer) detstackvar(10) + ((Integer) 1));
	r3 = (Integer) r1;
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(8);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	detstackvar(2) = (Integer) r4;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r6, ((Integer) 1)) = string_const("setup bridging label", 20);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	tag_incr_hp(r9, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r9, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r8, ((Integer) 1)) = string_const("cross the bridge", 16);
	field(mktag(3), (Integer) r9, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__frameopt__generate_labels_13_0_i16,
		STATIC(mercury__frameopt__generate_labels_13_0));
	}
	}
Define_label(mercury__frameopt__generate_labels_13_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__generate_labels_13_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__frameopt__generate_labels_13_0_i1019);
	r1 = (Integer) r10;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module21)
	init_entry(mercury__frameopt__detstack_setup_2_3_0);
	init_label(mercury__frameopt__detstack_setup_2_3_0_i1018);
	init_label(mercury__frameopt__detstack_setup_2_3_0_i12);
	init_label(mercury__frameopt__detstack_setup_2_3_0_i9);
	init_label(mercury__frameopt__detstack_setup_2_3_0_i15);
	init_label(mercury__frameopt__detstack_setup_2_3_0_i1015);
	init_label(mercury__frameopt__detstack_setup_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'frameopt__detstack_setup_2'/3 in mode 0 */
Define_static(mercury__frameopt__detstack_setup_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1015);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	if ((tag((Integer) field(mktag(3), (Integer) r5, ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r5, ((Integer) 1)), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	if (((Integer) r2 != (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) r5, ((Integer) 1)), ((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	if ((tag((Integer) field(mktag(3), (Integer) r5, ((Integer) 2))) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	if (((Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r5, ((Integer) 2)), ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1018);
	r2 = (Integer) r3;
	r1 = TRUE;
	proceed();
Define_label(mercury__frameopt__detstack_setup_2_3_0_i1018);
	incr_sp_push_msg(2, "frameopt__detstack_setup_2");
	detstackvar(2) = (Integer) succip;
	r1 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i9);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i9);
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__frameopt__detstack_setup_2_3_0,
		LABEL(mercury__frameopt__detstack_setup_2_3_0_i12),
		STATIC(mercury__frameopt__detstack_setup_2_3_0));
Define_label(mercury__frameopt__detstack_setup_2_3_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_setup_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__frameopt__detstack_setup_2_3_0_i9);
	r1 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1);
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__frameopt__detstack_setup_2_3_0,
		LABEL(mercury__frameopt__detstack_setup_2_3_0_i15),
		STATIC(mercury__frameopt__detstack_setup_2_3_0));
Define_label(mercury__frameopt__detstack_setup_2_3_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_setup_2_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_3_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__frameopt__detstack_setup_2_3_0_i1015);
	r1 = FALSE;
	proceed();
Define_label(mercury__frameopt__detstack_setup_2_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module22)
	init_entry(mercury__frameopt__detstack_teardown_6_0);
	init_label(mercury__frameopt__detstack_teardown_6_0_i2);
	init_label(mercury__frameopt__detstack_teardown_6_0_i1000);
BEGIN_CODE

/* code for predicate 'frameopt__detstack_teardown'/6 in mode 0 */
Define_static(mercury__frameopt__detstack_teardown_6_0);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(1, "frameopt__detstack_teardown");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__frameopt__detstack_teardown_2_10_0),
		mercury__frameopt__detstack_teardown_6_0_i2,
		STATIC(mercury__frameopt__detstack_teardown_6_0));
Define_label(mercury__frameopt__detstack_teardown_6_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_6_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_6_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__frameopt__detstack_teardown_6_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module23)
	init_entry(mercury__frameopt__detstack_teardown_2_10_0);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i2);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i7);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i15);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i8);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i17);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i18);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i19);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i23);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i26);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i27);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i28);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i6);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i1);
	init_label(mercury__frameopt__detstack_teardown_2_10_0_i1000);
BEGIN_CODE

/* code for predicate 'frameopt__detstack_teardown_2'/10 in mode 0 */
Define_static(mercury__frameopt__detstack_teardown_2_10_0);
	incr_sp_push_msg(9, "frameopt__detstack_teardown_2");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__opt_util__skip_comments_2_0);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__frameopt__detstack_teardown_2_10_0_i2,
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
	}
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r3 = tag((Integer) r2);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i6);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)),
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i7) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i23) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i28) AND
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1));
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i7);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r4 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i8);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i8);
	r7 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r7) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i8);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i8);
	if (((Integer) detstackvar(1) != (Integer) field(mktag(3), (Integer) r7, ((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i8);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	if (((Integer) detstackvar(3) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r1 = (Integer) r5;
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	localcall(mercury__frameopt__detstack_teardown_2_10_0,
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i15),
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	if ((Integer) r1)
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i8);
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__detstack_teardown_2_10_0_i17,
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
	}
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i17);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__detstack_teardown_2_10_0_i18,
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
	}
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	if ((((Integer) 1) != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__detstack_teardown_2_10_0_i19,
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
	}
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	localcall(mercury__frameopt__detstack_teardown_2_10_0,
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i15),
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i23);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(3);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	if (((Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) tempr1;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__detstack_teardown_2_10_0_i26,
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
	}
	}
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	detstackvar(1) = (Integer) detstackvar(4);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__detstack_teardown_2_10_0_i27,
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
	}
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_10_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) r1;
	r5 = (Integer) detstackvar(7);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i28);
	if (((Integer) detstackvar(1) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	if (((Integer) detstackvar(3) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r2 = (Integer) detstackvar(1);
	r5 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	localcall(mercury__frameopt__detstack_teardown_2_10_0,
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i15),
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	if (((Integer) detstackvar(5) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r7, ((Integer) 0));
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	localcall(mercury__frameopt__detstack_teardown_2_10_0,
		LABEL(mercury__frameopt__detstack_teardown_2_10_0_i15),
		STATIC(mercury__frameopt__detstack_teardown_2_10_0));
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__frameopt__detstack_teardown_2_10_0_i1000);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module24)
	init_entry(mercury__frameopt__insert_late_setups_4_0);
	init_label(mercury__frameopt__insert_late_setups_4_0_i4);
	init_label(mercury__frameopt__insert_late_setups_4_0_i8);
	init_label(mercury__frameopt__insert_late_setups_4_0_i10);
	init_label(mercury__frameopt__insert_late_setups_4_0_i12);
	init_label(mercury__frameopt__insert_late_setups_4_0_i11);
	init_label(mercury__frameopt__insert_late_setups_4_0_i13);
	init_label(mercury__frameopt__insert_late_setups_4_0_i14);
	init_label(mercury__frameopt__insert_late_setups_4_0_i6);
	init_label(mercury__frameopt__insert_late_setups_4_0_i5);
	init_label(mercury__frameopt__insert_late_setups_4_0_i1015);
BEGIN_CODE

/* code for predicate 'frameopt__insert_late_setups'/4 in mode 0 */
Define_static(mercury__frameopt__insert_late_setups_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_4_0_i1015);
	incr_sp_push_msg(5, "frameopt__insert_late_setups");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) tempr1;
	detstackvar(4) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__frameopt__insert_late_setups_4_0,
		LABEL(mercury__frameopt__insert_late_setups_4_0_i4),
		STATIC(mercury__frameopt__insert_late_setups_4_0));
	}
Define_label(mercury__frameopt__insert_late_setups_4_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__insert_late_setups_4_0));
	if ((tag((Integer) detstackvar(4)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_4_0_i5);
	if (((Integer) field(mktag(3), (Integer) detstackvar(4), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_4_0_i5);
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r4 = (Integer) field(mktag(3), (Integer) detstackvar(4), ((Integer) 1));
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__insert_late_setups_4_0_i8,
		STATIC(mercury__frameopt__insert_late_setups_4_0));
	}
Define_label(mercury__frameopt__insert_late_setups_4_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__insert_late_setups_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_4_0_i6);
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__frameopt__insert_late_setups_4_0_i10,
		STATIC(mercury__frameopt__insert_late_setups_4_0));
	}
Define_label(mercury__frameopt__insert_late_setups_4_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__insert_late_setups_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_4_0_i12);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1);
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	GOTO_LABEL(mercury__frameopt__insert_late_setups_4_0_i11);
Define_label(mercury__frameopt__insert_late_setups_4_0_i12);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = string_const("jump around setup", 17);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_1);
	r2 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
Define_label(mercury__frameopt__insert_late_setups_4_0_i11);
	detstackvar(3) = (Integer) r4;
	detstackvar(1) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__frameopt__insert_late_setups_4_0_i13,
		STATIC(mercury__frameopt__insert_late_setups_4_0));
	}
Define_label(mercury__frameopt__insert_late_setups_4_0_i13);
	update_prof_current_proc(LABEL(mercury__frameopt__insert_late_setups_4_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__frameopt__insert_late_setups_list_3_0),
		mercury__frameopt__insert_late_setups_4_0_i14,
		STATIC(mercury__frameopt__insert_late_setups_4_0));
Define_label(mercury__frameopt__insert_late_setups_4_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__insert_late_setups_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__list__condense_2_0);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__frameopt__insert_late_setups_4_0));
	}
Define_label(mercury__frameopt__insert_late_setups_4_0_i6);
	r1 = (Integer) detstackvar(1);
Define_label(mercury__frameopt__insert_late_setups_4_0_i5);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__frameopt__insert_late_setups_4_0_i1015);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__frameopt_module25)
	init_entry(mercury__frameopt__insert_late_setups_list_3_0);
	init_label(mercury__frameopt__insert_late_setups_list_3_0_i4);
	init_label(mercury__frameopt__insert_late_setups_list_3_0_i1026);
	init_label(mercury__frameopt__insert_late_setups_list_3_0_i1018);
BEGIN_CODE

/* code for predicate 'frameopt__insert_late_setups_list'/3 in mode 0 */
Define_static(mercury__frameopt__insert_late_setups_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_list_3_0_i1018);
	incr_sp_push_msg(4, "frameopt__insert_late_setups_list");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__frameopt__insert_late_setups_list_3_0,
		LABEL(mercury__frameopt__insert_late_setups_list_3_0_i4),
		STATIC(mercury__frameopt__insert_late_setups_list_3_0));
Define_label(mercury__frameopt__insert_late_setups_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__insert_late_setups_list_3_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__frameopt__insert_late_setups_list_3_0_i1026);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("label for late setup code", 25);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__list__condense_2_0);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__frameopt__insert_late_setups_list_3_0));
	}
	}
Define_label(mercury__frameopt__insert_late_setups_list_3_0_i1026);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("label for late setup code", 25);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 6);
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = string_const("jump around next setup", 22);
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_frameopt__common_0);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__list__condense_2_0);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__frameopt__insert_late_setups_list_3_0));
	}
	}
Define_label(mercury__frameopt__insert_late_setups_list_3_0_i1018);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__frameopt_bunch_0(void)
{
	mercury__frameopt_module0();
	mercury__frameopt_module1();
	mercury__frameopt_module2();
	mercury__frameopt_module3();
	mercury__frameopt_module4();
	mercury__frameopt_module5();
	mercury__frameopt_module6();
	mercury__frameopt_module7();
	mercury__frameopt_module8();
	mercury__frameopt_module9();
	mercury__frameopt_module10();
	mercury__frameopt_module11();
	mercury__frameopt_module12();
	mercury__frameopt_module13();
	mercury__frameopt_module14();
	mercury__frameopt_module15();
	mercury__frameopt_module16();
	mercury__frameopt_module17();
	mercury__frameopt_module18();
	mercury__frameopt_module19();
	mercury__frameopt_module20();
	mercury__frameopt_module21();
	mercury__frameopt_module22();
	mercury__frameopt_module23();
	mercury__frameopt_module24();
	mercury__frameopt_module25();
}

#endif

void mercury__frameopt__init(void); /* suppress gcc warning */
void mercury__frameopt__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__frameopt_bunch_0();
#endif
}
