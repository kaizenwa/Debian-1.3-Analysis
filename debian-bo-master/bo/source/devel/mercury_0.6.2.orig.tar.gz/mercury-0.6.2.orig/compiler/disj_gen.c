/*
** Automatically generated from `disj_gen.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__disj_gen__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__disj_gen__generate_det_disj_5_0);
Define_extern_entry(mercury__disj_gen__generate_semi_disj_5_0);
Declare_label(mercury__disj_gen__generate_semi_disj_5_0_i1003);
Define_extern_entry(mercury__disj_gen__generate_non_disj_5_0);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i1001);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i6);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i1000);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i7);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i2);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i8);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i9);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i10);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i11);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i12);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i13);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i14);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i15);
Declare_label(mercury__disj_gen__generate_non_disj_5_0_i16);
Declare_static(mercury__disj_gen__generate_pruned_disj_5_0);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i2);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i3);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i4);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i5);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i6);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i7);
Declare_label(mercury__disj_gen__generate_pruned_disj_5_0_i8);
Declare_static(mercury__disj_gen__generate_pruned_disjuncts_11_0);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i4);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i5);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i9);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i10);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i11);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i12);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i16);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i14);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i13);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i18);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i23);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i19);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i24);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i25);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i26);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i27);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i30);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i31);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i32);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i33);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i34);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i35);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i36);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i37);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i38);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i39);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i6);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i40);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i41);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i42);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i43);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i44);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i45);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i46);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i3);
Declare_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i48);
Declare_static(mercury__disj_gen__generate_non_disjuncts_9_0);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i4);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i8);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i9);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i10);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i11);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i12);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i13);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i14);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i15);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i16);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i17);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i18);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i19);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i20);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i21);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i22);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i5);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i23);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i26);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i27);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i28);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i29);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i30);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i31);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i32);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i33);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i34);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i3);
Declare_label(mercury__disj_gen__generate_non_disjuncts_9_0_i36);

BEGIN_MODULE(mercury__disj_gen_module0)
	init_entry(mercury__disj_gen__generate_det_disj_5_0);
BEGIN_CODE

/* code for predicate 'disj_gen__generate_det_disj'/5 in mode 0 */
Define_entry(mercury__disj_gen__generate_det_disj_5_0);
	tailcall(STATIC(mercury__disj_gen__generate_pruned_disj_5_0),
		ENTRY(mercury__disj_gen__generate_det_disj_5_0));
END_MODULE

BEGIN_MODULE(mercury__disj_gen_module1)
	init_entry(mercury__disj_gen__generate_semi_disj_5_0);
	init_label(mercury__disj_gen__generate_semi_disj_5_0_i1003);
BEGIN_CODE

/* code for predicate 'disj_gen__generate_semi_disj'/5 in mode 0 */
Define_entry(mercury__disj_gen__generate_semi_disj_5_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_semi_disj_5_0_i1003);
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__generate_failure_3_0);
	tailcall(ENTRY(mercury__code_info__generate_failure_3_0),
		ENTRY(mercury__disj_gen__generate_semi_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_semi_disj_5_0_i1003);
	tailcall(STATIC(mercury__disj_gen__generate_pruned_disj_5_0),
		ENTRY(mercury__disj_gen__generate_semi_disj_5_0));
END_MODULE

BEGIN_MODULE(mercury__disj_gen_module2)
	init_entry(mercury__disj_gen__generate_non_disj_5_0);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i1001);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i6);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i1000);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i7);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i2);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i8);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i9);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i10);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i11);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i12);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i13);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i14);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i15);
	init_label(mercury__disj_gen__generate_non_disj_5_0_i16);
BEGIN_CODE

/* code for predicate 'disj_gen__generate_non_disj'/5 in mode 0 */
Define_entry(mercury__disj_gen__generate_non_disj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_non_disj_5_0_i1000);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r4 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_non_disj_5_0_i1001);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r3;
	r3 = (Integer) tempr1;
	incr_sp_push_msg(7, "disj_gen__generate_non_disj");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__disj_gen__generate_non_disj_5_0_i2);
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i1001);
	incr_sp_push_msg(7, "disj_gen__generate_non_disj");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = string_const("singleton disjunction", 21);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__disj_gen__generate_non_disj_5_0_i6,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i6);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__disj_gen__generate_non_disj_5_0_i2);
Define_label(mercury__disj_gen__generate_non_disj_5_0_i1000);
	incr_sp_push_msg(7, "disj_gen__generate_non_disj");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = string_const("empty disjunction shouldn't be non-det", 38);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__disj_gen__generate_non_disj_5_0_i7,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i7);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
Define_label(mercury__disj_gen__generate_non_disj_5_0_i2);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__disj_gen__generate_non_disj_5_0_i8,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i8);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r2 = ((Integer) 53);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__disj_gen__generate_non_disj_5_0_i9,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i9);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_ticket_4_0),
		mercury__disj_gen__generate_non_disj_5_0_i10,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i10);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) r3;
	r2 = ((Integer) 70);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__disj_gen__generate_non_disj_5_0_i11,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i11);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_hp_4_0),
		mercury__disj_gen__generate_non_disj_5_0_i12,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i12);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__disj_gen__generate_non_disj_5_0_i13,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i13);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r3 = (Integer) r1;
	r7 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__disj_gen__generate_non_disjuncts_9_0),
		mercury__disj_gen__generate_non_disj_5_0_i14,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
Define_label(mercury__disj_gen__generate_non_disj_5_0_i14);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__unset_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__unset_failure_cont_3_0),
		mercury__disj_gen__generate_non_disj_5_0_i15,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i15);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__remake_with_store_map_3_0);
	call_localret(ENTRY(mercury__code_info__remake_with_store_map_3_0),
		mercury__disj_gen__generate_non_disj_5_0_i16,
		ENTRY(mercury__disj_gen__generate_non_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_non_disj_5_0_i16);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disj_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__disj_gen_module3)
	init_entry(mercury__disj_gen__generate_pruned_disj_5_0);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i2);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i3);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i4);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i5);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i6);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i7);
	init_label(mercury__disj_gen__generate_pruned_disj_5_0_i8);
BEGIN_CODE

/* code for predicate 'disj_gen__generate_pruned_disj'/5 in mode 0 */
Define_static(mercury__disj_gen__generate_pruned_disj_5_0);
	incr_sp_push_msg(6, "disj_gen__generate_pruned_disj");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i2,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i2);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r2 = ((Integer) 69);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i3,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i3);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 53);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i4,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__maybe_save_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_save_ticket_4_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i5,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_label_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i6,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i6);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	r3 = (Integer) r1;
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	r5 = ((Integer) 1);
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(3);
	r8 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i7,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i7);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__code_info__remake_with_store_map_3_0);
	call_localret(ENTRY(mercury__code_info__remake_with_store_map_3_0),
		mercury__disj_gen__generate_pruned_disj_5_0_i8,
		STATIC(mercury__disj_gen__generate_pruned_disj_5_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disj_5_0_i8);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disj_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__disj_gen_module4)
	init_entry(mercury__disj_gen__generate_pruned_disjuncts_11_0);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i4);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i5);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i9);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i10);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i11);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i12);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i16);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i14);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i13);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i18);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i23);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i19);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i24);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i25);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i26);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i27);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i30);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i31);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i32);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i33);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i34);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i35);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i36);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i37);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i38);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i39);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i6);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i40);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i41);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i42);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i43);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i44);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i45);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i46);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i3);
	init_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i48);
BEGIN_CODE

/* code for predicate 'disj_gen__generate_pruned_disjuncts'/11 in mode 0 */
Define_static(mercury__disj_gen__generate_pruned_disjuncts_11_0);
	incr_sp_push_msg(20, "disj_gen__generate_pruned_disjuncts");
	detstackvar(20) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(9) = (Integer) tempr1;
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(12) = (Integer) r1;
	detstackvar(11) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i4,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i4);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i5,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i5);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i6);
	r2 = (Integer) detstackvar(8);
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__push_resume_point_vars_3_0);
	call_localret(ENTRY(mercury__code_info__push_resume_point_vars_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i9,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i9);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__make_known_failure_cont_8_0);
	call_localret(ENTRY(mercury__code_info__make_known_failure_cont_8_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i10,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i10);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	detstackvar(9) = (Integer) r3;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_resume_point_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i11,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i11);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r3;
	r2 = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__code_info__maybe_get_old_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_get_old_hp_4_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i12,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i12);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	if (((Integer) detstackvar(6) != ((Integer) 0)))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i13);
	detstackvar(9) = (Integer) r1;
	detstackvar(19) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_util__goal_may_allocate_heap_1_0);
	call_localret(ENTRY(mercury__code_util__goal_may_allocate_heap_1_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i16,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i16);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i14);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(5);
	r12 = (Integer) detstackvar(9);
	r13 = ((Integer) 0);
	r1 = (Integer) detstackvar(19);
	GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i18);
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i14);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(19);
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i13);
	r12 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(5);
	r13 = ((Integer) 1);
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i18);
	if (((Integer) r13 != ((Integer) 0)))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i19);
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i19);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(10) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	detstackvar(3) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(5) = (Integer) r11;
	detstackvar(9) = (Integer) r12;
	detstackvar(11) = (Integer) r13;
	{
	Declare_entry(mercury__code_info__save_hp_3_0);
	call_localret(ENTRY(mercury__code_info__save_hp_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i23,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i23);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r13 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(5);
	r11 = (Integer) detstackvar(9);
	r12 = (Integer) detstackvar(11);
	r14 = ((Integer) 0);
	GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i24);
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i19);
	r14 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) r6;
	r6 = (Integer) r7;
	r7 = (Integer) r8;
	r8 = (Integer) r9;
	r9 = (Integer) r10;
	r10 = (Integer) r11;
	r11 = (Integer) r12;
	r12 = (Integer) r13;
	r13 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i24);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(7) = (Integer) r1;
	detstackvar(10) = (Integer) r6;
	detstackvar(13) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(5) = (Integer) r10;
	detstackvar(9) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	{
	Declare_entry(mercury__code_info__maybe_restore_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_ticket_4_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i25,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i25);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i26,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i26);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	if (((Integer) detstackvar(13) != ((Integer) 1)))
		GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i27);
	r3 = (Integer) r2;
	r16 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(9);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(14);
	r15 = (Integer) detstackvar(15);
	GOTO_LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i31);
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i27);
	detstackvar(16) = (Integer) r1;
	detstackvar(17) = (Integer) r2;
	r1 = string_const("pruned disj non-last goal is not semidet", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i30,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i30);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(3);
	r10 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(5);
	r11 = (Integer) detstackvar(9);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r14 = (Integer) detstackvar(14);
	r15 = (Integer) detstackvar(15);
	r16 = (Integer) detstackvar(16);
	r3 = (Integer) detstackvar(17);
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i31);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(13) = (Integer) r1;
	detstackvar(3) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(14) = (Integer) r14;
	detstackvar(15) = (Integer) r15;
	detstackvar(16) = (Integer) r16;
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i32,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i32);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r3 = (Integer) r2;
	detstackvar(17) = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i33,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i33);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(18) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pickup_zombies_3_0);
	call_localret(ENTRY(mercury__code_info__pickup_zombies_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i34,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i34);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i35,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i35);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r2 = (Integer) detstackvar(16);
	tag_incr_hp(detstackvar(16), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	tempr2 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr2;
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) detstackvar(16), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("skip to end of pruned disj", 26);
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i36,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i36);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	{
	Declare_entry(mercury__code_info__pop_resume_point_vars_2_0);
	call_localret(ENTRY(mercury__code_info__pop_resume_point_vars_2_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i37,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i37);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	{
	Declare_entry(mercury__code_info__restore_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__restore_failure_cont_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i38,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i38);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r6 = (Integer) detstackvar(11);
	r9 = (Integer) r2;
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(14);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	localcall(mercury__disj_gen__generate_pruned_disjuncts_11_0,
		LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0_i39),
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i39);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(15);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(17);
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(18);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(16);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i6);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__code_info__maybe_get_old_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_get_old_hp_4_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i40,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i40);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__maybe_pop_stack_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_pop_stack_4_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i41,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i41);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__code_info__maybe_restore_ticket_and_pop_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_ticket_and_pop_4_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i42,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i42);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r3 = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i43,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i43);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i44,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i44);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pickup_zombies_3_0);
	call_localret(ENTRY(mercury__code_info__pickup_zombies_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i45,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i45);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i46,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i46);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("End of pruned disj", 18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i3);
	detstackvar(1) = (Integer) r9;
	r1 = string_const("Empty pruned disjunction!", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__disj_gen__generate_pruned_disjuncts_11_0_i48,
		STATIC(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	}
Define_label(mercury__disj_gen__generate_pruned_disjuncts_11_0_i48);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_pruned_disjuncts_11_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(20);
	decr_sp_pop_msg(20);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__disj_gen_module5)
	init_entry(mercury__disj_gen__generate_non_disjuncts_9_0);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i4);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i8);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i9);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i10);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i11);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i12);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i13);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i14);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i15);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i16);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i17);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i18);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i19);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i20);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i21);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i22);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i5);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i23);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i26);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i27);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i28);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i29);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i30);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i31);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i32);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i33);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i34);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i3);
	init_label(mercury__disj_gen__generate_non_disjuncts_9_0_i36);
BEGIN_CODE

/* code for predicate 'disj_gen__generate_non_disjuncts'/9 in mode 0 */
Define_static(mercury__disj_gen__generate_non_disjuncts_9_0);
	incr_sp_push_msg(14, "disj_gen__generate_non_disjuncts");
	detstackvar(14) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_non_disjuncts_9_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) tempr1;
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(10) = (Integer) r1;
	detstackvar(9) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i4,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i4);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_non_disjuncts_9_0_i5);
	r2 = (Integer) detstackvar(6);
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__code_info__push_resume_point_vars_3_0);
	call_localret(ENTRY(mercury__code_info__push_resume_point_vars_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i8,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i8);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(7);
	r3 = ((Integer) 0);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__make_known_failure_cont_8_0);
	call_localret(ENTRY(mercury__code_info__make_known_failure_cont_8_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i9,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i9);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_resume_point_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_resume_point_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i10,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i10);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r2 = (Integer) detstackvar(7);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	detstackvar(7) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__code_info__maybe_get_old_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_get_old_hp_4_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i11,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i11);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__maybe_restore_ticket_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_ticket_4_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i12,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i12);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i13,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i13);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r1;
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i14,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i14);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r3 = (Integer) r2;
	detstackvar(11) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i15,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i15);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__flush_resume_vars_to_stack_3_0);
	call_localret(ENTRY(mercury__code_info__flush_resume_vars_to_stack_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i16,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i16);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pickup_zombies_3_0);
	call_localret(ENTRY(mercury__code_info__pickup_zombies_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i17,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i17);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i18,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i18);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r2 = (Integer) detstackvar(7);
	tag_incr_hp(detstackvar(7), mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 6);
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	tempr2 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr2;
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) detstackvar(7), ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = string_const("skip to end of nondet disj", 26);
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i19,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i19);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	{
	Declare_entry(mercury__code_info__pop_resume_point_vars_2_0);
	call_localret(ENTRY(mercury__code_info__pop_resume_point_vars_2_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i20,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i20);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	{
	Declare_entry(mercury__code_info__restore_failure_cont_3_0);
	call_localret(ENTRY(mercury__code_info__restore_failure_cont_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i21,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i21);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r7 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	localcall(mercury__disj_gen__generate_non_disjuncts_9_0,
		LABEL(mercury__disj_gen__generate_non_disjuncts_9_0_i22),
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i22);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(10);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(11);
	tag_incr_hp(r7, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(12);
	tag_incr_hp(r8, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(13);
	tag_incr_hp(r9, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r9, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(2), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(2), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i5);
	if (((Integer) detstackvar(8) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__disj_gen__generate_non_disjuncts_9_0_i23);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__disj_gen__generate_non_disjuncts_9_0_i27);
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i23);
	r1 = string_const("disj_gen__generate_non_disjuncts: last disjunct followed by others", 66);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i26,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i26);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i27);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	{
	Declare_entry(mercury__code_info__maybe_get_old_hp_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_get_old_hp_4_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i28,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i28);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__code_info__maybe_pop_stack_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_pop_stack_4_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i29,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i29);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__maybe_restore_ticket_and_pop_4_0);
	call_localret(ENTRY(mercury__code_info__maybe_restore_ticket_and_pop_4_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i30,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i30);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r3 = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i31,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i31);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i32,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i32);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__pickup_zombies_3_0);
	call_localret(ENTRY(mercury__code_info__pickup_zombies_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i33,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i33);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	{
	Declare_entry(mercury__code_info__make_vars_dead_3_0);
	call_localret(ENTRY(mercury__code_info__make_vars_dead_3_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i34,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i34);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 1)) = string_const("End of pruned disj", 18);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i3);
	detstackvar(1) = (Integer) r7;
	r1 = string_const("empty nondet disjunction!", 25);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__disj_gen__generate_non_disjuncts_9_0_i36,
		STATIC(mercury__disj_gen__generate_non_disjuncts_9_0));
	}
Define_label(mercury__disj_gen__generate_non_disjuncts_9_0_i36);
	update_prof_current_proc(LABEL(mercury__disj_gen__generate_non_disjuncts_9_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__disj_gen_bunch_0(void)
{
	mercury__disj_gen_module0();
	mercury__disj_gen_module1();
	mercury__disj_gen_module2();
	mercury__disj_gen_module3();
	mercury__disj_gen_module4();
	mercury__disj_gen_module5();
}

#endif

void mercury__disj_gen__init(void); /* suppress gcc warning */
void mercury__disj_gen__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__disj_gen_bunch_0();
#endif
}
