/*
** Automatically generated from `live_vars.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__live_vars__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__live_vars__allocate_stack_slots_in_proc_3_0);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i2);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i3);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i4);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i5);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i6);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i7);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i8);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i9);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i10);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i11);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i14);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i15);
Declare_static(mercury__live_vars__build_live_sets_in_goal_9_0);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i2);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i3);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i7);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i10);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i12);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i9);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i13);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i14);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i18);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i19);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i20);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i21);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i16);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i15);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i28);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i31);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i30);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i33);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i34);
Declare_label(mercury__live_vars__build_live_sets_in_goal_9_0_i36);
Declare_static(mercury__live_vars__build_live_sets_in_goal_2_10_0);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1008);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1007);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1006);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1005);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1004);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i11);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i12);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i8);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i16);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i17);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i18);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i19);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i20);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i21);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i25);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i26);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i27);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i28);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i29);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i30);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i31);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i32);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i38);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i39);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i40);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i41);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i42);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i43);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1003);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i48);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i53);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i52);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i55);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i56);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i57);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i58);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i59);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i50);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i66);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i67);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i68);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i69);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i70);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i71);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i72);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i73);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i74);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1000);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1002);
Declare_static(mercury__live_vars__build_live_sets_in_conj_9_0);
Declare_label(mercury__live_vars__build_live_sets_in_conj_9_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_conj_9_0_i7);
Declare_label(mercury__live_vars__build_live_sets_in_conj_9_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_conj_9_0_i10);
Declare_label(mercury__live_vars__build_live_sets_in_conj_9_0_i1003);
Declare_static(mercury__live_vars__build_live_sets_in_disj_10_0);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i10);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i11);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i14);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i13);
Declare_label(mercury__live_vars__build_live_sets_in_disj_10_0_i1004);
Declare_static(mercury__live_vars__build_live_sets_in_cases_9_0);
Declare_label(mercury__live_vars__build_live_sets_in_cases_9_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_cases_9_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_cases_9_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_cases_9_0_i1002);
Declare_static(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0);
Declare_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i2);
Declare_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i3);
Declare_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i7);
Declare_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i8);
Declare_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i9);
Declare_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i4);
Declare_static(mercury__live_vars__find_output_vars_5_0);
Declare_label(mercury__live_vars__find_output_vars_5_0_i2);
Declare_label(mercury__live_vars__find_output_vars_5_0_i3);
Declare_label(mercury__live_vars__find_output_vars_5_0_i4);
Declare_label(mercury__live_vars__find_output_vars_5_0_i5);
Declare_label(mercury__live_vars__find_output_vars_5_0_i6);
Declare_static(mercury__live_vars__find_output_vars_from_arg_info_3_0);
Declare_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i2);
Declare_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i3);
Declare_static(mercury__live_vars__find_output_vars_2_3_0);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i7);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i1003);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i1005);
Declare_static(mercury__live_vars__allocate_stack_slots_2_5_0);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i4);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i9);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i1004);
Declare_static(mercury__live_vars__allocate_same_stack_slot_4_0);
Declare_label(mercury__live_vars__allocate_same_stack_slot_4_0_i4);
Declare_label(mercury__live_vars__allocate_same_stack_slot_4_0_i1002);

extern Word * mercury_data_set__base_type_info_set_1[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_live_vars__common_0[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

BEGIN_MODULE(mercury__live_vars_module0)
	init_entry(mercury__live_vars__allocate_stack_slots_in_proc_3_0);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i2);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i3);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i4);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i5);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i6);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i7);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i8);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i9);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i10);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i11);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i14);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i15);
BEGIN_CODE

/* code for predicate 'allocate_stack_slots_in_proc'/3 in mode 0 */
Define_entry(mercury__live_vars__allocate_stack_slots_in_proc_3_0);
	incr_sp_push_msg(7, "allocate_stack_slots_in_proc");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i2,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i3,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__liveness__initial_liveness_3_0);
	call_localret(ENTRY(mercury__liveness__initial_liveness_3_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i4,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i5,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i6,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i7,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__graph_colour__group_elements_2_0);
	call_localret(ENTRY(mercury__graph_colour__group_elements_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i8,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i8);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i9,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i9);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i10,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	if (((Integer) detstackvar(4) != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i11);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 0);
	r3 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i14);
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i11);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = ((Integer) 1);
	r3 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(1);
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i14);
	detstackvar(1) = (Integer) r5;
	call_localret(STATIC(mercury__live_vars__allocate_stack_slots_2_5_0),
		mercury__live_vars__allocate_stack_slots_in_proc_3_0_i15,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_3_0_i15);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__hlds_pred__proc_info_set_stack_slots_3_0);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_set_stack_slots_3_0),
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__live_vars_module1)
	init_entry(mercury__live_vars__build_live_sets_in_goal_9_0);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i2);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i3);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i7);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i10);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i12);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i9);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i13);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i14);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i18);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i19);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i20);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i21);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i16);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i15);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i28);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i31);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i30);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i33);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i34);
	init_label(mercury__live_vars__build_live_sets_in_goal_9_0_i36);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_goal'/9 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_goal_9_0);
	incr_sp_push_msg(14, "build_live_sets_in_goal");
	detstackvar(14) = (Integer) succip;
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_births_2_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i2,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_deaths_2_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i3,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_births_2_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i4,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_deaths_2_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i5,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i7,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_goal__goal_is_atomic_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_is_atomic_1_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i10,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i9);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i12,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i12);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i13);
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i9);
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(10);
	r8 = (Integer) detstackvar(11);
	r9 = (Integer) detstackvar(12);
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i13);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r7;
	detstackvar(11) = (Integer) r8;
	detstackvar(1) = (Integer) r9;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i14,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i14);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i16);
	COMPUTED_GOTO((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)),
		LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i18) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i19) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i19) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i19));
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i18);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i15);
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i19);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i20,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i20);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	r3 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_9_0_i21,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i21);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i15);
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i16);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i15);
	detstackvar(8) = (Integer) r1;
	detstackvar(10) = (Integer) r8;
	detstackvar(11) = (Integer) r9;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i28,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i28);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	detstackvar(6) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__hlds_goal__goal_is_atomic_1_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_is_atomic_1_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i31,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i31);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i30);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(13);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_9_0_i34);
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i30);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i33,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i33);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(10);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i34);
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_9_0_i36,
		STATIC(mercury__live_vars__build_live_sets_in_goal_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_9_0_i36);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_9_0));
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__live_vars_module2)
	init_entry(mercury__live_vars__build_live_sets_in_goal_2_10_0);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1008);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1007);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1006);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1005);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1004);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i11);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i12);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i8);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i16);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i17);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i18);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i19);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i20);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i21);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i25);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i26);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i27);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i28);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i29);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i30);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i31);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i32);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i38);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i39);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i40);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i41);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i42);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i43);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1003);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i48);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i53);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i52);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i55);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i56);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i57);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i58);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i59);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i50);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i66);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i67);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i68);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i69);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i70);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i71);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i72);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i73);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i74);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1000);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1002);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_goal_2'/10 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_goal_2_10_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1003);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1000) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1008) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1002) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1007) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1006) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1005) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1004));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1008);
	incr_sp_push_msg(11, "build_live_sets_in_goal_2");
	detstackvar(11) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r5 = (Integer) r3;
	r6 = (Integer) r2;
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i8);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i8);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i11,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1007);
	incr_sp_push_msg(11, "build_live_sets_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i16);
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1006);
	incr_sp_push_msg(11, "build_live_sets_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i18);
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1005);
	incr_sp_push_msg(11, "build_live_sets_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i25);
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1004);
	incr_sp_push_msg(11, "build_live_sets_in_goal_2");
	detstackvar(11) = (Integer) succip;
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i30);
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i11);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i12,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i12);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i8);
	r1 = (Integer) r6;
	r2 = (Integer) r5;
	r3 = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i16);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i17,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i17);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i18);
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i19,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i19);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	detstackvar(7) = (Integer) r1;
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i20,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i20);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i21);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i21);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i25);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i26,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i26);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i27,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i27);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r4 = (Integer) r3;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i28,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i28);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i29,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i29);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i30);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i31,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i31);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	if (((Integer) r1 == ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i32);
	if (((Integer) detstackvar(4) != ((Integer) 1)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i32);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i32);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__live_vars__find_output_vars_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i38,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i38);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i39,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i39);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i40,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i40);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i41,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i41);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i42,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i42);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	if (((Integer) detstackvar(4) != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i43);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i43);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1003);
	incr_sp_push_msg(11, "build_live_sets_in_goal_2");
	detstackvar(11) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i48);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_conj_9_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i48);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i50);
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_inline_1_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i53,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i53);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i52);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i52);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r4 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__live_vars__find_output_vars_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i55,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i55);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i56,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i56);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i57,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i57);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i58,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i58);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i59,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i59);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i20,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i50);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(9) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(10) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	{
	Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i66,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i66);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r4 = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__arg_info__make_arg_infos_6_0);
	call_localret(ENTRY(mercury__arg_info__make_arg_infos_6_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i67,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i67);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i68,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i68);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i69,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i69);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i70,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i70);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i71,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i71);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_live_vars__common_0);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i72,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i72);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_10_0_i73,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i73);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_10_0_i74);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i74);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_cases_9_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_10_0_i1002);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_disj_10_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_10_0));
END_MODULE

BEGIN_MODULE(mercury__live_vars_module3)
	init_entry(mercury__live_vars__build_live_sets_in_conj_9_0);
	init_label(mercury__live_vars__build_live_sets_in_conj_9_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_conj_9_0_i7);
	init_label(mercury__live_vars__build_live_sets_in_conj_9_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_conj_9_0_i10);
	init_label(mercury__live_vars__build_live_sets_in_conj_9_0_i1003);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_conj'/9 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_conj_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_conj_9_0_i1003);
	incr_sp_push_msg(8, "build_live_sets_in_conj");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) tempr1;
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__live_vars__build_live_sets_in_conj_9_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_conj_9_0));
	}
	}
Define_label(mercury__live_vars__build_live_sets_in_conj_9_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_conj_9_0));
	{
	Declare_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_unreachable_1_0),
		mercury__live_vars__build_live_sets_in_conj_9_0_i7,
		STATIC(mercury__live_vars__build_live_sets_in_conj_9_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_conj_9_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_conj_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_conj_9_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		STATIC(mercury__live_vars__build_live_sets_in_conj_9_0));
Define_label(mercury__live_vars__build_live_sets_in_conj_9_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_conj_9_0_i10,
		STATIC(mercury__live_vars__build_live_sets_in_conj_9_0));
Define_label(mercury__live_vars__build_live_sets_in_conj_9_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_conj_9_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__live_vars__build_live_sets_in_conj_9_0,
		STATIC(mercury__live_vars__build_live_sets_in_conj_9_0));
Define_label(mercury__live_vars__build_live_sets_in_conj_9_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__live_vars_module4)
	init_entry(mercury__live_vars__build_live_sets_in_disj_10_0);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i10);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i11);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i14);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i13);
	init_label(mercury__live_vars__build_live_sets_in_disj_10_0_i1004);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_disj'/10 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_disj_10_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_disj_10_0_i1004);
	incr_sp_push_msg(7, "build_live_sets_in_disj");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) r6;
	r6 = (Integer) r7;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_disj_10_0_i4,
		STATIC(mercury__live_vars__build_live_sets_in_disj_10_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_10_0));
	r7 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) r3;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	localcall(mercury__live_vars__build_live_sets_in_disj_10_0,
		LABEL(mercury__live_vars__build_live_sets_in_disj_10_0_i5),
		STATIC(mercury__live_vars__build_live_sets_in_disj_10_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_10_0));
	r1 = (Integer) detstackvar(3);
	detstackvar(4) = (Integer) r3;
	detstackvar(6) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_disj_10_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_disj_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_10_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_disj_10_0_i13);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_disj_10_0_i10,
		STATIC(mercury__live_vars__build_live_sets_in_disj_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_10_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__live_vars__build_live_sets_in_disj_10_0_i11,
		STATIC(mercury__live_vars__build_live_sets_in_disj_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i11);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_10_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_disj_10_0_i13);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_disj_10_0_i14,
		STATIC(mercury__live_vars__build_live_sets_in_disj_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i14);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i13);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_disj_10_0_i1004);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__live_vars_module5)
	init_entry(mercury__live_vars__build_live_sets_in_cases_9_0);
	init_label(mercury__live_vars__build_live_sets_in_cases_9_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_cases_9_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_cases_9_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_cases_9_0_i1002);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_cases'/9 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_cases_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_cases_9_0_i1002);
	incr_sp_push_msg(6, "build_live_sets_in_cases");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_9_0),
		mercury__live_vars__build_live_sets_in_cases_9_0_i4,
		STATIC(mercury__live_vars__build_live_sets_in_cases_9_0));
Define_label(mercury__live_vars__build_live_sets_in_cases_9_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_cases_9_0));
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	localcall(mercury__live_vars__build_live_sets_in_cases_9_0,
		LABEL(mercury__live_vars__build_live_sets_in_cases_9_0_i5),
		STATIC(mercury__live_vars__build_live_sets_in_cases_9_0));
Define_label(mercury__live_vars__build_live_sets_in_cases_9_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_cases_9_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) tempr1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_cases_9_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_cases_9_0));
	}
	}
Define_label(mercury__live_vars__build_live_sets_in_cases_9_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_cases_9_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_cases_9_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__live_vars_module6)
	init_entry(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0);
	init_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i2);
	init_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i3);
	init_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i7);
	init_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i8);
	init_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i9);
	init_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i4);
BEGIN_CODE

/* code for predicate 'maybe_add_accurate_gc_typeinfos'/5 in mode 0 */
Define_static(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0);
	incr_sp_push_msg(4, "maybe_add_accurate_gc_typeinfos");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_globals_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i2,
		STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	}
Define_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	{
	Declare_entry(mercury__globals__get_gc_method_2_0);
	call_localret(ENTRY(mercury__globals__get_gc_method_2_0),
		mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i3,
		STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	}
Define_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i4);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0),
		mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i7,
		STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	}
Define_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_used_typeinfos_setwise_3_0),
		mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i8,
		STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	}
Define_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i8);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i9,
		STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	}
Define_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i9);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__set__union_3_0);
	tailcall(ENTRY(mercury__set__union_3_0),
		STATIC(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0));
	}
Define_label(mercury__live_vars__maybe_add_accurate_gc_typeinfos_5_0_i4);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__live_vars_module7)
	init_entry(mercury__live_vars__find_output_vars_5_0);
	init_label(mercury__live_vars__find_output_vars_5_0_i2);
	init_label(mercury__live_vars__find_output_vars_5_0_i3);
	init_label(mercury__live_vars__find_output_vars_5_0_i4);
	init_label(mercury__live_vars__find_output_vars_5_0_i5);
	init_label(mercury__live_vars__find_output_vars_5_0_i6);
BEGIN_CODE

/* code for predicate 'find_output_vars'/5 in mode 0 */
Define_static(mercury__live_vars__find_output_vars_5_0);
	incr_sp_push_msg(4, "find_output_vars");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__live_vars__find_output_vars_5_0_i2,
		STATIC(mercury__live_vars__find_output_vars_5_0));
	}
Define_label(mercury__live_vars__find_output_vars_5_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__live_vars__find_output_vars_5_0_i3,
		STATIC(mercury__live_vars__find_output_vars_5_0));
	}
Define_label(mercury__live_vars__find_output_vars_5_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__live_vars__find_output_vars_5_0_i4,
		STATIC(mercury__live_vars__find_output_vars_5_0));
	}
Define_label(mercury__live_vars__find_output_vars_5_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__live_vars__find_output_vars_5_0_i5,
		STATIC(mercury__live_vars__find_output_vars_5_0));
	}
Define_label(mercury__live_vars__find_output_vars_5_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	{
	Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__live_vars__find_output_vars_5_0_i6,
		STATIC(mercury__live_vars__find_output_vars_5_0));
	}
Define_label(mercury__live_vars__find_output_vars_5_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0),
		STATIC(mercury__live_vars__find_output_vars_5_0));
END_MODULE

BEGIN_MODULE(mercury__live_vars_module8)
	init_entry(mercury__live_vars__find_output_vars_from_arg_info_3_0);
	init_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i2);
	init_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_output_vars_from_arg_info'/3 in mode 0 */
Define_static(mercury__live_vars__find_output_vars_from_arg_info_3_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	incr_sp_push_msg(2, "find_output_vars_from_arg_info");
	detstackvar(2) = (Integer) succip;
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__live_vars__find_output_vars_from_arg_info_3_0_i2,
		STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0));
	}
Define_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_from_arg_info_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__find_output_vars_from_arg_info_3_0_i3,
		STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0));
	}
Define_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_from_arg_info_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__live_vars__find_output_vars_2_3_0),
		STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0));
END_MODULE

BEGIN_MODULE(mercury__live_vars_module9)
	init_entry(mercury__live_vars__find_output_vars_2_3_0);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i7);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i1003);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i1005);
BEGIN_CODE

/* code for predicate 'find_output_vars_2'/3 in mode 0 */
Define_static(mercury__live_vars__find_output_vars_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__find_output_vars_2_3_0_i1003);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__live_vars__find_output_vars_2_3_0_i1005);
	incr_sp_push_msg(2, "find_output_vars_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__find_output_vars_2_3_0_i7,
		STATIC(mercury__live_vars__find_output_vars_2_3_0));
	}
Define_label(mercury__live_vars__find_output_vars_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__live_vars__find_output_vars_2_3_0,
		STATIC(mercury__live_vars__find_output_vars_2_3_0));
Define_label(mercury__live_vars__find_output_vars_2_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__live_vars__find_output_vars_2_3_0_i1005);
	r1 = (Integer) r3;
	localtailcall(mercury__live_vars__find_output_vars_2_3_0,
		STATIC(mercury__live_vars__find_output_vars_2_3_0));
END_MODULE

BEGIN_MODULE(mercury__live_vars_module10)
	init_entry(mercury__live_vars__allocate_stack_slots_2_5_0);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i4);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i9);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i1004);
BEGIN_CODE

/* code for predicate 'allocate_stack_slots_2'/5 in mode 0 */
Define_static(mercury__live_vars__allocate_stack_slots_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__allocate_stack_slots_2_5_0_i1004);
	incr_sp_push_msg(5, "allocate_stack_slots_2");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__live_vars__allocate_stack_slots_2_5_0_i4,
		STATIC(mercury__live_vars__allocate_stack_slots_2_5_0));
	}
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_2_5_0));
	if (((Integer) detstackvar(2) != ((Integer) 2)))
		GOTO_LABEL(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	GOTO_LABEL(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r2, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r2, ((Integer) 1)) = (Integer) r4;
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	call_localret(STATIC(mercury__live_vars__allocate_same_stack_slot_4_0),
		mercury__live_vars__allocate_stack_slots_2_5_0_i9,
		STATIC(mercury__live_vars__allocate_stack_slots_2_5_0));
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) detstackvar(1) + ((Integer) 1));
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__live_vars__allocate_stack_slots_2_5_0,
		STATIC(mercury__live_vars__allocate_stack_slots_2_5_0));
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i1004);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__live_vars_module11)
	init_entry(mercury__live_vars__allocate_same_stack_slot_4_0);
	init_label(mercury__live_vars__allocate_same_stack_slot_4_0_i4);
	init_label(mercury__live_vars__allocate_same_stack_slot_4_0_i1002);
BEGIN_CODE

/* code for predicate 'allocate_same_stack_slot'/4 in mode 0 */
Define_static(mercury__live_vars__allocate_same_stack_slot_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__live_vars__allocate_same_stack_slot_4_0_i1002);
	incr_sp_push_msg(3, "allocate_same_stack_slot");
	detstackvar(3) = (Integer) succip;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r2 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__live_vars__allocate_same_stack_slot_4_0_i4,
		STATIC(mercury__live_vars__allocate_same_stack_slot_4_0));
	}
Define_label(mercury__live_vars__allocate_same_stack_slot_4_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_same_stack_slot_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__live_vars__allocate_same_stack_slot_4_0,
		STATIC(mercury__live_vars__allocate_same_stack_slot_4_0));
Define_label(mercury__live_vars__allocate_same_stack_slot_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__live_vars_bunch_0(void)
{
	mercury__live_vars_module0();
	mercury__live_vars_module1();
	mercury__live_vars_module2();
	mercury__live_vars_module3();
	mercury__live_vars_module4();
	mercury__live_vars_module5();
	mercury__live_vars_module6();
	mercury__live_vars_module7();
	mercury__live_vars_module8();
	mercury__live_vars_module9();
	mercury__live_vars_module10();
	mercury__live_vars_module11();
}

#endif

void mercury__live_vars__init(void); /* suppress gcc warning */
void mercury__live_vars__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__live_vars_bunch_0();
#endif
}
