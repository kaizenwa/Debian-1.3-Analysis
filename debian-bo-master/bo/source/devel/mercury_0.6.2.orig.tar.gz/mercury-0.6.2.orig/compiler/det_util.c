/*
** Automatically generated from `det_util.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__det_util__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___det_util_det_info_0__ua10000_2_0);
Define_extern_entry(mercury__det_util__update_instmap_3_0);
Declare_label(mercury__det_util__update_instmap_3_0_i2);
Define_extern_entry(mercury__det_util__interpret_unify_4_0);
Declare_label(mercury__det_util__interpret_unify_4_0_i5);
Declare_label(mercury__det_util__interpret_unify_4_0_i1002);
Declare_label(mercury__det_util__interpret_unify_4_0_i8);
Declare_label(mercury__det_util__interpret_unify_4_0_i9);
Declare_label(mercury__det_util__interpret_unify_4_0_i10);
Declare_label(mercury__det_util__interpret_unify_4_0_i7);
Declare_label(mercury__det_util__interpret_unify_4_0_i1);
Declare_label(mercury__det_util__interpret_unify_4_0_i1000);
Define_extern_entry(mercury__det_util__det_lookup_detism_4_0);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i2);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i3);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i4);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i5);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i6);
Define_extern_entry(mercury__det_util__det_get_proc_info_2_0);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i2);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i3);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i4);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i5);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i6);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i7);
Define_extern_entry(mercury__det_util__det_lookup_var_type_4_0);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i2);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i3);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i6);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i8);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i9);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i5);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i11);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i1000);
Define_extern_entry(mercury__det_util__det_no_output_vars_4_0);
Declare_label(mercury__det_util__det_no_output_vars_4_0_i2);
Define_extern_entry(mercury__det_util__det_info_init_5_0);
Declare_label(mercury__det_util__det_info_init_5_0_i2);
Declare_label(mercury__det_util__det_info_init_5_0_i3);
Declare_label(mercury__det_util__det_info_init_5_0_i4);
Define_extern_entry(mercury__det_util__det_info_get_module_info_2_0);
Define_extern_entry(mercury__det_util__det_info_get_pred_id_2_0);
Define_extern_entry(mercury__det_util__det_info_get_proc_id_2_0);
Define_extern_entry(mercury__det_util__det_info_get_reorder_conj_2_0);
Define_extern_entry(mercury__det_util__det_info_get_reorder_disj_2_0);
Define_extern_entry(mercury__det_util__det_info_get_fully_strict_2_0);
Define_extern_entry(mercury____Unify___det_util__maybe_changed_0_0);
Declare_label(mercury____Unify___det_util__maybe_changed_0_0_i1);
Define_extern_entry(mercury____Index___det_util__maybe_changed_0_0);
Define_extern_entry(mercury____Compare___det_util__maybe_changed_0_0);
Define_extern_entry(mercury____Unify___det_util__det_info_0_0);
Declare_label(mercury____Unify___det_util__det_info_0_0_i2);
Declare_label(mercury____Unify___det_util__det_info_0_0_i4);
Declare_label(mercury____Unify___det_util__det_info_0_0_i6);
Declare_label(mercury____Unify___det_util__det_info_0_0_i1);
Define_extern_entry(mercury____Index___det_util__det_info_0_0);
Define_extern_entry(mercury____Compare___det_util__det_info_0_0);
Declare_label(mercury____Compare___det_util__det_info_0_0_i4);
Declare_label(mercury____Compare___det_util__det_info_0_0_i5);
Declare_label(mercury____Compare___det_util__det_info_0_0_i3);
Declare_label(mercury____Compare___det_util__det_info_0_0_i10);
Declare_label(mercury____Compare___det_util__det_info_0_0_i16);
Declare_label(mercury____Compare___det_util__det_info_0_0_i22);
Declare_label(mercury____Compare___det_util__det_info_0_0_i28);

extern Word * mercury_data_det_util__base_type_layout_det_info_0[];
Word * mercury_data_det_util__base_type_info_det_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___det_util__det_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___det_util__det_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___det_util__det_info_0_0),
	(Word *) (Integer) mercury_data_det_util__base_type_layout_det_info_0
};

extern Word * mercury_data_det_util__base_type_layout_maybe_changed_0[];
Word * mercury_data_det_util__base_type_info_maybe_changed_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___det_util__maybe_changed_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___det_util__maybe_changed_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___det_util__maybe_changed_0_0),
	(Word *) (Integer) mercury_data_det_util__base_type_layout_maybe_changed_0
};

extern Word * mercury_data_det_util__common_1[];
Word * mercury_data_det_util__base_type_layout_maybe_changed_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_1)
};

extern Word * mercury_data_det_util__common_5[];
Word * mercury_data_det_util__base_type_layout_det_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_det_util__common_5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_det_util__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_det_util__common_1[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("changed", 7),
	(Word *) string_const("unchanged", 9)
};

extern Word * mercury_data_hlds_module__base_type_info_module_info_0[];
Word * mercury_data_det_util__common_2[] = {
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_module_info_0
};

Word * mercury_data_det_util__common_3[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_det_util__common_4[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_det_util__common_5[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_4),
	(Word *) string_const("det_info", 8)
};

BEGIN_MODULE(mercury__det_util_module0)
	init_entry(mercury____Index___det_util_det_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___det_util_det_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___det_util_det_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module1)
	init_entry(mercury__det_util__update_instmap_3_0);
	init_label(mercury__det_util__update_instmap_3_0_i2);
BEGIN_CODE

/* code for predicate 'update_instmap'/3 in mode 0 */
Define_entry(mercury__det_util__update_instmap_3_0);
	incr_sp_push_msg(2, "update_instmap");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__det_util__update_instmap_3_0_i2,
		ENTRY(mercury__det_util__update_instmap_3_0));
	}
Define_label(mercury__det_util__update_instmap_3_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__update_instmap_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
	tailcall(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		ENTRY(mercury__det_util__update_instmap_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_util_module2)
	init_entry(mercury__det_util__interpret_unify_4_0);
	init_label(mercury__det_util__interpret_unify_4_0_i5);
	init_label(mercury__det_util__interpret_unify_4_0_i1002);
	init_label(mercury__det_util__interpret_unify_4_0_i8);
	init_label(mercury__det_util__interpret_unify_4_0_i9);
	init_label(mercury__det_util__interpret_unify_4_0_i10);
	init_label(mercury__det_util__interpret_unify_4_0_i7);
	init_label(mercury__det_util__interpret_unify_4_0_i1);
	init_label(mercury__det_util__interpret_unify_4_0_i1000);
BEGIN_CODE

/* code for predicate 'interpret_unify'/4 in mode 0 */
Define_entry(mercury__det_util__interpret_unify_4_0);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i1002);
	r4 = (Integer) r2;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	incr_sp_push_msg(5, "interpret_unify");
	detstackvar(5) = (Integer) succip;
	{
	Declare_entry(mercury__term__unify_4_0);
	call_localret(ENTRY(mercury__term__unify_4_0),
		mercury__det_util__interpret_unify_4_0_i5,
		ENTRY(mercury__det_util__interpret_unify_4_0));
	}
	}
Define_label(mercury__det_util__interpret_unify_4_0_i5);
	update_prof_current_proc(LABEL(mercury__det_util__interpret_unify_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if ((Integer) r1)
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__det_util__interpret_unify_4_0_i1002);
	incr_sp_push_msg(5, "interpret_unify");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i7);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__det_util__interpret_unify_4_0_i8,
		ENTRY(mercury__det_util__interpret_unify_4_0));
	}
Define_label(mercury__det_util__interpret_unify_4_0_i8);
	update_prof_current_proc(LABEL(mercury__det_util__interpret_unify_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__term__var_list_to_term_list_2_0);
	call_localret(ENTRY(mercury__term__var_list_to_term_list_2_0),
		mercury__det_util__interpret_unify_4_0_i9,
		ENTRY(mercury__det_util__interpret_unify_4_0));
	}
Define_label(mercury__det_util__interpret_unify_4_0_i9);
	update_prof_current_proc(LABEL(mercury__det_util__interpret_unify_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__cons_id_to_const_3_0);
	call_localret(ENTRY(mercury__hlds_data__cons_id_to_const_3_0),
		mercury__det_util__interpret_unify_4_0_i10,
		ENTRY(mercury__det_util__interpret_unify_4_0));
	}
Define_label(mercury__det_util__interpret_unify_4_0_i10);
	update_prof_current_proc(LABEL(mercury__det_util__interpret_unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i1);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__term__unify_4_0);
	call_localret(ENTRY(mercury__term__unify_4_0),
		mercury__det_util__interpret_unify_4_0_i5,
		ENTRY(mercury__det_util__interpret_unify_4_0));
	}
Define_label(mercury__det_util__interpret_unify_4_0_i7);
	r2 = (Integer) r3;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__det_util__interpret_unify_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__det_util__interpret_unify_4_0_i1000);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module3)
	init_entry(mercury__det_util__det_lookup_detism_4_0);
	init_label(mercury__det_util__det_lookup_detism_4_0_i2);
	init_label(mercury__det_util__det_lookup_detism_4_0_i3);
	init_label(mercury__det_util__det_lookup_detism_4_0_i4);
	init_label(mercury__det_util__det_lookup_detism_4_0_i5);
	init_label(mercury__det_util__det_lookup_detism_4_0_i6);
BEGIN_CODE

/* code for predicate 'det_lookup_detism'/4 in mode 0 */
Define_entry(mercury__det_util__det_lookup_detism_4_0);
	incr_sp_push_msg(3, "det_lookup_detism");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
		call_localret(STATIC(mercury__det_util__det_info_get_module_info_2_0),
		mercury__det_util__det_lookup_detism_4_0_i2,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
	}
Define_label(mercury__det_util__det_lookup_detism_4_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_util__det_lookup_detism_4_0_i3,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
	}
Define_label(mercury__det_util__det_lookup_detism_4_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_util__det_lookup_detism_4_0_i4,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
	}
Define_label(mercury__det_util__det_lookup_detism_4_0_i4);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__det_util__det_lookup_detism_4_0_i5,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
	}
Define_label(mercury__det_util__det_lookup_detism_4_0_i5);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_util__det_lookup_detism_4_0_i6,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
	}
Define_label(mercury__det_util__det_lookup_detism_4_0_i6);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_util_module4)
	init_entry(mercury__det_util__det_get_proc_info_2_0);
	init_label(mercury__det_util__det_get_proc_info_2_0_i2);
	init_label(mercury__det_util__det_get_proc_info_2_0_i3);
	init_label(mercury__det_util__det_get_proc_info_2_0_i4);
	init_label(mercury__det_util__det_get_proc_info_2_0_i5);
	init_label(mercury__det_util__det_get_proc_info_2_0_i6);
	init_label(mercury__det_util__det_get_proc_info_2_0_i7);
BEGIN_CODE

/* code for predicate 'det_get_proc_info'/2 in mode 0 */
Define_entry(mercury__det_util__det_get_proc_info_2_0);
	incr_sp_push_msg(3, "det_get_proc_info");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__det_util__det_info_get_module_info_2_0),
		mercury__det_util__det_get_proc_info_2_0_i2,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
Define_label(mercury__det_util__det_get_proc_info_2_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__det_util__det_info_get_pred_id_2_0),
		mercury__det_util__det_get_proc_info_2_0_i3,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
Define_label(mercury__det_util__det_get_proc_info_2_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__det_util__det_info_get_proc_id_2_0),
		mercury__det_util__det_get_proc_info_2_0_i4,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
Define_label(mercury__det_util__det_get_proc_info_2_0_i4);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_util__det_get_proc_info_2_0_i5,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
Define_label(mercury__det_util__det_get_proc_info_2_0_i5);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_util__det_get_proc_info_2_0_i6,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
Define_label(mercury__det_util__det_get_proc_info_2_0_i6);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__det_util__det_get_proc_info_2_0_i7,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
Define_label(mercury__det_util__det_get_proc_info_2_0_i7);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_util_module5)
	init_entry(mercury__det_util__det_lookup_var_type_4_0);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i2);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i3);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i6);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i8);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i9);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i5);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i11);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i1000);
BEGIN_CODE

/* code for predicate 'det_lookup_var_type'/4 in mode 0 */
Define_entry(mercury__det_util__det_lookup_var_type_4_0);
	incr_sp_push_msg(3, "det_lookup_var_type");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__det_util__det_lookup_var_type_4_0_i2,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
	}
Define_label(mercury__det_util__det_lookup_var_type_4_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__det_util__det_lookup_var_type_4_0_i3,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
	}
Define_label(mercury__det_util__det_lookup_var_type_4_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__det_util__det_lookup_var_type_4_0_i6,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
	}
Define_label(mercury__det_util__det_lookup_var_type_4_0_i6);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__det_util__det_lookup_var_type_4_0_i5);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__det_util__det_lookup_var_type_4_0_i8,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
	}
Define_label(mercury__det_util__det_lookup_var_type_4_0_i8);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_det_util__common_0);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__det_util__det_lookup_var_type_4_0_i9,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
	}
Define_label(mercury__det_util__det_lookup_var_type_4_0_i9);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((Integer) r1)
		GOTO_LABEL(mercury__det_util__det_lookup_var_type_4_0_i1000);
	r1 = FALSE;
	proceed();
Define_label(mercury__det_util__det_lookup_var_type_4_0_i5);
	r1 = string_const("cannot lookup the type of a variable", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__det_util__det_lookup_var_type_4_0_i11,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
	}
Define_label(mercury__det_util__det_lookup_var_type_4_0_i11);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__det_util__det_lookup_var_type_4_0_i1000);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module6)
	init_entry(mercury__det_util__det_no_output_vars_4_0);
	init_label(mercury__det_util__det_no_output_vars_4_0_i2);
BEGIN_CODE

/* code for predicate 'det_no_output_vars'/4 in mode 0 */
Define_entry(mercury__det_util__det_no_output_vars_4_0);
	incr_sp_push_msg(4, "det_no_output_vars");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	{
		call_localret(STATIC(mercury__det_util__det_info_get_module_info_2_0),
		mercury__det_util__det_no_output_vars_4_0_i2,
		ENTRY(mercury__det_util__det_no_output_vars_4_0));
	}
Define_label(mercury__det_util__det_no_output_vars_4_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_no_output_vars_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__instmap__no_output_vars_4_0);
	tailcall(ENTRY(mercury__instmap__no_output_vars_4_0),
		ENTRY(mercury__det_util__det_no_output_vars_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_util_module7)
	init_entry(mercury__det_util__det_info_init_5_0);
	init_label(mercury__det_util__det_info_init_5_0_i2);
	init_label(mercury__det_util__det_info_init_5_0_i3);
	init_label(mercury__det_util__det_info_init_5_0_i4);
BEGIN_CODE

/* code for predicate 'det_info_init'/5 in mode 0 */
Define_entry(mercury__det_util__det_info_init_5_0);
	incr_sp_push_msg(6, "det_info_init");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r4;
	r2 = ((Integer) 39);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__det_util__det_info_init_5_0_i2,
		ENTRY(mercury__det_util__det_info_init_5_0));
	}
Define_label(mercury__det_util__det_info_init_5_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_info_init_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 40);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__det_util__det_info_init_5_0_i3,
		ENTRY(mercury__det_util__det_info_init_5_0));
	}
Define_label(mercury__det_util__det_info_init_5_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_info_init_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 41);
	{
	Declare_entry(mercury__globals__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__det_util__det_info_init_5_0_i4,
		ENTRY(mercury__det_util__det_info_init_5_0));
	}
Define_label(mercury__det_util__det_info_init_5_0_i4);
	update_prof_current_proc(LABEL(mercury__det_util__det_info_init_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module8)
	init_entry(mercury__det_util__det_info_get_module_info_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_module_info'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_module_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module9)
	init_entry(mercury__det_util__det_info_get_pred_id_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_pred_id'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_pred_id_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module10)
	init_entry(mercury__det_util__det_info_get_proc_id_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_proc_id'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_proc_id_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module11)
	init_entry(mercury__det_util__det_info_get_reorder_conj_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_reorder_conj'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_reorder_conj_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module12)
	init_entry(mercury__det_util__det_info_get_reorder_disj_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_reorder_disj'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_reorder_disj_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module13)
	init_entry(mercury__det_util__det_info_get_fully_strict_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_fully_strict'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_fully_strict_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module14)
	init_entry(mercury____Unify___det_util__maybe_changed_0_0);
	init_label(mercury____Unify___det_util__maybe_changed_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___det_util__maybe_changed_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___det_util__maybe_changed_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___det_util__maybe_changed_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module15)
	init_entry(mercury____Index___det_util__maybe_changed_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___det_util__maybe_changed_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___det_util__maybe_changed_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_util_module16)
	init_entry(mercury____Compare___det_util__maybe_changed_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___det_util__maybe_changed_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___det_util__maybe_changed_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__det_util_module17)
	init_entry(mercury____Unify___det_util__det_info_0_0);
	init_label(mercury____Unify___det_util__det_info_0_0_i2);
	init_label(mercury____Unify___det_util__det_info_0_0_i4);
	init_label(mercury____Unify___det_util__det_info_0_0_i6);
	init_label(mercury____Unify___det_util__det_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___det_util__det_info_0_0);
	incr_sp_push_msg(11, "__Unify__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___det_util__det_info_0_0_i2,
		ENTRY(mercury____Unify___det_util__det_info_0_0));
	}
Define_label(mercury____Unify___det_util__det_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___det_util__det_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(6)))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(7)))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Unify___bool__bool_0_0);
	call_localret(ENTRY(mercury____Unify___bool__bool_0_0),
		mercury____Unify___det_util__det_info_0_0_i4,
		ENTRY(mercury____Unify___det_util__det_info_0_0));
	}
Define_label(mercury____Unify___det_util__det_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___det_util__det_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Unify___bool__bool_0_0);
	call_localret(ENTRY(mercury____Unify___bool__bool_0_0),
		mercury____Unify___det_util__det_info_0_0_i6,
		ENTRY(mercury____Unify___det_util__det_info_0_0));
	}
Define_label(mercury____Unify___det_util__det_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___det_util__det_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Unify___bool__bool_0_0);
	tailcall(ENTRY(mercury____Unify___bool__bool_0_0),
		ENTRY(mercury____Unify___det_util__det_info_0_0));
	}
Define_label(mercury____Unify___det_util__det_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__det_util_module18)
	init_entry(mercury____Index___det_util__det_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___det_util__det_info_0_0);
	tailcall(STATIC(mercury____Index___det_util_det_info_0__ua10000_2_0),
		ENTRY(mercury____Index___det_util__det_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__det_util_module19)
	init_entry(mercury____Compare___det_util__det_info_0_0);
	init_label(mercury____Compare___det_util__det_info_0_0_i4);
	init_label(mercury____Compare___det_util__det_info_0_0_i5);
	init_label(mercury____Compare___det_util__det_info_0_0_i3);
	init_label(mercury____Compare___det_util__det_info_0_0_i10);
	init_label(mercury____Compare___det_util__det_info_0_0_i16);
	init_label(mercury____Compare___det_util__det_info_0_0_i22);
	init_label(mercury____Compare___det_util__det_info_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___det_util__det_info_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___det_util__det_info_0_0_i4,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
	}
Define_label(mercury____Compare___det_util__det_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i3);
Define_label(mercury____Compare___det_util__det_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___det_util__det_info_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___det_util__det_info_0_0_i10,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
	}
Define_label(mercury____Compare___det_util__det_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___det_util__det_info_0_0_i16,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
	}
Define_label(mercury____Compare___det_util__det_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___bool__bool_0_0);
	call_localret(ENTRY(mercury____Compare___bool__bool_0_0),
		mercury____Compare___det_util__det_info_0_0_i22,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
	}
Define_label(mercury____Compare___det_util__det_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___bool__bool_0_0);
	call_localret(ENTRY(mercury____Compare___bool__bool_0_0),
		mercury____Compare___det_util__det_info_0_0_i28,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
	}
Define_label(mercury____Compare___det_util__det_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___bool__bool_0_0);
	tailcall(ENTRY(mercury____Compare___bool__bool_0_0),
		ENTRY(mercury____Compare___det_util__det_info_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__det_util_bunch_0(void)
{
	mercury__det_util_module0();
	mercury__det_util_module1();
	mercury__det_util_module2();
	mercury__det_util_module3();
	mercury__det_util_module4();
	mercury__det_util_module5();
	mercury__det_util_module6();
	mercury__det_util_module7();
	mercury__det_util_module8();
	mercury__det_util_module9();
	mercury__det_util_module10();
	mercury__det_util_module11();
	mercury__det_util_module12();
	mercury__det_util_module13();
	mercury__det_util_module14();
	mercury__det_util_module15();
	mercury__det_util_module16();
	mercury__det_util_module17();
	mercury__det_util_module18();
	mercury__det_util_module19();
}

#endif

void mercury__det_util__init(void); /* suppress gcc warning */
void mercury__det_util__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__det_util_bunch_0();
#endif
}
