/*
** Automatically generated from `bytecode_gen.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__bytecode_gen__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__bytecode_gen__unify__ua10000_5_0);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i6);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i7);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i1025);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i10);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i11);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i12);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i15);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i16);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i14);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i9);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i21);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i22);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i23);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i24);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i27);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i26);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i29);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i20);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i31);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i32);
Declare_label(mercury__bytecode_gen__unify__ua10000_5_0_i1023);
Define_extern_entry(mercury__bytecode_gen__module_4_0);
Declare_label(mercury__bytecode_gen__module_4_0_i2);
Declare_label(mercury__bytecode_gen__module_4_0_i3);
Declare_label(mercury__bytecode_gen__module_4_0_i4);
Declare_label(mercury__bytecode_gen__module_4_0_i5);
Declare_static(mercury__bytecode_gen__preds_5_0);
Declare_label(mercury__bytecode_gen__preds_5_0_i4);
Declare_label(mercury__bytecode_gen__preds_5_0_i5);
Declare_label(mercury__bytecode_gen__preds_5_0_i6);
Declare_label(mercury__bytecode_gen__preds_5_0_i7);
Declare_label(mercury__bytecode_gen__preds_5_0_i10);
Declare_label(mercury__bytecode_gen__preds_5_0_i11);
Declare_label(mercury__bytecode_gen__preds_5_0_i12);
Declare_label(mercury__bytecode_gen__preds_5_0_i13);
Declare_label(mercury__bytecode_gen__preds_5_0_i14);
Declare_label(mercury__bytecode_gen__preds_5_0_i1008);
Declare_static(mercury__bytecode_gen__pred_7_0);
Declare_label(mercury__bytecode_gen__pred_7_0_i4);
Declare_label(mercury__bytecode_gen__pred_7_0_i5);
Declare_label(mercury__bytecode_gen__pred_7_0_i6);
Declare_label(mercury__bytecode_gen__pred_7_0_i7);
Declare_label(mercury__bytecode_gen__pred_7_0_i8);
Declare_label(mercury__bytecode_gen__pred_7_0_i9);
Declare_label(mercury__bytecode_gen__pred_7_0_i10);
Declare_label(mercury__bytecode_gen__pred_7_0_i11);
Declare_label(mercury__bytecode_gen__pred_7_0_i12);
Declare_label(mercury__bytecode_gen__pred_7_0_i13);
Declare_label(mercury__bytecode_gen__pred_7_0_i14);
Declare_label(mercury__bytecode_gen__pred_7_0_i15);
Declare_label(mercury__bytecode_gen__pred_7_0_i16);
Declare_label(mercury__bytecode_gen__pred_7_0_i17);
Declare_label(mercury__bytecode_gen__pred_7_0_i18);
Declare_label(mercury__bytecode_gen__pred_7_0_i19);
Declare_label(mercury__bytecode_gen__pred_7_0_i20);
Declare_label(mercury__bytecode_gen__pred_7_0_i21);
Declare_label(mercury__bytecode_gen__pred_7_0_i22);
Declare_label(mercury__bytecode_gen__pred_7_0_i23);
Declare_label(mercury__bytecode_gen__pred_7_0_i24);
Declare_label(mercury__bytecode_gen__pred_7_0_i27);
Declare_label(mercury__bytecode_gen__pred_7_0_i26);
Declare_label(mercury__bytecode_gen__pred_7_0_i29);
Declare_label(mercury__bytecode_gen__pred_7_0_i30);
Declare_label(mercury__bytecode_gen__pred_7_0_i1017);
Declare_static(mercury__bytecode_gen__goal_5_0);
Declare_label(mercury__bytecode_gen__goal_5_0_i2);
Declare_label(mercury__bytecode_gen__goal_5_0_i3);
Declare_static(mercury__bytecode_gen__goal_expr_5_0);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1008);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1007);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1006);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1005);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1004);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1003);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i5);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i6);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i7);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i8);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i9);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i10);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i11);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i12);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i13);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i14);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i15);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i16);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i17);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i18);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i19);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1002);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i21);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i26);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i25);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i23);
Declare_label(mercury__bytecode_gen__goal_expr_5_0_i1000);
Declare_static(mercury__bytecode_gen__gen_places_3_0);
Declare_label(mercury__bytecode_gen__gen_places_3_0_i4);
Declare_label(mercury__bytecode_gen__gen_places_3_0_i5);
Declare_label(mercury__bytecode_gen__gen_places_3_0_i1006);
Declare_static(mercury__bytecode_gen__gen_pickups_3_0);
Declare_label(mercury__bytecode_gen__gen_pickups_3_0_i4);
Declare_label(mercury__bytecode_gen__gen_pickups_3_0_i5);
Declare_label(mercury__bytecode_gen__gen_pickups_3_0_i1006);
Declare_static(mercury__bytecode_gen__call_5_0);
Declare_label(mercury__bytecode_gen__call_5_0_i2);
Declare_label(mercury__bytecode_gen__call_5_0_i3);
Declare_label(mercury__bytecode_gen__call_5_0_i4);
Declare_label(mercury__bytecode_gen__call_5_0_i5);
Declare_label(mercury__bytecode_gen__call_5_0_i6);
Declare_label(mercury__bytecode_gen__call_5_0_i7);
Declare_label(mercury__bytecode_gen__call_5_0_i8);
Declare_label(mercury__bytecode_gen__call_5_0_i9);
Declare_static(mercury__bytecode_gen__builtin_5_0);
Declare_label(mercury__bytecode_gen__builtin_5_0_i2);
Declare_label(mercury__bytecode_gen__builtin_5_0_i3);
Declare_label(mercury__bytecode_gen__builtin_5_0_i6);
Declare_label(mercury__bytecode_gen__builtin_5_0_i14);
Declare_label(mercury__bytecode_gen__builtin_5_0_i15);
Declare_label(mercury__bytecode_gen__builtin_5_0_i11);
Declare_label(mercury__bytecode_gen__builtin_5_0_i19);
Declare_label(mercury__bytecode_gen__builtin_5_0_i16);
Declare_label(mercury__bytecode_gen__builtin_5_0_i20);
Declare_label(mercury__bytecode_gen__builtin_5_0_i8);
Declare_label(mercury__bytecode_gen__builtin_5_0_i23);
Declare_label(mercury__bytecode_gen__builtin_5_0_i30);
Declare_label(mercury__bytecode_gen__builtin_5_0_i31);
Declare_label(mercury__bytecode_gen__builtin_5_0_i32);
Declare_label(mercury__bytecode_gen__builtin_5_0_i27);
Declare_label(mercury__bytecode_gen__builtin_5_0_i36);
Declare_label(mercury__bytecode_gen__builtin_5_0_i37);
Declare_label(mercury__bytecode_gen__builtin_5_0_i33);
Declare_label(mercury__bytecode_gen__builtin_5_0_i1049);
Declare_label(mercury__bytecode_gen__builtin_5_0_i5);
Declare_label(mercury__bytecode_gen__builtin_5_0_i42);
Declare_static(mercury__bytecode_gen__map_arg_3_0);
Declare_label(mercury__bytecode_gen__map_arg_3_0_i5);
Declare_label(mercury__bytecode_gen__map_arg_3_0_i1001);
Declare_label(mercury__bytecode_gen__map_arg_3_0_i6);
Declare_label(mercury__bytecode_gen__map_arg_3_0_i10);
Declare_static(mercury__bytecode_gen__map_uni_modes_4_0);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i6);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i7);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i8);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i9);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i13);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i17);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i21);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i24);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i25);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i1016);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i1014);
Declare_label(mercury__bytecode_gen__map_uni_modes_4_0_i1015);
Declare_static(mercury__bytecode_gen__all_dirs_same_2_0);
Declare_label(mercury__bytecode_gen__all_dirs_same_2_0_i1003);
Declare_label(mercury__bytecode_gen__all_dirs_same_2_0_i1004);
Declare_static(mercury__bytecode_gen__conj_5_0);
Declare_label(mercury__bytecode_gen__conj_5_0_i4);
Declare_label(mercury__bytecode_gen__conj_5_0_i5);
Declare_label(mercury__bytecode_gen__conj_5_0_i1002);
Declare_static(mercury__bytecode_gen__disj_5_0);
Declare_label(mercury__bytecode_gen__disj_5_0_i4);
Declare_label(mercury__bytecode_gen__disj_5_0_i5);
Declare_label(mercury__bytecode_gen__disj_5_0_i1011);
Declare_static(mercury__bytecode_gen__switch_6_0);
Declare_label(mercury__bytecode_gen__switch_6_0_i4);
Declare_label(mercury__bytecode_gen__switch_6_0_i5);
Declare_label(mercury__bytecode_gen__switch_6_0_i6);
Declare_label(mercury__bytecode_gen__switch_6_0_i1011);
Declare_static(mercury__bytecode_gen__map_cons_id_4_0);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i5);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i7);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i6);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i9);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i1028);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i1049);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i13);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i12);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i11);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i14);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i15);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i19);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i21);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i23);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i25);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i27);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i28);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i29);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i18);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i30);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i10);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i1043);
Declare_label(mercury__bytecode_gen__map_cons_id_4_0_i1048);
Declare_static(mercury__bytecode_gen__create_varmap_7_0);
Declare_label(mercury__bytecode_gen__create_varmap_7_0_i4);
Declare_label(mercury__bytecode_gen__create_varmap_7_0_i5);
Declare_label(mercury__bytecode_gen__create_varmap_7_0_i6);
Declare_label(mercury__bytecode_gen__create_varmap_7_0_i7);
Declare_label(mercury__bytecode_gen__create_varmap_7_0_i1003);
Declare_static(mercury__bytecode_gen__map_vars_2_3_0);
Declare_label(mercury__bytecode_gen__map_vars_2_3_0_i4);
Declare_label(mercury__bytecode_gen__map_vars_2_3_0_i5);
Declare_label(mercury__bytecode_gen__map_vars_2_3_0_i1002);
Declare_static(mercury__bytecode_gen__map_var_3_0);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_bytecode_gen__base_type_layout_byte_info_0[];
Word * mercury_data_bytecode_gen__base_type_info_byte_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_bytecode_gen__base_type_layout_byte_info_0
};

extern Word * mercury_data_bytecode_gen__common_22[];
Word * mercury_data_bytecode_gen__base_type_layout_byte_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_22),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
extern Word * mercury_data_bytecode__base_type_info_byte_code_0[];
Word * mercury_data_bytecode_gen__common_0[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_bytecode__base_type_info_byte_code_0
};

Word mercury_data_bytecode_gen__common_1[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_2[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_1)
};

Word mercury_data_bytecode_gen__common_3[] = {
	((Integer) 0),
	((Integer) 0)
};

Word * mercury_data_bytecode_gen__common_4[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_bytecode_gen__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_5[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_4)
};

Word mercury_data_bytecode_gen__common_6[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 12))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_7[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_6)
};

Word mercury_data_bytecode_gen__common_8[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_9[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_8)
};

Word * mercury_data_bytecode_gen__common_10[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_7),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_9)
};

Word mercury_data_bytecode_gen__common_11[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 9))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_12[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_11)
};

Word mercury_data_bytecode_gen__common_13[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 11))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_14[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_13)
};

Word mercury_data_bytecode_gen__common_15[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 10))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_16[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_15)
};

Word mercury_data_bytecode_gen__common_17[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 6))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_bytecode_gen__common_18[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_17)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_bytecode_gen__common_19[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_bytecode_gen__common_20[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_hlds_module__base_type_info_module_info_0[];
Word * mercury_data_bytecode_gen__common_21[] = {
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_module_info_0
};

Word * mercury_data_bytecode_gen__common_22[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_bytecode_gen__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_bytecode_gen__common_20),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_bytecode_gen__common_21),
	(Word *) string_const("byte_info", 9)
};

BEGIN_MODULE(mercury__bytecode_gen_module0)
	init_entry(mercury__bytecode_gen__unify__ua10000_5_0);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i6);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i7);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i1025);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i10);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i11);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i12);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i15);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i16);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i14);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i9);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i21);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i22);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i23);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i24);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i27);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i26);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i29);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i20);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i31);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i32);
	init_label(mercury__bytecode_gen__unify__ua10000_5_0_i1023);
BEGIN_CODE

/* code for predicate 'bytecode_gen__unify__ua10000'/5 in mode 0 */
Define_static(mercury__bytecode_gen__unify__ua10000_5_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__unify__ua10000_5_0_i1025);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__bytecode_gen__unify__ua10000_5_0_i1023);
	incr_sp_push_msg(7, "bytecode_gen__unify__ua10000");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i6,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i7,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 8);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i1025);
	incr_sp_push_msg(7, "bytecode_gen__unify__ua10000");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__bytecode_gen__unify__ua10000_5_0_i9);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i10,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i10);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_vars_2_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i11,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i11);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__bytecode_gen__map_cons_id_4_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i12,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i12);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_uni_modes_4_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i15,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i15);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__bytecode_gen__all_dirs_same_2_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i16,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i16);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__bytecode_gen__unify__ua10000_5_0_i14);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 9);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i14);
	r1 = string_const("invalid mode for construction unification", 41);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
	}
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i9);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__bytecode_gen__unify__ua10000_5_0_i20);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i21,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i21);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_vars_2_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i22,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i22);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__bytecode_gen__map_cons_id_4_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i23,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i23);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_uni_modes_4_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i24,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i24);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	detstackvar(3) = (Integer) r1;
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__bytecode_gen__all_dirs_same_2_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i27,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i27);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__bytecode_gen__unify__ua10000_5_0_i26);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 10);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i26);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_bytecode__base_type_info_byte_dir_0[];
	r2 = (Integer) mercury_data_bytecode__base_type_info_byte_dir_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i29,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
	}
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i29);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 11);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i20);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i31,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i31);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__unify__ua10000_5_0_i32,
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i32);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__unify__ua10000_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 7);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__bytecode_gen__unify__ua10000_5_0_i1023);
	r1 = string_const("we do not handle complicated unifications yet", 45);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__unify__ua10000_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module1)
	init_entry(mercury__bytecode_gen__module_4_0);
	init_label(mercury__bytecode_gen__module_4_0_i2);
	init_label(mercury__bytecode_gen__module_4_0_i3);
	init_label(mercury__bytecode_gen__module_4_0_i4);
	init_label(mercury__bytecode_gen__module_4_0_i5);
BEGIN_CODE

/* code for predicate 'bytecode_gen__module'/4 in mode 0 */
Define_entry(mercury__bytecode_gen__module_4_0);
	incr_sp_push_msg(3, "bytecode_gen__module");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_predids_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__bytecode_gen__module_4_0_i2,
		ENTRY(mercury__bytecode_gen__module_4_0));
	}
Define_label(mercury__bytecode_gen__module_4_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__module_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__bytecode_gen__preds_5_0),
		mercury__bytecode_gen__module_4_0_i3,
		ENTRY(mercury__bytecode_gen__module_4_0));
Define_label(mercury__bytecode_gen__module_4_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__module_4_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_bytecode_gen__common_0);
	{
	Declare_entry(mercury__tree__flatten_2_0);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__bytecode_gen__module_4_0_i4,
		ENTRY(mercury__bytecode_gen__module_4_0));
	}
Define_label(mercury__bytecode_gen__module_4_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__module_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_bytecode__base_type_info_byte_code_0;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__bytecode_gen__module_4_0_i5,
		ENTRY(mercury__bytecode_gen__module_4_0));
	}
Define_label(mercury__bytecode_gen__module_4_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__module_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module2)
	init_entry(mercury__bytecode_gen__preds_5_0);
	init_label(mercury__bytecode_gen__preds_5_0_i4);
	init_label(mercury__bytecode_gen__preds_5_0_i5);
	init_label(mercury__bytecode_gen__preds_5_0_i6);
	init_label(mercury__bytecode_gen__preds_5_0_i7);
	init_label(mercury__bytecode_gen__preds_5_0_i10);
	init_label(mercury__bytecode_gen__preds_5_0_i11);
	init_label(mercury__bytecode_gen__preds_5_0_i12);
	init_label(mercury__bytecode_gen__preds_5_0_i13);
	init_label(mercury__bytecode_gen__preds_5_0_i14);
	init_label(mercury__bytecode_gen__preds_5_0_i1008);
BEGIN_CODE

/* code for predicate 'bytecode_gen__preds'/5 in mode 0 */
Define_static(mercury__bytecode_gen__preds_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__preds_5_0_i1008);
	incr_sp_push_msg(6, "bytecode_gen__preds");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__bytecode_gen__preds_5_0_i4,
		STATIC(mercury__bytecode_gen__preds_5_0));
	}
Define_label(mercury__bytecode_gen__preds_5_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__bytecode_gen__preds_5_0_i5,
		STATIC(mercury__bytecode_gen__preds_5_0));
	}
Define_label(mercury__bytecode_gen__preds_5_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__bytecode_gen__preds_5_0_i6,
		STATIC(mercury__bytecode_gen__preds_5_0));
	}
Define_label(mercury__bytecode_gen__preds_5_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__preds_5_0_i7);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__bytecode_gen__preds_5_0_i13);
Define_label(mercury__bytecode_gen__preds_5_0_i7);
	r5 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__bytecode_gen__pred_7_0),
		mercury__bytecode_gen__preds_5_0_i10,
		STATIC(mercury__bytecode_gen__preds_5_0));
Define_label(mercury__bytecode_gen__preds_5_0_i10);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	detstackvar(5) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__bytecode_gen__preds_5_0_i11,
		STATIC(mercury__bytecode_gen__preds_5_0));
	}
Define_label(mercury__bytecode_gen__preds_5_0_i11);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__bytecode_gen__preds_5_0_i12,
		STATIC(mercury__bytecode_gen__preds_5_0));
	}
Define_label(mercury__bytecode_gen__preds_5_0_i12);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_2);
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__bytecode_gen__preds_5_0_i13);
	detstackvar(1) = (Integer) r4;
	localcall(mercury__bytecode_gen__preds_5_0,
		LABEL(mercury__bytecode_gen__preds_5_0_i14),
		STATIC(mercury__bytecode_gen__preds_5_0));
Define_label(mercury__bytecode_gen__preds_5_0_i14);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__preds_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__bytecode_gen__preds_5_0_i1008);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module3)
	init_entry(mercury__bytecode_gen__pred_7_0);
	init_label(mercury__bytecode_gen__pred_7_0_i4);
	init_label(mercury__bytecode_gen__pred_7_0_i5);
	init_label(mercury__bytecode_gen__pred_7_0_i6);
	init_label(mercury__bytecode_gen__pred_7_0_i7);
	init_label(mercury__bytecode_gen__pred_7_0_i8);
	init_label(mercury__bytecode_gen__pred_7_0_i9);
	init_label(mercury__bytecode_gen__pred_7_0_i10);
	init_label(mercury__bytecode_gen__pred_7_0_i11);
	init_label(mercury__bytecode_gen__pred_7_0_i12);
	init_label(mercury__bytecode_gen__pred_7_0_i13);
	init_label(mercury__bytecode_gen__pred_7_0_i14);
	init_label(mercury__bytecode_gen__pred_7_0_i15);
	init_label(mercury__bytecode_gen__pred_7_0_i16);
	init_label(mercury__bytecode_gen__pred_7_0_i17);
	init_label(mercury__bytecode_gen__pred_7_0_i18);
	init_label(mercury__bytecode_gen__pred_7_0_i19);
	init_label(mercury__bytecode_gen__pred_7_0_i20);
	init_label(mercury__bytecode_gen__pred_7_0_i21);
	init_label(mercury__bytecode_gen__pred_7_0_i22);
	init_label(mercury__bytecode_gen__pred_7_0_i23);
	init_label(mercury__bytecode_gen__pred_7_0_i24);
	init_label(mercury__bytecode_gen__pred_7_0_i27);
	init_label(mercury__bytecode_gen__pred_7_0_i26);
	init_label(mercury__bytecode_gen__pred_7_0_i29);
	init_label(mercury__bytecode_gen__pred_7_0_i30);
	init_label(mercury__bytecode_gen__pred_7_0_i1017);
BEGIN_CODE

/* code for predicate 'bytecode_gen__pred'/7 in mode 0 */
Define_static(mercury__bytecode_gen__pred_7_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__pred_7_0_i1017);
	incr_sp_push_msg(13, "bytecode_gen__pred");
	detstackvar(13) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("% Generating bytecode for ", 26);
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__passes_aux__write_proc_progress_message_6_0);
	call_localret(ENTRY(mercury__passes_aux__write_proc_progress_message_6_0),
		mercury__bytecode_gen__pred_7_0_i4,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__bytecode_gen__pred_7_0_i5,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__bytecode_gen__pred_7_0_i6,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__bytecode_gen__pred_7_0_i7,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__bytecode_gen__pred_7_0_i8,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i8);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__bytecode_gen__pred_7_0_i9,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i9);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		mercury__bytecode_gen__pred_7_0_i10,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i10);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__goal_util__goal_vars_2_0);
	call_localret(ENTRY(mercury__goal_util__goal_vars_2_0),
		mercury__bytecode_gen__pred_7_0_i11,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i11);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__bytecode_gen__pred_7_0_i12,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i12);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__bytecode_gen__pred_7_0_i13,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i13);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(9);
	r4 = ((Integer) 0);
	call_localret(STATIC(mercury__bytecode_gen__create_varmap_7_0),
		mercury__bytecode_gen__pred_7_0_i14,
		STATIC(mercury__bytecode_gen__pred_7_0));
Define_label(mercury__bytecode_gen__pred_7_0_i14);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	detstackvar(10) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	detstackvar(9) = (Integer) r2;
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__bytecode_gen__pred_7_0_i15,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i15);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__bytecode_gen__pred_7_0_i16,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i16);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__bytecode_gen__pred_7_0_i17,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i17);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__call_gen__input_arg_locs_2_0);
	call_localret(ENTRY(mercury__call_gen__input_arg_locs_2_0),
		mercury__bytecode_gen__pred_7_0_i18,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i18);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__bytecode_gen__gen_pickups_3_0),
		mercury__bytecode_gen__pred_7_0_i19,
		STATIC(mercury__bytecode_gen__pred_7_0));
Define_label(mercury__bytecode_gen__pred_7_0_i19);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__call_gen__output_arg_locs_2_0);
	call_localret(ENTRY(mercury__call_gen__output_arg_locs_2_0),
		mercury__bytecode_gen__pred_7_0_i20,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i20);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__bytecode_gen__gen_places_3_0),
		mercury__bytecode_gen__pred_7_0_i21,
		STATIC(mercury__bytecode_gen__pred_7_0));
Define_label(mercury__bytecode_gen__pred_7_0_i21);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__pred_7_0_i22,
		STATIC(mercury__bytecode_gen__pred_7_0));
Define_label(mercury__bytecode_gen__pred_7_0_i22);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r3 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_bytecode_gen__common_0);
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_5);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__tree__flatten_2_0);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__bytecode_gen__pred_7_0_i23,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
	}
Define_label(mercury__bytecode_gen__pred_7_0_i23);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_bytecode__base_type_info_byte_code_0;
	{
	Declare_entry(mercury__list__condense_2_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__bytecode_gen__pred_7_0_i24,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i24);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r3 = (Integer) r1;
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) mercury_data_bytecode__base_type_info_byte_code_0;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 12)));
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__bytecode_gen__pred_7_0_i27,
		STATIC(mercury__bytecode_gen__pred_7_0));
	}
Define_label(mercury__bytecode_gen__pred_7_0_i27);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__bytecode_gen__pred_7_0_i26);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(2), (Integer) mercury_data_bytecode_gen__common_10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	r5 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__bytecode_gen__pred_7_0_i29);
	}
Define_label(mercury__bytecode_gen__pred_7_0_i26);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(9);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(8);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(11);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_9);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	r5 = (Integer) detstackvar(7);
	}
Define_label(mercury__bytecode_gen__pred_7_0_i29);
	detstackvar(6) = (Integer) r6;
	localcall(mercury__bytecode_gen__pred_7_0,
		LABEL(mercury__bytecode_gen__pred_7_0_i30),
		STATIC(mercury__bytecode_gen__pred_7_0));
Define_label(mercury__bytecode_gen__pred_7_0_i30);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__pred_7_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(13);
	decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__bytecode_gen__pred_7_0_i1017);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module4)
	init_entry(mercury__bytecode_gen__goal_5_0);
	init_label(mercury__bytecode_gen__goal_5_0_i2);
	init_label(mercury__bytecode_gen__goal_5_0_i3);
BEGIN_CODE

/* code for predicate 'bytecode_gen__goal'/5 in mode 0 */
Define_static(mercury__bytecode_gen__goal_5_0);
	incr_sp_push_msg(3, "bytecode_gen__goal");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__bytecode_gen__goal_expr_5_0),
		mercury__bytecode_gen__goal_5_0_i2,
		STATIC(mercury__bytecode_gen__goal_5_0));
Define_label(mercury__bytecode_gen__goal_5_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__bytecode_gen__goal_5_0_i3,
		STATIC(mercury__bytecode_gen__goal_5_0));
	}
Define_label(mercury__bytecode_gen__goal_5_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_5_0));
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 19);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module5)
	init_entry(mercury__bytecode_gen__goal_expr_5_0);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1008);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1007);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1006);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1005);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1004);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1003);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i5);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i6);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i7);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i8);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i9);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i10);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i11);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i12);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i13);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i14);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i15);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i16);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i17);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i18);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i19);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1002);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i21);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i26);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i25);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i23);
	init_label(mercury__bytecode_gen__goal_expr_5_0_i1000);
BEGIN_CODE

/* code for predicate 'bytecode_gen__goal_expr'/5 in mode 0 */
Define_static(mercury__bytecode_gen__goal_expr_5_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i1002);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1008) AND
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1007) AND
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1006) AND
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1005) AND
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1004) AND
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1003) AND
		LABEL(mercury__bytecode_gen__goal_expr_5_0_i1000));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1008);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i5);
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1007);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i8);
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1006);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i10);
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1005);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i12);
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1004);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i14);
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1003);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i16);
Define_label(mercury__bytecode_gen__goal_expr_5_0_i5);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__bytecode_gen__switch_6_0),
		mercury__bytecode_gen__goal_expr_5_0_i6,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__goal_expr_5_0_i7,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	r3 = (Integer) r1;
	r1 = ((Integer) detstackvar(2) + ((Integer) 1));
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 4)));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i8);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	call_localret(STATIC(mercury__bytecode_gen__unify__ua10000_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i9,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i9);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__bytecode_gen__goal_expr_5_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__bytecode_gen__disj_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i11,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i11);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r3 = (Integer) r1;
	r1 = ((Integer) r3 + ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i12);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i13,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i13);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r3 = (Integer) r1;
	r1 = ((Integer) r3 + ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_12);
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i14);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i15,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i15);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_14);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i16);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i17,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i17);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i18,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i18);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r3 = ((Integer) tempr1 + ((Integer) 1));
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i19,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i19);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	r3 = (Integer) r1;
	r1 = ((Integer) r3 + ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_18);
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 7)));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r6, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 8)));
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(2), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1002);
	incr_sp_push_msg(6, "bytecode_gen__goal_expr");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i21);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__bytecode_gen__conj_5_0),
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i21);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i23);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0);
	call_localret(ENTRY(mercury__hlds_goal__hlds__is_builtin_is_internal_1_0),
		mercury__bytecode_gen__goal_expr_5_0_i26,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i26);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__goal_expr_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__bytecode_gen__goal_expr_5_0_i25);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__bytecode_gen__builtin_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i9,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i25);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__bytecode_gen__call_5_0),
		mercury__bytecode_gen__goal_expr_5_0_i9,
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
Define_label(mercury__bytecode_gen__goal_expr_5_0_i23);
	r1 = string_const("we do not handle higher order calls yet", 39);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__goal_expr_5_0));
	}
Define_label(mercury__bytecode_gen__goal_expr_5_0_i1000);
	r1 = (Integer) r3;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_bytecode_gen__common_7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module6)
	init_entry(mercury__bytecode_gen__gen_places_3_0);
	init_label(mercury__bytecode_gen__gen_places_3_0_i4);
	init_label(mercury__bytecode_gen__gen_places_3_0_i5);
	init_label(mercury__bytecode_gen__gen_places_3_0_i1006);
BEGIN_CODE

/* code for predicate 'bytecode_gen__gen_places'/3 in mode 0 */
Define_static(mercury__bytecode_gen__gen_places_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__gen_places_3_0_i1006);
	incr_sp_push_msg(4, "bytecode_gen__gen_places");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__bytecode_gen__gen_places_3_0,
		LABEL(mercury__bytecode_gen__gen_places_3_0_i4),
		STATIC(mercury__bytecode_gen__gen_places_3_0));
Define_label(mercury__bytecode_gen__gen_places_3_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__gen_places_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__gen_places_3_0_i5,
		STATIC(mercury__bytecode_gen__gen_places_3_0));
Define_label(mercury__bytecode_gen__gen_places_3_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__gen_places_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 12);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) r2;
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__bytecode_gen__gen_places_3_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module7)
	init_entry(mercury__bytecode_gen__gen_pickups_3_0);
	init_label(mercury__bytecode_gen__gen_pickups_3_0_i4);
	init_label(mercury__bytecode_gen__gen_pickups_3_0_i5);
	init_label(mercury__bytecode_gen__gen_pickups_3_0_i1006);
BEGIN_CODE

/* code for predicate 'bytecode_gen__gen_pickups'/3 in mode 0 */
Define_static(mercury__bytecode_gen__gen_pickups_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__gen_pickups_3_0_i1006);
	incr_sp_push_msg(4, "bytecode_gen__gen_pickups");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__bytecode_gen__gen_pickups_3_0,
		LABEL(mercury__bytecode_gen__gen_pickups_3_0_i4),
		STATIC(mercury__bytecode_gen__gen_pickups_3_0));
Define_label(mercury__bytecode_gen__gen_pickups_3_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__gen_pickups_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__gen_pickups_3_0_i5,
		STATIC(mercury__bytecode_gen__gen_pickups_3_0));
Define_label(mercury__bytecode_gen__gen_pickups_3_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__gen_pickups_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(r5, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 14);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) r2;
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__bytecode_gen__gen_pickups_3_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module8)
	init_entry(mercury__bytecode_gen__call_5_0);
	init_label(mercury__bytecode_gen__call_5_0_i2);
	init_label(mercury__bytecode_gen__call_5_0_i3);
	init_label(mercury__bytecode_gen__call_5_0_i4);
	init_label(mercury__bytecode_gen__call_5_0_i5);
	init_label(mercury__bytecode_gen__call_5_0_i6);
	init_label(mercury__bytecode_gen__call_5_0_i7);
	init_label(mercury__bytecode_gen__call_5_0_i8);
	init_label(mercury__bytecode_gen__call_5_0_i9);
BEGIN_CODE

/* code for predicate 'bytecode_gen__call'/5 in mode 0 */
Define_static(mercury__bytecode_gen__call_5_0);
	incr_sp_push_msg(6, "bytecode_gen__call");
	detstackvar(6) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	detstackvar(5) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__bytecode_gen__call_5_0_i2,
		STATIC(mercury__bytecode_gen__call_5_0));
	}
Define_label(mercury__bytecode_gen__call_5_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__bytecode_gen__call_5_0_i3,
		STATIC(mercury__bytecode_gen__call_5_0));
	}
Define_label(mercury__bytecode_gen__call_5_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_arg_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_arg_info_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__bytecode_gen__call_5_0_i4,
		STATIC(mercury__bytecode_gen__call_5_0));
	}
Define_label(mercury__bytecode_gen__call_5_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__call_gen__input_arg_locs_2_0);
	call_localret(ENTRY(mercury__call_gen__input_arg_locs_2_0),
		mercury__bytecode_gen__call_5_0_i5,
		STATIC(mercury__bytecode_gen__call_5_0));
	}
Define_label(mercury__bytecode_gen__call_5_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__gen_places_3_0),
		mercury__bytecode_gen__call_5_0_i6,
		STATIC(mercury__bytecode_gen__call_5_0));
Define_label(mercury__bytecode_gen__call_5_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__call_gen__output_arg_locs_2_0);
	call_localret(ENTRY(mercury__call_gen__output_arg_locs_2_0),
		mercury__bytecode_gen__call_5_0_i7,
		STATIC(mercury__bytecode_gen__call_5_0));
	}
Define_label(mercury__bytecode_gen__call_5_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__gen_pickups_3_0),
		mercury__bytecode_gen__call_5_0_i8,
		STATIC(mercury__bytecode_gen__call_5_0));
Define_label(mercury__bytecode_gen__call_5_0_i8);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_module__predicate_id_5_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_id_5_0),
		mercury__bytecode_gen__call_5_0_i9,
		STATIC(mercury__bytecode_gen__call_5_0));
	}
Define_label(mercury__bytecode_gen__call_5_0_i9);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__call_5_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 13);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module9)
	init_entry(mercury__bytecode_gen__builtin_5_0);
	init_label(mercury__bytecode_gen__builtin_5_0_i2);
	init_label(mercury__bytecode_gen__builtin_5_0_i3);
	init_label(mercury__bytecode_gen__builtin_5_0_i6);
	init_label(mercury__bytecode_gen__builtin_5_0_i14);
	init_label(mercury__bytecode_gen__builtin_5_0_i15);
	init_label(mercury__bytecode_gen__builtin_5_0_i11);
	init_label(mercury__bytecode_gen__builtin_5_0_i19);
	init_label(mercury__bytecode_gen__builtin_5_0_i16);
	init_label(mercury__bytecode_gen__builtin_5_0_i20);
	init_label(mercury__bytecode_gen__builtin_5_0_i8);
	init_label(mercury__bytecode_gen__builtin_5_0_i23);
	init_label(mercury__bytecode_gen__builtin_5_0_i30);
	init_label(mercury__bytecode_gen__builtin_5_0_i31);
	init_label(mercury__bytecode_gen__builtin_5_0_i32);
	init_label(mercury__bytecode_gen__builtin_5_0_i27);
	init_label(mercury__bytecode_gen__builtin_5_0_i36);
	init_label(mercury__bytecode_gen__builtin_5_0_i37);
	init_label(mercury__bytecode_gen__builtin_5_0_i33);
	init_label(mercury__bytecode_gen__builtin_5_0_i1049);
	init_label(mercury__bytecode_gen__builtin_5_0_i5);
	init_label(mercury__bytecode_gen__builtin_5_0_i42);
BEGIN_CODE

/* code for predicate 'bytecode_gen__builtin'/5 in mode 0 */
Define_static(mercury__bytecode_gen__builtin_5_0);
	incr_sp_push_msg(7, "bytecode_gen__builtin");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	detstackvar(5) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
	Declare_entry(mercury__hlds_module__predicate_module_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__bytecode_gen__builtin_5_0_i2,
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__hlds_module__predicate_name_3_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__bytecode_gen__builtin_5_0_i3,
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_util__translate_builtin_6_0);
	call_localret(ENTRY(mercury__code_util__translate_builtin_6_0),
		mercury__bytecode_gen__builtin_5_0_i6,
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i5);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i8);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i11);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i11);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) detstackvar(4);
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__bytecode_gen__map_arg_3_0),
		mercury__bytecode_gen__builtin_5_0_i14,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i14);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_arg_3_0),
		mercury__bytecode_gen__builtin_5_0_i15,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i15);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 17);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i23);
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i11);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i16);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i16);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(4);
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__bytecode_gen__map_arg_3_0),
		mercury__bytecode_gen__builtin_5_0_i19,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i19);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 18);
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i23);
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i16);
	detstackvar(2) = (Integer) r3;
	r1 = string_const("builtin test is not a unary or binary operator", 46);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_gen__builtin_5_0_i20,
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i20);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) r3;
	GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i23);
Define_label(mercury__bytecode_gen__builtin_5_0_i8);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) r3;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__bytecode_gen__builtin_5_0_i23);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i1049);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i27);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i27);
	detstackvar(3) = (Integer) r5;
	r2 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r1;
	call_localret(STATIC(mercury__bytecode_gen__map_arg_3_0),
		mercury__bytecode_gen__builtin_5_0_i30,
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i30);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_arg_3_0),
		mercury__bytecode_gen__builtin_5_0_i31,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i31);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__builtin_5_0_i32,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i32);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 5));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 4)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 15);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i27);
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i33);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__bytecode_gen__builtin_5_0_i33);
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r4, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r4, ((Integer) 2));
	call_localret(STATIC(mercury__bytecode_gen__map_arg_3_0),
		mercury__bytecode_gen__builtin_5_0_i36,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i36);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__builtin_5_0_i37,
		STATIC(mercury__bytecode_gen__builtin_5_0));
Define_label(mercury__bytecode_gen__builtin_5_0_i37);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 4));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 3)) = (Integer) r2;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 16);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i33);
	r1 = string_const("builtin assignment is not a unary or binary operator", 52);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i1049);
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__bytecode_gen__builtin_5_0_i5);
	r1 = string_const("unknown builtin predicate ", 26);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__bytecode_gen__builtin_5_0_i42,
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
Define_label(mercury__bytecode_gen__builtin_5_0_i42);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__builtin_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__builtin_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module10)
	init_entry(mercury__bytecode_gen__map_arg_3_0);
	init_label(mercury__bytecode_gen__map_arg_3_0_i5);
	init_label(mercury__bytecode_gen__map_arg_3_0_i1001);
	init_label(mercury__bytecode_gen__map_arg_3_0_i6);
	init_label(mercury__bytecode_gen__map_arg_3_0_i10);
BEGIN_CODE

/* code for predicate 'bytecode_gen__map_arg'/3 in mode 0 */
Define_static(mercury__bytecode_gen__map_arg_3_0);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i1001);
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(1, "bytecode_gen__map_arg");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__bytecode_gen__map_var_3_0),
		mercury__bytecode_gen__map_arg_3_0_i5,
		STATIC(mercury__bytecode_gen__map_arg_3_0));
Define_label(mercury__bytecode_gen__map_arg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_arg_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__bytecode_gen__map_arg_3_0_i1001);
	incr_sp_push_msg(1, "bytecode_gen__map_arg");
	detstackvar(1) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i6);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i6);
	r1 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i6);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__bytecode_gen__map_arg_3_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i10);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i10);
	if ((tag((Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__bytecode_gen__map_arg_3_0_i10);
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) field(mktag(3), (Integer) r2, ((Integer) 1)), ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__bytecode_gen__map_arg_3_0_i10);
	r1 = string_const("unknown kind of builtin argument", 32);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_arg_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module11)
	init_entry(mercury__bytecode_gen__map_uni_modes_4_0);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i6);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i7);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i8);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i9);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i13);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i17);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i21);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i24);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i25);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i1016);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i1014);
	init_label(mercury__bytecode_gen__map_uni_modes_4_0_i1015);
BEGIN_CODE

/* code for predicate 'bytecode_gen__map_uni_modes'/4 in mode 0 */
Define_static(mercury__bytecode_gen__map_uni_modes_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i1016);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i1014);
	incr_sp_push_msg(9, "bytecode_gen__map_uni_modes");
	detstackvar(9) = (Integer) succip;
	{
	Word tempr1, tempr2, tempr3;
	tempr2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr1 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	tempr3 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr3, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__bytecode_gen__map_uni_modes_4_0_i6,
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
	}
	}
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_uni_modes_4_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	r3 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__bytecode_gen__map_uni_modes_4_0_i7,
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
	}
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_uni_modes_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(6);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__bytecode_gen__map_uni_modes_4_0_i8,
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
	}
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i8);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_uni_modes_4_0));
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i9);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i9);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 0);
	r1 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i24);
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i9);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i13);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i13);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 1);
	r1 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i24);
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i13);
	if (((Integer) detstackvar(3) != ((Integer) 1)))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i17);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i17);
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 2);
	r1 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i24);
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i17);
	r1 = string_const("invalid mode for deconstruct unification", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_gen__map_uni_modes_4_0_i21,
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
	}
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i21);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_uni_modes_4_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(8);
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i24);
	detstackvar(1) = (Integer) r4;
	localcall(mercury__bytecode_gen__map_uni_modes_4_0,
		LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i25),
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i25);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_uni_modes_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i1016);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__map_uni_modes_4_0_i1015);
	r1 = string_const("bytecode_gen__map_uni_modes: length mismatch", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
	}
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i1014);
	r1 = string_const("bytecode_gen__map_uni_modes: length mismatch", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_uni_modes_4_0));
	}
Define_label(mercury__bytecode_gen__map_uni_modes_4_0_i1015);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module12)
	init_entry(mercury__bytecode_gen__all_dirs_same_2_0);
	init_label(mercury__bytecode_gen__all_dirs_same_2_0_i1003);
	init_label(mercury__bytecode_gen__all_dirs_same_2_0_i1004);
BEGIN_CODE

/* code for predicate 'bytecode_gen__all_dirs_same'/2 in mode 0 */
Define_static(mercury__bytecode_gen__all_dirs_same_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__all_dirs_same_2_0_i1003);
	r3 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != (Integer) r2))
		GOTO_LABEL(mercury__bytecode_gen__all_dirs_same_2_0_i1004);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localtailcall(mercury__bytecode_gen__all_dirs_same_2_0,
		STATIC(mercury__bytecode_gen__all_dirs_same_2_0));
Define_label(mercury__bytecode_gen__all_dirs_same_2_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__bytecode_gen__all_dirs_same_2_0_i1004);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module13)
	init_entry(mercury__bytecode_gen__conj_5_0);
	init_label(mercury__bytecode_gen__conj_5_0_i4);
	init_label(mercury__bytecode_gen__conj_5_0_i5);
	init_label(mercury__bytecode_gen__conj_5_0_i1002);
BEGIN_CODE

/* code for predicate 'bytecode_gen__conj'/5 in mode 0 */
Define_static(mercury__bytecode_gen__conj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__conj_5_0_i1002);
	incr_sp_push_msg(3, "bytecode_gen__conj");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__conj_5_0_i4,
		STATIC(mercury__bytecode_gen__conj_5_0));
Define_label(mercury__bytecode_gen__conj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__conj_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__bytecode_gen__conj_5_0,
		LABEL(mercury__bytecode_gen__conj_5_0_i5),
		STATIC(mercury__bytecode_gen__conj_5_0));
	}
Define_label(mercury__bytecode_gen__conj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__conj_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__bytecode_gen__conj_5_0_i1002);
	r1 = (Integer) r3;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module14)
	init_entry(mercury__bytecode_gen__disj_5_0);
	init_label(mercury__bytecode_gen__disj_5_0_i4);
	init_label(mercury__bytecode_gen__disj_5_0_i5);
	init_label(mercury__bytecode_gen__disj_5_0_i1011);
BEGIN_CODE

/* code for predicate 'bytecode_gen__disj'/5 in mode 0 */
Define_static(mercury__bytecode_gen__disj_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__disj_5_0_i1011);
	incr_sp_push_msg(3, "bytecode_gen__disj");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__disj_5_0_i4,
		STATIC(mercury__bytecode_gen__disj_5_0));
Define_label(mercury__bytecode_gen__disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__disj_5_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r3 = ((Integer) tempr1 + ((Integer) 1));
	localcall(mercury__bytecode_gen__disj_5_0,
		LABEL(mercury__bytecode_gen__disj_5_0_i5),
		STATIC(mercury__bytecode_gen__disj_5_0));
	}
Define_label(mercury__bytecode_gen__disj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__disj_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 3)));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__bytecode_gen__disj_5_0_i1011);
	r1 = (Integer) r3;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module15)
	init_entry(mercury__bytecode_gen__switch_6_0);
	init_label(mercury__bytecode_gen__switch_6_0_i4);
	init_label(mercury__bytecode_gen__switch_6_0_i5);
	init_label(mercury__bytecode_gen__switch_6_0_i6);
	init_label(mercury__bytecode_gen__switch_6_0_i1011);
BEGIN_CODE

/* code for predicate 'bytecode_gen__switch'/6 in mode 0 */
Define_static(mercury__bytecode_gen__switch_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__switch_6_0_i1011);
	incr_sp_push_msg(6, "bytecode_gen__switch");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__bytecode_gen__map_cons_id_4_0),
		mercury__bytecode_gen__switch_6_0_i4,
		STATIC(mercury__bytecode_gen__switch_6_0));
	}
Define_label(mercury__bytecode_gen__switch_6_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__switch_6_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__bytecode_gen__goal_5_0),
		mercury__bytecode_gen__switch_6_0_i5,
		STATIC(mercury__bytecode_gen__switch_6_0));
Define_label(mercury__bytecode_gen__switch_6_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__switch_6_0));
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r4 = ((Integer) detstackvar(1) + ((Integer) 1));
	localcall(mercury__bytecode_gen__switch_6_0,
		LABEL(mercury__bytecode_gen__switch_6_0_i6),
		STATIC(mercury__bytecode_gen__switch_6_0));
Define_label(mercury__bytecode_gen__switch_6_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__switch_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(2), ((Integer) 2));
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) mkword(mktag(0), mkbody(((Integer) 5)));
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(2), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__bytecode_gen__switch_6_0_i1011);
	r1 = (Integer) r4;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module16)
	init_entry(mercury__bytecode_gen__map_cons_id_4_0);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i5);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i7);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i6);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i9);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i1028);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i1049);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i13);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i12);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i11);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i14);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i15);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i19);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i21);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i23);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i25);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i27);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i28);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i29);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i18);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i30);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i10);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i1043);
	init_label(mercury__bytecode_gen__map_cons_id_4_0_i1048);
BEGIN_CODE

/* code for predicate 'bytecode_gen__map_cons_id'/4 in mode 0 */
Define_static(mercury__bytecode_gen__map_cons_id_4_0);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i1049);
	r4 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	incr_sp_push_msg(5, "bytecode_gen__map_cons_id");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i5);
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i5);
	if (((Integer) r4 != ((Integer) 1)))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i6);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__predicate_id_5_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_id_5_0),
		mercury__bytecode_gen__map_cons_id_4_0_i7,
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_cons_id_4_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i6);
	if (((Integer) r4 != ((Integer) 2)))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i1028);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__predicate_id_5_0);
	call_localret(ENTRY(mercury__hlds_module__predicate_id_5_0),
		mercury__bytecode_gen__map_cons_id_4_0_i9,
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i9);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_cons_id_4_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i1028);
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 3));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i1049);
	incr_sp_push_msg(5, "bytecode_gen__map_cons_id");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i10);
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r4) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r1 = string_const("bytecode_gen__map_cons_id: qualified cons_id", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_gen__map_cons_id_4_0_i13,
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i13);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_cons_id_4_0));
	r8 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r4 = (Integer) r8;
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i11);
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i12);
	r8 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	r5 = (Integer) r3;
	r7 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r4 = (Integer) r2;
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i11);
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(1) = (Integer) r8;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__bytecode_gen__map_cons_id_4_0_i14,
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i14);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_cons_id_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_util__cons_id_to_tag_4_0);
	call_localret(ENTRY(mercury__code_util__cons_id_to_tag_4_0),
		mercury__bytecode_gen__map_cons_id_4_0_i15,
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i15);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_cons_id_4_0));
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i18);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i19) AND
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i21) AND
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i23) AND
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i25) AND
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i27) AND
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i28) AND
		LABEL(mercury__bytecode_gen__map_cons_id_4_0_i29));
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i19);
	r1 = string_const("int_constant cons tag for non-int_constant cons id", 50);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i21);
	r1 = string_const("pred_closure_tag cons tag for non-pred_const cons id", 52);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i23);
	r1 = string_const("code_addr_constant cons tag for non-address_const cons id", 57);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i25);
	r1 = string_const("base_type_info_constant cons tag for non-base_type_info_constant cons id", 72);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i27);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i28);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i29);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i18);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i30);
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i30);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i1048);
	r1 = string_const("string_constant cons tag for non-string_constant cons id", 56);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i10);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__bytecode_gen__map_cons_id_4_0_i1043);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i1043);
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__bytecode_gen__map_cons_id_4_0_i1048);
	r1 = string_const("float_constant cons tag for non-float_constant cons id", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__bytecode_gen__map_cons_id_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module17)
	init_entry(mercury__bytecode_gen__create_varmap_7_0);
	init_label(mercury__bytecode_gen__create_varmap_7_0_i4);
	init_label(mercury__bytecode_gen__create_varmap_7_0_i5);
	init_label(mercury__bytecode_gen__create_varmap_7_0_i6);
	init_label(mercury__bytecode_gen__create_varmap_7_0_i7);
	init_label(mercury__bytecode_gen__create_varmap_7_0_i1003);
BEGIN_CODE

/* code for predicate 'bytecode_gen__create_varmap'/7 in mode 0 */
Define_static(mercury__bytecode_gen__create_varmap_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__create_varmap_7_0_i1003);
	incr_sp_push_msg(7, "bytecode_gen__create_varmap");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r5;
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__bytecode_gen__create_varmap_7_0_i4,
		STATIC(mercury__bytecode_gen__create_varmap_7_0));
	}
Define_label(mercury__bytecode_gen__create_varmap_7_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__create_varmap_7_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	detstackvar(6) = ((Integer) r2 + ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__varset__lookup_name_3_0);
	call_localret(ENTRY(mercury__varset__lookup_name_3_0),
		mercury__bytecode_gen__create_varmap_7_0_i5,
		STATIC(mercury__bytecode_gen__create_varmap_7_0));
	}
Define_label(mercury__bytecode_gen__create_varmap_7_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__create_varmap_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__bytecode_gen__create_varmap_7_0_i6,
		STATIC(mercury__bytecode_gen__create_varmap_7_0));
	}
Define_label(mercury__bytecode_gen__create_varmap_7_0_i6);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__create_varmap_7_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	localcall(mercury__bytecode_gen__create_varmap_7_0,
		LABEL(mercury__bytecode_gen__create_varmap_7_0_i7),
		STATIC(mercury__bytecode_gen__create_varmap_7_0));
Define_label(mercury__bytecode_gen__create_varmap_7_0_i7);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__create_varmap_7_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__bytecode_gen__create_varmap_7_0_i1003);
	r1 = (Integer) r5;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module18)
	init_entry(mercury__bytecode_gen__map_vars_2_3_0);
	init_label(mercury__bytecode_gen__map_vars_2_3_0_i4);
	init_label(mercury__bytecode_gen__map_vars_2_3_0_i5);
	init_label(mercury__bytecode_gen__map_vars_2_3_0_i1002);
BEGIN_CODE

/* code for predicate 'bytecode_gen__map_vars_2'/3 in mode 0 */
Define_static(mercury__bytecode_gen__map_vars_2_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__bytecode_gen__map_vars_2_3_0_i1002);
	incr_sp_push_msg(3, "bytecode_gen__map_vars_2");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) r1;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__bytecode_gen__map_vars_2_3_0_i4,
		STATIC(mercury__bytecode_gen__map_vars_2_3_0));
	}
Define_label(mercury__bytecode_gen__map_vars_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_vars_2_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	localcall(mercury__bytecode_gen__map_vars_2_3_0,
		LABEL(mercury__bytecode_gen__map_vars_2_3_0_i5),
		STATIC(mercury__bytecode_gen__map_vars_2_3_0));
Define_label(mercury__bytecode_gen__map_vars_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_gen__map_vars_2_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__bytecode_gen__map_vars_2_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__bytecode_gen_module19)
	init_entry(mercury__bytecode_gen__map_var_3_0);
BEGIN_CODE

/* code for predicate 'bytecode_gen__map_var'/3 in mode 0 */
Define_static(mercury__bytecode_gen__map_var_3_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		STATIC(mercury__bytecode_gen__map_var_3_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__bytecode_gen_bunch_0(void)
{
	mercury__bytecode_gen_module0();
	mercury__bytecode_gen_module1();
	mercury__bytecode_gen_module2();
	mercury__bytecode_gen_module3();
	mercury__bytecode_gen_module4();
	mercury__bytecode_gen_module5();
	mercury__bytecode_gen_module6();
	mercury__bytecode_gen_module7();
	mercury__bytecode_gen_module8();
	mercury__bytecode_gen_module9();
	mercury__bytecode_gen_module10();
	mercury__bytecode_gen_module11();
	mercury__bytecode_gen_module12();
	mercury__bytecode_gen_module13();
	mercury__bytecode_gen_module14();
	mercury__bytecode_gen_module15();
	mercury__bytecode_gen_module16();
	mercury__bytecode_gen_module17();
	mercury__bytecode_gen_module18();
	mercury__bytecode_gen_module19();
}

#endif

void mercury__bytecode_gen__init(void); /* suppress gcc warning */
void mercury__bytecode_gen__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__bytecode_gen_bunch_0();
#endif
}
