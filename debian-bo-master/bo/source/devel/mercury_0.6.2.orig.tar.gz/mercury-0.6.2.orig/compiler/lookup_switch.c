/*
** Automatically generated from `lookup_switch.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__lookup_switch__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i2);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i3);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i4);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i5);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i6);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i7);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i8);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i9);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i10);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i11);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i12);
Declare_static(mercury__lookup_switch__LambdaGoal__1_5_0);
Declare_label(mercury__lookup_switch__LambdaGoal__1_5_0_i1);
Declare_label(mercury__lookup_switch__LambdaGoal__1_5_0_i2);
Declare_label(mercury__lookup_switch__LambdaGoal__1_5_0_i3);
Declare_label(mercury__lookup_switch__LambdaGoal__1_5_0_i4);
Define_extern_entry(mercury__lookup_switch__is_lookup_switch_15_0);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i2);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i3);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i4);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i5);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i8);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i10);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i11);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i13);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i17);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i18);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i19);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i22);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i24);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i21);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i14);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i26);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i27);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i30);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i29);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i32);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i33);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i34);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i35);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i36);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i37);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i38);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i1);
Define_extern_entry(mercury__lookup_switch__generate_12_0);
Declare_label(mercury__lookup_switch__generate_12_0_i2);
Declare_label(mercury__lookup_switch__generate_12_0_i3);
Declare_label(mercury__lookup_switch__generate_12_0_i6);
Declare_label(mercury__lookup_switch__generate_12_0_i8);
Declare_label(mercury__lookup_switch__generate_12_0_i9);
Declare_label(mercury__lookup_switch__generate_12_0_i7);
Declare_label(mercury__lookup_switch__generate_12_0_i11);
Declare_label(mercury__lookup_switch__generate_12_0_i12);
Declare_label(mercury__lookup_switch__generate_12_0_i10);
Declare_label(mercury__lookup_switch__generate_12_0_i13);
Declare_label(mercury__lookup_switch__generate_12_0_i14);
Declare_label(mercury__lookup_switch__generate_12_0_i15);
Declare_label(mercury__lookup_switch__generate_12_0_i18);
Declare_label(mercury__lookup_switch__generate_12_0_i17);
Declare_label(mercury__lookup_switch__generate_12_0_i19);
Declare_label(mercury__lookup_switch__generate_12_0_i16);
Declare_label(mercury__lookup_switch__generate_12_0_i20);
Declare_static(mercury__lookup_switch__generate_constants_7_0);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i1001);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i5);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i6);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i7);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i8);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i10);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i12);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i13);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i1);
Declare_static(mercury__lookup_switch__code_is_empty_1_0);
Declare_label(mercury__lookup_switch__code_is_empty_1_0_i5);
Declare_label(mercury__lookup_switch__code_is_empty_1_0_i1004);
Declare_label(mercury__lookup_switch__code_is_empty_1_0_i1005);
Declare_label(mercury__lookup_switch__code_is_empty_1_0_i1);
Declare_static(mercury__lookup_switch__get_case_rvals_4_0);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i1001);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i4);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i5);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i7);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i8);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i9);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i10);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i12);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i1);
Declare_static(mercury__lookup_switch__rval_is_constant_2_0);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1012);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i9);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i8);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i10);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i13);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1011);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1010);
Declare_static(mercury__lookup_switch__rvals_are_constant_2_0);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i5);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i1004);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i1005);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i1);
Declare_static(mercury__lookup_switch__generate_bit_vec_2_5_0);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i6);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i9);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i1003);
Declare_static(mercury__lookup_switch__generate_bit_vec_args_3_0);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i7);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i1);
Declare_static(mercury__lookup_switch__generate_terms_2_5_0);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i4);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i5);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i6);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i7);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i8);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i1004);
Declare_static(mercury__lookup_switch__construct_args_3_0);
Declare_label(mercury__lookup_switch__construct_args_3_0_i6);
Declare_label(mercury__lookup_switch__construct_args_3_0_i2);
Declare_label(mercury__lookup_switch__construct_args_3_0_i4);
Declare_label(mercury__lookup_switch__construct_args_3_0_i7);
Declare_label(mercury__lookup_switch__construct_args_3_0_i1);
Declare_static(mercury__lookup_switch__rearrange_vals_5_0);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i4);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i5);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i1002);
Declare_static(mercury__lookup_switch__rearrange_vals_2_4_0);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i6);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i9);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i1006);
Define_extern_entry(mercury____Unify___lookup_switch__case_consts_0_0);
Define_extern_entry(mercury____Index___lookup_switch__case_consts_0_0);
Define_extern_entry(mercury____Compare___lookup_switch__case_consts_0_0);
Define_extern_entry(mercury____Unify___lookup_switch__rval_map_0_0);
Define_extern_entry(mercury____Index___lookup_switch__rval_map_0_0);
Define_extern_entry(mercury____Compare___lookup_switch__rval_map_0_0);

extern Word * mercury_data_lookup_switch__base_type_layout_case_consts_0[];
Word * mercury_data_lookup_switch__base_type_info_case_consts_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___lookup_switch__case_consts_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___lookup_switch__case_consts_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___lookup_switch__case_consts_0_0),
	(Word *) (Integer) mercury_data_lookup_switch__base_type_layout_case_consts_0
};

extern Word * mercury_data_lookup_switch__base_type_layout_rval_map_0[];
Word * mercury_data_lookup_switch__base_type_info_rval_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___lookup_switch__rval_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___lookup_switch__rval_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___lookup_switch__rval_map_0_0),
	(Word *) (Integer) mercury_data_lookup_switch__base_type_layout_rval_map_0
};

extern Word * mercury_data_lookup_switch__common_14[];
Word * mercury_data_lookup_switch__base_type_layout_rval_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_14)
};

extern Word * mercury_data_lookup_switch__common_16[];
Word * mercury_data_lookup_switch__base_type_layout_case_consts_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_16)
};

Word mercury_data_lookup_switch__common_0[] = {
	((Integer) 1)
};

Word * mercury_data_lookup_switch__common_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_0)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data___base_type_info_int_0[];
extern Word * mercury_data_llds__base_type_info_rval_0[];
Word * mercury_data_lookup_switch__common_2[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data_llds__base_type_info_rval_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_lookup_switch__common_3[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_2)
};

Word * mercury_data_lookup_switch__common_4[] = {
	(Word *) string_const("lookup switch", 13)
};

Word * mercury_data_lookup_switch__common_5[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_4),
	(Word *) string_const("", 0)
};

Word * mercury_data_lookup_switch__common_6[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_lookup_switch__common_7[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_6)
};

Word mercury_data_lookup_switch__common_8[] = {
	((Integer) 0)
};

Word * mercury_data_lookup_switch__common_9[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_8)
};

Word * mercury_data_lookup_switch__common_10[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_9)
};

Word * mercury_data_lookup_switch__common_11[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_llds__base_type_info_rval_0
};

Word * mercury_data_lookup_switch__common_12[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_11)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_lookup_switch__common_13[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3)
};

Word * mercury_data_lookup_switch__common_14[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_13)
};

Word * mercury_data_lookup_switch__common_15[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_12)
};

Word * mercury_data_lookup_switch__common_16[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_15)
};

BEGIN_MODULE(mercury__lookup_switch_module0)
	init_entry(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i2);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i3);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i4);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i5);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i6);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i7);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i8);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i9);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i10);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i11);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i12);
BEGIN_CODE

/* code for predicate 'lookup_switch__generate_bitvec_test__ua10000'/7 in mode 0 */
Define_static(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0);
	incr_sp_push_msg(6, "lookup_switch__generate_bitvec_test__ua10000");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i2,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i3,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i3);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	detstackvar(5) = (Integer) r2;
	{
	Declare_entry(mercury__globals__get_options_2_0);
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i4,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r3 = ((Integer) 58);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i5,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i6,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i7,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__lookup_switch__generate_bit_vec_args_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i8,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i9,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	tag_incr_hp(r3, mktag(2), ((Integer) 4));
	field(mktag(2), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	field(mktag(2), (Integer) r3, ((Integer) 3)) = (Integer) r1;
	r1 = (Integer) r2;
	field(mktag(2), (Integer) r3, ((Integer) 2)) = ((Integer) 1);
	field(mktag(2), (Integer) r3, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i10,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__globals__get_options_2_0);
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i11,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i11);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r3 = ((Integer) 58);
	{
	Declare_entry(mercury__getopt__lookup_int_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i12,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 7);
	tag_incr_hp(r3, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r3, ((Integer) 1)) = ((Integer) 5);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) mkword(mktag(3), (Integer) mercury_data_lookup_switch__common_1);
	tag_incr_hp(r4, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = ((Integer) 4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(3), (Integer) r3, ((Integer) 3)) = (Integer) r4;
	field(mktag(3), (Integer) r4, ((Integer) 3)) = (Integer) r5;
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	tag_incr_hp(r4, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r4, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r4, ((Integer) 1)) = ((Integer) 0);
	field(mktag(3), (Integer) r4, ((Integer) 2)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 3);
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = ((Integer) 6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r6, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r6, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(3), (Integer) r4, ((Integer) 3)) = (Integer) r5;
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) r6;
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__code_info__generate_test_and_fail_4_0);
	tailcall(ENTRY(mercury__code_info__generate_test_and_fail_4_0),
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module1)
	init_entry(mercury__lookup_switch__LambdaGoal__1_5_0);
	init_label(mercury__lookup_switch__LambdaGoal__1_5_0_i1);
	init_label(mercury__lookup_switch__LambdaGoal__1_5_0_i2);
	init_label(mercury__lookup_switch__LambdaGoal__1_5_0_i3);
	init_label(mercury__lookup_switch__LambdaGoal__1_5_0_i4);
BEGIN_CODE

/* code for predicate 'lookup_switch__LambdaGoal__1'/5 in mode 0 */
Define_static(mercury__lookup_switch__LambdaGoal__1_5_0);
	{
	Declare_entry(do_fail);
	mkframe("lookup_switch__LambdaGoal__1/5", 5, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r1;
	framevar(1) = (Integer) r2;
	framevar(2) = (Integer) r4;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__set__member_2_1);
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__lookup_switch__LambdaGoal__1_5_0_i1,
		STATIC(mercury__lookup_switch__LambdaGoal__1_5_0));
	}
Define_label(mercury__lookup_switch__LambdaGoal__1_5_0_i1);
	update_prof_current_proc(LABEL(mercury__lookup_switch__LambdaGoal__1_5_0));
	r2 = (Integer) r1;
	framevar(3) = (Integer) r1;
	r1 = (Integer) framevar(0);
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__lookup_switch__LambdaGoal__1_5_0_i2,
		STATIC(mercury__lookup_switch__LambdaGoal__1_5_0));
	}
Define_label(mercury__lookup_switch__LambdaGoal__1_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__LambdaGoal__1_5_0));
	framevar(4) = (Integer) r1;
	r1 = (Integer) framevar(2);
	r2 = (Integer) framevar(3);
	{
	Declare_entry(mercury__instmap__lookup_var_3_0);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__lookup_switch__LambdaGoal__1_5_0_i3,
		STATIC(mercury__lookup_switch__LambdaGoal__1_5_0));
	}
Define_label(mercury__lookup_switch__LambdaGoal__1_5_0_i3);
	update_prof_current_proc(LABEL(mercury__lookup_switch__LambdaGoal__1_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) framevar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) framevar(4);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__mode_util__mode_is_output_2_0);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__lookup_switch__LambdaGoal__1_5_0_i4,
		STATIC(mercury__lookup_switch__LambdaGoal__1_5_0));
	}
Define_label(mercury__lookup_switch__LambdaGoal__1_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__LambdaGoal__1_5_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(3);
	succeed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module2)
	init_entry(mercury__lookup_switch__is_lookup_switch_15_0);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i2);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i3);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i4);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i5);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i8);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i10);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i11);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i13);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i17);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i18);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i19);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i22);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i24);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i21);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i14);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i26);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i27);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i30);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i29);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i32);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i33);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i34);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i35);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i36);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i37);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i38);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i1);
BEGIN_CODE

/* code for predicate 'lookup_switch__is_lookup_switch'/15 in mode 0 */
Define_entry(mercury__lookup_switch__is_lookup_switch_15_0);
	incr_sp_push_msg(16, "lookup_switch__is_lookup_switch");
	detstackvar(16) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r7;
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i2,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	detstackvar(9) = (Integer) r2;
	{
	Declare_entry(mercury__globals__get_options_2_0);
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i3,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i3);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r3 = ((Integer) 112);
	{
	Declare_entry(mercury__getopt__lookup_bool_option_3_0);
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i4,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	{
	extern Word * mercury_data_switch_gen__base_type_info_extended_case_0[];
	r1 = (Integer) mercury_data_switch_gen__base_type_info_extended_case_0;
	}
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i5,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	tempr2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0)), ((Integer) 1));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r3 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	detstackvar(10) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	{
	extern Word * mercury_data_switch_gen__base_type_info_extended_case_0[];
	r1 = (Integer) mercury_data_switch_gen__base_type_info_extended_case_0;
	}
	r2 = (Integer) tempr1;
	{
	Declare_entry(mercury__list__index1_det_3_0);
	call_localret(ENTRY(mercury__list__index1_det_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i8,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	r2 = (((Integer) tempr2 - (Integer) detstackvar(10)) + ((Integer) 1));
	detstackvar(11) = (Integer) tempr2;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__dense_switch__calc_density_3_0);
	call_localret(ENTRY(mercury__dense_switch__calc_density_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i10,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (((Integer) r1 <= (Integer) detstackvar(5)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r1 = (Integer) detstackvar(8);
	if (((Integer) detstackvar(7) != (Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i11);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = ((Integer) 1);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i13);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i11);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = ((Integer) 0);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(10);
	r11 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(9);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i13);
	if (((Integer) r5 != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i14);
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r11;
	{
	Declare_entry(mercury__code_info__variable_type_4_0);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i17,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i17);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i18,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i18);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	detstackvar(12) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__type_util__classify_type_3_0);
	call_localret(ENTRY(mercury__type_util__classify_type_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i19,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i19);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__dense_switch__type_range_5_0);
	call_localret(ENTRY(mercury__dense_switch__type_range_5_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i22,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i22);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i21);
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	detstackvar(7) = (Integer) r3;
	{
	Declare_entry(mercury__dense_switch__calc_density_3_0);
	call_localret(ENTRY(mercury__dense_switch__calc_density_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i24,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i24);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (((Integer) r1 <= (Integer) detstackvar(5)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i21);
	r2 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = ((Integer) 0);
	r5 = ((Integer) detstackvar(1) - ((Integer) 1));
	r6 = ((Integer) 1);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i26);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i21);
	r2 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(10);
	r5 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i26);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i14);
	r1 = (Integer) r4;
	r6 = (Integer) r5;
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r7;
	r7 = (Integer) r8;
	r8 = (Integer) tempr1;
	r4 = (Integer) r10;
	r5 = (Integer) r11;
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i26);
	detstackvar(2) = (Integer) r2;
	detstackvar(6) = (Integer) r3;
	detstackvar(1) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i27,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i27);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	detstackvar(14) = (Integer) r1;
	{
	Declare_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_unreachable_1_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i30,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i30);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i29);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i37);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i29);
	r1 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__code_info__get_instmap_3_0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i32,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i32);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_module_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i33,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i33);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	detstackvar(9) = (Integer) r2;
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i34,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i34);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = (Integer) detstackvar(14);
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i35,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i35);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r2, ((Integer) 5)) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) STATIC(mercury__lookup_switch__LambdaGoal__1_5_0);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = ((Integer) 4);
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__std_util__solutions_2_1);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lookup_switch__is_lookup_switch_15_0_i36,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i36);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(9);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i37);
	detstackvar(1) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r2;
	call_localret(STATIC(mercury__lookup_switch__generate_constants_7_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i38,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i38);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r7 = (Integer) r2;
	r8 = (Integer) r3;
	r9 = (Integer) r4;
	r1 = TRUE;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(8);
	r6 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	proceed();
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module3)
	init_entry(mercury__lookup_switch__generate_12_0);
	init_label(mercury__lookup_switch__generate_12_0_i2);
	init_label(mercury__lookup_switch__generate_12_0_i3);
	init_label(mercury__lookup_switch__generate_12_0_i6);
	init_label(mercury__lookup_switch__generate_12_0_i8);
	init_label(mercury__lookup_switch__generate_12_0_i9);
	init_label(mercury__lookup_switch__generate_12_0_i7);
	init_label(mercury__lookup_switch__generate_12_0_i11);
	init_label(mercury__lookup_switch__generate_12_0_i12);
	init_label(mercury__lookup_switch__generate_12_0_i10);
	init_label(mercury__lookup_switch__generate_12_0_i13);
	init_label(mercury__lookup_switch__generate_12_0_i14);
	init_label(mercury__lookup_switch__generate_12_0_i15);
	init_label(mercury__lookup_switch__generate_12_0_i18);
	init_label(mercury__lookup_switch__generate_12_0_i17);
	init_label(mercury__lookup_switch__generate_12_0_i19);
	init_label(mercury__lookup_switch__generate_12_0_i16);
	init_label(mercury__lookup_switch__generate_12_0_i20);
BEGIN_CODE

/* code for predicate 'lookup_switch__generate'/12 in mode 0 */
Define_entry(mercury__lookup_switch__generate_12_0);
	incr_sp_push_msg(11, "lookup_switch__generate");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	r2 = (Integer) r10;
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__lookup_switch__generate_12_0_i2,
		ENTRY(mercury__lookup_switch__generate_12_0));
	}
Define_label(mercury__lookup_switch__generate_12_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__generate_12_0_i3);
	r10 = (Integer) r1;
	r11 = (Integer) r2;
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	GOTO_LABEL(mercury__lookup_switch__generate_12_0_i6);
Define_label(mercury__lookup_switch__generate_12_0_i3);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) r1;
	r12 = (Integer) r3;
	tag_incr_hp(r11, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r11, ((Integer) 2)) = (Integer) r2;
	field(mktag(3), (Integer) r11, ((Integer) 1)) = ((Integer) 1);
	field(mktag(3), (Integer) r11, ((Integer) 0)) = ((Integer) 3);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r13, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r13, ((Integer) 0)) = ((Integer) 1);
	r2 = (Integer) r12;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(3), (Integer) r11, ((Integer) 3)) = (Integer) r13;
	field(mktag(3), (Integer) r13, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__lookup_switch__generate_12_0_i6);
	if (((Integer) r6 == ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__generate_12_0_i8);
	r5 = (Integer) r1;
	r6 = (Integer) r7;
	r7 = (Integer) r8;
	{
	Word tempr1;
	tempr1 = (Integer) r4;
	r4 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	r8 = (Integer) r9;
	r9 = (Integer) r10;
	r1 = (Integer) r11;
	r10 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__lookup_switch__generate_12_0_i7);
	}
Define_label(mercury__lookup_switch__generate_12_0_i8);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r10;
	detstackvar(5) = (Integer) r11;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	tag_incr_hp(r1, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 23);
	tag_incr_hp(r3, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r3, ((Integer) 1)) = ((Integer) 6);
	field(mktag(3), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r3, ((Integer) 2)) = (Integer) r11;
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	tag_incr_hp(r12, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r12, ((Integer) 0)) = ((Integer) 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(3), (Integer) r12, ((Integer) 1)) = (Integer) r3;
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) r12;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = ((Integer) r5 - (Integer) r4);
	{
	Declare_entry(mercury__code_info__generate_test_and_fail_4_0);
	call_localret(ENTRY(mercury__code_info__generate_test_and_fail_4_0),
		mercury__lookup_switch__generate_12_0_i9,
		ENTRY(mercury__lookup_switch__generate_12_0));
	}
Define_label(mercury__lookup_switch__generate_12_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r4 = (Integer) r2;
	r10 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(4);
Define_label(mercury__lookup_switch__generate_12_0_i7);
	if (((Integer) r6 == ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__generate_12_0_i11);
	r6 = (Integer) r7;
	r12 = (Integer) r4;
	r7 = (Integer) r8;
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r5;
	r5 = (Integer) tempr1;
	r8 = (Integer) r9;
	r4 = (Integer) r2;
	r9 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	r11 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__lookup_switch__generate_12_0_i10);
	}
Define_label(mercury__lookup_switch__generate_12_0_i11);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r10;
	call_localret(STATIC(mercury__lookup_switch__generate_bitvec_test__ua10000_7_0),
		mercury__lookup_switch__generate_12_0_i12,
		ENTRY(mercury__lookup_switch__generate_12_0));
Define_label(mercury__lookup_switch__generate_12_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(4);
	r9 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(6);
	r11 = (Integer) r1;
	r12 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
Define_label(mercury__lookup_switch__generate_12_0_i10);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(8) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	detstackvar(5) = (Integer) r9;
	detstackvar(6) = (Integer) r10;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r12;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lookup_switch__generate_12_0_i13,
		ENTRY(mercury__lookup_switch__generate_12_0));
	}
Define_label(mercury__lookup_switch__generate_12_0_i13);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__lookup_switch__rearrange_vals_5_0),
		mercury__lookup_switch__generate_12_0_i14,
		ENTRY(mercury__lookup_switch__generate_12_0));
Define_label(mercury__lookup_switch__generate_12_0_i14);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(10);
	call_localret(STATIC(mercury__lookup_switch__generate_terms_2_5_0),
		mercury__lookup_switch__generate_12_0_i15,
		ENTRY(mercury__lookup_switch__generate_12_0));
Define_label(mercury__lookup_switch__generate_12_0_i15);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r3 = (Integer) detstackvar(7);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__generate_12_0_i17);
	r2 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__code_info__set_liveness_info_3_0);
	call_localret(ENTRY(mercury__code_info__set_liveness_info_3_0),
		mercury__lookup_switch__generate_12_0_i18,
		ENTRY(mercury__lookup_switch__generate_12_0));
	}
Define_label(mercury__lookup_switch__generate_12_0_i18);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(9);
	r3 = (Integer) r1;
	r1 = ((Integer) 0);
	GOTO_LABEL(mercury__lookup_switch__generate_12_0_i16);
Define_label(mercury__lookup_switch__generate_12_0_i17);
	r1 = string_const("lookup_switch__generate: no liveness!", 37);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lookup_switch__generate_12_0_i19,
		ENTRY(mercury__lookup_switch__generate_12_0));
	}
Define_label(mercury__lookup_switch__generate_12_0_i19);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(9);
Define_label(mercury__lookup_switch__generate_12_0_i16);
	detstackvar(4) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(9) = (Integer) r6;
	{
	Declare_entry(mercury__code_info__generate_branch_end_5_0);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_5_0),
		mercury__lookup_switch__generate_12_0_i20,
		ENTRY(mercury__lookup_switch__generate_12_0));
	}
Define_label(mercury__lookup_switch__generate_12_0_i20);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_12_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_7);
	tag_incr_hp(r4, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(6);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r5, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(2), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module4)
	init_entry(mercury__lookup_switch__generate_constants_7_0);
	init_label(mercury__lookup_switch__generate_constants_7_0_i1001);
	init_label(mercury__lookup_switch__generate_constants_7_0_i5);
	init_label(mercury__lookup_switch__generate_constants_7_0_i6);
	init_label(mercury__lookup_switch__generate_constants_7_0_i7);
	init_label(mercury__lookup_switch__generate_constants_7_0_i8);
	init_label(mercury__lookup_switch__generate_constants_7_0_i10);
	init_label(mercury__lookup_switch__generate_constants_7_0_i12);
	init_label(mercury__lookup_switch__generate_constants_7_0_i13);
	init_label(mercury__lookup_switch__generate_constants_7_0_i1);
BEGIN_CODE

/* code for predicate 'lookup_switch__generate_constants'/7 in mode 0 */
Define_static(mercury__lookup_switch__generate_constants_7_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1001);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__lookup_switch__generate_constants_7_0_i1001);
	incr_sp_push_msg(8, "lookup_switch__generate_constants");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tempr2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) tempr2, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	r1 = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__code_info__grab_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__grab_code_info_3_0),
		mercury__lookup_switch__generate_constants_7_0_i5,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
	}
	}
Define_label(mercury__lookup_switch__generate_constants_7_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	r3 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_gen__generate_goal_5_0);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__lookup_switch__generate_constants_7_0_i6,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
	}
Define_label(mercury__lookup_switch__generate_constants_7_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_liveness_info_3_0);
	call_localret(ENTRY(mercury__code_info__get_liveness_info_3_0),
		mercury__lookup_switch__generate_constants_7_0_i7,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
	}
Define_label(mercury__lookup_switch__generate_constants_7_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r3;
	detstackvar(7) = (Integer) r2;
	call_localret(STATIC(mercury__lookup_switch__code_is_empty_1_0),
		mercury__lookup_switch__generate_constants_7_0_i8,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__lookup_switch__get_case_rvals_4_0),
		mercury__lookup_switch__generate_constants_7_0_i10,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = (Integer) detstackvar(5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(5) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__code_info__slap_code_info_3_0);
	call_localret(ENTRY(mercury__code_info__slap_code_info_3_0),
		mercury__lookup_switch__generate_constants_7_0_i12,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
	}
	}
Define_label(mercury__lookup_switch__generate_constants_7_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__lookup_switch__generate_constants_7_0,
		LABEL(mercury__lookup_switch__generate_constants_7_0_i13),
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i13);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	r3 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module5)
	init_entry(mercury__lookup_switch__code_is_empty_1_0);
	init_label(mercury__lookup_switch__code_is_empty_1_0_i5);
	init_label(mercury__lookup_switch__code_is_empty_1_0_i1004);
	init_label(mercury__lookup_switch__code_is_empty_1_0_i1005);
	init_label(mercury__lookup_switch__code_is_empty_1_0_i1);
BEGIN_CODE

/* code for predicate 'lookup_switch__code_is_empty'/1 in mode 0 */
Define_static(mercury__lookup_switch__code_is_empty_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__code_is_empty_1_0_i1004);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__lookup_switch__code_is_empty_1_0_i1005);
	incr_sp_push_msg(2, "lookup_switch__code_is_empty");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	localcall(mercury__lookup_switch__code_is_empty_1_0,
		LABEL(mercury__lookup_switch__code_is_empty_1_0_i5),
		STATIC(mercury__lookup_switch__code_is_empty_1_0));
Define_label(mercury__lookup_switch__code_is_empty_1_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__code_is_empty_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__code_is_empty_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__lookup_switch__code_is_empty_1_0,
		STATIC(mercury__lookup_switch__code_is_empty_1_0));
Define_label(mercury__lookup_switch__code_is_empty_1_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__lookup_switch__code_is_empty_1_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury__lookup_switch__code_is_empty_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module6)
	init_entry(mercury__lookup_switch__get_case_rvals_4_0);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i1001);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i4);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i5);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i7);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i8);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i9);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i10);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i12);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i1);
BEGIN_CODE

/* code for predicate 'lookup_switch__get_case_rvals'/4 in mode 0 */
Define_static(mercury__lookup_switch__get_case_rvals_4_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1001);
	r3 = (Integer) r2;
	r1 = TRUE;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i1001);
	incr_sp_push_msg(4, "lookup_switch__get_case_rvals");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__code_info__produce_variable_5_0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__lookup_switch__get_case_rvals_4_0_i4,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
	}
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	call_localret(STATIC(mercury__lookup_switch__code_is_empty_1_0),
		mercury__lookup_switch__get_case_rvals_4_0_i5,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__code_info__get_globals_3_0);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__get_case_rvals_4_0_i7,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
	}
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__globals__get_options_2_0);
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__get_case_rvals_4_0_i8,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
	}
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	{
	Declare_entry(mercury__exprn_aux__init_exprn_opts_2_0);
	call_localret(ENTRY(mercury__exprn_aux__init_exprn_opts_2_0),
		mercury__lookup_switch__get_case_rvals_4_0_i9,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
	}
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__lookup_switch__rval_is_constant_2_0),
		mercury__lookup_switch__get_case_rvals_4_0_i10,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	localcall(mercury__lookup_switch__get_case_rvals_4_0,
		LABEL(mercury__lookup_switch__get_case_rvals_4_0_i12),
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module7)
	init_entry(mercury__lookup_switch__rval_is_constant_2_0);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1012);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i9);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i8);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i10);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i13);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1011);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1010);
BEGIN_CODE

/* code for predicate 'lookup_switch__rval_is_constant'/2 in mode 0 */
Define_static(mercury__lookup_switch__rval_is_constant_2_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1011);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1012);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localtailcall(mercury__lookup_switch__rval_is_constant_2_0,
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1012);
	incr_sp_push_msg(3, "lookup_switch__rval_is_constant");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__exprn_aux__const_is_constant_3_0);
	call_localret(ENTRY(mercury__exprn_aux__const_is_constant_3_0),
		mercury__lookup_switch__rval_is_constant_2_0_i9,
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
	}
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rval_is_constant_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i8);
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__lookup_switch__rval_is_constant_2_0,
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i10);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	localcall(mercury__lookup_switch__rval_is_constant_2_0,
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i13),
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i13);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rval_is_constant_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__lookup_switch__rval_is_constant_2_0,
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1011);
	incr_sp_push_msg(3, "lookup_switch__rval_is_constant");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 2)) != ((Integer) 0)))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1010);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__lookup_switch__rvals_are_constant_2_0),
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1010);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module8)
	init_entry(mercury__lookup_switch__rvals_are_constant_2_0);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i5);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i1004);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i1005);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i1);
BEGIN_CODE

/* code for predicate 'lookup_switch__rvals_are_constant'/2 in mode 0 */
Define_static(mercury__lookup_switch__rvals_are_constant_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i1004);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i1005);
	incr_sp_push_msg(3, "lookup_switch__rvals_are_constant");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__lookup_switch__rval_is_constant_2_0),
		mercury__lookup_switch__rvals_are_constant_2_0_i5,
		STATIC(mercury__lookup_switch__rvals_are_constant_2_0));
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rvals_are_constant_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__lookup_switch__rvals_are_constant_2_0,
		STATIC(mercury__lookup_switch__rvals_are_constant_2_0));
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module9)
	init_entry(mercury__lookup_switch__generate_bit_vec_2_5_0);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i6);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i9);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i1003);
BEGIN_CODE

/* code for predicate 'generate_bit_vec_2'/5 in mode 0 */
Define_static(mercury__lookup_switch__generate_bit_vec_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0_i1003);
	incr_sp_push_msg(7, "generate_bit_vec_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1, tempr2;
	tempr2 = ((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)) - (Integer) r2);
	tempr1 = ((Integer) tempr2 / (Integer) r3);
	detstackvar(5) = (Integer) tempr1;
	detstackvar(3) = (Integer) r4;
	r3 = (Integer) r4;
	r4 = (Integer) tempr1;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(6) = ((Integer) tempr2 % (Integer) detstackvar(2));
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i6,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
	}
	}
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r8 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = ((Integer) r2 | (((Integer) 1) << (Integer) detstackvar(6)));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r8 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (((Integer) 1) << (Integer) detstackvar(6));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
	detstackvar(1) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i9,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
	}
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__lookup_switch__generate_bit_vec_2_5_0,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i1003);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module10)
	init_entry(mercury__lookup_switch__generate_bit_vec_args_3_0);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i7);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i1);
BEGIN_CODE

/* code for predicate 'generate_bit_vec_args'/3 in mode 0 */
Define_static(mercury__lookup_switch__generate_bit_vec_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i1);
	r9 = (Integer) sp;
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
	incr_sp_push_msg(1, "generate_bit_vec_args");
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if (((Integer) r2 >= (Integer) r5))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
	r2 = ((Integer) r2 + ((Integer) 1));
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_10);
	GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
	r1 = (Integer) r3;
	r2 = ((Integer) r2 + ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	tag_incr_hp(r7, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r7, ((Integer) 0)) = ((Integer) 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(3), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r7;
	}
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
	detstackvar(1) = (Integer) r3;
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i7);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r9))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module11)
	init_entry(mercury__lookup_switch__generate_terms_2_5_0);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i4);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i5);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i6);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i7);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i8);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i1004);
BEGIN_CODE

/* code for predicate 'lookup_switch__generate_terms_2'/5 in mode 0 */
Define_static(mercury__lookup_switch__generate_terms_2_5_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__generate_terms_2_5_0_i1004);
	incr_sp_push_msg(6, "lookup_switch__generate_terms_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__lookup_switch__generate_terms_2_5_0_i4,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
	}
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_2);
	{
	Declare_entry(mercury__list__sort_2_0);
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__lookup_switch__generate_terms_2_5_0_i5,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
	}
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__lookup_switch__construct_args_3_0),
		mercury__lookup_switch__generate_terms_2_5_0_i6,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__code_info__get_next_cell_number_3_0);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__lookup_switch__generate_terms_2_5_0_i7,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
	}
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	tag_incr_hp(r5, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = ((Integer) 0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 4));
	field(mktag(3), (Integer) r5, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	r3 = (Integer) r4;
	field(mktag(3), (Integer) r5, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) tempr1, ((Integer) 2)) = ((Integer) 1);
	field(mktag(2), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__code_info__cache_expression_4_0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__lookup_switch__generate_terms_2_5_0_i8,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
	}
	}
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__lookup_switch__generate_terms_2_5_0,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i1004);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module12)
	init_entry(mercury__lookup_switch__construct_args_3_0);
	init_label(mercury__lookup_switch__construct_args_3_0_i6);
	init_label(mercury__lookup_switch__construct_args_3_0_i2);
	init_label(mercury__lookup_switch__construct_args_3_0_i4);
	init_label(mercury__lookup_switch__construct_args_3_0_i7);
	init_label(mercury__lookup_switch__construct_args_3_0_i1);
BEGIN_CODE

/* code for predicate 'construct_args'/3 in mode 0 */
Define_static(mercury__lookup_switch__construct_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i1);
	r7 = (Integer) sp;
Define_label(mercury__lookup_switch__construct_args_3_0_i6);
	incr_sp_push_msg(1, "construct_args");
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if (((Integer) r2 >= (Integer) r5))
		GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i2);
	r2 = ((Integer) r2 + ((Integer) 1));
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_lookup_switch__common_10);
	GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i4);
Define_label(mercury__lookup_switch__construct_args_3_0_i2);
	r1 = (Integer) r3;
	r2 = ((Integer) r2 + ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
Define_label(mercury__lookup_switch__construct_args_3_0_i4);
	detstackvar(1) = (Integer) r3;
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i6);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__lookup_switch__construct_args_3_0_i7);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r7))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lookup_switch__construct_args_3_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module13)
	init_entry(mercury__lookup_switch__rearrange_vals_5_0);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i4);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i5);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i1002);
BEGIN_CODE

/* code for predicate 'rearrange_vals'/5 in mode 0 */
Define_static(mercury__lookup_switch__rearrange_vals_5_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__rearrange_vals_5_0_i1002);
	incr_sp_push_msg(6, "rearrange_vals");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_llds__base_type_info_rval_0;
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__lookup_switch__rearrange_vals_5_0_i4,
		STATIC(mercury__lookup_switch__rearrange_vals_5_0));
	}
	}
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_5_0));
	r2 = ((Integer) detstackvar(4) - (Integer) detstackvar(2));
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__lookup_switch__rearrange_vals_2_4_0),
		mercury__lookup_switch__rearrange_vals_5_0_i5,
		STATIC(mercury__lookup_switch__rearrange_vals_5_0));
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__lookup_switch__rearrange_vals_5_0,
		STATIC(mercury__lookup_switch__rearrange_vals_5_0));
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module14)
	init_entry(mercury__lookup_switch__rearrange_vals_2_4_0);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i6);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i9);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i1006);
BEGIN_CODE

/* code for predicate 'rearrange_vals_2'/4 in mode 0 */
Define_static(mercury__lookup_switch__rearrange_vals_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__lookup_switch__rearrange_vals_2_4_0_i1006);
	incr_sp_push_msg(6, "rearrange_vals_2");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lookup_switch__rearrange_vals_2_4_0_i6,
		STATIC(mercury__lookup_switch__rearrange_vals_2_4_0));
	}
	}
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
	r6 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	GOTO_LABEL(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
	r6 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r1;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
	detstackvar(1) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lookup_switch__rearrange_vals_2_4_0_i9,
		STATIC(mercury__lookup_switch__rearrange_vals_2_4_0));
	}
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__lookup_switch__rearrange_vals_2_4_0,
		STATIC(mercury__lookup_switch__rearrange_vals_2_4_0));
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i1006);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module15)
	init_entry(mercury____Unify___lookup_switch__case_consts_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lookup_switch__case_consts_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_12);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___lookup_switch__case_consts_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module16)
	init_entry(mercury____Index___lookup_switch__case_consts_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lookup_switch__case_consts_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_12);
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___lookup_switch__case_consts_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module17)
	init_entry(mercury____Compare___lookup_switch__case_consts_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lookup_switch__case_consts_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_12);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___lookup_switch__case_consts_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module18)
	init_entry(mercury____Unify___lookup_switch__rval_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lookup_switch__rval_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___lookup_switch__rval_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module19)
	init_entry(mercury____Index___lookup_switch__rval_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lookup_switch__rval_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___lookup_switch__rval_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__lookup_switch_module20)
	init_entry(mercury____Compare___lookup_switch__rval_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lookup_switch__rval_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_lookup_switch__common_3);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___lookup_switch__rval_map_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__lookup_switch_bunch_0(void)
{
	mercury__lookup_switch_module0();
	mercury__lookup_switch_module1();
	mercury__lookup_switch_module2();
	mercury__lookup_switch_module3();
	mercury__lookup_switch_module4();
	mercury__lookup_switch_module5();
	mercury__lookup_switch_module6();
	mercury__lookup_switch_module7();
	mercury__lookup_switch_module8();
	mercury__lookup_switch_module9();
	mercury__lookup_switch_module10();
	mercury__lookup_switch_module11();
	mercury__lookup_switch_module12();
	mercury__lookup_switch_module13();
	mercury__lookup_switch_module14();
	mercury__lookup_switch_module15();
	mercury__lookup_switch_module16();
	mercury__lookup_switch_module17();
	mercury__lookup_switch_module18();
	mercury__lookup_switch_module19();
	mercury__lookup_switch_module20();
}

#endif

void mercury__lookup_switch__init(void); /* suppress gcc warning */
void mercury__lookup_switch__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__lookup_switch_bunch_0();
#endif
}
