/*
** Automatically generated from `mode_info.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__mode_info__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___mode_info_mode_info_0__ua10000_2_0);
Declare_static(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0);
Declare_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i2);
Declare_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i3);
Declare_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i6);
Declare_static(mercury__mode_info__mode_info_get_instvarset__ua10000_2_0);
Define_extern_entry(mercury__mode_info__mode_info_init_8_0);
Declare_label(mercury__mode_info__mode_info_init_8_0_i2);
Declare_label(mercury__mode_info__mode_info_init_8_0_i3);
Declare_label(mercury__mode_info__mode_info_init_8_0_i4);
Declare_label(mercury__mode_info__mode_info_init_8_0_i5);
Declare_label(mercury__mode_info__mode_info_init_8_0_i6);
Declare_label(mercury__mode_info__mode_info_init_8_0_i7);
Declare_label(mercury__mode_info__mode_info_init_8_0_i8);
Declare_label(mercury__mode_info__mode_info_init_8_0_i9);
Define_extern_entry(mercury__mode_info__mode_info_get_io_state_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_io_state_3_0);
Declare_label(mercury__mode_info__mode_info_set_io_state_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_get_module_info_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_module_info_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_preds_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_modes_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_insts_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_predid_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_procid_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_context_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_context_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_mode_context_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_mode_context_3_0);
Define_extern_entry(mercury__mode_info__mode_info_set_call_context_3_0);
Declare_label(mercury__mode_info__mode_info_set_call_context_3_0_i4);
Declare_label(mercury__mode_info__mode_info_set_call_context_3_0_i6);
Define_extern_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
Declare_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
Declare_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i3);
Declare_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i7);
Define_extern_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_instmap_2_0);
Define_extern_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
Declare_label(mercury__mode_info__mode_info_dcg_get_instmap_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_set_instmap_3_0);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i4);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i6);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i8);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
Define_extern_entry(mercury__mode_info__mode_info_get_locked_vars_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_locked_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_errors_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_num_errors_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_errors_3_0);
Define_extern_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i4);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i6);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i8);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i10);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i11);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i12);
Define_extern_entry(mercury__mode_info__mode_info_var_list_is_live_3_0);
Declare_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i4);
Declare_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i5);
Declare_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i1002);
Define_extern_entry(mercury__mode_info__mode_info_var_is_live_3_0);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i7);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i8);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i6);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i10);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i7);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i8);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i10);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_get_liveness_2_0);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_get_liveness_2_3_0);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i4);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i1002);
Define_extern_entry(mercury__mode_info__mode_info_get_varset_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_varset_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_instvarset_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_var_types_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_var_types_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
Declare_label(mercury__mode_info__mode_info_get_types_of_vars_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_lock_vars_3_0);
Declare_label(mercury__mode_info__mode_info_lock_vars_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_unlock_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_var_is_locked_2_0);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_var_is_locked_2_2_0);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i5);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i9);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i1003);
Define_extern_entry(mercury__mode_info__mode_info_get_delay_info_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_delay_info_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_changed_flag_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
Define_extern_entry(mercury__mode_info__mode_info_error_4_0);
Declare_label(mercury__mode_info__mode_info_error_4_0_i2);
Declare_label(mercury__mode_info__mode_info_error_4_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_add_error_3_0);
Declare_label(mercury__mode_info__mode_info_add_error_3_0_i2);
Declare_label(mercury__mode_info__mode_info_add_error_3_0_i3);
Define_extern_entry(mercury____Unify___mode_info__mode_context_0_0);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i1017);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i6);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i8);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i11);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i1014);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i1);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i1016);
Define_extern_entry(mercury____Index___mode_info__mode_context_0_0);
Declare_label(mercury____Index___mode_info__mode_context_0_0_i4);
Declare_label(mercury____Index___mode_info__mode_context_0_0_i5);
Declare_label(mercury____Index___mode_info__mode_context_0_0_i6);
Define_extern_entry(mercury____Compare___mode_info__mode_context_0_0);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i2);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i3);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i4);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i6);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i12);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i18);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i19);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i17);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i14);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i28);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i24);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i37);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i9);
Define_extern_entry(mercury____Unify___mode_info__side_0_0);
Declare_label(mercury____Unify___mode_info__side_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__side_0_0);
Define_extern_entry(mercury____Compare___mode_info__side_0_0);
Define_extern_entry(mercury____Unify___mode_info__call_context_0_0);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i1011);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i8);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i1008);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i1);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i1010);
Define_extern_entry(mercury____Index___mode_info__call_context_0_0);
Declare_label(mercury____Index___mode_info__call_context_0_0_i4);
Declare_label(mercury____Index___mode_info__call_context_0_0_i5);
Define_extern_entry(mercury____Compare___mode_info__call_context_0_0);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i2);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i3);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i4);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i6);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i12);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i15);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i1000);
Define_extern_entry(mercury____Unify___mode_info__mode_info_0_0);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i2);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i4);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i6);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i8);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i10);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i12);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i14);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i16);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i18);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i20);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i22);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i24);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__mode_info_0_0);
Define_extern_entry(mercury____Compare___mode_info__mode_info_0_0);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i4);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i5);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i3);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i10);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i16);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i22);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i28);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i34);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i40);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i46);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i52);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i58);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i64);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i70);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i76);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i82);

extern Word * mercury_data_mode_info__base_type_layout_call_context_0[];
Word * mercury_data_mode_info__base_type_info_call_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mode_info__call_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mode_info__call_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mode_info__call_context_0_0),
	(Word *) (Integer) mercury_data_mode_info__base_type_layout_call_context_0
};

extern Word * mercury_data_mode_info__base_type_layout_mode_context_0[];
Word * mercury_data_mode_info__base_type_info_mode_context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mode_info__mode_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mode_info__mode_context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mode_info__mode_context_0_0),
	(Word *) (Integer) mercury_data_mode_info__base_type_layout_mode_context_0
};

extern Word * mercury_data_mode_info__base_type_layout_mode_info_0[];
Word * mercury_data_mode_info__base_type_info_mode_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mode_info__mode_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mode_info__mode_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mode_info__mode_info_0_0),
	(Word *) (Integer) mercury_data_mode_info__base_type_layout_mode_info_0
};

extern Word * mercury_data_mode_info__base_type_layout_side_0[];
Word * mercury_data_mode_info__base_type_info_side_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mode_info__side_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mode_info__side_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mode_info__side_0_0),
	(Word *) (Integer) mercury_data_mode_info__base_type_layout_side_0
};

extern Word * mercury_data_mode_info__common_1[];
Word * mercury_data_mode_info__base_type_layout_side_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_1)
};

extern Word * mercury_data_mode_info__common_14[];
Word * mercury_data_mode_info__base_type_layout_mode_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_14),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mode_info__common_15[];
extern Word * mercury_data_mode_info__common_16[];
extern Word * mercury_data_mode_info__common_18[];
extern Word * mercury_data_mode_info__common_21[];
Word * mercury_data_mode_info__base_type_layout_mode_context_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_15),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_16),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_18),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_21)
};

extern Word * mercury_data_mode_info__common_22[];
extern Word * mercury_data_mode_info__common_23[];
extern Word * mercury_data_mode_info__common_24[];
Word * mercury_data_mode_info__base_type_layout_call_context_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_22),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_23),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mode_info__common_24),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_set__base_type_info_set_1[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
Word * mercury_data_mode_info__common_0[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0
};

Word * mercury_data_mode_info__common_1[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("left", 4),
	(Word *) string_const("right", 5)
};

extern Word * mercury_data_io__base_type_info_io__state_0[];
Word * mercury_data_mode_info__common_2[] = {
	(Word *) (Integer) mercury_data_io__base_type_info_io__state_0
};

extern Word * mercury_data_hlds_module__base_type_info_module_info_0[];
Word * mercury_data_mode_info__common_3[] = {
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_module_info_0
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_mode_info__common_4[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_mode_info__common_5[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_mode_info__common_6[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_mode_info__common_7[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

Word * mercury_data_mode_info__common_8[] = {
	(Word *) (Integer) mercury_data_mode_info__base_type_info_mode_context_0
};

extern Word * mercury_data_instmap__base_type_info_instmap_0[];
Word * mercury_data_mode_info__common_9[] = {
	(Word *) (Integer) mercury_data_instmap__base_type_info_instmap_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_mode_info__common_10[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0)
};

extern Word * mercury_data_delay_info__base_type_info_delay_info_0[];
Word * mercury_data_mode_info__common_11[] = {
	(Word *) (Integer) mercury_data_delay_info__base_type_info_delay_info_0
};

extern Word * mercury_data_mode_errors__base_type_info_mode_error_info_0[];
Word * mercury_data_mode_info__common_12[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mode_errors__base_type_info_mode_error_info_0
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_mode_info__common_13[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_mode_info__common_14[] = {
	(Word *) ((Integer) 15),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_13),
	(Word *) string_const("mode_info", 9)
};

Word * mercury_data_mode_info__common_15[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("uninitialized", 13)
};

Word * mercury_data_mode_info__common_16[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_4),
	(Word *) string_const("call", 4)
};

extern Word * mercury_data_hlds_pred__base_type_info_pred_or_func_0[];
Word * mercury_data_mode_info__common_17[] = {
	(Word *) (Integer) mercury_data_hlds_pred__base_type_info_pred_or_func_0
};

Word * mercury_data_mode_info__common_18[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_4),
	(Word *) string_const("higher_order_call", 17)
};

extern Word * mercury_data_hlds_goal__base_type_info_unify_context_0[];
Word * mercury_data_mode_info__common_19[] = {
	(Word *) (Integer) mercury_data_hlds_goal__base_type_info_unify_context_0
};

Word * mercury_data_mode_info__common_20[] = {
	(Word *) (Integer) mercury_data_mode_info__base_type_info_side_0
};

Word * mercury_data_mode_info__common_21[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_20),
	(Word *) string_const("unify", 5)
};

Word * mercury_data_mode_info__common_22[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_19),
	(Word *) string_const("unify", 5)
};

Word * mercury_data_mode_info__common_23[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_4),
	(Word *) string_const("call", 4)
};

Word * mercury_data_mode_info__common_24[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_17),
	(Word *) string_const("higher_order_call", 17)
};

BEGIN_MODULE(mercury__mode_info_module0)
	init_entry(mercury____Index___mode_info_mode_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___mode_info_mode_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___mode_info_mode_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module1)
	init_entry(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0);
	init_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i2);
	init_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i3);
	init_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i6);
BEGIN_CODE

/* code for predicate 'mode_info_unlock_vars__ua10000'/3 in mode 0 */
Define_static(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0);
	incr_sp_push_msg(2, "mode_info_unlock_vars__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_locked_vars_2_0),
		mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i2,
		STATIC(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i3);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_locked_vars_3_0),
		STATIC(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i3);
	r1 = string_const("mode_info_unlock_vars: stack is empty", 37);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i6,
		STATIC(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_locked_vars_3_0),
		STATIC(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module2)
	init_entry(mercury__mode_info__mode_info_get_instvarset__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_instvarset__ua10000'/2 in mode 0 */
Define_static(mercury__mode_info__mode_info_get_instvarset__ua10000_2_0);
	{
	Declare_entry(mercury__varset__init_1_0);
	tailcall(ENTRY(mercury__varset__init_1_0),
		STATIC(mercury__mode_info__mode_info_get_instvarset__ua10000_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module3)
	init_entry(mercury__mode_info__mode_info_init_8_0);
	init_label(mercury__mode_info__mode_info_init_8_0_i2);
	init_label(mercury__mode_info__mode_info_init_8_0_i3);
	init_label(mercury__mode_info__mode_info_init_8_0_i4);
	init_label(mercury__mode_info__mode_info_init_8_0_i5);
	init_label(mercury__mode_info__mode_info_init_8_0_i6);
	init_label(mercury__mode_info__mode_info_init_8_0_i7);
	init_label(mercury__mode_info__mode_info_init_8_0_i8);
	init_label(mercury__mode_info__mode_info_init_8_0_i9);
BEGIN_CODE

/* code for predicate 'mode_info_init'/8 in mode 0 */
Define_entry(mercury__mode_info__mode_info_init_8_0);
	incr_sp_push_msg(11, "mode_info_init");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	{
	Declare_entry(mercury__mode_errors__mode_context_init_1_0);
	call_localret(ENTRY(mercury__mode_errors__mode_context_init_1_0),
		mercury__mode_info__mode_info_init_8_0_i2,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	detstackvar(8) = (Integer) r1;
	{
	Declare_entry(mercury__delay_info__init_1_0);
	call_localret(ENTRY(mercury__delay_info__init_1_0),
		mercury__mode_info__mode_info_init_8_0_i3,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i3);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__mode_info__mode_info_init_8_0_i4,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_pred_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_pred_info_0;
	}
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__mode_info__mode_info_init_8_0_i5,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	{
	Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__mode_info__mode_info_init_8_0_i6,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	extern Word * mercury_data_hlds_pred__base_type_info_proc_info_0[];
	r2 = (Integer) mercury_data_hlds_pred__base_type_info_proc_info_0;
	}
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__mode_info__mode_info_init_8_0_i7,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i7);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	detstackvar(10) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_pred__proc_info_variables_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_variables_2_0),
		mercury__mode_info__mode_info_init_8_0_i8,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i8);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	r2 = (Integer) detstackvar(10);
	detstackvar(10) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__mode_info__mode_info_init_8_0_i9,
		ENTRY(mercury__mode_info__mode_info_init_8_0));
	}
Define_label(mercury__mode_info__mode_info_init_8_0_i9);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 14)) = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module4)
	init_entry(mercury__mode_info__mode_info_get_io_state_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_io_state'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_io_state_2_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_io__base_type_info_io__state_0;
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__mode_info__mode_info_get_io_state_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module5)
	init_entry(mercury__mode_info__mode_info_set_io_state_3_0);
	init_label(mercury__mode_info__mode_info_set_io_state_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_set_io_state'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_io_state_3_0);
	incr_sp_push_msg(15, "mode_info_set_io_state");
	detstackvar(15) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 14));
	r1 = (Integer) mercury_data_io__base_type_info_io__state_0;
	{
	Declare_entry(mercury__copy_2_0);
	call_localret(ENTRY(mercury__copy_2_0),
		mercury__mode_info__mode_info_set_io_state_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_set_io_state_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_io_state_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_io_state_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) detstackvar(14);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module6)
	init_entry(mercury__mode_info__mode_info_get_module_info_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_module_info'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module7)
	init_entry(mercury__mode_info__mode_info_set_module_info_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_module_info'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_module_info_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module8)
	init_entry(mercury__mode_info__mode_info_get_preds_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_preds'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_preds_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__module_info_preds_2_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		ENTRY(mercury__mode_info__mode_info_get_preds_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module9)
	init_entry(mercury__mode_info__mode_info_get_modes_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_modes'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_modes_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__module_info_modes_2_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_modes_2_0),
		ENTRY(mercury__mode_info__mode_info_get_modes_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module10)
	init_entry(mercury__mode_info__mode_info_get_insts_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_insts'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_insts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
	Declare_entry(mercury__hlds_module__module_info_insts_2_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_insts_2_0),
		ENTRY(mercury__mode_info__mode_info_get_insts_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module11)
	init_entry(mercury__mode_info__mode_info_get_predid_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_predid'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_predid_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module12)
	init_entry(mercury__mode_info__mode_info_get_procid_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_procid'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_procid_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module13)
	init_entry(mercury__mode_info__mode_info_get_context_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_context'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_context_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module14)
	init_entry(mercury__mode_info__mode_info_set_context_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_context_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module15)
	init_entry(mercury__mode_info__mode_info_get_mode_context_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_mode_context'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_mode_context_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module16)
	init_entry(mercury__mode_info__mode_info_set_mode_context_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_mode_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_mode_context_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module17)
	init_entry(mercury__mode_info__mode_info_set_call_context_3_0);
	init_label(mercury__mode_info__mode_info_set_call_context_3_0_i4);
	init_label(mercury__mode_info__mode_info_set_call_context_3_0_i6);
BEGIN_CODE

/* code for predicate 'mode_info_set_call_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_call_context_3_0);
	r3 = tag((Integer) r1);
	incr_sp_push_msg(1, "mode_info_set_call_context");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_context_3_0_i4);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(3), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_mode_context_3_0),
		ENTRY(mercury__mode_info__mode_info_set_call_context_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_call_context_3_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_context_3_0_i6);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_mode_context_3_0),
		ENTRY(mercury__mode_info__mode_info_set_call_context_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_call_context_3_0_i6);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_mode_context_3_0),
		ENTRY(mercury__mode_info__mode_info_set_call_context_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module18)
	init_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
	init_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
	init_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i3);
	init_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i7);
BEGIN_CODE

/* code for predicate 'mode_info_set_call_arg_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
	incr_sp_push_msg(3, "mode_info_set_call_arg_context");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_mode_context_2_0),
		mercury__mode_info__mode_info_set_call_arg_context_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_call_arg_context_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_arg_context_3_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_mode_context_3_0),
		ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i3);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_arg_context_3_0_i7);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_mode_context_3_0),
		ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i7);
	r1 = string_const("mode_info_set_call_arg_context", 30);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module19)
	init_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_unset_call_context'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_mode_context_3_0),
		ENTRY(mercury__mode_info__mode_info_unset_call_context_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module20)
	init_entry(mercury__mode_info__mode_info_get_instmap_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_instmap'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module21)
	init_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
	init_label(mercury__mode_info__mode_info_dcg_get_instmap_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_dcg_get_instmap'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
	incr_sp_push_msg(2, "mode_info_dcg_get_instmap");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__mode_info__mode_info_dcg_get_instmap_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0));
	}
Define_label(mercury__mode_info__mode_info_dcg_get_instmap_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_dcg_get_instmap_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module22)
	init_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i4);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i6);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i8);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
BEGIN_CODE

/* code for predicate 'mode_info_set_instmap'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	incr_sp_push_msg(17, "mode_info_set_instmap");
	detstackvar(17) = (Integer) succip;
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__instmap__is_unreachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__mode_info__mode_info_set_instmap_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_set_instmap_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_instmap_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
	r1 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__instmap__is_reachable_1_0);
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__mode_info__mode_info_set_instmap_3_0_i6,
		ENTRY(mercury__mode_info__mode_info_set_instmap_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_instmap_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__delay_info__bind_all_vars_2_0);
	call_localret(ENTRY(mercury__delay_info__bind_all_vars_2_0),
		mercury__mode_info__mode_info_set_instmap_3_0_i8,
		ENTRY(mercury__mode_info__mode_info_set_instmap_3_0));
	}
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i8);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_instmap_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) detstackvar(14);
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) detstackvar(16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) detstackvar(14);
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) detstackvar(16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module23)
	init_entry(mercury__mode_info__mode_info_get_locked_vars_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_locked_vars'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_locked_vars_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module24)
	init_entry(mercury__mode_info__mode_info_set_locked_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_locked_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_locked_vars_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module25)
	init_entry(mercury__mode_info__mode_info_get_errors_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_errors'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_errors_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module26)
	init_entry(mercury__mode_info__mode_info_get_num_errors_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_num_errors'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_num_errors_2_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	r1 = (Integer) mercury_data_mode_errors__base_type_info_mode_error_info_0;
	{
	Declare_entry(mercury__list__length_2_0);
	tailcall(ENTRY(mercury__list__length_2_0),
		ENTRY(mercury__mode_info__mode_info_get_num_errors_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module27)
	init_entry(mercury__mode_info__mode_info_set_errors_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_errors'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_errors_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module28)
	init_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_add_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module29)
	init_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i4);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i6);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i8);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i10);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i11);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i12);
BEGIN_CODE

/* code for predicate 'mode_info_remove_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
	r3 = (Integer) r1;
	incr_sp_push_msg(16, "mode_info_remove_live_vars");
	detstackvar(16) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) detstackvar(14);
	detstackvar(14) = (Integer) tempr1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__delete_first_3_0);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i6,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
	tag_incr_hp(r3, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r3, ((Integer) 13)) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 14)) = (Integer) detstackvar(15);
	field(mktag(0), (Integer) r3, ((Integer) 12)) = (Integer) detstackvar(14);
	field(mktag(0), (Integer) r3, ((Integer) 11)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r3, ((Integer) 10)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r3, ((Integer) 9)) = (Integer) detstackvar(11);
	field(mktag(0), (Integer) r3, ((Integer) 7)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r3, ((Integer) 6)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r3, ((Integer) 5)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 8)) = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
	r1 = string_const("mode_info_remove_live_vars: failed", 34);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i8,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i8);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i10,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i10);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_delay_info_2_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i11,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i11);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__delay_info__bind_var_list_3_0);
	call_localret(ENTRY(mercury__delay_info__bind_var_list_3_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i12,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i12);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_delay_info_3_0),
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module30)
	init_entry(mercury__mode_info__mode_info_var_list_is_live_3_0);
	init_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i4);
	init_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i5);
	init_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i1002);
BEGIN_CODE

/* code for predicate 'mode_info_var_list_is_live'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_list_is_live_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0_i1002);
	incr_sp_push_msg(3, "mode_info_var_list_is_live");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		call_localret(STATIC(mercury__mode_info__mode_info_var_is_live_3_0),
		mercury__mode_info__mode_info_var_list_is_live_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_var_list_is_live_3_0));
	}
Define_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__mode_info__mode_info_var_list_is_live_3_0,
		LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0_i5),
		ENTRY(mercury__mode_info__mode_info_var_list_is_live_3_0));
Define_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module31)
	init_entry(mercury__mode_info__mode_info_var_is_live_3_0);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i7);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i8);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i6);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i10);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_live'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_live_3_0);
	incr_sp_push_msg(5, "mode_info_var_is_live");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) curfr;
	detstackvar(3) = (Integer) maxfr;
	detstackvar(4) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__mode_info__mode_info_var_is_live_3_0_i6);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	{
	Declare_entry(mercury__list__member_2_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__mode_info__mode_info_var_is_live_3_0_i7,
		ENTRY(mercury__mode_info__mode_info_var_is_live_3_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i7);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_live_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__mode_info__mode_info_var_is_live_3_0_i8,
		ENTRY(mercury__mode_info__mode_info_var_is_live_3_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i8);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_live_3_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_live_3_0_i10);
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_live_3_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_live_3_0_i2);
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i10);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i2);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module32)
	init_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i7);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i8);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i10);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_nondet_live'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);
	incr_sp_push_msg(5, "mode_info_var_is_nondet_live");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) curfr;
	detstackvar(3) = (Integer) maxfr;
	detstackvar(4) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	{
	Declare_entry(mercury__list__member_2_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__mode_info__mode_info_var_is_nondet_live_3_0_i7,
		ENTRY(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i7);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__mode_info__mode_info_var_is_nondet_live_3_0_i8,
		ENTRY(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i8);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i10);
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i2);
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i10);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i2);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module33)
	init_entry(mercury__mode_info__mode_info_get_liveness_2_0);
	init_label(mercury__mode_info__mode_info_get_liveness_2_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_get_liveness'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_liveness_2_0);
	incr_sp_push_msg(2, "mode_info_get_liveness");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__mode_info__mode_info_get_liveness_2_0_i2,
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_0));
	}
Define_label(mercury__mode_info__mode_info_get_liveness_2_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_get_liveness_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_get_liveness_2_3_0),
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module34)
	init_entry(mercury__mode_info__mode_info_get_liveness_2_3_0);
	init_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i4);
	init_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i1002);
BEGIN_CODE

/* code for predicate 'mode_info_get_liveness_2'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_liveness_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mode_info__mode_info_get_liveness_2_3_0_i1002);
	incr_sp_push_msg(2, "mode_info_get_liveness_2");
	detstackvar(2) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__mode_info__mode_info_get_liveness_2_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_3_0));
	}
Define_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_get_liveness_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__mode_info__mode_info_get_liveness_2_3_0,
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_3_0));
Define_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module35)
	init_entry(mercury__mode_info__mode_info_get_varset_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_varset'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_varset_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module36)
	init_entry(mercury__mode_info__mode_info_set_varset_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_varset'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_varset_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module37)
	init_entry(mercury__mode_info__mode_info_get_instvarset_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_instvarset'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_instvarset_2_0);
	tailcall(STATIC(mercury__mode_info__mode_info_get_instvarset__ua10000_2_0),
		ENTRY(mercury__mode_info__mode_info_get_instvarset_2_0));
END_MODULE

BEGIN_MODULE(mercury__mode_info_module38)
	init_entry(mercury__mode_info__mode_info_get_var_types_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_var_types'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_var_types_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module39)
	init_entry(mercury__mode_info__mode_info_set_var_types_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_var_types'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_var_types_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module40)
	init_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
	init_label(mercury__mode_info__mode_info_get_types_of_vars_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_get_types_of_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
	incr_sp_push_msg(2, "mode_info_get_types_of_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_var_types_2_0),
		mercury__mode_info__mode_info_get_types_of_vars_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_get_types_of_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_get_types_of_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_get_types_of_vars_3_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__map__apply_to_list_3_0);
	tailcall(ENTRY(mercury__map__apply_to_list_3_0),
		ENTRY(mercury__mode_info__mode_info_get_types_of_vars_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module41)
	init_entry(mercury__mode_info__mode_info_lock_vars_3_0);
	init_label(mercury__mode_info__mode_info_lock_vars_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_lock_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_lock_vars_3_0);
	incr_sp_push_msg(3, "mode_info_lock_vars");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_locked_vars_2_0),
		mercury__mode_info__mode_info_lock_vars_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_lock_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_lock_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_lock_vars_3_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_locked_vars_3_0),
		ENTRY(mercury__mode_info__mode_info_lock_vars_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module42)
	init_entry(mercury__mode_info__mode_info_unlock_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_unlock_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_unlock_vars_3_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__mode_info__mode_info_unlock_vars__ua10000_3_0),
		ENTRY(mercury__mode_info__mode_info_unlock_vars_3_0));
END_MODULE

BEGIN_MODULE(mercury__mode_info_module43)
	init_entry(mercury__mode_info__mode_info_var_is_locked_2_0);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_locked'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_locked_2_0);
	incr_sp_push_msg(2, "mode_info_var_is_locked");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_locked_vars_2_0),
		mercury__mode_info__mode_info_var_is_locked_2_0_i2,
		ENTRY(mercury__mode_info__mode_info_var_is_locked_2_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_locked_2_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_locked_2_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_var_is_locked_2_2_0),
		ENTRY(mercury__mode_info__mode_info_var_is_locked_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module44)
	init_entry(mercury__mode_info__mode_info_var_is_locked_2_2_0);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i5);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i9);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i1003);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_locked_2'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_locked_2_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mode_info__mode_info_var_is_locked_2_2_0_i1003);
	incr_sp_push_msg(3, "mode_info_var_is_locked_2");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__mode_info__mode_info_var_is_locked_2_2_0_i5,
		ENTRY(mercury__mode_info__mode_info_var_is_locked_2_2_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_locked_2_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__mode_info__mode_info_var_is_locked_2_2_0_i9);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__mode_info__mode_info_var_is_locked_2_2_0,
		ENTRY(mercury__mode_info__mode_info_var_is_locked_2_2_0));
Define_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i9);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mode_info__mode_info_var_is_locked_2_2_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module45)
	init_entry(mercury__mode_info__mode_info_get_delay_info_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_delay_info'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_delay_info_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module46)
	init_entry(mercury__mode_info__mode_info_set_delay_info_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_delay_info'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_delay_info_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module47)
	init_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_nondet_live_vars'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module48)
	init_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_nondet_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module49)
	init_entry(mercury__mode_info__mode_info_get_changed_flag_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_changed_flag'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_changed_flag_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 14));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module50)
	init_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_changed_flag'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 15));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 9)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 10)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	field(mktag(0), (Integer) r1, ((Integer) 11)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	field(mktag(0), (Integer) r1, ((Integer) 12)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	field(mktag(0), (Integer) r1, ((Integer) 13)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	field(mktag(0), (Integer) r1, ((Integer) 14)) = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module51)
	init_entry(mercury__mode_info__mode_info_error_4_0);
	init_label(mercury__mode_info__mode_info_error_4_0_i2);
	init_label(mercury__mode_info__mode_info_error_4_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_error'/4 in mode 0 */
Define_entry(mercury__mode_info__mode_info_error_4_0);
	incr_sp_push_msg(5, "mode_info_error");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r3;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_context_2_0),
		mercury__mode_info__mode_info_error_4_0_i2,
		ENTRY(mercury__mode_info__mode_info_error_4_0));
	}
Define_label(mercury__mode_info__mode_info_error_4_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_error_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_mode_context_2_0),
		mercury__mode_info__mode_info_error_4_0_i3,
		ENTRY(mercury__mode_info__mode_info_error_4_0));
	}
Define_label(mercury__mode_info__mode_info_error_4_0_i3);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_error_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_add_error_3_0),
		ENTRY(mercury__mode_info__mode_info_error_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module52)
	init_entry(mercury__mode_info__mode_info_add_error_3_0);
	init_label(mercury__mode_info__mode_info_add_error_3_0_i2);
	init_label(mercury__mode_info__mode_info_add_error_3_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_add_error'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_add_error_3_0);
	incr_sp_push_msg(3, "mode_info_add_error");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__mode_info__mode_info_get_errors_2_0),
		mercury__mode_info__mode_info_add_error_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_add_error_3_0));
	}
Define_label(mercury__mode_info__mode_info_add_error_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_add_error_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mode_errors__base_type_info_mode_error_info_0;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__mode_info__mode_info_add_error_3_0_i3,
		ENTRY(mercury__mode_info__mode_info_add_error_3_0));
	}
Define_label(mercury__mode_info__mode_info_add_error_3_0_i3);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_add_error_3_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__mode_info__mode_info_set_errors_3_0),
		ENTRY(mercury__mode_info__mode_info_add_error_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module53)
	init_entry(mercury____Unify___mode_info__mode_context_0_0);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i1017);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i6);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i8);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i11);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i1014);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i1);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i1016);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__mode_context_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1017);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1014);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i1017);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1016);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1016);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_goal__unify_context_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_goal__unify_context_0_0),
		mercury____Unify___mode_info__mode_context_0_0_i11,
		ENTRY(mercury____Unify___mode_info__mode_context_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_context_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_context_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i1014);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i1016);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module54)
	init_entry(mercury____Index___mode_info__mode_context_0_0);
	init_label(mercury____Index___mode_info__mode_context_0_0_i4);
	init_label(mercury____Index___mode_info__mode_context_0_0_i5);
	init_label(mercury____Index___mode_info__mode_context_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__mode_context_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___mode_info__mode_context_0_0_i4);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___mode_info__mode_context_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___mode_info__mode_context_0_0_i5);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___mode_info__mode_context_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___mode_info__mode_context_0_0_i6);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___mode_info__mode_context_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module55)
	init_entry(mercury____Compare___mode_info__mode_context_0_0);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i2);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i3);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i4);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i6);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i12);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i18);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i19);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i17);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i14);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i28);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i24);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i37);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__mode_context_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___mode_info__mode_context_0_0),
		mercury____Compare___mode_info__mode_context_0_0_i2,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___mode_info__mode_context_0_0),
		mercury____Compare___mode_info__mode_context_0_0_i3,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i12);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i14);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_context_0_0_i18,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i17);
Define_label(mercury____Compare___mode_info__mode_context_0_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i17);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i14);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i24);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_context_0_0_i28,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i24);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i9);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___hlds_goal__unify_context_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_goal__unify_context_0_0),
		mercury____Compare___mode_info__mode_context_0_0_i37,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i37);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module56)
	init_entry(mercury____Unify___mode_info__side_0_0);
	init_label(mercury____Unify___mode_info__side_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__side_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___mode_info__side_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__side_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module57)
	init_entry(mercury____Index___mode_info__side_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__side_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___mode_info__side_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module58)
	init_entry(mercury____Compare___mode_info__side_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__side_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__side_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module59)
	init_entry(mercury____Unify___mode_info__call_context_0_0);
	init_label(mercury____Unify___mode_info__call_context_0_0_i1011);
	init_label(mercury____Unify___mode_info__call_context_0_0_i8);
	init_label(mercury____Unify___mode_info__call_context_0_0_i1008);
	init_label(mercury____Unify___mode_info__call_context_0_0_i1);
	init_label(mercury____Unify___mode_info__call_context_0_0_i1010);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__call_context_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1011);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1008);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___hlds_goal__unify_context_0_0);
	tailcall(ENTRY(mercury____Unify___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Unify___mode_info__call_context_0_0));
	}
Define_label(mercury____Unify___mode_info__call_context_0_0_i1011);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__call_context_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__call_context_0_0_i1008);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___mode_info__call_context_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___mode_info__call_context_0_0_i1010);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module60)
	init_entry(mercury____Index___mode_info__call_context_0_0);
	init_label(mercury____Index___mode_info__call_context_0_0_i4);
	init_label(mercury____Index___mode_info__call_context_0_0_i5);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__call_context_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___mode_info__call_context_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___mode_info__call_context_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___mode_info__call_context_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___mode_info__call_context_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module61)
	init_entry(mercury____Compare___mode_info__call_context_0_0);
	init_label(mercury____Compare___mode_info__call_context_0_0_i2);
	init_label(mercury____Compare___mode_info__call_context_0_0_i3);
	init_label(mercury____Compare___mode_info__call_context_0_0_i4);
	init_label(mercury____Compare___mode_info__call_context_0_0_i6);
	init_label(mercury____Compare___mode_info__call_context_0_0_i12);
	init_label(mercury____Compare___mode_info__call_context_0_0_i15);
	init_label(mercury____Compare___mode_info__call_context_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__call_context_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___mode_info__call_context_0_0),
		mercury____Compare___mode_info__call_context_0_0_i2,
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
	}
Define_label(mercury____Compare___mode_info__call_context_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__call_context_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___mode_info__call_context_0_0),
		mercury____Compare___mode_info__call_context_0_0_i3,
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
	}
Define_label(mercury____Compare___mode_info__call_context_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__call_context_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mode_info__call_context_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mode_info__call_context_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i12);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___hlds_goal__unify_context_0_0);
	tailcall(ENTRY(mercury____Compare___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
	}
Define_label(mercury____Compare___mode_info__call_context_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i15);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
	}
Define_label(mercury____Compare___mode_info__call_context_0_0_i15);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
	}
Define_label(mercury____Compare___mode_info__call_context_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mode_info_module62)
	init_entry(mercury____Unify___mode_info__mode_info_0_0);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i2);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i4);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i6);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i8);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i10);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i12);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i14);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i16);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i18);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i20);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i22);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i24);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__mode_info_0_0);
	incr_sp_push_msg(29, "__Unify__");
	detstackvar(29) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 14));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(23) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(24) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(25) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(26) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(27) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	detstackvar(28) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___io__state_0_0);
	call_localret(ENTRY(mercury____Unify___io__state_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i2,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i4,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(16)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(17)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i6,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___mode_info__mode_info_0_0_i8,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i10,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(21);
	{
		call_localret(STATIC(mercury____Unify___mode_info__mode_context_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i12,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(22);
	{
	Declare_entry(mercury____Unify___instmap__instmap_0_0);
	call_localret(ENTRY(mercury____Unify___instmap__instmap_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i14,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(23);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i16,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(24);
	{
	Declare_entry(mercury____Unify___delay_info__delay_info_0_0);
	call_localret(ENTRY(mercury____Unify___delay_info__delay_info_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i18,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) mercury_data_mode_errors__base_type_info_mode_error_info_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(25);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i20,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(26);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i22,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(27);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i24,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
	}
Define_label(mercury____Unify___mode_info__mode_info_0_0_i24);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if (((Integer) detstackvar(14) != (Integer) detstackvar(28)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(29);
	decr_sp_pop_msg(29);
	proceed();
Define_label(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(29);
	decr_sp_pop_msg(29);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mode_info_module63)
	init_entry(mercury____Index___mode_info__mode_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__mode_info_0_0);
	tailcall(STATIC(mercury____Index___mode_info_mode_info_0__ua10000_2_0),
		ENTRY(mercury____Index___mode_info__mode_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__mode_info_module64)
	init_entry(mercury____Compare___mode_info__mode_info_0_0);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i4);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i5);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i3);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i10);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i16);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i22);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i28);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i34);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i40);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i46);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i52);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i58);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i64);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i70);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i76);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i82);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__mode_info_0_0);
	incr_sp_push_msg(29, "__Compare__");
	detstackvar(29) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 12));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 13));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 14));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(23) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(24) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(25) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	detstackvar(26) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 12));
	detstackvar(27) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 13));
	detstackvar(28) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 14));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Compare___io__state_0_0);
	call_localret(ENTRY(mercury____Compare___io__state_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i4,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i3);
Define_label(mercury____Compare___mode_info__mode_info_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(29);
	decr_sp_pop_msg(29);
	proceed();
Define_label(mercury____Compare___mode_info__mode_info_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i10,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_info_0_0_i16,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_info_0_0_i22,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i28,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___mode_info__mode_info_0_0_i34,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i40,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(21);
	{
		call_localret(STATIC(mercury____Compare___mode_info__mode_context_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i46,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(22);
	{
	Declare_entry(mercury____Compare___instmap__instmap_0_0);
	call_localret(ENTRY(mercury____Compare___instmap__instmap_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i52,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i52);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(23);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i58,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i58);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(24);
	{
	Declare_entry(mercury____Compare___delay_info__delay_info_0_0);
	call_localret(ENTRY(mercury____Compare___delay_info__delay_info_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i64,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i64);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) mercury_data_mode_errors__base_type_info_mode_error_info_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(25);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i70,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i70);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(26);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i76,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i76);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mode_info__common_0);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(27);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i82,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
Define_label(mercury____Compare___mode_info__mode_info_0_0_i82);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i5);
	r1 = (Integer) detstackvar(14);
	r2 = (Integer) detstackvar(28);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(29);
	decr_sp_pop_msg(29);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__mode_info_bunch_0(void)
{
	mercury__mode_info_module0();
	mercury__mode_info_module1();
	mercury__mode_info_module2();
	mercury__mode_info_module3();
	mercury__mode_info_module4();
	mercury__mode_info_module5();
	mercury__mode_info_module6();
	mercury__mode_info_module7();
	mercury__mode_info_module8();
	mercury__mode_info_module9();
	mercury__mode_info_module10();
	mercury__mode_info_module11();
	mercury__mode_info_module12();
	mercury__mode_info_module13();
	mercury__mode_info_module14();
	mercury__mode_info_module15();
	mercury__mode_info_module16();
	mercury__mode_info_module17();
	mercury__mode_info_module18();
	mercury__mode_info_module19();
	mercury__mode_info_module20();
	mercury__mode_info_module21();
	mercury__mode_info_module22();
	mercury__mode_info_module23();
	mercury__mode_info_module24();
	mercury__mode_info_module25();
	mercury__mode_info_module26();
	mercury__mode_info_module27();
	mercury__mode_info_module28();
	mercury__mode_info_module29();
	mercury__mode_info_module30();
	mercury__mode_info_module31();
	mercury__mode_info_module32();
	mercury__mode_info_module33();
	mercury__mode_info_module34();
	mercury__mode_info_module35();
	mercury__mode_info_module36();
	mercury__mode_info_module37();
	mercury__mode_info_module38();
	mercury__mode_info_module39();
	mercury__mode_info_module40();
}

static void mercury__mode_info_bunch_1(void)
{
	mercury__mode_info_module41();
	mercury__mode_info_module42();
	mercury__mode_info_module43();
	mercury__mode_info_module44();
	mercury__mode_info_module45();
	mercury__mode_info_module46();
	mercury__mode_info_module47();
	mercury__mode_info_module48();
	mercury__mode_info_module49();
	mercury__mode_info_module50();
	mercury__mode_info_module51();
	mercury__mode_info_module52();
	mercury__mode_info_module53();
	mercury__mode_info_module54();
	mercury__mode_info_module55();
	mercury__mode_info_module56();
	mercury__mode_info_module57();
	mercury__mode_info_module58();
	mercury__mode_info_module59();
	mercury__mode_info_module60();
	mercury__mode_info_module61();
	mercury__mode_info_module62();
	mercury__mode_info_module63();
	mercury__mode_info_module64();
}

#endif

void mercury__mode_info__init(void); /* suppress gcc warning */
void mercury__mode_info__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__mode_info_bunch_0();
	mercury__mode_info_bunch_1();
#endif
}
