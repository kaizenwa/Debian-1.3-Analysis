/*
** Automatically generated from `modules.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__modules__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___modules_deps_0__ua10000_2_0);
Declare_static(mercury____Index___modules_module_imports_0__ua10000_2_0);
Define_extern_entry(mercury__modules__read_mod_8_0);
Declare_label(mercury__modules__read_mod_8_0_i2);
Declare_label(mercury__modules__read_mod_8_0_i3);
Declare_label(mercury__modules__read_mod_8_0_i4);
Declare_label(mercury__modules__read_mod_8_0_i5);
Declare_label(mercury__modules__read_mod_8_0_i6);
Declare_label(mercury__modules__read_mod_8_0_i7);
Declare_label(mercury__modules__read_mod_8_0_i8);
Declare_label(mercury__modules__read_mod_8_0_i9);
Declare_label(mercury__modules__read_mod_8_0_i10);
Declare_label(mercury__modules__read_mod_8_0_i11);
Declare_label(mercury__modules__read_mod_8_0_i15);
Declare_label(mercury__modules__read_mod_8_0_i16);
Declare_label(mercury__modules__read_mod_8_0_i12);
Declare_label(mercury__modules__read_mod_8_0_i20);
Declare_label(mercury__modules__read_mod_8_0_i21);
Declare_label(mercury__modules__read_mod_8_0_i17);
Declare_label(mercury__modules__read_mod_8_0_i22);
Declare_label(mercury__modules__read_mod_8_0_i24);
Declare_label(mercury__modules__read_mod_8_0_i25);
Define_extern_entry(mercury__modules__read_mod_ignore_errors_8_0);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i2);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i3);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i4);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i5);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i6);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i7);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i8);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i9);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i10);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i11);
Declare_label(mercury__modules__read_mod_ignore_errors_8_0_i12);
Define_extern_entry(mercury__modules__make_interface_4_0);
Declare_label(mercury__modules__make_interface_4_0_i2);
Declare_label(mercury__modules__make_interface_4_0_i3);
Declare_label(mercury__modules__make_interface_4_0_i4);
Declare_label(mercury__modules__make_interface_4_0_i5);
Declare_label(mercury__modules__make_interface_4_0_i6);
Declare_label(mercury__modules__make_interface_4_0_i7);
Declare_label(mercury__modules__make_interface_4_0_i8);
Declare_label(mercury__modules__make_interface_4_0_i12);
Declare_label(mercury__modules__make_interface_4_0_i13);
Declare_label(mercury__modules__make_interface_4_0_i14);
Declare_label(mercury__modules__make_interface_4_0_i20);
Declare_label(mercury__modules__make_interface_4_0_i21);
Declare_label(mercury__modules__make_interface_4_0_i22);
Declare_label(mercury__modules__make_interface_4_0_i23);
Declare_label(mercury__modules__make_interface_4_0_i24);
Declare_label(mercury__modules__make_interface_4_0_i25);
Define_extern_entry(mercury__modules__make_short_interface_4_0);
Declare_label(mercury__modules__make_short_interface_4_0_i2);
Declare_label(mercury__modules__make_short_interface_4_0_i3);
Declare_label(mercury__modules__make_short_interface_4_0_i4);
Declare_label(mercury__modules__make_short_interface_4_0_i5);
Declare_label(mercury__modules__make_short_interface_4_0_i6);
Define_extern_entry(mercury__modules__grab_imported_modules_7_0);
Declare_label(mercury__modules__grab_imported_modules_7_0_i2);
Declare_label(mercury__modules__grab_imported_modules_7_0_i3);
Declare_label(mercury__modules__grab_imported_modules_7_0_i4);
Declare_label(mercury__modules__grab_imported_modules_7_0_i5);
Declare_label(mercury__modules__grab_imported_modules_7_0_i6);
Declare_label(mercury__modules__grab_imported_modules_7_0_i7);
Declare_label(mercury__modules__grab_imported_modules_7_0_i8);
Define_extern_entry(mercury__modules__write_dependency_file_6_0);
Declare_label(mercury__modules__write_dependency_file_6_0_i2);
Declare_label(mercury__modules__write_dependency_file_6_0_i3);
Declare_label(mercury__modules__write_dependency_file_6_0_i4);
Declare_label(mercury__modules__write_dependency_file_6_0_i5);
Declare_label(mercury__modules__write_dependency_file_6_0_i6);
Declare_label(mercury__modules__write_dependency_file_6_0_i7);
Declare_label(mercury__modules__write_dependency_file_6_0_i8);
Declare_label(mercury__modules__write_dependency_file_6_0_i12);
Declare_label(mercury__modules__write_dependency_file_6_0_i13);
Declare_label(mercury__modules__write_dependency_file_6_0_i14);
Declare_label(mercury__modules__write_dependency_file_6_0_i15);
Declare_label(mercury__modules__write_dependency_file_6_0_i16);
Declare_label(mercury__modules__write_dependency_file_6_0_i17);
Declare_label(mercury__modules__write_dependency_file_6_0_i18);
Declare_label(mercury__modules__write_dependency_file_6_0_i19);
Declare_label(mercury__modules__write_dependency_file_6_0_i20);
Declare_label(mercury__modules__write_dependency_file_6_0_i21);
Declare_label(mercury__modules__write_dependency_file_6_0_i22);
Declare_label(mercury__modules__write_dependency_file_6_0_i26);
Declare_label(mercury__modules__write_dependency_file_6_0_i27);
Declare_label(mercury__modules__write_dependency_file_6_0_i28);
Declare_label(mercury__modules__write_dependency_file_6_0_i23);
Declare_label(mercury__modules__write_dependency_file_6_0_i29);
Declare_label(mercury__modules__write_dependency_file_6_0_i30);
Declare_label(mercury__modules__write_dependency_file_6_0_i31);
Declare_label(mercury__modules__write_dependency_file_6_0_i32);
Declare_label(mercury__modules__write_dependency_file_6_0_i33);
Declare_label(mercury__modules__write_dependency_file_6_0_i34);
Declare_label(mercury__modules__write_dependency_file_6_0_i9);
Declare_label(mercury__modules__write_dependency_file_6_0_i36);
Define_extern_entry(mercury__modules__generate_dependencies_3_0);
Declare_label(mercury__modules__generate_dependencies_3_0_i2);
Declare_label(mercury__modules__generate_dependencies_3_0_i3);
Declare_label(mercury__modules__generate_dependencies_3_0_i4);
Declare_label(mercury__modules__generate_dependencies_3_0_i8);
Declare_label(mercury__modules__generate_dependencies_3_0_i5);
Declare_label(mercury__modules__generate_dependencies_3_0_i10);
Declare_label(mercury__modules__generate_dependencies_3_0_i11);
Declare_label(mercury__modules__generate_dependencies_3_0_i12);
Declare_label(mercury__modules__generate_dependencies_3_0_i13);
Declare_label(mercury__modules__generate_dependencies_3_0_i14);
Declare_label(mercury__modules__generate_dependencies_3_0_i15);
Declare_label(mercury__modules__generate_dependencies_3_0_i19);
Declare_label(mercury__modules__generate_dependencies_3_0_i20);
Declare_label(mercury__modules__generate_dependencies_3_0_i16);
Declare_label(mercury__modules__generate_dependencies_3_0_i22);
Define_extern_entry(mercury__modules__get_dependencies_2_0);
Define_extern_entry(mercury__modules__process_module_interfaces_6_0);
Declare_label(mercury__modules__process_module_interfaces_6_0_i1016);
Declare_label(mercury__modules__process_module_interfaces_6_0_i9);
Declare_label(mercury__modules__process_module_interfaces_6_0_i13);
Declare_label(mercury__modules__process_module_interfaces_6_0_i14);
Declare_label(mercury__modules__process_module_interfaces_6_0_i15);
Declare_label(mercury__modules__process_module_interfaces_6_0_i10);
Declare_label(mercury__modules__process_module_interfaces_6_0_i1015);
Declare_label(mercury__modules__process_module_interfaces_6_0_i21);
Declare_label(mercury__modules__process_module_interfaces_6_0_i20);
Declare_label(mercury__modules__process_module_interfaces_6_0_i24);
Declare_label(mercury__modules__process_module_interfaces_6_0_i25);
Declare_label(mercury__modules__process_module_interfaces_6_0_i30);
Declare_label(mercury__modules__process_module_interfaces_6_0_i31);
Declare_label(mercury__modules__process_module_interfaces_6_0_i36);
Declare_label(mercury__modules__process_module_interfaces_6_0_i37);
Declare_label(mercury__modules__process_module_interfaces_6_0_i38);
Declare_label(mercury__modules__process_module_interfaces_6_0_i39);
Declare_label(mercury__modules__process_module_interfaces_6_0_i40);
Declare_label(mercury__modules__process_module_interfaces_6_0_i43);
Declare_label(mercury__modules__process_module_interfaces_6_0_i44);
Declare_label(mercury__modules__process_module_interfaces_6_0_i45);
Declare_label(mercury__modules__process_module_interfaces_6_0_i1014);
Define_extern_entry(mercury__modules__touch_interface_datestamp_4_0);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i2);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i3);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i4);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i5);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i6);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i7);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i8);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i12);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i13);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i9);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i15);
Declare_label(mercury__modules__touch_interface_datestamp_4_0_i16);
Define_extern_entry(mercury__modules__update_interface_3_0);
Declare_label(mercury__modules__update_interface_3_0_i2);
Declare_label(mercury__modules__update_interface_3_0_i3);
Declare_label(mercury__modules__update_interface_3_0_i4);
Declare_label(mercury__modules__update_interface_3_0_i7);
Declare_label(mercury__modules__update_interface_3_0_i8);
Declare_label(mercury__modules__update_interface_3_0_i9);
Declare_label(mercury__modules__update_interface_3_0_i1000);
Declare_static(mercury__modules__strip_imported_items_3_0);
Declare_label(mercury__modules__strip_imported_items_3_0_i1008);
Declare_label(mercury__modules__strip_imported_items_3_0_i1007);
Declare_static(mercury__modules__check_for_clauses_in_interface_4_0);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i1006);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i6);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i9);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i10);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i4);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i12);
Declare_label(mercury__modules__check_for_clauses_in_interface_4_0_i1004);
Declare_static(mercury__modules__check_for_no_exports_4_0);
Declare_label(mercury__modules__check_for_no_exports_4_0_i1014);
Declare_label(mercury__modules__check_for_no_exports_4_0_i4);
Declare_label(mercury__modules__check_for_no_exports_4_0_i1013);
Declare_label(mercury__modules__check_for_no_exports_4_0_i11);
Declare_label(mercury__modules__check_for_no_exports_4_0_i15);
Declare_label(mercury__modules__check_for_no_exports_4_0_i16);
Declare_label(mercury__modules__check_for_no_exports_4_0_i20);
Declare_label(mercury__modules__check_for_no_exports_4_0_i17);
Declare_label(mercury__modules__check_for_no_exports_4_0_i12);
Declare_label(mercury__modules__check_for_no_exports_4_0_i1009);
Declare_static(mercury__modules__write_interface_file_5_0);
Declare_label(mercury__modules__write_interface_file_5_0_i2);
Declare_label(mercury__modules__write_interface_file_5_0_i3);
Declare_label(mercury__modules__write_interface_file_5_0_i4);
Declare_label(mercury__modules__write_interface_file_5_0_i5);
Declare_label(mercury__modules__write_interface_file_5_0_i6);
Declare_label(mercury__modules__write_interface_file_5_0_i7);
Declare_static(mercury__modules__get_curr_dir_deps_5_0);
Declare_label(mercury__modules__get_curr_dir_deps_5_0_i4);
Declare_label(mercury__modules__get_curr_dir_deps_5_0_i5);
Declare_label(mercury__modules__get_curr_dir_deps_5_0_i9);
Declare_label(mercury__modules__get_curr_dir_deps_5_0_i6);
Declare_label(mercury__modules__get_curr_dir_deps_5_0_i1003);
Declare_static(mercury__modules__generate_deps_map_5_0);
Declare_label(mercury__modules__generate_deps_map_5_0_i4);
Declare_label(mercury__modules__generate_deps_map_5_0_i8);
Declare_label(mercury__modules__generate_deps_map_5_0_i9);
Declare_label(mercury__modules__generate_deps_map_5_0_i10);
Declare_label(mercury__modules__generate_deps_map_5_0_i11);
Declare_label(mercury__modules__generate_deps_map_5_0_i17);
Declare_label(mercury__modules__generate_deps_map_5_0_i12);
Declare_label(mercury__modules__generate_deps_map_5_0_i18);
Declare_label(mercury__modules__generate_deps_map_5_0_i19);
Declare_label(mercury__modules__generate_deps_map_5_0_i5);
Declare_label(mercury__modules__generate_deps_map_5_0_i1004);
Declare_static(mercury__modules__generate_dep_file_5_0);
Declare_label(mercury__modules__generate_dep_file_5_0_i2);
Declare_label(mercury__modules__generate_dep_file_5_0_i3);
Declare_label(mercury__modules__generate_dep_file_5_0_i4);
Declare_label(mercury__modules__generate_dep_file_5_0_i5);
Declare_label(mercury__modules__generate_dep_file_5_0_i6);
Declare_label(mercury__modules__generate_dep_file_5_0_i7);
Declare_label(mercury__modules__generate_dep_file_5_0_i8);
Declare_label(mercury__modules__generate_dep_file_5_0_i9);
Declare_label(mercury__modules__generate_dep_file_5_0_i10);
Declare_label(mercury__modules__generate_dep_file_5_0_i11);
Declare_label(mercury__modules__generate_dep_file_5_0_i12);
Declare_label(mercury__modules__generate_dep_file_5_0_i13);
Declare_label(mercury__modules__generate_dep_file_5_0_i14);
Declare_label(mercury__modules__generate_dep_file_5_0_i15);
Declare_label(mercury__modules__generate_dep_file_5_0_i17);
Declare_label(mercury__modules__generate_dep_file_5_0_i18);
Declare_label(mercury__modules__generate_dep_file_5_0_i16);
Declare_label(mercury__modules__generate_dep_file_5_0_i19);
Declare_label(mercury__modules__generate_dep_file_5_0_i20);
Declare_label(mercury__modules__generate_dep_file_5_0_i21);
Declare_label(mercury__modules__generate_dep_file_5_0_i22);
Declare_label(mercury__modules__generate_dep_file_5_0_i23);
Declare_label(mercury__modules__generate_dep_file_5_0_i24);
Declare_label(mercury__modules__generate_dep_file_5_0_i25);
Declare_label(mercury__modules__generate_dep_file_5_0_i26);
Declare_label(mercury__modules__generate_dep_file_5_0_i27);
Declare_label(mercury__modules__generate_dep_file_5_0_i28);
Declare_label(mercury__modules__generate_dep_file_5_0_i29);
Declare_label(mercury__modules__generate_dep_file_5_0_i30);
Declare_label(mercury__modules__generate_dep_file_5_0_i31);
Declare_label(mercury__modules__generate_dep_file_5_0_i32);
Declare_label(mercury__modules__generate_dep_file_5_0_i33);
Declare_label(mercury__modules__generate_dep_file_5_0_i34);
Declare_label(mercury__modules__generate_dep_file_5_0_i35);
Declare_label(mercury__modules__generate_dep_file_5_0_i36);
Declare_label(mercury__modules__generate_dep_file_5_0_i37);
Declare_label(mercury__modules__generate_dep_file_5_0_i38);
Declare_label(mercury__modules__generate_dep_file_5_0_i39);
Declare_label(mercury__modules__generate_dep_file_5_0_i40);
Declare_label(mercury__modules__generate_dep_file_5_0_i41);
Declare_label(mercury__modules__generate_dep_file_5_0_i42);
Declare_label(mercury__modules__generate_dep_file_5_0_i43);
Declare_label(mercury__modules__generate_dep_file_5_0_i44);
Declare_label(mercury__modules__generate_dep_file_5_0_i45);
Declare_label(mercury__modules__generate_dep_file_5_0_i46);
Declare_label(mercury__modules__generate_dep_file_5_0_i47);
Declare_label(mercury__modules__generate_dep_file_5_0_i48);
Declare_label(mercury__modules__generate_dep_file_5_0_i49);
Declare_label(mercury__modules__generate_dep_file_5_0_i50);
Declare_label(mercury__modules__generate_dep_file_5_0_i51);
Declare_label(mercury__modules__generate_dep_file_5_0_i52);
Declare_label(mercury__modules__generate_dep_file_5_0_i53);
Declare_label(mercury__modules__generate_dep_file_5_0_i54);
Declare_label(mercury__modules__generate_dep_file_5_0_i55);
Declare_label(mercury__modules__generate_dep_file_5_0_i56);
Declare_label(mercury__modules__generate_dep_file_5_0_i57);
Declare_label(mercury__modules__generate_dep_file_5_0_i58);
Declare_label(mercury__modules__generate_dep_file_5_0_i59);
Declare_label(mercury__modules__generate_dep_file_5_0_i60);
Declare_label(mercury__modules__generate_dep_file_5_0_i61);
Declare_label(mercury__modules__generate_dep_file_5_0_i62);
Declare_label(mercury__modules__generate_dep_file_5_0_i63);
Declare_label(mercury__modules__generate_dep_file_5_0_i64);
Declare_label(mercury__modules__generate_dep_file_5_0_i65);
Declare_label(mercury__modules__generate_dep_file_5_0_i66);
Declare_label(mercury__modules__generate_dep_file_5_0_i67);
Declare_label(mercury__modules__generate_dep_file_5_0_i68);
Declare_label(mercury__modules__generate_dep_file_5_0_i69);
Declare_label(mercury__modules__generate_dep_file_5_0_i70);
Declare_label(mercury__modules__generate_dep_file_5_0_i71);
Declare_label(mercury__modules__generate_dep_file_5_0_i72);
Declare_label(mercury__modules__generate_dep_file_5_0_i73);
Declare_label(mercury__modules__generate_dep_file_5_0_i74);
Declare_label(mercury__modules__generate_dep_file_5_0_i75);
Declare_label(mercury__modules__generate_dep_file_5_0_i76);
Declare_label(mercury__modules__generate_dep_file_5_0_i77);
Declare_label(mercury__modules__generate_dep_file_5_0_i78);
Declare_label(mercury__modules__generate_dep_file_5_0_i79);
Declare_label(mercury__modules__generate_dep_file_5_0_i80);
Declare_label(mercury__modules__generate_dep_file_5_0_i81);
Declare_label(mercury__modules__generate_dep_file_5_0_i82);
Declare_label(mercury__modules__generate_dep_file_5_0_i83);
Declare_label(mercury__modules__generate_dep_file_5_0_i84);
Declare_label(mercury__modules__generate_dep_file_5_0_i85);
Declare_label(mercury__modules__generate_dep_file_5_0_i86);
Declare_label(mercury__modules__generate_dep_file_5_0_i87);
Declare_label(mercury__modules__generate_dep_file_5_0_i88);
Declare_label(mercury__modules__generate_dep_file_5_0_i89);
Declare_label(mercury__modules__generate_dep_file_5_0_i90);
Declare_label(mercury__modules__generate_dep_file_5_0_i91);
Declare_label(mercury__modules__generate_dep_file_5_0_i95);
Declare_label(mercury__modules__generate_dep_file_5_0_i96);
Declare_label(mercury__modules__generate_dep_file_5_0_i97);
Declare_label(mercury__modules__generate_dep_file_5_0_i98);
Declare_label(mercury__modules__generate_dep_file_5_0_i99);
Declare_label(mercury__modules__generate_dep_file_5_0_i100);
Declare_label(mercury__modules__generate_dep_file_5_0_i92);
Declare_label(mercury__modules__generate_dep_file_5_0_i101);
Declare_label(mercury__modules__generate_dep_file_5_0_i105);
Declare_label(mercury__modules__generate_dep_file_5_0_i102);
Declare_label(mercury__modules__generate_dep_file_5_0_i110);
Declare_label(mercury__modules__generate_dep_file_5_0_i107);
Declare_label(mercury__modules__generate_dep_file_5_0_i111);
Declare_label(mercury__modules__generate_dep_file_5_0_i112);
Declare_label(mercury__modules__generate_dep_file_5_0_i113);
Declare_label(mercury__modules__generate_dep_file_5_0_i114);
Declare_label(mercury__modules__generate_dep_file_5_0_i115);
Declare_label(mercury__modules__generate_dep_file_5_0_i116);
Declare_label(mercury__modules__generate_dep_file_5_0_i117);
Declare_label(mercury__modules__generate_dep_file_5_0_i118);
Declare_label(mercury__modules__generate_dep_file_5_0_i119);
Declare_label(mercury__modules__generate_dep_file_5_0_i120);
Declare_label(mercury__modules__generate_dep_file_5_0_i124);
Declare_label(mercury__modules__generate_dep_file_5_0_i121);
Declare_label(mercury__modules__generate_dep_file_5_0_i125);
Declare_label(mercury__modules__generate_dep_file_5_0_i126);
Declare_label(mercury__modules__generate_dep_file_5_0_i127);
Declare_label(mercury__modules__generate_dep_file_5_0_i128);
Declare_label(mercury__modules__generate_dep_file_5_0_i129);
Declare_label(mercury__modules__generate_dep_file_5_0_i130);
Declare_static(mercury__modules__get_extra_link_objects_3_0);
Declare_static(mercury__modules__get_extra_link_objects_2_4_0);
Declare_label(mercury__modules__get_extra_link_objects_2_4_0_i4);
Declare_label(mercury__modules__get_extra_link_objects_2_4_0_i5);
Declare_label(mercury__modules__get_extra_link_objects_2_4_0_i1002);
Declare_static(mercury__modules__select_ok_modules_3_0);
Declare_label(mercury__modules__select_ok_modules_3_0_i4);
Declare_label(mercury__modules__select_ok_modules_3_0_i5);
Declare_label(mercury__modules__select_ok_modules_3_0_i3);
Declare_label(mercury__modules__select_ok_modules_3_0_i2);
Declare_static(mercury__modules__write_dependencies_list_5_0);
Declare_label(mercury__modules__write_dependencies_list_5_0_i4);
Declare_label(mercury__modules__write_dependencies_list_5_0_i5);
Declare_label(mercury__modules__write_dependencies_list_5_0_i6);
Declare_label(mercury__modules__write_dependencies_list_5_0_i1002);
Declare_static(mercury__modules__write_compact_dependencies_list_6_0);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i4);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i5);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i6);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i7);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i8);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i9);
Declare_label(mercury__modules__write_compact_dependencies_list_6_0_i1003);
Declare_static(mercury__modules__write_compact_dependencies_separator_4_0);
Declare_label(mercury__modules__write_compact_dependencies_separator_4_0_i1002);
Declare_static(mercury__modules__transitive_dependencies_2_8_0);
Declare_label(mercury__modules__transitive_dependencies_2_8_0_i6);
Declare_label(mercury__modules__transitive_dependencies_2_8_0_i5);
Declare_label(mercury__modules__transitive_dependencies_2_8_0_i8);
Declare_label(mercury__modules__transitive_dependencies_2_8_0_i9);
Declare_label(mercury__modules__transitive_dependencies_2_8_0_i10);
Declare_label(mercury__modules__transitive_dependencies_2_8_0_i1003);
Declare_static(mercury__modules__trans_impl_dependencies_7_0);
Declare_label(mercury__modules__trans_impl_dependencies_7_0_i2);
Declare_label(mercury__modules__trans_impl_dependencies_7_0_i3);
Declare_label(mercury__modules__trans_impl_dependencies_7_0_i4);
Declare_static(mercury__modules__trans_impl_dependencies_2_8_0);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i6);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i5);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i8);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i9);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i10);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i11);
Declare_label(mercury__modules__trans_impl_dependencies_2_8_0_i1003);
Declare_static(mercury__modules__lookup_dependencies_11_0);
Declare_label(mercury__modules__lookup_dependencies_11_0_i4);
Declare_label(mercury__modules__lookup_dependencies_11_0_i3);
Declare_label(mercury__modules__lookup_dependencies_11_0_i6);
Declare_label(mercury__modules__lookup_dependencies_11_0_i11);
Declare_label(mercury__modules__lookup_dependencies_11_0_i7);
Declare_label(mercury__modules__lookup_dependencies_11_0_i12);
Declare_label(mercury__modules__lookup_dependencies_11_0_i13);
Declare_label(mercury__modules__lookup_dependencies_11_0_i14);
Declare_label(mercury__modules__lookup_dependencies_11_0_i15);
Declare_label(mercury__modules__lookup_dependencies_11_0_i16);
Declare_label(mercury__modules__lookup_dependencies_11_0_i17);
Declare_static(mercury__modules__process_module_short_interfaces_6_0);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i1013);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i11);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i10);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i13);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i5);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i16);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i17);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i22);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i23);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i28);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i29);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i30);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i31);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i32);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i33);
Declare_label(mercury__modules__process_module_short_interfaces_6_0_i1011);
Declare_static(mercury__modules__get_dependencies_2_3_0);
Declare_label(mercury__modules__get_dependencies_2_3_0_i9);
Declare_label(mercury__modules__get_dependencies_2_3_0_i1008);
Declare_label(mercury__modules__get_dependencies_2_3_0_i1010);
Declare_static(mercury__modules__get_fact_table_dependencies_2_3_0);
Declare_label(mercury__modules__get_fact_table_dependencies_2_3_0_i8);
Declare_label(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
Declare_label(mercury__modules__get_fact_table_dependencies_2_3_0_i6);
Declare_label(mercury__modules__get_fact_table_dependencies_2_3_0_i1);
Declare_static(mercury__modules__get_interface_3_0);
Declare_label(mercury__modules__get_interface_3_0_i2);
Declare_static(mercury__modules__get_interface_2_5_0);
Declare_label(mercury__modules__get_interface_2_5_0_i26);
Declare_label(mercury__modules__get_interface_2_5_0_i2);
Declare_label(mercury__modules__get_interface_2_5_0_i10);
Declare_label(mercury__modules__get_interface_2_5_0_i6);
Declare_label(mercury__modules__get_interface_2_5_0_i14);
Declare_label(mercury__modules__get_interface_2_5_0_i18);
Declare_label(mercury__modules__get_interface_2_5_0_i24);
Declare_label(mercury__modules__get_interface_2_5_0_i1);
Declare_static(mercury__modules__get_short_interface_2_0);
Declare_label(mercury__modules__get_short_interface_2_0_i2);
Declare_label(mercury__modules__get_short_interface_2_0_i3);
Declare_label(mercury__modules__get_short_interface_2_0_i7);
Declare_label(mercury__modules__get_short_interface_2_0_i9);
Declare_static(mercury__modules__get_short_interface_2_7_0);
Declare_label(mercury__modules__get_short_interface_2_7_0_i25);
Declare_label(mercury__modules__get_short_interface_2_7_0_i2);
Declare_label(mercury__modules__get_short_interface_2_7_0_i10);
Declare_label(mercury__modules__get_short_interface_2_7_0_i9);
Declare_label(mercury__modules__get_short_interface_2_7_0_i6);
Declare_label(mercury__modules__get_short_interface_2_7_0_i17);
Declare_label(mercury__modules__get_short_interface_2_7_0_i12);
Declare_label(mercury__modules__get_short_interface_2_7_0_i23);
Declare_label(mercury__modules__get_short_interface_2_7_0_i1);
Define_extern_entry(mercury____Unify___modules__module_imports_0_0);
Declare_label(mercury____Unify___modules__module_imports_0_0_i2);
Declare_label(mercury____Unify___modules__module_imports_0_0_i4);
Declare_label(mercury____Unify___modules__module_imports_0_0_i6);
Declare_label(mercury____Unify___modules__module_imports_0_0_i1006);
Declare_label(mercury____Unify___modules__module_imports_0_0_i1);
Define_extern_entry(mercury____Index___modules__module_imports_0_0);
Define_extern_entry(mercury____Compare___modules__module_imports_0_0);
Declare_label(mercury____Compare___modules__module_imports_0_0_i4);
Declare_label(mercury____Compare___modules__module_imports_0_0_i5);
Declare_label(mercury____Compare___modules__module_imports_0_0_i3);
Declare_label(mercury____Compare___modules__module_imports_0_0_i10);
Declare_label(mercury____Compare___modules__module_imports_0_0_i16);
Declare_label(mercury____Compare___modules__module_imports_0_0_i22);
Declare_static(mercury____Unify___modules__deps_0_0);
Declare_label(mercury____Unify___modules__deps_0_0_i2);
Declare_label(mercury____Unify___modules__deps_0_0_i4);
Declare_label(mercury____Unify___modules__deps_0_0_i1005);
Declare_label(mercury____Unify___modules__deps_0_0_i1);
Declare_static(mercury____Index___modules__deps_0_0);
Declare_static(mercury____Compare___modules__deps_0_0);
Declare_label(mercury____Compare___modules__deps_0_0_i4);
Declare_label(mercury____Compare___modules__deps_0_0_i5);
Declare_label(mercury____Compare___modules__deps_0_0_i3);
Declare_label(mercury____Compare___modules__deps_0_0_i10);
Declare_label(mercury____Compare___modules__deps_0_0_i16);
Declare_label(mercury____Compare___modules__deps_0_0_i22);

extern Word * mercury_data_modules__base_type_layout_deps_0[];
Word * mercury_data_modules__base_type_info_deps_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) STATIC(mercury____Unify___modules__deps_0_0),
	(Word *) (Integer) STATIC(mercury____Index___modules__deps_0_0),
	(Word *) (Integer) STATIC(mercury____Compare___modules__deps_0_0),
	(Word *) (Integer) mercury_data_modules__base_type_layout_deps_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_modules__base_type_layout_deps_map_0[];
Word * mercury_data_modules__base_type_info_deps_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_modules__base_type_layout_deps_map_0
};

extern Word * mercury_data_modules__base_type_layout_module_imports_0[];
Word * mercury_data_modules__base_type_info_module_imports_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___modules__module_imports_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___modules__module_imports_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___modules__module_imports_0_0),
	(Word *) (Integer) mercury_data_modules__base_type_layout_module_imports_0
};

extern Word * mercury_data_modules__common_32[];
Word * mercury_data_modules__base_type_layout_module_imports_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_32),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_modules__common_34[];
Word * mercury_data_modules__base_type_layout_deps_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_modules__common_34),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_modules__common_34),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_modules__common_34),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_modules__common_34)
};

extern Word * mercury_data_modules__common_36[];
Word * mercury_data_modules__base_type_layout_deps_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_36),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_prog_data__base_type_info_item_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term__context_0[];
Word * mercury_data_modules__common_0[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_item_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

Word * mercury_data_modules__common_1[] = {
	(Word *) string_const(".int2 not written.\n", 19),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_2[] = {
	(Word *) string_const(".int not written.\n", 18),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_3[] = {
	(Word *) string_const(".m", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_4[] = {
	(Word *) string_const(".o :", 4),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_5[] = {
	(Word *) string_const(".m\n", 3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_6[] = {
	(Word *) string_const("' for output.", 13),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_7[] = {
	(Word *) string_const("'.", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_8[] = {
	(Word *) string_const("`:- inst' or `:- mode' declaration.\n", 36),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_9[] = {
	(Word *) string_const("This would normally be a `:- pred', `:- func', `:- type',\n\t\t", 60),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_8)
};

Word * mercury_data_modules__common_10[] = {
	(Word *) string_const("`:- import_module' in its interface section(s).\n\t\t", 50),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_9)
};

Word * mercury_data_modules__common_11[] = {
	(Word *) string_const("A file should contain at least one declaration other than\n\t\t", 60),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_10)
};

Word * mercury_data_modules__common_12[] = {
	(Word *) string_const("To be useful, a module should export something.\n\t\t", 50),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_11)
};

Word * mercury_data_modules__common_13[] = {
	(Word *) string_const("\t\t", 2),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_12)
};

Word * mercury_data_modules__common_14[] = {
	(Word *) string_const(".garbs)\n\n", 9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_15[] = {
	(Word *) string_const(".os) $(MLLIBS)\n\n", 16),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_16[] = {
	(Word *) string_const(".split.a $(MLLIBS)\n\n", 20),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_17[] = {
	(Word *) string_const(".split.a\n\n", 10),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_18[] = {
	(Word *) string_const("_init.c\n\n", 9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_19[] = {
	(Word *) string_const(".nos)\n\n", 7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_20[] = {
	(Word *) string_const(".qls)\n\n", 7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_21[] = {
	(Word *) string_const(".optdates)\n\n", 12),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_22[] = {
	(Word *) string_const(".clean\n", 7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_23[] = {
	(Word *) string_const(".errs)\n", 7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_24[] = {
	(Word *) string_const("_garb.s\n\n", 9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_25[] = {
	(Word *) string_const(".realclean\n", 11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_26[] = {
	(Word *) string_const(".hs)\n", 5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_modules__common_27[] = {
	(Word *) string_const(".dep\n\n", 6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_modules__common_28[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_modules__common_29[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_modules__common_30[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0)
};

extern Word * mercury_data_prog_io__base_type_info_module_error_0[];
Word * mercury_data_modules__common_31[] = {
	(Word *) (Integer) mercury_data_prog_io__base_type_info_module_error_0
};

Word * mercury_data_modules__common_32[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_28),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_29),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_29),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_30),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_31),
	(Word *) string_const("module_imports", 14)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_modules__common_33[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data_modules__base_type_info_deps_0
};

Word * mercury_data_modules__common_34[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_33)
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_modules__common_35[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_modules__common_36[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_35),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_31),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_29),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_29),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_29),
	(Word *) string_const("deps", 4)
};

BEGIN_MODULE(mercury__modules_module0)
	init_entry(mercury____Index___modules_deps_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___modules_deps_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___modules_deps_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module1)
	init_entry(mercury____Index___modules_module_imports_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___modules_module_imports_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___modules_module_imports_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module2)
	init_entry(mercury__modules__read_mod_8_0);
	init_label(mercury__modules__read_mod_8_0_i2);
	init_label(mercury__modules__read_mod_8_0_i3);
	init_label(mercury__modules__read_mod_8_0_i4);
	init_label(mercury__modules__read_mod_8_0_i5);
	init_label(mercury__modules__read_mod_8_0_i6);
	init_label(mercury__modules__read_mod_8_0_i7);
	init_label(mercury__modules__read_mod_8_0_i8);
	init_label(mercury__modules__read_mod_8_0_i9);
	init_label(mercury__modules__read_mod_8_0_i10);
	init_label(mercury__modules__read_mod_8_0_i11);
	init_label(mercury__modules__read_mod_8_0_i15);
	init_label(mercury__modules__read_mod_8_0_i16);
	init_label(mercury__modules__read_mod_8_0_i12);
	init_label(mercury__modules__read_mod_8_0_i20);
	init_label(mercury__modules__read_mod_8_0_i21);
	init_label(mercury__modules__read_mod_8_0_i17);
	init_label(mercury__modules__read_mod_8_0_i22);
	init_label(mercury__modules__read_mod_8_0_i24);
	init_label(mercury__modules__read_mod_8_0_i25);
BEGIN_CODE

/* code for predicate 'read_mod'/8 in mode 0 */
Define_entry(mercury__modules__read_mod_8_0);
	incr_sp_push_msg(6, "read_mod");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__dir__basename_2_0);
	call_localret(ENTRY(mercury__dir__basename_2_0),
		mercury__modules__read_mod_8_0_i2,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__read_mod_8_0_i3,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 12);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__read_mod_8_0_i4,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	detstackvar(5) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% ", 2);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i5,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i6,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const(" `", 2);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i7,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i8,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("'... ", 5);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i9,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__passes_aux__maybe_flush_output_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__modules__read_mod_8_0_i10,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__prog_io__read_module_8_0);
	call_localret(ENTRY(mercury__prog_io__read_module_8_0),
		mercury__modules__read_mod_8_0_i11,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__modules__read_mod_8_0_i12);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("fatal error(s).\n", 16);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i15,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__modules__read_mod_8_0_i16,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i16);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__modules__read_mod_8_0_i24);
Define_label(mercury__modules__read_mod_8_0_i12);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__modules__read_mod_8_0_i17);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("parse error(s).\n", 16);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i20,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i20);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__modules__read_mod_8_0_i21,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i21);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__modules__read_mod_8_0_i24);
Define_label(mercury__modules__read_mod_8_0_i17);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("successful parse.\n", 18);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_8_0_i22,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i22);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
Define_label(mercury__modules__read_mod_8_0_i24);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__prog_out__write_messages_3_0);
	call_localret(ENTRY(mercury__prog_out__write_messages_3_0),
		mercury__modules__read_mod_8_0_i25,
		ENTRY(mercury__modules__read_mod_8_0));
	}
Define_label(mercury__modules__read_mod_8_0_i25);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module3)
	init_entry(mercury__modules__read_mod_ignore_errors_8_0);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i2);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i3);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i4);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i5);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i6);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i7);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i8);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i9);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i10);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i11);
	init_label(mercury__modules__read_mod_ignore_errors_8_0_i12);
BEGIN_CODE

/* code for predicate 'read_mod_ignore_errors'/8 in mode 0 */
Define_entry(mercury__modules__read_mod_ignore_errors_8_0);
	incr_sp_push_msg(7, "read_mod_ignore_errors");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__dir__basename_2_0);
	call_localret(ENTRY(mercury__dir__basename_2_0),
		mercury__modules__read_mod_ignore_errors_8_0_i2,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = ((Integer) 12);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i3,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	detstackvar(6) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% ", 2);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i4,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i5,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = string_const(" `", 2);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i6,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i7,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = string_const("'... ", 5);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i8,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__passes_aux__maybe_flush_output_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__modules__read_mod_ignore_errors_8_0_i9,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__read_mod_ignore_errors_8_0_i10,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__prog_io__read_module_8_0);
	call_localret(ENTRY(mercury__prog_io__read_module_8_0),
		mercury__modules__read_mod_ignore_errors_8_0_i11,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = string_const("done.\n", 6);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__read_mod_ignore_errors_8_0_i12,
		ENTRY(mercury__modules__read_mod_ignore_errors_8_0));
	}
Define_label(mercury__modules__read_mod_ignore_errors_8_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__read_mod_ignore_errors_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module4)
	init_entry(mercury__modules__make_interface_4_0);
	init_label(mercury__modules__make_interface_4_0_i2);
	init_label(mercury__modules__make_interface_4_0_i3);
	init_label(mercury__modules__make_interface_4_0_i4);
	init_label(mercury__modules__make_interface_4_0_i5);
	init_label(mercury__modules__make_interface_4_0_i6);
	init_label(mercury__modules__make_interface_4_0_i7);
	init_label(mercury__modules__make_interface_4_0_i8);
	init_label(mercury__modules__make_interface_4_0_i12);
	init_label(mercury__modules__make_interface_4_0_i13);
	init_label(mercury__modules__make_interface_4_0_i14);
	init_label(mercury__modules__make_interface_4_0_i20);
	init_label(mercury__modules__make_interface_4_0_i21);
	init_label(mercury__modules__make_interface_4_0_i22);
	init_label(mercury__modules__make_interface_4_0_i23);
	init_label(mercury__modules__make_interface_4_0_i24);
	init_label(mercury__modules__make_interface_4_0_i25);
BEGIN_CODE

/* code for predicate 'make_interface'/4 in mode 0 */
Define_entry(mercury__modules__make_interface_4_0);
	incr_sp_push_msg(6, "make_interface");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = ((Integer) 0);
	call_localret(STATIC(mercury__modules__get_interface_3_0),
		mercury__modules__make_interface_4_0_i2,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__modules__make_interface_4_0_i3,
		ENTRY(mercury__modules__make_interface_4_0));
	}
Define_label(mercury__modules__make_interface_4_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__modules__make_interface_4_0_i4,
		ENTRY(mercury__modules__make_interface_4_0));
	}
Define_label(mercury__modules__make_interface_4_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__modules__get_dependencies_2_0),
		mercury__modules__make_interface_4_0_i5,
		ENTRY(mercury__modules__make_interface_4_0));
	}
Define_label(mercury__modules__make_interface_4_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__make_interface_4_0_i6,
		ENTRY(mercury__modules__make_interface_4_0));
	}
	}
Define_label(mercury__modules__make_interface_4_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("mercury_builtin", 15);
	r2 = string_const(".int3", 5);
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 4)) = ((Integer) 0);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__process_module_short_interfaces_6_0),
		mercury__modules__make_interface_4_0_i7,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 4)) != ((Integer) 1)))
		GOTO_LABEL(mercury__modules__make_interface_4_0_i8);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Error reading short interface files.\n", 37);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".int and ", 9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_1);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	tailcall(ENTRY(mercury__io__write_strings_3_0),
		ENTRY(mercury__modules__make_interface_4_0));
	}
	}
Define_label(mercury__modules__make_interface_4_0_i8);
	r1 = (Integer) r3;
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 0);
	{
	Declare_entry(mercury__module_qual__module_qualify_items_9_0);
	call_localret(ENTRY(mercury__module_qual__module_qualify_items_9_0),
		mercury__modules__make_interface_4_0_i12,
		ENTRY(mercury__modules__make_interface_4_0));
	}
Define_label(mercury__modules__make_interface_4_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r5;
	{
	Declare_entry(mercury__io__get_exit_status_3_0);
	call_localret(ENTRY(mercury__io__get_exit_status_3_0),
		mercury__modules__make_interface_4_0_i13,
		ENTRY(mercury__modules__make_interface_4_0));
	}
Define_label(mercury__modules__make_interface_4_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__modules__make_interface_4_0_i14);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	tailcall(ENTRY(mercury__io__write_strings_3_0),
		ENTRY(mercury__modules__make_interface_4_0));
	}
Define_label(mercury__modules__make_interface_4_0_i14);
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__modules__strip_imported_items_3_0),
		mercury__modules__make_interface_4_0_i20,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i20);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__check_for_clauses_in_interface_4_0),
		mercury__modules__make_interface_4_0_i21,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i21);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__modules__check_for_no_exports_4_0),
		mercury__modules__make_interface_4_0_i22,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i22);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".int", 4);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_interface_file_5_0),
		mercury__modules__make_interface_4_0_i23,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i23);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__modules__get_short_interface_2_0),
		mercury__modules__make_interface_4_0_i24,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i24);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".int2", 5);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_interface_file_5_0),
		mercury__modules__make_interface_4_0_i25,
		ENTRY(mercury__modules__make_interface_4_0));
Define_label(mercury__modules__make_interface_4_0_i25);
	update_prof_current_proc(LABEL(mercury__modules__make_interface_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".date", 5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
		tailcall(STATIC(mercury__modules__touch_interface_datestamp_4_0),
		ENTRY(mercury__modules__make_interface_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module5)
	init_entry(mercury__modules__make_short_interface_4_0);
	init_label(mercury__modules__make_short_interface_4_0_i2);
	init_label(mercury__modules__make_short_interface_4_0_i3);
	init_label(mercury__modules__make_short_interface_4_0_i4);
	init_label(mercury__modules__make_short_interface_4_0_i5);
	init_label(mercury__modules__make_short_interface_4_0_i6);
BEGIN_CODE

/* code for predicate 'make_short_interface'/4 in mode 0 */
Define_entry(mercury__modules__make_short_interface_4_0);
	incr_sp_push_msg(3, "make_short_interface");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__modules__get_interface_3_0),
		mercury__modules__make_short_interface_4_0_i2,
		ENTRY(mercury__modules__make_short_interface_4_0));
Define_label(mercury__modules__make_short_interface_4_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__make_short_interface_4_0));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__check_for_clauses_in_interface_4_0),
		mercury__modules__make_short_interface_4_0_i3,
		ENTRY(mercury__modules__make_short_interface_4_0));
Define_label(mercury__modules__make_short_interface_4_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__make_short_interface_4_0));
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury__modules__get_short_interface_2_0),
		mercury__modules__make_short_interface_4_0_i4,
		ENTRY(mercury__modules__make_short_interface_4_0));
Define_label(mercury__modules__make_short_interface_4_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__make_short_interface_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__module_qual__module_qualify_items_9_0);
	call_localret(ENTRY(mercury__module_qual__module_qualify_items_9_0),
		mercury__modules__make_short_interface_4_0_i5,
		ENTRY(mercury__modules__make_short_interface_4_0));
	}
Define_label(mercury__modules__make_short_interface_4_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__make_short_interface_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".int3", 5);
	r4 = (Integer) r5;
	call_localret(STATIC(mercury__modules__write_interface_file_5_0),
		mercury__modules__make_short_interface_4_0_i6,
		ENTRY(mercury__modules__make_short_interface_4_0));
Define_label(mercury__modules__make_short_interface_4_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__make_short_interface_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".date3", 6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__modules__touch_interface_datestamp_4_0),
		ENTRY(mercury__modules__make_short_interface_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module6)
	init_entry(mercury__modules__grab_imported_modules_7_0);
	init_label(mercury__modules__grab_imported_modules_7_0_i2);
	init_label(mercury__modules__grab_imported_modules_7_0_i3);
	init_label(mercury__modules__grab_imported_modules_7_0_i4);
	init_label(mercury__modules__grab_imported_modules_7_0_i5);
	init_label(mercury__modules__grab_imported_modules_7_0_i6);
	init_label(mercury__modules__grab_imported_modules_7_0_i7);
	init_label(mercury__modules__grab_imported_modules_7_0_i8);
BEGIN_CODE

/* code for predicate 'grab_imported_modules'/7 in mode 0 */
Define_entry(mercury__modules__grab_imported_modules_7_0);
	incr_sp_push_msg(7, "grab_imported_modules");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__modules__get_dependencies_2_0),
		mercury__modules__grab_imported_modules_7_0_i2,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
	}
Define_label(mercury__modules__grab_imported_modules_7_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__modules__get_fact_table_dependencies_2_3_0),
		mercury__modules__grab_imported_modules_7_0_i3,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
Define_label(mercury__modules__grab_imported_modules_7_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__modules__grab_imported_modules_7_0_i4,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
	}
Define_label(mercury__modules__grab_imported_modules_7_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__term__context_init_3_0);
	call_localret(ENTRY(mercury__term__context_init_3_0),
		mercury__modules__grab_imported_modules_7_0_i5,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
	}
Define_label(mercury__modules__grab_imported_modules_7_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	r4 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 2)));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r4;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__grab_imported_modules_7_0_i6,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
	}
	}
Define_label(mercury__modules__grab_imported_modules_7_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__dir__basename_2_0);
	call_localret(ENTRY(mercury__dir__basename_2_0),
		mercury__modules__grab_imported_modules_7_0_i7,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
	}
Define_label(mercury__modules__grab_imported_modules_7_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("mercury_builtin", 15);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 4)) = ((Integer) 0);
	r4 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__modules__process_module_interfaces_6_0),
		mercury__modules__grab_imported_modules_7_0_i8,
		ENTRY(mercury__modules__grab_imported_modules_7_0));
	}
Define_label(mercury__modules__grab_imported_modules_7_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__grab_imported_modules_7_0));
	r4 = (Integer) r2;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module7)
	init_entry(mercury__modules__write_dependency_file_6_0);
	init_label(mercury__modules__write_dependency_file_6_0_i2);
	init_label(mercury__modules__write_dependency_file_6_0_i3);
	init_label(mercury__modules__write_dependency_file_6_0_i4);
	init_label(mercury__modules__write_dependency_file_6_0_i5);
	init_label(mercury__modules__write_dependency_file_6_0_i6);
	init_label(mercury__modules__write_dependency_file_6_0_i7);
	init_label(mercury__modules__write_dependency_file_6_0_i8);
	init_label(mercury__modules__write_dependency_file_6_0_i12);
	init_label(mercury__modules__write_dependency_file_6_0_i13);
	init_label(mercury__modules__write_dependency_file_6_0_i14);
	init_label(mercury__modules__write_dependency_file_6_0_i15);
	init_label(mercury__modules__write_dependency_file_6_0_i16);
	init_label(mercury__modules__write_dependency_file_6_0_i17);
	init_label(mercury__modules__write_dependency_file_6_0_i18);
	init_label(mercury__modules__write_dependency_file_6_0_i19);
	init_label(mercury__modules__write_dependency_file_6_0_i20);
	init_label(mercury__modules__write_dependency_file_6_0_i21);
	init_label(mercury__modules__write_dependency_file_6_0_i22);
	init_label(mercury__modules__write_dependency_file_6_0_i26);
	init_label(mercury__modules__write_dependency_file_6_0_i27);
	init_label(mercury__modules__write_dependency_file_6_0_i28);
	init_label(mercury__modules__write_dependency_file_6_0_i23);
	init_label(mercury__modules__write_dependency_file_6_0_i29);
	init_label(mercury__modules__write_dependency_file_6_0_i30);
	init_label(mercury__modules__write_dependency_file_6_0_i31);
	init_label(mercury__modules__write_dependency_file_6_0_i32);
	init_label(mercury__modules__write_dependency_file_6_0_i33);
	init_label(mercury__modules__write_dependency_file_6_0_i34);
	init_label(mercury__modules__write_dependency_file_6_0_i9);
	init_label(mercury__modules__write_dependency_file_6_0_i36);
BEGIN_CODE

/* code for predicate 'write_dependency_file'/6 in mode 0 */
Define_entry(mercury__modules__write_dependency_file_6_0);
	incr_sp_push_msg(7, "write_dependency_file");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = ((Integer) 11);
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__write_dependency_file_6_0_i2,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".d", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__write_dependency_file_6_0_i3,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("% Writing auto-dependency file `", 32);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__write_dependency_file_6_0_i4,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__write_dependency_file_6_0_i5,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("'...", 4);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__write_dependency_file_6_0_i6,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__passes_aux__maybe_flush_output_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__modules__write_dependency_file_6_0_i7,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__open_output_4_0);
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__modules__write_dependency_file_6_0_i8,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__modules__write_dependency_file_6_0_i9);
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__list__sort_and_remove_dups_2_0);
	call_localret(ENTRY(mercury__list__sort_and_remove_dups_2_0),
		mercury__modules__write_dependency_file_6_0_i12,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__modules__write_dependency_file_6_0_i13,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__list__sort_and_remove_dups_2_0);
	call_localret(ENTRY(mercury__list__sort_and_remove_dups_2_0),
		mercury__modules__write_dependency_file_6_0_i14,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i14);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__delete_elems_3_0);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__modules__write_dependency_file_6_0_i15,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__delete_all_3_1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__modules__write_dependency_file_6_0_i16,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i16);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__list__sort_and_remove_dups_2_0);
	call_localret(ENTRY(mercury__list__sort_and_remove_dups_2_0),
		mercury__modules__write_dependency_file_6_0_i17,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i17);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(".optdate ", 9);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".c ", 3);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".err ", 5);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const(".o : ", 5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) tempr1;
	r3 = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_3);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__write_dependency_file_6_0_i18,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
	}
Define_label(mercury__modules__write_dependency_file_6_0_i18);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".int", 4);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__write_dependency_file_6_0_i19,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i19);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".int2", 5);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__write_dependency_file_6_0_i20,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i20);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = string_const("", 0);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__write_dependency_file_6_0_i21,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i21);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 85);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__write_dependency_file_6_0_i22,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i22);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__write_dependency_file_6_0_i23);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("\n\n", 2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(".c ", 3);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".err ", 5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_4);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__write_dependency_file_6_0_i26,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
	}
Define_label(mercury__modules__write_dependency_file_6_0_i26);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__modules__get_curr_dir_deps_5_0),
		mercury__modules__write_dependency_file_6_0_i27,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i27);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	r4 = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r2 = string_const(".opt", 4);
	r3 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__write_dependency_file_6_0_i28,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i28);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("\n\n", 2);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const(".date : ", 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_3);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__modules__write_dependency_file_6_0_i29);
	}
Define_label(mercury__modules__write_dependency_file_6_0_i23);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) r2;
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("\n\n", 2);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const(".date : ", 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_3);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__modules__write_dependency_file_6_0_i29);
	detstackvar(1) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__write_dependency_file_6_0_i30,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i30);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".int3", 5);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__write_dependency_file_6_0_i31,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i31);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".int3", 5);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__write_dependency_file_6_0_i32,
		ENTRY(mercury__modules__write_dependency_file_6_0));
Define_label(mercury__modules__write_dependency_file_6_0_i32);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("\n\n", 2);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(".dir/", 5);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("_000.o: ", 8);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".m\n", 3);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("\trm -rf ", 8);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(".dir\n", 5);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\t$(MCS) -s$(GRADE) $(MCSFLAGS) ", 31);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_5);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__write_dependency_file_6_0_i33,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
	}
Define_label(mercury__modules__write_dependency_file_6_0_i33);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__close_output_3_0);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__modules__write_dependency_file_6_0_i34,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i34);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const(" done.\n", 7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	tailcall(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i9);
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("can't open file `", 17);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_6);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__modules__write_dependency_file_6_0_i36,
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
Define_label(mercury__modules__write_dependency_file_6_0_i36);
	update_prof_current_proc(LABEL(mercury__modules__write_dependency_file_6_0));
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__passes_aux__report_error_3_0);
	tailcall(ENTRY(mercury__passes_aux__report_error_3_0),
		ENTRY(mercury__modules__write_dependency_file_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module8)
	init_entry(mercury__modules__generate_dependencies_3_0);
	init_label(mercury__modules__generate_dependencies_3_0_i2);
	init_label(mercury__modules__generate_dependencies_3_0_i3);
	init_label(mercury__modules__generate_dependencies_3_0_i4);
	init_label(mercury__modules__generate_dependencies_3_0_i8);
	init_label(mercury__modules__generate_dependencies_3_0_i5);
	init_label(mercury__modules__generate_dependencies_3_0_i10);
	init_label(mercury__modules__generate_dependencies_3_0_i11);
	init_label(mercury__modules__generate_dependencies_3_0_i12);
	init_label(mercury__modules__generate_dependencies_3_0_i13);
	init_label(mercury__modules__generate_dependencies_3_0_i14);
	init_label(mercury__modules__generate_dependencies_3_0_i15);
	init_label(mercury__modules__generate_dependencies_3_0_i19);
	init_label(mercury__modules__generate_dependencies_3_0_i20);
	init_label(mercury__modules__generate_dependencies_3_0_i16);
	init_label(mercury__modules__generate_dependencies_3_0_i22);
BEGIN_CODE

/* code for predicate 'generate_dependencies'/3 in mode 0 */
Define_entry(mercury__modules__generate_dependencies_3_0);
	incr_sp_push_msg(5, "generate_dependencies");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__modules__generate_dependencies_3_0_i2,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__generate_deps_map_5_0),
		mercury__modules__generate_dependencies_3_0_i3,
		ENTRY(mercury__modules__generate_dependencies_3_0));
Define_label(mercury__modules__generate_dependencies_3_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modules__generate_dependencies_3_0_i4,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != ((Integer) 2)))
		GOTO_LABEL(mercury__modules__generate_dependencies_3_0_i5);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("fatal error reading module `", 28);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_7);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__modules__generate_dependencies_3_0_i8,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__passes_aux__report_error_3_0);
	tailcall(ENTRY(mercury__passes_aux__report_error_3_0),
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".dep", 4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__generate_dependencies_3_0_i10,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 11);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__generate_dependencies_3_0_i11,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	detstackvar(4) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% Creating auto-dependency file `", 33);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__generate_dependencies_3_0_i12,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__generate_dependencies_3_0_i13,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("'...\n", 5);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__generate_dependencies_3_0_i14,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i14);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__open_output_4_0);
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__modules__generate_dependencies_3_0_i15,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__modules__generate_dependencies_3_0_i16);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__generate_dep_file_5_0),
		mercury__modules__generate_dependencies_3_0_i19,
		ENTRY(mercury__modules__generate_dependencies_3_0));
Define_label(mercury__modules__generate_dependencies_3_0_i19);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__close_output_3_0);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__modules__generate_dependencies_3_0_i20,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i20);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% done\n", 7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	tailcall(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i16);
	detstackvar(1) = (Integer) r2;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("can't open file `", 17);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_6);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__modules__generate_dependencies_3_0_i22,
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
Define_label(mercury__modules__generate_dependencies_3_0_i22);
	update_prof_current_proc(LABEL(mercury__modules__generate_dependencies_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__passes_aux__report_error_3_0);
	tailcall(ENTRY(mercury__passes_aux__report_error_3_0),
		ENTRY(mercury__modules__generate_dependencies_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module9)
	init_entry(mercury__modules__get_dependencies_2_0);
BEGIN_CODE

/* code for predicate 'get_dependencies'/2 in mode 0 */
Define_entry(mercury__modules__get_dependencies_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__modules__get_dependencies_2_3_0),
		ENTRY(mercury__modules__get_dependencies_2_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module10)
	init_entry(mercury__modules__process_module_interfaces_6_0);
	init_label(mercury__modules__process_module_interfaces_6_0_i1016);
	init_label(mercury__modules__process_module_interfaces_6_0_i9);
	init_label(mercury__modules__process_module_interfaces_6_0_i13);
	init_label(mercury__modules__process_module_interfaces_6_0_i14);
	init_label(mercury__modules__process_module_interfaces_6_0_i15);
	init_label(mercury__modules__process_module_interfaces_6_0_i10);
	init_label(mercury__modules__process_module_interfaces_6_0_i1015);
	init_label(mercury__modules__process_module_interfaces_6_0_i21);
	init_label(mercury__modules__process_module_interfaces_6_0_i20);
	init_label(mercury__modules__process_module_interfaces_6_0_i24);
	init_label(mercury__modules__process_module_interfaces_6_0_i25);
	init_label(mercury__modules__process_module_interfaces_6_0_i30);
	init_label(mercury__modules__process_module_interfaces_6_0_i31);
	init_label(mercury__modules__process_module_interfaces_6_0_i36);
	init_label(mercury__modules__process_module_interfaces_6_0_i37);
	init_label(mercury__modules__process_module_interfaces_6_0_i38);
	init_label(mercury__modules__process_module_interfaces_6_0_i39);
	init_label(mercury__modules__process_module_interfaces_6_0_i40);
	init_label(mercury__modules__process_module_interfaces_6_0_i43);
	init_label(mercury__modules__process_module_interfaces_6_0_i44);
	init_label(mercury__modules__process_module_interfaces_6_0_i45);
	init_label(mercury__modules__process_module_interfaces_6_0_i1014);
BEGIN_CODE

/* code for predicate 'process_module_interfaces'/6 in mode 0 */
Define_entry(mercury__modules__process_module_interfaces_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i1014);
	r10 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r11 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r8 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r7 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r6 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	r5 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r9 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((strcmp((char *)(Integer) r11, (char *)(Integer) r9) !=0))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i1015);
	if ((strcmp((char *)(Integer) r9, (char *)string_const("mercury_builtin", 15)) !=0))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i1016);
	r1 = (Integer) r10;
	localtailcall(mercury__modules__process_module_interfaces_6_0,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
Define_label(mercury__modules__process_module_interfaces_6_0_i1016);
	incr_sp_push_msg(16, "process_module_interfaces");
	detstackvar(16) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(5) = (Integer) r10;
	detstackvar(6) = (Integer) r9;
	r1 = ((Integer) 0);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__process_module_interfaces_6_0_i9,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i10);
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(6);
	r2 = ((Integer) 1);
	{
	Declare_entry(mercury__term__context_init_3_0);
	call_localret(ENTRY(mercury__term__context_init_3_0),
		mercury__modules__process_module_interfaces_6_0_i13,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__modules__process_module_interfaces_6_0_i14,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i14);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	r2 = (Integer) r1;
	r1 = string_const("Warning: module imports itself!\n", 32);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__modules__process_module_interfaces_6_0_i15,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	localtailcall(mercury__modules__process_module_interfaces_6_0,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
Define_label(mercury__modules__process_module_interfaces_6_0_i10);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	localtailcall(mercury__modules__process_module_interfaces_6_0,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
Define_label(mercury__modules__process_module_interfaces_6_0_i1015);
	incr_sp_push_msg(16, "process_module_interfaces");
	detstackvar(16) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r11;
	detstackvar(5) = (Integer) r10;
	detstackvar(6) = (Integer) r9;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r7;
	detstackvar(9) = (Integer) r6;
	detstackvar(10) = (Integer) r5;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) r11;
	r3 = (Integer) r8;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__modules__process_module_interfaces_6_0_i21,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i21);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i20);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	localtailcall(mercury__modules__process_module_interfaces_6_0,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
Define_label(mercury__modules__process_module_interfaces_6_0_i20);
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".int", 4);
	r3 = string_const("Reading interface for module", 28);
	r4 = ((Integer) 0);
	r5 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__modules__read_mod_8_0),
		mercury__modules__process_module_interfaces_6_0_i24,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i24);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i25);
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i25);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i25);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i25);
	r10 = (Integer) r2;
	r11 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i30);
Define_label(mercury__modules__process_module_interfaces_6_0_i25);
	r10 = (Integer) r2;
	r11 = (Integer) r1;
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
Define_label(mercury__modules__process_module_interfaces_6_0_i30);
	if (((Integer) r10 == ((Integer) 0)))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i31);
	r9 = (Integer) r8;
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = ((Integer) 14);
	r12 = ((Integer) 1);
	GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i36);
Define_label(mercury__modules__process_module_interfaces_6_0_i31);
	r12 = (Integer) r9;
	r9 = (Integer) r8;
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = ((Integer) 14);
Define_label(mercury__modules__process_module_interfaces_6_0_i36);
	detstackvar(1) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(2) = (Integer) r10;
	detstackvar(3) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__process_module_interfaces_6_0_i37,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i37);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	{
	Declare_entry(mercury__passes_aux__maybe_report_stats_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_report_stats_3_0),
		mercury__modules__process_module_interfaces_6_0_i38,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i38);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__modules__get_dependencies_2_0),
		mercury__modules__process_module_interfaces_6_0_i39,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i39);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	if (((Integer) detstackvar(2) != ((Integer) 2)))
		GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i40);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(11);
	r3 = (Integer) r1;
	r10 = (Integer) detstackvar(7);
	r11 = (Integer) detstackvar(15);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	GOTO_LABEL(mercury__modules__process_module_interfaces_6_0_i43);
Define_label(mercury__modules__process_module_interfaces_6_0_i40);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(3);
	r9 = (Integer) detstackvar(11);
	r3 = (Integer) r1;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) detstackvar(7);
	r11 = (Integer) detstackvar(15);
	r1 = (Integer) mercury_data___base_type_info_string_0;
Define_label(mercury__modules__process_module_interfaces_6_0_i43);
	detstackvar(5) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(3) = (Integer) r8;
	detstackvar(11) = (Integer) r9;
	detstackvar(12) = (Integer) r10;
	detstackvar(15) = (Integer) r11;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__process_module_interfaces_6_0_i44,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i44);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__process_module_interfaces_6_0_i45,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_interfaces_6_0_i45);
	update_prof_current_proc(LABEL(mercury__modules__process_module_interfaces_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(13);
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	localtailcall(mercury__modules__process_module_interfaces_6_0,
		ENTRY(mercury__modules__process_module_interfaces_6_0));
Define_label(mercury__modules__process_module_interfaces_6_0_i1014);
	r1 = (Integer) r2;
	r2 = string_const(".int2", 5);
	tailcall(STATIC(mercury__modules__process_module_short_interfaces_6_0),
		ENTRY(mercury__modules__process_module_interfaces_6_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module11)
	init_entry(mercury__modules__touch_interface_datestamp_4_0);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i2);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i3);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i4);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i5);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i6);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i7);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i8);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i12);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i13);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i9);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i15);
	init_label(mercury__modules__touch_interface_datestamp_4_0_i16);
BEGIN_CODE

/* code for predicate 'touch_interface_datestamp'/4 in mode 0 */
Define_entry(mercury__modules__touch_interface_datestamp_4_0);
	incr_sp_push_msg(3, "touch_interface_datestamp");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__touch_interface_datestamp_4_0_i2,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 11);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__touch_interface_datestamp_4_0_i3,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% Touching `", 12);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__touch_interface_datestamp_4_0_i4,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__touch_interface_datestamp_4_0_i5,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("'... ", 5);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__touch_interface_datestamp_4_0_i6,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__passes_aux__maybe_flush_output_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__modules__touch_interface_datestamp_4_0_i7,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__open_output_4_0);
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__modules__touch_interface_datestamp_4_0_i8,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__modules__touch_interface_datestamp_4_0_i9);
	r3 = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__touch_interface_datestamp_4_0_i12,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__close_output_3_0);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__modules__touch_interface_datestamp_4_0_i13,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(" done.\n", 7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	tailcall(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i9);
	r1 = string_const("\nError opening `", 16);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__modules__touch_interface_datestamp_4_0_i15,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__modules__touch_interface_datestamp_4_0_i16,
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
Define_label(mercury__modules__touch_interface_datestamp_4_0_i16);
	update_prof_current_proc(LABEL(mercury__modules__touch_interface_datestamp_4_0));
	r2 = (Integer) r1;
	r1 = string_const("' for output\n", 13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__modules__touch_interface_datestamp_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module12)
	init_entry(mercury__modules__update_interface_3_0);
	init_label(mercury__modules__update_interface_3_0_i2);
	init_label(mercury__modules__update_interface_3_0_i3);
	init_label(mercury__modules__update_interface_3_0_i4);
	init_label(mercury__modules__update_interface_3_0_i7);
	init_label(mercury__modules__update_interface_3_0_i8);
	init_label(mercury__modules__update_interface_3_0_i9);
	init_label(mercury__modules__update_interface_3_0_i1000);
BEGIN_CODE

/* code for predicate 'update_interface'/3 in mode 0 */
Define_entry(mercury__modules__update_interface_3_0);
	incr_sp_push_msg(3, "update_interface");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 11);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__update_interface_3_0_i2,
		ENTRY(mercury__modules__update_interface_3_0));
	}
Define_label(mercury__modules__update_interface_3_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__update_interface_3_0));
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% Updating interface:\n", 22);
	{
	Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__modules__update_interface_3_0_i3,
		ENTRY(mercury__modules__update_interface_3_0));
	}
Define_label(mercury__modules__update_interface_3_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__update_interface_3_0));
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__update_interface_3_0_i4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = string_const("mercury_update_interface -v ", 28);
	GOTO_LABEL(mercury__modules__update_interface_3_0_i7);
Define_label(mercury__modules__update_interface_3_0_i4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = string_const("mercury_update_interface ", 25);
Define_label(mercury__modules__update_interface_3_0_i7);
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__update_interface_3_0_i8,
		ENTRY(mercury__modules__update_interface_3_0));
	}
Define_label(mercury__modules__update_interface_3_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__update_interface_3_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__passes_aux__invoke_system_command_4_0);
	call_localret(ENTRY(mercury__passes_aux__invoke_system_command_4_0),
		mercury__modules__update_interface_3_0_i9,
		ENTRY(mercury__modules__update_interface_3_0));
	}
Define_label(mercury__modules__update_interface_3_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__update_interface_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__modules__update_interface_3_0_i1000);
	r1 = string_const("problem updating interface files.", 33);
	{
	Declare_entry(mercury__passes_aux__report_error_3_0);
	tailcall(ENTRY(mercury__passes_aux__report_error_3_0),
		ENTRY(mercury__modules__update_interface_3_0));
	}
Define_label(mercury__modules__update_interface_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module13)
	init_entry(mercury__modules__strip_imported_items_3_0);
	init_label(mercury__modules__strip_imported_items_3_0_i1008);
	init_label(mercury__modules__strip_imported_items_3_0_i1007);
BEGIN_CODE

/* code for predicate 'strip_imported_items'/3 in mode 0 */
Define_static(mercury__modules__strip_imported_items_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__strip_imported_items_3_0_i1007);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r5 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__strip_imported_items_3_0_i1008);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__strip_imported_items_3_0_i1008);
	if (((Integer) field(mktag(3), (Integer) r5, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury__modules__strip_imported_items_3_0_i1008);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__modules__strip_imported_items_3_0));
	}
Define_label(mercury__modules__strip_imported_items_3_0_i1008);
	incr_sp_push_msg(1, "strip_imported_items");
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) tempr1;
	r1 = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	decr_sp_pop_msg(1);
	localtailcall(mercury__modules__strip_imported_items_3_0,
		STATIC(mercury__modules__strip_imported_items_3_0));
	}
Define_label(mercury__modules__strip_imported_items_3_0_i1007);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__modules__strip_imported_items_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module14)
	init_entry(mercury__modules__check_for_clauses_in_interface_4_0);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i1006);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i6);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i9);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i10);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i4);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i12);
	init_label(mercury__modules__check_for_clauses_in_interface_4_0_i1004);
BEGIN_CODE

/* code for predicate 'check_for_clauses_in_interface'/4 in mode 0 */
Define_static(mercury__modules__check_for_clauses_in_interface_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__check_for_clauses_in_interface_4_0_i1004);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__modules__check_for_clauses_in_interface_4_0_i1006);
	r3 = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	incr_sp_push_msg(2, "check_for_clauses_in_interface");
	detstackvar(2) = (Integer) succip;
	GOTO_LABEL(mercury__modules__check_for_clauses_in_interface_4_0_i6);
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i1006);
	incr_sp_push_msg(2, "check_for_clauses_in_interface");
	detstackvar(2) = (Integer) succip;
	if ((tag((Integer) r5) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__modules__check_for_clauses_in_interface_4_0_i4);
	r3 = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i6);
	detstackvar(1) = (Integer) r4;
	{
	Declare_entry(mercury__prog_out__write_context_3_0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__modules__check_for_clauses_in_interface_4_0_i9,
		STATIC(mercury__modules__check_for_clauses_in_interface_4_0));
	}
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__check_for_clauses_in_interface_4_0));
	r2 = (Integer) r1;
	r1 = string_const("Warning: clause in module interface.\n", 37);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__modules__check_for_clauses_in_interface_4_0_i10,
		STATIC(mercury__modules__check_for_clauses_in_interface_4_0));
	}
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__check_for_clauses_in_interface_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__modules__check_for_clauses_in_interface_4_0,
		STATIC(mercury__modules__check_for_clauses_in_interface_4_0));
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i4);
	detstackvar(1) = (Integer) r4;
	r1 = (Integer) r3;
	localcall(mercury__modules__check_for_clauses_in_interface_4_0,
		LABEL(mercury__modules__check_for_clauses_in_interface_4_0_i12),
		STATIC(mercury__modules__check_for_clauses_in_interface_4_0));
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__check_for_clauses_in_interface_4_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__modules__check_for_clauses_in_interface_4_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module15)
	init_entry(mercury__modules__check_for_no_exports_4_0);
	init_label(mercury__modules__check_for_no_exports_4_0_i1014);
	init_label(mercury__modules__check_for_no_exports_4_0_i4);
	init_label(mercury__modules__check_for_no_exports_4_0_i1013);
	init_label(mercury__modules__check_for_no_exports_4_0_i11);
	init_label(mercury__modules__check_for_no_exports_4_0_i15);
	init_label(mercury__modules__check_for_no_exports_4_0_i16);
	init_label(mercury__modules__check_for_no_exports_4_0_i20);
	init_label(mercury__modules__check_for_no_exports_4_0_i17);
	init_label(mercury__modules__check_for_no_exports_4_0_i12);
	init_label(mercury__modules__check_for_no_exports_4_0_i1009);
BEGIN_CODE

/* code for predicate 'check_for_no_exports'/4 in mode 0 */
Define_static(mercury__modules__check_for_no_exports_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__check_for_no_exports_4_0_i1013);
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__check_for_no_exports_4_0_i1014);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localtailcall(mercury__modules__check_for_no_exports_4_0,
		STATIC(mercury__modules__check_for_no_exports_4_0));
Define_label(mercury__modules__check_for_no_exports_4_0_i1014);
	incr_sp_push_msg(2, "check_for_no_exports");
	detstackvar(2) = (Integer) succip;
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) tempr2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__check_for_no_exports_4_0_i4);
	decr_sp_pop_msg(2);
	if (((Integer) field(mktag(3), (Integer) tempr2, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__check_for_no_exports_4_0_i1009);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localtailcall(mercury__modules__check_for_no_exports_4_0,
		STATIC(mercury__modules__check_for_no_exports_4_0));
	}
Define_label(mercury__modules__check_for_no_exports_4_0_i4);
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__modules__check_for_no_exports_4_0_i1013);
	incr_sp_push_msg(2, "check_for_no_exports");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r1 = ((Integer) 6);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__check_for_no_exports_4_0_i11,
		STATIC(mercury__modules__check_for_no_exports_4_0));
	}
Define_label(mercury__modules__check_for_no_exports_4_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__check_for_no_exports_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__check_for_no_exports_4_0_i12);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = ((Integer) 1);
	r3 = string_const("interface does not export anything.", 35);
	{
	Declare_entry(mercury__prog_io__report_warning_5_0);
	call_localret(ENTRY(mercury__prog_io__report_warning_5_0),
		mercury__modules__check_for_no_exports_4_0_i15,
		STATIC(mercury__modules__check_for_no_exports_4_0));
	}
Define_label(mercury__modules__check_for_no_exports_4_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__check_for_no_exports_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 13);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__check_for_no_exports_4_0_i16,
		STATIC(mercury__modules__check_for_no_exports_4_0));
	}
Define_label(mercury__modules__check_for_no_exports_4_0_i16);
	update_prof_current_proc(LABEL(mercury__modules__check_for_no_exports_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__check_for_no_exports_4_0_i17);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__modules__check_for_no_exports_4_0_i20,
		STATIC(mercury__modules__check_for_no_exports_4_0));
	}
Define_label(mercury__modules__check_for_no_exports_4_0_i20);
	update_prof_current_proc(LABEL(mercury__modules__check_for_no_exports_4_0));
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_13);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	tailcall(ENTRY(mercury__io__write_strings_4_0),
		STATIC(mercury__modules__check_for_no_exports_4_0));
	}
Define_label(mercury__modules__check_for_no_exports_4_0_i17);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__modules__check_for_no_exports_4_0_i12);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__modules__check_for_no_exports_4_0_i1009);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module16)
	init_entry(mercury__modules__write_interface_file_5_0);
	init_label(mercury__modules__write_interface_file_5_0_i2);
	init_label(mercury__modules__write_interface_file_5_0_i3);
	init_label(mercury__modules__write_interface_file_5_0_i4);
	init_label(mercury__modules__write_interface_file_5_0_i5);
	init_label(mercury__modules__write_interface_file_5_0_i6);
	init_label(mercury__modules__write_interface_file_5_0_i7);
BEGIN_CODE

/* code for predicate 'write_interface_file'/5 in mode 0 */
Define_static(mercury__modules__write_interface_file_5_0);
	incr_sp_push_msg(7, "write_interface_file");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__write_interface_file_5_0_i2,
		STATIC(mercury__modules__write_interface_file_5_0));
	}
Define_label(mercury__modules__write_interface_file_5_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__write_interface_file_5_0));
	detstackvar(4) = (Integer) r1;
	r2 = string_const(".tmp", 4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__write_interface_file_5_0_i3,
		STATIC(mercury__modules__write_interface_file_5_0));
	}
Define_label(mercury__modules__write_interface_file_5_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__write_interface_file_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__dir__basename_2_0);
	call_localret(ENTRY(mercury__dir__basename_2_0),
		mercury__modules__write_interface_file_5_0_i4,
		STATIC(mercury__modules__write_interface_file_5_0));
	}
Define_label(mercury__modules__write_interface_file_5_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__write_interface_file_5_0));
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__varset__init_1_0);
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__modules__write_interface_file_5_0_i5,
		STATIC(mercury__modules__write_interface_file_5_0));
	}
Define_label(mercury__modules__write_interface_file_5_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__write_interface_file_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 0);
	{
	Declare_entry(mercury__term__context_init_3_0);
	call_localret(ENTRY(mercury__term__context_init_3_0),
		mercury__modules__write_interface_file_5_0_i6,
		STATIC(mercury__modules__write_interface_file_5_0));
	}
Define_label(mercury__modules__write_interface_file_5_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__write_interface_file_5_0));
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 3));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	r4 = (Integer) detstackvar(3);
	field(mktag(3), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__mercury_to_mercury__convert_to_mercury_5_0);
	call_localret(ENTRY(mercury__mercury_to_mercury__convert_to_mercury_5_0),
		mercury__modules__write_interface_file_5_0_i7,
		STATIC(mercury__modules__write_interface_file_5_0));
	}
	}
Define_label(mercury__modules__write_interface_file_5_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__write_interface_file_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
		tailcall(STATIC(mercury__modules__update_interface_3_0),
		STATIC(mercury__modules__write_interface_file_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module17)
	init_entry(mercury__modules__get_curr_dir_deps_5_0);
	init_label(mercury__modules__get_curr_dir_deps_5_0_i4);
	init_label(mercury__modules__get_curr_dir_deps_5_0_i5);
	init_label(mercury__modules__get_curr_dir_deps_5_0_i9);
	init_label(mercury__modules__get_curr_dir_deps_5_0_i6);
	init_label(mercury__modules__get_curr_dir_deps_5_0_i1003);
BEGIN_CODE

/* code for predicate 'get_curr_dir_deps'/5 in mode 0 */
Define_static(mercury__modules__get_curr_dir_deps_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_curr_dir_deps_5_0_i1003);
	incr_sp_push_msg(5, "get_curr_dir_deps");
	detstackvar(5) = (Integer) succip;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	r2 = string_const(".m", 2);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__get_curr_dir_deps_5_0_i4,
		STATIC(mercury__modules__get_curr_dir_deps_5_0));
	}
Define_label(mercury__modules__get_curr_dir_deps_5_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__get_curr_dir_deps_5_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__see_4_0);
	call_localret(ENTRY(mercury__io__see_4_0),
		mercury__modules__get_curr_dir_deps_5_0_i5,
		STATIC(mercury__modules__get_curr_dir_deps_5_0));
	}
Define_label(mercury__modules__get_curr_dir_deps_5_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__get_curr_dir_deps_5_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_curr_dir_deps_5_0_i6);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__seen_2_0);
	call_localret(ENTRY(mercury__io__seen_2_0),
		mercury__modules__get_curr_dir_deps_5_0_i9,
		STATIC(mercury__modules__get_curr_dir_deps_5_0));
	}
Define_label(mercury__modules__get_curr_dir_deps_5_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__get_curr_dir_deps_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__modules__get_curr_dir_deps_5_0,
		STATIC(mercury__modules__get_curr_dir_deps_5_0));
Define_label(mercury__modules__get_curr_dir_deps_5_0_i6);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__modules__get_curr_dir_deps_5_0,
		STATIC(mercury__modules__get_curr_dir_deps_5_0));
Define_label(mercury__modules__get_curr_dir_deps_5_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module18)
	init_entry(mercury__modules__generate_deps_map_5_0);
	init_label(mercury__modules__generate_deps_map_5_0_i4);
	init_label(mercury__modules__generate_deps_map_5_0_i8);
	init_label(mercury__modules__generate_deps_map_5_0_i9);
	init_label(mercury__modules__generate_deps_map_5_0_i10);
	init_label(mercury__modules__generate_deps_map_5_0_i11);
	init_label(mercury__modules__generate_deps_map_5_0_i17);
	init_label(mercury__modules__generate_deps_map_5_0_i12);
	init_label(mercury__modules__generate_deps_map_5_0_i18);
	init_label(mercury__modules__generate_deps_map_5_0_i19);
	init_label(mercury__modules__generate_deps_map_5_0_i5);
	init_label(mercury__modules__generate_deps_map_5_0_i1004);
BEGIN_CODE

/* code for predicate 'generate_deps_map'/5 in mode 0 */
Define_static(mercury__modules__generate_deps_map_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__generate_deps_map_5_0_i1004);
	incr_sp_push_msg(8, "generate_deps_map");
	detstackvar(8) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r4 = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__modules__lookup_dependencies_11_0),
		mercury__modules__generate_deps_map_5_0_i4,
		STATIC(mercury__modules__generate_deps_map_5_0));
Define_label(mercury__modules__generate_deps_map_5_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__modules__generate_deps_map_5_0_i5);
	detstackvar(5) = (Integer) r5;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	r5 = (Integer) tempr1;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	r3 = (Integer) r6;
	r4 = (Integer) detstackvar(1);
	detstackvar(7) = (Integer) r7;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = ((Integer) 0);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__modules__generate_deps_map_5_0_i8,
		STATIC(mercury__modules__generate_deps_map_5_0));
	}
	}
Define_label(mercury__modules__generate_deps_map_5_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__modules__generate_deps_map_5_0_i9,
		STATIC(mercury__modules__generate_deps_map_5_0));
	}
Define_label(mercury__modules__generate_deps_map_5_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	r4 = ((Integer) 1);
	r5 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__modules__transitive_dependencies_2_8_0),
		mercury__modules__generate_deps_map_5_0_i10,
		STATIC(mercury__modules__generate_deps_map_5_0));
Define_label(mercury__modules__generate_deps_map_5_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	detstackvar(7) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__modules__generate_deps_map_5_0_i11,
		STATIC(mercury__modules__generate_deps_map_5_0));
	}
Define_label(mercury__modules__generate_deps_map_5_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	if (((Integer) detstackvar(3) == ((Integer) 2)))
		GOTO_LABEL(mercury__modules__generate_deps_map_5_0_i12);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(7);
	{
		call_localret(STATIC(mercury__modules__write_dependency_file_6_0),
		mercury__modules__generate_deps_map_5_0_i17,
		STATIC(mercury__modules__generate_deps_map_5_0));
	}
Define_label(mercury__modules__generate_deps_map_5_0_i17);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	GOTO_LABEL(mercury__modules__generate_deps_map_5_0_i18);
Define_label(mercury__modules__generate_deps_map_5_0_i12);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r1 = (Integer) mercury_data___base_type_info_string_0;
Define_label(mercury__modules__generate_deps_map_5_0_i18);
	detstackvar(6) = (Integer) r4;
	detstackvar(1) = (Integer) r5;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__generate_deps_map_5_0_i19,
		STATIC(mercury__modules__generate_deps_map_5_0));
	}
Define_label(mercury__modules__generate_deps_map_5_0_i19);
	update_prof_current_proc(LABEL(mercury__modules__generate_deps_map_5_0));
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__modules__generate_deps_map_5_0,
		STATIC(mercury__modules__generate_deps_map_5_0));
Define_label(mercury__modules__generate_deps_map_5_0_i5);
	r2 = (Integer) r6;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury__modules__generate_deps_map_5_0,
		STATIC(mercury__modules__generate_deps_map_5_0));
Define_label(mercury__modules__generate_deps_map_5_0_i1004);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module19)
	init_entry(mercury__modules__generate_dep_file_5_0);
	init_label(mercury__modules__generate_dep_file_5_0_i2);
	init_label(mercury__modules__generate_dep_file_5_0_i3);
	init_label(mercury__modules__generate_dep_file_5_0_i4);
	init_label(mercury__modules__generate_dep_file_5_0_i5);
	init_label(mercury__modules__generate_dep_file_5_0_i6);
	init_label(mercury__modules__generate_dep_file_5_0_i7);
	init_label(mercury__modules__generate_dep_file_5_0_i8);
	init_label(mercury__modules__generate_dep_file_5_0_i9);
	init_label(mercury__modules__generate_dep_file_5_0_i10);
	init_label(mercury__modules__generate_dep_file_5_0_i11);
	init_label(mercury__modules__generate_dep_file_5_0_i12);
	init_label(mercury__modules__generate_dep_file_5_0_i13);
	init_label(mercury__modules__generate_dep_file_5_0_i14);
	init_label(mercury__modules__generate_dep_file_5_0_i15);
	init_label(mercury__modules__generate_dep_file_5_0_i17);
	init_label(mercury__modules__generate_dep_file_5_0_i18);
	init_label(mercury__modules__generate_dep_file_5_0_i16);
	init_label(mercury__modules__generate_dep_file_5_0_i19);
	init_label(mercury__modules__generate_dep_file_5_0_i20);
	init_label(mercury__modules__generate_dep_file_5_0_i21);
	init_label(mercury__modules__generate_dep_file_5_0_i22);
	init_label(mercury__modules__generate_dep_file_5_0_i23);
	init_label(mercury__modules__generate_dep_file_5_0_i24);
	init_label(mercury__modules__generate_dep_file_5_0_i25);
	init_label(mercury__modules__generate_dep_file_5_0_i26);
	init_label(mercury__modules__generate_dep_file_5_0_i27);
	init_label(mercury__modules__generate_dep_file_5_0_i28);
	init_label(mercury__modules__generate_dep_file_5_0_i29);
	init_label(mercury__modules__generate_dep_file_5_0_i30);
	init_label(mercury__modules__generate_dep_file_5_0_i31);
	init_label(mercury__modules__generate_dep_file_5_0_i32);
	init_label(mercury__modules__generate_dep_file_5_0_i33);
	init_label(mercury__modules__generate_dep_file_5_0_i34);
	init_label(mercury__modules__generate_dep_file_5_0_i35);
	init_label(mercury__modules__generate_dep_file_5_0_i36);
	init_label(mercury__modules__generate_dep_file_5_0_i37);
	init_label(mercury__modules__generate_dep_file_5_0_i38);
	init_label(mercury__modules__generate_dep_file_5_0_i39);
	init_label(mercury__modules__generate_dep_file_5_0_i40);
	init_label(mercury__modules__generate_dep_file_5_0_i41);
	init_label(mercury__modules__generate_dep_file_5_0_i42);
	init_label(mercury__modules__generate_dep_file_5_0_i43);
	init_label(mercury__modules__generate_dep_file_5_0_i44);
	init_label(mercury__modules__generate_dep_file_5_0_i45);
	init_label(mercury__modules__generate_dep_file_5_0_i46);
	init_label(mercury__modules__generate_dep_file_5_0_i47);
	init_label(mercury__modules__generate_dep_file_5_0_i48);
	init_label(mercury__modules__generate_dep_file_5_0_i49);
	init_label(mercury__modules__generate_dep_file_5_0_i50);
	init_label(mercury__modules__generate_dep_file_5_0_i51);
	init_label(mercury__modules__generate_dep_file_5_0_i52);
	init_label(mercury__modules__generate_dep_file_5_0_i53);
	init_label(mercury__modules__generate_dep_file_5_0_i54);
	init_label(mercury__modules__generate_dep_file_5_0_i55);
	init_label(mercury__modules__generate_dep_file_5_0_i56);
	init_label(mercury__modules__generate_dep_file_5_0_i57);
	init_label(mercury__modules__generate_dep_file_5_0_i58);
	init_label(mercury__modules__generate_dep_file_5_0_i59);
	init_label(mercury__modules__generate_dep_file_5_0_i60);
	init_label(mercury__modules__generate_dep_file_5_0_i61);
	init_label(mercury__modules__generate_dep_file_5_0_i62);
	init_label(mercury__modules__generate_dep_file_5_0_i63);
	init_label(mercury__modules__generate_dep_file_5_0_i64);
	init_label(mercury__modules__generate_dep_file_5_0_i65);
	init_label(mercury__modules__generate_dep_file_5_0_i66);
	init_label(mercury__modules__generate_dep_file_5_0_i67);
	init_label(mercury__modules__generate_dep_file_5_0_i68);
	init_label(mercury__modules__generate_dep_file_5_0_i69);
	init_label(mercury__modules__generate_dep_file_5_0_i70);
	init_label(mercury__modules__generate_dep_file_5_0_i71);
	init_label(mercury__modules__generate_dep_file_5_0_i72);
	init_label(mercury__modules__generate_dep_file_5_0_i73);
	init_label(mercury__modules__generate_dep_file_5_0_i74);
	init_label(mercury__modules__generate_dep_file_5_0_i75);
	init_label(mercury__modules__generate_dep_file_5_0_i76);
	init_label(mercury__modules__generate_dep_file_5_0_i77);
	init_label(mercury__modules__generate_dep_file_5_0_i78);
	init_label(mercury__modules__generate_dep_file_5_0_i79);
	init_label(mercury__modules__generate_dep_file_5_0_i80);
	init_label(mercury__modules__generate_dep_file_5_0_i81);
	init_label(mercury__modules__generate_dep_file_5_0_i82);
	init_label(mercury__modules__generate_dep_file_5_0_i83);
	init_label(mercury__modules__generate_dep_file_5_0_i84);
	init_label(mercury__modules__generate_dep_file_5_0_i85);
	init_label(mercury__modules__generate_dep_file_5_0_i86);
	init_label(mercury__modules__generate_dep_file_5_0_i87);
	init_label(mercury__modules__generate_dep_file_5_0_i88);
	init_label(mercury__modules__generate_dep_file_5_0_i89);
	init_label(mercury__modules__generate_dep_file_5_0_i90);
	init_label(mercury__modules__generate_dep_file_5_0_i91);
	init_label(mercury__modules__generate_dep_file_5_0_i95);
	init_label(mercury__modules__generate_dep_file_5_0_i96);
	init_label(mercury__modules__generate_dep_file_5_0_i97);
	init_label(mercury__modules__generate_dep_file_5_0_i98);
	init_label(mercury__modules__generate_dep_file_5_0_i99);
	init_label(mercury__modules__generate_dep_file_5_0_i100);
	init_label(mercury__modules__generate_dep_file_5_0_i92);
	init_label(mercury__modules__generate_dep_file_5_0_i101);
	init_label(mercury__modules__generate_dep_file_5_0_i105);
	init_label(mercury__modules__generate_dep_file_5_0_i102);
	init_label(mercury__modules__generate_dep_file_5_0_i110);
	init_label(mercury__modules__generate_dep_file_5_0_i107);
	init_label(mercury__modules__generate_dep_file_5_0_i111);
	init_label(mercury__modules__generate_dep_file_5_0_i112);
	init_label(mercury__modules__generate_dep_file_5_0_i113);
	init_label(mercury__modules__generate_dep_file_5_0_i114);
	init_label(mercury__modules__generate_dep_file_5_0_i115);
	init_label(mercury__modules__generate_dep_file_5_0_i116);
	init_label(mercury__modules__generate_dep_file_5_0_i117);
	init_label(mercury__modules__generate_dep_file_5_0_i118);
	init_label(mercury__modules__generate_dep_file_5_0_i119);
	init_label(mercury__modules__generate_dep_file_5_0_i120);
	init_label(mercury__modules__generate_dep_file_5_0_i124);
	init_label(mercury__modules__generate_dep_file_5_0_i121);
	init_label(mercury__modules__generate_dep_file_5_0_i125);
	init_label(mercury__modules__generate_dep_file_5_0_i126);
	init_label(mercury__modules__generate_dep_file_5_0_i127);
	init_label(mercury__modules__generate_dep_file_5_0_i128);
	init_label(mercury__modules__generate_dep_file_5_0_i129);
	init_label(mercury__modules__generate_dep_file_5_0_i130);
BEGIN_CODE

/* code for predicate 'generate_dep_file'/5 in mode 0 */
Define_static(mercury__modules__generate_dep_file_5_0);
	incr_sp_push_msg(6, "generate_dep_file");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r3;
	r2 = string_const("# Automatically generated dependencies for module `", 51);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i2,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i3,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("'.\n", 3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i4,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__modules__generate_dep_file_5_0_i5,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("# Generated by the Mercury compiler, version ", 45);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i6,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i7,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".\n\n", 3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i8,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__modules__generate_dep_file_5_0_i9,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__modules__select_ok_modules_3_0),
		mercury__modules__generate_dep_file_5_0_i10,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i11,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".ms =", 5);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i12,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i12);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".m", 2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__generate_dep_file_5_0_i13,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i14,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i14);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 30);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__generate_dep_file_5_0_i15,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i17);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i16);
Define_label(mercury__modules__generate_dep_file_5_0_i17);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".ms", 3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__modules__generate_dep_file_5_0_i18,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i18);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	tag_incr_hp(r5, mktag(1), ((Integer) 1));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = string_const(".m", 2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r6;
	r6 = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	}
Define_label(mercury__modules__generate_dep_file_5_0_i16);
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	call_localret(STATIC(mercury__modules__get_extra_link_objects_3_0),
		mercury__modules__generate_dep_file_5_0_i19,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i19);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i20,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i20);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".nos = ", 7);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i21,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i21);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".no", 3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i22,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i22);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i23,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i23);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i24,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i24);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".qls = ", 7);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i25,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i25);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".ql", 3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i26,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i26);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i27,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i27);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i28,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i28);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".cs = ", 6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i29,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i29);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".c", 2);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i30,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i30);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i31,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i31);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i32,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i32);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".os = ", 6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i33,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i33);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".o", 2);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i34,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i34);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const(".o", 2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_dependencies_list_5_0),
		mercury__modules__generate_dep_file_5_0_i35,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i35);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i36,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i36);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i37,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i37);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".pic_os = ", 10);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i38,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i38);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".$(EXT_FOR_PIC_OBJECTS)", 23);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i39,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i39);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i40,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i40);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i41,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i41);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".dirs = ", 8);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i42,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i42);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".dir", 4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i43,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i43);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i44,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i44);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i45,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i45);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".dir_os = ", 10);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i46,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i46);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".dir/*.o", 8);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i47,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i47);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i48,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i48);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i49,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i49);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".ss = ", 6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i50,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i50);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".s", 2);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i51,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i51);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i52,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i52);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i53,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i53);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".errs = ", 8);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i54,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i54);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".err", 4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i55,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i55);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i56,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i56);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i57,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i57);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".dates = ", 9);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i58,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i58);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".date", 5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i59,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i59);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i60,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i60);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i61,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i61);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".date3s = ", 10);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i62,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i62);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".date3", 6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i63,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i63);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i64,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i64);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i65,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i65);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".optdates = ", 12);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i66,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i66);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".optdate", 8);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i67,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i67);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i68,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i68);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i69,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i69);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".ds = ", 6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i70,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i70);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".d", 2);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i71,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i71);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i72,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i72);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i73,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i73);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".hs = ", 6);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i74,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i74);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".h", 2);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i75,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i75);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i76,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i76);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i77,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i77);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".ints = ", 8);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i78,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i78);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".int", 4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i79,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i79);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_separator_4_0),
		mercury__modules__generate_dep_file_5_0_i80,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i80);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".int2", 5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i81,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i81);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i82,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i82);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i83,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i83);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".int3s = ", 9);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i84,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i84);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".int3", 5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i85,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i85);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i86,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i86);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i87,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i87);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".opts = ", 8);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i88,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i88);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(".opt", 4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i89,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i89);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i90,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i90);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 51);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__modules__generate_dep_file_5_0_i91,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i91);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	if ((strcmp((char *)(Integer) r1, (char *)string_const("accurate", 8)) !=0))
		GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i92);
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__modules__generate_dep_file_5_0_i95,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i95);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = ((Integer) 0);
	r4 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__modules__trans_impl_dependencies_7_0),
		mercury__modules__generate_dep_file_5_0_i96,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i96);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i97,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i97);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const(".garbs = ", 9);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i98,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i98);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const(".garb", 5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__modules__write_compact_dependencies_list_6_0),
		mercury__modules__generate_dep_file_5_0_i99,
		STATIC(mercury__modules__generate_dep_file_5_0));
Define_label(mercury__modules__generate_dep_file_5_0_i99);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n\n", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i100,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i100);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i101);
Define_label(mercury__modules__generate_dep_file_5_0_i92);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
Define_label(mercury__modules__generate_dep_file_5_0_i101);
	if ((strcmp((char *)(Integer) r4, (char *)string_const("accurate", 8)) !=0))
		GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i102);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const("_garb.c : $(", 12);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const(".garbs)\n", 8);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const("\t$(MLINK) $(MLINKFLAGS) -o ", 27);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("_garb.c $(", 10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_14);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i105,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i105);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__modules__generate_dep_file_5_0_i102);
	if ((strcmp((char *)(Integer) r4, (char *)string_const("accurate", 8)) !=0))
		GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i107);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(" : $(", 5);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const(".os) ", 5);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("_init.o ", 8);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const("_garb.o\n", 8);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\t$(ML) -s $(GRADE) $(MLFLAGS) -o ", 33);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("_garb.o ", 8);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const("_init.o \\\n", 10);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = string_const("\t$(", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_15);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i110,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i110);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".split : ", 9);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".split.a ", 9);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("_init.o\n", 8);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const("\t$(ML) -s $(GRADE) $(MLFLAGS) -o ", 33);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".split ", 7);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("_init.o \\\n", 10);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("\t", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_16);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i112);
	}
Define_label(mercury__modules__generate_dep_file_5_0_i107);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r4;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(" : $(", 5);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const(".os) ", 5);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("_init.o\n", 8);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("\t$(ML) -s $(GRADE) $(MLFLAGS) -o ", 33);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const("_init.o \\\n", 10);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("\t$(", 3);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_15);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r5;
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i111,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i111);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".split : ", 9);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".split.a ", 9);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("_init.o\n", 8);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const("\t$(ML) -s $(GRADE) $(MLFLAGS) -o ", 33);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".split ", 7);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("_init.o \\\n", 10);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("\t", 1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_16);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__modules__generate_dep_file_5_0_i112);
	detstackvar(1) = (Integer) r4;
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i113,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i113);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".split.a : $(", 13);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".dir_os)\n", 9);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\trm -f ", 7);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".split.a\n", 9);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("\tar cr ", 7);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(".split.a\n", 9);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\tfor dir in $(", 14);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const(".dirs); do \\\n", 13);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("\t\tar q ", 7);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = string_const(".split.a $$dir/*.o; \\\n", 22);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const("\tdone\n", 6);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = string_const("\tranlib ", 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_17);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i114,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i114);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const("_init.c :\n", 10);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\t$(C2INIT) $(C2INITFLAGS) $(", 28);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".ms) > ", 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_18);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i115,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i115);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".nu : $(", 8);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".nos)\n", 6);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\t$(MNL) $(MNLFLAGS) -o ", 23);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".nu ", 4);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("$(", 2);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(".nos)\n\n", 7);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".nu.debug : $(", 14);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const(".nos)\n", 6);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("\t$(MNL) --debug $(MNLFLAGS) -o ", 31);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const(".nu.debug ", 10);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = string_const("$(", 2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_19);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i116,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i116);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".sicstus : $(", 13);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".qls)\n", 6);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\t$(MSL) $(MSLFLAGS) -o ", 23);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".sicstus ", 9);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("$(", 2);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(".qls)\n\n", 7);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".sicstus.debug : $(", 19);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const(".qls)\n", 6);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("\t$(MSL) --debug $(MSLFLAGS) -o ", 31);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const(".sicstus.debug $(", 17);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_20);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i117,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i117);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".check : $(", 11);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".errs)\n\n", 8);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const(".ints : $(", 10);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const(".dates)\n\n", 9);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(".int3s : $(", 11);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".date3s)\n\n", 10);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const(".opts : $(", 10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_21);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i118,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i118);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("clean: ", 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_22);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i119,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i119);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".clean :\n", 9);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("\t-rm -rf ", 9);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".dir\n", 5);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const(".cs) ", 5);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const("_init.c\n", 8);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const(".ss) ", 5);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("_init.s\n", 8);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = string_const(".os) ", 5);
	tag_incr_hp(r21, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r21, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r22, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r22, ((Integer) 0)) = string_const("_init.o\n", 8);
	tag_incr_hp(r23, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r23, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r24, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r24, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r25, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r25, ((Integer) 0)) = string_const(".nos)\n", 6);
	tag_incr_hp(r26, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r26, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r27, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r27, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r28, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r28, ((Integer) 0)) = string_const(".qls)\n", 6);
	tag_incr_hp(r29, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r29, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r29, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) r21, ((Integer) 1)) = (Integer) r22;
	field(mktag(1), (Integer) r22, ((Integer) 1)) = (Integer) r23;
	field(mktag(1), (Integer) r23, ((Integer) 1)) = (Integer) r24;
	field(mktag(1), (Integer) r24, ((Integer) 1)) = (Integer) r25;
	field(mktag(1), (Integer) r25, ((Integer) 1)) = (Integer) r26;
	field(mktag(1), (Integer) r26, ((Integer) 1)) = (Integer) r27;
	field(mktag(1), (Integer) r27, ((Integer) 1)) = (Integer) r28;
	field(mktag(1), (Integer) r28, ((Integer) 1)) = (Integer) r29;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_23);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i120,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i120);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	if ((strcmp((char *)(Integer) detstackvar(4), (char *)string_const("accurate", 8)) !=0))
		GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i121);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(".garbs)\n", 8);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const("\t-rm -f ", 8);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const("_garb.o ", 8);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("_garb.c ", 8);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_24);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i124,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i124);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".change_clean :\n", 16);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".cs) ", 5);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("_init.c\n", 8);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".ss) ", 5);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("_init.s\n", 8);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const(".os) ", 5);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r21, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r21, ((Integer) 0)) = string_const("_init.o\n", 8);
	tag_incr_hp(r22, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r22, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r23, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r23, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r24, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r24, ((Integer) 0)) = string_const(".hs)\n", 5);
	tag_incr_hp(r25, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r25, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r26, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r26, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r27, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r27, ((Integer) 0)) = string_const(".ds)\n", 5);
	tag_incr_hp(r28, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r28, ((Integer) 0)) = string_const("\t-rm -f ", 8);
	tag_incr_hp(r29, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r29, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r30, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r30, ((Integer) 0)) = string_const(".dep ", 5);
	tag_incr_hp(r31, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r31, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r32, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r32, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r(33), mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r(33), ((Integer) 0)) = string_const("\t-rm -f ", 8);
	tag_incr_hp(r(34), mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r(34), ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r(35), mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r(35), ((Integer) 0)) = string_const(".split ", 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_17);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) r21, ((Integer) 1)) = (Integer) r22;
	field(mktag(1), (Integer) r22, ((Integer) 1)) = (Integer) r23;
	field(mktag(1), (Integer) r23, ((Integer) 1)) = (Integer) r24;
	field(mktag(1), (Integer) r24, ((Integer) 1)) = (Integer) r25;
	field(mktag(1), (Integer) r25, ((Integer) 1)) = (Integer) r26;
	field(mktag(1), (Integer) r26, ((Integer) 1)) = (Integer) r27;
	field(mktag(1), (Integer) r27, ((Integer) 1)) = (Integer) r28;
	field(mktag(1), (Integer) r28, ((Integer) 1)) = (Integer) r29;
	field(mktag(1), (Integer) r29, ((Integer) 1)) = (Integer) r30;
	field(mktag(1), (Integer) r30, ((Integer) 1)) = (Integer) r31;
	field(mktag(1), (Integer) r31, ((Integer) 1)) = (Integer) r32;
	field(mktag(1), (Integer) r32, ((Integer) 1)) = (Integer) r(33);
	field(mktag(1), (Integer) r(33), ((Integer) 1)) = (Integer) r(34);
	field(mktag(1), (Integer) r(34), ((Integer) 1)) = (Integer) r(35);
	field(mktag(1), (Integer) r(35), ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__modules__generate_dep_file_5_0_i126);
	}
Define_label(mercury__modules__generate_dep_file_5_0_i121);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__generate_dep_file_5_0_i125,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i125);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".change_clean :\n", 16);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".cs) ", 5);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("_init.c\n", 8);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = string_const(".ss) ", 5);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("_init.s\n", 8);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const(".os) ", 5);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r21, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r21, ((Integer) 0)) = string_const("_init.o\n", 8);
	tag_incr_hp(r22, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r22, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r23, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r23, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r24, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r24, ((Integer) 0)) = string_const(".hs)\n", 5);
	tag_incr_hp(r25, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r25, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r26, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r26, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r27, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r27, ((Integer) 0)) = string_const(".ds)\n", 5);
	tag_incr_hp(r28, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r28, ((Integer) 0)) = string_const("\t-rm -f ", 8);
	tag_incr_hp(r29, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r29, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r30, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r30, ((Integer) 0)) = string_const(".dep ", 5);
	tag_incr_hp(r31, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r31, ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r32, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r32, ((Integer) 0)) = string_const("\n", 1);
	tag_incr_hp(r(33), mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r(33), ((Integer) 0)) = string_const("\t-rm -f ", 8);
	tag_incr_hp(r(34), mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r(34), ((Integer) 0)) = (Integer) r4;
	tag_incr_hp(r(35), mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r(35), ((Integer) 0)) = string_const(".split ", 7);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_17);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) r21, ((Integer) 1)) = (Integer) r22;
	field(mktag(1), (Integer) r22, ((Integer) 1)) = (Integer) r23;
	field(mktag(1), (Integer) r23, ((Integer) 1)) = (Integer) r24;
	field(mktag(1), (Integer) r24, ((Integer) 1)) = (Integer) r25;
	field(mktag(1), (Integer) r25, ((Integer) 1)) = (Integer) r26;
	field(mktag(1), (Integer) r26, ((Integer) 1)) = (Integer) r27;
	field(mktag(1), (Integer) r27, ((Integer) 1)) = (Integer) r28;
	field(mktag(1), (Integer) r28, ((Integer) 1)) = (Integer) r29;
	field(mktag(1), (Integer) r29, ((Integer) 1)) = (Integer) r30;
	field(mktag(1), (Integer) r30, ((Integer) 1)) = (Integer) r31;
	field(mktag(1), (Integer) r31, ((Integer) 1)) = (Integer) r32;
	field(mktag(1), (Integer) r32, ((Integer) 1)) = (Integer) r(33);
	field(mktag(1), (Integer) r(33), ((Integer) 1)) = (Integer) r(34);
	field(mktag(1), (Integer) r(34), ((Integer) 1)) = (Integer) r(35);
	field(mktag(1), (Integer) r(35), ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__modules__generate_dep_file_5_0_i126);
	detstackvar(1) = (Integer) r4;
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i127,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
Define_label(mercury__modules__generate_dep_file_5_0_i127);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("realclean: ", 11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_25);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i128,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i128);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = string_const(".realclean : ", 13);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = string_const(".clean\n", 7);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".dates)\n", 8);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = string_const(".date3s)\n", 9);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const(".optdates)\n", 11);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = string_const(".ints)\n", 7);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r21, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r21, ((Integer) 0)) = string_const(".int3s)\n", 8);
	tag_incr_hp(r22, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r22, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r23, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r23, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r24, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r24, ((Integer) 0)) = string_const(".opts)\n", 7);
	tag_incr_hp(r25, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r25, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r26, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r26, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r27, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r27, ((Integer) 0)) = string_const(".ds)\n", 5);
	tag_incr_hp(r28, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r28, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r28, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) r21, ((Integer) 1)) = (Integer) r22;
	field(mktag(1), (Integer) r22, ((Integer) 1)) = (Integer) r23;
	field(mktag(1), (Integer) r23, ((Integer) 1)) = (Integer) r24;
	field(mktag(1), (Integer) r24, ((Integer) 1)) = (Integer) r25;
	field(mktag(1), (Integer) r25, ((Integer) 1)) = (Integer) r26;
	field(mktag(1), (Integer) r26, ((Integer) 1)) = (Integer) r27;
	field(mktag(1), (Integer) r27, ((Integer) 1)) = (Integer) r28;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_26);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i129,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i129);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("\t-rm -f ", 8);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(" ", 1);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".split ", 7);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = string_const(".split.a ", 9);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const(".nu ", 4);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const(".nu.save ", 9);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const(".nu.debug.save ", 15);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r17, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r17, ((Integer) 0)) = string_const(".nu.debug ", 10);
	tag_incr_hp(r18, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r18, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r19, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r19, ((Integer) 0)) = string_const(".sicstus ", 9);
	tag_incr_hp(r20, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r20, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r21, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r21, ((Integer) 0)) = string_const(".sicstus.debug ", 15);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r21, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) r17;
	field(mktag(1), (Integer) r17, ((Integer) 1)) = (Integer) r18;
	field(mktag(1), (Integer) r18, ((Integer) 1)) = (Integer) r19;
	field(mktag(1), (Integer) r19, ((Integer) 1)) = (Integer) r20;
	field(mktag(1), (Integer) r20, ((Integer) 1)) = (Integer) r21;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_27);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__modules__generate_dep_file_5_0_i130,
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
Define_label(mercury__modules__generate_dep_file_5_0_i130);
	update_prof_current_proc(LABEL(mercury__modules__generate_dep_file_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("clean_nu: ", 10);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const(".clean_nu\n", 10);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = string_const(".clean_nu :\n", 12);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = string_const(".nos)\n\n", 7);
	tag_incr_hp(r11, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r11, ((Integer) 0)) = string_const("clean_sicstus: ", 15);
	tag_incr_hp(r12, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r12, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r13, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r13, ((Integer) 0)) = string_const(".clean_sicstus\n", 15);
	tag_incr_hp(r14, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r14, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r15, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r15, ((Integer) 0)) = string_const(".clean_sicstus :\n", 17);
	tag_incr_hp(r16, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 0)) = string_const("\t-rm -f $(", 10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r16, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) r11;
	field(mktag(1), (Integer) r11, ((Integer) 1)) = (Integer) r12;
	field(mktag(1), (Integer) r12, ((Integer) 1)) = (Integer) r13;
	field(mktag(1), (Integer) r13, ((Integer) 1)) = (Integer) r14;
	field(mktag(1), (Integer) r14, ((Integer) 1)) = (Integer) r15;
	field(mktag(1), (Integer) r15, ((Integer) 1)) = (Integer) r16;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_modules__common_20);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	tailcall(ENTRY(mercury__io__write_strings_4_0),
		STATIC(mercury__modules__generate_dep_file_5_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module20)
	init_entry(mercury__modules__get_extra_link_objects_3_0);
BEGIN_CODE

/* code for predicate 'get_extra_link_objects'/3 in mode 0 */
Define_static(mercury__modules__get_extra_link_objects_3_0);
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__modules__get_extra_link_objects_2_4_0),
		STATIC(mercury__modules__get_extra_link_objects_3_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module21)
	init_entry(mercury__modules__get_extra_link_objects_2_4_0);
	init_label(mercury__modules__get_extra_link_objects_2_4_0_i4);
	init_label(mercury__modules__get_extra_link_objects_2_4_0_i5);
	init_label(mercury__modules__get_extra_link_objects_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'get_extra_link_objects_2'/4 in mode 0 */
Define_static(mercury__modules__get_extra_link_objects_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_extra_link_objects_2_4_0_i1002);
	incr_sp_push_msg(4, "get_extra_link_objects_2");
	detstackvar(4) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modules__get_extra_link_objects_2_4_0_i4,
		STATIC(mercury__modules__get_extra_link_objects_2_4_0));
	}
Define_label(mercury__modules__get_extra_link_objects_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__get_extra_link_objects_2_4_0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__get_extra_link_objects_2_4_0_i5,
		STATIC(mercury__modules__get_extra_link_objects_2_4_0));
	}
Define_label(mercury__modules__get_extra_link_objects_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__get_extra_link_objects_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__modules__get_extra_link_objects_2_4_0,
		STATIC(mercury__modules__get_extra_link_objects_2_4_0));
Define_label(mercury__modules__get_extra_link_objects_2_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module22)
	init_entry(mercury__modules__select_ok_modules_3_0);
	init_label(mercury__modules__select_ok_modules_3_0_i4);
	init_label(mercury__modules__select_ok_modules_3_0_i5);
	init_label(mercury__modules__select_ok_modules_3_0_i3);
	init_label(mercury__modules__select_ok_modules_3_0_i2);
BEGIN_CODE

/* code for predicate 'select_ok_modules'/3 in mode 0 */
Define_static(mercury__modules__select_ok_modules_3_0);
	incr_sp_push_msg(4, "select_ok_modules");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__select_ok_modules_3_0_i3);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__modules__select_ok_modules_3_0_i4,
		STATIC(mercury__modules__select_ok_modules_3_0));
	}
Define_label(mercury__modules__select_ok_modules_3_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__select_ok_modules_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(3);
	localcall(mercury__modules__select_ok_modules_3_0,
		LABEL(mercury__modules__select_ok_modules_3_0_i5),
		STATIC(mercury__modules__select_ok_modules_3_0));
Define_label(mercury__modules__select_ok_modules_3_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__select_ok_modules_3_0));
	if (((Integer) detstackvar(1) == ((Integer) 2)))
		GOTO_LABEL(mercury__modules__select_ok_modules_3_0_i2);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__modules__select_ok_modules_3_0_i3);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__modules__select_ok_modules_3_0_i2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module23)
	init_entry(mercury__modules__write_dependencies_list_5_0);
	init_label(mercury__modules__write_dependencies_list_5_0_i4);
	init_label(mercury__modules__write_dependencies_list_5_0_i5);
	init_label(mercury__modules__write_dependencies_list_5_0_i6);
	init_label(mercury__modules__write_dependencies_list_5_0_i1002);
BEGIN_CODE

/* code for predicate 'write_dependencies_list'/5 in mode 0 */
Define_static(mercury__modules__write_dependencies_list_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__write_dependencies_list_5_0_i1002);
	incr_sp_push_msg(5, "write_dependencies_list");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r3;
	r2 = string_const(" \\\n\t", 4);
	r3 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_dependencies_list_5_0_i4,
		STATIC(mercury__modules__write_dependencies_list_5_0));
	}
Define_label(mercury__modules__write_dependencies_list_5_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__write_dependencies_list_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_dependencies_list_5_0_i5,
		STATIC(mercury__modules__write_dependencies_list_5_0));
	}
Define_label(mercury__modules__write_dependencies_list_5_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__write_dependencies_list_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_dependencies_list_5_0_i6,
		STATIC(mercury__modules__write_dependencies_list_5_0));
	}
Define_label(mercury__modules__write_dependencies_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__write_dependencies_list_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__modules__write_dependencies_list_5_0,
		STATIC(mercury__modules__write_dependencies_list_5_0));
Define_label(mercury__modules__write_dependencies_list_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module24)
	init_entry(mercury__modules__write_compact_dependencies_list_6_0);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i4);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i5);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i6);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i7);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i8);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i9);
	init_label(mercury__modules__write_compact_dependencies_list_6_0_i1003);
BEGIN_CODE

/* code for predicate 'write_compact_dependencies_list'/6 in mode 0 */
Define_static(mercury__modules__write_compact_dependencies_list_6_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__write_compact_dependencies_list_6_0_i1003);
	incr_sp_push_msg(5, "write_compact_dependencies_list");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) r4;
	r2 = string_const("$(", 2);
	r3 = (Integer) r5;
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_compact_dependencies_list_6_0_i4,
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__write_compact_dependencies_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_compact_dependencies_list_6_0_i5,
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i5);
	update_prof_current_proc(LABEL(mercury__modules__write_compact_dependencies_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(":", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_compact_dependencies_list_6_0_i6,
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__write_compact_dependencies_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_compact_dependencies_list_6_0_i7,
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__write_compact_dependencies_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("=", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_compact_dependencies_list_6_0_i8,
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__write_compact_dependencies_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__modules__write_compact_dependencies_list_6_0_i9,
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__write_compact_dependencies_list_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__io__write_string_4_0);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
	}
Define_label(mercury__modules__write_compact_dependencies_list_6_0_i1003);
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	tailcall(STATIC(mercury__modules__write_dependencies_list_5_0),
		STATIC(mercury__modules__write_compact_dependencies_list_6_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module25)
	init_entry(mercury__modules__write_compact_dependencies_separator_4_0);
	init_label(mercury__modules__write_compact_dependencies_separator_4_0_i1002);
BEGIN_CODE

/* code for predicate 'write_compact_dependencies_separator'/4 in mode 0 */
Define_static(mercury__modules__write_compact_dependencies_separator_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__write_compact_dependencies_separator_4_0_i1002);
	r1 = (Integer) r2;
	r2 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		STATIC(mercury__modules__write_compact_dependencies_separator_4_0));
	}
Define_label(mercury__modules__write_compact_dependencies_separator_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module26)
	init_entry(mercury__modules__transitive_dependencies_2_8_0);
	init_label(mercury__modules__transitive_dependencies_2_8_0_i6);
	init_label(mercury__modules__transitive_dependencies_2_8_0_i5);
	init_label(mercury__modules__transitive_dependencies_2_8_0_i8);
	init_label(mercury__modules__transitive_dependencies_2_8_0_i9);
	init_label(mercury__modules__transitive_dependencies_2_8_0_i10);
	init_label(mercury__modules__transitive_dependencies_2_8_0_i1003);
BEGIN_CODE

/* code for predicate 'transitive_dependencies_2'/8 in mode 0 */
Define_static(mercury__modules__transitive_dependencies_2_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__transitive_dependencies_2_8_0_i1003);
	incr_sp_push_msg(7, "transitive_dependencies_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__modules__transitive_dependencies_2_8_0_i6,
		STATIC(mercury__modules__transitive_dependencies_2_8_0));
	}
Define_label(mercury__modules__transitive_dependencies_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__transitive_dependencies_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modules__transitive_dependencies_2_8_0_i5);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__modules__transitive_dependencies_2_8_0,
		STATIC(mercury__modules__transitive_dependencies_2_8_0));
Define_label(mercury__modules__transitive_dependencies_2_8_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__modules__transitive_dependencies_2_8_0_i8,
		STATIC(mercury__modules__transitive_dependencies_2_8_0));
	}
Define_label(mercury__modules__transitive_dependencies_2_8_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__transitive_dependencies_2_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__modules__lookup_dependencies_11_0),
		mercury__modules__transitive_dependencies_2_8_0_i9,
		STATIC(mercury__modules__transitive_dependencies_2_8_0));
Define_label(mercury__modules__transitive_dependencies_2_8_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__transitive_dependencies_2_8_0));
	r2 = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(6);
	detstackvar(2) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__transitive_dependencies_2_8_0_i10,
		STATIC(mercury__modules__transitive_dependencies_2_8_0));
	}
Define_label(mercury__modules__transitive_dependencies_2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__transitive_dependencies_2_8_0));
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__modules__transitive_dependencies_2_8_0,
		STATIC(mercury__modules__transitive_dependencies_2_8_0));
Define_label(mercury__modules__transitive_dependencies_2_8_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module27)
	init_entry(mercury__modules__trans_impl_dependencies_7_0);
	init_label(mercury__modules__trans_impl_dependencies_7_0_i2);
	init_label(mercury__modules__trans_impl_dependencies_7_0_i3);
	init_label(mercury__modules__trans_impl_dependencies_7_0_i4);
BEGIN_CODE

/* code for predicate 'trans_impl_dependencies'/7 in mode 0 */
Define_static(mercury__modules__trans_impl_dependencies_7_0);
	incr_sp_push_msg(5, "trans_impl_dependencies");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__modules__trans_impl_dependencies_7_0_i2,
		STATIC(mercury__modules__trans_impl_dependencies_7_0));
	}
Define_label(mercury__modules__trans_impl_dependencies_7_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__modules__trans_impl_dependencies_2_8_0),
		mercury__modules__trans_impl_dependencies_7_0_i3,
		STATIC(mercury__modules__trans_impl_dependencies_7_0));
Define_label(mercury__modules__trans_impl_dependencies_7_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_7_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__modules__trans_impl_dependencies_7_0_i4,
		STATIC(mercury__modules__trans_impl_dependencies_7_0));
	}
Define_label(mercury__modules__trans_impl_dependencies_7_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_7_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module28)
	init_entry(mercury__modules__trans_impl_dependencies_2_8_0);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i6);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i5);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i8);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i9);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i10);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i11);
	init_label(mercury__modules__trans_impl_dependencies_2_8_0_i1003);
BEGIN_CODE

/* code for predicate 'trans_impl_dependencies_2'/8 in mode 0 */
Define_static(mercury__modules__trans_impl_dependencies_2_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__trans_impl_dependencies_2_8_0_i1003);
	incr_sp_push_msg(7, "trans_impl_dependencies_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__modules__trans_impl_dependencies_2_8_0_i6,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
	}
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modules__trans_impl_dependencies_2_8_0_i5);
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__modules__trans_impl_dependencies_2_8_0,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__modules__trans_impl_dependencies_2_8_0_i8,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
	}
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i8);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_2_8_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__modules__lookup_dependencies_11_0),
		mercury__modules__trans_impl_dependencies_2_8_0_i9,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_2_8_0));
	r2 = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(6);
	detstackvar(2) = (Integer) r6;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r7;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__trans_impl_dependencies_2_8_0_i10,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
	}
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_2_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__trans_impl_dependencies_2_8_0_i11,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
	}
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__trans_impl_dependencies_2_8_0));
	r4 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__modules__trans_impl_dependencies_2_8_0,
		STATIC(mercury__modules__trans_impl_dependencies_2_8_0));
Define_label(mercury__modules__trans_impl_dependencies_2_8_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module29)
	init_entry(mercury__modules__lookup_dependencies_11_0);
	init_label(mercury__modules__lookup_dependencies_11_0_i4);
	init_label(mercury__modules__lookup_dependencies_11_0_i3);
	init_label(mercury__modules__lookup_dependencies_11_0_i6);
	init_label(mercury__modules__lookup_dependencies_11_0_i11);
	init_label(mercury__modules__lookup_dependencies_11_0_i7);
	init_label(mercury__modules__lookup_dependencies_11_0_i12);
	init_label(mercury__modules__lookup_dependencies_11_0_i13);
	init_label(mercury__modules__lookup_dependencies_11_0_i14);
	init_label(mercury__modules__lookup_dependencies_11_0_i15);
	init_label(mercury__modules__lookup_dependencies_11_0_i16);
	init_label(mercury__modules__lookup_dependencies_11_0_i17);
BEGIN_CODE

/* code for predicate 'lookup_dependencies'/11 in mode 0 */
Define_static(mercury__modules__lookup_dependencies_11_0);
	incr_sp_push_msg(7, "lookup_dependencies");
	detstackvar(7) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__modules__lookup_dependencies_11_0_i4,
		STATIC(mercury__modules__lookup_dependencies_11_0));
	}
Define_label(mercury__modules__lookup_dependencies_11_0_i4);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modules__lookup_dependencies_11_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r5 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__modules__lookup_dependencies_11_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".m", 2);
	r3 = string_const("Getting dependencies for module", 31);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	{
		call_localret(STATIC(mercury__modules__read_mod_ignore_errors_8_0),
		mercury__modules__lookup_dependencies_11_0_i6,
		STATIC(mercury__modules__lookup_dependencies_11_0));
	}
Define_label(mercury__modules__lookup_dependencies_11_0_i6);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__lookup_dependencies_11_0_i7);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__modules__lookup_dependencies_11_0_i7);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) r3;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(".int", 4);
	r3 = string_const("Getting dependencies for module interface", 41);
	{
		call_localret(STATIC(mercury__modules__read_mod_ignore_errors_8_0),
		mercury__modules__lookup_dependencies_11_0_i11,
		STATIC(mercury__modules__lookup_dependencies_11_0));
	}
Define_label(mercury__modules__lookup_dependencies_11_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	r5 = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__modules__lookup_dependencies_11_0_i12);
Define_label(mercury__modules__lookup_dependencies_11_0_i7);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r5 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
Define_label(mercury__modules__lookup_dependencies_11_0_i12);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(4) = (Integer) r1;
	{
		call_localret(STATIC(mercury__modules__get_dependencies_2_0),
		mercury__modules__lookup_dependencies_11_0_i13,
		STATIC(mercury__modules__lookup_dependencies_11_0));
	}
Define_label(mercury__modules__lookup_dependencies_11_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = ((Integer) 1);
	call_localret(STATIC(mercury__modules__get_interface_3_0),
		mercury__modules__lookup_dependencies_11_0_i14,
		STATIC(mercury__modules__lookup_dependencies_11_0));
Define_label(mercury__modules__lookup_dependencies_11_0_i14);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	{
		call_localret(STATIC(mercury__modules__get_dependencies_2_0),
		mercury__modules__lookup_dependencies_11_0_i15,
		STATIC(mercury__modules__lookup_dependencies_11_0));
	}
Define_label(mercury__modules__lookup_dependencies_11_0_i15);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r3;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("mercury_builtin", 15);
	call_localret(STATIC(mercury__modules__get_fact_table_dependencies_2_3_0),
		mercury__modules__lookup_dependencies_11_0_i16,
		STATIC(mercury__modules__lookup_dependencies_11_0));
Define_label(mercury__modules__lookup_dependencies_11_0_i16);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_modules__base_type_info_deps_0;
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r5, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r5, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r5, ((Integer) 4)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__modules__lookup_dependencies_11_0_i17,
		STATIC(mercury__modules__lookup_dependencies_11_0));
	}
Define_label(mercury__modules__lookup_dependencies_11_0_i17);
	update_prof_current_proc(LABEL(mercury__modules__lookup_dependencies_11_0));
	r6 = (Integer) r1;
	r1 = ((Integer) 1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module30)
	init_entry(mercury__modules__process_module_short_interfaces_6_0);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i1013);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i11);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i10);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i13);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i5);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i16);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i17);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i22);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i23);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i28);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i29);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i30);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i31);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i32);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i33);
	init_label(mercury__modules__process_module_short_interfaces_6_0_i1011);
BEGIN_CODE

/* code for predicate 'process_module_short_interfaces'/6 in mode 0 */
Define_static(mercury__modules__process_module_short_interfaces_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i1011);
	r10 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r11 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r8 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	r7 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r6 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	r5 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r9 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	if ((strcmp((char *)(Integer) r11, (char *)(Integer) r9) !=0))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i1013);
	r1 = (Integer) r10;
	localtailcall(mercury__modules__process_module_short_interfaces_6_0,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
Define_label(mercury__modules__process_module_short_interfaces_6_0_i1013);
	incr_sp_push_msg(14, "process_module_short_interfaces");
	detstackvar(14) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r11;
	detstackvar(5) = (Integer) r10;
	detstackvar(6) = (Integer) r9;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r7;
	detstackvar(9) = (Integer) r6;
	detstackvar(10) = (Integer) r5;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) r11;
	r3 = (Integer) r8;
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__modules__process_module_short_interfaces_6_0_i11,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i11);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i10);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	localtailcall(mercury__modules__process_module_short_interfaces_6_0,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
Define_label(mercury__modules__process_module_short_interfaces_6_0_i10);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__modules__process_module_short_interfaces_6_0_i13,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i13);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	localtailcall(mercury__modules__process_module_short_interfaces_6_0,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
Define_label(mercury__modules__process_module_short_interfaces_6_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = string_const("Reading short interface for module", 34);
	r4 = ((Integer) 0);
	r5 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__modules__read_mod_8_0),
		mercury__modules__process_module_short_interfaces_6_0_i16,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i16);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i17);
	r4 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	if ((tag((Integer) r4) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i17);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i17);
	if (((Integer) field(mktag(3), (Integer) r4, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i17);
	r10 = (Integer) r2;
	r11 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i22);
Define_label(mercury__modules__process_module_short_interfaces_6_0_i17);
	r10 = (Integer) r2;
	r11 = (Integer) r1;
	r2 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(8);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(10);
Define_label(mercury__modules__process_module_short_interfaces_6_0_i22);
	if (((Integer) r10 == ((Integer) 0)))
		GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i23);
	r9 = (Integer) r8;
	r10 = (Integer) r11;
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = ((Integer) 14);
	r11 = ((Integer) 1);
	GOTO_LABEL(mercury__modules__process_module_short_interfaces_6_0_i28);
Define_label(mercury__modules__process_module_short_interfaces_6_0_i23);
	r10 = (Integer) r11;
	r11 = (Integer) r9;
	r9 = (Integer) r8;
	r8 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = (Integer) r5;
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r1;
	r1 = ((Integer) 14);
Define_label(mercury__modules__process_module_short_interfaces_6_0_i28);
	detstackvar(1) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(2) = (Integer) r10;
	detstackvar(3) = (Integer) r11;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__modules__process_module_short_interfaces_6_0_i29,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i29);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	{
	Declare_entry(mercury__passes_aux__maybe_report_stats_3_0);
	call_localret(ENTRY(mercury__passes_aux__maybe_report_stats_3_0),
		mercury__modules__process_module_short_interfaces_6_0_i30,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i30);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__modules__get_dependencies_2_0),
		mercury__modules__process_module_short_interfaces_6_0_i31,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i31);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__process_module_short_interfaces_6_0_i32,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i32);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__process_module_short_interfaces_6_0_i33,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i33);
	update_prof_current_proc(LABEL(mercury__modules__process_module_short_interfaces_6_0));
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) r1;
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	r1 = (Integer) detstackvar(11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) tempr1;
	r4 = (Integer) detstackvar(13);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	localtailcall(mercury__modules__process_module_short_interfaces_6_0,
		STATIC(mercury__modules__process_module_short_interfaces_6_0));
	}
Define_label(mercury__modules__process_module_short_interfaces_6_0_i1011);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module31)
	init_entry(mercury__modules__get_dependencies_2_3_0);
	init_label(mercury__modules__get_dependencies_2_3_0_i9);
	init_label(mercury__modules__get_dependencies_2_3_0_i1008);
	init_label(mercury__modules__get_dependencies_2_3_0_i1010);
BEGIN_CODE

/* code for predicate 'get_dependencies_2'/3 in mode 0 */
Define_static(mercury__modules__get_dependencies_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1008);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1010);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1010);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1010);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2)), ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1010);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2)), ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1010);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2)), ((Integer) 1)), ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__modules__get_dependencies_2_3_0_i1010);
	incr_sp_push_msg(2, "get_dependencies_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 2)), ((Integer) 1)), ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__modules__get_dependencies_2_3_0_i9,
		STATIC(mercury__modules__get_dependencies_2_3_0));
	}
Define_label(mercury__modules__get_dependencies_2_3_0_i9);
	update_prof_current_proc(LABEL(mercury__modules__get_dependencies_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__modules__get_dependencies_2_3_0,
		STATIC(mercury__modules__get_dependencies_2_3_0));
Define_label(mercury__modules__get_dependencies_2_3_0_i1008);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__modules__get_dependencies_2_3_0_i1010);
	r1 = (Integer) r3;
	localtailcall(mercury__modules__get_dependencies_2_3_0,
		STATIC(mercury__modules__get_dependencies_2_3_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module32)
	init_entry(mercury__modules__get_fact_table_dependencies_2_3_0);
	init_label(mercury__modules__get_fact_table_dependencies_2_3_0_i8);
	init_label(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
	init_label(mercury__modules__get_fact_table_dependencies_2_3_0_i6);
	init_label(mercury__modules__get_fact_table_dependencies_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'get_fact_table_dependencies_2'/3 in mode 0 */
Define_static(mercury__modules__get_fact_table_dependencies_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i1);
Define_label(mercury__modules__get_fact_table_dependencies_2_3_0_i8);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
	if (((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 0)) != ((Integer) 8)))
		GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
	if ((tag((Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1))) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
	if (((Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)), ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) field(mktag(3), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0)), ((Integer) 1)), ((Integer) 3));
	r1 = (Integer) r3;
	r2 = (Integer) tempr1;
	GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i6);
	}
Define_label(mercury__modules__get_fact_table_dependencies_2_3_0_i2);
	r1 = (Integer) r3;
Define_label(mercury__modules__get_fact_table_dependencies_2_3_0_i6);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_fact_table_dependencies_2_3_0_i8);
Define_label(mercury__modules__get_fact_table_dependencies_2_3_0_i1);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module33)
	init_entry(mercury__modules__get_interface_3_0);
	init_label(mercury__modules__get_interface_3_0_i2);
BEGIN_CODE

/* code for predicate 'get_interface'/3 in mode 0 */
Define_static(mercury__modules__get_interface_3_0);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	incr_sp_push_msg(1, "get_interface");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__modules__get_interface_2_5_0),
		mercury__modules__get_interface_3_0_i2,
		STATIC(mercury__modules__get_interface_3_0));
Define_label(mercury__modules__get_interface_3_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__get_interface_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__modules__get_interface_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module34)
	init_entry(mercury__modules__get_interface_2_5_0);
	init_label(mercury__modules__get_interface_2_5_0_i26);
	init_label(mercury__modules__get_interface_2_5_0_i2);
	init_label(mercury__modules__get_interface_2_5_0_i10);
	init_label(mercury__modules__get_interface_2_5_0_i6);
	init_label(mercury__modules__get_interface_2_5_0_i14);
	init_label(mercury__modules__get_interface_2_5_0_i18);
	init_label(mercury__modules__get_interface_2_5_0_i24);
	init_label(mercury__modules__get_interface_2_5_0_i1);
BEGIN_CODE

/* code for predicate 'get_interface_2'/5 in mode 0 */
Define_static(mercury__modules__get_interface_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i1);
Define_label(mercury__modules__get_interface_2_5_0_i26);
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(0), (Integer) r5, ((Integer) 0));
	if ((tag((Integer) r7) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i2);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i2);
	r8 = (Integer) field(mktag(3), (Integer) r7, ((Integer) 2));
	if (((Integer) r8 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i2);
	r1 = (Integer) r6;
	r2 = ((Integer) 0);
	GOTO_LABEL(mercury__modules__get_interface_2_5_0_i24);
Define_label(mercury__modules__get_interface_2_5_0_i2);
	if ((tag((Integer) r7) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i6);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i6);
	r1 = (Integer) field(mktag(3), (Integer) r7, ((Integer) 2));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i6);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i10);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r1 = (Integer) r6;
	r2 = ((Integer) 0);
	r4 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r5;
	GOTO_LABEL(mercury__modules__get_interface_2_5_0_i24);
	}
Define_label(mercury__modules__get_interface_2_5_0_i10);
	r1 = (Integer) r6;
	r2 = ((Integer) 1);
	GOTO_LABEL(mercury__modules__get_interface_2_5_0_i24);
Define_label(mercury__modules__get_interface_2_5_0_i6);
	if ((tag((Integer) r7) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i14);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i14);
	if (((Integer) field(mktag(3), (Integer) r7, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i14);
	r1 = (Integer) r6;
	r2 = ((Integer) 1);
	GOTO_LABEL(mercury__modules__get_interface_2_5_0_i24);
Define_label(mercury__modules__get_interface_2_5_0_i14);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i18);
	r1 = (Integer) r6;
	r7 = (Integer) r4;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r7;
	GOTO_LABEL(mercury__modules__get_interface_2_5_0_i24);
Define_label(mercury__modules__get_interface_2_5_0_i18);
	r1 = (Integer) r6;
Define_label(mercury__modules__get_interface_2_5_0_i24);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_interface_2_5_0_i26);
Define_label(mercury__modules__get_interface_2_5_0_i1);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module35)
	init_entry(mercury__modules__get_short_interface_2_0);
	init_label(mercury__modules__get_short_interface_2_0_i2);
	init_label(mercury__modules__get_short_interface_2_0_i3);
	init_label(mercury__modules__get_short_interface_2_0_i7);
	init_label(mercury__modules__get_short_interface_2_0_i9);
BEGIN_CODE

/* code for predicate 'get_short_interface'/2 in mode 0 */
Define_static(mercury__modules__get_short_interface_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = ((Integer) 1);
	incr_sp_push_msg(3, "get_short_interface");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__modules__get_short_interface_2_7_0),
		mercury__modules__get_short_interface_2_0_i2,
		STATIC(mercury__modules__get_short_interface_2_0));
Define_label(mercury__modules__get_short_interface_2_0_i2);
	update_prof_current_proc(LABEL(mercury__modules__get_short_interface_2_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__modules__get_short_interface_2_0_i3,
		STATIC(mercury__modules__get_short_interface_2_0));
	}
Define_label(mercury__modules__get_short_interface_2_0_i3);
	update_prof_current_proc(LABEL(mercury__modules__get_short_interface_2_0));
	if (((Integer) detstackvar(2) != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__get_short_interface_2_0_i9);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__modules__get_short_interface_2_0_i7,
		STATIC(mercury__modules__get_short_interface_2_0));
	}
Define_label(mercury__modules__get_short_interface_2_0_i7);
	update_prof_current_proc(LABEL(mercury__modules__get_short_interface_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__list__append_3_1);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__modules__get_short_interface_2_0));
	}
Define_label(mercury__modules__get_short_interface_2_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module36)
	init_entry(mercury__modules__get_short_interface_2_7_0);
	init_label(mercury__modules__get_short_interface_2_7_0_i25);
	init_label(mercury__modules__get_short_interface_2_7_0_i2);
	init_label(mercury__modules__get_short_interface_2_7_0_i10);
	init_label(mercury__modules__get_short_interface_2_7_0_i9);
	init_label(mercury__modules__get_short_interface_2_7_0_i6);
	init_label(mercury__modules__get_short_interface_2_7_0_i17);
	init_label(mercury__modules__get_short_interface_2_7_0_i12);
	init_label(mercury__modules__get_short_interface_2_7_0_i23);
	init_label(mercury__modules__get_short_interface_2_7_0_i1);
BEGIN_CODE

/* code for predicate 'get_short_interface_2'/7 in mode 0 */
Define_static(mercury__modules__get_short_interface_2_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i1);
Define_label(mercury__modules__get_short_interface_2_7_0_i25);
	r5 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	r6 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r8 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r6) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i2);
	if (((Integer) field(mktag(3), (Integer) r6, ((Integer) 0)) != ((Integer) 3)))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i2);
	r9 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	if ((tag((Integer) r9) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i2);
	if (((Integer) field(mktag(3), (Integer) r9, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r3;
	r1 = (Integer) r7;
	r3 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r8;
	GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i23);
	}
Define_label(mercury__modules__get_short_interface_2_7_0_i2);
	if ((tag((Integer) r6) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i6);
	if (((Integer) field(mktag(3), (Integer) r6, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i6);
	r1 = (Integer) field(mktag(3), (Integer) r6, ((Integer) 2));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i10);
	r10 = (Integer) r1;
	r1 = (Integer) r7;
	r7 = (Integer) r5;
	tag_incr_hp(r8, mktag(3), ((Integer) 4));
	field(mktag(3), (Integer) r8, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r8, ((Integer) 1)) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 1));
	field(mktag(3), (Integer) r8, ((Integer) 3)) = (Integer) field(mktag(3), (Integer) r6, ((Integer) 3));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r10, ((Integer) 1));
	field(mktag(3), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r10, ((Integer) 0));
	field(mktag(3), (Integer) r8, ((Integer) 2)) = (Integer) tempr1;
	GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i9);
	}
Define_label(mercury__modules__get_short_interface_2_7_0_i10);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i6);
	r1 = (Integer) r7;
	r7 = (Integer) r5;
	r8 = (Integer) r6;
Define_label(mercury__modules__get_short_interface_2_7_0_i9);
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r7;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r8;
	GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i23);
	}
Define_label(mercury__modules__get_short_interface_2_7_0_i6);
	if ((tag((Integer) r6) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i12);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r6, ((Integer) 0)),
		LABEL(mercury__modules__get_short_interface_2_7_0_i17) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i17) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i17) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i17) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i12) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i12) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i12) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i12) AND
		LABEL(mercury__modules__get_short_interface_2_7_0_i12));
Define_label(mercury__modules__get_short_interface_2_7_0_i17);
	r5 = (Integer) r8;
	r1 = (Integer) r7;
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	r4 = ((Integer) 0);
	GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i23);
Define_label(mercury__modules__get_short_interface_2_7_0_i12);
	r1 = (Integer) r7;
Define_label(mercury__modules__get_short_interface_2_7_0_i23);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__modules__get_short_interface_2_7_0_i25);
Define_label(mercury__modules__get_short_interface_2_7_0_i1);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module37)
	init_entry(mercury____Unify___modules__module_imports_0_0);
	init_label(mercury____Unify___modules__module_imports_0_0_i2);
	init_label(mercury____Unify___modules__module_imports_0_0_i4);
	init_label(mercury____Unify___modules__module_imports_0_0_i6);
	init_label(mercury____Unify___modules__module_imports_0_0_i1006);
	init_label(mercury____Unify___modules__module_imports_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___modules__module_imports_0_0);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___modules__module_imports_0_0_i1006);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___modules__module_imports_0_0_i2,
		ENTRY(mercury____Unify___modules__module_imports_0_0));
	}
Define_label(mercury____Unify___modules__module_imports_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___modules__module_imports_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___modules__module_imports_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___modules__module_imports_0_0_i4,
		ENTRY(mercury____Unify___modules__module_imports_0_0));
	}
Define_label(mercury____Unify___modules__module_imports_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___modules__module_imports_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___modules__module_imports_0_0_i1);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___modules__module_imports_0_0_i6,
		ENTRY(mercury____Unify___modules__module_imports_0_0));
	}
Define_label(mercury____Unify___modules__module_imports_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___modules__module_imports_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___modules__module_imports_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(6)))
		GOTO_LABEL(mercury____Unify___modules__module_imports_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___modules__module_imports_0_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___modules__module_imports_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module38)
	init_entry(mercury____Index___modules__module_imports_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___modules__module_imports_0_0);
	tailcall(STATIC(mercury____Index___modules_module_imports_0__ua10000_2_0),
		ENTRY(mercury____Index___modules__module_imports_0_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module39)
	init_entry(mercury____Compare___modules__module_imports_0_0);
	init_label(mercury____Compare___modules__module_imports_0_0_i4);
	init_label(mercury____Compare___modules__module_imports_0_0_i5);
	init_label(mercury____Compare___modules__module_imports_0_0_i3);
	init_label(mercury____Compare___modules__module_imports_0_0_i10);
	init_label(mercury____Compare___modules__module_imports_0_0_i16);
	init_label(mercury____Compare___modules__module_imports_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___modules__module_imports_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___modules__module_imports_0_0_i4,
		ENTRY(mercury____Compare___modules__module_imports_0_0));
	}
Define_label(mercury____Compare___modules__module_imports_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___modules__module_imports_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__module_imports_0_0_i3);
Define_label(mercury____Compare___modules__module_imports_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___modules__module_imports_0_0_i3);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___modules__module_imports_0_0_i10,
		ENTRY(mercury____Compare___modules__module_imports_0_0));
	}
Define_label(mercury____Compare___modules__module_imports_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___modules__module_imports_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__module_imports_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___modules__module_imports_0_0_i16,
		ENTRY(mercury____Compare___modules__module_imports_0_0));
	}
Define_label(mercury____Compare___modules__module_imports_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___modules__module_imports_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__module_imports_0_0_i5);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_modules__common_0);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___modules__module_imports_0_0_i22,
		ENTRY(mercury____Compare___modules__module_imports_0_0));
	}
Define_label(mercury____Compare___modules__module_imports_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___modules__module_imports_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__module_imports_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___modules__module_imports_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__modules_module40)
	init_entry(mercury____Unify___modules__deps_0_0);
	init_label(mercury____Unify___modules__deps_0_0_i2);
	init_label(mercury____Unify___modules__deps_0_0_i4);
	init_label(mercury____Unify___modules__deps_0_0_i1005);
	init_label(mercury____Unify___modules__deps_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___modules__deps_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___modules__deps_0_0_i1005);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___modules__deps_0_0_i1005);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___modules__deps_0_0_i2,
		STATIC(mercury____Unify___modules__deps_0_0));
	}
Define_label(mercury____Unify___modules__deps_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___modules__deps_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___modules__deps_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___modules__deps_0_0_i4,
		STATIC(mercury____Unify___modules__deps_0_0));
	}
Define_label(mercury____Unify___modules__deps_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___modules__deps_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___modules__deps_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		STATIC(mercury____Unify___modules__deps_0_0));
	}
Define_label(mercury____Unify___modules__deps_0_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___modules__deps_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__modules_module41)
	init_entry(mercury____Index___modules__deps_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___modules__deps_0_0);
	tailcall(STATIC(mercury____Index___modules_deps_0__ua10000_2_0),
		STATIC(mercury____Index___modules__deps_0_0));
END_MODULE

BEGIN_MODULE(mercury__modules_module42)
	init_entry(mercury____Compare___modules__deps_0_0);
	init_label(mercury____Compare___modules__deps_0_0_i4);
	init_label(mercury____Compare___modules__deps_0_0_i5);
	init_label(mercury____Compare___modules__deps_0_0_i3);
	init_label(mercury____Compare___modules__deps_0_0_i10);
	init_label(mercury____Compare___modules__deps_0_0_i16);
	init_label(mercury____Compare___modules__deps_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___modules__deps_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___modules__deps_0_0_i4,
		STATIC(mercury____Compare___modules__deps_0_0));
	}
Define_label(mercury____Compare___modules__deps_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___modules__deps_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__deps_0_0_i3);
Define_label(mercury____Compare___modules__deps_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___modules__deps_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___modules__deps_0_0_i10,
		STATIC(mercury____Compare___modules__deps_0_0));
	}
Define_label(mercury____Compare___modules__deps_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___modules__deps_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__deps_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___modules__deps_0_0_i16,
		STATIC(mercury____Compare___modules__deps_0_0));
	}
Define_label(mercury____Compare___modules__deps_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___modules__deps_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__deps_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___modules__deps_0_0_i22,
		STATIC(mercury____Compare___modules__deps_0_0));
	}
Define_label(mercury____Compare___modules__deps_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___modules__deps_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___modules__deps_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		STATIC(mercury____Compare___modules__deps_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__modules_bunch_0(void)
{
	mercury__modules_module0();
	mercury__modules_module1();
	mercury__modules_module2();
	mercury__modules_module3();
	mercury__modules_module4();
	mercury__modules_module5();
	mercury__modules_module6();
	mercury__modules_module7();
	mercury__modules_module8();
	mercury__modules_module9();
	mercury__modules_module10();
	mercury__modules_module11();
	mercury__modules_module12();
	mercury__modules_module13();
	mercury__modules_module14();
	mercury__modules_module15();
	mercury__modules_module16();
	mercury__modules_module17();
	mercury__modules_module18();
	mercury__modules_module19();
	mercury__modules_module20();
	mercury__modules_module21();
	mercury__modules_module22();
	mercury__modules_module23();
	mercury__modules_module24();
	mercury__modules_module25();
	mercury__modules_module26();
	mercury__modules_module27();
	mercury__modules_module28();
	mercury__modules_module29();
	mercury__modules_module30();
	mercury__modules_module31();
	mercury__modules_module32();
	mercury__modules_module33();
	mercury__modules_module34();
	mercury__modules_module35();
	mercury__modules_module36();
	mercury__modules_module37();
	mercury__modules_module38();
	mercury__modules_module39();
	mercury__modules_module40();
}

static void mercury__modules_bunch_1(void)
{
	mercury__modules_module41();
	mercury__modules_module42();
}

#endif

void mercury__modules__init(void); /* suppress gcc warning */
void mercury__modules__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__modules_bunch_0();
	mercury__modules_bunch_1();
#endif
}
