/*
** Automatically generated from `instmap.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__instmap__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__instmap__init_reachable_1_0);
Declare_label(mercury__instmap__init_reachable_1_0_i2);
Define_extern_entry(mercury__instmap__init_unreachable_1_0);
Define_extern_entry(mercury__instmap__instmap_delta_init_reachable_1_0);
Declare_label(mercury__instmap__instmap_delta_init_reachable_1_0_i2);
Define_extern_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
Define_extern_entry(mercury__instmap__is_reachable_1_0);
Declare_label(mercury__instmap__is_reachable_1_0_i1);
Define_extern_entry(mercury__instmap__is_unreachable_1_0);
Declare_label(mercury__instmap__is_unreachable_1_0_i1);
Define_extern_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
Declare_label(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
Define_extern_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
Declare_label(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
Define_extern_entry(mercury__instmap__from_assoc_list_2_0);
Declare_label(mercury__instmap__from_assoc_list_2_0_i2);
Define_extern_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
Declare_label(mercury__instmap__instmap_delta_from_assoc_list_2_0_i2);
Define_extern_entry(mercury__instmap__vars_2_0);
Declare_label(mercury__instmap__vars_2_0_i2);
Define_extern_entry(mercury__instmap__vars_list_2_0);
Declare_label(mercury__instmap__vars_list_2_0_i1002);
Define_extern_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
Declare_label(mercury__instmap__instmap_delta_changed_vars_2_0_i4);
Declare_label(mercury__instmap__instmap_delta_changed_vars_2_0_i1004);
Define_extern_entry(mercury__instmap__lookup_var_3_0);
Declare_label(mercury__instmap__lookup_var_3_0_i1002);
Define_extern_entry(mercury__instmap__instmap_delta_lookup_var_3_0);
Define_extern_entry(mercury__instmap__lookup_vars_3_0);
Declare_label(mercury__instmap__lookup_vars_3_0_i4);
Declare_label(mercury__instmap__lookup_vars_3_0_i5);
Declare_label(mercury__instmap__lookup_vars_3_0_i1002);
Define_extern_entry(mercury__instmap__set_4_0);
Declare_label(mercury__instmap__set_4_0_i4);
Declare_label(mercury__instmap__set_4_0_i1002);
Define_extern_entry(mercury__instmap__instmap_delta_insert_4_0);
Declare_label(mercury__instmap__instmap_delta_insert_4_0_i4);
Declare_label(mercury__instmap__instmap_delta_insert_4_0_i1002);
Define_extern_entry(mercury__instmap__compute_instmap_delta_4_0);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i6);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i7);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i8);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i1004);
Define_extern_entry(mercury__instmap__apply_instmap_delta_3_0);
Declare_label(mercury__instmap__apply_instmap_delta_3_0_i6);
Declare_label(mercury__instmap__apply_instmap_delta_3_0_i1004);
Define_extern_entry(mercury__instmap__instmap_delta_apply_instmap_delta_3_0);
Declare_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6);
Declare_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i1004);
Define_extern_entry(mercury__instmap__merge_5_0);
Declare_label(mercury__instmap__merge_5_0_i2);
Declare_label(mercury__instmap__merge_5_0_i3);
Declare_label(mercury__instmap__merge_5_0_i4);
Declare_label(mercury__instmap__merge_5_0_i5);
Declare_label(mercury__instmap__merge_5_0_i11);
Declare_label(mercury__instmap__merge_5_0_i12);
Declare_label(mercury__instmap__merge_5_0_i13);
Declare_label(mercury__instmap__merge_5_0_i17);
Declare_label(mercury__instmap__merge_5_0_i18);
Declare_label(mercury__instmap__merge_5_0_i8);
Define_extern_entry(mercury__instmap__restrict_3_0);
Declare_label(mercury__instmap__restrict_3_0_i4);
Declare_label(mercury__instmap__restrict_3_0_i1002);
Define_extern_entry(mercury__instmap__instmap_delta_restrict_3_0);
Declare_label(mercury__instmap__instmap_delta_restrict_3_0_i4);
Declare_label(mercury__instmap__instmap_delta_restrict_3_0_i1002);
Define_extern_entry(mercury__instmap__instmap_delta_delete_vars_3_0);
Declare_label(mercury__instmap__instmap_delta_delete_vars_3_0_i4);
Declare_label(mercury__instmap__instmap_delta_delete_vars_3_0_i1002);
Define_extern_entry(mercury__instmap__no_output_vars_4_0);
Declare_label(mercury__instmap__no_output_vars_4_0_i4);
Declare_label(mercury__instmap__no_output_vars_4_0_i1002);
Define_extern_entry(mercury__instmap__merge_instmap_delta_5_0);
Declare_label(mercury__instmap__merge_instmap_delta_5_0_i6);
Declare_label(mercury__instmap__merge_instmap_delta_5_0_i7);
Declare_label(mercury__instmap__merge_instmap_delta_5_0_i1004);
Declare_label(mercury__instmap__merge_instmap_delta_5_0_i1003);
Define_extern_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i4);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i5);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i6);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i1002);
Define_extern_entry(mercury__instmap__to_assoc_list_2_0);
Declare_label(mercury__instmap__to_assoc_list_2_0_i1002);
Define_extern_entry(mercury__instmap__instmap_delta_to_assoc_list_2_0);
Declare_label(mercury__instmap__instmap_delta_to_assoc_list_2_0_i1002);
Declare_static(mercury__instmap__instmapping_lookup_var_3_0);
Declare_label(mercury__instmap__instmapping_lookup_var_3_0_i4);
Declare_label(mercury__instmap__instmapping_lookup_var_3_0_i1000);
Declare_static(mercury__instmap__get_reachable_instmaps_2_0);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i7);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i1003);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i1005);
Declare_static(mercury__instmap__merge_2_7_0);
Declare_label(mercury__instmap__merge_2_7_0_i4);
Declare_label(mercury__instmap__merge_2_7_0_i5);
Declare_label(mercury__instmap__merge_2_7_0_i9);
Declare_label(mercury__instmap__merge_2_7_0_i6);
Declare_label(mercury__instmap__merge_2_7_0_i1000);
Declare_static(mercury__instmap__merge_var_7_0);
Declare_label(mercury__instmap__merge_var_7_0_i4);
Declare_label(mercury__instmap__merge_var_7_0_i5);
Declare_label(mercury__instmap__merge_var_7_0_i8);
Declare_label(mercury__instmap__merge_var_7_0_i7);
Declare_label(mercury__instmap__merge_var_7_0_i1003);
Declare_static(mercury__instmap__compute_instmap_delta_2_4_0);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i4);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i5);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i6);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i9);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i8);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i1004);
Declare_static(mercury__instmap__no_output_vars_2_4_0);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i4);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i7);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i6);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i9);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i10);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i1004);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i1);
Declare_static(mercury__instmap__merge_instmapping_delta_2_6_0);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i4);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i7);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i11);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i13);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i10);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i6);
Declare_label(mercury__instmap__merge_instmapping_delta_2_6_0_i1000);
Declare_static(mercury__instmap__instmap_delta_apply_sub_2_5_0);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i6);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i10);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i12);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1004);
Define_extern_entry(mercury____Unify___instmap__instmap_0_0);
Declare_label(mercury____Unify___instmap__instmap_0_0_i1008);
Declare_label(mercury____Unify___instmap__instmap_0_0_i1005);
Declare_label(mercury____Unify___instmap__instmap_0_0_i1007);
Define_extern_entry(mercury____Index___instmap__instmap_0_0);
Declare_label(mercury____Index___instmap__instmap_0_0_i3);
Define_extern_entry(mercury____Compare___instmap__instmap_0_0);
Declare_label(mercury____Compare___instmap__instmap_0_0_i2);
Declare_label(mercury____Compare___instmap__instmap_0_0_i3);
Declare_label(mercury____Compare___instmap__instmap_0_0_i4);
Declare_label(mercury____Compare___instmap__instmap_0_0_i6);
Declare_label(mercury____Compare___instmap__instmap_0_0_i11);
Declare_label(mercury____Compare___instmap__instmap_0_0_i9);
Define_extern_entry(mercury____Unify___instmap__instmap_delta_0_0);
Define_extern_entry(mercury____Index___instmap__instmap_delta_0_0);
Define_extern_entry(mercury____Compare___instmap__instmap_delta_0_0);

extern Word * mercury_data_instmap__base_type_layout_instmap_0[];
Word * mercury_data_instmap__base_type_info_instmap_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___instmap__instmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___instmap__instmap_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___instmap__instmap_0_0),
	(Word *) (Integer) mercury_data_instmap__base_type_layout_instmap_0
};

extern Word * mercury_data_instmap__base_type_layout_instmap_delta_0[];
Word * mercury_data_instmap__base_type_info_instmap_delta_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___instmap__instmap_delta_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___instmap__instmap_delta_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___instmap__instmap_delta_0_0),
	(Word *) (Integer) mercury_data_instmap__base_type_layout_instmap_delta_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_instmap__base_type_layout_instmapping_0[];
Word * mercury_data_instmap__base_type_info_instmapping_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_instmap__base_type_layout_instmapping_0
};

extern Word * mercury_data_instmap__common_1[];
Word * mercury_data_instmap__base_type_layout_instmapping_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_1)
};

extern Word * mercury_data_instmap__common_3[];
Word * mercury_data_instmap__base_type_layout_instmap_delta_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_3),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_3),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_3),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_instmap__common_3)
};

extern Word * mercury_data_instmap__common_4[];
extern Word * mercury_data_instmap__common_5[];
Word * mercury_data_instmap__base_type_layout_instmap_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_instmap__common_4),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_instmap__common_5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_prog_data__base_type_info_inst_0[];
Word * mercury_data_instmap__common_0[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0
};

Word * mercury_data_instmap__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_instmap__common_0)
};

Word * mercury_data_instmap__common_2[] = {
	(Word *) (Integer) mercury_data_instmap__base_type_info_instmap_0
};

Word * mercury_data_instmap__common_3[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_instmap__common_2)
};

Word * mercury_data_instmap__common_4[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("unreachable", 11)
};

Word * mercury_data_instmap__common_5[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_instmap__common_0),
	(Word *) string_const("reachable", 9)
};

BEGIN_MODULE(mercury__instmap_module0)
	init_entry(mercury__instmap__init_reachable_1_0);
	init_label(mercury__instmap__init_reachable_1_0_i2);
BEGIN_CODE

/* code for predicate 'instmap__init_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__init_reachable_1_0);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap__init_reachable");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__init_reachable_1_0_i2,
		ENTRY(mercury__instmap__init_reachable_1_0));
	}
Define_label(mercury__instmap__init_reachable_1_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__init_reachable_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module1)
	init_entry(mercury__instmap__init_unreachable_1_0);
BEGIN_CODE

/* code for predicate 'instmap__init_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__init_unreachable_1_0);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module2)
	init_entry(mercury__instmap__instmap_delta_init_reachable_1_0);
	init_label(mercury__instmap__instmap_delta_init_reachable_1_0_i2);
BEGIN_CODE

/* code for predicate 'instmap_delta_init_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_init_reachable_1_0);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_init_reachable");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__instmap_delta_init_reachable_1_0_i2,
		ENTRY(mercury__instmap__instmap_delta_init_reachable_1_0));
	}
Define_label(mercury__instmap__instmap_delta_init_reachable_1_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_init_reachable_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module3)
	init_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
BEGIN_CODE

/* code for predicate 'instmap_delta_init_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module4)
	init_entry(mercury__instmap__is_reachable_1_0);
	init_label(mercury__instmap__is_reachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'instmap__is_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__is_reachable_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__is_reachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__is_reachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module5)
	init_entry(mercury__instmap__is_unreachable_1_0);
	init_label(mercury__instmap__is_unreachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'instmap__is_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__is_unreachable_1_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__is_unreachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__is_unreachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module6)
	init_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
	init_label(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'instmap_delta_is_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module7)
	init_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	init_label(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'instmap_delta_is_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module8)
	init_entry(mercury__instmap__from_assoc_list_2_0);
	init_label(mercury__instmap__from_assoc_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'instmap__from_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__from_assoc_list_2_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap__from_assoc_list");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__instmap__from_assoc_list_2_0_i2,
		ENTRY(mercury__instmap__from_assoc_list_2_0));
	}
Define_label(mercury__instmap__from_assoc_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__from_assoc_list_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module9)
	init_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
	init_label(mercury__instmap__instmap_delta_from_assoc_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'instmap_delta_from_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_from_assoc_list");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__instmap__instmap_delta_from_assoc_list_2_0_i2,
		ENTRY(mercury__instmap__instmap_delta_from_assoc_list_2_0));
	}
Define_label(mercury__instmap__instmap_delta_from_assoc_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_from_assoc_list_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module10)
	init_entry(mercury__instmap__vars_2_0);
	init_label(mercury__instmap__vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'instmap__vars'/2 in mode 0 */
Define_entry(mercury__instmap__vars_2_0);
	incr_sp_push_msg(1, "instmap__vars");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__instmap__vars_list_2_0),
		mercury__instmap__vars_2_0_i2,
		ENTRY(mercury__instmap__vars_2_0));
	}
Define_label(mercury__instmap__vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__vars_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		ENTRY(mercury__instmap__vars_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module11)
	init_entry(mercury__instmap__vars_list_2_0);
	init_label(mercury__instmap__vars_list_2_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__vars_list'/2 in mode 0 */
Define_entry(mercury__instmap__vars_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__vars_list_2_0_i1002);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__keys_2_0);
	tailcall(ENTRY(mercury__map__keys_2_0),
		ENTRY(mercury__instmap__vars_list_2_0));
	}
Define_label(mercury__instmap__vars_list_2_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module12)
	init_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
	init_label(mercury__instmap__instmap_delta_changed_vars_2_0_i4);
	init_label(mercury__instmap__instmap_delta_changed_vars_2_0_i1004);
BEGIN_CODE

/* code for predicate 'instmap_delta_changed_vars'/2 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_changed_vars_2_0_i1004);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_changed_vars");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__instmap_delta_changed_vars_2_0_i4,
		ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0));
	}
Define_label(mercury__instmap__instmap_delta_changed_vars_2_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_changed_vars_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__set__sorted_list_to_set_2_0);
	tailcall(ENTRY(mercury__set__sorted_list_to_set_2_0),
		ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0));
	}
Define_label(mercury__instmap__instmap_delta_changed_vars_2_0_i1004);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__init_1_0);
	tailcall(ENTRY(mercury__set__init_1_0),
		ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module13)
	init_entry(mercury__instmap__lookup_var_3_0);
	init_label(mercury__instmap__lookup_var_3_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__lookup_var'/3 in mode 0 */
Define_entry(mercury__instmap__lookup_var_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__lookup_var_3_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__instmap__instmapping_lookup_var_3_0),
		ENTRY(mercury__instmap__lookup_var_3_0));
Define_label(mercury__instmap__lookup_var_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module14)
	init_entry(mercury__instmap__instmap_delta_lookup_var_3_0);
BEGIN_CODE

/* code for predicate 'instmap_delta_lookup_var'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_lookup_var_3_0);
	{
		tailcall(STATIC(mercury__instmap__lookup_var_3_0),
		ENTRY(mercury__instmap__instmap_delta_lookup_var_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module15)
	init_entry(mercury__instmap__lookup_vars_3_0);
	init_label(mercury__instmap__lookup_vars_3_0_i4);
	init_label(mercury__instmap__lookup_vars_3_0_i5);
	init_label(mercury__instmap__lookup_vars_3_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__lookup_vars'/3 in mode 0 */
Define_entry(mercury__instmap__lookup_vars_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__lookup_vars_3_0_i1002);
	incr_sp_push_msg(3, "instmap__lookup_vars");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__lookup_vars_3_0_i4,
		ENTRY(mercury__instmap__lookup_vars_3_0));
	}
Define_label(mercury__instmap__lookup_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__lookup_vars_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__instmap__lookup_vars_3_0,
		LABEL(mercury__instmap__lookup_vars_3_0_i5),
		ENTRY(mercury__instmap__lookup_vars_3_0));
Define_label(mercury__instmap__lookup_vars_3_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__lookup_vars_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__instmap__lookup_vars_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module16)
	init_entry(mercury__instmap__set_4_0);
	init_label(mercury__instmap__set_4_0_i4);
	init_label(mercury__instmap__set_4_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__set'/4 in mode 0 */
Define_entry(mercury__instmap__set_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__set_4_0_i1002);
	r5 = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap__set");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__set_4_0_i4,
		ENTRY(mercury__instmap__set_4_0));
	}
Define_label(mercury__instmap__set_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__set_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__set_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module17)
	init_entry(mercury__instmap__instmap_delta_insert_4_0);
	init_label(mercury__instmap__instmap_delta_insert_4_0_i4);
	init_label(mercury__instmap__instmap_delta_insert_4_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap_delta_insert'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_insert_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_insert_4_0_i1002);
	r5 = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_insert");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__instmap__instmap_delta_insert_4_0_i4,
		ENTRY(mercury__instmap__instmap_delta_insert_4_0));
	}
Define_label(mercury__instmap__instmap_delta_insert_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_insert_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_insert_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module18)
	init_entry(mercury__instmap__compute_instmap_delta_4_0);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i6);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i7);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i8);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i1004);
BEGIN_CODE

/* code for predicate 'compute_instmap_delta'/4 in mode 0 */
Define_entry(mercury__instmap__compute_instmap_delta_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_4_0_i1004);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_4_0_i1004);
	incr_sp_push_msg(3, "compute_instmap_delta");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__compute_instmap_delta_4_0_i6,
		ENTRY(mercury__instmap__compute_instmap_delta_4_0));
	}
Define_label(mercury__instmap__compute_instmap_delta_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__instmap__compute_instmap_delta_2_4_0),
		mercury__instmap__compute_instmap_delta_4_0_i7,
		ENTRY(mercury__instmap__compute_instmap_delta_4_0));
Define_label(mercury__instmap__compute_instmap_delta_4_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__from_sorted_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_sorted_assoc_list_2_0),
		mercury__instmap__compute_instmap_delta_4_0_i8,
		ENTRY(mercury__instmap__compute_instmap_delta_4_0));
	}
Define_label(mercury__instmap__compute_instmap_delta_4_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_4_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module19)
	init_entry(mercury__instmap__apply_instmap_delta_3_0);
	init_label(mercury__instmap__apply_instmap_delta_3_0_i6);
	init_label(mercury__instmap__apply_instmap_delta_3_0_i1004);
BEGIN_CODE

/* code for predicate 'instmap__apply_instmap_delta'/3 in mode 0 */
Define_entry(mercury__instmap__apply_instmap_delta_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__apply_instmap_delta_3_0_i1004);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__apply_instmap_delta_3_0_i1004);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap__apply_instmap_delta");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__overlay_3_0);
	call_localret(ENTRY(mercury__map__overlay_3_0),
		mercury__instmap__apply_instmap_delta_3_0_i6,
		ENTRY(mercury__instmap__apply_instmap_delta_3_0));
	}
Define_label(mercury__instmap__apply_instmap_delta_3_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__apply_instmap_delta_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__apply_instmap_delta_3_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module20)
	init_entry(mercury__instmap__instmap_delta_apply_instmap_delta_3_0);
	init_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6);
	init_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i1004);
BEGIN_CODE

/* code for predicate 'instmap_delta_apply_instmap_delta'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_apply_instmap_delta_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i1004);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i1004);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_apply_instmap_delta");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__overlay_3_0);
	call_localret(ENTRY(mercury__map__overlay_3_0),
		mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6,
		ENTRY(mercury__instmap__instmap_delta_apply_instmap_delta_3_0));
	}
Define_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_instmap_delta_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module21)
	init_entry(mercury__instmap__merge_5_0);
	init_label(mercury__instmap__merge_5_0_i2);
	init_label(mercury__instmap__merge_5_0_i3);
	init_label(mercury__instmap__merge_5_0_i4);
	init_label(mercury__instmap__merge_5_0_i5);
	init_label(mercury__instmap__merge_5_0_i11);
	init_label(mercury__instmap__merge_5_0_i12);
	init_label(mercury__instmap__merge_5_0_i13);
	init_label(mercury__instmap__merge_5_0_i17);
	init_label(mercury__instmap__merge_5_0_i18);
	init_label(mercury__instmap__merge_5_0_i8);
BEGIN_CODE

/* code for predicate 'instmap__merge'/5 in mode 0 */
Define_entry(mercury__instmap__merge_5_0);
	incr_sp_push_msg(7, "instmap__merge");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__instmap__merge_5_0_i2,
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__instmap__merge_5_0_i3,
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i3);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__instmap__get_reachable_instmaps_2_0),
		mercury__instmap__merge_5_0_i4,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_5_0_i5);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i5);
	r3 = (Integer) detstackvar(5);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_5_0_i8);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__merge_5_0_i11,
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__instmap__merge_2_7_0),
		mercury__instmap__merge_5_0_i12,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__mode_info__mode_info_set_module_info_3_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_module_info_3_0),
		mercury__instmap__merge_5_0_i13,
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i13);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	if (((Integer) detstackvar(2) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_5_0_i18);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 0)), ((Integer) 0));
	{
	Declare_entry(mercury__set__singleton_set_2_1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__instmap__merge_5_0_i17,
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i17);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__mode_info__mode_info_error_4_0);
	call_localret(ENTRY(mercury__mode_info__mode_info_error_4_0),
		mercury__instmap__merge_5_0_i18,
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i18);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__merge_5_0));
	}
Define_label(mercury__instmap__merge_5_0_i8);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__merge_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module22)
	init_entry(mercury__instmap__restrict_3_0);
	init_label(mercury__instmap__restrict_3_0_i4);
	init_label(mercury__instmap__restrict_3_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__restrict'/3 in mode 0 */
Define_entry(mercury__instmap__restrict_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__restrict_3_0_i1002);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap__restrict");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__select_3_0);
	call_localret(ENTRY(mercury__map__select_3_0),
		mercury__instmap__restrict_3_0_i4,
		ENTRY(mercury__instmap__restrict_3_0));
	}
Define_label(mercury__instmap__restrict_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__restrict_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__restrict_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module23)
	init_entry(mercury__instmap__instmap_delta_restrict_3_0);
	init_label(mercury__instmap__instmap_delta_restrict_3_0_i4);
	init_label(mercury__instmap__instmap_delta_restrict_3_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap_delta_restrict'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_restrict_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_restrict_3_0_i1002);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_restrict");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__select_3_0);
	call_localret(ENTRY(mercury__map__select_3_0),
		mercury__instmap__instmap_delta_restrict_3_0_i4,
		ENTRY(mercury__instmap__instmap_delta_restrict_3_0));
	}
Define_label(mercury__instmap__instmap_delta_restrict_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_restrict_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_restrict_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module24)
	init_entry(mercury__instmap__instmap_delta_delete_vars_3_0);
	init_label(mercury__instmap__instmap_delta_delete_vars_3_0_i4);
	init_label(mercury__instmap__instmap_delta_delete_vars_3_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap_delta_delete_vars'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_delete_vars_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_delete_vars_3_0_i1002);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmap_delta_delete_vars");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__delete_list_3_1);
	call_localret(ENTRY(mercury__map__delete_list_3_1),
		mercury__instmap__instmap_delta_delete_vars_3_0_i4,
		ENTRY(mercury__instmap__instmap_delta_delete_vars_3_0));
	}
Define_label(mercury__instmap__instmap_delta_delete_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_delete_vars_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_delete_vars_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module25)
	init_entry(mercury__instmap__no_output_vars_4_0);
	init_label(mercury__instmap__no_output_vars_4_0_i4);
	init_label(mercury__instmap__no_output_vars_4_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__no_output_vars'/4 in mode 0 */
Define_entry(mercury__instmap__no_output_vars_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__no_output_vars_4_0_i1002);
	incr_sp_push_msg(4, "instmap__no_output_vars");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__no_output_vars_4_0_i4,
		ENTRY(mercury__instmap__no_output_vars_4_0));
	}
Define_label(mercury__instmap__no_output_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__instmap__no_output_vars_2_4_0),
		ENTRY(mercury__instmap__no_output_vars_4_0));
Define_label(mercury__instmap__no_output_vars_4_0_i1002);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module26)
	init_entry(mercury__instmap__merge_instmap_delta_5_0);
	init_label(mercury__instmap__merge_instmap_delta_5_0_i6);
	init_label(mercury__instmap__merge_instmap_delta_5_0_i7);
	init_label(mercury__instmap__merge_instmap_delta_5_0_i1004);
	init_label(mercury__instmap__merge_instmap_delta_5_0_i1003);
BEGIN_CODE

/* code for predicate 'merge_instmap_delta'/5 in mode 0 */
Define_entry(mercury__instmap__merge_instmap_delta_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_instmap_delta_5_0_i1003);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_instmap_delta_5_0_i1004);
	incr_sp_push_msg(4, "merge_instmap_delta");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__merge_instmap_delta_5_0_i6,
		ENTRY(mercury__instmap__merge_instmap_delta_5_0));
	}
Define_label(mercury__instmap__merge_instmap_delta_5_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_5_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__instmap__merge_instmapping_delta_2_6_0),
		mercury__instmap__merge_instmap_delta_5_0_i7,
		ENTRY(mercury__instmap__merge_instmap_delta_5_0));
Define_label(mercury__instmap__merge_instmap_delta_5_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__instmap__merge_instmap_delta_5_0_i1004);
	r2 = (Integer) r3;
	proceed();
Define_label(mercury__instmap__merge_instmap_delta_5_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module27)
	init_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i4);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i5);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i6);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap_delta_apply_sub'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_4_0_i1002);
	incr_sp_push_msg(4, "instmap_delta_apply_sub");
	detstackvar(4) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__instmap__instmap_delta_apply_sub_4_0_i4,
		ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0));
	}
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__instmap_delta_apply_sub_4_0_i5,
		ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0));
	}
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0),
		mercury__instmap__instmap_delta_apply_sub_4_0_i6,
		ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module28)
	init_entry(mercury__instmap__to_assoc_list_2_0);
	init_label(mercury__instmap__to_assoc_list_2_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap__to_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__to_assoc_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__to_assoc_list_2_0_i1002);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		ENTRY(mercury__instmap__to_assoc_list_2_0));
	}
Define_label(mercury__instmap__to_assoc_list_2_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module29)
	init_entry(mercury__instmap__instmap_delta_to_assoc_list_2_0);
	init_label(mercury__instmap__instmap_delta_to_assoc_list_2_0_i1002);
BEGIN_CODE

/* code for predicate 'instmap_delta_to_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_to_assoc_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_to_assoc_list_2_0_i1002);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		ENTRY(mercury__instmap__instmap_delta_to_assoc_list_2_0));
	}
Define_label(mercury__instmap__instmap_delta_to_assoc_list_2_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module30)
	init_entry(mercury__instmap__instmapping_lookup_var_3_0);
	init_label(mercury__instmap__instmapping_lookup_var_3_0_i4);
	init_label(mercury__instmap__instmapping_lookup_var_3_0_i1000);
BEGIN_CODE

/* code for predicate 'instmapping_lookup_var'/3 in mode 0 */
Define_static(mercury__instmap__instmapping_lookup_var_3_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	incr_sp_push_msg(1, "instmapping_lookup_var");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__instmapping_lookup_var_3_0_i4,
		STATIC(mercury__instmap__instmapping_lookup_var_3_0));
	}
Define_label(mercury__instmap__instmapping_lookup_var_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmapping_lookup_var_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__instmapping_lookup_var_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__instmap__instmapping_lookup_var_3_0_i1000);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module31)
	init_entry(mercury__instmap__get_reachable_instmaps_2_0);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i7);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i1003);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i1005);
BEGIN_CODE

/* code for predicate 'get_reachable_instmaps'/2 in mode 0 */
Define_static(mercury__instmap__get_reachable_instmaps_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__get_reachable_instmaps_2_0_i1003);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__get_reachable_instmaps_2_0_i1005);
	incr_sp_push_msg(2, "get_reachable_instmaps");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = (Integer) r2;
	localcall(mercury__instmap__get_reachable_instmaps_2_0,
		LABEL(mercury__instmap__get_reachable_instmaps_2_0_i7),
		STATIC(mercury__instmap__get_reachable_instmaps_2_0));
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__get_reachable_instmaps_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i1005);
	r1 = (Integer) r2;
	localtailcall(mercury__instmap__get_reachable_instmaps_2_0,
		STATIC(mercury__instmap__get_reachable_instmaps_2_0));
END_MODULE

BEGIN_MODULE(mercury__instmap_module32)
	init_entry(mercury__instmap__merge_2_7_0);
	init_label(mercury__instmap__merge_2_7_0_i4);
	init_label(mercury__instmap__merge_2_7_0_i5);
	init_label(mercury__instmap__merge_2_7_0_i9);
	init_label(mercury__instmap__merge_2_7_0_i6);
	init_label(mercury__instmap__merge_2_7_0_i1000);
BEGIN_CODE

/* code for predicate 'instmap__merge_2'/7 in mode 0 */
Define_static(mercury__instmap__merge_2_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_2_7_0_i1000);
	incr_sp_push_msg(4, "instmap__merge_2");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__instmap__merge_2_7_0,
		LABEL(mercury__instmap__merge_2_7_0_i4),
		STATIC(mercury__instmap__merge_2_7_0));
Define_label(mercury__instmap__merge_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_2_7_0));
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__instmap__merge_var_7_0),
		mercury__instmap__merge_2_7_0_i5,
		STATIC(mercury__instmap__merge_2_7_0));
Define_label(mercury__instmap__merge_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__merge_2_7_0));
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__instmap__merge_2_7_0_i6);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r3;
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(detstackvar(2), mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	r3 = (Integer) r2;
	field(mktag(1), (Integer) detstackvar(2), ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	field(mktag(1), (Integer) detstackvar(2), ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__merge_2_7_0_i9,
		STATIC(mercury__instmap__merge_2_7_0));
	}
	}
Define_label(mercury__instmap__merge_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__merge_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__instmap__merge_2_7_0_i6);
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	detstackvar(2) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__merge_2_7_0_i9,
		STATIC(mercury__instmap__merge_2_7_0));
	}
	}
Define_label(mercury__instmap__merge_2_7_0_i1000);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module33)
	init_entry(mercury__instmap__merge_var_7_0);
	init_label(mercury__instmap__merge_var_7_0_i4);
	init_label(mercury__instmap__merge_var_7_0_i5);
	init_label(mercury__instmap__merge_var_7_0_i8);
	init_label(mercury__instmap__merge_var_7_0_i7);
	init_label(mercury__instmap__merge_var_7_0_i1003);
BEGIN_CODE

/* code for predicate 'instmap__merge_var'/7 in mode 0 */
Define_static(mercury__instmap__merge_var_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_var_7_0_i1003);
	incr_sp_push_msg(5, "instmap__merge_var");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__instmap__merge_var_7_0,
		LABEL(mercury__instmap__merge_var_7_0_i4),
		STATIC(mercury__instmap__merge_var_7_0));
Define_label(mercury__instmap__merge_var_7_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_var_7_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	{
		call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__merge_var_7_0_i5,
		STATIC(mercury__instmap__merge_var_7_0));
	}
	}
Define_label(mercury__instmap__merge_var_7_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__merge_var_7_0));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__inst_match__inst_merge_5_0);
	call_localret(ENTRY(mercury__inst_match__inst_merge_5_0),
		mercury__instmap__merge_var_7_0_i8,
		STATIC(mercury__instmap__merge_var_7_0));
	}
	}
Define_label(mercury__instmap__merge_var_7_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__merge_var_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__merge_var_7_0_i7);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__instmap__merge_var_7_0_i7);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	r3 = (Integer) detstackvar(3);
	r4 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__instmap__merge_var_7_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 1)));
	r4 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module34)
	init_entry(mercury__instmap__compute_instmap_delta_2_4_0);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i4);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i5);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i6);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i9);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i8);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i1004);
BEGIN_CODE

/* code for predicate 'compute_instmap_delta_2'/4 in mode 0 */
Define_static(mercury__instmap__compute_instmap_delta_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i1004);
	incr_sp_push_msg(6, "compute_instmap_delta_2");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) tempr1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__instmap__instmapping_lookup_var_3_0),
		mercury__instmap__compute_instmap_delta_2_4_0_i4,
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
	}
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__instmap__instmapping_lookup_var_3_0),
		mercury__instmap__compute_instmap_delta_2_4_0_i5,
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__instmap__compute_instmap_delta_2_4_0,
		LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i6),
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury____Unify___prog_data__inst_0_0);
	call_localret(ENTRY(mercury____Unify___prog_data__inst_0_0),
		mercury__instmap__compute_instmap_delta_2_4_0_i9,
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
	}
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i8);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i8);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module35)
	init_entry(mercury__instmap__no_output_vars_2_4_0);
	init_label(mercury__instmap__no_output_vars_2_4_0_i4);
	init_label(mercury__instmap__no_output_vars_2_4_0_i7);
	init_label(mercury__instmap__no_output_vars_2_4_0_i6);
	init_label(mercury__instmap__no_output_vars_2_4_0_i9);
	init_label(mercury__instmap__no_output_vars_2_4_0_i10);
	init_label(mercury__instmap__no_output_vars_2_4_0_i1004);
	init_label(mercury__instmap__no_output_vars_2_4_0_i1);
BEGIN_CODE

/* code for predicate 'instmap__no_output_vars_2'/4 in mode 0 */
Define_static(mercury__instmap__no_output_vars_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i1004);
	incr_sp_push_msg(6, "instmap__no_output_vars_2");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) tempr1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
		call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__no_output_vars_2_4_0_i4,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
	}
	}
Define_label(mercury__instmap__no_output_vars_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_2_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__no_output_vars_2_4_0_i7,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
	}
Define_label(mercury__instmap__no_output_vars_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i6);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i9);
Define_label(mercury__instmap__no_output_vars_2_4_0_i6);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(4);
	r1 = (Integer) r2;
Define_label(mercury__instmap__no_output_vars_2_4_0_i9);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r3;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__inst_match__inst_matches_binding_3_0);
	call_localret(ENTRY(mercury__inst_match__inst_matches_binding_3_0),
		mercury__instmap__no_output_vars_2_4_0_i10,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
	}
Define_label(mercury__instmap__no_output_vars_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i1);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__instmap__no_output_vars_2_4_0,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
Define_label(mercury__instmap__no_output_vars_2_4_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__no_output_vars_2_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module36)
	init_entry(mercury__instmap__merge_instmapping_delta_2_6_0);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i4);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i7);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i11);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i13);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i10);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i6);
	init_label(mercury__instmap__merge_instmapping_delta_2_6_0_i1000);
BEGIN_CODE

/* code for predicate 'merge_instmapping_delta_2'/6 in mode 0 */
Define_static(mercury__instmap__merge_instmapping_delta_2_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_6_0_i1000);
	incr_sp_push_msg(7, "merge_instmapping_delta_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__instmap__merge_instmapping_delta_2_6_0_i4,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
	}
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_6_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__merge_instmapping_delta_2_6_0_i7,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
	}
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_6_0_i6);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__inst_match__inst_merge_5_0);
	call_localret(ENTRY(mercury__inst_match__inst_merge_5_0),
		mercury__instmap__merge_instmapping_delta_2_6_0_i11,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
	}
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_6_0_i10);
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r3;
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r5 = (Integer) r2;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__instmap__merge_instmapping_delta_2_6_0_i13,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
	}
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i13);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__instmap__merge_instmapping_delta_2_6_0,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i10);
	r1 = string_const("merge_instmapping_delta_2: unexpected mode error", 48);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__merge_instmapping_delta_2_6_0_i13,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
	}
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i6);
	r2 = (Integer) detstackvar(1);
	r1 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__instmap__merge_instmapping_delta_2_6_0,
		STATIC(mercury__instmap__merge_instmapping_delta_2_6_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_6_0_i1000);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module37)
	init_entry(mercury__instmap__instmap_delta_apply_sub_2_5_0);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i6);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i10);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i12);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1004);
BEGIN_CODE

/* code for predicate 'instmap_delta_apply_sub_2'/5 in mode 0 */
Define_static(mercury__instmap__instmap_delta_apply_sub_2_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1004);
	incr_sp_push_msg(7, "instmap_delta_apply_sub_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(3) = (Integer) r4;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i6,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	}
	}
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
	if (((Integer) detstackvar(1) == ((Integer) 0)))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(4);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
	r1 = string_const("instmap_delta_apply_sub_2: no substitute", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i10,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	}
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(2);
	r8 = (Integer) detstackvar(6);
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
	detstackvar(1) = (Integer) r6;
	detstackvar(2) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i12,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	}
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__instmap__instmap_delta_apply_sub_2_5_0,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1004);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module38)
	init_entry(mercury____Unify___instmap__instmap_0_0);
	init_label(mercury____Unify___instmap__instmap_0_0_i1008);
	init_label(mercury____Unify___instmap__instmap_0_0_i1005);
	init_label(mercury____Unify___instmap__instmap_0_0_i1007);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___instmap__instmap_0_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___instmap__instmap_0_0_i1008);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___instmap__instmap_0_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___instmap__instmap_0_0_i1008);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___instmap__instmap_0_0_i1007);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___instmap__instmap_0_0));
	}
Define_label(mercury____Unify___instmap__instmap_0_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___instmap__instmap_0_0_i1007);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module39)
	init_entry(mercury____Index___instmap__instmap_0_0);
	init_label(mercury____Index___instmap__instmap_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___instmap__instmap_0_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___instmap__instmap_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___instmap__instmap_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__instmap_module40)
	init_entry(mercury____Compare___instmap__instmap_0_0);
	init_label(mercury____Compare___instmap__instmap_0_0_i2);
	init_label(mercury____Compare___instmap__instmap_0_0_i3);
	init_label(mercury____Compare___instmap__instmap_0_0_i4);
	init_label(mercury____Compare___instmap__instmap_0_0_i6);
	init_label(mercury____Compare___instmap__instmap_0_0_i11);
	init_label(mercury____Compare___instmap__instmap_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___instmap__instmap_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___instmap__instmap_0_0),
		mercury____Compare___instmap__instmap_0_0_i2,
		ENTRY(mercury____Compare___instmap__instmap_0_0));
	}
Define_label(mercury____Compare___instmap__instmap_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___instmap__instmap_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___instmap__instmap_0_0),
		mercury____Compare___instmap__instmap_0_0_i3,
		ENTRY(mercury____Compare___instmap__instmap_0_0));
	}
Define_label(mercury____Compare___instmap__instmap_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___instmap__instmap_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___instmap__instmap_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___instmap__instmap_0_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___instmap__instmap_0_0_i11);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i9);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r4 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_prog_data__base_type_info_inst_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___instmap__instmap_0_0));
	}
	}
Define_label(mercury____Compare___instmap__instmap_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___instmap__instmap_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module41)
	init_entry(mercury____Unify___instmap__instmap_delta_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___instmap__instmap_delta_0_0);
	{
		tailcall(STATIC(mercury____Unify___instmap__instmap_0_0),
		ENTRY(mercury____Unify___instmap__instmap_delta_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module42)
	init_entry(mercury____Index___instmap__instmap_delta_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___instmap__instmap_delta_0_0);
	{
		tailcall(STATIC(mercury____Index___instmap__instmap_0_0),
		ENTRY(mercury____Index___instmap__instmap_delta_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__instmap_module43)
	init_entry(mercury____Compare___instmap__instmap_delta_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___instmap__instmap_delta_0_0);
	{
		tailcall(STATIC(mercury____Compare___instmap__instmap_0_0),
		ENTRY(mercury____Compare___instmap__instmap_delta_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__instmap_bunch_0(void)
{
	mercury__instmap_module0();
	mercury__instmap_module1();
	mercury__instmap_module2();
	mercury__instmap_module3();
	mercury__instmap_module4();
	mercury__instmap_module5();
	mercury__instmap_module6();
	mercury__instmap_module7();
	mercury__instmap_module8();
	mercury__instmap_module9();
	mercury__instmap_module10();
	mercury__instmap_module11();
	mercury__instmap_module12();
	mercury__instmap_module13();
	mercury__instmap_module14();
	mercury__instmap_module15();
	mercury__instmap_module16();
	mercury__instmap_module17();
	mercury__instmap_module18();
	mercury__instmap_module19();
	mercury__instmap_module20();
	mercury__instmap_module21();
	mercury__instmap_module22();
	mercury__instmap_module23();
	mercury__instmap_module24();
	mercury__instmap_module25();
	mercury__instmap_module26();
	mercury__instmap_module27();
	mercury__instmap_module28();
	mercury__instmap_module29();
	mercury__instmap_module30();
	mercury__instmap_module31();
	mercury__instmap_module32();
	mercury__instmap_module33();
	mercury__instmap_module34();
	mercury__instmap_module35();
	mercury__instmap_module36();
	mercury__instmap_module37();
	mercury__instmap_module38();
	mercury__instmap_module39();
	mercury__instmap_module40();
}

static void mercury__instmap_bunch_1(void)
{
	mercury__instmap_module41();
	mercury__instmap_module42();
	mercury__instmap_module43();
}

#endif

void mercury__instmap__init(void); /* suppress gcc warning */
void mercury__instmap__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__instmap_bunch_0();
	mercury__instmap_bunch_1();
#endif
}
