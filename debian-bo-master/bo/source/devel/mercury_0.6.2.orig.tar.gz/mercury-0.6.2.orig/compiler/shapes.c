/*
** Automatically generated from `shapes.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__shapes__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__shapes__create_shapeA__ua10000_8_0);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i4);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i5);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i6);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i9);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i12);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i15);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i18);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i21);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i28);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i30);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i31);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i26);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i25);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i35);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i37);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i33);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i32);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i41);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i39);
Declare_label(mercury__shapes__create_shapeA__ua10000_8_0_i1021);
Define_extern_entry(mercury__shapes__init_shape_table_1_0);
Declare_label(mercury__shapes__init_shape_table_1_0_i2);
Declare_label(mercury__shapes__init_shape_table_1_0_i3);
Declare_label(mercury__shapes__init_shape_table_1_0_i4);
Declare_label(mercury__shapes__init_shape_table_1_0_i5);
Declare_label(mercury__shapes__init_shape_table_1_0_i6);
Declare_label(mercury__shapes__init_shape_table_1_0_i7);
Declare_label(mercury__shapes__init_shape_table_1_0_i8);
Declare_label(mercury__shapes__init_shape_table_1_0_i9);
Define_extern_entry(mercury__shapes__request_shape_number_5_0);
Declare_label(mercury__shapes__request_shape_number_5_0_i2);
Declare_label(mercury__shapes__request_shape_number_5_0_i5);
Declare_label(mercury__shapes__request_shape_number_5_0_i7);
Declare_label(mercury__shapes__request_shape_number_5_0_i8);
Declare_label(mercury__shapes__request_shape_number_5_0_i11);
Declare_label(mercury__shapes__request_shape_number_5_0_i14);
Declare_label(mercury__shapes__request_shape_number_5_0_i4);
Declare_label(mercury__shapes__request_shape_number_5_0_i17);
Declare_label(mercury__shapes__request_shape_number_5_0_i18);
Declare_label(mercury__shapes__request_shape_number_5_0_i19);
Define_extern_entry(mercury__shapes__do_abstract_exports_2_0);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i2);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i3);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i4);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i5);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i6);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i7);
Declare_label(mercury__shapes__do_abstract_exports_2_0_i8);
Define_extern_entry(mercury__shapes__write_shape_num_3_0);
Declare_label(mercury__shapes__write_shape_num_3_0_i1026);
Declare_label(mercury__shapes__write_shape_num_3_0_i26);
Declare_label(mercury__shapes__write_shape_num_3_0_i27);
Declare_label(mercury__shapes__write_shape_num_3_0_i25);
Declare_label(mercury__shapes__write_shape_num_3_0_i29);
Declare_label(mercury__shapes__write_shape_num_3_0_i30);
Declare_label(mercury__shapes__write_shape_num_3_0_i1014);
Declare_label(mercury__shapes__write_shape_num_3_0_i1015);
Declare_label(mercury__shapes__write_shape_num_3_0_i1016);
Declare_label(mercury__shapes__write_shape_num_3_0_i1017);
Declare_label(mercury__shapes__write_shape_num_3_0_i1018);
Declare_label(mercury__shapes__write_shape_num_3_0_i1019);
Declare_label(mercury__shapes__write_shape_num_3_0_i1020);
Declare_label(mercury__shapes__write_shape_num_3_0_i1021);
Declare_label(mercury__shapes__write_shape_num_3_0_i1022);
Declare_label(mercury__shapes__write_shape_num_3_0_i1023);
Declare_static(mercury__shapes__create_special_preds_3_0);
Declare_label(mercury__shapes__create_special_preds_3_0_i4);
Declare_label(mercury__shapes__create_special_preds_3_0_i6);
Declare_label(mercury__shapes__create_special_preds_3_0_i5);
Declare_label(mercury__shapes__create_special_preds_3_0_i1008);
Declare_label(mercury__shapes__create_special_preds_3_0_i1009);
Declare_static(mercury__shapes__add_shape_numbers_5_0);
Declare_label(mercury__shapes__add_shape_numbers_5_0_i4);
Declare_label(mercury__shapes__add_shape_numbers_5_0_i5);
Declare_label(mercury__shapes__add_shape_numbers_5_0_i11);
Declare_label(mercury__shapes__add_shape_numbers_5_0_i8);
Declare_label(mercury__shapes__add_shape_numbers_5_0_i1009);
Declare_static(mercury__shapes__replace_context_2_0);
Declare_label(mercury__shapes__replace_context_2_0_i2);
Declare_label(mercury__shapes__replace_context_2_0_i3);
Declare_static(mercury__shapes__replace_all_contexts_2_0);
Declare_label(mercury__shapes__replace_all_contexts_2_0_i7);
Declare_label(mercury__shapes__replace_all_contexts_2_0_i8);
Declare_label(mercury__shapes__replace_all_contexts_2_0_i4);
Declare_label(mercury__shapes__replace_all_contexts_2_0_i9);
Declare_label(mercury__shapes__replace_all_contexts_2_0_i10);
Declare_label(mercury__shapes__replace_all_contexts_2_0_i1004);
Declare_static(mercury__shapes__replace_all_contexts_in_ctor_args_2_0);
Declare_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i7);
Declare_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i8);
Declare_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i4);
Declare_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i9);
Declare_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i10);
Declare_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i1004);
Declare_static(mercury__shapes__tag_match_2_0);
Declare_label(mercury__shapes__tag_match_2_0_i3);
Declare_label(mercury__shapes__tag_match_2_0_i5);
Declare_label(mercury__shapes__tag_match_2_0_i7);
Declare_label(mercury__shapes__tag_match_2_0_i9);
Declare_label(mercury__shapes__tag_match_2_0_i2);
Declare_label(mercury__shapes__tag_match_2_0_i1);
Declare_static(mercury__shapes__create_shape_5_0);
Declare_label(mercury__shapes__create_shape_5_0_i4);
Declare_label(mercury__shapes__create_shape_5_0_i3);
Declare_label(mercury__shapes__create_shape_5_0_i10);
Declare_label(mercury__shapes__create_shape_5_0_i7);
Declare_static(mercury__shapes__create_shape_2_8_0);
Declare_label(mercury__shapes__create_shape_2_8_0_i4);
Declare_label(mercury__shapes__create_shape_2_8_0_i6);
Declare_label(mercury__shapes__create_shape_2_8_0_i7);
Declare_label(mercury__shapes__create_shape_2_8_0_i11);
Declare_label(mercury__shapes__create_shape_2_8_0_i12);
Declare_label(mercury__shapes__create_shape_2_8_0_i13);
Declare_label(mercury__shapes__create_shape_2_8_0_i16);
Declare_label(mercury__shapes__create_shape_2_8_0_i18);
Declare_label(mercury__shapes__create_shape_2_8_0_i26);
Declare_label(mercury__shapes__create_shape_2_8_0_i15);
Declare_label(mercury__shapes__create_shape_2_8_0_i27);
Declare_label(mercury__shapes__create_shape_2_8_0_i28);
Declare_label(mercury__shapes__create_shape_2_8_0_i29);
Declare_label(mercury__shapes__create_shape_2_8_0_i30);
Declare_label(mercury__shapes__create_shape_2_8_0_i8);
Declare_label(mercury__shapes__create_shape_2_8_0_i37);
Declare_label(mercury__shapes__create_shape_2_8_0_i39);
Declare_label(mercury__shapes__create_shape_2_8_0_i41);
Declare_label(mercury__shapes__create_shape_2_8_0_i42);
Declare_label(mercury__shapes__create_shape_2_8_0_i1035);
Declare_label(mercury__shapes__create_shape_2_8_0_i32);
Declare_label(mercury__shapes__create_shape_2_8_0_i47);
Declare_label(mercury__shapes__create_shape_2_8_0_i44);
Declare_label(mercury__shapes__create_shape_2_8_0_i49);
Declare_label(mercury__shapes__create_shape_2_8_0_i3);
Declare_label(mercury__shapes__create_shape_2_8_0_i55);
Declare_label(mercury__shapes__create_shape_2_8_0_i54);
Declare_label(mercury__shapes__create_shape_2_8_0_i57);
Declare_static(mercury__shapes__get_snums_2_0);
Declare_label(mercury__shapes__get_snums_2_0_i3);
Declare_label(mercury__shapes__get_snums_2_0_i4);
Declare_label(mercury__shapes__get_snums_2_0_i1);
Declare_static(mercury__shapes__apply_to_ctors_3_0);
Declare_label(mercury__shapes__apply_to_ctors_3_0_i4);
Declare_label(mercury__shapes__apply_to_ctors_3_0_i5);
Declare_label(mercury__shapes__apply_to_ctors_3_0_i1003);
Declare_static(mercury__shapes__apply_to_ctor_args_3_0);
Declare_label(mercury__shapes__apply_to_ctor_args_3_0_i4);
Declare_label(mercury__shapes__apply_to_ctor_args_3_0_i5);
Declare_label(mercury__shapes__apply_to_ctor_args_3_0_i1003);
Declare_static(mercury__shapes__lookup_simple_info_5_0);
Declare_label(mercury__shapes__lookup_simple_info_5_0_i4);
Declare_label(mercury__shapes__lookup_simple_info_5_0_i5);
Declare_label(mercury__shapes__lookup_simple_info_5_0_i1005);
Declare_static(mercury__shapes__lookup_complicated_info_7_0);
Declare_label(mercury__shapes__lookup_complicated_info_7_0_i4);
Declare_label(mercury__shapes__lookup_complicated_info_7_0_i7);
Declare_label(mercury__shapes__lookup_complicated_info_7_0_i6);
Declare_label(mercury__shapes__lookup_complicated_info_7_0_i1003);
Declare_static(mercury__shapes__get_complicated_shapeids_7_0);
Declare_label(mercury__shapes__get_complicated_shapeids_7_0_i2);
Declare_label(mercury__shapes__get_complicated_shapeids_7_0_i3);
Declare_label(mercury__shapes__get_complicated_shapeids_7_0_i5);
Declare_label(mercury__shapes__get_complicated_shapeids_7_0_i7);
Declare_label(mercury__shapes__get_complicated_shapeids_7_0_i8);
Declare_label(mercury__shapes__get_complicated_shapeids_7_0_i1);
Define_extern_entry(mercury____Unify___shapes__tagged_num_0_0);
Define_extern_entry(mercury____Index___shapes__tagged_num_0_0);
Define_extern_entry(mercury____Compare___shapes__tagged_num_0_0);
Define_extern_entry(mercury____Unify___shapes__tag_type_0_0);
Declare_label(mercury____Unify___shapes__tag_type_0_0_i1);
Define_extern_entry(mercury____Index___shapes__tag_type_0_0);
Define_extern_entry(mercury____Compare___shapes__tag_type_0_0);
Define_extern_entry(mercury____Unify___shapes__shape_list_0_0);
Define_extern_entry(mercury____Index___shapes__shape_list_0_0);
Define_extern_entry(mercury____Compare___shapes__shape_list_0_0);
Define_extern_entry(mercury____Unify___shapes__length_list_0_0);
Define_extern_entry(mercury____Index___shapes__length_list_0_0);
Define_extern_entry(mercury____Compare___shapes__length_list_0_0);
Define_extern_entry(mercury____Unify___shapes__contents_list_0_0);
Define_extern_entry(mercury____Index___shapes__contents_list_0_0);
Define_extern_entry(mercury____Compare___shapes__contents_list_0_0);
Define_extern_entry(mercury____Unify___shapes__shape_num_0_0);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i5);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i7);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i9);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i11);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i13);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i15);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i17);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i19);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i21);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i23);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i4);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i25);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i2);
Declare_label(mercury____Unify___shapes__shape_num_0_0_i1);
Define_extern_entry(mercury____Index___shapes__shape_num_0_0);
Declare_label(mercury____Index___shapes__shape_num_0_0_i5);
Declare_label(mercury____Index___shapes__shape_num_0_0_i6);
Declare_label(mercury____Index___shapes__shape_num_0_0_i7);
Declare_label(mercury____Index___shapes__shape_num_0_0_i8);
Declare_label(mercury____Index___shapes__shape_num_0_0_i9);
Declare_label(mercury____Index___shapes__shape_num_0_0_i10);
Declare_label(mercury____Index___shapes__shape_num_0_0_i11);
Declare_label(mercury____Index___shapes__shape_num_0_0_i12);
Declare_label(mercury____Index___shapes__shape_num_0_0_i13);
Declare_label(mercury____Index___shapes__shape_num_0_0_i14);
Declare_label(mercury____Index___shapes__shape_num_0_0_i4);
Declare_label(mercury____Index___shapes__shape_num_0_0_i15);
Define_extern_entry(mercury____Compare___shapes__shape_num_0_0);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i2);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i3);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i4);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i6);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i13);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i15);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i17);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i19);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i21);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i23);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i25);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i27);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i29);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i31);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i12);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i33);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i9);
Declare_label(mercury____Compare___shapes__shape_num_0_0_i1000);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_shapes__base_type_layout_bit_number_0[];
Word * mercury_data_shapes__base_type_info_bit_number_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_bit_number_0
};

extern Word * mercury_data_shapes__base_type_layout_contents_list_0[];
Word * mercury_data_shapes__base_type_info_contents_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___shapes__contents_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___shapes__contents_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___shapes__contents_list_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_contents_list_0
};

extern Word * mercury_data_shapes__base_type_layout_length_list_0[];
Word * mercury_data_shapes__base_type_info_length_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___shapes__length_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___shapes__length_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___shapes__length_list_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_length_list_0
};

extern Word * mercury_data_shapes__base_type_layout_shape_list_0[];
Word * mercury_data_shapes__base_type_info_shape_list_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___shapes__shape_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___shapes__shape_list_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___shapes__shape_list_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_shape_list_0
};

extern Word * mercury_data_shapes__base_type_layout_shape_num_0[];
Word * mercury_data_shapes__base_type_info_shape_num_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___shapes__shape_num_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___shapes__shape_num_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___shapes__shape_num_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_shape_num_0
};

extern Word * mercury_data_shapes__base_type_layout_tag_type_0[];
Word * mercury_data_shapes__base_type_info_tag_type_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___shapes__tag_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___shapes__tag_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___shapes__tag_type_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_tag_type_0
};

extern Word * mercury_data_shapes__base_type_layout_tagged_num_0[];
Word * mercury_data_shapes__base_type_info_tagged_num_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___shapes__tagged_num_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___shapes__tagged_num_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___shapes__tagged_num_0_0),
	(Word *) (Integer) mercury_data_shapes__base_type_layout_tagged_num_0
};

extern Word * mercury_data_shapes__common_37[];
Word * mercury_data_shapes__base_type_layout_tagged_num_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_37),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_37),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_37),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_37)
};

extern Word * mercury_data_shapes__common_38[];
Word * mercury_data_shapes__base_type_layout_tag_type_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_38),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_38)
};

extern Word * mercury_data_shapes__common_39[];
extern Word * mercury_data_shapes__common_41[];
extern Word * mercury_data_shapes__common_42[];
Word * mercury_data_shapes__base_type_layout_shape_num_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_39),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_shapes__common_41),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_shapes__common_42),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_shapes__common_44[];
Word * mercury_data_shapes__base_type_layout_shape_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_44),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_44),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_44),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_44)
};

extern Word * mercury_data_shapes__common_46[];
Word * mercury_data_shapes__base_type_layout_length_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46)
};

Word * mercury_data_shapes__base_type_layout_contents_list_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_46)
};

extern Word * mercury_data_shapes__common_47[];
Word * mercury_data_shapes__base_type_layout_bit_number_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_47),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_47),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_47),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_47)
};

Word * mercury_data_shapes__common_0[] = {
	(Word *) string_const("X", 1)
};

Word * mercury_data_shapes__common_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_0),
	(Word *) ((Integer) 0)
};

Word mercury_data_shapes__common_2[] = {
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0))),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_shapes__common_3[] = {
	((Integer) 1),
	((Integer) 0),
	(Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_shapes__common_4[] = {
	(Word *) string_const("string", 6)
};

Word * mercury_data_shapes__common_5[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_4),
	(Word *) ((Integer) 0)
};

Word * mercury_data_shapes__common_6[] = {
	(Word *) string_const("float", 5)
};

Word * mercury_data_shapes__common_7[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_6),
	(Word *) ((Integer) 0)
};

Word * mercury_data_shapes__common_8[] = {
	(Word *) string_const("int", 3)
};

Word * mercury_data_shapes__common_9[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_8),
	(Word *) ((Integer) 0)
};

Word * mercury_data_shapes__common_10[] = {
	(Word *) string_const("character", 9)
};

Word * mercury_data_shapes__common_11[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_10),
	(Word *) ((Integer) 0)
};

Word * mercury_data_shapes__common_12[] = {
	(Word *) string_const("io", 2),
	(Word *) string_const("io__stream", 10)
};

Word * mercury_data_shapes__common_13[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_shapes__common_12),
	(Word *) ((Integer) 0)
};

Word * mercury_data_shapes__common_14[] = {
	(Word *) string_const("std_util", 8),
	(Word *) string_const("univ", 4)
};

Word * mercury_data_shapes__common_15[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_shapes__common_14),
	(Word *) ((Integer) 0)
};

Word * mercury_data_shapes__common_16[] = {
	(Word *) string_const("io", 2),
	(Word *) string_const("io__external_state", 18)
};

Word * mercury_data_shapes__common_17[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_shapes__common_16),
	(Word *) ((Integer) 0)
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
extern Word * mercury_data_hlds_module__base_type_info_shape_0[];
Word * mercury_data_shapes__common_18[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_shapes__base_type_info_shape_num_0,
	(Word *) (Integer) mercury_data_hlds_module__base_type_info_shape_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
extern Word * mercury_data_prog_data__base_type_info_inst_0[];
Word * mercury_data_shapes__common_19[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_inst_0
};

Word mercury_data_shapes__common_20[] = {
	((Integer) 0)
};

Word * mercury_data_shapes__common_21[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_20),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

Word mercury_data_shapes__common_22[] = {
	((Integer) 1)
};

Word * mercury_data_shapes__common_23[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

Word mercury_data_shapes__common_24[] = {
	((Integer) 2)
};

Word * mercury_data_shapes__common_25[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_24),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

Word mercury_data_shapes__common_26[] = {
	((Integer) 3)
};

Word * mercury_data_shapes__common_27[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_26),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

Word mercury_data_shapes__common_28[] = {
	((Integer) 4)
};

Word * mercury_data_shapes__common_29[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_28),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

Word mercury_data_shapes__common_30[] = {
	((Integer) 5)
};

Word * mercury_data_shapes__common_31[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_30),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

Word mercury_data_shapes__common_32[] = {
	((Integer) 6)
};

Word * mercury_data_shapes__common_33[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_shapes__common_32),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2)
};

extern Word * mercury_data_prog_data__base_type_info_sym_name_0[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_shapes__common_34[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_prog_data__base_type_info_sym_name_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_shapes__common_35[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_shapes__base_type_info_shape_num_0,
	(Word *) (Integer) mercury_data_shapes__base_type_info_tag_type_0
};

Word * mercury_data_shapes__common_36[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data_shapes__base_type_info_shape_num_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_35)
};

Word * mercury_data_shapes__common_37[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_35)
};

Word * mercury_data_shapes__common_38[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("const", 5),
	(Word *) string_const("simple", 6),
	(Word *) string_const("complicated", 11)
};

Word * mercury_data_shapes__common_39[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 10),
	(Word *) string_const("succip", 6),
	(Word *) string_const("hp", 2),
	(Word *) string_const("maxfr", 5),
	(Word *) string_const("curfr", 5),
	(Word *) string_const("redoip", 6),
	(Word *) string_const("succfr", 6),
	(Word *) string_const("prevfr", 6),
	(Word *) string_const("sp", 2),
	(Word *) string_const("ticket", 6),
	(Word *) string_const("unwanted", 8)
};

Word * mercury_data_shapes__common_40[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_shapes__common_41[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_40),
	(Word *) string_const("num", 3)
};

Word * mercury_data_shapes__common_42[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_40),
	(Word *) string_const("builtin", 7)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_shapes__common_43[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_36)
};

Word * mercury_data_shapes__common_44[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_43)
};

Word * mercury_data_shapes__common_45[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_shapes__common_46[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_45)
};

Word * mercury_data_shapes__common_47[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 4),
	(Word *) string_const("bit_zero", 8),
	(Word *) string_const("bit_one", 7),
	(Word *) string_const("bit_two", 7),
	(Word *) string_const("bit_three", 9)
};

BEGIN_MODULE(mercury__shapes_module0)
	init_entry(mercury__shapes__create_shapeA__ua10000_8_0);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i4);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i5);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i6);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i9);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i12);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i15);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i18);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i21);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i28);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i30);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i31);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i26);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i25);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i35);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i37);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i33);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i32);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i41);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i39);
	init_label(mercury__shapes__create_shapeA__ua10000_8_0_i1021);
BEGIN_CODE

/* code for predicate 'shapes__create_shapeA__ua10000'/8 in mode 0 */
Define_static(mercury__shapes__create_shapeA__ua10000_8_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i1021);
	incr_sp_push_msg(9, "shapes__create_shapeA__ua10000");
	detstackvar(9) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(7) = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r3;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_1);
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_data__make_cons_id_4_0);
	call_localret(ENTRY(mercury__hlds_data__make_cons_id_4_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i4,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
	}
	}
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	r4 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	}
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__shapes__create_shapeA__ua10000_8_0_i5,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
	}
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i6);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i6);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i9);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i9);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i12);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i12);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i12);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i15);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 2)))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i15);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i15);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i18);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i18);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i18);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i21);
	r1 = string_const("shapes__create_shapesA: unexpected `no_tag'", 43);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
	}
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i21);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i25);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 4)))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i25);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__tag_match_2_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i28,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i28);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i26);
	r1 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__shapes__replace_all_contexts_in_ctor_args_2_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i30,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i30);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__shapes__lookup_simple_info_5_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i31,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i31);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i26);
	r1 = (Integer) detstackvar(8);
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i25);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i32);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 5)))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i32);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__tag_match_2_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i35,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i35);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i33);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__shapes__lookup_complicated_info_7_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i37,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i37);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i33);
	r1 = (Integer) detstackvar(8);
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i32);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i39);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 6)))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i39);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__tag_match_2_0),
		mercury__shapes__create_shapeA__ua10000_8_0_i41,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i41);
	update_prof_current_proc(LABEL(mercury__shapes__create_shapeA__ua10000_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shapeA__ua10000_8_0_i39);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i39);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__shapes__create_shapeA__ua10000_8_0,
		STATIC(mercury__shapes__create_shapeA__ua10000_8_0));
Define_label(mercury__shapes__create_shapeA__ua10000_8_0_i1021);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module1)
	init_entry(mercury__shapes__init_shape_table_1_0);
	init_label(mercury__shapes__init_shape_table_1_0_i2);
	init_label(mercury__shapes__init_shape_table_1_0_i3);
	init_label(mercury__shapes__init_shape_table_1_0_i4);
	init_label(mercury__shapes__init_shape_table_1_0_i5);
	init_label(mercury__shapes__init_shape_table_1_0_i6);
	init_label(mercury__shapes__init_shape_table_1_0_i7);
	init_label(mercury__shapes__init_shape_table_1_0_i8);
	init_label(mercury__shapes__init_shape_table_1_0_i9);
BEGIN_CODE

/* code for predicate 'shapes__init_shape_table'/1 in mode 0 */
Define_entry(mercury__shapes__init_shape_table_1_0);
	incr_sp_push_msg(9, "shapes__init_shape_table");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2);
	detstackvar(2) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_5);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i2,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i2);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_7);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i3,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i3);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_9);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i4,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_11);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i5,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_13);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i6,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i6);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_15);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i7,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_17);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__type_util__construct_type_3_0);
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__shapes__init_shape_table_1_0_i8,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
Define_label(mercury__shapes__init_shape_table_1_0_i8);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_18);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	r4 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_19);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_21);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r5;
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r6, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r6, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_23);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(0), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r7, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_25);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r7;
	field(mktag(0), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r8, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_27);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r8;
	field(mktag(0), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r9, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r9, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_29);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r9;
	field(mktag(0), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(r10, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_31);
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) r10;
	field(mktag(0), (Integer) r10, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(r11, mktag(0), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r11, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) r11;
	field(mktag(0), (Integer) r11, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_33);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__shapes__init_shape_table_1_0_i9,
		ENTRY(mercury__shapes__init_shape_table_1_0));
	}
	}
Define_label(mercury__shapes__init_shape_table_1_0_i9);
	update_prof_current_proc(LABEL(mercury__shapes__init_shape_table_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = ((Integer) 7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module2)
	init_entry(mercury__shapes__request_shape_number_5_0);
	init_label(mercury__shapes__request_shape_number_5_0_i2);
	init_label(mercury__shapes__request_shape_number_5_0_i5);
	init_label(mercury__shapes__request_shape_number_5_0_i7);
	init_label(mercury__shapes__request_shape_number_5_0_i8);
	init_label(mercury__shapes__request_shape_number_5_0_i11);
	init_label(mercury__shapes__request_shape_number_5_0_i14);
	init_label(mercury__shapes__request_shape_number_5_0_i4);
	init_label(mercury__shapes__request_shape_number_5_0_i17);
	init_label(mercury__shapes__request_shape_number_5_0_i18);
	init_label(mercury__shapes__request_shape_number_5_0_i19);
BEGIN_CODE

/* code for predicate 'shapes__request_shape_number'/5 in mode 0 */
Define_entry(mercury__shapes__request_shape_number_5_0);
	incr_sp_push_msg(6, "shapes__request_shape_number");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	call_localret(STATIC(mercury__shapes__replace_context_2_0),
		mercury__shapes__request_shape_number_5_0_i2,
		ENTRY(mercury__shapes__request_shape_number_5_0));
Define_label(mercury__shapes__request_shape_number_5_0_i2);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	r4 = (Integer) r1;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_19);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_18);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__shapes__request_shape_number_5_0_i5,
		ENTRY(mercury__shapes__request_shape_number_5_0));
	}
Define_label(mercury__shapes__request_shape_number_5_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__request_shape_number_5_0_i4);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_19);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_18);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__shapes__request_shape_number_5_0_i7,
		ENTRY(mercury__shapes__request_shape_number_5_0));
	}
Define_label(mercury__shapes__request_shape_number_5_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__shapes__request_shape_number_5_0_i8);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__shapes__request_shape_number_5_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__shapes__request_shape_number_5_0_i11);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__shapes__request_shape_number_5_0_i11);
	r1 = string_const("shapes: Unexpected shape_num type found", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__shapes__request_shape_number_5_0_i14,
		ENTRY(mercury__shapes__request_shape_number_5_0));
	}
Define_label(mercury__shapes__request_shape_number_5_0_i14);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__shapes__request_shape_number_5_0_i4);
	r3 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	detstackvar(2) = (Integer) r2;
	r4 = (Integer) detstackvar(4);
	detstackvar(3) = ((Integer) r2 + ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_19);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_18);
	detstackvar(5) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__shapes__request_shape_number_5_0_i17,
		ENTRY(mercury__shapes__request_shape_number_5_0));
	}
	}
Define_label(mercury__shapes__request_shape_number_5_0_i17);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__create_shape_5_0),
		mercury__shapes__request_shape_number_5_0_i18,
		ENTRY(mercury__shapes__request_shape_number_5_0));
Define_label(mercury__shapes__request_shape_number_5_0_i18);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	r7 = (Integer) r1;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_19);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_18);
	r4 = (Integer) detstackvar(4);
	tag_incr_hp(r5, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r7;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__shapes__request_shape_number_5_0_i19,
		ENTRY(mercury__shapes__request_shape_number_5_0));
	}
Define_label(mercury__shapes__request_shape_number_5_0_i19);
	update_prof_current_proc(LABEL(mercury__shapes__request_shape_number_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module3)
	init_entry(mercury__shapes__do_abstract_exports_2_0);
	init_label(mercury__shapes__do_abstract_exports_2_0_i2);
	init_label(mercury__shapes__do_abstract_exports_2_0_i3);
	init_label(mercury__shapes__do_abstract_exports_2_0_i4);
	init_label(mercury__shapes__do_abstract_exports_2_0_i5);
	init_label(mercury__shapes__do_abstract_exports_2_0_i6);
	init_label(mercury__shapes__do_abstract_exports_2_0_i7);
	init_label(mercury__shapes__do_abstract_exports_2_0_i8);
BEGIN_CODE

/* code for predicate 'shapes__do_abstract_exports'/2 in mode 0 */
Define_entry(mercury__shapes__do_abstract_exports_2_0);
	incr_sp_push_msg(5, "shapes__do_abstract_exports");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_module__module_info_types_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__shapes__do_abstract_exports_2_0_i2,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
	}
Define_label(mercury__shapes__do_abstract_exports_2_0_i2);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_shape_info_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_shape_info_2_0),
		mercury__shapes__do_abstract_exports_2_0_i3,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
	}
Define_label(mercury__shapes__do_abstract_exports_2_0_i3);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_34);
	{
	extern Word * mercury_data_hlds_module__base_type_info_maybe_shape_num_0[];
	r2 = (Integer) mercury_data_hlds_module__base_type_info_maybe_shape_num_0;
	}
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__shapes__do_abstract_exports_2_0_i4,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
	}
Define_label(mercury__shapes__do_abstract_exports_2_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__add_shape_numbers_5_0),
		mercury__shapes__do_abstract_exports_2_0_i5,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
Define_label(mercury__shapes__do_abstract_exports_2_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_34);
	{
	extern Word * mercury_data_hlds_module__base_type_info_maybe_shape_num_0[];
	r2 = (Integer) mercury_data_hlds_module__base_type_info_maybe_shape_num_0;
	}
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__shapes__do_abstract_exports_2_0_i6,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
	}
Define_label(mercury__shapes__do_abstract_exports_2_0_i6);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__hlds_module__module_info_name_2_0);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__shapes__do_abstract_exports_2_0_i7,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
	}
Define_label(mercury__shapes__do_abstract_exports_2_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__create_special_preds_3_0),
		mercury__shapes__do_abstract_exports_2_0_i8,
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
Define_label(mercury__shapes__do_abstract_exports_2_0_i8);
	update_prof_current_proc(LABEL(mercury__shapes__do_abstract_exports_2_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__hlds_module__module_info_set_shape_info_3_0);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_shape_info_3_0),
		ENTRY(mercury__shapes__do_abstract_exports_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module4)
	init_entry(mercury__shapes__write_shape_num_3_0);
	init_label(mercury__shapes__write_shape_num_3_0_i1026);
	init_label(mercury__shapes__write_shape_num_3_0_i26);
	init_label(mercury__shapes__write_shape_num_3_0_i27);
	init_label(mercury__shapes__write_shape_num_3_0_i25);
	init_label(mercury__shapes__write_shape_num_3_0_i29);
	init_label(mercury__shapes__write_shape_num_3_0_i30);
	init_label(mercury__shapes__write_shape_num_3_0_i1014);
	init_label(mercury__shapes__write_shape_num_3_0_i1015);
	init_label(mercury__shapes__write_shape_num_3_0_i1016);
	init_label(mercury__shapes__write_shape_num_3_0_i1017);
	init_label(mercury__shapes__write_shape_num_3_0_i1018);
	init_label(mercury__shapes__write_shape_num_3_0_i1019);
	init_label(mercury__shapes__write_shape_num_3_0_i1020);
	init_label(mercury__shapes__write_shape_num_3_0_i1021);
	init_label(mercury__shapes__write_shape_num_3_0_i1022);
	init_label(mercury__shapes__write_shape_num_3_0_i1023);
BEGIN_CODE

/* code for predicate 'shapes__write_shape_num'/3 in mode 0 */
Define_entry(mercury__shapes__write_shape_num_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__shapes__write_shape_num_3_0_i1026);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury__shapes__write_shape_num_3_0_i1014) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1015) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1016) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1017) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1018) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1019) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1020) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1021) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1022) AND
		LABEL(mercury__shapes__write_shape_num_3_0_i1023));
Define_label(mercury__shapes__write_shape_num_3_0_i1026);
	incr_sp_push_msg(2, "shapes__write_shape_num");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__shapes__write_shape_num_3_0_i25);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = string_const("num(", 4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__shapes__write_shape_num_3_0_i26,
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i26);
	update_prof_current_proc(LABEL(mercury__shapes__write_shape_num_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__shapes__write_shape_num_3_0_i27,
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i27);
	update_prof_current_proc(LABEL(mercury__shapes__write_shape_num_3_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i25);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = string_const("builtin(", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__shapes__write_shape_num_3_0_i29,
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i29);
	update_prof_current_proc(LABEL(mercury__shapes__write_shape_num_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_int_3_0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__shapes__write_shape_num_3_0_i30,
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i30);
	update_prof_current_proc(LABEL(mercury__shapes__write_shape_num_3_0));
	r2 = (Integer) r1;
	r1 = string_const(")", 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1014);
	r1 = string_const("succip", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1015);
	r1 = string_const("hp", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1016);
	r1 = string_const("maxfr", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1017);
	r1 = string_const("curfr", 5);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1018);
	r1 = string_const("redoip", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1019);
	r1 = string_const("succfr", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1020);
	r1 = string_const("prevfr", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1021);
	r1 = string_const("sp", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1022);
	r1 = string_const("ticket", 6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
Define_label(mercury__shapes__write_shape_num_3_0_i1023);
	r1 = string_const("unwanted", 8);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__shapes__write_shape_num_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module5)
	init_entry(mercury__shapes__create_special_preds_3_0);
	init_label(mercury__shapes__create_special_preds_3_0_i4);
	init_label(mercury__shapes__create_special_preds_3_0_i6);
	init_label(mercury__shapes__create_special_preds_3_0_i5);
	init_label(mercury__shapes__create_special_preds_3_0_i1008);
	init_label(mercury__shapes__create_special_preds_3_0_i1009);
BEGIN_CODE

/* code for predicate 'shapes__create_special_preds'/3 in mode 0 */
Define_static(mercury__shapes__create_special_preds_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_special_preds_3_0_i1009);
	incr_sp_push_msg(3, "shapes__create_special_preds");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__shapes__create_special_preds_3_0,
		LABEL(mercury__shapes__create_special_preds_3_0_i4),
		STATIC(mercury__shapes__create_special_preds_3_0));
Define_label(mercury__shapes__create_special_preds_3_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__create_special_preds_3_0));
	if ((tag((Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0)), ((Integer) 0))) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__shapes__create_special_preds_3_0_i6);
	r3 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	tag_incr_hp(r4, mktag(2), ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 5));
	{
	Word tempr1, tempr2;
	tempr2 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0));
	tempr1 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 4)) = ((Integer) 1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = string_const("__Unify__", 9);
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	GOTO_LABEL(mercury__shapes__create_special_preds_3_0_i5);
	}
Define_label(mercury__shapes__create_special_preds_3_0_i6);
	r3 = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 1));
	tag_incr_hp(r4, mktag(2), ((Integer) 1));
	tag_incr_hp(r2, mktag(1), ((Integer) 5));
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(0), (Integer) detstackvar(2), ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 4)) = ((Integer) 1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = string_const("__Unify__", 9);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	}
Define_label(mercury__shapes__create_special_preds_3_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__shapes__create_special_preds_3_0_i1008);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mercury_data_shapes__base_type_info_shape_num_0;
	{
	Declare_entry(mercury__map__set_4_1);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__shapes__create_special_preds_3_0));
	}
Define_label(mercury__shapes__create_special_preds_3_0_i1008);
	r1 = string_const("shapes: unable to find shape number for special pred", 52);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__shapes__create_special_preds_3_0));
	}
Define_label(mercury__shapes__create_special_preds_3_0_i1009);
	{
	extern Word * mercury_data_llds__base_type_info_label_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_label_0;
	}
	r2 = (Integer) mercury_data_shapes__base_type_info_shape_num_0;
	{
	Declare_entry(mercury__map__init_1_0);
	tailcall(ENTRY(mercury__map__init_1_0),
		STATIC(mercury__shapes__create_special_preds_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module6)
	init_entry(mercury__shapes__add_shape_numbers_5_0);
	init_label(mercury__shapes__add_shape_numbers_5_0_i4);
	init_label(mercury__shapes__add_shape_numbers_5_0_i5);
	init_label(mercury__shapes__add_shape_numbers_5_0_i11);
	init_label(mercury__shapes__add_shape_numbers_5_0_i8);
	init_label(mercury__shapes__add_shape_numbers_5_0_i1009);
BEGIN_CODE

/* code for predicate 'shapes__add_shape_numbers'/5 in mode 0 */
Define_static(mercury__shapes__add_shape_numbers_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__add_shape_numbers_5_0_i1009);
	incr_sp_push_msg(5, "shapes__add_shape_numbers");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) tempr1;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	localcall(mercury__shapes__add_shape_numbers_5_0,
		LABEL(mercury__shapes__add_shape_numbers_5_0_i4),
		STATIC(mercury__shapes__add_shape_numbers_5_0));
	}
Define_label(mercury__shapes__add_shape_numbers_5_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__add_shape_numbers_5_0));
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__shapes__add_shape_numbers_5_0_i5);
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__shapes__add_shape_numbers_5_0_i5);
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__shapes__add_shape_numbers_5_0_i8);
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r2;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) detstackvar(3), ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	{
		call_localret(STATIC(mercury__shapes__request_shape_number_5_0),
		mercury__shapes__add_shape_numbers_5_0_i11,
		STATIC(mercury__shapes__add_shape_numbers_5_0));
	}
Define_label(mercury__shapes__add_shape_numbers_5_0_i11);
	update_prof_current_proc(LABEL(mercury__shapes__add_shape_numbers_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r4, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(0), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__shapes__add_shape_numbers_5_0_i8);
	r1 = string_const("shapes__add_shape_numbers: Unreachable case reached!", 52);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__shapes__add_shape_numbers_5_0));
	}
Define_label(mercury__shapes__add_shape_numbers_5_0_i1009);
	r1 = (Integer) r3;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module7)
	init_entry(mercury__shapes__replace_context_2_0);
	init_label(mercury__shapes__replace_context_2_0_i2);
	init_label(mercury__shapes__replace_context_2_0_i3);
BEGIN_CODE

/* code for predicate 'shapes__replace_context'/2 in mode 0 */
Define_static(mercury__shapes__replace_context_2_0);
	incr_sp_push_msg(2, "shapes__replace_context");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__shapes__replace_all_contexts_2_0),
		mercury__shapes__replace_context_2_0_i2,
		STATIC(mercury__shapes__replace_context_2_0));
Define_label(mercury__shapes__replace_context_2_0_i2);
	update_prof_current_proc(LABEL(mercury__shapes__replace_context_2_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__replace_context_2_0_i3);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__replace_context_2_0_i3);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__shapes__replace_context_2_0_i3);
	r1 = string_const("shapes__replace_context - empty list returned", 45);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__shapes__replace_context_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module8)
	init_entry(mercury__shapes__replace_all_contexts_2_0);
	init_label(mercury__shapes__replace_all_contexts_2_0_i7);
	init_label(mercury__shapes__replace_all_contexts_2_0_i8);
	init_label(mercury__shapes__replace_all_contexts_2_0_i4);
	init_label(mercury__shapes__replace_all_contexts_2_0_i9);
	init_label(mercury__shapes__replace_all_contexts_2_0_i10);
	init_label(mercury__shapes__replace_all_contexts_2_0_i1004);
BEGIN_CODE

/* code for predicate 'shapes__replace_all_contexts'/2 in mode 0 */
Define_static(mercury__shapes__replace_all_contexts_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__replace_all_contexts_2_0_i1004);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(4, "shapes__replace_all_contexts");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__shapes__replace_all_contexts_2_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	localcall(mercury__shapes__replace_all_contexts_2_0,
		LABEL(mercury__shapes__replace_all_contexts_2_0_i7),
		STATIC(mercury__shapes__replace_all_contexts_2_0));
Define_label(mercury__shapes__replace_all_contexts_2_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__replace_all_contexts_2_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__shapes__replace_all_contexts_2_0_i8,
		STATIC(mercury__shapes__replace_all_contexts_2_0));
	}
Define_label(mercury__shapes__replace_all_contexts_2_0_i8);
	update_prof_current_proc(LABEL(mercury__shapes__replace_all_contexts_2_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__shapes__replace_all_contexts_2_0_i9);
Define_label(mercury__shapes__replace_all_contexts_2_0_i4);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
Define_label(mercury__shapes__replace_all_contexts_2_0_i9);
	detstackvar(1) = (Integer) r2;
	localcall(mercury__shapes__replace_all_contexts_2_0,
		LABEL(mercury__shapes__replace_all_contexts_2_0_i10),
		STATIC(mercury__shapes__replace_all_contexts_2_0));
Define_label(mercury__shapes__replace_all_contexts_2_0_i10);
	update_prof_current_proc(LABEL(mercury__shapes__replace_all_contexts_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__shapes__replace_all_contexts_2_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module9)
	init_entry(mercury__shapes__replace_all_contexts_in_ctor_args_2_0);
	init_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i7);
	init_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i8);
	init_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i4);
	init_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i9);
	init_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i10);
	init_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i1004);
BEGIN_CODE

/* code for predicate 'shapes__replace_all_contexts_in_ctor_args'/2 in mode 0 */
Define_static(mercury__shapes__replace_all_contexts_in_ctor_args_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i1004);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	incr_sp_push_msg(4, "shapes__replace_all_contexts_in_ctor_args");
	detstackvar(4) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	call_localret(STATIC(mercury__shapes__replace_all_contexts_2_0),
		mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i7,
		STATIC(mercury__shapes__replace_all_contexts_in_ctor_args_2_0));
Define_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__term__context_init_1_0);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i8,
		STATIC(mercury__shapes__replace_all_contexts_in_ctor_args_2_0));
	}
Define_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i8);
	update_prof_current_proc(LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i9);
Define_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i4);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
Define_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i9);
	detstackvar(1) = (Integer) r2;
	localcall(mercury__shapes__replace_all_contexts_in_ctor_args_2_0,
		LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i10),
		STATIC(mercury__shapes__replace_all_contexts_in_ctor_args_2_0));
Define_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i10);
	update_prof_current_proc(LABEL(mercury__shapes__replace_all_contexts_in_ctor_args_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__shapes__replace_all_contexts_in_ctor_args_2_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module10)
	init_entry(mercury__shapes__tag_match_2_0);
	init_label(mercury__shapes__tag_match_2_0_i3);
	init_label(mercury__shapes__tag_match_2_0_i5);
	init_label(mercury__shapes__tag_match_2_0_i7);
	init_label(mercury__shapes__tag_match_2_0_i9);
	init_label(mercury__shapes__tag_match_2_0_i2);
	init_label(mercury__shapes__tag_match_2_0_i1);
BEGIN_CODE

/* code for predicate 'shapes__tag_match'/2 in mode 0 */
Define_static(mercury__shapes__tag_match_2_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__shapes__tag_match_2_0_i3) AND
		LABEL(mercury__shapes__tag_match_2_0_i5) AND
		LABEL(mercury__shapes__tag_match_2_0_i7) AND
		LABEL(mercury__shapes__tag_match_2_0_i9));
Define_label(mercury__shapes__tag_match_2_0_i3);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__shapes__tag_match_2_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__shapes__tag_match_2_0_i5);
	if (((Integer) r2 == ((Integer) 1)))
		GOTO_LABEL(mercury__shapes__tag_match_2_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__shapes__tag_match_2_0_i7);
	if (((Integer) r2 == ((Integer) 2)))
		GOTO_LABEL(mercury__shapes__tag_match_2_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__shapes__tag_match_2_0_i9);
	if (((Integer) r2 != ((Integer) 3)))
		GOTO_LABEL(mercury__shapes__tag_match_2_0_i1);
Define_label(mercury__shapes__tag_match_2_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__shapes__tag_match_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module11)
	init_entry(mercury__shapes__create_shape_5_0);
	init_label(mercury__shapes__create_shape_5_0_i4);
	init_label(mercury__shapes__create_shape_5_0_i3);
	init_label(mercury__shapes__create_shape_5_0_i10);
	init_label(mercury__shapes__create_shape_5_0_i7);
BEGIN_CODE

/* code for predicate 'shapes__create_shape'/5 in mode 0 */
Define_static(mercury__shapes__create_shape_5_0);
	incr_sp_push_msg(5, "shapes__create_shape");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__shapes__create_shape_5_0_i4,
		STATIC(mercury__shapes__create_shape_5_0));
	}
Define_label(mercury__shapes__create_shape_5_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shape_5_0_i3);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r5 = (Integer) r3;
	r3 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__shapes__create_shape_2_8_0),
		STATIC(mercury__shapes__create_shape_5_0));
Define_label(mercury__shapes__create_shape_5_0_i3);
	r2 = (Integer) detstackvar(3);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__shapes__create_shape_5_0_i7);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__term__var_to_int_2_0);
	call_localret(ENTRY(mercury__term__var_to_int_2_0),
		mercury__shapes__create_shape_5_0_i10,
		STATIC(mercury__shapes__create_shape_5_0));
	}
Define_label(mercury__shapes__create_shape_5_0_i10);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__shapes__create_shape_5_0_i7);
	r1 = string_const("shapes: unexpected term", 23);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__shapes__create_shape_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module12)
	init_entry(mercury__shapes__create_shape_2_8_0);
	init_label(mercury__shapes__create_shape_2_8_0_i4);
	init_label(mercury__shapes__create_shape_2_8_0_i6);
	init_label(mercury__shapes__create_shape_2_8_0_i7);
	init_label(mercury__shapes__create_shape_2_8_0_i11);
	init_label(mercury__shapes__create_shape_2_8_0_i12);
	init_label(mercury__shapes__create_shape_2_8_0_i13);
	init_label(mercury__shapes__create_shape_2_8_0_i16);
	init_label(mercury__shapes__create_shape_2_8_0_i18);
	init_label(mercury__shapes__create_shape_2_8_0_i26);
	init_label(mercury__shapes__create_shape_2_8_0_i15);
	init_label(mercury__shapes__create_shape_2_8_0_i27);
	init_label(mercury__shapes__create_shape_2_8_0_i28);
	init_label(mercury__shapes__create_shape_2_8_0_i29);
	init_label(mercury__shapes__create_shape_2_8_0_i30);
	init_label(mercury__shapes__create_shape_2_8_0_i8);
	init_label(mercury__shapes__create_shape_2_8_0_i37);
	init_label(mercury__shapes__create_shape_2_8_0_i39);
	init_label(mercury__shapes__create_shape_2_8_0_i41);
	init_label(mercury__shapes__create_shape_2_8_0_i42);
	init_label(mercury__shapes__create_shape_2_8_0_i1035);
	init_label(mercury__shapes__create_shape_2_8_0_i32);
	init_label(mercury__shapes__create_shape_2_8_0_i47);
	init_label(mercury__shapes__create_shape_2_8_0_i44);
	init_label(mercury__shapes__create_shape_2_8_0_i49);
	init_label(mercury__shapes__create_shape_2_8_0_i3);
	init_label(mercury__shapes__create_shape_2_8_0_i55);
	init_label(mercury__shapes__create_shape_2_8_0_i54);
	init_label(mercury__shapes__create_shape_2_8_0_i57);
BEGIN_CODE

/* code for predicate 'shapes__create_shape_2'/8 in mode 0 */
Define_static(mercury__shapes__create_shape_2_8_0);
	incr_sp_push_msg(8, "shapes__create_shape_2");
	detstackvar(8) = (Integer) succip;
	detstackvar(3) = (Integer) r3;
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_34);
	{
	extern Word * mercury_data_hlds_data__base_type_info_hlds__type_defn_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_hlds__type_defn_0;
	}
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__shapes__create_shape_2_8_0_i4,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i3);
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_tparams_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tparams_2_0),
		mercury__shapes__create_shape_2_8_0_i6,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__shapes__create_shape_2_8_0_i7,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i8);
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__term__term_list_to_var_list_2_0);
	call_localret(ENTRY(mercury__term__term_list_to_var_list_2_0),
		mercury__shapes__create_shape_2_8_0_i11,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i11);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__shapes__create_shape_2_8_0_i12,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i12);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__shapes__apply_to_ctors_3_0),
		mercury__shapes__create_shape_2_8_0_i13,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i13);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__type_util__type_is_no_tag_type_3_0);
	call_localret(ENTRY(mercury__type_util__type_is_no_tag_type_3_0),
		mercury__shapes__create_shape_2_8_0_i16,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i16);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i15);
	if ((tag((Integer) detstackvar(3)) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i18);
	if (((Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i18);
	r1 = (Integer) field(mktag(3), (Integer) detstackvar(3), ((Integer) 2));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i18);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i18);
	if (((Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i18);
	if (((Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i18);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__shapes__request_shape_number_5_0),
		mercury__shapes__create_shape_2_8_0_i26,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
	}
Define_label(mercury__shapes__create_shape_2_8_0_i18);
	r4 = (Integer) r3;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__shapes__request_shape_number_5_0),
		mercury__shapes__create_shape_2_8_0_i26,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i26);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 1));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__shapes__create_shape_2_8_0_i15);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	r3 = ((Integer) 0);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__shapes__create_shapeA__ua10000_8_0),
		mercury__shapes__create_shape_2_8_0_i27,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i27);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r5 = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	r3 = ((Integer) 1);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__shapes__create_shapeA__ua10000_8_0),
		mercury__shapes__create_shape_2_8_0_i28,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i28);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r5 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	r3 = ((Integer) 2);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__shapes__create_shapeA__ua10000_8_0),
		mercury__shapes__create_shape_2_8_0_i29,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i29);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(7);
	r3 = ((Integer) 3);
	call_localret(STATIC(mercury__shapes__create_shapeA__ua10000_8_0),
		mercury__shapes__create_shape_2_8_0_i30,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i30);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(6);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__shapes__create_shape_2_8_0_i8);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i32);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__type_util__type_to_type_id_3_0);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__shapes__create_shape_2_8_0_i37,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i37);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i1035);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury__shapes__create_shape_2_8_0_i39,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i39);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i1035);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__shapes__lookup_simple_info_5_0),
		mercury__shapes__create_shape_2_8_0_i41,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i41);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__shapes__get_snums_2_0),
		mercury__shapes__create_shape_2_8_0_i42,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i42);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__shapes__create_shape_2_8_0_i1035);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__shapes__create_shape_2_8_0_i32);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i44);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	call_localret(STATIC(mercury__shapes__replace_context_2_0),
		mercury__shapes__create_shape_2_8_0_i47,
		STATIC(mercury__shapes__create_shape_2_8_0));
Define_label(mercury__shapes__create_shape_2_8_0_i47);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__shapes__request_shape_number_5_0),
		mercury__shapes__create_shape_2_8_0_i26,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i44);
	r1 = string_const("shapes__create_shape_2: unknown type", 36);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__shapes__create_shape_2_8_0_i49,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i49);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__shapes__create_shape_2_8_0_i3);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__type_util__type_is_higher_order_3_0);
	call_localret(ENTRY(mercury__type_util__type_is_higher_order_3_0),
		mercury__shapes__create_shape_2_8_0_i55,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i55);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__create_shape_2_8_0_i54);
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	r2 = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__shapes__create_shape_2_8_0_i54);
	r1 = string_const("shapes__create_shape_2: not in type table", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__shapes__create_shape_2_8_0_i57,
		STATIC(mercury__shapes__create_shape_2_8_0));
	}
Define_label(mercury__shapes__create_shape_2_8_0_i57);
	update_prof_current_proc(LABEL(mercury__shapes__create_shape_2_8_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module13)
	init_entry(mercury__shapes__get_snums_2_0);
	init_label(mercury__shapes__get_snums_2_0_i3);
	init_label(mercury__shapes__get_snums_2_0_i4);
	init_label(mercury__shapes__get_snums_2_0_i1);
BEGIN_CODE

/* code for predicate 'shapes__get_snums'/2 in mode 0 */
Define_static(mercury__shapes__get_snums_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__get_snums_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__shapes__get_snums_2_0_i3);
	while (1) {
	incr_sp_push_msg(1, "shapes__get_snums");
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__shapes__get_snums_2_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__shapes__get_snums_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module14)
	init_entry(mercury__shapes__apply_to_ctors_3_0);
	init_label(mercury__shapes__apply_to_ctors_3_0_i4);
	init_label(mercury__shapes__apply_to_ctors_3_0_i5);
	init_label(mercury__shapes__apply_to_ctors_3_0_i1003);
BEGIN_CODE

/* code for predicate 'shapes__apply_to_ctors'/3 in mode 0 */
Define_static(mercury__shapes__apply_to_ctors_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__apply_to_ctors_3_0_i1003);
	incr_sp_push_msg(4, "shapes__apply_to_ctors");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__shapes__apply_to_ctor_args_3_0),
		mercury__shapes__apply_to_ctors_3_0_i4,
		STATIC(mercury__shapes__apply_to_ctors_3_0));
Define_label(mercury__shapes__apply_to_ctors_3_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__apply_to_ctors_3_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__shapes__apply_to_ctors_3_0,
		LABEL(mercury__shapes__apply_to_ctors_3_0_i5),
		STATIC(mercury__shapes__apply_to_ctors_3_0));
Define_label(mercury__shapes__apply_to_ctors_3_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__apply_to_ctors_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__shapes__apply_to_ctors_3_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module15)
	init_entry(mercury__shapes__apply_to_ctor_args_3_0);
	init_label(mercury__shapes__apply_to_ctor_args_3_0_i4);
	init_label(mercury__shapes__apply_to_ctor_args_3_0_i5);
	init_label(mercury__shapes__apply_to_ctor_args_3_0_i1003);
BEGIN_CODE

/* code for predicate 'shapes__apply_to_ctor_args'/3 in mode 0 */
Define_static(mercury__shapes__apply_to_ctor_args_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__apply_to_ctor_args_3_0_i1003);
	incr_sp_push_msg(4, "shapes__apply_to_ctor_args");
	detstackvar(4) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__term__apply_substitution_3_0);
	call_localret(ENTRY(mercury__term__apply_substitution_3_0),
		mercury__shapes__apply_to_ctor_args_3_0_i4,
		STATIC(mercury__shapes__apply_to_ctor_args_3_0));
	}
Define_label(mercury__shapes__apply_to_ctor_args_3_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__apply_to_ctor_args_3_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	localcall(mercury__shapes__apply_to_ctor_args_3_0,
		LABEL(mercury__shapes__apply_to_ctor_args_3_0_i5),
		STATIC(mercury__shapes__apply_to_ctor_args_3_0));
Define_label(mercury__shapes__apply_to_ctor_args_3_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__apply_to_ctor_args_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__shapes__apply_to_ctor_args_3_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module16)
	init_entry(mercury__shapes__lookup_simple_info_5_0);
	init_label(mercury__shapes__lookup_simple_info_5_0_i4);
	init_label(mercury__shapes__lookup_simple_info_5_0_i5);
	init_label(mercury__shapes__lookup_simple_info_5_0_i1005);
BEGIN_CODE

/* code for predicate 'shapes__lookup_simple_info'/5 in mode 0 */
Define_static(mercury__shapes__lookup_simple_info_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__lookup_simple_info_5_0_i1005);
	incr_sp_push_msg(4, "shapes__lookup_simple_info");
	detstackvar(4) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(3), (Integer) mercury_data_shapes__common_3);
	{
		call_localret(STATIC(mercury__shapes__request_shape_number_5_0),
		mercury__shapes__lookup_simple_info_5_0_i4,
		STATIC(mercury__shapes__lookup_simple_info_5_0));
	}
	}
Define_label(mercury__shapes__lookup_simple_info_5_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__lookup_simple_info_5_0));
	r3 = (Integer) detstackvar(1);
	tag_incr_hp(detstackvar(1), mktag(0), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r1;
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) tempr1;
	r1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) detstackvar(3);
	localcall(mercury__shapes__lookup_simple_info_5_0,
		LABEL(mercury__shapes__lookup_simple_info_5_0_i5),
		STATIC(mercury__shapes__lookup_simple_info_5_0));
	}
Define_label(mercury__shapes__lookup_simple_info_5_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__lookup_simple_info_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__shapes__lookup_simple_info_5_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module17)
	init_entry(mercury__shapes__lookup_complicated_info_7_0);
	init_label(mercury__shapes__lookup_complicated_info_7_0_i4);
	init_label(mercury__shapes__lookup_complicated_info_7_0_i7);
	init_label(mercury__shapes__lookup_complicated_info_7_0_i6);
	init_label(mercury__shapes__lookup_complicated_info_7_0_i1003);
BEGIN_CODE

/* code for predicate 'shapes__lookup_complicated_info'/7 in mode 0 */
Define_static(mercury__shapes__lookup_complicated_info_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__shapes__lookup_complicated_info_7_0_i1003);
	incr_sp_push_msg(5, "shapes__lookup_complicated_info");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__shapes__lookup_complicated_info_7_0,
		LABEL(mercury__shapes__lookup_complicated_info_7_0_i4),
		STATIC(mercury__shapes__lookup_complicated_info_7_0));
Define_label(mercury__shapes__lookup_complicated_info_7_0_i4);
	update_prof_current_proc(LABEL(mercury__shapes__lookup_complicated_info_7_0));
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) r2;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__shapes__get_complicated_shapeids_7_0),
		mercury__shapes__lookup_complicated_info_7_0_i7,
		STATIC(mercury__shapes__lookup_complicated_info_7_0));
Define_label(mercury__shapes__lookup_complicated_info_7_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__lookup_complicated_info_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__lookup_complicated_info_7_0_i6);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	r2 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__shapes__lookup_complicated_info_7_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__shapes__lookup_complicated_info_7_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module18)
	init_entry(mercury__shapes__get_complicated_shapeids_7_0);
	init_label(mercury__shapes__get_complicated_shapeids_7_0_i2);
	init_label(mercury__shapes__get_complicated_shapeids_7_0_i3);
	init_label(mercury__shapes__get_complicated_shapeids_7_0_i5);
	init_label(mercury__shapes__get_complicated_shapeids_7_0_i7);
	init_label(mercury__shapes__get_complicated_shapeids_7_0_i8);
	init_label(mercury__shapes__get_complicated_shapeids_7_0_i1);
BEGIN_CODE

/* code for predicate 'shapes__get_complicated_shapeids'/7 in mode 0 */
Define_static(mercury__shapes__get_complicated_shapeids_7_0);
	incr_sp_push_msg(6, "shapes__get_complicated_shapeids");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(5) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r3 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_1);
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__hlds_data__make_cons_id_4_0);
	call_localret(ENTRY(mercury__hlds_data__make_cons_id_4_0),
		mercury__shapes__get_complicated_shapeids_7_0_i2,
		STATIC(mercury__shapes__get_complicated_shapeids_7_0));
	}
Define_label(mercury__shapes__get_complicated_shapeids_7_0_i2);
	update_prof_current_proc(LABEL(mercury__shapes__get_complicated_shapeids_7_0));
	r4 = (Integer) r1;
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_id_0[];
	r1 = (Integer) mercury_data_hlds_data__base_type_info_cons_id_0;
	}
	{
	extern Word * mercury_data_hlds_data__base_type_info_cons_tag_0[];
	r2 = (Integer) mercury_data_hlds_data__base_type_info_cons_tag_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__shapes__get_complicated_shapeids_7_0_i3,
		STATIC(mercury__shapes__get_complicated_shapeids_7_0));
	}
Define_label(mercury__shapes__get_complicated_shapeids_7_0_i3);
	update_prof_current_proc(LABEL(mercury__shapes__get_complicated_shapeids_7_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__shapes__get_complicated_shapeids_7_0_i1);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 5)))
		GOTO_LABEL(mercury__shapes__get_complicated_shapeids_7_0_i1);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__shapes__tag_match_2_0),
		mercury__shapes__get_complicated_shapeids_7_0_i5,
		STATIC(mercury__shapes__get_complicated_shapeids_7_0));
Define_label(mercury__shapes__get_complicated_shapeids_7_0_i5);
	update_prof_current_proc(LABEL(mercury__shapes__get_complicated_shapeids_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__shapes__get_complicated_shapeids_7_0_i1);
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__shapes__replace_all_contexts_in_ctor_args_2_0),
		mercury__shapes__get_complicated_shapeids_7_0_i7,
		STATIC(mercury__shapes__get_complicated_shapeids_7_0));
Define_label(mercury__shapes__get_complicated_shapeids_7_0_i7);
	update_prof_current_proc(LABEL(mercury__shapes__get_complicated_shapeids_7_0));
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__shapes__lookup_simple_info_5_0),
		mercury__shapes__get_complicated_shapeids_7_0_i8,
		STATIC(mercury__shapes__get_complicated_shapeids_7_0));
Define_label(mercury__shapes__get_complicated_shapeids_7_0_i8);
	update_prof_current_proc(LABEL(mercury__shapes__get_complicated_shapeids_7_0));
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__shapes__get_complicated_shapeids_7_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module19)
	init_entry(mercury____Unify___shapes__tagged_num_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___shapes__tagged_num_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_shapes__base_type_info_shape_num_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_shapes__base_type_info_tag_type_0;
	{
	Declare_entry(mercury____Unify___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___shapes__tagged_num_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module20)
	init_entry(mercury____Index___shapes__tagged_num_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___shapes__tagged_num_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_shapes__base_type_info_shape_num_0;
	r2 = (Integer) mercury_data_shapes__base_type_info_tag_type_0;
	{
	Declare_entry(mercury____Index___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___shapes__tagged_num_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module21)
	init_entry(mercury____Compare___shapes__tagged_num_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___shapes__tagged_num_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_shapes__base_type_info_shape_num_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_shapes__base_type_info_tag_type_0;
	{
	Declare_entry(mercury____Compare___std_util__pair_2_0);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___shapes__tagged_num_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module22)
	init_entry(mercury____Unify___shapes__tag_type_0_0);
	init_label(mercury____Unify___shapes__tag_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___shapes__tag_type_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___shapes__tag_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___shapes__tag_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module23)
	init_entry(mercury____Index___shapes__tag_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___shapes__tag_type_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___shapes__tag_type_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module24)
	init_entry(mercury____Compare___shapes__tag_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___shapes__tag_type_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___shapes__tag_type_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module25)
	init_entry(mercury____Unify___shapes__shape_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___shapes__shape_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_36);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___shapes__shape_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module26)
	init_entry(mercury____Index___shapes__shape_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___shapes__shape_list_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_36);
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___shapes__shape_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module27)
	init_entry(mercury____Compare___shapes__shape_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___shapes__shape_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_shapes__common_36);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___shapes__shape_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module28)
	init_entry(mercury____Unify___shapes__length_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___shapes__length_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___shapes__length_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module29)
	init_entry(mercury____Index___shapes__length_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___shapes__length_list_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___shapes__length_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module30)
	init_entry(mercury____Compare___shapes__length_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___shapes__length_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___shapes__length_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module31)
	init_entry(mercury____Unify___shapes__contents_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___shapes__contents_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___shapes__contents_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module32)
	init_entry(mercury____Index___shapes__contents_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___shapes__contents_list_0_0);
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Index___mercury_builtin__list_1_0),
		ENTRY(mercury____Index___shapes__contents_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module33)
	init_entry(mercury____Compare___shapes__contents_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___shapes__contents_list_0_0);
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___shapes__contents_list_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__shapes_module34)
	init_entry(mercury____Unify___shapes__shape_num_0_0);
	init_label(mercury____Unify___shapes__shape_num_0_0_i5);
	init_label(mercury____Unify___shapes__shape_num_0_0_i7);
	init_label(mercury____Unify___shapes__shape_num_0_0_i9);
	init_label(mercury____Unify___shapes__shape_num_0_0_i11);
	init_label(mercury____Unify___shapes__shape_num_0_0_i13);
	init_label(mercury____Unify___shapes__shape_num_0_0_i15);
	init_label(mercury____Unify___shapes__shape_num_0_0_i17);
	init_label(mercury____Unify___shapes__shape_num_0_0_i19);
	init_label(mercury____Unify___shapes__shape_num_0_0_i21);
	init_label(mercury____Unify___shapes__shape_num_0_0_i23);
	init_label(mercury____Unify___shapes__shape_num_0_0_i4);
	init_label(mercury____Unify___shapes__shape_num_0_0_i25);
	init_label(mercury____Unify___shapes__shape_num_0_0_i2);
	init_label(mercury____Unify___shapes__shape_num_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___shapes__shape_num_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i4);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Unify___shapes__shape_num_0_0_i5) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i7) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i9) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i11) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i13) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i15) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i17) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i19) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i21) AND
		LABEL(mercury____Unify___shapes__shape_num_0_0_i23));
Define_label(mercury____Unify___shapes__shape_num_0_0_i5);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i7);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i9);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i11);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i13);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i15);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 5)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i17);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 6)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i19);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 7)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i21);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 8)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i23);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 9)))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i25);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i25);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___shapes__shape_num_0_0_i1);
Define_label(mercury____Unify___shapes__shape_num_0_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___shapes__shape_num_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module35)
	init_entry(mercury____Index___shapes__shape_num_0_0);
	init_label(mercury____Index___shapes__shape_num_0_0_i5);
	init_label(mercury____Index___shapes__shape_num_0_0_i6);
	init_label(mercury____Index___shapes__shape_num_0_0_i7);
	init_label(mercury____Index___shapes__shape_num_0_0_i8);
	init_label(mercury____Index___shapes__shape_num_0_0_i9);
	init_label(mercury____Index___shapes__shape_num_0_0_i10);
	init_label(mercury____Index___shapes__shape_num_0_0_i11);
	init_label(mercury____Index___shapes__shape_num_0_0_i12);
	init_label(mercury____Index___shapes__shape_num_0_0_i13);
	init_label(mercury____Index___shapes__shape_num_0_0_i14);
	init_label(mercury____Index___shapes__shape_num_0_0_i4);
	init_label(mercury____Index___shapes__shape_num_0_0_i15);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___shapes__shape_num_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___shapes__shape_num_0_0_i4);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Index___shapes__shape_num_0_0_i5) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i6) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i7) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i8) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i9) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i10) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i11) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i12) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i13) AND
		LABEL(mercury____Index___shapes__shape_num_0_0_i14));
Define_label(mercury____Index___shapes__shape_num_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i7);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i8);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i10);
	r1 = ((Integer) 7);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i11);
	r1 = ((Integer) 8);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i12);
	r1 = ((Integer) 9);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i13);
	r1 = ((Integer) 10);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i14);
	r1 = ((Integer) 11);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___shapes__shape_num_0_0_i15);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___shapes__shape_num_0_0_i15);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__shapes_module36)
	init_entry(mercury____Compare___shapes__shape_num_0_0);
	init_label(mercury____Compare___shapes__shape_num_0_0_i2);
	init_label(mercury____Compare___shapes__shape_num_0_0_i3);
	init_label(mercury____Compare___shapes__shape_num_0_0_i4);
	init_label(mercury____Compare___shapes__shape_num_0_0_i6);
	init_label(mercury____Compare___shapes__shape_num_0_0_i13);
	init_label(mercury____Compare___shapes__shape_num_0_0_i15);
	init_label(mercury____Compare___shapes__shape_num_0_0_i17);
	init_label(mercury____Compare___shapes__shape_num_0_0_i19);
	init_label(mercury____Compare___shapes__shape_num_0_0_i21);
	init_label(mercury____Compare___shapes__shape_num_0_0_i23);
	init_label(mercury____Compare___shapes__shape_num_0_0_i25);
	init_label(mercury____Compare___shapes__shape_num_0_0_i27);
	init_label(mercury____Compare___shapes__shape_num_0_0_i29);
	init_label(mercury____Compare___shapes__shape_num_0_0_i31);
	init_label(mercury____Compare___shapes__shape_num_0_0_i12);
	init_label(mercury____Compare___shapes__shape_num_0_0_i33);
	init_label(mercury____Compare___shapes__shape_num_0_0_i9);
	init_label(mercury____Compare___shapes__shape_num_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___shapes__shape_num_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___shapes__shape_num_0_0),
		mercury____Compare___shapes__shape_num_0_0_i2,
		ENTRY(mercury____Compare___shapes__shape_num_0_0));
	}
Define_label(mercury____Compare___shapes__shape_num_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___shapes__shape_num_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___shapes__shape_num_0_0),
		mercury____Compare___shapes__shape_num_0_0_i3,
		ENTRY(mercury____Compare___shapes__shape_num_0_0));
	}
Define_label(mercury____Compare___shapes__shape_num_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___shapes__shape_num_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i12);
	COMPUTED_GOTO(unmkbody((Integer) r1),
		LABEL(mercury____Compare___shapes__shape_num_0_0_i13) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i15) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i17) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i19) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i21) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i23) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i25) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i27) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i29) AND
		LABEL(mercury____Compare___shapes__shape_num_0_0_i31));
Define_label(mercury____Compare___shapes__shape_num_0_0_i13);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i15);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i17);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i19);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i21);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 4)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i23);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 5)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i25);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 6)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i27);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 7)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i29);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 8)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i31);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 9)))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___shapes__shape_num_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i33);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___shapes__shape_num_0_0));
	}
Define_label(mercury____Compare___shapes__shape_num_0_0_i33);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___shapes__shape_num_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___shapes__shape_num_0_0));
	}
Define_label(mercury____Compare___shapes__shape_num_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___shapes__shape_num_0_0));
	}
Define_label(mercury____Compare___shapes__shape_num_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___shapes__shape_num_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__shapes_bunch_0(void)
{
	mercury__shapes_module0();
	mercury__shapes_module1();
	mercury__shapes_module2();
	mercury__shapes_module3();
	mercury__shapes_module4();
	mercury__shapes_module5();
	mercury__shapes_module6();
	mercury__shapes_module7();
	mercury__shapes_module8();
	mercury__shapes_module9();
	mercury__shapes_module10();
	mercury__shapes_module11();
	mercury__shapes_module12();
	mercury__shapes_module13();
	mercury__shapes_module14();
	mercury__shapes_module15();
	mercury__shapes_module16();
	mercury__shapes_module17();
	mercury__shapes_module18();
	mercury__shapes_module19();
	mercury__shapes_module20();
	mercury__shapes_module21();
	mercury__shapes_module22();
	mercury__shapes_module23();
	mercury__shapes_module24();
	mercury__shapes_module25();
	mercury__shapes_module26();
	mercury__shapes_module27();
	mercury__shapes_module28();
	mercury__shapes_module29();
	mercury__shapes_module30();
	mercury__shapes_module31();
	mercury__shapes_module32();
	mercury__shapes_module33();
	mercury__shapes_module34();
	mercury__shapes_module35();
	mercury__shapes_module36();
}

#endif

void mercury__shapes__init(void); /* suppress gcc warning */
void mercury__shapes__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__shapes_bunch_0();
#endif
}
