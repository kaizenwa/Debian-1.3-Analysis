/*
** Automatically generated from `goal_util.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__goal_util__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__goal_util__rename_var_maps_2__ua10000_4_0);
Declare_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i4);
Declare_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i5);
Declare_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i1003);
Define_extern_entry(mercury__goal_util__rename_vars_in_goals_4_0);
Declare_label(mercury__goal_util__rename_vars_in_goals_4_0_i4);
Declare_label(mercury__goal_util__rename_vars_in_goals_4_0_i5);
Declare_label(mercury__goal_util__rename_vars_in_goals_4_0_i1002);
Define_extern_entry(mercury__goal_util__rename_vars_in_goal_3_0);
Define_extern_entry(mercury__goal_util__must_rename_vars_in_goal_3_0);
Define_extern_entry(mercury__goal_util__rename_var_list_4_0);
Declare_label(mercury__goal_util__rename_var_list_4_0_i4);
Declare_label(mercury__goal_util__rename_var_list_4_0_i5);
Declare_label(mercury__goal_util__rename_var_list_4_0_i1002);
Define_extern_entry(mercury__goal_util__create_variables_9_0);
Declare_label(mercury__goal_util__create_variables_9_0_i6);
Declare_label(mercury__goal_util__create_variables_9_0_i5);
Declare_label(mercury__goal_util__create_variables_9_0_i8);
Declare_label(mercury__goal_util__create_variables_9_0_i11);
Declare_label(mercury__goal_util__create_variables_9_0_i13);
Declare_label(mercury__goal_util__create_variables_9_0_i10);
Declare_label(mercury__goal_util__create_variables_9_0_i14);
Declare_label(mercury__goal_util__create_variables_9_0_i15);
Declare_label(mercury__goal_util__create_variables_9_0_i18);
Declare_label(mercury__goal_util__create_variables_9_0_i20);
Declare_label(mercury__goal_util__create_variables_9_0_i17);
Declare_label(mercury__goal_util__create_variables_9_0_i1005);
Define_extern_entry(mercury__goal_util__goal_vars_2_0);
Declare_label(mercury__goal_util__goal_vars_2_0_i2);
Define_extern_entry(mercury__goal_util__goal_is_branched_1_0);
Declare_label(mercury__goal_util__goal_is_branched_1_0_i2);
Declare_label(mercury__goal_util__goal_is_branched_1_0_i1);
Define_extern_entry(mercury__goal_util__goal_size_2_0);
Define_extern_entry(mercury__goal_util__goal_calls_2_0);
Declare_static(mercury__goal_util__rename_var_4_0);
Declare_label(mercury__goal_util__rename_var_4_0_i4);
Declare_label(mercury__goal_util__rename_var_4_0_i3);
Declare_label(mercury__goal_util__rename_var_4_0_i7);
Declare_static(mercury__goal_util__rename_vars_in_goal_4_0);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i2);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i3);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i4);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i5);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i6);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i7);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i8);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i9);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i10);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i11);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i12);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i13);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i14);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i15);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i16);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i17);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i18);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i19);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i20);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i21);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i24);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i23);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i22);
Declare_label(mercury__goal_util__rename_vars_in_goal_4_0_i25);
Declare_static(mercury__goal_util__name_apart_2_4_0);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1007);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1006);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1005);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1004);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1003);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1002);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1001);
Declare_label(mercury__goal_util__name_apart_2_4_0_i5);
Declare_label(mercury__goal_util__name_apart_2_4_0_i6);
Declare_label(mercury__goal_util__name_apart_2_4_0_i7);
Declare_label(mercury__goal_util__name_apart_2_4_0_i8);
Declare_label(mercury__goal_util__name_apart_2_4_0_i9);
Declare_label(mercury__goal_util__name_apart_2_4_0_i10);
Declare_label(mercury__goal_util__name_apart_2_4_0_i11);
Declare_label(mercury__goal_util__name_apart_2_4_0_i12);
Declare_label(mercury__goal_util__name_apart_2_4_0_i13);
Declare_label(mercury__goal_util__name_apart_2_4_0_i14);
Declare_label(mercury__goal_util__name_apart_2_4_0_i15);
Declare_label(mercury__goal_util__name_apart_2_4_0_i16);
Declare_label(mercury__goal_util__name_apart_2_4_0_i17);
Declare_label(mercury__goal_util__name_apart_2_4_0_i18);
Declare_label(mercury__goal_util__name_apart_2_4_0_i19);
Declare_label(mercury__goal_util__name_apart_2_4_0_i20);
Declare_label(mercury__goal_util__name_apart_2_4_0_i21);
Declare_label(mercury__goal_util__name_apart_2_4_0_i22);
Declare_label(mercury__goal_util__name_apart_2_4_0_i23);
Declare_label(mercury__goal_util__name_apart_2_4_0_i24);
Declare_label(mercury__goal_util__name_apart_2_4_0_i25);
Declare_label(mercury__goal_util__name_apart_2_4_0_i26);
Declare_label(mercury__goal_util__name_apart_2_4_0_i27);
Declare_label(mercury__goal_util__name_apart_2_4_0_i28);
Declare_label(mercury__goal_util__name_apart_2_4_0_i1000);
Declare_label(mercury__goal_util__name_apart_2_4_0_i30);
Declare_label(mercury__goal_util__name_apart_2_4_0_i29);
Declare_label(mercury__goal_util__name_apart_2_4_0_i32);
Declare_label(mercury__goal_util__name_apart_2_4_0_i31);
Declare_label(mercury__goal_util__name_apart_2_4_0_i33);
Declare_label(mercury__goal_util__name_apart_2_4_0_i34);
Declare_static(mercury__goal_util__name_apart_list_4_0);
Declare_label(mercury__goal_util__name_apart_list_4_0_i4);
Declare_label(mercury__goal_util__name_apart_list_4_0_i5);
Declare_label(mercury__goal_util__name_apart_list_4_0_i1002);
Declare_static(mercury__goal_util__name_apart_cases_4_0);
Declare_label(mercury__goal_util__name_apart_cases_4_0_i4);
Declare_label(mercury__goal_util__name_apart_cases_4_0_i5);
Declare_label(mercury__goal_util__name_apart_cases_4_0_i1003);
Declare_static(mercury__goal_util__rename_unify_rhs_4_0);
Declare_label(mercury__goal_util__rename_unify_rhs_4_0_i5);
Declare_label(mercury__goal_util__rename_unify_rhs_4_0_i1000);
Declare_label(mercury__goal_util__rename_unify_rhs_4_0_i7);
Declare_label(mercury__goal_util__rename_unify_rhs_4_0_i6);
Declare_label(mercury__goal_util__rename_unify_rhs_4_0_i8);
Declare_label(mercury__goal_util__rename_unify_rhs_4_0_i9);
Declare_static(mercury__goal_util__rename_unify_4_0);
Declare_label(mercury__goal_util__rename_unify_4_0_i6);
Declare_label(mercury__goal_util__rename_unify_4_0_i7);
Declare_label(mercury__goal_util__rename_unify_4_0_i1011);
Declare_label(mercury__goal_util__rename_unify_4_0_i9);
Declare_label(mercury__goal_util__rename_unify_4_0_i10);
Declare_label(mercury__goal_util__rename_unify_4_0_i8);
Declare_label(mercury__goal_util__rename_unify_4_0_i12);
Declare_label(mercury__goal_util__rename_unify_4_0_i13);
Declare_label(mercury__goal_util__rename_unify_4_0_i11);
Declare_label(mercury__goal_util__rename_unify_4_0_i14);
Declare_label(mercury__goal_util__rename_unify_4_0_i15);
Declare_label(mercury__goal_util__rename_unify_4_0_i1009);
Declare_static(mercury__goal_util__rename_var_maps_4_0);
Declare_label(mercury__goal_util__rename_var_maps_4_0_i2);
Declare_label(mercury__goal_util__rename_var_maps_4_0_i3);
Declare_static(mercury__goal_util__name_apart_set_4_0);
Declare_label(mercury__goal_util__name_apart_set_4_0_i2);
Declare_label(mercury__goal_util__name_apart_set_4_0_i3);
Declare_static(mercury__goal_util__goal_vars_2_3_0);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1019);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1018);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1017);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1016);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i5);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i6);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i8);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i9);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i15);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i16);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i18);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i19);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i20);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i21);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1015);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i25);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i27);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1012);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1013);
Declare_label(mercury__goal_util__goal_vars_2_3_0_i1014);
Declare_static(mercury__goal_util__goals_goal_vars_3_0);
Declare_label(mercury__goal_util__goals_goal_vars_3_0_i4);
Declare_label(mercury__goal_util__goals_goal_vars_3_0_i1002);
Declare_static(mercury__goal_util__cases_goal_vars_3_0);
Declare_label(mercury__goal_util__cases_goal_vars_3_0_i4);
Declare_label(mercury__goal_util__cases_goal_vars_3_0_i1002);
Declare_static(mercury__goal_util__rhs_goal_vars_3_0);
Declare_label(mercury__goal_util__rhs_goal_vars_3_0_i1000);
Declare_label(mercury__goal_util__rhs_goal_vars_3_0_i6);
Declare_label(mercury__goal_util__rhs_goal_vars_3_0_i8);
Declare_static(mercury__goal_util__goals_size_2_0);
Declare_label(mercury__goal_util__goals_size_2_0_i4);
Declare_label(mercury__goal_util__goals_size_2_0_i5);
Declare_label(mercury__goal_util__goals_size_2_0_i1002);
Declare_static(mercury__goal_util__cases_size_2_0);
Declare_label(mercury__goal_util__cases_size_2_0_i4);
Declare_label(mercury__goal_util__cases_size_2_0_i5);
Declare_label(mercury__goal_util__cases_size_2_0_i1002);
Declare_static(mercury__goal_util__goal_expr_size_2_0);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1008);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1007);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1006);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1005);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1004);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i5);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i6);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i8);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i10);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i12);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i14);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i15);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i16);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i17);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1003);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i19);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1001);
Declare_label(mercury__goal_util__goal_expr_size_2_0_i1002);
Declare_static(mercury__goal_util__goals_calls_2_0);
Declare_label(mercury__goal_util__goals_calls_2_0_i6);
Declare_label(mercury__goal_util__goals_calls_2_0_i3);
Declare_label(mercury__goal_util__goals_calls_2_0_i1003);
Declare_static(mercury__goal_util__cases_calls_2_0);
Declare_label(mercury__goal_util__cases_calls_2_0_i6);
Declare_label(mercury__goal_util__cases_calls_2_0_i3);
Declare_label(mercury__goal_util__cases_calls_2_0_i1003);
Declare_static(mercury__goal_util__goal_expr_calls_2_0);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1022);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i17);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i21);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i25);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1021);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i29);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i2);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1010);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1014);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1015);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1016);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1017);
Declare_label(mercury__goal_util__goal_expr_calls_2_0_i1020);

BEGIN_MODULE(mercury__goal_util_module0)
	init_entry(mercury__goal_util__rename_var_maps_2__ua10000_4_0);
	init_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i4);
	init_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i5);
	init_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i1003);
BEGIN_CODE

/* code for predicate 'goal_util__rename_var_maps_2__ua10000'/4 in mode 0 */
Define_static(mercury__goal_util__rename_var_maps_2__ua10000_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i1003);
	incr_sp_push_msg(5, "goal_util__rename_var_maps_2__ua10000");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_var_maps_2__ua10000_4_0_i4,
		STATIC(mercury__goal_util__rename_var_maps_2__ua10000_4_0));
	}
Define_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_maps_2__ua10000_4_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(3);
	localcall(mercury__goal_util__rename_var_maps_2__ua10000_4_0,
		LABEL(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i5),
		STATIC(mercury__goal_util__rename_var_maps_2__ua10000_4_0));
	}
Define_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_maps_2__ua10000_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__goal_util__rename_var_maps_2__ua10000_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module1)
	init_entry(mercury__goal_util__rename_vars_in_goals_4_0);
	init_label(mercury__goal_util__rename_vars_in_goals_4_0_i4);
	init_label(mercury__goal_util__rename_vars_in_goals_4_0_i5);
	init_label(mercury__goal_util__rename_vars_in_goals_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_util__rename_vars_in_goals'/4 in mode 0 */
Define_entry(mercury__goal_util__rename_vars_in_goals_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__rename_vars_in_goals_4_0_i1002);
	incr_sp_push_msg(4, "goal_util__rename_vars_in_goals");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__rename_vars_in_goals_4_0_i4,
		ENTRY(mercury__goal_util__rename_vars_in_goals_4_0));
Define_label(mercury__goal_util__rename_vars_in_goals_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goals_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__goal_util__rename_vars_in_goals_4_0,
		LABEL(mercury__goal_util__rename_vars_in_goals_4_0_i5),
		ENTRY(mercury__goal_util__rename_vars_in_goals_4_0));
Define_label(mercury__goal_util__rename_vars_in_goals_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goals_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__goal_util__rename_vars_in_goals_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module2)
	init_entry(mercury__goal_util__rename_vars_in_goal_3_0);
BEGIN_CODE

/* code for predicate 'goal_util__rename_vars_in_goal'/3 in mode 0 */
Define_entry(mercury__goal_util__rename_vars_in_goal_3_0);
	r3 = (Integer) r2;
	r2 = ((Integer) 1);
	tailcall(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		ENTRY(mercury__goal_util__rename_vars_in_goal_3_0));
END_MODULE

BEGIN_MODULE(mercury__goal_util_module3)
	init_entry(mercury__goal_util__must_rename_vars_in_goal_3_0);
BEGIN_CODE

/* code for predicate 'goal_util__must_rename_vars_in_goal'/3 in mode 0 */
Define_entry(mercury__goal_util__must_rename_vars_in_goal_3_0);
	r3 = (Integer) r2;
	r2 = ((Integer) 0);
	tailcall(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		ENTRY(mercury__goal_util__must_rename_vars_in_goal_3_0));
END_MODULE

BEGIN_MODULE(mercury__goal_util_module4)
	init_entry(mercury__goal_util__rename_var_list_4_0);
	init_label(mercury__goal_util__rename_var_list_4_0_i4);
	init_label(mercury__goal_util__rename_var_list_4_0_i5);
	init_label(mercury__goal_util__rename_var_list_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_util__rename_var_list'/4 in mode 0 */
Define_entry(mercury__goal_util__rename_var_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__rename_var_list_4_0_i1002);
	incr_sp_push_msg(4, "goal_util__rename_var_list");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_var_list_4_0_i4,
		ENTRY(mercury__goal_util__rename_var_list_4_0));
Define_label(mercury__goal_util__rename_var_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_list_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__goal_util__rename_var_list_4_0,
		LABEL(mercury__goal_util__rename_var_list_4_0_i5),
		ENTRY(mercury__goal_util__rename_var_list_4_0));
Define_label(mercury__goal_util__rename_var_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_list_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__goal_util__rename_var_list_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module5)
	init_entry(mercury__goal_util__create_variables_9_0);
	init_label(mercury__goal_util__create_variables_9_0_i6);
	init_label(mercury__goal_util__create_variables_9_0_i5);
	init_label(mercury__goal_util__create_variables_9_0_i8);
	init_label(mercury__goal_util__create_variables_9_0_i11);
	init_label(mercury__goal_util__create_variables_9_0_i13);
	init_label(mercury__goal_util__create_variables_9_0_i10);
	init_label(mercury__goal_util__create_variables_9_0_i14);
	init_label(mercury__goal_util__create_variables_9_0_i15);
	init_label(mercury__goal_util__create_variables_9_0_i18);
	init_label(mercury__goal_util__create_variables_9_0_i20);
	init_label(mercury__goal_util__create_variables_9_0_i17);
	init_label(mercury__goal_util__create_variables_9_0_i1005);
BEGIN_CODE

/* code for predicate 'goal_util__create_variables'/9 in mode 0 */
Define_entry(mercury__goal_util__create_variables_9_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__create_variables_9_0_i1005);
	incr_sp_push_msg(12, "goal_util__create_variables");
	detstackvar(12) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	{
	Declare_entry(mercury__map__contains_2_0);
	call_localret(ENTRY(mercury__map__contains_2_0),
		mercury__goal_util__create_variables_9_0_i6,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__goal_util__create_variables_9_0_i5);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__goal_util__create_variables_9_0,
		ENTRY(mercury__goal_util__create_variables_9_0));
Define_label(mercury__goal_util__create_variables_9_0_i5);
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__varset__new_var_3_0);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__goal_util__create_variables_9_0_i8,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i8);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	detstackvar(10) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__varset__search_name_3_0);
	call_localret(ENTRY(mercury__varset__search_name_3_0),
		mercury__goal_util__create_variables_9_0_i11,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i11);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__goal_util__create_variables_9_0_i10);
	r1 = (Integer) detstackvar(11);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__varset__name_var_4_0);
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__goal_util__create_variables_9_0_i13,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i13);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	r6 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) r1;
	r5 = (Integer) detstackvar(10);
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	GOTO_LABEL(mercury__goal_util__create_variables_9_0_i14);
Define_label(mercury__goal_util__create_variables_9_0_i10);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) r2;
	r5 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
Define_label(mercury__goal_util__create_variables_9_0_i14);
	detstackvar(2) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r8;
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(10) = (Integer) r5;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__goal_util__create_variables_9_0_i15,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i15);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	detstackvar(9) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__goal_util__create_variables_9_0_i18,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i18);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__goal_util__create_variables_9_0_i17);
	r5 = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__goal_util__create_variables_9_0_i20,
		ENTRY(mercury__goal_util__create_variables_9_0));
	}
Define_label(mercury__goal_util__create_variables_9_0_i20);
	update_prof_current_proc(LABEL(mercury__goal_util__create_variables_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__goal_util__create_variables_9_0,
		ENTRY(mercury__goal_util__create_variables_9_0));
Define_label(mercury__goal_util__create_variables_9_0_i17);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__goal_util__create_variables_9_0,
		ENTRY(mercury__goal_util__create_variables_9_0));
Define_label(mercury__goal_util__create_variables_9_0_i1005);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module6)
	init_entry(mercury__goal_util__goal_vars_2_0);
	init_label(mercury__goal_util__goal_vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'goal_util__goal_vars'/2 in mode 0 */
Define_entry(mercury__goal_util__goal_vars_2_0);
	incr_sp_push_msg(2, "goal_util__goal_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__goal_util__goal_vars_2_0_i2,
		ENTRY(mercury__goal_util__goal_vars_2_0));
	}
Define_label(mercury__goal_util__goal_vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__goal_util__goal_vars_2_3_0),
		ENTRY(mercury__goal_util__goal_vars_2_0));
END_MODULE

BEGIN_MODULE(mercury__goal_util_module7)
	init_entry(mercury__goal_util__goal_is_branched_1_0);
	init_label(mercury__goal_util__goal_is_branched_1_0_i2);
	init_label(mercury__goal_util__goal_is_branched_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_util__goal_is_branched'/1 in mode 0 */
Define_entry(mercury__goal_util__goal_is_branched_1_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__goal_util__goal_is_branched_1_0_i1);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__goal_util__goal_is_branched_1_0_i2) AND
		LABEL(mercury__goal_util__goal_is_branched_1_0_i1) AND
		LABEL(mercury__goal_util__goal_is_branched_1_0_i2) AND
		LABEL(mercury__goal_util__goal_is_branched_1_0_i1) AND
		LABEL(mercury__goal_util__goal_is_branched_1_0_i1) AND
		LABEL(mercury__goal_util__goal_is_branched_1_0_i2) AND
		LABEL(mercury__goal_util__goal_is_branched_1_0_i1));
Define_label(mercury__goal_util__goal_is_branched_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__goal_util__goal_is_branched_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module8)
	init_entry(mercury__goal_util__goal_size_2_0);
BEGIN_CODE

/* code for predicate 'goal_size'/2 in mode 0 */
Define_entry(mercury__goal_util__goal_size_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__goal_util__goal_expr_size_2_0),
		ENTRY(mercury__goal_util__goal_size_2_0));
END_MODULE

BEGIN_MODULE(mercury__goal_util_module9)
	init_entry(mercury__goal_util__goal_calls_2_0);
BEGIN_CODE

/* code for predicate 'goal_calls'/2 in mode 0 */
Define_entry(mercury__goal_util__goal_calls_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__goal_util__goal_expr_calls_2_0),
		ENTRY(mercury__goal_util__goal_calls_2_0));
END_MODULE

BEGIN_MODULE(mercury__goal_util_module10)
	init_entry(mercury__goal_util__rename_var_4_0);
	init_label(mercury__goal_util__rename_var_4_0_i4);
	init_label(mercury__goal_util__rename_var_4_0_i3);
	init_label(mercury__goal_util__rename_var_4_0_i7);
BEGIN_CODE

/* code for predicate 'goal_util__rename_var'/4 in mode 0 */
Define_static(mercury__goal_util__rename_var_4_0);
	r4 = (Integer) r1;
	incr_sp_push_msg(3, "goal_util__rename_var");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__goal_util__rename_var_4_0_i4,
		STATIC(mercury__goal_util__rename_var_4_0));
	}
Define_label(mercury__goal_util__rename_var_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__goal_util__rename_var_4_0_i3);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__goal_util__rename_var_4_0_i3);
	if (((Integer) detstackvar(2) == ((Integer) 0)))
		GOTO_LABEL(mercury__goal_util__rename_var_4_0_i7);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__goal_util__rename_var_4_0_i7);
	r1 = string_const("goal_util__rename_var: no substitute", 36);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__goal_util__rename_var_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__goal_util_module11)
	init_entry(mercury__goal_util__rename_vars_in_goal_4_0);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i2);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i3);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i4);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i5);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i6);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i7);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i8);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i9);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i10);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i11);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i12);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i13);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i14);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i15);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i16);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i17);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i18);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i19);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i20);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i21);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i24);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i23);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i22);
	init_label(mercury__goal_util__rename_vars_in_goal_4_0_i25);
BEGIN_CODE

/* code for predicate 'goal_util__rename_vars_in_goal'/4 in mode 0 */
Define_static(mercury__goal_util__rename_vars_in_goal_4_0);
	incr_sp_push_msg(5, "goal_util__rename_vars_in_goal");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__name_apart_2_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i2,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_births_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i3,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i3);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__name_apart_set_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i4,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_pre_births_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_pre_births_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i5,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_deaths_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i6,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__name_apart_set_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i7,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i7);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_pre_deaths_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_pre_deaths_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i8,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i8);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_births_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i9,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__name_apart_set_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i10,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i10);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_post_births_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_post_births_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i11,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i11);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_deaths_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i12,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i12);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__name_apart_set_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i13,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i13);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_post_deaths_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_post_deaths_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i14,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i14);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i15,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__name_apart_set_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i16,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i16);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_nonlocals_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_nonlocals_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i17,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i17);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i18,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i18);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
	call_localret(ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i19,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i19);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_instmap_delta_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_instmap_delta_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i20,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i20);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_follow_vars_2_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i21,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i21);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__rename_vars_in_goal_4_0_i23);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_maps_4_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i24,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i24);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r3 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	GOTO_LABEL(mercury__goal_util__rename_vars_in_goal_4_0_i22);
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i23);
	r3 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i22);
	detstackvar(4) = (Integer) r3;
	{
	Declare_entry(mercury__hlds_goal__goal_info_set_follow_vars_3_0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_follow_vars_3_0),
		mercury__goal_util__rename_vars_in_goal_4_0_i25,
		STATIC(mercury__goal_util__rename_vars_in_goal_4_0));
	}
Define_label(mercury__goal_util__rename_vars_in_goal_4_0_i25);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_vars_in_goal_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module12)
	init_entry(mercury__goal_util__name_apart_2_4_0);
	init_label(mercury__goal_util__name_apart_2_4_0_i1007);
	init_label(mercury__goal_util__name_apart_2_4_0_i1006);
	init_label(mercury__goal_util__name_apart_2_4_0_i1005);
	init_label(mercury__goal_util__name_apart_2_4_0_i1004);
	init_label(mercury__goal_util__name_apart_2_4_0_i1003);
	init_label(mercury__goal_util__name_apart_2_4_0_i1002);
	init_label(mercury__goal_util__name_apart_2_4_0_i1001);
	init_label(mercury__goal_util__name_apart_2_4_0_i5);
	init_label(mercury__goal_util__name_apart_2_4_0_i6);
	init_label(mercury__goal_util__name_apart_2_4_0_i7);
	init_label(mercury__goal_util__name_apart_2_4_0_i8);
	init_label(mercury__goal_util__name_apart_2_4_0_i9);
	init_label(mercury__goal_util__name_apart_2_4_0_i10);
	init_label(mercury__goal_util__name_apart_2_4_0_i11);
	init_label(mercury__goal_util__name_apart_2_4_0_i12);
	init_label(mercury__goal_util__name_apart_2_4_0_i13);
	init_label(mercury__goal_util__name_apart_2_4_0_i14);
	init_label(mercury__goal_util__name_apart_2_4_0_i15);
	init_label(mercury__goal_util__name_apart_2_4_0_i16);
	init_label(mercury__goal_util__name_apart_2_4_0_i17);
	init_label(mercury__goal_util__name_apart_2_4_0_i18);
	init_label(mercury__goal_util__name_apart_2_4_0_i19);
	init_label(mercury__goal_util__name_apart_2_4_0_i20);
	init_label(mercury__goal_util__name_apart_2_4_0_i21);
	init_label(mercury__goal_util__name_apart_2_4_0_i22);
	init_label(mercury__goal_util__name_apart_2_4_0_i23);
	init_label(mercury__goal_util__name_apart_2_4_0_i24);
	init_label(mercury__goal_util__name_apart_2_4_0_i25);
	init_label(mercury__goal_util__name_apart_2_4_0_i26);
	init_label(mercury__goal_util__name_apart_2_4_0_i27);
	init_label(mercury__goal_util__name_apart_2_4_0_i28);
	init_label(mercury__goal_util__name_apart_2_4_0_i1000);
	init_label(mercury__goal_util__name_apart_2_4_0_i30);
	init_label(mercury__goal_util__name_apart_2_4_0_i29);
	init_label(mercury__goal_util__name_apart_2_4_0_i32);
	init_label(mercury__goal_util__name_apart_2_4_0_i31);
	init_label(mercury__goal_util__name_apart_2_4_0_i33);
	init_label(mercury__goal_util__name_apart_2_4_0_i34);
BEGIN_CODE

/* code for predicate 'goal_util__name_apart_2'/4 in mode 0 */
Define_static(mercury__goal_util__name_apart_2_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i1000);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__goal_util__name_apart_2_4_0_i1007) AND
		LABEL(mercury__goal_util__name_apart_2_4_0_i1006) AND
		LABEL(mercury__goal_util__name_apart_2_4_0_i1005) AND
		LABEL(mercury__goal_util__name_apart_2_4_0_i1004) AND
		LABEL(mercury__goal_util__name_apart_2_4_0_i1003) AND
		LABEL(mercury__goal_util__name_apart_2_4_0_i1002) AND
		LABEL(mercury__goal_util__name_apart_2_4_0_i1001));
Define_label(mercury__goal_util__name_apart_2_4_0_i1007);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i5);
Define_label(mercury__goal_util__name_apart_2_4_0_i1006);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i9);
Define_label(mercury__goal_util__name_apart_2_4_0_i1005);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i13);
Define_label(mercury__goal_util__name_apart_2_4_0_i1004);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i16);
Define_label(mercury__goal_util__name_apart_2_4_0_i1003);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i18);
Define_label(mercury__goal_util__name_apart_2_4_0_i1002);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i21);
Define_label(mercury__goal_util__name_apart_2_4_0_i1001);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i27);
Define_label(mercury__goal_util__name_apart_2_4_0_i5);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__name_apart_2_4_0_i6,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__name_apart_cases_4_0),
		mercury__goal_util__name_apart_2_4_0_i7,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_maps_4_0),
		mercury__goal_util__name_apart_2_4_0_i8,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 5));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i9);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__name_apart_2_4_0_i10,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_unify_rhs_4_0),
		mercury__goal_util__name_apart_2_4_0_i11,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_unify_4_0),
		mercury__goal_util__name_apart_2_4_0_i12,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i13);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__goal_util__name_apart_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i14,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_maps_4_0),
		mercury__goal_util__name_apart_2_4_0_i15,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 2);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i16);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_2_4_0_i17,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 3);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i18);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i19,
		STATIC(mercury__goal_util__name_apart_2_4_0));
	}
Define_label(mercury__goal_util__name_apart_2_4_0_i19);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_2_4_0_i20,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i20);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 4);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i21);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i22,
		STATIC(mercury__goal_util__name_apart_2_4_0));
	}
Define_label(mercury__goal_util__name_apart_2_4_0_i22);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_2_4_0_i23,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i23);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_2_4_0_i24,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i24);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_2_4_0_i25,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i25);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data_llds__base_type_info_lval_0[];
	r1 = (Integer) mercury_data_llds__base_type_info_lval_0;
	}
	r2 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_maps_4_0),
		mercury__goal_util__name_apart_2_4_0_i26,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i26);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 6));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 5);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i27);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 6));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i28,
		STATIC(mercury__goal_util__name_apart_2_4_0));
	}
Define_label(mercury__goal_util__name_apart_2_4_0_i28);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 7));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 6);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(3), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(3), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(3), (Integer) r1, ((Integer) 5)) = (Integer) r2;
	field(mktag(3), (Integer) r1, ((Integer) 6)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i1000);
	incr_sp_push_msg(7, "goal_util__name_apart_2");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i29);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__name_apart_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i30,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i30);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i29);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__name_apart_2_4_0_i31);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i32,
		STATIC(mercury__goal_util__name_apart_2_4_0));
	}
Define_label(mercury__goal_util__name_apart_2_4_0_i32);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 6));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__name_apart_2_4_0_i31);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__name_apart_2_4_0_i33,
		STATIC(mercury__goal_util__name_apart_2_4_0));
Define_label(mercury__goal_util__name_apart_2_4_0_i33);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__name_apart_2_4_0_i34,
		STATIC(mercury__goal_util__name_apart_2_4_0));
	}
Define_label(mercury__goal_util__name_apart_2_4_0_i34);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 5));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(2), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module13)
	init_entry(mercury__goal_util__name_apart_list_4_0);
	init_label(mercury__goal_util__name_apart_list_4_0_i4);
	init_label(mercury__goal_util__name_apart_list_4_0_i5);
	init_label(mercury__goal_util__name_apart_list_4_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_util__name_apart_list'/4 in mode 0 */
Define_static(mercury__goal_util__name_apart_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__name_apart_list_4_0_i1002);
	incr_sp_push_msg(4, "goal_util__name_apart_list");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_list_4_0_i4,
		STATIC(mercury__goal_util__name_apart_list_4_0));
Define_label(mercury__goal_util__name_apart_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_list_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__goal_util__name_apart_list_4_0,
		LABEL(mercury__goal_util__name_apart_list_4_0_i5),
		STATIC(mercury__goal_util__name_apart_list_4_0));
Define_label(mercury__goal_util__name_apart_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_list_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__goal_util__name_apart_list_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module14)
	init_entry(mercury__goal_util__name_apart_cases_4_0);
	init_label(mercury__goal_util__name_apart_cases_4_0_i4);
	init_label(mercury__goal_util__name_apart_cases_4_0_i5);
	init_label(mercury__goal_util__name_apart_cases_4_0_i1003);
BEGIN_CODE

/* code for predicate 'goal_util__name_apart_cases'/4 in mode 0 */
Define_static(mercury__goal_util__name_apart_cases_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__name_apart_cases_4_0_i1003);
	incr_sp_push_msg(5, "goal_util__name_apart_cases");
	detstackvar(5) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__name_apart_cases_4_0_i4,
		STATIC(mercury__goal_util__name_apart_cases_4_0));
	}
Define_label(mercury__goal_util__name_apart_cases_4_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_cases_4_0));
	r2 = (Integer) detstackvar(1);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	detstackvar(1) = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(3);
	localcall(mercury__goal_util__name_apart_cases_4_0,
		LABEL(mercury__goal_util__name_apart_cases_4_0_i5),
		STATIC(mercury__goal_util__name_apart_cases_4_0));
	}
Define_label(mercury__goal_util__name_apart_cases_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_cases_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__goal_util__name_apart_cases_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module15)
	init_entry(mercury__goal_util__rename_unify_rhs_4_0);
	init_label(mercury__goal_util__rename_unify_rhs_4_0_i5);
	init_label(mercury__goal_util__rename_unify_rhs_4_0_i1000);
	init_label(mercury__goal_util__rename_unify_rhs_4_0_i7);
	init_label(mercury__goal_util__rename_unify_rhs_4_0_i6);
	init_label(mercury__goal_util__rename_unify_rhs_4_0_i8);
	init_label(mercury__goal_util__rename_unify_rhs_4_0_i9);
BEGIN_CODE

/* code for predicate 'goal_util__rename_unify_rhs'/4 in mode 0 */
Define_static(mercury__goal_util__rename_unify_rhs_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__rename_unify_rhs_4_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(7, "goal_util__rename_unify_rhs");
	detstackvar(7) = (Integer) succip;
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_rhs_4_0_i5,
		STATIC(mercury__goal_util__rename_unify_rhs_4_0));
Define_label(mercury__goal_util__rename_unify_rhs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_rhs_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__rename_unify_rhs_4_0_i1000);
	incr_sp_push_msg(7, "goal_util__rename_unify_rhs");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__rename_unify_rhs_4_0_i6);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__rename_unify_rhs_4_0_i7,
		STATIC(mercury__goal_util__rename_unify_rhs_4_0));
	}
Define_label(mercury__goal_util__rename_unify_rhs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_rhs_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__rename_unify_rhs_4_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__rename_unify_rhs_4_0_i8,
		STATIC(mercury__goal_util__rename_unify_rhs_4_0));
	}
Define_label(mercury__goal_util__rename_unify_rhs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_rhs_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_vars_in_goal_4_0),
		mercury__goal_util__rename_unify_rhs_4_0_i9,
		STATIC(mercury__goal_util__rename_unify_rhs_4_0));
Define_label(mercury__goal_util__rename_unify_rhs_4_0_i9);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_rhs_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 5));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(2), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(2), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module16)
	init_entry(mercury__goal_util__rename_unify_4_0);
	init_label(mercury__goal_util__rename_unify_4_0_i6);
	init_label(mercury__goal_util__rename_unify_4_0_i7);
	init_label(mercury__goal_util__rename_unify_4_0_i1011);
	init_label(mercury__goal_util__rename_unify_4_0_i9);
	init_label(mercury__goal_util__rename_unify_4_0_i10);
	init_label(mercury__goal_util__rename_unify_4_0_i8);
	init_label(mercury__goal_util__rename_unify_4_0_i12);
	init_label(mercury__goal_util__rename_unify_4_0_i13);
	init_label(mercury__goal_util__rename_unify_4_0_i11);
	init_label(mercury__goal_util__rename_unify_4_0_i14);
	init_label(mercury__goal_util__rename_unify_4_0_i15);
	init_label(mercury__goal_util__rename_unify_4_0_i1009);
BEGIN_CODE

/* code for predicate 'goal_util__rename_unify'/4 in mode 0 */
Define_static(mercury__goal_util__rename_unify_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__goal_util__rename_unify_4_0_i1011);
	r4 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r4 != ((Integer) 0)))
		GOTO_LABEL(mercury__goal_util__rename_unify_4_0_i1009);
	incr_sp_push_msg(7, "goal_util__rename_unify");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_4_0_i6,
		STATIC(mercury__goal_util__rename_unify_4_0));
Define_label(mercury__goal_util__rename_unify_4_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_4_0_i7,
		STATIC(mercury__goal_util__rename_unify_4_0));
Define_label(mercury__goal_util__rename_unify_4_0_i7);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(3), ((Integer) 3));
	field(mktag(3), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(3), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__rename_unify_4_0_i1011);
	incr_sp_push_msg(7, "goal_util__rename_unify");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__rename_unify_4_0_i8);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_4_0_i9,
		STATIC(mercury__goal_util__rename_unify_4_0));
Define_label(mercury__goal_util__rename_unify_4_0_i9);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__rename_unify_4_0_i10,
		STATIC(mercury__goal_util__rename_unify_4_0));
	}
Define_label(mercury__goal_util__rename_unify_4_0_i10);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__rename_unify_4_0_i8);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__rename_unify_4_0_i11);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_4_0_i12,
		STATIC(mercury__goal_util__rename_unify_4_0));
Define_label(mercury__goal_util__rename_unify_4_0_i12);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__rename_unify_4_0_i13,
		STATIC(mercury__goal_util__rename_unify_4_0));
	}
Define_label(mercury__goal_util__rename_unify_4_0_i13);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 5));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__rename_unify_4_0_i11);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_4_0_i14,
		STATIC(mercury__goal_util__rename_unify_4_0));
Define_label(mercury__goal_util__rename_unify_4_0_i14);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_4_0),
		mercury__goal_util__rename_unify_4_0_i15,
		STATIC(mercury__goal_util__rename_unify_4_0));
Define_label(mercury__goal_util__rename_unify_4_0_i15);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_unify_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(2), ((Integer) 2));
	field(mktag(2), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(2), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__goal_util__rename_unify_4_0_i1009);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module17)
	init_entry(mercury__goal_util__rename_var_maps_4_0);
	init_label(mercury__goal_util__rename_var_maps_4_0_i2);
	init_label(mercury__goal_util__rename_var_maps_4_0_i3);
BEGIN_CODE

/* code for predicate 'goal_util__rename_var_maps'/4 in mode 0 */
Define_static(mercury__goal_util__rename_var_maps_4_0);
	incr_sp_push_msg(4, "goal_util__rename_var_maps");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	detstackvar(2) = (Integer) r4;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__goal_util__rename_var_maps_4_0_i2,
		STATIC(mercury__goal_util__rename_var_maps_4_0));
	}
Define_label(mercury__goal_util__rename_var_maps_4_0_i2);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_maps_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__goal_util__rename_var_maps_2__ua10000_4_0),
		mercury__goal_util__rename_var_maps_4_0_i3,
		STATIC(mercury__goal_util__rename_var_maps_4_0));
Define_label(mercury__goal_util__rename_var_maps_4_0_i3);
	update_prof_current_proc(LABEL(mercury__goal_util__rename_var_maps_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	tailcall(ENTRY(mercury__map__from_assoc_list_2_0),
		STATIC(mercury__goal_util__rename_var_maps_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__goal_util_module18)
	init_entry(mercury__goal_util__name_apart_set_4_0);
	init_label(mercury__goal_util__name_apart_set_4_0_i2);
	init_label(mercury__goal_util__name_apart_set_4_0_i3);
BEGIN_CODE

/* code for predicate 'goal_util__name_apart_set'/4 in mode 0 */
Define_static(mercury__goal_util__name_apart_set_4_0);
	incr_sp_push_msg(3, "goal_util__name_apart_set");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__goal_util__name_apart_set_4_0_i2,
		STATIC(mercury__goal_util__name_apart_set_4_0));
	}
Define_label(mercury__goal_util__name_apart_set_4_0_i2);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_set_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__goal_util__rename_var_list_4_0),
		mercury__goal_util__name_apart_set_4_0_i3,
		STATIC(mercury__goal_util__name_apart_set_4_0));
	}
Define_label(mercury__goal_util__name_apart_set_4_0_i3);
	update_prof_current_proc(LABEL(mercury__goal_util__name_apart_set_4_0));
	r2 = (Integer) r1;
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		STATIC(mercury__goal_util__name_apart_set_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__goal_util_module19)
	init_entry(mercury__goal_util__goal_vars_2_3_0);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1019);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1018);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1017);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1016);
	init_label(mercury__goal_util__goal_vars_2_3_0_i5);
	init_label(mercury__goal_util__goal_vars_2_3_0_i6);
	init_label(mercury__goal_util__goal_vars_2_3_0_i8);
	init_label(mercury__goal_util__goal_vars_2_3_0_i9);
	init_label(mercury__goal_util__goal_vars_2_3_0_i15);
	init_label(mercury__goal_util__goal_vars_2_3_0_i16);
	init_label(mercury__goal_util__goal_vars_2_3_0_i18);
	init_label(mercury__goal_util__goal_vars_2_3_0_i19);
	init_label(mercury__goal_util__goal_vars_2_3_0_i20);
	init_label(mercury__goal_util__goal_vars_2_3_0_i21);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1015);
	init_label(mercury__goal_util__goal_vars_2_3_0_i25);
	init_label(mercury__goal_util__goal_vars_2_3_0_i27);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1012);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1013);
	init_label(mercury__goal_util__goal_vars_2_3_0_i1014);
BEGIN_CODE

/* code for predicate 'goal_util__goal_vars_2'/3 in mode 0 */
Define_static(mercury__goal_util__goal_vars_2_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i1015);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1019) AND
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1018) AND
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1012) AND
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1013) AND
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1017) AND
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1016) AND
		LABEL(mercury__goal_util__goal_vars_2_3_0_i1014));
Define_label(mercury__goal_util__goal_vars_2_3_0_i1019);
	incr_sp_push_msg(4, "goal_util__goal_vars_2");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i5);
Define_label(mercury__goal_util__goal_vars_2_3_0_i1018);
	incr_sp_push_msg(4, "goal_util__goal_vars_2");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i8);
Define_label(mercury__goal_util__goal_vars_2_3_0_i1017);
	incr_sp_push_msg(4, "goal_util__goal_vars_2");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i15);
Define_label(mercury__goal_util__goal_vars_2_3_0_i1016);
	incr_sp_push_msg(4, "goal_util__goal_vars_2");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i18);
Define_label(mercury__goal_util__goal_vars_2_3_0_i5);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__goal_util__goal_vars_2_3_0_i6,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
Define_label(mercury__goal_util__goal_vars_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__goal_util__cases_goal_vars_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i8);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__goal_util__goal_vars_2_3_0_i9,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
Define_label(mercury__goal_util__goal_vars_2_3_0_i9);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__goal_util__rhs_goal_vars_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i15);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__goal_util__goal_vars_2_3_0_i16,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
Define_label(mercury__goal_util__goal_vars_2_3_0_i16);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__goal_util__goal_vars_2_3_0,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i18);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r1, ((Integer) 2)), ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r1, ((Integer) 3)), ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) field(mktag(3), (Integer) r1, ((Integer) 4)), ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__goal_util__goal_vars_2_3_0_i19,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
Define_label(mercury__goal_util__goal_vars_2_3_0_i19);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	localcall(mercury__goal_util__goal_vars_2_3_0,
		LABEL(mercury__goal_util__goal_vars_2_3_0_i20),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i20);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__goal_util__goal_vars_2_3_0,
		LABEL(mercury__goal_util__goal_vars_2_3_0_i21),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i21);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_vars_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__goal_util__goal_vars_2_3_0,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i1015);
	incr_sp_push_msg(4, "goal_util__goal_vars_2");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i25);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__goal_util__goals_goal_vars_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i25);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__goal_vars_2_3_0_i27);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__set__insert_list_3_0);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
Define_label(mercury__goal_util__goal_vars_2_3_0_i27);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__set__insert_list_3_0);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
Define_label(mercury__goal_util__goal_vars_2_3_0_i1012);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__goal_util__goals_goal_vars_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i1013);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	localtailcall(mercury__goal_util__goal_vars_2_3_0,
		STATIC(mercury__goal_util__goal_vars_2_3_0));
Define_label(mercury__goal_util__goal_vars_2_3_0_i1014);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 5));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_list_3_0);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__goal_util__goal_vars_2_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__goal_util_module20)
	init_entry(mercury__goal_util__goals_goal_vars_3_0);
	init_label(mercury__goal_util__goals_goal_vars_3_0_i4);
	init_label(mercury__goal_util__goals_goal_vars_3_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_util__goals_goal_vars'/3 in mode 0 */
Define_static(mercury__goal_util__goals_goal_vars_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__goals_goal_vars_3_0_i1002);
	incr_sp_push_msg(2, "goal_util__goals_goal_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__goal_vars_2_3_0),
		mercury__goal_util__goals_goal_vars_3_0_i4,
		STATIC(mercury__goal_util__goals_goal_vars_3_0));
Define_label(mercury__goal_util__goals_goal_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__goals_goal_vars_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__goal_util__goals_goal_vars_3_0,
		STATIC(mercury__goal_util__goals_goal_vars_3_0));
Define_label(mercury__goal_util__goals_goal_vars_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module21)
	init_entry(mercury__goal_util__cases_goal_vars_3_0);
	init_label(mercury__goal_util__cases_goal_vars_3_0_i4);
	init_label(mercury__goal_util__cases_goal_vars_3_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_util__cases_goal_vars'/3 in mode 0 */
Define_static(mercury__goal_util__cases_goal_vars_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__cases_goal_vars_3_0_i1002);
	incr_sp_push_msg(2, "goal_util__cases_goal_vars");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1)), ((Integer) 0));
	call_localret(STATIC(mercury__goal_util__goal_vars_2_3_0),
		mercury__goal_util__cases_goal_vars_3_0_i4,
		STATIC(mercury__goal_util__cases_goal_vars_3_0));
Define_label(mercury__goal_util__cases_goal_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__cases_goal_vars_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__goal_util__cases_goal_vars_3_0,
		STATIC(mercury__goal_util__cases_goal_vars_3_0));
Define_label(mercury__goal_util__cases_goal_vars_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module22)
	init_entry(mercury__goal_util__rhs_goal_vars_3_0);
	init_label(mercury__goal_util__rhs_goal_vars_3_0_i1000);
	init_label(mercury__goal_util__rhs_goal_vars_3_0_i6);
	init_label(mercury__goal_util__rhs_goal_vars_3_0_i8);
BEGIN_CODE

/* code for predicate 'goal_util__rhs_goal_vars'/3 in mode 0 */
Define_static(mercury__goal_util__rhs_goal_vars_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__rhs_goal_vars_3_0_i1000);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_3_1);
	tailcall(ENTRY(mercury__set__insert_3_1),
		STATIC(mercury__goal_util__rhs_goal_vars_3_0));
	}
Define_label(mercury__goal_util__rhs_goal_vars_3_0_i1000);
	incr_sp_push_msg(2, "goal_util__rhs_goal_vars");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__rhs_goal_vars_3_0_i6);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__insert_list_3_0);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__goal_util__rhs_goal_vars_3_0));
	}
Define_label(mercury__goal_util__rhs_goal_vars_3_0_i6);
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) field(mktag(2), (Integer) r1, ((Integer) 4)), ((Integer) 0));
	{
	extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	}
	{
	Declare_entry(mercury__set__insert_list_3_0);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__goal_util__rhs_goal_vars_3_0_i8,
		STATIC(mercury__goal_util__rhs_goal_vars_3_0));
	}
Define_label(mercury__goal_util__rhs_goal_vars_3_0_i8);
	update_prof_current_proc(LABEL(mercury__goal_util__rhs_goal_vars_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__goal_util__goal_vars_2_3_0),
		STATIC(mercury__goal_util__rhs_goal_vars_3_0));
END_MODULE

BEGIN_MODULE(mercury__goal_util_module23)
	init_entry(mercury__goal_util__goals_size_2_0);
	init_label(mercury__goal_util__goals_size_2_0_i4);
	init_label(mercury__goal_util__goals_size_2_0_i5);
	init_label(mercury__goal_util__goals_size_2_0_i1002);
BEGIN_CODE

/* code for predicate 'goals_size'/2 in mode 0 */
Define_static(mercury__goal_util__goals_size_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__goals_size_2_0_i1002);
	incr_sp_push_msg(2, "goals_size");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__goals_size_2_0_i4,
		STATIC(mercury__goal_util__goals_size_2_0));
	}
Define_label(mercury__goal_util__goals_size_2_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__goals_size_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__goal_util__goals_size_2_0,
		LABEL(mercury__goal_util__goals_size_2_0_i5),
		STATIC(mercury__goal_util__goals_size_2_0));
Define_label(mercury__goal_util__goals_size_2_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__goals_size_2_0));
	r1 = ((Integer) detstackvar(1) + (Integer) r1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__goal_util__goals_size_2_0_i1002);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module24)
	init_entry(mercury__goal_util__cases_size_2_0);
	init_label(mercury__goal_util__cases_size_2_0_i4);
	init_label(mercury__goal_util__cases_size_2_0_i5);
	init_label(mercury__goal_util__cases_size_2_0_i1002);
BEGIN_CODE

/* code for predicate 'cases_size'/2 in mode 0 */
Define_static(mercury__goal_util__cases_size_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__cases_size_2_0_i1002);
	incr_sp_push_msg(2, "cases_size");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__cases_size_2_0_i4,
		STATIC(mercury__goal_util__cases_size_2_0));
	}
Define_label(mercury__goal_util__cases_size_2_0_i4);
	update_prof_current_proc(LABEL(mercury__goal_util__cases_size_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	localcall(mercury__goal_util__cases_size_2_0,
		LABEL(mercury__goal_util__cases_size_2_0_i5),
		STATIC(mercury__goal_util__cases_size_2_0));
Define_label(mercury__goal_util__cases_size_2_0_i5);
	update_prof_current_proc(LABEL(mercury__goal_util__cases_size_2_0));
	r1 = ((Integer) detstackvar(1) + (Integer) r1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__goal_util__cases_size_2_0_i1002);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module25)
	init_entry(mercury__goal_util__goal_expr_size_2_0);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1008);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1007);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1006);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1005);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1004);
	init_label(mercury__goal_util__goal_expr_size_2_0_i5);
	init_label(mercury__goal_util__goal_expr_size_2_0_i6);
	init_label(mercury__goal_util__goal_expr_size_2_0_i8);
	init_label(mercury__goal_util__goal_expr_size_2_0_i10);
	init_label(mercury__goal_util__goal_expr_size_2_0_i12);
	init_label(mercury__goal_util__goal_expr_size_2_0_i14);
	init_label(mercury__goal_util__goal_expr_size_2_0_i15);
	init_label(mercury__goal_util__goal_expr_size_2_0_i16);
	init_label(mercury__goal_util__goal_expr_size_2_0_i17);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1003);
	init_label(mercury__goal_util__goal_expr_size_2_0_i19);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1001);
	init_label(mercury__goal_util__goal_expr_size_2_0_i1002);
BEGIN_CODE

/* code for predicate 'goal_expr_size'/2 in mode 0 */
Define_static(mercury__goal_util__goal_expr_size_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i1003);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1008) AND
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1001) AND
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1007) AND
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1006) AND
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1005) AND
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1004) AND
		LABEL(mercury__goal_util__goal_expr_size_2_0_i1001));
Define_label(mercury__goal_util__goal_expr_size_2_0_i1008);
	incr_sp_push_msg(3, "goal_expr_size");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i5);
Define_label(mercury__goal_util__goal_expr_size_2_0_i1007);
	incr_sp_push_msg(3, "goal_expr_size");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i8);
Define_label(mercury__goal_util__goal_expr_size_2_0_i1006);
	incr_sp_push_msg(3, "goal_expr_size");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i10);
Define_label(mercury__goal_util__goal_expr_size_2_0_i1005);
	incr_sp_push_msg(3, "goal_expr_size");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i12);
Define_label(mercury__goal_util__goal_expr_size_2_0_i1004);
	incr_sp_push_msg(3, "goal_expr_size");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i14);
Define_label(mercury__goal_util__goal_expr_size_2_0_i5);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	call_localret(STATIC(mercury__goal_util__cases_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i6,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
Define_label(mercury__goal_util__goal_expr_size_2_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_expr_size_2_0));
	r1 = ((Integer) r1 + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__goal_util__goal_expr_size_2_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	call_localret(STATIC(mercury__goal_util__goals_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i6,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
Define_label(mercury__goal_util__goal_expr_size_2_0_i10);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i6,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
	}
Define_label(mercury__goal_util__goal_expr_size_2_0_i12);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i6,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
	}
Define_label(mercury__goal_util__goal_expr_size_2_0_i14);
	detstackvar(1) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i15,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
	}
Define_label(mercury__goal_util__goal_expr_size_2_0_i15);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_expr_size_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i16,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
	}
Define_label(mercury__goal_util__goal_expr_size_2_0_i16);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_expr_size_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__goal_util__goal_size_2_0),
		mercury__goal_util__goal_expr_size_2_0_i17,
		STATIC(mercury__goal_util__goal_expr_size_2_0));
	}
Define_label(mercury__goal_util__goal_expr_size_2_0_i17);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_expr_size_2_0));
	r1 = ((((Integer) detstackvar(1) + (Integer) detstackvar(2)) + (Integer) r1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__goal_util__goal_expr_size_2_0_i1003);
	incr_sp_push_msg(3, "goal_expr_size");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i19);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__goal_util__goals_size_2_0),
		STATIC(mercury__goal_util__goal_expr_size_2_0));
Define_label(mercury__goal_util__goal_expr_size_2_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__goal_expr_size_2_0_i1002);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__goal_util__goal_expr_size_2_0_i1001);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__goal_util__goal_expr_size_2_0_i1002);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module26)
	init_entry(mercury__goal_util__goals_calls_2_0);
	init_label(mercury__goal_util__goals_calls_2_0_i6);
	init_label(mercury__goal_util__goals_calls_2_0_i3);
	init_label(mercury__goal_util__goals_calls_2_0_i1003);
BEGIN_CODE

/* code for predicate 'goals_calls'/2 in mode 0 */
Define_static(mercury__goal_util__goals_calls_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__goals_calls_2_0_i1003);
	incr_sp_push_msg(3, "goals_calls");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__goal_util__goal_calls_2_0),
		mercury__goal_util__goals_calls_2_0_i6,
		STATIC(mercury__goal_util__goals_calls_2_0));
	}
Define_label(mercury__goal_util__goals_calls_2_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__goals_calls_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__goal_util__goals_calls_2_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__goal_util__goals_calls_2_0,
		STATIC(mercury__goal_util__goals_calls_2_0));
Define_label(mercury__goal_util__goals_calls_2_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__goal_util__goals_calls_2_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module27)
	init_entry(mercury__goal_util__cases_calls_2_0);
	init_label(mercury__goal_util__cases_calls_2_0_i6);
	init_label(mercury__goal_util__cases_calls_2_0_i3);
	init_label(mercury__goal_util__cases_calls_2_0_i1003);
BEGIN_CODE

/* code for predicate 'cases_calls'/2 in mode 0 */
Define_static(mercury__goal_util__cases_calls_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__goal_util__cases_calls_2_0_i1003);
	incr_sp_push_msg(3, "cases_calls");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), ((Integer) 1));
	{
		call_localret(STATIC(mercury__goal_util__goal_calls_2_0),
		mercury__goal_util__cases_calls_2_0_i6,
		STATIC(mercury__goal_util__cases_calls_2_0));
	}
Define_label(mercury__goal_util__cases_calls_2_0_i6);
	update_prof_current_proc(LABEL(mercury__goal_util__cases_calls_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__goal_util__cases_calls_2_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__goal_util__cases_calls_2_0,
		STATIC(mercury__goal_util__cases_calls_2_0));
Define_label(mercury__goal_util__cases_calls_2_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__goal_util__cases_calls_2_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__goal_util_module28)
	init_entry(mercury__goal_util__goal_expr_calls_2_0);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1022);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i17);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i21);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i25);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1021);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i29);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i2);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1010);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1014);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1015);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1016);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1017);
	init_label(mercury__goal_util__goal_expr_calls_2_0_i1020);
BEGIN_CODE

/* code for predicate 'goal_expr_calls'/2 in mode 0 */
Define_static(mercury__goal_util__goal_expr_calls_2_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i1021);
	COMPUTED_GOTO((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)),
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1014) AND
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1010) AND
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1015) AND
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1016) AND
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1017) AND
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1022) AND
		LABEL(mercury__goal_util__goal_expr_calls_2_0_i1010));
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1022);
	incr_sp_push_msg(4, "goal_expr_calls");
	detstackvar(4) = (Integer) succip;
Define_label(mercury__goal_util__goal_expr_calls_2_0_i17);
	detstackvar(2) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(3), (Integer) r1, ((Integer) 4));
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__goal_util__goal_calls_2_0),
		mercury__goal_util__goal_expr_calls_2_0_i21,
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
	}
Define_label(mercury__goal_util__goal_expr_calls_2_0_i21);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_expr_calls_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i2);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__goal_util__goal_calls_2_0),
		mercury__goal_util__goal_expr_calls_2_0_i25,
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
	}
Define_label(mercury__goal_util__goal_expr_calls_2_0_i25);
	update_prof_current_proc(LABEL(mercury__goal_util__goal_expr_calls_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i2);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
		tailcall(STATIC(mercury__goal_util__goal_calls_2_0),
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
	}
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1021);
	incr_sp_push_msg(4, "goal_expr_calls");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i29);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__goal_util__goals_calls_2_0),
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
Define_label(mercury__goal_util__goal_expr_calls_2_0_i29);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury__goal_util__goal_expr_calls_2_0_i1020);
	r1 = TRUE;
	proceed();
Define_label(mercury__goal_util__goal_expr_calls_2_0_i2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1014);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 3));
	tailcall(STATIC(mercury__goal_util__cases_calls_2_0),
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1015);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__goal_util__goals_calls_2_0),
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1016);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__goal_util__goal_calls_2_0),
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
	}
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1017);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 2));
	{
		tailcall(STATIC(mercury__goal_util__goal_calls_2_0),
		STATIC(mercury__goal_util__goal_expr_calls_2_0));
	}
Define_label(mercury__goal_util__goal_expr_calls_2_0_i1020);
	r1 = FALSE;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__goal_util_bunch_0(void)
{
	mercury__goal_util_module0();
	mercury__goal_util_module1();
	mercury__goal_util_module2();
	mercury__goal_util_module3();
	mercury__goal_util_module4();
	mercury__goal_util_module5();
	mercury__goal_util_module6();
	mercury__goal_util_module7();
	mercury__goal_util_module8();
	mercury__goal_util_module9();
	mercury__goal_util_module10();
	mercury__goal_util_module11();
	mercury__goal_util_module12();
	mercury__goal_util_module13();
	mercury__goal_util_module14();
	mercury__goal_util_module15();
	mercury__goal_util_module16();
	mercury__goal_util_module17();
	mercury__goal_util_module18();
	mercury__goal_util_module19();
	mercury__goal_util_module20();
	mercury__goal_util_module21();
	mercury__goal_util_module22();
	mercury__goal_util_module23();
	mercury__goal_util_module24();
	mercury__goal_util_module25();
	mercury__goal_util_module26();
	mercury__goal_util_module27();
	mercury__goal_util_module28();
}

#endif

void mercury__goal_util__init(void); /* suppress gcc warning */
void mercury__goal_util__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__goal_util_bunch_0();
#endif
}
