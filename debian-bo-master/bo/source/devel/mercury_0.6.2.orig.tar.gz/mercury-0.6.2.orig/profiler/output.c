/*
** Automatically generated from `output.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__output__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__output__main_4_0);
Declare_label(mercury__output__main_4_0_i2);
Declare_label(mercury__output__main_4_0_i6);
Declare_label(mercury__output__main_4_0_i7);
Declare_label(mercury__output__main_4_0_i3);
Declare_label(mercury__output__main_4_0_i8);
Declare_label(mercury__output__main_4_0_i9);
Declare_label(mercury__output__main_4_0_i10);
Declare_label(mercury__output__main_4_0_i11);
Declare_label(mercury__output__main_4_0_i12);
Declare_label(mercury__output__main_4_0_i13);
Declare_label(mercury__output__main_4_0_i14);
Declare_label(mercury__output__main_4_0_i15);
Declare_label(mercury__output__main_4_0_i16);
Declare_label(mercury__output__main_4_0_i17);
Declare_label(mercury__output__main_4_0_i18);
Declare_label(mercury__output__main_4_0_i19);
Declare_label(mercury__output__main_4_0_i20);
Declare_label(mercury__output__main_4_0_i21);
Declare_label(mercury__output__main_4_0_i22);
Declare_label(mercury__output__main_4_0_i23);
Declare_label(mercury__output__main_4_0_i24);
Declare_label(mercury__output__main_4_0_i25);
Declare_label(mercury__output__main_4_0_i26);
Declare_label(mercury__output__main_4_0_i27);
Declare_label(mercury__output__main_4_0_i28);
Declare_static(mercury__output__call_graph_headers_2_0);
Declare_label(mercury__output__call_graph_headers_2_0_i2);
Declare_label(mercury__output__call_graph_headers_2_0_i3);
Declare_label(mercury__output__call_graph_headers_2_0_i4);
Declare_label(mercury__output__call_graph_headers_2_0_i5);
Declare_label(mercury__output__call_graph_headers_2_0_i6);
Declare_label(mercury__output__call_graph_headers_2_0_i7);
Declare_label(mercury__output__call_graph_headers_2_0_i8);
Declare_label(mercury__output__call_graph_headers_2_0_i9);
Declare_label(mercury__output__call_graph_headers_2_0_i10);
Declare_label(mercury__output__call_graph_headers_2_0_i11);
Declare_label(mercury__output__call_graph_headers_2_0_i12);
Declare_label(mercury__output__call_graph_headers_2_0_i13);
Declare_label(mercury__output__call_graph_headers_2_0_i14);
Declare_label(mercury__output__call_graph_headers_2_0_i15);
Declare_label(mercury__output__call_graph_headers_2_0_i16);
Declare_label(mercury__output__call_graph_headers_2_0_i17);
Declare_label(mercury__output__call_graph_headers_2_0_i18);
Declare_label(mercury__output__call_graph_headers_2_0_i19);
Declare_label(mercury__output__call_graph_headers_2_0_i20);
Declare_label(mercury__output__call_graph_headers_2_0_i21);
Declare_label(mercury__output__call_graph_headers_2_0_i22);
Declare_label(mercury__output__call_graph_headers_2_0_i23);
Declare_label(mercury__output__call_graph_headers_2_0_i24);
Declare_label(mercury__output__call_graph_headers_2_0_i25);
Declare_label(mercury__output__call_graph_headers_2_0_i26);
Declare_label(mercury__output__call_graph_headers_2_0_i27);
Declare_label(mercury__output__call_graph_headers_2_0_i28);
Declare_label(mercury__output__call_graph_headers_2_0_i29);
Declare_label(mercury__output__call_graph_headers_2_0_i30);
Declare_label(mercury__output__call_graph_headers_2_0_i31);
Declare_label(mercury__output__call_graph_headers_2_0_i32);
Declare_label(mercury__output__call_graph_headers_2_0_i33);
Declare_label(mercury__output__call_graph_headers_2_0_i34);
Declare_label(mercury__output__call_graph_headers_2_0_i35);
Declare_label(mercury__output__call_graph_headers_2_0_i36);
Declare_label(mercury__output__call_graph_headers_2_0_i37);
Declare_label(mercury__output__call_graph_headers_2_0_i38);
Declare_label(mercury__output__call_graph_headers_2_0_i39);
Declare_label(mercury__output__call_graph_headers_2_0_i40);
Declare_label(mercury__output__call_graph_headers_2_0_i41);
Declare_label(mercury__output__call_graph_headers_2_0_i42);
Declare_label(mercury__output__call_graph_headers_2_0_i43);
Declare_label(mercury__output__call_graph_headers_2_0_i44);
Declare_label(mercury__output__call_graph_headers_2_0_i45);
Declare_label(mercury__output__call_graph_headers_2_0_i46);
Declare_static(mercury__output__output_call_graph_5_0);
Declare_label(mercury__output__output_call_graph_5_0_i4);
Declare_label(mercury__output__output_call_graph_5_0_i5);
Declare_label(mercury__output__output_call_graph_5_0_i6);
Declare_label(mercury__output__output_call_graph_5_0_i7);
Declare_label(mercury__output__output_call_graph_5_0_i1002);
Declare_static(mercury__output__output_formatted_prof_node_5_0);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i4);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i3);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i2);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i5);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i6);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i7);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i8);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i9);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i15);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i10);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i16);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i21);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i22);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i17);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i23);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i24);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i25);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i26);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i30);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i27);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i31);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i32);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i33);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i34);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i35);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i36);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i37);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i38);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i39);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i40);
Declare_label(mercury__output__output_formatted_prof_node_5_0_i47);
Declare_static(mercury__output__output_formatted_cycle_parent_list_4_0);
Declare_label(mercury__output__output_formatted_cycle_parent_list_4_0_i4);
Declare_label(mercury__output__output_formatted_cycle_parent_list_4_0_i5);
Declare_label(mercury__output__output_formatted_cycle_parent_list_4_0_i6);
Declare_label(mercury__output__output_formatted_cycle_parent_list_4_0_i7);
Declare_label(mercury__output__output_formatted_cycle_parent_list_4_0_i1007);
Declare_static(mercury__output__output_formatted_parent_list_5_0);
Declare_label(mercury__output__output_formatted_parent_list_5_0_i4);
Declare_label(mercury__output__output_formatted_parent_list_5_0_i5);
Declare_label(mercury__output__output_formatted_parent_list_5_0_i6);
Declare_label(mercury__output__output_formatted_parent_list_5_0_i7);
Declare_label(mercury__output__output_formatted_parent_list_5_0_i1013);
Declare_static(mercury__output__output_formatted_cycle_child_list_4_0);
Declare_label(mercury__output__output_formatted_cycle_child_list_4_0_i4);
Declare_label(mercury__output__output_formatted_cycle_child_list_4_0_i5);
Declare_label(mercury__output__output_formatted_cycle_child_list_4_0_i6);
Declare_label(mercury__output__output_formatted_cycle_child_list_4_0_i7);
Declare_label(mercury__output__output_formatted_cycle_child_list_4_0_i1007);
Declare_static(mercury__output__output_formatted_child_list_4_0);
Declare_label(mercury__output__output_formatted_child_list_4_0_i4);
Declare_label(mercury__output__output_formatted_child_list_4_0_i5);
Declare_label(mercury__output__output_formatted_child_list_4_0_i6);
Declare_label(mercury__output__output_formatted_child_list_4_0_i7);
Declare_label(mercury__output__output_formatted_child_list_4_0_i1013);
Declare_static(mercury__output__flat_profile_6_0);
Declare_label(mercury__output__flat_profile_6_0_i4);
Declare_label(mercury__output__flat_profile_6_0_i5);
Declare_label(mercury__output__flat_profile_6_0_i8);
Declare_label(mercury__output__flat_profile_6_0_i7);
Declare_label(mercury__output__flat_profile_6_0_i6);
Declare_label(mercury__output__flat_profile_6_0_i9);
Declare_label(mercury__output__flat_profile_6_0_i10);
Declare_label(mercury__output__flat_profile_6_0_i11);
Declare_label(mercury__output__flat_profile_6_0_i12);
Declare_label(mercury__output__flat_profile_6_0_i13);
Declare_label(mercury__output__flat_profile_6_0_i14);
Declare_label(mercury__output__flat_profile_6_0_i15);
Declare_label(mercury__output__flat_profile_6_0_i16);
Declare_label(mercury__output__flat_profile_6_0_i17);
Declare_label(mercury__output__flat_profile_6_0_i1020);
Declare_static(mercury__output__output_alphabet_listing_2_3_0);
Declare_label(mercury__output__output_alphabet_listing_2_3_0_i4);
Declare_label(mercury__output__output_alphabet_listing_2_3_0_i5);
Declare_label(mercury__output__output_alphabet_listing_2_3_0_i1006);
Declare_static(mercury__output__output_alphabet_listing_3_3_0);
Declare_label(mercury__output__output_alphabet_listing_3_3_0_i4);
Declare_label(mercury__output__output_alphabet_listing_3_3_0_i5);
Declare_label(mercury__output__output_alphabet_listing_3_3_0_i1005);
Declare_static(mercury__output__construct_name_3_0);
Declare_label(mercury__output__construct_name_3_0_i5);
Declare_label(mercury__output__construct_name_3_0_i1004);

Word * mercury_data_output__common_0[] = {
	(Word *) string_const("] ", 2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_output__common_1[] = {
	(Word *) string_const("<spontaneous>\n", 14)
};

Word * mercury_data_output__common_2[] = {
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_output__common_1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_output__common_3[] = {
	(Word *) string_const(">", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

BEGIN_MODULE(mercury__output_module0)
	init_entry(mercury__output__main_4_0);
	init_label(mercury__output__main_4_0_i2);
	init_label(mercury__output__main_4_0_i6);
	init_label(mercury__output__main_4_0_i7);
	init_label(mercury__output__main_4_0_i3);
	init_label(mercury__output__main_4_0_i8);
	init_label(mercury__output__main_4_0_i9);
	init_label(mercury__output__main_4_0_i10);
	init_label(mercury__output__main_4_0_i11);
	init_label(mercury__output__main_4_0_i12);
	init_label(mercury__output__main_4_0_i13);
	init_label(mercury__output__main_4_0_i14);
	init_label(mercury__output__main_4_0_i15);
	init_label(mercury__output__main_4_0_i16);
	init_label(mercury__output__main_4_0_i17);
	init_label(mercury__output__main_4_0_i18);
	init_label(mercury__output__main_4_0_i19);
	init_label(mercury__output__main_4_0_i20);
	init_label(mercury__output__main_4_0_i21);
	init_label(mercury__output__main_4_0_i22);
	init_label(mercury__output__main_4_0_i23);
	init_label(mercury__output__main_4_0_i24);
	init_label(mercury__output__main_4_0_i25);
	init_label(mercury__output__main_4_0_i26);
	init_label(mercury__output__main_4_0_i27);
	init_label(mercury__output__main_4_0_i28);
BEGIN_CODE

/* code for predicate 'output__main'/4 in mode 0 */
Define_entry(mercury__output__main_4_0);
	incr_sp_push_msg(5, "output__main");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = ((Integer) 3);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__output__main_4_0_i2,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i2);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__output__main_4_0_i3);
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__output__call_graph_headers_2_0),
		mercury__output__main_4_0_i6,
		ENTRY(mercury__output__main_4_0));
Define_label(mercury__output__main_4_0_i6);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__output__output_call_graph_5_0),
		mercury__output__main_4_0_i7,
		ENTRY(mercury__output__main_4_0));
Define_label(mercury__output__main_4_0_i7);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = string_const("\nflat profile:\n\n", 16);
	GOTO_LABEL(mercury__output__main_4_0_i8);
Define_label(mercury__output__main_4_0_i3);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	r1 = string_const("\nflat profile:\n\n", 16);
Define_label(mercury__output__main_4_0_i8);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i9,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i9);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" %\tthe percentage of total running time of the program\n", 55);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i10,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i10);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("time\tused by this function.\n\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i11,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i11);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" cum\tthe total time of the current predicate and the ones\n", 58);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i12,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i12);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("time\tlisted above it.\n\n", 23);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i13,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i13);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" self\tthe number of seconds accounted for by this predicate alone.\n", 67);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i14,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i14);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("seconds\tThe listing is sorted on this row.\n\n", 44);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i15,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i15);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("calls\tthe number of times this predicate was called.\n\n", 54);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i16,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i16);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" self\tthe average number of milliseconds spent in\n", 50);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i17,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i17);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("ms/call\tthis predicate per call.\n\n", 34);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i18,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i18);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" total\tthe average number of milliseconds spent in this predicate and its\n", 74);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i19,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i19);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("ms/call\tdescendents per call.\n\n", 31);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i20,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i20);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("name\tthe name of the predicate followed by its index number.\n\n", 62);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i21,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i21);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("   %  cumulative    self              self", 42);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i22,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i22);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("    total\n", 10);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i23,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i23);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" time   seconds   seconds    calls  ms/call", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i24,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i24);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("  ms/call name\n", 15);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i25,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i25);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	static const Float mercury_float_const_0 = 0;
	r2 = (Word)(&mercury_float_const_0);
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__output__flat_profile_6_0),
		mercury__output__main_4_0_i26,
		ENTRY(mercury__output__main_4_0));
Define_label(mercury__output__main_4_0_i26);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\n\n\nalphabetic listing:\n\n", 24);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__main_4_0_i27,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i27);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__output__main_4_0_i28,
		ENTRY(mercury__output__main_4_0));
	}
Define_label(mercury__output__main_4_0_i28);
	update_prof_current_proc(LABEL(mercury__output__main_4_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__output__output_alphabet_listing_2_3_0),
		ENTRY(mercury__output__main_4_0));
END_MODULE

BEGIN_MODULE(mercury__output_module1)
	init_entry(mercury__output__call_graph_headers_2_0);
	init_label(mercury__output__call_graph_headers_2_0_i2);
	init_label(mercury__output__call_graph_headers_2_0_i3);
	init_label(mercury__output__call_graph_headers_2_0_i4);
	init_label(mercury__output__call_graph_headers_2_0_i5);
	init_label(mercury__output__call_graph_headers_2_0_i6);
	init_label(mercury__output__call_graph_headers_2_0_i7);
	init_label(mercury__output__call_graph_headers_2_0_i8);
	init_label(mercury__output__call_graph_headers_2_0_i9);
	init_label(mercury__output__call_graph_headers_2_0_i10);
	init_label(mercury__output__call_graph_headers_2_0_i11);
	init_label(mercury__output__call_graph_headers_2_0_i12);
	init_label(mercury__output__call_graph_headers_2_0_i13);
	init_label(mercury__output__call_graph_headers_2_0_i14);
	init_label(mercury__output__call_graph_headers_2_0_i15);
	init_label(mercury__output__call_graph_headers_2_0_i16);
	init_label(mercury__output__call_graph_headers_2_0_i17);
	init_label(mercury__output__call_graph_headers_2_0_i18);
	init_label(mercury__output__call_graph_headers_2_0_i19);
	init_label(mercury__output__call_graph_headers_2_0_i20);
	init_label(mercury__output__call_graph_headers_2_0_i21);
	init_label(mercury__output__call_graph_headers_2_0_i22);
	init_label(mercury__output__call_graph_headers_2_0_i23);
	init_label(mercury__output__call_graph_headers_2_0_i24);
	init_label(mercury__output__call_graph_headers_2_0_i25);
	init_label(mercury__output__call_graph_headers_2_0_i26);
	init_label(mercury__output__call_graph_headers_2_0_i27);
	init_label(mercury__output__call_graph_headers_2_0_i28);
	init_label(mercury__output__call_graph_headers_2_0_i29);
	init_label(mercury__output__call_graph_headers_2_0_i30);
	init_label(mercury__output__call_graph_headers_2_0_i31);
	init_label(mercury__output__call_graph_headers_2_0_i32);
	init_label(mercury__output__call_graph_headers_2_0_i33);
	init_label(mercury__output__call_graph_headers_2_0_i34);
	init_label(mercury__output__call_graph_headers_2_0_i35);
	init_label(mercury__output__call_graph_headers_2_0_i36);
	init_label(mercury__output__call_graph_headers_2_0_i37);
	init_label(mercury__output__call_graph_headers_2_0_i38);
	init_label(mercury__output__call_graph_headers_2_0_i39);
	init_label(mercury__output__call_graph_headers_2_0_i40);
	init_label(mercury__output__call_graph_headers_2_0_i41);
	init_label(mercury__output__call_graph_headers_2_0_i42);
	init_label(mercury__output__call_graph_headers_2_0_i43);
	init_label(mercury__output__call_graph_headers_2_0_i44);
	init_label(mercury__output__call_graph_headers_2_0_i45);
	init_label(mercury__output__call_graph_headers_2_0_i46);
BEGIN_CODE

/* code for predicate 'output__call_graph_headers'/2 in mode 0 */
Define_static(mercury__output__call_graph_headers_2_0);
	r2 = (Integer) r1;
	r1 = string_const("call graph profile:\n", 20);
	incr_sp_push_msg(1, "output__call_graph_headers");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i2,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i2);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tSorted on the %time field.\n\n", 29);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i3,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i3);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tpredicate entries:\n\n", 21);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i4,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i4);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("index\tthe index number of the predicate in the call graph\n", 58);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i5,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i5);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tlisting.\n\n", 11);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i6,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i6);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("%time\tthe percentage of the total running time of\n", 50);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i7,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i7);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tthe program spent in this predicate and its\n", 45);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i8,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i8);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tdescendents.\n\n", 15);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i9,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i9);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("self\tthe number of seconds spent actually executing\n", 52);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i10,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i10);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tthe predicate's own code.\n\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i11,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i11);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("descendents\n", 12);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i12,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i12);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tthe number of seconds spent executing the\n", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i13,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i13);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tdescendents of the current predicate.\n\n", 40);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i14,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i14);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("called\tthe number of times the current predicate is\n", 52);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i15,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i15);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tcalled (not counting self recursive calls).\n\n", 46);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i16,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i16);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("self\tthe number of self recursive calls.\n\n", 42);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i17,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i17);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("name\tthe name of the current predicate.\n\n", 41);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i18,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i18);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("index\ta index number to locate the function easily.\n\n\n\n", 55);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i19,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i19);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tparent listings:\n\n", 19);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i20,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i20);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("self*\tthe number of seconds of the current predicates self\n", 59);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i21,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i21);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\ttime due to calls from this parent.\n\n", 38);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i22,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i22);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("descendents*\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i23,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i23);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tthe number of seconds of the current predicate's descendent\n", 61);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i24,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i24);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\ttime which is due to calls from this parent.\n\n", 47);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i25,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i25);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("called*\tthe number of times the current predicate is called\n", 60);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i26,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i26);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tby this parent.\n\n", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i27,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i27);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("total\tthe number of times this predicate is called by its parents.\n\n", 68);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i28,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i28);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("parents\tthe name of this parent.\n\n", 34);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i29,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i29);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("index\tthe index number of the parent predicate\n\n\n\n", 50);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i30,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i30);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("children listings:\n\n", 20);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i31,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i31);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("self*\tthe number of seconds of this child's self time which is due\n", 67);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i32,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i32);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tto being called by the current predicate.\n\n", 44);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i33,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i33);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("descendent*\n", 12);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i34,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i34);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tthe number of seconds of this child's desdendent time which is due\n", 68);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i35,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i35);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tto the current predicate.\n\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i36,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i36);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("called*\tthe number of times this child is called by the current\n", 64);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i37,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i37);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\tpredicate.\n\n", 13);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i38,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i38);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("total*\tthe number of times this child is called by all predicates.\n\n", 68);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i39,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i39);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("children\tthe name of this child.\n\n", 34);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i40,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i40);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("index\tthe index number of the child.\n\n", 38);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i41,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i41);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("                                  called/total", 46);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i42,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i42);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("       parents\n", 15);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i43,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i43);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("index  %time    self descendents  called+self", 45);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i44,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i44);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("    name           index\n", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i45,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i45);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("                                  called/total", 46);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__call_graph_headers_2_0_i46,
		STATIC(mercury__output__call_graph_headers_2_0));
	}
Define_label(mercury__output__call_graph_headers_2_0_i46);
	update_prof_current_proc(LABEL(mercury__output__call_graph_headers_2_0));
	r2 = (Integer) r1;
	r1 = string_const("       children\n\n", 17);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__output__call_graph_headers_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__output_module2)
	init_entry(mercury__output__output_call_graph_5_0);
	init_label(mercury__output__output_call_graph_5_0_i4);
	init_label(mercury__output__output_call_graph_5_0_i5);
	init_label(mercury__output__output_call_graph_5_0_i6);
	init_label(mercury__output__output_call_graph_5_0_i7);
	init_label(mercury__output__output_call_graph_5_0_i1002);
BEGIN_CODE

/* code for predicate 'output_call_graph'/5 in mode 0 */
Define_static(mercury__output__output_call_graph_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_call_graph_5_0_i1002);
	incr_sp_push_msg(6, "output_call_graph");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r4;
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_output_prof_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0;
	}
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__output_call_graph_5_0_i4,
		STATIC(mercury__output__output_call_graph_5_0));
	}
Define_label(mercury__output__output_call_graph_5_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_call_graph_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	r4 = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__output_call_graph_5_0_i5,
		STATIC(mercury__output__output_call_graph_5_0));
	}
Define_label(mercury__output__output_call_graph_5_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_call_graph_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__output__output_formatted_prof_node_5_0),
		mercury__output__output_call_graph_5_0_i6,
		STATIC(mercury__output__output_call_graph_5_0));
Define_label(mercury__output__output_call_graph_5_0_i6);
	update_prof_current_proc(LABEL(mercury__output__output_call_graph_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n-----------------------------------------------\n\n", 50);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_call_graph_5_0_i7,
		STATIC(mercury__output__output_call_graph_5_0));
	}
Define_label(mercury__output__output_call_graph_5_0_i7);
	update_prof_current_proc(LABEL(mercury__output__output_call_graph_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__output__output_call_graph_5_0,
		STATIC(mercury__output__output_call_graph_5_0));
Define_label(mercury__output__output_call_graph_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module3)
	init_entry(mercury__output__output_formatted_prof_node_5_0);
	init_label(mercury__output__output_formatted_prof_node_5_0_i4);
	init_label(mercury__output__output_formatted_prof_node_5_0_i3);
	init_label(mercury__output__output_formatted_prof_node_5_0_i2);
	init_label(mercury__output__output_formatted_prof_node_5_0_i5);
	init_label(mercury__output__output_formatted_prof_node_5_0_i6);
	init_label(mercury__output__output_formatted_prof_node_5_0_i7);
	init_label(mercury__output__output_formatted_prof_node_5_0_i8);
	init_label(mercury__output__output_formatted_prof_node_5_0_i9);
	init_label(mercury__output__output_formatted_prof_node_5_0_i15);
	init_label(mercury__output__output_formatted_prof_node_5_0_i10);
	init_label(mercury__output__output_formatted_prof_node_5_0_i16);
	init_label(mercury__output__output_formatted_prof_node_5_0_i21);
	init_label(mercury__output__output_formatted_prof_node_5_0_i22);
	init_label(mercury__output__output_formatted_prof_node_5_0_i17);
	init_label(mercury__output__output_formatted_prof_node_5_0_i23);
	init_label(mercury__output__output_formatted_prof_node_5_0_i24);
	init_label(mercury__output__output_formatted_prof_node_5_0_i25);
	init_label(mercury__output__output_formatted_prof_node_5_0_i26);
	init_label(mercury__output__output_formatted_prof_node_5_0_i30);
	init_label(mercury__output__output_formatted_prof_node_5_0_i27);
	init_label(mercury__output__output_formatted_prof_node_5_0_i31);
	init_label(mercury__output__output_formatted_prof_node_5_0_i32);
	init_label(mercury__output__output_formatted_prof_node_5_0_i33);
	init_label(mercury__output__output_formatted_prof_node_5_0_i34);
	init_label(mercury__output__output_formatted_prof_node_5_0_i35);
	init_label(mercury__output__output_formatted_prof_node_5_0_i36);
	init_label(mercury__output__output_formatted_prof_node_5_0_i37);
	init_label(mercury__output__output_formatted_prof_node_5_0_i38);
	init_label(mercury__output__output_formatted_prof_node_5_0_i39);
	init_label(mercury__output__output_formatted_prof_node_5_0_i40);
	init_label(mercury__output__output_formatted_prof_node_5_0_i47);
BEGIN_CODE

/* code for predicate 'output_formatted_prof_node'/5 in mode 0 */
Define_static(mercury__output__output_formatted_prof_node_5_0);
	incr_sp_push_msg(15, "output_formatted_prof_node");
	detstackvar(15) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i3);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	r1 = string_const("output_formatted_prof_node: Cannot have output_cycle_prof\n", 58);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__output__output_formatted_prof_node_5_0_i4,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r10 = (Integer) detstackvar(8);
	r11 = (Integer) detstackvar(9);
	r12 = (Integer) detstackvar(10);
	r13 = (Integer) detstackvar(11);
	r14 = (Integer) detstackvar(12);
	GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i2);
Define_label(mercury__output__output_formatted_prof_node_5_0_i3);
	r5 = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r7 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r8 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	r9 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	r10 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	r11 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	r12 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	r13 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	r14 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
Define_label(mercury__output__output_formatted_prof_node_5_0_i2);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	detstackvar(8) = (Integer) r10;
	detstackvar(9) = (Integer) r11;
	detstackvar(10) = (Integer) r12;
	detstackvar(11) = (Integer) r13;
	detstackvar(12) = (Integer) r14;
	call_localret(STATIC(mercury__output__construct_name_3_0),
		mercury__output__output_formatted_prof_node_5_0_i5,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
Define_label(mercury__output__output_formatted_prof_node_5_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__output__output_formatted_prof_node_5_0_i6,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i6);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("[", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_output__common_0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__output__output_formatted_prof_node_5_0_i7,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i7);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	tag_incr_hp(detstackvar(14), mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) detstackvar(14), ((Integer) 0)) = (Integer) detstackvar(8);
	r1 = string_const("%40d             %s [%d]\n", 25);
	r4 = (Integer) r2;
	r5 = (Integer) detstackvar(14);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(13);
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_prof_node_5_0_i8,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i8);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("%-6s %5.1f %7.2f %11.2f %7d", 27);
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r4;
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_prof_node_5_0_i9,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i9);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) detstackvar(14);
	r3 = (Integer) r2;
	if (((Integer) detstackvar(8) == ((Integer) 0)))
		GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i10);
	detstackvar(5) = (Integer) r1;
	detstackvar(14) = (Integer) r3;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i15,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i15);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r12 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(1);
	r10 = (Integer) detstackvar(4);
	r11 = (Integer) detstackvar(5);
	r13 = (Integer) detstackvar(14);
	GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i16);
Define_label(mercury__output__output_formatted_prof_node_5_0_i10);
	r11 = (Integer) r1;
	r13 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(9);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(11);
	r7 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(1);
	r10 = (Integer) detstackvar(4);
	r12 = (Integer) detstackvar(3);
Define_label(mercury__output__output_formatted_prof_node_5_0_i16);
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i17);
	if (((Integer) r4 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i17);
	detstackvar(2) = (Integer) r1;
	detstackvar(8) = (Integer) r3;
	detstackvar(10) = (Integer) r5;
	detstackvar(12) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	detstackvar(1) = (Integer) r9;
	detstackvar(4) = (Integer) r10;
	detstackvar(5) = (Integer) r11;
	detstackvar(6) = (Integer) r12;
	detstackvar(14) = (Integer) r13;
	r1 = string_const("%67s", 4);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_output__common_2);
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_prof_node_5_0_i21,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i21);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i22,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i22);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(1);
	r9 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(14);
	GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i25);
Define_label(mercury__output__output_formatted_prof_node_5_0_i17);
	detstackvar(7) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	detstackvar(8) = (Integer) r3;
	r1 = (Integer) r6;
	r3 = (Integer) r12;
	detstackvar(1) = (Integer) r9;
	detstackvar(4) = (Integer) r10;
	detstackvar(5) = (Integer) r11;
	detstackvar(9) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	detstackvar(12) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	detstackvar(14) = (Integer) r13;
	call_localret(STATIC(mercury__output__output_formatted_cycle_parent_list_4_0),
		mercury__output__output_formatted_prof_node_5_0_i23,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
Define_label(mercury__output__output_formatted_prof_node_5_0_i23);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__output__output_formatted_parent_list_5_0),
		mercury__output__output_formatted_prof_node_5_0_i24,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
Define_label(mercury__output__output_formatted_prof_node_5_0_i24);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(1);
	r9 = (Integer) detstackvar(4);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r10 = (Integer) detstackvar(14);
Define_label(mercury__output__output_formatted_prof_node_5_0_i25);
	detstackvar(2) = (Integer) r3;
	detstackvar(8) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	detstackvar(12) = (Integer) r6;
	detstackvar(13) = (Integer) r7;
	detstackvar(1) = (Integer) r8;
	detstackvar(4) = (Integer) r9;
	detstackvar(14) = (Integer) r10;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i26,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i26);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	if (((Integer) detstackvar(8) != ((Integer) 0)))
		GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i27);
	r2 = (Integer) r1;
	r1 = string_const("         ", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i30,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i30);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(12);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i34);
Define_label(mercury__output__output_formatted_prof_node_5_0_i27);
	r2 = (Integer) r1;
	r1 = string_const("+", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i31,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i31);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = string_const("%-7d", 4);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(14);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_prof_node_5_0_i32,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i32);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i33,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i33);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(8);
	r5 = (Integer) detstackvar(10);
	r6 = (Integer) detstackvar(12);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(13);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(4);
Define_label(mercury__output__output_formatted_prof_node_5_0_i34);
	detstackvar(2) = (Integer) r3;
	detstackvar(8) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	detstackvar(12) = (Integer) r6;
	detstackvar(1) = (Integer) r7;
	detstackvar(4) = (Integer) r8;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i35,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i35);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) r1;
	r1 = string_const(" ", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i36,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i36);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i37,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i37);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r2 = (Integer) r1;
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_prof_node_5_0_i38,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i38);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__output__output_formatted_child_list_4_0),
		mercury__output__output_formatted_prof_node_5_0_i39,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
Define_label(mercury__output__output_formatted_prof_node_5_0_i39);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__output__output_formatted_cycle_child_list_4_0),
		mercury__output__output_formatted_prof_node_5_0_i40,
		STATIC(mercury__output__output_formatted_prof_node_5_0));
Define_label(mercury__output__output_formatted_prof_node_5_0_i40);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_prof_node_5_0));
	if (((Integer) detstackvar(8) == ((Integer) 0)))
		GOTO_LABEL(mercury__output__output_formatted_prof_node_5_0_i47);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__output__output_formatted_prof_node_5_0));
	}
Define_label(mercury__output__output_formatted_prof_node_5_0_i47);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module4)
	init_entry(mercury__output__output_formatted_cycle_parent_list_4_0);
	init_label(mercury__output__output_formatted_cycle_parent_list_4_0_i4);
	init_label(mercury__output__output_formatted_cycle_parent_list_4_0_i5);
	init_label(mercury__output__output_formatted_cycle_parent_list_4_0_i6);
	init_label(mercury__output__output_formatted_cycle_parent_list_4_0_i7);
	init_label(mercury__output__output_formatted_cycle_parent_list_4_0_i1007);
BEGIN_CODE

/* code for predicate 'output_formatted_cycle_parent_list'/4 in mode 0 */
Define_static(mercury__output__output_formatted_cycle_parent_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_formatted_cycle_parent_list_4_0_i1007);
	incr_sp_push_msg(6, "output_formatted_cycle_parent_list");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__output__construct_name_3_0),
		mercury__output__output_formatted_cycle_parent_list_4_0_i4,
		STATIC(mercury__output__output_formatted_cycle_parent_list_4_0));
	}
Define_label(mercury__output__output_formatted_cycle_parent_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_parent_list_4_0));
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(4) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__output_formatted_cycle_parent_list_4_0_i5,
		STATIC(mercury__output__output_formatted_cycle_parent_list_4_0));
	}
	}
Define_label(mercury__output__output_formatted_cycle_parent_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_parent_list_4_0));
	r3 = (Integer) r1;
	r1 = string_const("%40d             %s [%d]\n", 25);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_cycle_parent_list_4_0_i6,
		STATIC(mercury__output__output_formatted_cycle_parent_list_4_0));
	}
	}
Define_label(mercury__output__output_formatted_cycle_parent_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_parent_list_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_cycle_parent_list_4_0_i7,
		STATIC(mercury__output__output_formatted_cycle_parent_list_4_0));
	}
Define_label(mercury__output__output_formatted_cycle_parent_list_4_0_i7);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_parent_list_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__output__output_formatted_cycle_parent_list_4_0,
		STATIC(mercury__output__output_formatted_cycle_parent_list_4_0));
Define_label(mercury__output__output_formatted_cycle_parent_list_4_0_i1007);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module5)
	init_entry(mercury__output__output_formatted_parent_list_5_0);
	init_label(mercury__output__output_formatted_parent_list_5_0_i4);
	init_label(mercury__output__output_formatted_parent_list_5_0_i5);
	init_label(mercury__output__output_formatted_parent_list_5_0_i6);
	init_label(mercury__output__output_formatted_parent_list_5_0_i7);
	init_label(mercury__output__output_formatted_parent_list_5_0_i1013);
BEGIN_CODE

/* code for predicate 'output_formatted_parent_list'/5 in mode 0 */
Define_static(mercury__output__output_formatted_parent_list_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_formatted_parent_list_5_0_i1013);
	incr_sp_push_msg(10, "output_formatted_parent_list");
	detstackvar(10) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	call_localret(STATIC(mercury__output__construct_name_3_0),
		mercury__output__output_formatted_parent_list_5_0_i4,
		STATIC(mercury__output__output_formatted_parent_list_5_0));
	}
Define_label(mercury__output__output_formatted_parent_list_5_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_parent_list_5_0));
	r2 = (Integer) detstackvar(5);
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	detstackvar(5) = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	detstackvar(6) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	detstackvar(7) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(2);
	detstackvar(8) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	r4 = (Integer) r2;
	detstackvar(9) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__output_formatted_parent_list_5_0_i5,
		STATIC(mercury__output__output_formatted_parent_list_5_0));
	}
	}
Define_label(mercury__output__output_formatted_parent_list_5_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_parent_list_5_0));
	r3 = (Integer) r1;
	r1 = string_const("%20.2f %11.2f %7d/%-11d %s [%d]\n", 32);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(9);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_parent_list_5_0_i6,
		STATIC(mercury__output__output_formatted_parent_list_5_0));
	}
	}
Define_label(mercury__output__output_formatted_parent_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_parent_list_5_0));
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_parent_list_5_0_i7,
		STATIC(mercury__output__output_formatted_parent_list_5_0));
	}
Define_label(mercury__output__output_formatted_parent_list_5_0_i7);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_parent_list_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__output__output_formatted_parent_list_5_0,
		STATIC(mercury__output__output_formatted_parent_list_5_0));
Define_label(mercury__output__output_formatted_parent_list_5_0_i1013);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module6)
	init_entry(mercury__output__output_formatted_cycle_child_list_4_0);
	init_label(mercury__output__output_formatted_cycle_child_list_4_0_i4);
	init_label(mercury__output__output_formatted_cycle_child_list_4_0_i5);
	init_label(mercury__output__output_formatted_cycle_child_list_4_0_i6);
	init_label(mercury__output__output_formatted_cycle_child_list_4_0_i7);
	init_label(mercury__output__output_formatted_cycle_child_list_4_0_i1007);
BEGIN_CODE

/* code for predicate 'output_formatted_cycle_child_list'/4 in mode 0 */
Define_static(mercury__output__output_formatted_cycle_child_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_formatted_cycle_child_list_4_0_i1007);
	incr_sp_push_msg(6, "output_formatted_cycle_child_list");
	detstackvar(6) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__output__construct_name_3_0),
		mercury__output__output_formatted_cycle_child_list_4_0_i4,
		STATIC(mercury__output__output_formatted_cycle_child_list_4_0));
	}
Define_label(mercury__output__output_formatted_cycle_child_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_child_list_4_0));
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(4) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	r4 = (Integer) r2;
	detstackvar(5) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__output_formatted_cycle_child_list_4_0_i5,
		STATIC(mercury__output__output_formatted_cycle_child_list_4_0));
	}
	}
Define_label(mercury__output__output_formatted_cycle_child_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_child_list_4_0));
	r3 = (Integer) r1;
	r1 = string_const("%40d             %s [%d]\n", 25);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_cycle_child_list_4_0_i6,
		STATIC(mercury__output__output_formatted_cycle_child_list_4_0));
	}
	}
Define_label(mercury__output__output_formatted_cycle_child_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_child_list_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_cycle_child_list_4_0_i7,
		STATIC(mercury__output__output_formatted_cycle_child_list_4_0));
	}
Define_label(mercury__output__output_formatted_cycle_child_list_4_0_i7);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_cycle_child_list_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__output__output_formatted_cycle_child_list_4_0,
		STATIC(mercury__output__output_formatted_cycle_child_list_4_0));
Define_label(mercury__output__output_formatted_cycle_child_list_4_0_i1007);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module7)
	init_entry(mercury__output__output_formatted_child_list_4_0);
	init_label(mercury__output__output_formatted_child_list_4_0_i4);
	init_label(mercury__output__output_formatted_child_list_4_0_i5);
	init_label(mercury__output__output_formatted_child_list_4_0_i6);
	init_label(mercury__output__output_formatted_child_list_4_0_i7);
	init_label(mercury__output__output_formatted_child_list_4_0_i1013);
BEGIN_CODE

/* code for predicate 'output_formatted_child_list'/4 in mode 0 */
Define_static(mercury__output__output_formatted_child_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_formatted_child_list_4_0_i1013);
	incr_sp_push_msg(9, "output_formatted_child_list");
	detstackvar(9) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(4) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	call_localret(STATIC(mercury__output__construct_name_3_0),
		mercury__output__output_formatted_child_list_4_0_i4,
		STATIC(mercury__output__output_formatted_child_list_4_0));
	}
Define_label(mercury__output__output_formatted_child_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_child_list_4_0));
	r2 = (Integer) detstackvar(4);
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(5);
	detstackvar(4) = (Integer) r3;
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(6);
	detstackvar(5) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(7);
	detstackvar(6) = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(8);
	detstackvar(7) = (Integer) r3;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	r4 = (Integer) r2;
	detstackvar(8) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__output_formatted_child_list_4_0_i5,
		STATIC(mercury__output__output_formatted_child_list_4_0));
	}
	}
Define_label(mercury__output__output_formatted_child_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_child_list_4_0));
	r3 = (Integer) r1;
	r1 = string_const("%20.2f %11.2f %7d/%-11d %s [%d]\n", 32);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(5);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(6);
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) detstackvar(7);
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) detstackvar(8);
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_formatted_child_list_4_0_i6,
		STATIC(mercury__output__output_formatted_child_list_4_0));
	}
	}
Define_label(mercury__output__output_formatted_child_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_child_list_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_formatted_child_list_4_0_i7,
		STATIC(mercury__output__output_formatted_child_list_4_0));
	}
Define_label(mercury__output__output_formatted_child_list_4_0_i7);
	update_prof_current_proc(LABEL(mercury__output__output_formatted_child_list_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	localtailcall(mercury__output__output_formatted_child_list_4_0,
		STATIC(mercury__output__output_formatted_child_list_4_0));
Define_label(mercury__output__output_formatted_child_list_4_0_i1013);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module8)
	init_entry(mercury__output__flat_profile_6_0);
	init_label(mercury__output__flat_profile_6_0_i4);
	init_label(mercury__output__flat_profile_6_0_i5);
	init_label(mercury__output__flat_profile_6_0_i8);
	init_label(mercury__output__flat_profile_6_0_i7);
	init_label(mercury__output__flat_profile_6_0_i6);
	init_label(mercury__output__flat_profile_6_0_i9);
	init_label(mercury__output__flat_profile_6_0_i10);
	init_label(mercury__output__flat_profile_6_0_i11);
	init_label(mercury__output__flat_profile_6_0_i12);
	init_label(mercury__output__flat_profile_6_0_i13);
	init_label(mercury__output__flat_profile_6_0_i14);
	init_label(mercury__output__flat_profile_6_0_i15);
	init_label(mercury__output__flat_profile_6_0_i16);
	init_label(mercury__output__flat_profile_6_0_i17);
	init_label(mercury__output__flat_profile_6_0_i1020);
BEGIN_CODE

/* code for predicate 'output__flat_profile'/6 in mode 0 */
Define_static(mercury__output__flat_profile_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__flat_profile_6_0_i1020);
	incr_sp_push_msg(15, "output__flat_profile");
	detstackvar(15) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_output_prof_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0;
	}
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__flat_profile_6_0_i4,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i4);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	r4 = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__output__flat_profile_6_0_i5,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i5);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	if ((tag((Integer) detstackvar(5)) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__output__flat_profile_6_0_i7);
	detstackvar(5) = (Integer) r1;
	r1 = string_const("output_flat_profile: Cannot have output_cycle_prof\n", 51);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__output__flat_profile_6_0_i8,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i8);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(7);
	r9 = (Integer) detstackvar(8);
	r10 = (Integer) detstackvar(9);
	r11 = (Integer) detstackvar(10);
	r12 = (Integer) detstackvar(11);
	r13 = (Integer) detstackvar(12);
	r1 = (Integer) detstackvar(13);
	GOTO_LABEL(mercury__output__flat_profile_6_0_i6);
Define_label(mercury__output__flat_profile_6_0_i7);
	r7 = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 7));
	r13 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 6));
	r12 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	r11 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	r10 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	r9 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r8 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	}
Define_label(mercury__output__flat_profile_6_0_i6);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(5) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r9;
	detstackvar(9) = (Integer) r10;
	detstackvar(10) = (Integer) r11;
	detstackvar(11) = (Integer) r12;
	detstackvar(12) = (Integer) r13;
	detstackvar(13) = (Integer) r1;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__output__flat_profile_6_0_i9,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i9);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__output__flat_profile_6_0_i10,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i10);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	detstackvar(12) = ((Integer) detstackvar(13) + (Integer) detstackvar(12));
	r2 = float_to_word(word_to_float((Integer) r1) + word_to_float((Integer) detstackvar(14)));
	r1 = (Integer) detstackvar(10);
	detstackvar(13) = float_to_word(word_to_float((Integer) r1) + word_to_float((Integer) detstackvar(1)));
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__generate_output__checked_float_divide_3_0);
	call_localret(ENTRY(mercury__generate_output__checked_float_divide_3_0),
		mercury__output__flat_profile_6_0_i11,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i11);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__generate_output__checked_float_divide_3_0);
	call_localret(ENTRY(mercury__generate_output__checked_float_divide_3_0),
		mercury__output__flat_profile_6_0_i12,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i12);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	{
	static const Float mercury_float_const_1000 = 1000;
	detstackvar(1) = float_to_word(((Float) 1000.00000000000) * word_to_float((Integer) detstackvar(1)));
	}
	r3 = (Integer) detstackvar(7);
	{
	static const Float mercury_float_const_1000 = 1000;
	detstackvar(7) = float_to_word(((Float) 1000.00000000000) * word_to_float((Integer) r1));
	}
	r1 = (Integer) r3;
	r2 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__output__construct_name_3_0),
		mercury__output__flat_profile_6_0_i13,
		STATIC(mercury__output__flat_profile_6_0));
Define_label(mercury__output__flat_profile_6_0_i13);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__output__flat_profile_6_0_i14,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i14);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("[", 1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_output__common_0);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__output__flat_profile_6_0_i15,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i15);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r3 = (Integer) r1;
	r1 = string_const("%5.1f %10.2f %8.2f %8d %8.2f %8.2f %s %s\n", 41);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(9);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(13);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(10);
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r6, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(12);
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r7, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r8, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(7);
	field(mktag(1), (Integer) r8, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r9, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r9, ((Integer) 0)) = (Integer) tempr1;
	tag_incr_hp(r10, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r10, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	field(mktag(1), (Integer) r6, ((Integer) 1)) = (Integer) r7;
	field(mktag(1), (Integer) r7, ((Integer) 1)) = (Integer) r8;
	field(mktag(1), (Integer) r8, ((Integer) 1)) = (Integer) r9;
	field(mktag(1), (Integer) r9, ((Integer) 1)) = (Integer) r10;
	field(mktag(1), (Integer) r10, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__flat_profile_6_0_i16,
		STATIC(mercury__output__flat_profile_6_0));
	}
	}
Define_label(mercury__output__flat_profile_6_0_i16);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__flat_profile_6_0_i17,
		STATIC(mercury__output__flat_profile_6_0));
	}
Define_label(mercury__output__flat_profile_6_0_i17);
	update_prof_current_proc(LABEL(mercury__output__flat_profile_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(13);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(15);
	decr_sp_pop_msg(15);
	localtailcall(mercury__output__flat_profile_6_0,
		STATIC(mercury__output__flat_profile_6_0));
Define_label(mercury__output__flat_profile_6_0_i1020);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module9)
	init_entry(mercury__output__output_alphabet_listing_2_3_0);
	init_label(mercury__output__output_alphabet_listing_2_3_0_i4);
	init_label(mercury__output__output_alphabet_listing_2_3_0_i5);
	init_label(mercury__output__output_alphabet_listing_2_3_0_i1006);
BEGIN_CODE

/* code for predicate 'output_alphabet_listing_2'/3 in mode 0 */
Define_static(mercury__output__output_alphabet_listing_2_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_alphabet_listing_2_3_0_i1006);
	incr_sp_push_msg(3, "output_alphabet_listing_2");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = string_const("[%d]\t%-30s", 10);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_alphabet_listing_2_3_0_i4,
		STATIC(mercury__output__output_alphabet_listing_2_3_0));
	}
	}
Define_label(mercury__output__output_alphabet_listing_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_alphabet_listing_2_3_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_alphabet_listing_2_3_0_i5,
		STATIC(mercury__output__output_alphabet_listing_2_3_0));
	}
Define_label(mercury__output__output_alphabet_listing_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_alphabet_listing_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__output__output_alphabet_listing_3_3_0),
		STATIC(mercury__output__output_alphabet_listing_2_3_0));
Define_label(mercury__output__output_alphabet_listing_2_3_0_i1006);
	r1 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__output__output_alphabet_listing_2_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__output_module10)
	init_entry(mercury__output__output_alphabet_listing_3_3_0);
	init_label(mercury__output__output_alphabet_listing_3_3_0_i4);
	init_label(mercury__output__output_alphabet_listing_3_3_0_i5);
	init_label(mercury__output__output_alphabet_listing_3_3_0_i1005);
BEGIN_CODE

/* code for predicate 'output_alphabet_listing_3'/3 in mode 0 */
Define_static(mercury__output__output_alphabet_listing_3_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__output__output_alphabet_listing_3_3_0_i1005);
	incr_sp_push_msg(3, "output_alphabet_listing_3");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	r1 = string_const("[%d]\t%-30s\n", 11);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1, tempr2;
	tag_incr_hp(tempr2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr2;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	tag_incr_hp(tempr1, mktag(2), ((Integer) 1));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(2), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) field(mktag(1), (Integer) r3, ((Integer) 0)), ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__output__output_alphabet_listing_3_3_0_i4,
		STATIC(mercury__output__output_alphabet_listing_3_3_0));
	}
	}
Define_label(mercury__output__output_alphabet_listing_3_3_0_i4);
	update_prof_current_proc(LABEL(mercury__output__output_alphabet_listing_3_3_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__output__output_alphabet_listing_3_3_0_i5,
		STATIC(mercury__output__output_alphabet_listing_3_3_0));
	}
Define_label(mercury__output__output_alphabet_listing_3_3_0_i5);
	update_prof_current_proc(LABEL(mercury__output__output_alphabet_listing_3_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__output__output_alphabet_listing_2_3_0),
		STATIC(mercury__output__output_alphabet_listing_3_3_0));
Define_label(mercury__output__output_alphabet_listing_3_3_0_i1005);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_module11)
	init_entry(mercury__output__construct_name_3_0);
	init_label(mercury__output__construct_name_3_0_i5);
	init_label(mercury__output__construct_name_3_0_i1004);
BEGIN_CODE

/* code for predicate 'output__construct_name'/3 in mode 0 */
Define_static(mercury__output__construct_name_3_0);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__output__construct_name_3_0_i1004);
	incr_sp_push_msg(2, "output__construct_name");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__output__construct_name_3_0_i5,
		STATIC(mercury__output__construct_name_3_0));
	}
Define_label(mercury__output__construct_name_3_0_i5);
	update_prof_current_proc(LABEL(mercury__output__construct_name_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = string_const("  <cycle ", 9);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_output__common_3);
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_list_2_0);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__output__construct_name_3_0));
	}
	}
Define_label(mercury__output__construct_name_3_0_i1004);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__output_bunch_0(void)
{
	mercury__output_module0();
	mercury__output_module1();
	mercury__output_module2();
	mercury__output_module3();
	mercury__output_module4();
	mercury__output_module5();
	mercury__output_module6();
	mercury__output_module7();
	mercury__output_module8();
	mercury__output_module9();
	mercury__output_module10();
	mercury__output_module11();
}

#endif

void mercury__output__init(void); /* suppress gcc warning */
void mercury__output__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__output_bunch_0();
#endif
}
