/*
** Automatically generated from `prof_info.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__prof_info__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___prof_info_pred_info_0__ua10000_2_0);
Declare_static(mercury____Index___prof_info_prof_0__ua10000_2_0);
Define_extern_entry(mercury__prof_info__get_prof_node_4_0);
Declare_label(mercury__prof_info__get_prof_node_4_0_i2);
Define_extern_entry(mercury__prof_info__update_prof_node_5_0);
Declare_label(mercury__prof_info__update_prof_node_5_0_i2);
Define_extern_entry(mercury__prof_info__prof_node_init_2_0);
Define_extern_entry(mercury__prof_info__prof_node__init_cycle_8_0);
Define_extern_entry(mercury__prof_info__prof__get_entire_7_0);
Define_extern_entry(mercury__prof_info__prof_get_addrdeclmap_2_0);
Define_extern_entry(mercury__prof_info__prof_get_profnodemap_2_0);
Define_extern_entry(mercury__prof_info__prof__set_entire_7_0);
Define_extern_entry(mercury__prof_info__prof_set_profnodemap_3_0);
Define_extern_entry(mercury__prof_info__prof_set_cyclemap_3_0);
Define_extern_entry(mercury__prof_info__prof_node__type_2_0);
Declare_label(mercury__prof_info__prof_node__type_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node__get_entire_pred_10_0);
Declare_label(mercury__prof_info__prof_node__get_entire_pred_10_0_i1002);
Define_extern_entry(mercury__prof_info__prof_node__get_entire_cycle_8_0);
Declare_label(mercury__prof_info__prof_node__get_entire_cycle_8_0_i1003);
Define_extern_entry(mercury__prof_info__prof_node_get_pred_name_2_0);
Declare_label(mercury__prof_info__prof_node_get_pred_name_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_get_cycle_number_2_0);
Declare_label(mercury__prof_info__prof_node_get_cycle_number_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_get_initial_counts_2_0);
Declare_label(mercury__prof_info__prof_node_get_initial_counts_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_get_propagated_counts_2_0);
Declare_label(mercury__prof_info__prof_node_get_propagated_counts_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_get_parent_list_2_0);
Declare_label(mercury__prof_info__prof_node_get_parent_list_2_0_i1002);
Define_extern_entry(mercury__prof_info__prof_node_get_child_list_2_0);
Declare_label(mercury__prof_info__prof_node_get_child_list_2_0_i1002);
Define_extern_entry(mercury__prof_info__prof_node_get_total_calls_2_0);
Declare_label(mercury__prof_info__prof_node_get_total_calls_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_get_self_calls_2_0);
Declare_label(mercury__prof_info__prof_node_get_self_calls_2_0_i3);
Define_extern_entry(mercury__prof_info__prof_node__set_cycle_num_3_0);
Declare_label(mercury__prof_info__prof_node__set_cycle_num_3_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_set_initial_counts_3_0);
Declare_label(mercury__prof_info__prof_node_set_initial_counts_3_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_set_propagated_counts_3_0);
Declare_label(mercury__prof_info__prof_node_set_propagated_counts_3_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_concat_to_parent_4_0);
Declare_label(mercury__prof_info__prof_node_concat_to_parent_4_0_i1000);
Define_extern_entry(mercury__prof_info__prof_node_concat_to_child_4_0);
Declare_label(mercury__prof_info__prof_node_concat_to_child_4_0_i1000);
Define_extern_entry(mercury__prof_info__prof_node_set_total_calls_3_0);
Declare_label(mercury__prof_info__prof_node_set_total_calls_3_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_set_self_calls_3_0);
Declare_label(mercury__prof_info__prof_node_set_self_calls_3_0_i3);
Define_extern_entry(mercury__prof_info__prof_node_concat_to_name_list_3_0);
Declare_label(mercury__prof_info__prof_node_concat_to_name_list_3_0_i1000);
Define_extern_entry(mercury__prof_info__prof_node__concat_to_member_4_0);
Declare_label(mercury__prof_info__prof_node__concat_to_member_4_0_i1005);
Define_extern_entry(mercury__prof_info__pred_info__init_3_0);
Define_extern_entry(mercury__prof_info__pred_info__get_entire_3_0);
Define_extern_entry(mercury__prof_info__pred_info_get_pred_name_2_0);
Define_extern_entry(mercury__prof_info__pred_info_get_counts_2_0);
Define_extern_entry(mercury____Unify___prof_info__prof_0_0);
Declare_label(mercury____Unify___prof_info__prof_0_0_i2);
Declare_label(mercury____Unify___prof_info__prof_0_0_i4);
Declare_label(mercury____Unify___prof_info__prof_0_0_i1006);
Declare_label(mercury____Unify___prof_info__prof_0_0_i1);
Define_extern_entry(mercury____Index___prof_info__prof_0_0);
Define_extern_entry(mercury____Compare___prof_info__prof_0_0);
Declare_label(mercury____Compare___prof_info__prof_0_0_i4);
Declare_label(mercury____Compare___prof_info__prof_0_0_i5);
Declare_label(mercury____Compare___prof_info__prof_0_0_i3);
Declare_label(mercury____Compare___prof_info__prof_0_0_i10);
Declare_label(mercury____Compare___prof_info__prof_0_0_i16);
Declare_label(mercury____Compare___prof_info__prof_0_0_i22);
Declare_label(mercury____Compare___prof_info__prof_0_0_i28);
Define_extern_entry(mercury____Unify___prof_info__addrdecl_0_0);
Define_extern_entry(mercury____Index___prof_info__addrdecl_0_0);
Define_extern_entry(mercury____Compare___prof_info__addrdecl_0_0);
Define_extern_entry(mercury____Unify___prof_info__prof_node_map_0_0);
Define_extern_entry(mercury____Index___prof_info__prof_node_map_0_0);
Define_extern_entry(mercury____Compare___prof_info__prof_node_map_0_0);
Define_extern_entry(mercury____Unify___prof_info__cycle_map_0_0);
Define_extern_entry(mercury____Index___prof_info__cycle_map_0_0);
Define_extern_entry(mercury____Compare___prof_info__cycle_map_0_0);
Define_extern_entry(mercury____Unify___prof_info__prof_node_0_0);
Declare_label(mercury____Unify___prof_info__prof_node_0_0_i5);
Declare_label(mercury____Unify___prof_info__prof_node_0_0_i7);
Declare_label(mercury____Unify___prof_info__prof_node_0_0_i1022);
Declare_label(mercury____Unify___prof_info__prof_node_0_0_i12);
Declare_label(mercury____Unify___prof_info__prof_node_0_0_i1019);
Declare_label(mercury____Unify___prof_info__prof_node_0_0_i1);
Define_extern_entry(mercury____Index___prof_info__prof_node_0_0);
Declare_label(mercury____Index___prof_info__prof_node_0_0_i3);
Define_extern_entry(mercury____Compare___prof_info__prof_node_0_0);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i2);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i3);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i4);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i6);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i15);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i16);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i14);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i21);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i27);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i33);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i39);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i45);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i51);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i57);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i11);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i73);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i79);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i85);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i91);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i97);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i103);
Declare_label(mercury____Compare___prof_info__prof_node_0_0_i9);
Define_extern_entry(mercury____Unify___prof_info__pred_info_0_0);
Declare_label(mercury____Unify___prof_info__pred_info_0_0_i1);
Define_extern_entry(mercury____Index___prof_info__pred_info_0_0);
Define_extern_entry(mercury____Compare___prof_info__pred_info_0_0);
Declare_label(mercury____Compare___prof_info__pred_info_0_0_i4);
Declare_label(mercury____Compare___prof_info__pred_info_0_0_i3);
Define_extern_entry(mercury____Unify___prof_info__prof_node_type_0_0);
Declare_label(mercury____Unify___prof_info__prof_node_type_0_0_i1);
Define_extern_entry(mercury____Index___prof_info__prof_node_type_0_0);
Define_extern_entry(mercury____Compare___prof_info__prof_node_type_0_0);

extern Word * mercury_data_prof_info__base_type_layout_addrdecl_0[];
Word * mercury_data_prof_info__base_type_info_addrdecl_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__addrdecl_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__addrdecl_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__addrdecl_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_addrdecl_0
};

extern Word * mercury_data_prof_info__base_type_layout_cycle_map_0[];
Word * mercury_data_prof_info__base_type_info_cycle_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__cycle_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__cycle_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__cycle_map_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_cycle_map_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_prof_info__base_type_layout_junk_0[];
Word * mercury_data_prof_info__base_type_info_junk_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_junk_0
};

extern Word * mercury_data_prof_info__base_type_layout_pred_info_0[];
Word * mercury_data_prof_info__base_type_info_pred_info_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__pred_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__pred_info_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__pred_info_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_pred_info_0
};

extern Word * mercury_data_prof_info__base_type_layout_prof_0[];
Word * mercury_data_prof_info__base_type_info_prof_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__prof_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__prof_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__prof_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_prof_0
};

extern Word * mercury_data_prof_info__base_type_layout_prof_node_0[];
Word * mercury_data_prof_info__base_type_info_prof_node_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__prof_node_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__prof_node_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__prof_node_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_prof_node_0
};

extern Word * mercury_data_prof_info__base_type_layout_prof_node_map_0[];
Word * mercury_data_prof_info__base_type_info_prof_node_map_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__prof_node_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__prof_node_map_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__prof_node_map_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_prof_node_map_0
};

extern Word * mercury_data_prof_info__base_type_layout_prof_node_type_0[];
Word * mercury_data_prof_info__base_type_info_prof_node_type_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___prof_info__prof_node_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___prof_info__prof_node_type_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___prof_info__prof_node_type_0_0),
	(Word *) (Integer) mercury_data_prof_info__base_type_layout_prof_node_type_0
};

extern Word * mercury_data_prof_info__common_0[];
Word * mercury_data_prof_info__base_type_layout_prof_node_type_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_0)
};

extern Word * mercury_data_prof_info__common_2[];
Word * mercury_data_prof_info__base_type_layout_prof_node_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_2)
};

extern Word * mercury_data_prof_info__common_8[];
extern Word * mercury_data_prof_info__common_9[];
Word * mercury_data_prof_info__base_type_layout_prof_node_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_prof_info__common_8),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_prof_info__common_9),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_prof_info__common_11[];
Word * mercury_data_prof_info__base_type_layout_prof_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_prof_info__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_prof_info__common_12[];
Word * mercury_data_prof_info__base_type_layout_pred_info_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_prof_info__common_12),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_prof_info__common_14[];
Word * mercury_data_prof_info__base_type_layout_junk_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_14),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_14)
};

extern Word * mercury_data_prof_info__common_15[];
Word * mercury_data_prof_info__base_type_layout_cycle_map_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15)
};

Word * mercury_data_prof_info__base_type_layout_addrdecl_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_prof_info__common_15)
};

Word * mercury_data_prof_info__common_0[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("predicate", 9),
	(Word *) string_const("cycle", 5)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_prof_info__common_1[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data_prof_info__base_type_info_prof_node_0
};

Word * mercury_data_prof_info__common_2[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_1)
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_prof_info__common_3[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_prof_info__common_4[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data___base_type_info_float_0[];
Word * mercury_data_prof_info__common_5[] = {
	(Word *) (Integer) mercury_data___base_type_info_float_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_prof_info__common_6[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_prof_info__base_type_info_pred_info_0
};

Word * mercury_data_prof_info__common_7[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_prof_info__common_8[] = {
	(Word *) ((Integer) 9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_7),
	(Word *) string_const("pred_node", 9)
};

Word * mercury_data_prof_info__common_9[] = {
	(Word *) ((Integer) 7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) string_const("cycle_node", 10)
};

Word * mercury_data_prof_info__common_10[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_prof_info__common_11[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_10),
	(Word *) string_const("prof", 4)
};

Word * mercury_data_prof_info__common_12[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_4),
	(Word *) string_const("pred_info", 9)
};

extern Word * mercury_data_std_util__base_type_info_unit_0[];
Word * mercury_data_prof_info__common_13[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_unit_0
};

Word * mercury_data_prof_info__common_14[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_13)
};

Word * mercury_data_prof_info__common_15[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_prof_info__common_10)
};

BEGIN_MODULE(mercury__prof_info_module0)
	init_entry(mercury____Index___prof_info_pred_info_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___prof_info_pred_info_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___prof_info_pred_info_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module1)
	init_entry(mercury____Index___prof_info_prof_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___prof_info_prof_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___prof_info_prof_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module2)
	init_entry(mercury__prof_info__get_prof_node_4_0);
	init_label(mercury__prof_info__get_prof_node_4_0_i2);
BEGIN_CODE

/* code for predicate 'get_prof_node'/4 in mode 0 */
Define_entry(mercury__prof_info__get_prof_node_4_0);
	incr_sp_push_msg(2, "get_prof_node");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r2;
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__prof_info__get_prof_node_4_0_i2,
		ENTRY(mercury__prof_info__get_prof_node_4_0));
	}
Define_label(mercury__prof_info__get_prof_node_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prof_info__get_prof_node_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__prof_info__get_prof_node_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module3)
	init_entry(mercury__prof_info__update_prof_node_5_0);
	init_label(mercury__prof_info__update_prof_node_5_0_i2);
BEGIN_CODE

/* code for predicate 'update_prof_node'/5 in mode 0 */
Define_entry(mercury__prof_info__update_prof_node_5_0);
	incr_sp_push_msg(3, "update_prof_node");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) r4;
	r4 = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__prof_info__update_prof_node_5_0_i2,
		ENTRY(mercury__prof_info__update_prof_node_5_0));
	}
Define_label(mercury__prof_info__update_prof_node_5_0_i2);
	update_prof_current_proc(LABEL(mercury__prof_info__update_prof_node_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__map__det_update_4_0);
	tailcall(ENTRY(mercury__map__det_update_4_0),
		ENTRY(mercury__prof_info__update_prof_node_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module4)
	init_entry(mercury__prof_info__prof_node_init_2_0);
BEGIN_CODE

/* code for predicate 'prof_node_init'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_init_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = ((Integer) 0);
	{
	static const Float mercury_float_const_0 = 0;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Word)(&mercury_float_const_0);
	}
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 7)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module5)
	init_entry(mercury__prof_info__prof_node__init_cycle_8_0);
BEGIN_CODE

/* code for predicate 'prof_node__init_cycle'/8 in mode 0 */
Define_entry(mercury__prof_info__prof_node__init_cycle_8_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 6)) = (Integer) r7;
	field(mktag(1), (Integer) tempr1, ((Integer) 5)) = (Integer) r6;
	field(mktag(1), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	field(mktag(1), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module6)
	init_entry(mercury__prof_info__prof__get_entire_7_0);
BEGIN_CODE

/* code for predicate 'prof__get_entire'/7 in mode 0 */
Define_entry(mercury__prof_info__prof__get_entire_7_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module7)
	init_entry(mercury__prof_info__prof_get_addrdeclmap_2_0);
BEGIN_CODE

/* code for predicate 'prof_get_addrdeclmap'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_get_addrdeclmap_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module8)
	init_entry(mercury__prof_info__prof_get_profnodemap_2_0);
BEGIN_CODE

/* code for predicate 'prof_get_profnodemap'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_get_profnodemap_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module9)
	init_entry(mercury__prof_info__prof__set_entire_7_0);
BEGIN_CODE

/* code for predicate 'prof__set_entire'/7 in mode 0 */
Define_entry(mercury__prof_info__prof__set_entire_7_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 5)) = (Integer) r6;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module10)
	init_entry(mercury__prof_info__prof_set_profnodemap_3_0);
BEGIN_CODE

/* code for predicate 'prof_set_profnodemap'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_set_profnodemap_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module11)
	init_entry(mercury__prof_info__prof_set_cyclemap_3_0);
BEGIN_CODE

/* code for predicate 'prof_set_cyclemap'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_set_cyclemap_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module12)
	init_entry(mercury__prof_info__prof_node__type_2_0);
	init_label(mercury__prof_info__prof_node__type_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node__type'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node__type_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node__type_2_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__prof_info__prof_node__type_2_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module13)
	init_entry(mercury__prof_info__prof_node__get_entire_pred_10_0);
	init_label(mercury__prof_info__prof_node__get_entire_pred_10_0_i1002);
BEGIN_CODE

/* code for predicate 'prof_node__get_entire_pred'/10 in mode 0 */
Define_entry(mercury__prof_info__prof_node__get_entire_pred_10_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node__get_entire_pred_10_0_i1002);
	r1 = string_const("prof_node__get_entire_pred: not a pred\n", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node__get_entire_pred_10_0));
	}
Define_label(mercury__prof_info__prof_node__get_entire_pred_10_0_i1002);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r6 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	r7 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	r8 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	r9 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module14)
	init_entry(mercury__prof_info__prof_node__get_entire_cycle_8_0);
	init_label(mercury__prof_info__prof_node__get_entire_cycle_8_0_i1003);
BEGIN_CODE

/* code for predicate 'prof_node__get_entire_cycle'/8 in mode 0 */
Define_entry(mercury__prof_info__prof_node__get_entire_cycle_8_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node__get_entire_cycle_8_0_i1003);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	r5 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 5));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 6));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__prof_info__prof_node__get_entire_cycle_8_0_i1003);
	r1 = string_const("prof_node__get_entire_cycle: not a cycle\n", 41);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node__get_entire_cycle_8_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module15)
	init_entry(mercury__prof_info__prof_node_get_pred_name_2_0);
	init_label(mercury__prof_info__prof_node_get_pred_name_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_get_pred_name'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_pred_name_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_pred_name_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__prof_info__prof_node_get_pred_name_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module16)
	init_entry(mercury__prof_info__prof_node_get_cycle_number_2_0);
	init_label(mercury__prof_info__prof_node_get_cycle_number_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_get_cycle_number'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_cycle_number_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_cycle_number_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__prof_info__prof_node_get_cycle_number_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module17)
	init_entry(mercury__prof_info__prof_node_get_initial_counts_2_0);
	init_label(mercury__prof_info__prof_node_get_initial_counts_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_get_initial_counts'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_initial_counts_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_initial_counts_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	proceed();
Define_label(mercury__prof_info__prof_node_get_initial_counts_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module18)
	init_entry(mercury__prof_info__prof_node_get_propagated_counts_2_0);
	init_label(mercury__prof_info__prof_node_get_propagated_counts_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_get_propagated_counts'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_propagated_counts_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_propagated_counts_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	proceed();
Define_label(mercury__prof_info__prof_node_get_propagated_counts_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module19)
	init_entry(mercury__prof_info__prof_node_get_parent_list_2_0);
	init_label(mercury__prof_info__prof_node_get_parent_list_2_0_i1002);
BEGIN_CODE

/* code for predicate 'prof_node_get_parent_list'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_parent_list_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_parent_list_2_0_i1002);
	r1 = string_const("prof_node_get_parent_list: cycle_node has no parent list\n", 57);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node_get_parent_list_2_0));
	}
Define_label(mercury__prof_info__prof_node_get_parent_list_2_0_i1002);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module20)
	init_entry(mercury__prof_info__prof_node_get_child_list_2_0);
	init_label(mercury__prof_info__prof_node_get_child_list_2_0_i1002);
BEGIN_CODE

/* code for predicate 'prof_node_get_child_list'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_child_list_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_child_list_2_0_i1002);
	r1 = string_const("prof_node_get_child_list: cycle_node has no child list\n", 55);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node_get_child_list_2_0));
	}
Define_label(mercury__prof_info__prof_node_get_child_list_2_0_i1002);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module21)
	init_entry(mercury__prof_info__prof_node_get_total_calls_2_0);
	init_label(mercury__prof_info__prof_node_get_total_calls_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_get_total_calls'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_total_calls_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_total_calls_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 5));
	proceed();
Define_label(mercury__prof_info__prof_node_get_total_calls_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module22)
	init_entry(mercury__prof_info__prof_node_get_self_calls_2_0);
	init_label(mercury__prof_info__prof_node_get_self_calls_2_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_get_self_calls'/2 in mode 0 */
Define_entry(mercury__prof_info__prof_node_get_self_calls_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_get_self_calls_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 6));
	proceed();
Define_label(mercury__prof_info__prof_node_get_self_calls_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module23)
	init_entry(mercury__prof_info__prof_node__set_cycle_num_3_0);
	init_label(mercury__prof_info__prof_node__set_cycle_num_3_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node__set_cycle_num'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_node__set_cycle_num_3_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node__set_cycle_num_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	field(mktag(1), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 6));
	proceed();
Define_label(mercury__prof_info__prof_node__set_cycle_num_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module24)
	init_entry(mercury__prof_info__prof_node_set_initial_counts_3_0);
	init_label(mercury__prof_info__prof_node_set_initial_counts_3_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_set_initial_counts'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_node_set_initial_counts_3_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_set_initial_counts_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	field(mktag(1), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 6));
	proceed();
Define_label(mercury__prof_info__prof_node_set_initial_counts_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module25)
	init_entry(mercury__prof_info__prof_node_set_propagated_counts_3_0);
	init_label(mercury__prof_info__prof_node_set_propagated_counts_3_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_set_propagated_counts'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_node_set_propagated_counts_3_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_set_propagated_counts_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	field(mktag(1), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 6));
	proceed();
Define_label(mercury__prof_info__prof_node_set_propagated_counts_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module26)
	init_entry(mercury__prof_info__prof_node_concat_to_parent_4_0);
	init_label(mercury__prof_info__prof_node_concat_to_parent_4_0_i1000);
BEGIN_CODE

/* code for predicate 'prof_node_concat_to_parent'/4 in mode 0 */
Define_entry(mercury__prof_info__prof_node_concat_to_parent_4_0);
	if ((tag((Integer) r3) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_concat_to_parent_4_0_i1000);
	r1 = string_const("prof_node_concat_to_parent: cycle_node has no parents\n", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node_concat_to_parent_4_0));
	}
Define_label(mercury__prof_info__prof_node_concat_to_parent_4_0_i1000);
	incr_sp_push_msg(1, "prof_node_concat_to_parent");
	detstackvar(1) = (Integer) succip;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module27)
	init_entry(mercury__prof_info__prof_node_concat_to_child_4_0);
	init_label(mercury__prof_info__prof_node_concat_to_child_4_0_i1000);
BEGIN_CODE

/* code for predicate 'prof_node_concat_to_child'/4 in mode 0 */
Define_entry(mercury__prof_info__prof_node_concat_to_child_4_0);
	if ((tag((Integer) r3) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_concat_to_child_4_0_i1000);
	r1 = string_const("prof_node_concat_to_child: cycle_node has no child\n", 51);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node_concat_to_child_4_0));
	}
Define_label(mercury__prof_info__prof_node_concat_to_child_4_0_i1000);
	incr_sp_push_msg(1, "prof_node_concat_to_child");
	detstackvar(1) = (Integer) succip;
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module28)
	init_entry(mercury__prof_info__prof_node_set_total_calls_3_0);
	init_label(mercury__prof_info__prof_node_set_total_calls_3_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_set_total_calls'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_node_set_total_calls_3_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_set_total_calls_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 6));
	proceed();
Define_label(mercury__prof_info__prof_node_set_total_calls_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module29)
	init_entry(mercury__prof_info__prof_node_set_self_calls_3_0);
	init_label(mercury__prof_info__prof_node_set_self_calls_3_0_i3);
BEGIN_CODE

/* code for predicate 'prof_node_set_self_calls'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_node_set_self_calls_3_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_set_self_calls_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	field(mktag(1), (Integer) r1, ((Integer) 6)) = (Integer) r3;
	proceed();
Define_label(mercury__prof_info__prof_node_set_self_calls_3_0_i3);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module30)
	init_entry(mercury__prof_info__prof_node_concat_to_name_list_3_0);
	init_label(mercury__prof_info__prof_node_concat_to_name_list_3_0_i1000);
BEGIN_CODE

/* code for predicate 'prof_node_concat_to_name_list'/3 in mode 0 */
Define_entry(mercury__prof_info__prof_node_concat_to_name_list_3_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node_concat_to_name_list_3_0_i1000);
	r1 = string_const("prof_node_concat_to_name_list: cycle_node has no namelist\n", 58);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node_concat_to_name_list_3_0));
	}
Define_label(mercury__prof_info__prof_node_concat_to_name_list_3_0_i1000);
	incr_sp_push_msg(1, "prof_node_concat_to_name_list");
	detstackvar(1) = (Integer) succip;
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 9));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	field(mktag(0), (Integer) r1, ((Integer) 7)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 8)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module31)
	init_entry(mercury__prof_info__prof_node__concat_to_member_4_0);
	init_label(mercury__prof_info__prof_node__concat_to_member_4_0_i1005);
BEGIN_CODE

/* code for predicate 'prof_node__concat_to_member'/4 in mode 0 */
Define_entry(mercury__prof_info__prof_node__concat_to_member_4_0);
	if ((tag((Integer) r3) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__prof_info__prof_node__concat_to_member_4_0_i1005);
	r4 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 7));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r1, ((Integer) 6)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 6));
	field(mktag(1), (Integer) r1, ((Integer) 5)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 5));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 4)) = (Integer) r5;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	proceed();
	}
Define_label(mercury__prof_info__prof_node__concat_to_member_4_0_i1005);
	r1 = string_const("prof_node_concat_to_member: pred_node has no members\n", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__prof_info__prof_node__concat_to_member_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module32)
	init_entry(mercury__prof_info__pred_info__init_3_0);
BEGIN_CODE

/* code for predicate 'pred_info__init'/3 in mode 0 */
Define_entry(mercury__prof_info__pred_info__init_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module33)
	init_entry(mercury__prof_info__pred_info__get_entire_3_0);
BEGIN_CODE

/* code for predicate 'pred_info__get_entire'/3 in mode 0 */
Define_entry(mercury__prof_info__pred_info__get_entire_3_0);
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module34)
	init_entry(mercury__prof_info__pred_info_get_pred_name_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_get_pred_name'/2 in mode 0 */
Define_entry(mercury__prof_info__pred_info_get_pred_name_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module35)
	init_entry(mercury__prof_info__pred_info_get_counts_2_0);
BEGIN_CODE

/* code for predicate 'pred_info_get_counts'/2 in mode 0 */
Define_entry(mercury__prof_info__pred_info_get_counts_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module36)
	init_entry(mercury____Unify___prof_info__prof_0_0);
	init_label(mercury____Unify___prof_info__prof_0_0_i2);
	init_label(mercury____Unify___prof_info__prof_0_0_i4);
	init_label(mercury____Unify___prof_info__prof_0_0_i1006);
	init_label(mercury____Unify___prof_info__prof_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__prof_0_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_0_0_i1006);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_0_0_i1006);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_0_0_i1006);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___prof_info__prof_0_0_i2,
		ENTRY(mercury____Unify___prof_info__prof_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___prof_info__prof_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___prof_info__prof_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___prof_info__prof_0_0_i4,
		ENTRY(mercury____Unify___prof_info__prof_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___prof_info__prof_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___prof_info__prof_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___prof_info__prof_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_0_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___prof_info__prof_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module37)
	init_entry(mercury____Index___prof_info__prof_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__prof_0_0);
	tailcall(STATIC(mercury____Index___prof_info_prof_0__ua10000_2_0),
		ENTRY(mercury____Index___prof_info__prof_0_0));
END_MODULE

BEGIN_MODULE(mercury__prof_info_module38)
	init_entry(mercury____Compare___prof_info__prof_0_0);
	init_label(mercury____Compare___prof_info__prof_0_0_i4);
	init_label(mercury____Compare___prof_info__prof_0_0_i5);
	init_label(mercury____Compare___prof_info__prof_0_0_i3);
	init_label(mercury____Compare___prof_info__prof_0_0_i10);
	init_label(mercury____Compare___prof_info__prof_0_0_i16);
	init_label(mercury____Compare___prof_info__prof_0_0_i22);
	init_label(mercury____Compare___prof_info__prof_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__prof_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_0_0_i4,
		ENTRY(mercury____Compare___prof_info__prof_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_0_0_i3);
Define_label(mercury____Compare___prof_info__prof_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___prof_info__prof_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_0_0_i10,
		ENTRY(mercury____Compare___prof_info__prof_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_0_0_i16,
		ENTRY(mercury____Compare___prof_info__prof_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___prof_info__prof_0_0_i22,
		ENTRY(mercury____Compare___prof_info__prof_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___prof_info__prof_0_0_i28,
		ENTRY(mercury____Compare___prof_info__prof_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___prof_info__prof_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module39)
	init_entry(mercury____Unify___prof_info__addrdecl_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__addrdecl_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___prof_info__addrdecl_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module40)
	init_entry(mercury____Index___prof_info__addrdecl_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__addrdecl_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___prof_info__addrdecl_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module41)
	init_entry(mercury____Compare___prof_info__addrdecl_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__addrdecl_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___prof_info__addrdecl_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module42)
	init_entry(mercury____Unify___prof_info__prof_node_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__prof_node_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___prof_info__prof_node_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module43)
	init_entry(mercury____Index___prof_info__prof_node_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__prof_node_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___prof_info__prof_node_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module44)
	init_entry(mercury____Compare___prof_info__prof_node_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__prof_node_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___prof_info__prof_node_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module45)
	init_entry(mercury____Unify___prof_info__cycle_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__cycle_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___prof_info__cycle_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module46)
	init_entry(mercury____Index___prof_info__cycle_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__cycle_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___prof_info__cycle_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module47)
	init_entry(mercury____Compare___prof_info__cycle_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__cycle_map_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___prof_info__cycle_map_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module48)
	init_entry(mercury____Unify___prof_info__prof_node_0_0);
	init_label(mercury____Unify___prof_info__prof_node_0_0_i5);
	init_label(mercury____Unify___prof_info__prof_node_0_0_i7);
	init_label(mercury____Unify___prof_info__prof_node_0_0_i1022);
	init_label(mercury____Unify___prof_info__prof_node_0_0_i12);
	init_label(mercury____Unify___prof_info__prof_node_0_0_i1019);
	init_label(mercury____Unify___prof_info__prof_node_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__prof_node_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1022);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1019);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1019);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1019);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1019);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 3))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1019);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 6));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 7));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	r1 = (Integer) mercury_data_prof_info__base_type_info_pred_info_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___prof_info__prof_node_0_0_i5,
		ENTRY(mercury____Unify___prof_info__prof_node_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_node_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___prof_info__prof_node_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	r1 = (Integer) mercury_data_prof_info__base_type_info_pred_info_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___prof_info__prof_node_0_0_i7,
		ENTRY(mercury____Unify___prof_info__prof_node_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_node_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___prof_info__prof_node_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(6)))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if (((Integer) detstackvar(3) != (Integer) detstackvar(7)))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___prof_info__prof_node_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_node_0_0_i1022);
	incr_sp_push_msg(9, "__Unify__");
	detstackvar(9) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(1), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 2))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if ((word_to_float((Integer) field(mktag(1), (Integer) r1, ((Integer) 3))) != word_to_float((Integer) field(mktag(1), (Integer) r2, ((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 4));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 5));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 6));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 4));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 5));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 6));
	r1 = (Integer) mercury_data_prof_info__base_type_info_pred_info_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___prof_info__prof_node_0_0_i12,
		ENTRY(mercury____Unify___prof_info__prof_node_0_0));
	}
Define_label(mercury____Unify___prof_info__prof_node_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___prof_info__prof_node_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(3)))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	if (((Integer) detstackvar(2) != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_0_0_i1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___prof_info__prof_node_0_0_i1019);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___prof_info__prof_node_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module49)
	init_entry(mercury____Index___prof_info__prof_node_0_0);
	init_label(mercury____Index___prof_info__prof_node_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__prof_node_0_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___prof_info__prof_node_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___prof_info__prof_node_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module50)
	init_entry(mercury____Compare___prof_info__prof_node_0_0);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i2);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i3);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i4);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i6);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i15);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i16);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i14);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i21);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i27);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i33);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i39);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i45);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i51);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i57);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i11);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i73);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i79);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i85);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i91);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i97);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i103);
	init_label(mercury____Compare___prof_info__prof_node_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__prof_node_0_0);
	incr_sp_push_msg(17, "__Compare__");
	detstackvar(17) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___prof_info__prof_node_0_0),
		mercury____Compare___prof_info__prof_node_0_0_i2,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___prof_info__prof_node_0_0),
		mercury____Compare___prof_info__prof_node_0_0_i3,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury____Compare___prof_info__prof_node_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury____Compare___prof_info__prof_node_0_0_i6);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 8));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i15,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i14);
Define_label(mercury____Compare___prof_info__prof_node_0_0_i16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	proceed();
Define_label(mercury____Compare___prof_info__prof_node_0_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i21,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i27,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i33,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i33);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) mercury_data_prof_info__base_type_info_pred_info_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___prof_info__prof_node_0_0_i39,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) mercury_data_prof_info__base_type_info_pred_info_0;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___prof_info__prof_node_0_0_i45,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i45);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i51,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i57,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i57);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 4));
	detstackvar(11) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 5));
	detstackvar(12) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 6));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 6));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i73,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i73);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i79,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i79);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i85,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i85);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i91,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i91);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) mercury_data_prof_info__base_type_info_pred_info_0;
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___prof_info__prof_node_0_0_i97,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i97);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prof_info__prof_node_0_0_i103,
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i103);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__prof_node_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__prof_node_0_0_i16);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
Define_label(mercury____Compare___prof_info__prof_node_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(17);
	decr_sp_pop_msg(17);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___prof_info__prof_node_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module51)
	init_entry(mercury____Unify___prof_info__pred_info_0_0);
	init_label(mercury____Unify___prof_info__pred_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__pred_info_0_0);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___prof_info__pred_info_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___prof_info__pred_info_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___prof_info__pred_info_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module52)
	init_entry(mercury____Index___prof_info__pred_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__pred_info_0_0);
	tailcall(STATIC(mercury____Index___prof_info_pred_info_0__ua10000_2_0),
		ENTRY(mercury____Index___prof_info__pred_info_0_0));
END_MODULE

BEGIN_MODULE(mercury__prof_info_module53)
	init_entry(mercury____Compare___prof_info__pred_info_0_0);
	init_label(mercury____Compare___prof_info__pred_info_0_0_i4);
	init_label(mercury____Compare___prof_info__pred_info_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__pred_info_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___prof_info__pred_info_0_0_i4,
		ENTRY(mercury____Compare___prof_info__pred_info_0_0));
	}
Define_label(mercury____Compare___prof_info__pred_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___prof_info__pred_info_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prof_info__pred_info_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___prof_info__pred_info_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___prof_info__pred_info_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module54)
	init_entry(mercury____Unify___prof_info__prof_node_type_0_0);
	init_label(mercury____Unify___prof_info__prof_node_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prof_info__prof_node_type_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___prof_info__prof_node_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___prof_info__prof_node_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__prof_info_module55)
	init_entry(mercury____Index___prof_info__prof_node_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prof_info__prof_node_type_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___prof_info__prof_node_type_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__prof_info_module56)
	init_entry(mercury____Compare___prof_info__prof_node_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prof_info__prof_node_type_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___prof_info__prof_node_type_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__prof_info_bunch_0(void)
{
	mercury__prof_info_module0();
	mercury__prof_info_module1();
	mercury__prof_info_module2();
	mercury__prof_info_module3();
	mercury__prof_info_module4();
	mercury__prof_info_module5();
	mercury__prof_info_module6();
	mercury__prof_info_module7();
	mercury__prof_info_module8();
	mercury__prof_info_module9();
	mercury__prof_info_module10();
	mercury__prof_info_module11();
	mercury__prof_info_module12();
	mercury__prof_info_module13();
	mercury__prof_info_module14();
	mercury__prof_info_module15();
	mercury__prof_info_module16();
	mercury__prof_info_module17();
	mercury__prof_info_module18();
	mercury__prof_info_module19();
	mercury__prof_info_module20();
	mercury__prof_info_module21();
	mercury__prof_info_module22();
	mercury__prof_info_module23();
	mercury__prof_info_module24();
	mercury__prof_info_module25();
	mercury__prof_info_module26();
	mercury__prof_info_module27();
	mercury__prof_info_module28();
	mercury__prof_info_module29();
	mercury__prof_info_module30();
	mercury__prof_info_module31();
	mercury__prof_info_module32();
	mercury__prof_info_module33();
	mercury__prof_info_module34();
	mercury__prof_info_module35();
	mercury__prof_info_module36();
	mercury__prof_info_module37();
	mercury__prof_info_module38();
	mercury__prof_info_module39();
	mercury__prof_info_module40();
}

static void mercury__prof_info_bunch_1(void)
{
	mercury__prof_info_module41();
	mercury__prof_info_module42();
	mercury__prof_info_module43();
	mercury__prof_info_module44();
	mercury__prof_info_module45();
	mercury__prof_info_module46();
	mercury__prof_info_module47();
	mercury__prof_info_module48();
	mercury__prof_info_module49();
	mercury__prof_info_module50();
	mercury__prof_info_module51();
	mercury__prof_info_module52();
	mercury__prof_info_module53();
	mercury__prof_info_module54();
	mercury__prof_info_module55();
	mercury__prof_info_module56();
}

#endif

void mercury__prof_info__init(void); /* suppress gcc warning */
void mercury__prof_info__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__prof_info_bunch_0();
	mercury__prof_info_bunch_1();
#endif
}
