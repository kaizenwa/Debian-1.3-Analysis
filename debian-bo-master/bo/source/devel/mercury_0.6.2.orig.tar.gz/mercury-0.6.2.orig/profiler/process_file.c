/*
** Automatically generated from `process_file.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__process_file__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__process_file__main_4_0);
Declare_label(mercury__process_file__main_4_0_i2);
Declare_label(mercury__process_file__main_4_0_i3);
Declare_label(mercury__process_file__main_4_0_i4);
Declare_label(mercury__process_file__main_4_0_i5);
Declare_label(mercury__process_file__main_4_0_i6);
Declare_label(mercury__process_file__main_4_0_i7);
Declare_label(mercury__process_file__main_4_0_i8);
Declare_label(mercury__process_file__main_4_0_i9);
Declare_label(mercury__process_file__main_4_0_i10);
Declare_label(mercury__process_file__main_4_0_i11);
Declare_label(mercury__process_file__main_4_0_i12);
Declare_label(mercury__process_file__main_4_0_i13);
Declare_label(mercury__process_file__main_4_0_i16);
Declare_label(mercury__process_file__main_4_0_i17);
Declare_label(mercury__process_file__main_4_0_i18);
Declare_label(mercury__process_file__main_4_0_i19);
Declare_label(mercury__process_file__main_4_0_i20);
Declare_label(mercury__process_file__main_4_0_i21);
Declare_label(mercury__process_file__main_4_0_i15);
Declare_label(mercury__process_file__main_4_0_i22);
Declare_label(mercury__process_file__main_4_0_i23);
Declare_label(mercury__process_file__main_4_0_i14);
Declare_label(mercury__process_file__main_4_0_i24);
Declare_label(mercury__process_file__main_4_0_i25);
Declare_label(mercury__process_file__main_4_0_i26);
Declare_label(mercury__process_file__main_4_0_i27);
Declare_label(mercury__process_file__main_4_0_i28);
Declare_label(mercury__process_file__main_4_0_i29);
Declare_label(mercury__process_file__main_4_0_i30);
Declare_label(mercury__process_file__main_4_0_i31);
Declare_label(mercury__process_file__main_4_0_i32);
Declare_label(mercury__process_file__main_4_0_i33);
Declare_label(mercury__process_file__main_4_0_i34);
Declare_label(mercury__process_file__main_4_0_i38);
Declare_label(mercury__process_file__main_4_0_i35);
Declare_static(mercury__process_file__process_addr_decl_2_6_0);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i2);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i5);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i6);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i7);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i10);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i9);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i12);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i13);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i14);
Declare_label(mercury__process_file__process_addr_decl_2_6_0_i4);
Declare_static(mercury__process_file__process_addr_7_0);
Declare_label(mercury__process_file__process_addr_7_0_i2);
Declare_label(mercury__process_file__process_addr_7_0_i3);
Declare_label(mercury__process_file__process_addr_7_0_i6);
Declare_label(mercury__process_file__process_addr_7_0_i7);
Declare_label(mercury__process_file__process_addr_7_0_i8);
Declare_label(mercury__process_file__process_addr_7_0_i9);
Declare_label(mercury__process_file__process_addr_7_0_i10);
Declare_label(mercury__process_file__process_addr_7_0_i11);
Declare_label(mercury__process_file__process_addr_7_0_i5);
Declare_label(mercury__process_file__process_addr_7_0_i12);
Declare_label(mercury__process_file__process_addr_7_0_i13);
Declare_label(mercury__process_file__process_addr_7_0_i14);
Declare_static(mercury__process_file__process_addr_2_6_0);
Declare_label(mercury__process_file__process_addr_2_6_0_i2);
Declare_label(mercury__process_file__process_addr_2_6_0_i5);
Declare_label(mercury__process_file__process_addr_2_6_0_i8);
Declare_label(mercury__process_file__process_addr_2_6_0_i10);
Declare_label(mercury__process_file__process_addr_2_6_0_i11);
Declare_label(mercury__process_file__process_addr_2_6_0_i12);
Declare_label(mercury__process_file__process_addr_2_6_0_i7);
Declare_label(mercury__process_file__process_addr_2_6_0_i13);
Declare_label(mercury__process_file__process_addr_2_6_0_i14);
Declare_label(mercury__process_file__process_addr_2_6_0_i4);
Declare_static(mercury__process_file__process_addr_pair_5_0);
Declare_label(mercury__process_file__process_addr_pair_5_0_i2);
Declare_label(mercury__process_file__process_addr_pair_5_0_i3);
Declare_label(mercury__process_file__process_addr_pair_5_0_i4);
Declare_label(mercury__process_file__process_addr_pair_5_0_i5);
Declare_label(mercury__process_file__process_addr_pair_5_0_i8);
Declare_label(mercury__process_file__process_addr_pair_5_0_i9);
Declare_label(mercury__process_file__process_addr_pair_5_0_i10);
Declare_label(mercury__process_file__process_addr_pair_5_0_i11);
Declare_label(mercury__process_file__process_addr_pair_5_0_i12);
Declare_label(mercury__process_file__process_addr_pair_5_0_i13);
Declare_label(mercury__process_file__process_addr_pair_5_0_i7);
Declare_label(mercury__process_file__process_addr_pair_5_0_i14);
Declare_static(mercury__process_file__process_addr_pair_2_7_0);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i2);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i5);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i6);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i7);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i8);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i9);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i10);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i11);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i12);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i15);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i16);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i17);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i13);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i18);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i19);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i20);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i24);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i25);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i26);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i21);
Declare_label(mercury__process_file__process_addr_pair_2_7_0_i4);
Declare_static(mercury__process_file__lookup_addr_5_0);
Declare_label(mercury__process_file__lookup_addr_5_0_i4);
Declare_label(mercury__process_file__lookup_addr_5_0_i3);
Declare_label(mercury__process_file__lookup_addr_5_0_i6);
Declare_label(mercury__process_file__lookup_addr_5_0_i7);
Declare_label(mercury__process_file__lookup_addr_5_0_i8);

BEGIN_MODULE(mercury__process_file_module0)
	init_entry(mercury__process_file__main_4_0);
	init_label(mercury__process_file__main_4_0_i2);
	init_label(mercury__process_file__main_4_0_i3);
	init_label(mercury__process_file__main_4_0_i4);
	init_label(mercury__process_file__main_4_0_i5);
	init_label(mercury__process_file__main_4_0_i6);
	init_label(mercury__process_file__main_4_0_i7);
	init_label(mercury__process_file__main_4_0_i8);
	init_label(mercury__process_file__main_4_0_i9);
	init_label(mercury__process_file__main_4_0_i10);
	init_label(mercury__process_file__main_4_0_i11);
	init_label(mercury__process_file__main_4_0_i12);
	init_label(mercury__process_file__main_4_0_i13);
	init_label(mercury__process_file__main_4_0_i16);
	init_label(mercury__process_file__main_4_0_i17);
	init_label(mercury__process_file__main_4_0_i18);
	init_label(mercury__process_file__main_4_0_i19);
	init_label(mercury__process_file__main_4_0_i20);
	init_label(mercury__process_file__main_4_0_i21);
	init_label(mercury__process_file__main_4_0_i15);
	init_label(mercury__process_file__main_4_0_i22);
	init_label(mercury__process_file__main_4_0_i23);
	init_label(mercury__process_file__main_4_0_i14);
	init_label(mercury__process_file__main_4_0_i24);
	init_label(mercury__process_file__main_4_0_i25);
	init_label(mercury__process_file__main_4_0_i26);
	init_label(mercury__process_file__main_4_0_i27);
	init_label(mercury__process_file__main_4_0_i28);
	init_label(mercury__process_file__main_4_0_i29);
	init_label(mercury__process_file__main_4_0_i30);
	init_label(mercury__process_file__main_4_0_i31);
	init_label(mercury__process_file__main_4_0_i32);
	init_label(mercury__process_file__main_4_0_i33);
	init_label(mercury__process_file__main_4_0_i34);
	init_label(mercury__process_file__main_4_0_i38);
	init_label(mercury__process_file__main_4_0_i35);
BEGIN_CODE

/* code for predicate 'process_file__main'/4 in mode 0 */
Define_entry(mercury__process_file__main_4_0);
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	incr_sp_push_msg(10, "process_file__main");
	detstackvar(10) = (Integer) succip;
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__process_file__main_4_0_i2,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i2);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 6);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__process_file__main_4_0_i3,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i3);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 4);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__process_file__main_4_0_i4,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i4);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 5);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__process_file__main_4_0_i5,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i5);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(4) = (Integer) r1;
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__process_file__main_4_0_i6,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i6);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("\n\t% Processing ", 15);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i7,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i7);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i8,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i8);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("...", 3);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i9,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i9);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(2) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__process_file__main_4_0_i10,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i10);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(6) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__process_file__main_4_0_i11,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i11);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 6);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__process_file__main_4_0_i12,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i12);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__io__see_4_0);
	call_localret(ENTRY(mercury__io__see_4_0),
		mercury__process_file__main_4_0_i13,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i13);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__process_file__main_4_0_i15);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__process_file__main_4_0_i16,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i16);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = string_const("error opening declaration file `", 32);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__main_4_0_i17,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i17);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r2 = string_const("': ", 3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__main_4_0_i18,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i18);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__main_4_0_i19,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i19);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__main_4_0_i20,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i20);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__process_file__main_4_0_i21,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i21);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(2);
	GOTO_LABEL(mercury__process_file__main_4_0_i14);
Define_label(mercury__process_file__main_4_0_i15);
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__process_file__process_addr_decl_2_6_0),
		mercury__process_file__main_4_0_i22,
		ENTRY(mercury__process_file__main_4_0));
Define_label(mercury__process_file__main_4_0_i22);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__seen_2_0);
	call_localret(ENTRY(mercury__io__seen_2_0),
		mercury__process_file__main_4_0_i23,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i23);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(" done.\n\t% Processing ", 21);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(2);
Define_label(mercury__process_file__main_4_0_i14);
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(2) = (Integer) r8;
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i24,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i24);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i25,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i25);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("...", 3);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i26,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i26);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__process_file__process_addr_7_0),
		mercury__process_file__main_4_0_i27,
		ENTRY(mercury__process_file__main_4_0));
Define_label(mercury__process_file__main_4_0_i27);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	detstackvar(7) = (Integer) r3;
	detstackvar(8) = (Integer) r4;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(" done.\n\t% Processing ", 21);
	r3 = (Integer) r5;
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i28,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i28);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i29,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i29);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = string_const("...", 3);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i30,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i30);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__process_file__process_addr_pair_5_0),
		mercury__process_file__main_4_0_i31,
		ENTRY(mercury__process_file__main_4_0));
Define_label(mercury__process_file__main_4_0_i31);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = string_const(" done.\n", 7);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i32,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i32);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	detstackvar(9) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__process_file__main_4_0_i33,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i33);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__prof_info__prof__set_entire_7_0);
	call_localret(ENTRY(mercury__prof_info__prof__set_entire_7_0),
		mercury__process_file__main_4_0_i34,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i34);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	if (((Integer) detstackvar(5) != ((Integer) 1)))
		GOTO_LABEL(mercury__process_file__main_4_0_i35);
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = string_const(" done.\n", 7);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__process_file__main_4_0_i38,
		ENTRY(mercury__process_file__main_4_0));
	}
Define_label(mercury__process_file__main_4_0_i38);
	update_prof_current_proc(LABEL(mercury__process_file__main_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__process_file__main_4_0_i35);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__process_file_module1)
	init_entry(mercury__process_file__process_addr_decl_2_6_0);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i2);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i5);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i6);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i7);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i10);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i9);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i12);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i13);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i14);
	init_label(mercury__process_file__process_addr_decl_2_6_0_i4);
BEGIN_CODE

/* code for predicate 'process_addr_decl_2'/6 in mode 0 */
Define_static(mercury__process_file__process_addr_decl_2_6_0);
	incr_sp_push_msg(6, "process_addr_decl_2");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__read__maybe_read_label_addr_3_0);
	call_localret(ENTRY(mercury__read__maybe_read_label_addr_3_0),
		mercury__process_file__process_addr_decl_2_6_0_i2,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i2);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__process_file__process_addr_decl_2_6_0_i4);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__read__read_label_name_3_0);
	call_localret(ENTRY(mercury__read__read_label_name_3_0),
		mercury__process_file__process_addr_decl_2_6_0_i5,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	{
	Declare_entry(mercury__prof_info__prof_node_init_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_init_2_0),
		mercury__process_file__process_addr_decl_2_6_0_i6,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__process_file__process_addr_decl_2_6_0_i7,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	r5 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__insert_4_0);
	call_localret(ENTRY(mercury__map__insert_4_0),
		mercury__process_file__process_addr_decl_2_6_0_i10,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__process_file__process_addr_decl_2_6_0_i9);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__process_file__process_addr_decl_2_6_0,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
Define_label(mercury__process_file__process_addr_decl_2_6_0_i9);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__process_file__lookup_addr_5_0),
		mercury__process_file__process_addr_decl_2_6_0_i12,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
Define_label(mercury__process_file__process_addr_decl_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__prof_info__prof_node_concat_to_name_list_3_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_concat_to_name_list_3_0),
		mercury__process_file__process_addr_decl_2_6_0_i13,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i13);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__process_file__process_addr_decl_2_6_0_i14,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
	}
Define_label(mercury__process_file__process_addr_decl_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_decl_2_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__process_file__process_addr_decl_2_6_0,
		STATIC(mercury__process_file__process_addr_decl_2_6_0));
Define_label(mercury__process_file__process_addr_decl_2_6_0_i4);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__process_file_module2)
	init_entry(mercury__process_file__process_addr_7_0);
	init_label(mercury__process_file__process_addr_7_0_i2);
	init_label(mercury__process_file__process_addr_7_0_i3);
	init_label(mercury__process_file__process_addr_7_0_i6);
	init_label(mercury__process_file__process_addr_7_0_i7);
	init_label(mercury__process_file__process_addr_7_0_i8);
	init_label(mercury__process_file__process_addr_7_0_i9);
	init_label(mercury__process_file__process_addr_7_0_i10);
	init_label(mercury__process_file__process_addr_7_0_i11);
	init_label(mercury__process_file__process_addr_7_0_i5);
	init_label(mercury__process_file__process_addr_7_0_i12);
	init_label(mercury__process_file__process_addr_7_0_i13);
	init_label(mercury__process_file__process_addr_7_0_i14);
BEGIN_CODE

/* code for predicate 'process_addr'/7 in mode 0 */
Define_static(mercury__process_file__process_addr_7_0);
	incr_sp_push_msg(5, "process_addr");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 4);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__process_file__process_addr_7_0_i2,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i2);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__io__see_4_0);
	call_localret(ENTRY(mercury__io__see_4_0),
		mercury__process_file__process_addr_7_0_i3,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i3);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__process_file__process_addr_7_0_i5);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__process_file__process_addr_7_0_i6,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i6);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	detstackvar(1) = (Integer) r1;
	r1 = string_const("error opening count file `", 26);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_7_0_i7,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i7);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	r2 = string_const("': ", 3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_7_0_i8,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i8);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_7_0_i9,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i9);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_7_0_i10,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i10);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__process_file__process_addr_7_0_i11,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i11);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__process_file__process_addr_7_0_i5);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__read__read_int_3_0);
	call_localret(ENTRY(mercury__read__read_int_3_0),
		mercury__process_file__process_addr_7_0_i12,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i12);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__read__read_int_3_0);
	call_localret(ENTRY(mercury__read__read_int_3_0),
		mercury__process_file__process_addr_7_0_i13,
		STATIC(mercury__process_file__process_addr_7_0));
	}
Define_label(mercury__process_file__process_addr_7_0_i13);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	r3 = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 0);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__process_file__process_addr_2_6_0),
		mercury__process_file__process_addr_7_0_i14,
		STATIC(mercury__process_file__process_addr_7_0));
Define_label(mercury__process_file__process_addr_7_0_i14);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_7_0));
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__seen_2_0);
	call_localret(ENTRY(mercury__io__seen_2_0),
		mercury__process_file__process_addr_7_0_i11,
		STATIC(mercury__process_file__process_addr_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__process_file_module3)
	init_entry(mercury__process_file__process_addr_2_6_0);
	init_label(mercury__process_file__process_addr_2_6_0_i2);
	init_label(mercury__process_file__process_addr_2_6_0_i5);
	init_label(mercury__process_file__process_addr_2_6_0_i8);
	init_label(mercury__process_file__process_addr_2_6_0_i10);
	init_label(mercury__process_file__process_addr_2_6_0_i11);
	init_label(mercury__process_file__process_addr_2_6_0_i12);
	init_label(mercury__process_file__process_addr_2_6_0_i7);
	init_label(mercury__process_file__process_addr_2_6_0_i13);
	init_label(mercury__process_file__process_addr_2_6_0_i14);
	init_label(mercury__process_file__process_addr_2_6_0_i4);
BEGIN_CODE

/* code for predicate 'process_addr_2'/6 in mode 0 */
Define_static(mercury__process_file__process_addr_2_6_0);
	incr_sp_push_msg(7, "process_addr_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__read__maybe_read_label_addr_3_0);
	call_localret(ENTRY(mercury__read__maybe_read_label_addr_3_0),
		mercury__process_file__process_addr_2_6_0_i2,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i2);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__process_file__process_addr_2_6_0_i4);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__read__read_int_3_0);
	call_localret(ENTRY(mercury__read__read_int_3_0),
		mercury__process_file__process_addr_2_6_0_i5,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__process_file__process_addr_2_6_0_i8,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__process_file__process_addr_2_6_0_i7);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__prof_info__prof_node_get_initial_counts_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_initial_counts_2_0),
		mercury__process_file__process_addr_2_6_0_i10,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	r1 = ((Integer) r1 + (Integer) detstackvar(4));
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__prof_info__prof_node_set_initial_counts_3_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_set_initial_counts_3_0),
		mercury__process_file__process_addr_2_6_0_i11,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__process_file__process_addr_2_6_0_i12,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	r2 = (Integer) r1;
	r1 = ((Integer) detstackvar(1) + (Integer) detstackvar(4));
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__process_file__process_addr_2_6_0,
		STATIC(mercury__process_file__process_addr_2_6_0));
Define_label(mercury__process_file__process_addr_2_6_0_i7);
	r1 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = string_const("\nWarning address %d not found!  Ignoring address and continuing computation.\n", 77);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__process_file__process_addr_2_6_0_i13,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i13);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__process_file__process_addr_2_6_0_i14,
		STATIC(mercury__process_file__process_addr_2_6_0));
	}
Define_label(mercury__process_file__process_addr_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_2_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__process_file__process_addr_2_6_0,
		STATIC(mercury__process_file__process_addr_2_6_0));
Define_label(mercury__process_file__process_addr_2_6_0_i4);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__process_file_module4)
	init_entry(mercury__process_file__process_addr_pair_5_0);
	init_label(mercury__process_file__process_addr_pair_5_0_i2);
	init_label(mercury__process_file__process_addr_pair_5_0_i3);
	init_label(mercury__process_file__process_addr_pair_5_0_i4);
	init_label(mercury__process_file__process_addr_pair_5_0_i5);
	init_label(mercury__process_file__process_addr_pair_5_0_i8);
	init_label(mercury__process_file__process_addr_pair_5_0_i9);
	init_label(mercury__process_file__process_addr_pair_5_0_i10);
	init_label(mercury__process_file__process_addr_pair_5_0_i11);
	init_label(mercury__process_file__process_addr_pair_5_0_i12);
	init_label(mercury__process_file__process_addr_pair_5_0_i13);
	init_label(mercury__process_file__process_addr_pair_5_0_i7);
	init_label(mercury__process_file__process_addr_pair_5_0_i14);
BEGIN_CODE

/* code for predicate 'process_addr_pair'/5 in mode 0 */
Define_static(mercury__process_file__process_addr_pair_5_0);
	incr_sp_push_msg(5, "process_addr_pair");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	{
	Declare_entry(mercury__relation__init_1_0);
	call_localret(ENTRY(mercury__relation__init_1_0),
		mercury__process_file__process_addr_pair_5_0_i2,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i2);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 2);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__process_file__process_addr_pair_5_0_i3,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i3);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 5);
	{
	Declare_entry(mercury__globals__io_lookup_string_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__process_file__process_addr_pair_5_0_i4,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i4);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	detstackvar(4) = (Integer) r1;
	{
	Declare_entry(mercury__io__see_4_0);
	call_localret(ENTRY(mercury__io__see_4_0),
		mercury__process_file__process_addr_pair_5_0_i5,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i5);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__process_file__process_addr_pair_5_0_i7);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__io__error_message_2_0);
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__process_file__process_addr_pair_5_0_i8,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i8);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = string_const("error opening pair file `", 25);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_pair_5_0_i9,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i9);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	r2 = string_const("': ", 3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_pair_5_0_i10,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i10);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_pair_5_0_i11,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i11);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__process_file__process_addr_pair_5_0_i12,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i12);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__process_file__process_addr_pair_5_0_i13,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
Define_label(mercury__process_file__process_addr_pair_5_0_i13);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__process_file__process_addr_pair_5_0_i7);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__process_file__process_addr_pair_2_7_0),
		mercury__process_file__process_addr_pair_5_0_i14,
		STATIC(mercury__process_file__process_addr_pair_5_0));
Define_label(mercury__process_file__process_addr_pair_5_0_i14);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_5_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__seen_2_0);
	call_localret(ENTRY(mercury__io__seen_2_0),
		mercury__process_file__process_addr_pair_5_0_i13,
		STATIC(mercury__process_file__process_addr_pair_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__process_file_module5)
	init_entry(mercury__process_file__process_addr_pair_2_7_0);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i2);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i5);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i6);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i7);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i8);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i9);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i10);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i11);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i12);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i15);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i16);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i17);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i13);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i18);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i19);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i20);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i24);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i25);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i26);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i21);
	init_label(mercury__process_file__process_addr_pair_2_7_0_i4);
BEGIN_CODE

/* code for predicate 'process_addr_pair_2'/7 in mode 0 */
Define_static(mercury__process_file__process_addr_pair_2_7_0);
	incr_sp_push_msg(12, "process_addr_pair_2");
	detstackvar(12) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__read__maybe_read_label_addr_3_0);
	call_localret(ENTRY(mercury__read__maybe_read_label_addr_3_0),
		mercury__process_file__process_addr_pair_2_7_0_i2,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i2);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__process_file__process_addr_pair_2_7_0_i4);
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__read__read_label_addr_3_0);
	call_localret(ENTRY(mercury__read__read_label_addr_3_0),
		mercury__process_file__process_addr_pair_2_7_0_i5,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__read__read_int_3_0);
	call_localret(ENTRY(mercury__read__read_int_3_0),
		mercury__process_file__process_addr_pair_2_7_0_i6,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r3 = (Integer) r2;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__process_file__lookup_addr_5_0),
		mercury__process_file__process_addr_pair_2_7_0_i7,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
Define_label(mercury__process_file__process_addr_pair_2_7_0_i7);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r3 = (Integer) r2;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__process_file__lookup_addr_5_0),
		mercury__process_file__process_addr_pair_2_7_0_i8,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
Define_label(mercury__process_file__process_addr_pair_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	detstackvar(8) = (Integer) r1;
	detstackvar(11) = (Integer) r2;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__prof_info__prof_node_get_pred_name_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_pred_name_2_0),
		mercury__process_file__process_addr_pair_2_7_0_i9,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__prof_info__prof_node_get_pred_name_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_pred_name_2_0),
		mercury__process_file__process_addr_pair_2_7_0_i10,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r3 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(6);
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__prof_info__prof_node_concat_to_child_4_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_concat_to_child_4_0),
		mercury__process_file__process_addr_pair_2_7_0_i11,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r5 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__process_file__process_addr_pair_2_7_0_i12,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	if (((Integer) detstackvar(5) == (Integer) detstackvar(4)))
		GOTO_LABEL(mercury__process_file__process_addr_pair_2_7_0_i13);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__prof_info__prof_node_get_total_calls_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_total_calls_2_0),
		mercury__process_file__process_addr_pair_2_7_0_i15,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i15);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r1 = ((Integer) r1 + (Integer) detstackvar(6));
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__prof_info__prof_node_set_total_calls_3_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_set_total_calls_3_0),
		mercury__process_file__process_addr_pair_2_7_0_i16,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__prof_info__prof_node_concat_to_parent_4_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_concat_to_parent_4_0),
		mercury__process_file__process_addr_pair_2_7_0_i17,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i17);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) r1;
	r10 = (Integer) detstackvar(11);
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	GOTO_LABEL(mercury__process_file__process_addr_pair_2_7_0_i19);
Define_label(mercury__process_file__process_addr_pair_2_7_0_i13);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__prof_info__prof_node_set_self_calls_3_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_set_self_calls_3_0),
		mercury__process_file__process_addr_pair_2_7_0_i18,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i18);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(9);
	r9 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) r1;
	r10 = (Integer) detstackvar(11);
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i19);
	detstackvar(1) = (Integer) r6;
	detstackvar(3) = (Integer) r7;
	detstackvar(9) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	detstackvar(11) = (Integer) r10;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__process_file__process_addr_pair_2_7_0_i20,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i20);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__process_file__process_addr_pair_2_7_0_i21);
	detstackvar(4) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__relation__add_element_4_0);
	call_localret(ENTRY(mercury__relation__add_element_4_0),
		mercury__process_file__process_addr_pair_2_7_0_i24,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i24);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	detstackvar(10) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	r3 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__relation__add_element_4_0);
	call_localret(ENTRY(mercury__relation__add_element_4_0),
		mercury__process_file__process_addr_pair_2_7_0_i25,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i25);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r4 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_string_0[];
	r1 = (Integer) mercury_data___base_type_info_string_0;
	}
	r3 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__relation__add_4_0);
	call_localret(ENTRY(mercury__relation__add_4_0),
		mercury__process_file__process_addr_pair_2_7_0_i26,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
	}
Define_label(mercury__process_file__process_addr_pair_2_7_0_i26);
	update_prof_current_proc(LABEL(mercury__process_file__process_addr_pair_2_7_0));
	r3 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__process_file__process_addr_pair_2_7_0,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
Define_label(mercury__process_file__process_addr_pair_2_7_0_i21);
	r3 = (Integer) detstackvar(3);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__process_file__process_addr_pair_2_7_0,
		STATIC(mercury__process_file__process_addr_pair_2_7_0));
Define_label(mercury__process_file__process_addr_pair_2_7_0_i4);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__process_file_module6)
	init_entry(mercury__process_file__lookup_addr_5_0);
	init_label(mercury__process_file__lookup_addr_5_0_i4);
	init_label(mercury__process_file__lookup_addr_5_0_i3);
	init_label(mercury__process_file__lookup_addr_5_0_i6);
	init_label(mercury__process_file__lookup_addr_5_0_i7);
	init_label(mercury__process_file__lookup_addr_5_0_i8);
BEGIN_CODE

/* code for predicate 'lookup_addr'/5 in mode 0 */
Define_static(mercury__process_file__lookup_addr_5_0);
	incr_sp_push_msg(3, "lookup_addr");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) r1;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__process_file__lookup_addr_5_0_i4,
		STATIC(mercury__process_file__lookup_addr_5_0));
	}
Define_label(mercury__process_file__lookup_addr_5_0_i4);
	update_prof_current_proc(LABEL(mercury__process_file__lookup_addr_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__process_file__lookup_addr_5_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__process_file__lookup_addr_5_0_i3);
	r1 = string_const("\nKey = %d\n", 10);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	tag_incr_hp(r3, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__string__format_3_0);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__process_file__lookup_addr_5_0_i6,
		STATIC(mercury__process_file__lookup_addr_5_0));
	}
Define_label(mercury__process_file__lookup_addr_5_0_i6);
	update_prof_current_proc(LABEL(mercury__process_file__lookup_addr_5_0));
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__process_file__lookup_addr_5_0_i7,
		STATIC(mercury__process_file__lookup_addr_5_0));
	}
Define_label(mercury__process_file__lookup_addr_5_0_i7);
	update_prof_current_proc(LABEL(mercury__process_file__lookup_addr_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = string_const("map__lookup: key not found\n", 27);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__process_file__lookup_addr_5_0_i8,
		STATIC(mercury__process_file__lookup_addr_5_0));
	}
Define_label(mercury__process_file__lookup_addr_5_0_i8);
	update_prof_current_proc(LABEL(mercury__process_file__lookup_addr_5_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__process_file_bunch_0(void)
{
	mercury__process_file_module0();
	mercury__process_file_module1();
	mercury__process_file_module2();
	mercury__process_file_module3();
	mercury__process_file_module4();
	mercury__process_file_module5();
	mercury__process_file_module6();
}

#endif

void mercury__process_file__init(void); /* suppress gcc warning */
void mercury__process_file__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__process_file_bunch_0();
#endif
}
