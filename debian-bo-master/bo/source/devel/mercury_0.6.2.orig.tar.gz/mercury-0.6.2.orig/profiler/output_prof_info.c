/*
** Automatically generated from `output_prof_info.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__output_prof_info__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___output_prof_info_child_0__ua10000_2_0);
Declare_static(mercury____Index___output_prof_info_parent_0__ua10000_2_0);
Declare_static(mercury____Index___output_prof_info_output_0__ua10000_2_0);
Define_extern_entry(mercury____Unify___output_prof_info__output_0_0);
Declare_label(mercury____Unify___output_prof_info__output_0_0_i2);
Declare_label(mercury____Unify___output_prof_info__output_0_0_i4);
Declare_label(mercury____Unify___output_prof_info__output_0_0_i1);
Define_extern_entry(mercury____Index___output_prof_info__output_0_0);
Define_extern_entry(mercury____Compare___output_prof_info__output_0_0);
Declare_label(mercury____Compare___output_prof_info__output_0_0_i4);
Declare_label(mercury____Compare___output_prof_info__output_0_0_i5);
Declare_label(mercury____Compare___output_prof_info__output_0_0_i3);
Declare_label(mercury____Compare___output_prof_info__output_0_0_i10);
Define_extern_entry(mercury____Unify___output_prof_info__output_prof_0_0);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i5);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i7);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i9);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i1027);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i14);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
Declare_label(mercury____Unify___output_prof_info__output_prof_0_0_i1);
Define_extern_entry(mercury____Index___output_prof_info__output_prof_0_0);
Declare_label(mercury____Index___output_prof_info__output_prof_0_0_i3);
Define_extern_entry(mercury____Compare___output_prof_info__output_prof_0_0);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i2);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i3);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i4);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i6);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i15);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i16);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i14);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i21);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i27);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i33);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i39);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i45);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i51);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i57);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i63);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i69);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i75);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i11);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i94);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i100);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i106);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i112);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i118);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i124);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i130);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i136);
Declare_label(mercury____Compare___output_prof_info__output_prof_0_0_i9);
Define_extern_entry(mercury____Unify___output_prof_info__parent_0_0);
Declare_label(mercury____Unify___output_prof_info__parent_0_0_i1);
Define_extern_entry(mercury____Index___output_prof_info__parent_0_0);
Define_extern_entry(mercury____Compare___output_prof_info__parent_0_0);
Declare_label(mercury____Compare___output_prof_info__parent_0_0_i4);
Declare_label(mercury____Compare___output_prof_info__parent_0_0_i5);
Declare_label(mercury____Compare___output_prof_info__parent_0_0_i3);
Declare_label(mercury____Compare___output_prof_info__parent_0_0_i10);
Declare_label(mercury____Compare___output_prof_info__parent_0_0_i16);
Declare_label(mercury____Compare___output_prof_info__parent_0_0_i22);
Define_extern_entry(mercury____Unify___output_prof_info__child_0_0);
Declare_label(mercury____Unify___output_prof_info__child_0_0_i1);
Define_extern_entry(mercury____Index___output_prof_info__child_0_0);
Define_extern_entry(mercury____Compare___output_prof_info__child_0_0);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i4);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i5);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i3);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i10);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i16);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i22);
Declare_label(mercury____Compare___output_prof_info__child_0_0_i28);

extern Word * mercury_data_output_prof_info__base_type_layout_child_0[];
Word * mercury_data_output_prof_info__base_type_info_child_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___output_prof_info__child_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___output_prof_info__child_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___output_prof_info__child_0_0),
	(Word *) (Integer) mercury_data_output_prof_info__base_type_layout_child_0
};

extern Word * mercury_data_output_prof_info__base_type_layout_output_0[];
Word * mercury_data_output_prof_info__base_type_info_output_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___output_prof_info__output_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___output_prof_info__output_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___output_prof_info__output_0_0),
	(Word *) (Integer) mercury_data_output_prof_info__base_type_layout_output_0
};

extern Word * mercury_data_output_prof_info__base_type_layout_output_prof_0[];
Word * mercury_data_output_prof_info__base_type_info_output_prof_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___output_prof_info__output_prof_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___output_prof_info__output_prof_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___output_prof_info__output_prof_0_0),
	(Word *) (Integer) mercury_data_output_prof_info__base_type_layout_output_prof_0
};

extern Word * mercury_data_output_prof_info__base_type_layout_parent_0[];
Word * mercury_data_output_prof_info__base_type_info_parent_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___output_prof_info__parent_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___output_prof_info__parent_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___output_prof_info__parent_0_0),
	(Word *) (Integer) mercury_data_output_prof_info__base_type_layout_parent_0
};

extern Word * mercury_data_output_prof_info__common_3[];
Word * mercury_data_output_prof_info__base_type_layout_parent_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_output_prof_info__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_output_prof_info__common_6[];
extern Word * mercury_data_output_prof_info__common_7[];
Word * mercury_data_output_prof_info__base_type_layout_output_prof_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_output_prof_info__common_6),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_output_prof_info__common_7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_output_prof_info__common_10[];
Word * mercury_data_output_prof_info__base_type_layout_output_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_output_prof_info__common_10),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_output_prof_info__common_11[];
Word * mercury_data_output_prof_info__base_type_layout_child_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_output_prof_info__common_11),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_output_prof_info__common_0[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_output_prof_info__common_1[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data___base_type_info_float_0[];
Word * mercury_data_output_prof_info__common_2[] = {
	(Word *) (Integer) mercury_data___base_type_info_float_0
};

Word * mercury_data_output_prof_info__common_3[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) string_const("parent", 6)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_output_prof_info__common_4[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_output_prof_info__base_type_info_parent_0
};

Word * mercury_data_output_prof_info__common_5[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_output_prof_info__base_type_info_child_0
};

Word * mercury_data_output_prof_info__common_6[] = {
	(Word *) ((Integer) 12),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_5),
	(Word *) string_const("output_prof", 11)
};

Word * mercury_data_output_prof_info__common_7[] = {
	(Word *) ((Integer) 9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_5),
	(Word *) string_const("output_cycle_prof", 17)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_output_prof_info__common_8[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0
};

Word * mercury_data_output_prof_info__common_9[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_output_prof_info__common_10[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_9),
	(Word *) string_const("output", 6)
};

Word * mercury_data_output_prof_info__common_11[] = {
	(Word *) ((Integer) 6),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_output_prof_info__common_1),
	(Word *) string_const("child", 5)
};

BEGIN_MODULE(mercury__output_prof_info_module0)
	init_entry(mercury____Index___output_prof_info_child_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___output_prof_info_child_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___output_prof_info_child_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module1)
	init_entry(mercury____Index___output_prof_info_parent_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___output_prof_info_parent_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___output_prof_info_parent_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module2)
	init_entry(mercury____Index___output_prof_info_output_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___output_prof_info_output_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___output_prof_info_output_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module3)
	init_entry(mercury____Unify___output_prof_info__output_0_0);
	init_label(mercury____Unify___output_prof_info__output_0_0_i2);
	init_label(mercury____Unify___output_prof_info__output_0_0_i4);
	init_label(mercury____Unify___output_prof_info__output_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___output_prof_info__output_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___output_prof_info__output_0_0_i2,
		ENTRY(mercury____Unify___output_prof_info__output_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___output_prof_info__output_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___output_prof_info__output_0_0_i4,
		ENTRY(mercury____Unify___output_prof_info__output_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___output_prof_info__output_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_0_0_i1);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___output_prof_info__output_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module4)
	init_entry(mercury____Index___output_prof_info__output_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___output_prof_info__output_0_0);
	tailcall(STATIC(mercury____Index___output_prof_info_output_0__ua10000_2_0),
		ENTRY(mercury____Index___output_prof_info__output_0_0));
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module5)
	init_entry(mercury____Compare___output_prof_info__output_0_0);
	init_label(mercury____Compare___output_prof_info__output_0_0_i4);
	init_label(mercury____Compare___output_prof_info__output_0_0_i5);
	init_label(mercury____Compare___output_prof_info__output_0_0_i3);
	init_label(mercury____Compare___output_prof_info__output_0_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___output_prof_info__output_0_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___output_prof_info__output_0_0_i4,
		ENTRY(mercury____Compare___output_prof_info__output_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_0_0_i3);
Define_label(mercury____Compare___output_prof_info__output_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___output_prof_info__output_0_0_i3);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___output_prof_info__output_0_0_i10,
		ENTRY(mercury____Compare___output_prof_info__output_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_0_0_i5);
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___output_prof_info__output_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module6)
	init_entry(mercury____Unify___output_prof_info__output_prof_0_0);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i5);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i7);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i9);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i1027);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i14);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	init_label(mercury____Unify___output_prof_info__output_prof_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___output_prof_info__output_prof_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1027);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 2))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 3))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 4))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 4)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 5))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 5)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 6)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 6))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 7)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 7))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 8));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 9));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 10));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 11));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 8));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 9));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 10));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 11));
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___output_prof_info__output_prof_0_0_i5,
		ENTRY(mercury____Unify___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___output_prof_info__output_prof_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___output_prof_info__output_prof_0_0_i7,
		ENTRY(mercury____Unify___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___output_prof_info__output_prof_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___output_prof_info__output_prof_0_0_i9,
		ENTRY(mercury____Unify___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i9);
	update_prof_current_proc(LABEL(mercury____Unify___output_prof_info__output_prof_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i1027);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(1), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if ((word_to_float((Integer) field(mktag(1), (Integer) r1, ((Integer) 2))) != word_to_float((Integer) field(mktag(1), (Integer) r2, ((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if ((word_to_float((Integer) field(mktag(1), (Integer) r1, ((Integer) 3))) != word_to_float((Integer) field(mktag(1), (Integer) r2, ((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if ((word_to_float((Integer) field(mktag(1), (Integer) r1, ((Integer) 4))) != word_to_float((Integer) field(mktag(1), (Integer) r2, ((Integer) 4)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 5)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 5))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 6)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 6))))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 7));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 8));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 7));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 8));
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___output_prof_info__output_prof_0_0_i14,
		ENTRY(mercury____Unify___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___output_prof_info__output_prof_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i1024);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___output_prof_info__output_prof_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module7)
	init_entry(mercury____Index___output_prof_info__output_prof_0_0);
	init_label(mercury____Index___output_prof_info__output_prof_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___output_prof_info__output_prof_0_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___output_prof_info__output_prof_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___output_prof_info__output_prof_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module8)
	init_entry(mercury____Compare___output_prof_info__output_prof_0_0);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i2);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i3);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i4);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i6);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i15);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i14);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i21);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i27);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i33);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i39);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i45);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i51);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i57);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i63);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i69);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i75);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i11);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i94);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i100);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i106);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i112);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i118);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i124);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i130);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i136);
	init_label(mercury____Compare___output_prof_info__output_prof_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___output_prof_info__output_prof_0_0);
	incr_sp_push_msg(23, "__Compare__");
	detstackvar(23) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___output_prof_info__output_prof_0_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i2,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___output_prof_info__output_prof_0_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i3,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(23);
	decr_sp_pop_msg(23);
	proceed();
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(23);
	decr_sp_pop_msg(23);
	proceed();
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i6);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(12) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(13) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(14) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 5));
	detstackvar(17) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 6));
	detstackvar(18) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 7));
	detstackvar(19) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 8));
	detstackvar(20) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 9));
	detstackvar(21) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 10));
	detstackvar(22) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 11));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 8));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 9));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 10));
	detstackvar(11) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 11));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i15,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i14);
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(23);
	decr_sp_pop_msg(23);
	proceed();
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i21,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i27,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i33,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i33);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i39,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(16);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i45,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i45);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(17);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i51,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(18);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i57,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i57);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(19);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i63,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i63);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(20);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i69,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i69);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(21);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i75,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i75);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	r2 = (Integer) detstackvar(11);
	r3 = (Integer) detstackvar(22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(23);
	decr_sp_pop_msg(23);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(10) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(11) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	detstackvar(12) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 4));
	detstackvar(13) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 5));
	detstackvar(14) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 6));
	detstackvar(15) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 7));
	detstackvar(16) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 8));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 6));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 7));
	detstackvar(8) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 8));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i94,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i94);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i100,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i100);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(10);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i106,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i106);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i112,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i112);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i118,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i118);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(13);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i124,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i124);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(14);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i130,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i130);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(15);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___output_prof_info__output_prof_0_0_i136,
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i136);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__output_prof_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__output_prof_0_0_i16);
	r1 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(23);
	decr_sp_pop_msg(23);
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
Define_label(mercury____Compare___output_prof_info__output_prof_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(23);
	decr_sp_pop_msg(23);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___output_prof_info__output_prof_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module9)
	init_entry(mercury____Unify___output_prof_info__parent_0_0);
	init_label(mercury____Unify___output_prof_info__parent_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___output_prof_info__parent_0_0);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___output_prof_info__parent_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___output_prof_info__parent_0_0_i1);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 2))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__parent_0_0_i1);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 3))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__parent_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 4)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 4))))
		GOTO_LABEL(mercury____Unify___output_prof_info__parent_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___output_prof_info__parent_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module10)
	init_entry(mercury____Index___output_prof_info__parent_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___output_prof_info__parent_0_0);
	tailcall(STATIC(mercury____Index___output_prof_info_parent_0__ua10000_2_0),
		ENTRY(mercury____Index___output_prof_info__parent_0_0));
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module11)
	init_entry(mercury____Compare___output_prof_info__parent_0_0);
	init_label(mercury____Compare___output_prof_info__parent_0_0_i4);
	init_label(mercury____Compare___output_prof_info__parent_0_0_i5);
	init_label(mercury____Compare___output_prof_info__parent_0_0_i3);
	init_label(mercury____Compare___output_prof_info__parent_0_0_i10);
	init_label(mercury____Compare___output_prof_info__parent_0_0_i16);
	init_label(mercury____Compare___output_prof_info__parent_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___output_prof_info__parent_0_0);
	incr_sp_push_msg(9, "__Compare__");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___output_prof_info__parent_0_0_i4,
		ENTRY(mercury____Compare___output_prof_info__parent_0_0));
	}
Define_label(mercury____Compare___output_prof_info__parent_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__parent_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__parent_0_0_i3);
Define_label(mercury____Compare___output_prof_info__parent_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Compare___output_prof_info__parent_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__parent_0_0_i10,
		ENTRY(mercury____Compare___output_prof_info__parent_0_0));
	}
Define_label(mercury____Compare___output_prof_info__parent_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__parent_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__parent_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__parent_0_0_i16,
		ENTRY(mercury____Compare___output_prof_info__parent_0_0));
	}
Define_label(mercury____Compare___output_prof_info__parent_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__parent_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__parent_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__parent_0_0_i22,
		ENTRY(mercury____Compare___output_prof_info__parent_0_0));
	}
Define_label(mercury____Compare___output_prof_info__parent_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__parent_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__parent_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___output_prof_info__parent_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module12)
	init_entry(mercury____Unify___output_prof_info__child_0_0);
	init_label(mercury____Unify___output_prof_info__child_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___output_prof_info__child_0_0);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___output_prof_info__child_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___output_prof_info__child_0_0_i1);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 2))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__child_0_0_i1);
	if ((word_to_float((Integer) field(mktag(0), (Integer) r1, ((Integer) 3))) != word_to_float((Integer) field(mktag(0), (Integer) r2, ((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___output_prof_info__child_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 4)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 4))))
		GOTO_LABEL(mercury____Unify___output_prof_info__child_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 5)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 5))))
		GOTO_LABEL(mercury____Unify___output_prof_info__child_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___output_prof_info__child_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module13)
	init_entry(mercury____Index___output_prof_info__child_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___output_prof_info__child_0_0);
	tailcall(STATIC(mercury____Index___output_prof_info_child_0__ua10000_2_0),
		ENTRY(mercury____Index___output_prof_info__child_0_0));
END_MODULE

BEGIN_MODULE(mercury__output_prof_info_module14)
	init_entry(mercury____Compare___output_prof_info__child_0_0);
	init_label(mercury____Compare___output_prof_info__child_0_0_i4);
	init_label(mercury____Compare___output_prof_info__child_0_0_i5);
	init_label(mercury____Compare___output_prof_info__child_0_0_i3);
	init_label(mercury____Compare___output_prof_info__child_0_0_i10);
	init_label(mercury____Compare___output_prof_info__child_0_0_i16);
	init_label(mercury____Compare___output_prof_info__child_0_0_i22);
	init_label(mercury____Compare___output_prof_info__child_0_0_i28);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___output_prof_info__child_0_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 5));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	detstackvar(9) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	detstackvar(10) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 5));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___output_prof_info__child_0_0_i4,
		ENTRY(mercury____Compare___output_prof_info__child_0_0));
	}
Define_label(mercury____Compare___output_prof_info__child_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__child_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__child_0_0_i3);
Define_label(mercury____Compare___output_prof_info__child_0_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___output_prof_info__child_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__child_0_0_i10,
		ENTRY(mercury____Compare___output_prof_info__child_0_0));
	}
Define_label(mercury____Compare___output_prof_info__child_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__child_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__child_0_0_i5);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__child_0_0_i16,
		ENTRY(mercury____Compare___output_prof_info__child_0_0));
	}
Define_label(mercury____Compare___output_prof_info__child_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__child_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__child_0_0_i5);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__builtin_compare_float_3_0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___output_prof_info__child_0_0_i22,
		ENTRY(mercury____Compare___output_prof_info__child_0_0));
	}
Define_label(mercury____Compare___output_prof_info__child_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__child_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__child_0_0_i5);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(9);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___output_prof_info__child_0_0_i28,
		ENTRY(mercury____Compare___output_prof_info__child_0_0));
	}
Define_label(mercury____Compare___output_prof_info__child_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___output_prof_info__child_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___output_prof_info__child_0_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(10);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___output_prof_info__child_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__output_prof_info_bunch_0(void)
{
	mercury__output_prof_info_module0();
	mercury__output_prof_info_module1();
	mercury__output_prof_info_module2();
	mercury__output_prof_info_module3();
	mercury__output_prof_info_module4();
	mercury__output_prof_info_module5();
	mercury__output_prof_info_module6();
	mercury__output_prof_info_module7();
	mercury__output_prof_info_module8();
	mercury__output_prof_info_module9();
	mercury__output_prof_info_module10();
	mercury__output_prof_info_module11();
	mercury__output_prof_info_module12();
	mercury__output_prof_info_module13();
	mercury__output_prof_info_module14();
}

#endif

void mercury__output_prof_info__init(void); /* suppress gcc warning */
void mercury__output_prof_info__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__output_prof_info_bunch_0();
#endif
}
