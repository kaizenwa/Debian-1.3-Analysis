/*
** Automatically generated from `generate_output.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__generate_output__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__generate_output__main_5_0);
Declare_label(mercury__generate_output__main_5_0_i2);
Declare_label(mercury__generate_output__main_5_0_i3);
Declare_label(mercury__generate_output__main_5_0_i4);
Declare_label(mercury__generate_output__main_5_0_i5);
Declare_label(mercury__generate_output__main_5_0_i6);
Declare_label(mercury__generate_output__main_5_0_i7);
Declare_label(mercury__generate_output__main_5_0_i8);
Declare_label(mercury__generate_output__main_5_0_i9);
Declare_label(mercury__generate_output__main_5_0_i10);
Declare_label(mercury__generate_output__main_5_0_i11);
Declare_label(mercury__generate_output__main_5_0_i12);
Declare_label(mercury__generate_output__main_5_0_i13);
Declare_label(mercury__generate_output__main_5_0_i14);
Declare_label(mercury__generate_output__main_5_0_i15);
Define_extern_entry(mercury__generate_output__checked_float_divide_3_0);
Declare_label(mercury__generate_output__checked_float_divide_3_0_i2);
Declare_static(mercury__generate_output__process_prof_node_list_7_0);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i7);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i8);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i9);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i4);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i10);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i11);
Declare_label(mercury__generate_output__process_prof_node_list_7_0_i1003);
Declare_static(mercury__generate_output__process_prof_node_4_0);
Declare_label(mercury__generate_output__process_prof_node_4_0_i2);
Declare_label(mercury__generate_output__process_prof_node_4_0_i4);
Declare_label(mercury__generate_output__process_prof_node_4_0_i5);
Declare_label(mercury__generate_output__process_prof_node_4_0_i6);
Declare_label(mercury__generate_output__process_prof_node_4_0_i7);
Declare_label(mercury__generate_output__process_prof_node_4_0_i8);
Declare_label(mercury__generate_output__process_prof_node_4_0_i12);
Declare_label(mercury__generate_output__process_prof_node_4_0_i13);
Declare_label(mercury__generate_output__process_prof_node_4_0_i14);
Declare_label(mercury__generate_output__process_prof_node_4_0_i15);
Declare_label(mercury__generate_output__process_prof_node_4_0_i18);
Declare_label(mercury__generate_output__process_prof_node_4_0_i19);
Declare_label(mercury__generate_output__process_prof_node_4_0_i20);
Declare_label(mercury__generate_output__process_prof_node_4_0_i21);
Declare_label(mercury__generate_output__process_prof_node_4_0_i24);
Declare_label(mercury__generate_output__process_prof_node_4_0_i25);
Declare_label(mercury__generate_output__process_prof_node_4_0_i26);
Declare_label(mercury__generate_output__process_prof_node_4_0_i29);
Declare_label(mercury__generate_output__process_prof_node_4_0_i30);
Declare_label(mercury__generate_output__process_prof_node_4_0_i31);
Declare_label(mercury__generate_output__process_prof_node_4_0_i28);
Declare_label(mercury__generate_output__process_prof_node_4_0_i27);
Declare_label(mercury__generate_output__process_prof_node_4_0_i32);
Declare_label(mercury__generate_output__process_prof_node_4_0_i33);
Declare_label(mercury__generate_output__process_prof_node_4_0_i34);
Declare_label(mercury__generate_output__process_prof_node_4_0_i35);
Declare_static(mercury__generate_output__construct_name_2_0);
Declare_label(mercury__generate_output__construct_name_2_0_i4);
Declare_label(mercury__generate_output__construct_name_2_0_i5);
Declare_label(mercury__generate_output__construct_name_2_0_i1002);
Declare_static(mercury__generate_output__remove_cycle_members_7_0);
Declare_label(mercury__generate_output__remove_cycle_members_7_0_i4);
Declare_label(mercury__generate_output__remove_cycle_members_7_0_i7);
Declare_label(mercury__generate_output__remove_cycle_members_7_0_i11);
Declare_label(mercury__generate_output__remove_cycle_members_7_0_i9);
Declare_label(mercury__generate_output__remove_cycle_members_7_0_i12);
Declare_label(mercury__generate_output__remove_cycle_members_7_0_i1006);
Declare_static(mercury__generate_output__process_prof_node_parents_3_7_0);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i4);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i7);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i6);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i9);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i10);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i11);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i12);
Declare_label(mercury__generate_output__process_prof_node_parents_3_7_0_i1003);
Declare_static(mercury__generate_output__process_prof_node_children_6_0);
Declare_label(mercury__generate_output__process_prof_node_children_6_0_i4);
Declare_label(mercury__generate_output__process_prof_node_children_6_0_i5);
Declare_label(mercury__generate_output__process_prof_node_children_6_0_i6);
Declare_label(mercury__generate_output__process_prof_node_children_6_0_i7);
Declare_label(mercury__generate_output__process_prof_node_children_6_0_i1002);
Declare_static(mercury__generate_output__remove_child_cycle_members_5_0);
Declare_label(mercury__generate_output__remove_child_cycle_members_5_0_i4);
Declare_label(mercury__generate_output__remove_child_cycle_members_5_0_i7);
Declare_label(mercury__generate_output__remove_child_cycle_members_5_0_i11);
Declare_label(mercury__generate_output__remove_child_cycle_members_5_0_i9);
Declare_label(mercury__generate_output__remove_child_cycle_members_5_0_i12);
Declare_label(mercury__generate_output__remove_child_cycle_members_5_0_i1006);
Declare_static(mercury__generate_output__process_prof_node_children_2_4_0);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i4);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i5);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i8);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i7);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i10);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i11);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i12);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i13);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i14);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i15);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i16);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i17);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i18);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i19);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i20);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i21);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i22);
Declare_label(mercury__generate_output__process_prof_node_children_2_4_0_i1003);
Declare_static(mercury__generate_output__assign_index_numbers_2_4_0);
Declare_label(mercury__generate_output__assign_index_numbers_2_4_0_i4);
Declare_label(mercury__generate_output__assign_index_numbers_2_4_0_i1002);

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_generate_output__base_type_layout_profiling_0[];
Word * mercury_data_generate_output__base_type_info_profiling_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_generate_output__base_type_layout_profiling_0
};

extern Word * mercury_data_generate_output__common_2[];
Word * mercury_data_generate_output__base_type_layout_profiling_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_generate_output__common_2),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data___base_type_info_string_0[];
extern Word * mercury_data_output_prof_info__base_type_info_output_prof_0[];
Word * mercury_data_generate_output__common_0[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0
};

extern Word * mercury_data_rbtree__base_type_info_rbtree_2[];
extern Word * mercury_data___base_type_info_float_0[];
Word * mercury_data_generate_output__common_1[] = {
	(Word *) (Integer) mercury_data_rbtree__base_type_info_rbtree_2,
	(Word *) (Integer) mercury_data___base_type_info_float_0,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_generate_output__common_2[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_generate_output__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_generate_output__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_generate_output__common_1),
	(Word *) string_const("profiling", 9)
};

BEGIN_MODULE(mercury__generate_output_module0)
	init_entry(mercury__generate_output__main_5_0);
	init_label(mercury__generate_output__main_5_0_i2);
	init_label(mercury__generate_output__main_5_0_i3);
	init_label(mercury__generate_output__main_5_0_i4);
	init_label(mercury__generate_output__main_5_0_i5);
	init_label(mercury__generate_output__main_5_0_i6);
	init_label(mercury__generate_output__main_5_0_i7);
	init_label(mercury__generate_output__main_5_0_i8);
	init_label(mercury__generate_output__main_5_0_i9);
	init_label(mercury__generate_output__main_5_0_i10);
	init_label(mercury__generate_output__main_5_0_i11);
	init_label(mercury__generate_output__main_5_0_i12);
	init_label(mercury__generate_output__main_5_0_i13);
	init_label(mercury__generate_output__main_5_0_i14);
	init_label(mercury__generate_output__main_5_0_i15);
BEGIN_CODE

/* code for predicate 'generate_output__main'/5 in mode 0 */
Define_entry(mercury__generate_output__main_5_0);
	incr_sp_push_msg(6, "generate_output__main");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__prof_info__prof__get_entire_7_0);
	call_localret(ENTRY(mercury__prof_info__prof__get_entire_7_0),
		mercury__generate_output__main_5_0_i2,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i2);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r1 = (Integer) r3;
	detstackvar(3) = (Integer) r5;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__main_5_0_i3,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i3);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_prof_info__base_type_info_prof_node_0[];
	r2 = (Integer) mercury_data_prof_info__base_type_info_prof_node_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__values_2_0);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__generate_output__main_5_0_i4,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__generate_output__main_5_0_i5,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i5);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_float_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__rbtree__init_1_0);
	call_localret(ENTRY(mercury__rbtree__init_1_0),
		mercury__generate_output__main_5_0_i6,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i6);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_float_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__rbtree__init_1_0);
	call_localret(ENTRY(mercury__rbtree__init_1_0),
		mercury__generate_output__main_5_0_i7,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r2 = (Integer) detstackvar(2);
	tag_incr_hp(r3, mktag(0), ((Integer) 3));
	detstackvar(2) = (Integer) r3;
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r1;
	r1 = ((Integer) 1);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__generate_output__main_5_0_i8,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i8);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r3 = (Integer) r1;
	r5 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__generate_output__process_prof_node_list_7_0),
		mercury__generate_output__main_5_0_i9,
		ENTRY(mercury__generate_output__main_5_0));
Define_label(mercury__generate_output__main_5_0_i9);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_float_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__rbtree__values_2_0);
	call_localret(ENTRY(mercury__rbtree__values_2_0),
		mercury__generate_output__main_5_0_i10,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i10);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_float_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__rbtree__values_2_0);
	call_localret(ENTRY(mercury__rbtree__values_2_0),
		mercury__generate_output__main_5_0_i11,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i11);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__generate_output__main_5_0_i12,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i12);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__generate_output__main_5_0_i13,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i13);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	r3 = ((Integer) 1);
	call_localret(STATIC(mercury__generate_output__assign_index_numbers_2_4_0),
		mercury__generate_output__main_5_0_i14,
		ENTRY(mercury__generate_output__main_5_0));
Define_label(mercury__generate_output__main_5_0_i14);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__generate_output__main_5_0_i15,
		ENTRY(mercury__generate_output__main_5_0));
	}
Define_label(mercury__generate_output__main_5_0_i15);
	update_prof_current_proc(LABEL(mercury__generate_output__main_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module1)
	init_entry(mercury__generate_output__checked_float_divide_3_0);
	init_label(mercury__generate_output__checked_float_divide_3_0_i2);
BEGIN_CODE

/* code for predicate 'checked_float_divide'/3 in mode 0 */
Define_entry(mercury__generate_output__checked_float_divide_3_0);
	{
	static const Float mercury_float_const_0 = 0;
	if ((word_to_float((Integer) r2) != ((Float) 0.00000000000000)))
		GOTO_LABEL(mercury__generate_output__checked_float_divide_3_0_i2);
	}
	{
	static const Float mercury_float_const_0 = 0;
	r1 = (Word)(&mercury_float_const_0);
	}
	proceed();
Define_label(mercury__generate_output__checked_float_divide_3_0_i2);
	r1 = float_to_word(word_to_float((Integer) r1) / word_to_float((Integer) r2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module2)
	init_entry(mercury__generate_output__process_prof_node_list_7_0);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i7);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i8);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i9);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i4);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i10);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i11);
	init_label(mercury__generate_output__process_prof_node_list_7_0_i1003);
BEGIN_CODE

/* code for predicate 'process_prof_node_list'/7 in mode 0 */
Define_static(mercury__generate_output__process_prof_node_list_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_list_7_0_i1003);
	r6 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	incr_sp_push_msg(7, "process_prof_node_list");
	detstackvar(7) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury__generate_output__process_prof_node_list_7_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r7;
	{
	Declare_entry(mercury__prof_info__prof_node_get_pred_name_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_pred_name_2_0),
		mercury__generate_output__process_prof_node_list_7_0_i7,
		STATIC(mercury__generate_output__process_prof_node_list_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_list_7_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_list_7_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = string_const("\n\t% Processing predicate ", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__generate_output__process_prof_node_list_7_0_i8,
		STATIC(mercury__generate_output__process_prof_node_list_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_list_7_0_i8);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_list_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__generate_output__process_prof_node_list_7_0_i9,
		STATIC(mercury__generate_output__process_prof_node_list_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_list_7_0_i9);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_list_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(6);
	GOTO_LABEL(mercury__generate_output__process_prof_node_list_7_0_i10);
Define_label(mercury__generate_output__process_prof_node_list_7_0_i4);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) r3;
	r3 = (Integer) r4;
	tempr2 = (Integer) r5;
	r5 = (Integer) r6;
	r6 = (Integer) tempr2;
	r4 = (Integer) tempr1;
	r1 = (Integer) r7;
	}
Define_label(mercury__generate_output__process_prof_node_list_7_0_i10);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	call_localret(STATIC(mercury__generate_output__process_prof_node_4_0),
		mercury__generate_output__process_prof_node_list_7_0_i11,
		STATIC(mercury__generate_output__process_prof_node_list_7_0));
Define_label(mercury__generate_output__process_prof_node_list_7_0_i11);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_list_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__generate_output__process_prof_node_list_7_0,
		STATIC(mercury__generate_output__process_prof_node_list_7_0));
Define_label(mercury__generate_output__process_prof_node_list_7_0_i1003);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module3)
	init_entry(mercury__generate_output__process_prof_node_4_0);
	init_label(mercury__generate_output__process_prof_node_4_0_i2);
	init_label(mercury__generate_output__process_prof_node_4_0_i4);
	init_label(mercury__generate_output__process_prof_node_4_0_i5);
	init_label(mercury__generate_output__process_prof_node_4_0_i6);
	init_label(mercury__generate_output__process_prof_node_4_0_i7);
	init_label(mercury__generate_output__process_prof_node_4_0_i8);
	init_label(mercury__generate_output__process_prof_node_4_0_i12);
	init_label(mercury__generate_output__process_prof_node_4_0_i13);
	init_label(mercury__generate_output__process_prof_node_4_0_i14);
	init_label(mercury__generate_output__process_prof_node_4_0_i15);
	init_label(mercury__generate_output__process_prof_node_4_0_i18);
	init_label(mercury__generate_output__process_prof_node_4_0_i19);
	init_label(mercury__generate_output__process_prof_node_4_0_i20);
	init_label(mercury__generate_output__process_prof_node_4_0_i21);
	init_label(mercury__generate_output__process_prof_node_4_0_i24);
	init_label(mercury__generate_output__process_prof_node_4_0_i25);
	init_label(mercury__generate_output__process_prof_node_4_0_i26);
	init_label(mercury__generate_output__process_prof_node_4_0_i29);
	init_label(mercury__generate_output__process_prof_node_4_0_i30);
	init_label(mercury__generate_output__process_prof_node_4_0_i31);
	init_label(mercury__generate_output__process_prof_node_4_0_i28);
	init_label(mercury__generate_output__process_prof_node_4_0_i27);
	init_label(mercury__generate_output__process_prof_node_4_0_i32);
	init_label(mercury__generate_output__process_prof_node_4_0_i33);
	init_label(mercury__generate_output__process_prof_node_4_0_i34);
	init_label(mercury__generate_output__process_prof_node_4_0_i35);
BEGIN_CODE

/* code for predicate 'process_prof_node'/4 in mode 0 */
Define_static(mercury__generate_output__process_prof_node_4_0);
	incr_sp_push_msg(19, "process_prof_node");
	detstackvar(19) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	{
	Declare_entry(mercury__prof_info__prof_node__type_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node__type_2_0),
		mercury__generate_output__process_prof_node_4_0_i2,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i2);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i4);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__generate_output__process_prof_node_4_0_i4);
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__prof_info__prof__get_entire_7_0);
	call_localret(ENTRY(mercury__prof_info__prof__get_entire_7_0),
		mercury__generate_output__process_prof_node_4_0_i5,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i5);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	detstackvar(6) = (Integer) r6;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_4_0_i6,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i6);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__prof_info__prof_node__get_entire_pred_10_0);
	call_localret(ENTRY(mercury__prof_info__prof_node__get_entire_pred_10_0),
		mercury__generate_output__process_prof_node_4_0_i7,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	if (((Integer) r5 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i8);
	if (((Integer) r6 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i8);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__generate_output__process_prof_node_4_0_i8);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(3);
	detstackvar(14) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(15) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(16) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) r9;
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r3;
	detstackvar(9) = (Integer) r4;
	detstackvar(10) = (Integer) r5;
	detstackvar(11) = (Integer) r6;
	detstackvar(12) = (Integer) r7;
	detstackvar(13) = (Integer) r8;
	call_localret(STATIC(mercury__generate_output__construct_name_2_0),
		mercury__generate_output__process_prof_node_4_0_i12,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i12);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__generate_output__process_prof_node_4_0_i13,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i13);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r2 = (Integer) detstackvar(8);
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_4_0_i14,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i14);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	{
	static const Float mercury_float_const_0 = 0;
	if ((word_to_float((Integer) detstackvar(1)) != ((Float) 0.00000000000000)))
		GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i15);
	}
	r16 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r10 = (Integer) detstackvar(12);
	r11 = (Integer) detstackvar(13);
	r12 = (Integer) detstackvar(14);
	r13 = (Integer) detstackvar(15);
	r14 = (Integer) detstackvar(16);
	r15 = (Integer) detstackvar(8);
	{
	static const Float mercury_float_const_0 = 0;
	r17 = (Word)(&mercury_float_const_0);
	}
	{
	static const Float mercury_float_const_0 = 0;
	r18 = (Word)(&mercury_float_const_0);
	}
	GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i18);
Define_label(mercury__generate_output__process_prof_node_4_0_i15);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(9);
	r16 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(7);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) detstackvar(11);
	r10 = (Integer) detstackvar(12);
	r11 = (Integer) detstackvar(13);
	r12 = (Integer) detstackvar(14);
	r13 = (Integer) detstackvar(15);
	r14 = (Integer) detstackvar(16);
	r15 = (Integer) detstackvar(8);
	{
	static const Float mercury_float_const_100 = 100;
	r17 = float_to_word(((word_to_float((Integer) r16) + word_to_float((Integer) r7)) / word_to_float((Integer) tempr1)) * ((Float) 100.000000000000));
	}
	{
	static const Float mercury_float_const_100 = 100;
	r18 = float_to_word((word_to_float((Integer) r16) / word_to_float((Integer) tempr1)) * ((Float) 100.000000000000));
	}
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i18);
	detstackvar(2) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(7) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(11) = (Integer) r9;
	detstackvar(12) = (Integer) r10;
	detstackvar(13) = (Integer) r11;
	detstackvar(14) = (Integer) r12;
	detstackvar(15) = (Integer) r13;
	detstackvar(16) = (Integer) r14;
	detstackvar(8) = (Integer) r15;
	detstackvar(1) = (Integer) r16;
	detstackvar(4) = (Integer) r17;
	detstackvar(17) = (Integer) r18;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_4_0_i19,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i19);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_4_0_i20,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i20);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	{
	static const Float mercury_float_const_0 = 0;
	if ((word_to_float((Integer) detstackvar(5)) != ((Float) 0.00000000000000)))
		GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i21);
	}
	r5 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(12);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(14);
	r10 = (Integer) detstackvar(15);
	r11 = (Integer) detstackvar(16);
	r12 = (Integer) detstackvar(8);
	r13 = (Integer) detstackvar(4);
	r14 = (Integer) detstackvar(17);
	{
	static const Float mercury_float_const_0 = 0;
	r15 = (Word)(&mercury_float_const_0);
	}
	{
	static const Float mercury_float_const_0 = 0;
	r16 = (Word)(&mercury_float_const_0);
	}
	GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i24);
Define_label(mercury__generate_output__process_prof_node_4_0_i21);
	{
	Word tempr1, tempr2, tempr3;
	tempr1 = (Integer) detstackvar(5);
	tempr2 = (Integer) detstackvar(1);
	tempr3 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(12);
	r3 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(11);
	r8 = (Integer) detstackvar(13);
	r9 = (Integer) detstackvar(14);
	r10 = (Integer) detstackvar(15);
	r11 = (Integer) detstackvar(16);
	r12 = (Integer) detstackvar(8);
	r13 = (Integer) detstackvar(4);
	r14 = (Integer) detstackvar(17);
	r15 = float_to_word((word_to_float((Integer) tempr2) / word_to_float((Integer) tempr1)) * word_to_float((Integer) tempr3));
	r16 = float_to_word(((word_to_float((Integer) tempr2) + word_to_float((Integer) detstackvar(9))) / word_to_float((Integer) tempr1)) * word_to_float((Integer) tempr3));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i24);
	detstackvar(2) = (Integer) r5;
	detstackvar(6) = (Integer) r4;
	detstackvar(3) = (Integer) r6;
	detstackvar(7) = (Integer) r3;
	detstackvar(11) = (Integer) r7;
	detstackvar(12) = (Integer) r2;
	detstackvar(13) = (Integer) r8;
	detstackvar(14) = (Integer) r9;
	detstackvar(15) = (Integer) r10;
	detstackvar(16) = (Integer) r11;
	detstackvar(8) = (Integer) r12;
	detstackvar(4) = (Integer) r13;
	detstackvar(17) = (Integer) r14;
	detstackvar(1) = (Integer) r15;
	detstackvar(5) = (Integer) r16;
	call_localret(STATIC(mercury__generate_output__remove_cycle_members_7_0),
		mercury__generate_output__process_prof_node_4_0_i25,
		STATIC(mercury__generate_output__process_prof_node_4_0));
Define_label(mercury__generate_output__process_prof_node_4_0_i25);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	detstackvar(9) = (Integer) r3;
	detstackvar(10) = (Integer) r2;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_4_0_i26,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i26);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	if (((Integer) detstackvar(10) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i28);
	detstackvar(18) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_parent_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	}
	{
	Declare_entry(mercury__rbtree__init_1_0);
	call_localret(ENTRY(mercury__rbtree__init_1_0),
		mercury__generate_output__process_prof_node_4_0_i29,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i29);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(18);
	r5 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__generate_output__process_prof_node_parents_3_7_0),
		mercury__generate_output__process_prof_node_4_0_i30,
		STATIC(mercury__generate_output__process_prof_node_4_0));
Define_label(mercury__generate_output__process_prof_node_4_0_i30);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_parent_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	}
	{
	Declare_entry(mercury__rbtree__values_2_0);
	call_localret(ENTRY(mercury__rbtree__values_2_0),
		mercury__generate_output__process_prof_node_4_0_i31,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i31);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r16 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(14);
	r9 = (Integer) detstackvar(15);
	r10 = (Integer) detstackvar(16);
	r11 = (Integer) detstackvar(8);
	r12 = (Integer) detstackvar(4);
	r13 = (Integer) detstackvar(17);
	r14 = (Integer) detstackvar(1);
	r15 = (Integer) detstackvar(5);
	r17 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__generate_output__process_prof_node_4_0_i27);
Define_label(mercury__generate_output__process_prof_node_4_0_i28);
	r4 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(11);
	r6 = (Integer) detstackvar(12);
	r7 = (Integer) detstackvar(13);
	r8 = (Integer) detstackvar(14);
	r9 = (Integer) detstackvar(15);
	r10 = (Integer) detstackvar(16);
	r11 = (Integer) detstackvar(8);
	r12 = (Integer) detstackvar(4);
	r13 = (Integer) detstackvar(17);
	r14 = (Integer) detstackvar(1);
	r15 = (Integer) detstackvar(5);
	r16 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r17 = (Integer) detstackvar(9);
Define_label(mercury__generate_output__process_prof_node_4_0_i27);
	detstackvar(3) = (Integer) r5;
	detstackvar(7) = (Integer) r2;
	detstackvar(12) = (Integer) r6;
	detstackvar(13) = (Integer) r7;
	detstackvar(14) = (Integer) r8;
	detstackvar(15) = (Integer) r9;
	detstackvar(16) = (Integer) r10;
	detstackvar(8) = (Integer) r11;
	detstackvar(4) = (Integer) r12;
	detstackvar(17) = (Integer) r13;
	detstackvar(1) = (Integer) r14;
	detstackvar(5) = (Integer) r15;
	detstackvar(2) = (Integer) r16;
	detstackvar(9) = (Integer) r17;
	call_localret(STATIC(mercury__generate_output__process_prof_node_children_6_0),
		mercury__generate_output__process_prof_node_4_0_i32,
		STATIC(mercury__generate_output__process_prof_node_4_0));
Define_label(mercury__generate_output__process_prof_node_4_0_i32);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	tag_incr_hp(r5, mktag(0), ((Integer) 12));
	field(mktag(0), (Integer) r5, ((Integer) 11)) = (Integer) r2;
	field(mktag(0), (Integer) r5, ((Integer) 9)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_output_prof_0;
	r3 = (Integer) detstackvar(14);
	r4 = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r5, ((Integer) 10)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r5, ((Integer) 7)) = (Integer) detstackvar(13);
	field(mktag(0), (Integer) r5, ((Integer) 6)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r5, ((Integer) 5)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r5, ((Integer) 4)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r5, ((Integer) 3)) = (Integer) detstackvar(17);
	field(mktag(0), (Integer) r5, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(8);
	field(mktag(0), (Integer) r5, ((Integer) 8)) = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__generate_output__process_prof_node_4_0_i33,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i33);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_float_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(15);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__rbtree__insert_duplicate_4_0);
	call_localret(ENTRY(mercury__rbtree__insert_duplicate_4_0),
		mercury__generate_output__process_prof_node_4_0_i34,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i34);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_float_0;
	r2 = (Integer) mercury_data___base_type_info_string_0;
	r3 = (Integer) detstackvar(16);
	r4 = (Integer) detstackvar(17);
	r5 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__rbtree__insert_duplicate_4_0);
	call_localret(ENTRY(mercury__rbtree__insert_duplicate_4_0),
		mercury__generate_output__process_prof_node_4_0_i35,
		STATIC(mercury__generate_output__process_prof_node_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_4_0_i35);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(19);
	decr_sp_pop_msg(19);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module4)
	init_entry(mercury__generate_output__construct_name_2_0);
	init_label(mercury__generate_output__construct_name_2_0_i4);
	init_label(mercury__generate_output__construct_name_2_0_i5);
	init_label(mercury__generate_output__construct_name_2_0_i1002);
BEGIN_CODE

/* code for predicate 'construct_name'/2 in mode 0 */
Define_static(mercury__generate_output__construct_name_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__construct_name_2_0_i1002);
	incr_sp_push_msg(2, "construct_name");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__generate_output__construct_name_2_0,
		LABEL(mercury__generate_output__construct_name_2_0_i4),
		STATIC(mercury__generate_output__construct_name_2_0));
Define_label(mercury__generate_output__construct_name_2_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__construct_name_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = string_const(" or ", 4);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__generate_output__construct_name_2_0_i5,
		STATIC(mercury__generate_output__construct_name_2_0));
	}
Define_label(mercury__generate_output__construct_name_2_0_i5);
	update_prof_current_proc(LABEL(mercury__generate_output__construct_name_2_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__string__append_3_2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__generate_output__construct_name_2_0));
	}
Define_label(mercury__generate_output__construct_name_2_0_i1002);
	r1 = string_const("", 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module5)
	init_entry(mercury__generate_output__remove_cycle_members_7_0);
	init_label(mercury__generate_output__remove_cycle_members_7_0_i4);
	init_label(mercury__generate_output__remove_cycle_members_7_0_i7);
	init_label(mercury__generate_output__remove_cycle_members_7_0_i11);
	init_label(mercury__generate_output__remove_cycle_members_7_0_i9);
	init_label(mercury__generate_output__remove_cycle_members_7_0_i12);
	init_label(mercury__generate_output__remove_cycle_members_7_0_i1006);
BEGIN_CODE

/* code for predicate 'remove_cycle_members'/7 in mode 0 */
Define_static(mercury__generate_output__remove_cycle_members_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__remove_cycle_members_7_0_i1006);
	incr_sp_push_msg(8, "remove_cycle_members");
	detstackvar(8) = (Integer) succip;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__prof_info__pred_info__get_entire_3_0);
	call_localret(ENTRY(mercury__prof_info__pred_info__get_entire_3_0),
		mercury__generate_output__remove_cycle_members_7_0_i4,
		STATIC(mercury__generate_output__remove_cycle_members_7_0));
	}
Define_label(mercury__generate_output__remove_cycle_members_7_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_cycle_members_7_0));
	r4 = (Integer) r1;
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__generate_output__remove_cycle_members_7_0_i7,
		STATIC(mercury__generate_output__remove_cycle_members_7_0));
	}
Define_label(mercury__generate_output__remove_cycle_members_7_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_cycle_members_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__generate_output__remove_cycle_members_7_0_i9);
	if (((Integer) r2 != (Integer) detstackvar(2)))
		GOTO_LABEL(mercury__generate_output__remove_cycle_members_7_0_i9);
	r1 = (Integer) detstackvar(5);
	r2 = ((Integer) detstackvar(1) - (Integer) detstackvar(7));
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__generate_output__remove_cycle_members_7_0,
		LABEL(mercury__generate_output__remove_cycle_members_7_0_i11),
		STATIC(mercury__generate_output__remove_cycle_members_7_0));
Define_label(mercury__generate_output__remove_cycle_members_7_0_i11);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_cycle_members_7_0));
	r4 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(7);
	{
	static const Float mercury_float_const_0 = 0;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Word)(&mercury_float_const_0);
	}
	{
	static const Float mercury_float_const_0 = 0;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Word)(&mercury_float_const_0);
	}
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__generate_output__remove_cycle_members_7_0_i9);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__generate_output__remove_cycle_members_7_0,
		LABEL(mercury__generate_output__remove_cycle_members_7_0_i12),
		STATIC(mercury__generate_output__remove_cycle_members_7_0));
Define_label(mercury__generate_output__remove_cycle_members_7_0_i12);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_cycle_members_7_0));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__generate_output__remove_cycle_members_7_0_i1006);
	r1 = (Integer) r2;
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module6)
	init_entry(mercury__generate_output__process_prof_node_parents_3_7_0);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i4);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i7);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i6);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i9);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i10);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i11);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i12);
	init_label(mercury__generate_output__process_prof_node_parents_3_7_0_i1003);
BEGIN_CODE

/* code for predicate 'process_prof_node_parents_3'/7 in mode 0 */
Define_static(mercury__generate_output__process_prof_node_parents_3_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_parents_3_7_0_i1003);
	incr_sp_push_msg(10, "process_prof_node_parents_3");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__prof_info__pred_info__get_entire_3_0);
	call_localret(ENTRY(mercury__prof_info__pred_info__get_entire_3_0),
		mercury__generate_output__process_prof_node_parents_3_7_0_i4,
		STATIC(mercury__generate_output__process_prof_node_parents_3_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_parents_3_7_0));
	r4 = (Integer) r1;
	detstackvar(7) = (Integer) r1;
	detstackvar(8) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__generate_output__process_prof_node_parents_3_7_0_i7,
		STATIC(mercury__generate_output__process_prof_node_parents_3_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_parents_3_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__generate_output__process_prof_node_parents_3_7_0_i6);
	r9 = (Integer) r2;
	r1 = (Integer) detstackvar(8);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__generate_output__process_prof_node_parents_3_7_0_i9);
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(7);
	r1 = (Integer) detstackvar(8);
	r9 = ((Integer) 0);
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i9);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	detstackvar(8) = (Integer) r1;
	detstackvar(9) = (Integer) r9;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_parents_3_7_0_i10,
		STATIC(mercury__generate_output__process_prof_node_parents_3_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i10);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_parents_3_7_0));
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__generate_output__checked_float_divide_3_0),
		mercury__generate_output__process_prof_node_parents_3_7_0_i11,
		STATIC(mercury__generate_output__process_prof_node_parents_3_7_0));
	}
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i11);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_parents_3_7_0));
	tag_incr_hp(r5, mktag(0), ((Integer) 5));
	r4 = (Integer) detstackvar(8);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_parent_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_parent_0;
	}
	r3 = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r5, ((Integer) 4)) = (Integer) r4;
	field(mktag(0), (Integer) r5, ((Integer) 3)) = float_to_word(word_to_float((Integer) detstackvar(2)) * word_to_float((Integer) tempr1));
	field(mktag(0), (Integer) r5, ((Integer) 2)) = float_to_word(word_to_float((Integer) detstackvar(1)) * word_to_float((Integer) tempr1));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__rbtree__insert_duplicate_4_0);
	call_localret(ENTRY(mercury__rbtree__insert_duplicate_4_0),
		mercury__generate_output__process_prof_node_parents_3_7_0_i12,
		STATIC(mercury__generate_output__process_prof_node_parents_3_7_0));
	}
	}
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i12);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_parents_3_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	localtailcall(mercury__generate_output__process_prof_node_parents_3_7_0,
		STATIC(mercury__generate_output__process_prof_node_parents_3_7_0));
Define_label(mercury__generate_output__process_prof_node_parents_3_7_0_i1003);
	r1 = (Integer) r6;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module7)
	init_entry(mercury__generate_output__process_prof_node_children_6_0);
	init_label(mercury__generate_output__process_prof_node_children_6_0_i4);
	init_label(mercury__generate_output__process_prof_node_children_6_0_i5);
	init_label(mercury__generate_output__process_prof_node_children_6_0_i6);
	init_label(mercury__generate_output__process_prof_node_children_6_0_i7);
	init_label(mercury__generate_output__process_prof_node_children_6_0_i1002);
BEGIN_CODE

/* code for predicate 'process_prof_node_children'/6 in mode 0 */
Define_static(mercury__generate_output__process_prof_node_children_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_children_6_0_i1002);
	incr_sp_push_msg(4, "process_prof_node_children");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	call_localret(STATIC(mercury__generate_output__remove_child_cycle_members_5_0),
		mercury__generate_output__process_prof_node_children_6_0_i4,
		STATIC(mercury__generate_output__process_prof_node_children_6_0));
Define_label(mercury__generate_output__process_prof_node_children_6_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_6_0));
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_child_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	}
	{
	Declare_entry(mercury__rbtree__init_1_0);
	call_localret(ENTRY(mercury__rbtree__init_1_0),
		mercury__generate_output__process_prof_node_children_6_0_i5,
		STATIC(mercury__generate_output__process_prof_node_children_6_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_6_0_i5);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__generate_output__process_prof_node_children_2_4_0),
		mercury__generate_output__process_prof_node_children_6_0_i6,
		STATIC(mercury__generate_output__process_prof_node_children_6_0));
Define_label(mercury__generate_output__process_prof_node_children_6_0_i6);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_6_0));
	r3 = (Integer) r1;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_child_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	}
	{
	Declare_entry(mercury__rbtree__values_2_0);
	call_localret(ENTRY(mercury__rbtree__values_2_0),
		mercury__generate_output__process_prof_node_children_6_0_i7,
		STATIC(mercury__generate_output__process_prof_node_children_6_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_6_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_6_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__generate_output__process_prof_node_children_6_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module8)
	init_entry(mercury__generate_output__remove_child_cycle_members_5_0);
	init_label(mercury__generate_output__remove_child_cycle_members_5_0_i4);
	init_label(mercury__generate_output__remove_child_cycle_members_5_0_i7);
	init_label(mercury__generate_output__remove_child_cycle_members_5_0_i11);
	init_label(mercury__generate_output__remove_child_cycle_members_5_0_i9);
	init_label(mercury__generate_output__remove_child_cycle_members_5_0_i12);
	init_label(mercury__generate_output__remove_child_cycle_members_5_0_i1006);
BEGIN_CODE

/* code for predicate 'remove_child_cycle_members'/5 in mode 0 */
Define_static(mercury__generate_output__remove_child_cycle_members_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__remove_child_cycle_members_5_0_i1006);
	incr_sp_push_msg(7, "remove_child_cycle_members");
	detstackvar(7) = (Integer) succip;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__prof_info__pred_info__get_entire_3_0);
	call_localret(ENTRY(mercury__prof_info__pred_info__get_entire_3_0),
		mercury__generate_output__remove_child_cycle_members_5_0_i4,
		STATIC(mercury__generate_output__remove_child_cycle_members_5_0));
	}
Define_label(mercury__generate_output__remove_child_cycle_members_5_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_child_cycle_members_5_0));
	r4 = (Integer) r1;
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__generate_output__remove_child_cycle_members_5_0_i7,
		STATIC(mercury__generate_output__remove_child_cycle_members_5_0));
	}
Define_label(mercury__generate_output__remove_child_cycle_members_5_0_i7);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_child_cycle_members_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__generate_output__remove_child_cycle_members_5_0_i9);
	if (((Integer) r2 != (Integer) detstackvar(1)))
		GOTO_LABEL(mercury__generate_output__remove_child_cycle_members_5_0_i9);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__generate_output__remove_child_cycle_members_5_0,
		LABEL(mercury__generate_output__remove_child_cycle_members_5_0_i11),
		STATIC(mercury__generate_output__remove_child_cycle_members_5_0));
Define_label(mercury__generate_output__remove_child_cycle_members_5_0_i11);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_child_cycle_members_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 6));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) tempr1;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 5)) = ((Integer) 0);
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) detstackvar(6);
	{
	static const Float mercury_float_const_0 = 0;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Word)(&mercury_float_const_0);
	}
	{
	static const Float mercury_float_const_0 = 0;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Word)(&mercury_float_const_0);
	}
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__generate_output__remove_child_cycle_members_5_0_i9);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__generate_output__remove_child_cycle_members_5_0,
		LABEL(mercury__generate_output__remove_child_cycle_members_5_0_i12),
		STATIC(mercury__generate_output__remove_child_cycle_members_5_0));
Define_label(mercury__generate_output__remove_child_cycle_members_5_0_i12);
	update_prof_current_proc(LABEL(mercury__generate_output__remove_child_cycle_members_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__generate_output__remove_child_cycle_members_5_0_i1006);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module9)
	init_entry(mercury__generate_output__process_prof_node_children_2_4_0);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i4);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i5);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i8);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i7);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i10);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i11);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i12);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i13);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i14);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i15);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i16);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i17);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i18);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i19);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i20);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i21);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i22);
	init_label(mercury__generate_output__process_prof_node_children_2_4_0_i1003);
BEGIN_CODE

/* code for predicate 'process_prof_node_children_2'/4 in mode 0 */
Define_static(mercury__generate_output__process_prof_node_children_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__process_prof_node_children_2_4_0_i1003);
	incr_sp_push_msg(16, "process_prof_node_children_2");
	detstackvar(16) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury__prof_info__pred_info__get_entire_3_0);
	call_localret(ENTRY(mercury__prof_info__pred_info__get_entire_3_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i4,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__prof_info__prof__get_entire_7_0);
	call_localret(ENTRY(mercury__prof_info__prof__get_entire_7_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i5,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(6) = (Integer) r1;
	detstackvar(7) = (Integer) r2;
	detstackvar(8) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	r3 = (Integer) r6;
	r4 = (Integer) detstackvar(4);
	detstackvar(9) = (Integer) r5;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__generate_output__process_prof_node_children_2_4_0_i8,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__generate_output__process_prof_node_children_2_4_0_i7);
	r10 = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	GOTO_LABEL(mercury__generate_output__process_prof_node_children_2_4_0_i10);
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i7);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	r6 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(5);
	r8 = (Integer) detstackvar(6);
	r9 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
	r3 = (Integer) detstackvar(9);
	r10 = ((Integer) 0);
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i10);
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) r5;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r7;
	detstackvar(6) = (Integer) r8;
	detstackvar(7) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	{
	Declare_entry(mercury__prof_info__get_prof_node_4_0);
	call_localret(ENTRY(mercury__prof_info__get_prof_node_4_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i11,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(11) = (Integer) r1;
	{
	Declare_entry(mercury__prof_info__prof_node_get_initial_counts_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_initial_counts_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i12,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	{
	Declare_entry(mercury__prof_info__prof_node_get_propagated_counts_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_propagated_counts_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i13,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__prof_info__prof_node_get_total_calls_2_0);
	call_localret(ENTRY(mercury__prof_info__prof_node_get_total_calls_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i14,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	r2 = (Integer) detstackvar(12);
	detstackvar(12) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i15,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	detstackvar(13) = float_to_word(word_to_float((Integer) r1) + word_to_float((Integer) r2));
	r1 = (Integer) detstackvar(12);
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i16,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i17,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	r2 = (Integer) detstackvar(14);
	{
		call_localret(STATIC(mercury__generate_output__checked_float_divide_3_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i18,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i18);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(14) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i19,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i19);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	detstackvar(15) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__int__to_float_2_0);
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i20,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i20);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	r2 = (Integer) detstackvar(11);
	detstackvar(11) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(15);
	{
		call_localret(STATIC(mercury__generate_output__checked_float_divide_3_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i21,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i21);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(14);
	tempr2 = (Integer) detstackvar(11);
	tag_incr_hp(r5, mktag(0), ((Integer) 6));
	field(mktag(0), (Integer) r5, ((Integer) 2)) = float_to_word((word_to_float((Integer) r1) * word_to_float((Integer) tempr2)) * word_to_float((Integer) tempr1));
	r4 = (Integer) detstackvar(5);
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r1 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	extern Word * mercury_data_output_prof_info__base_type_info_child_0[];
	r2 = (Integer) mercury_data_output_prof_info__base_type_info_child_0;
	}
	r3 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r5, ((Integer) 5)) = (Integer) detstackvar(12);
	field(mktag(0), (Integer) r5, ((Integer) 4)) = (Integer) r4;
	field(mktag(0), (Integer) r5, ((Integer) 3)) = float_to_word(((word_to_float((Integer) detstackvar(13)) / word_to_float((Integer) detstackvar(15))) * word_to_float((Integer) tempr2)) * word_to_float((Integer) tempr1));
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(10);
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__rbtree__insert_duplicate_4_0);
	call_localret(ENTRY(mercury__rbtree__insert_duplicate_4_0),
		mercury__generate_output__process_prof_node_children_2_4_0_i22,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
	}
	}
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i22);
	update_prof_current_proc(LABEL(mercury__generate_output__process_prof_node_children_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(16);
	decr_sp_pop_msg(16);
	localtailcall(mercury__generate_output__process_prof_node_children_2_4_0,
		STATIC(mercury__generate_output__process_prof_node_children_2_4_0));
Define_label(mercury__generate_output__process_prof_node_children_2_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__generate_output_module10)
	init_entry(mercury__generate_output__assign_index_numbers_2_4_0);
	init_label(mercury__generate_output__assign_index_numbers_2_4_0_i4);
	init_label(mercury__generate_output__assign_index_numbers_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'assign_index_numbers_2'/4 in mode 0 */
Define_static(mercury__generate_output__assign_index_numbers_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__generate_output__assign_index_numbers_2_4_0_i1002);
	incr_sp_push_msg(3, "assign_index_numbers_2");
	detstackvar(3) = (Integer) succip;
	r5 = (Integer) r3;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r2;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	extern Word * mercury_data___base_type_info_int_0[];
	r2 = (Integer) mercury_data___base_type_info_int_0;
	}
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__generate_output__assign_index_numbers_2_4_0_i4,
		STATIC(mercury__generate_output__assign_index_numbers_2_4_0));
	}
Define_label(mercury__generate_output__assign_index_numbers_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__generate_output__assign_index_numbers_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = ((Integer) detstackvar(1) + ((Integer) 1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__generate_output__assign_index_numbers_2_4_0,
		STATIC(mercury__generate_output__assign_index_numbers_2_4_0));
Define_label(mercury__generate_output__assign_index_numbers_2_4_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__generate_output_bunch_0(void)
{
	mercury__generate_output_module0();
	mercury__generate_output_module1();
	mercury__generate_output_module2();
	mercury__generate_output_module3();
	mercury__generate_output_module4();
	mercury__generate_output_module5();
	mercury__generate_output_module6();
	mercury__generate_output_module7();
	mercury__generate_output_module8();
	mercury__generate_output_module9();
	mercury__generate_output_module10();
}

#endif

void mercury__generate_output__init(void); /* suppress gcc warning */
void mercury__generate_output__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__generate_output_bunch_0();
#endif
}
