/*
** Automatically generated from `mercury_profile.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__mercury_profile__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__main_2_0);
Declare_label(mercury__main_2_0_i2);
Declare_label(mercury__main_2_0_i3);
Declare_label(mercury__main_2_0_i5);
Declare_label(mercury__main_2_0_i6);
Declare_label(mercury__main_2_0_i7);
Declare_label(mercury__main_2_0_i11);
Declare_label(mercury__main_2_0_i8);
Declare_label(mercury__main_2_0_i12);
Declare_label(mercury__main_2_0_i16);
Declare_label(mercury__main_2_0_i13);
Declare_label(mercury__main_2_0_i17);
Declare_static(mercury__mercury_profile__usage_error_3_0);
Declare_label(mercury__mercury_profile__usage_error_3_0_i2);
Declare_label(mercury__mercury_profile__usage_error_3_0_i3);
Declare_label(mercury__mercury_profile__usage_error_3_0_i4);
Declare_label(mercury__mercury_profile__usage_error_3_0_i5);
Declare_label(mercury__mercury_profile__usage_error_3_0_i6);
Declare_label(mercury__mercury_profile__usage_error_3_0_i7);
Declare_label(mercury__mercury_profile__usage_error_3_0_i8);
Declare_label(mercury__mercury_profile__usage_error_3_0_i9);
Declare_label(mercury__mercury_profile__usage_error_3_0_i10);
Declare_label(mercury__mercury_profile__usage_error_3_0_i11);
Declare_label(mercury__mercury_profile__usage_error_3_0_i12);
Declare_label(mercury__mercury_profile__usage_error_3_0_i13);
Declare_label(mercury__mercury_profile__usage_error_3_0_i14);
Declare_label(mercury__mercury_profile__usage_error_3_0_i15);
Declare_label(mercury__mercury_profile__usage_error_3_0_i16);
Declare_label(mercury__mercury_profile__usage_error_3_0_i17);
Declare_label(mercury__mercury_profile__usage_error_3_0_i18);
Declare_static(mercury__mercury_profile__main_2_4_0);
Declare_label(mercury__mercury_profile__main_2_4_0_i1002);
Declare_label(mercury__mercury_profile__main_2_4_0_i5);
Declare_label(mercury__mercury_profile__main_2_4_0_i6);
Declare_label(mercury__mercury_profile__main_2_4_0_i7);
Declare_label(mercury__mercury_profile__main_2_4_0_i8);
Declare_label(mercury__mercury_profile__main_2_4_0_i12);
Declare_label(mercury__mercury_profile__main_2_4_0_i13);
Declare_label(mercury__mercury_profile__main_2_4_0_i14);
Declare_label(mercury__mercury_profile__main_2_4_0_i15);
Declare_label(mercury__mercury_profile__main_2_4_0_i16);
Declare_label(mercury__mercury_profile__main_2_4_0_i17);
Declare_label(mercury__mercury_profile__main_2_4_0_i18);
Declare_label(mercury__mercury_profile__main_2_4_0_i19);
Declare_label(mercury__mercury_profile__main_2_4_0_i20);
Declare_label(mercury__mercury_profile__main_2_4_0_i21);
Declare_label(mercury__mercury_profile__main_2_4_0_i22);
Declare_label(mercury__mercury_profile__main_2_4_0_i9);
Declare_label(mercury__mercury_profile__main_2_4_0_i24);
Declare_label(mercury__mercury_profile__main_2_4_0_i25);
Declare_label(mercury__mercury_profile__main_2_4_0_i26);
Declare_label(mercury__mercury_profile__main_2_4_0_i27);
Declare_label(mercury__mercury_profile__main_2_4_0_i31);
Declare_label(mercury__mercury_profile__main_2_4_0_i32);
Declare_label(mercury__mercury_profile__main_2_4_0_i33);
Declare_label(mercury__mercury_profile__main_2_4_0_i34);
Declare_label(mercury__mercury_profile__main_2_4_0_i35);
Declare_label(mercury__mercury_profile__main_2_4_0_i36);
Declare_label(mercury__mercury_profile__main_2_4_0_i28);
Declare_label(mercury__mercury_profile__main_2_4_0_i37);
Declare_label(mercury__mercury_profile__main_2_4_0_i38);
Declare_label(mercury__mercury_profile__main_2_4_0_i39);
Declare_label(mercury__mercury_profile__main_2_4_0_i40);
Declare_label(mercury__mercury_profile__main_2_4_0_i41);
Declare_label(mercury__mercury_profile__main_2_4_0_i42);
Declare_label(mercury__mercury_profile__main_2_4_0_i43);

Declare_entry(mercury__options__short_option_2_0);
Word * mercury_data_mercury_profile__common_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__short_option_2_0)
};

Declare_entry(mercury__options__long_option_2_0);
Word * mercury_data_mercury_profile__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__long_option_2_0)
};

Declare_entry(mercury__options__option_defaults_2_0);
Word * mercury_data_mercury_profile__common_2[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__options__option_defaults_2_0)
};

Word * mercury_data_mercury_profile__common_3[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_profile__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_profile__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_profile__common_2)
};

Word mercury_data_mercury_profile__common_4[] = {
	((Integer) 0)
};

Word * mercury_data_mercury_profile__common_5[] = {
	(Word *) string_const("\n", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

BEGIN_MODULE(mercury__mercury_profile_module0)
	init_entry(mercury__main_2_0);
	init_label(mercury__main_2_0_i2);
	init_label(mercury__main_2_0_i3);
	init_label(mercury__main_2_0_i5);
	init_label(mercury__main_2_0_i6);
	init_label(mercury__main_2_0_i7);
	init_label(mercury__main_2_0_i11);
	init_label(mercury__main_2_0_i8);
	init_label(mercury__main_2_0_i12);
	init_label(mercury__main_2_0_i16);
	init_label(mercury__main_2_0_i13);
	init_label(mercury__main_2_0_i17);
BEGIN_CODE

/* code for predicate 'main'/2 in mode 0 */
Define_entry(mercury__main_2_0);
	incr_sp_push_msg(2, "main");
	detstackvar(2) = (Integer) succip;
	{
	Declare_entry(mercury__io__command_line_arguments_3_0);
	call_localret(ENTRY(mercury__io__command_line_arguments_3_0),
		mercury__main_2_0_i2,
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i2);
	update_prof_current_proc(LABEL(mercury__main_2_0));
	detstackvar(1) = (Integer) r2;
	r3 = (Integer) r1;
	{
	extern Word * mercury_data_options__base_type_info_option_0[];
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	}
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_profile__common_3);
	{
	Declare_entry(mercury__getopt__process_options_4_0);
	call_localret(ENTRY(mercury__getopt__process_options_4_0),
		mercury__main_2_0_i3,
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i3);
	update_prof_current_proc(LABEL(mercury__main_2_0));
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__main_2_0_i5);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r1;
	r1 = (Integer) tempr1;
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__mercury_profile__main_2_4_0),
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i5);
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__globals__io_init_3_0);
	call_localret(ENTRY(mercury__globals__io_init_3_0),
		mercury__main_2_0_i6,
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i6);
	update_prof_current_proc(LABEL(mercury__main_2_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__main_2_0_i7,
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i7);
	update_prof_current_proc(LABEL(mercury__main_2_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__main_2_0_i8);
	r1 = ((Integer) 0);
	r3 = (Integer) r2;
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_profile__common_4);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__main_2_0_i11,
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i11);
	update_prof_current_proc(LABEL(mercury__main_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__main_2_0_i12);
Define_label(mercury__main_2_0_i8);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
Define_label(mercury__main_2_0_i12);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__main_2_0_i13);
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 2);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_profile__common_4);
	{
	Declare_entry(mercury__globals__io_set_option_4_0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__main_2_0_i16,
		ENTRY(mercury__main_2_0));
	}
Define_label(mercury__main_2_0_i16);
	update_prof_current_proc(LABEL(mercury__main_2_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	GOTO_LABEL(mercury__main_2_0_i17);
Define_label(mercury__main_2_0_i13);
	r2 = (Integer) r1;
Define_label(mercury__main_2_0_i17);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__mercury_profile__main_2_4_0),
		ENTRY(mercury__main_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_profile_module1)
	init_entry(mercury__mercury_profile__usage_error_3_0);
	init_label(mercury__mercury_profile__usage_error_3_0_i2);
	init_label(mercury__mercury_profile__usage_error_3_0_i3);
	init_label(mercury__mercury_profile__usage_error_3_0_i4);
	init_label(mercury__mercury_profile__usage_error_3_0_i5);
	init_label(mercury__mercury_profile__usage_error_3_0_i6);
	init_label(mercury__mercury_profile__usage_error_3_0_i7);
	init_label(mercury__mercury_profile__usage_error_3_0_i8);
	init_label(mercury__mercury_profile__usage_error_3_0_i9);
	init_label(mercury__mercury_profile__usage_error_3_0_i10);
	init_label(mercury__mercury_profile__usage_error_3_0_i11);
	init_label(mercury__mercury_profile__usage_error_3_0_i12);
	init_label(mercury__mercury_profile__usage_error_3_0_i13);
	init_label(mercury__mercury_profile__usage_error_3_0_i14);
	init_label(mercury__mercury_profile__usage_error_3_0_i15);
	init_label(mercury__mercury_profile__usage_error_3_0_i16);
	init_label(mercury__mercury_profile__usage_error_3_0_i17);
	init_label(mercury__mercury_profile__usage_error_3_0_i18);
BEGIN_CODE

/* code for predicate 'usage_error'/3 in mode 0 */
Define_static(mercury__mercury_profile__usage_error_3_0);
	incr_sp_push_msg(4, "usage_error");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = string_const("mercury_profile", 15);
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__mercury_profile__usage_error_3_0_i2,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_profile__usage_error_3_0_i3,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i3);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i4,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(": ", 2);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i5,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i6,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("\n", 1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i7,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 1);
	{
	Declare_entry(mercury__io__set_exit_status_3_0);
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__mercury_profile__usage_error_3_0_i8,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r2 = (Integer) r1;
	r1 = string_const("mprof", 5);
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__mercury_profile__usage_error_3_0_i9,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i9);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_profile__usage_error_3_0_i10,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i10);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	detstackvar(2) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__mercury_profile__usage_error_3_0_i11,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i11);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = string_const("Mercury Profiler, version ", 26);
	r1 = (Integer) detstackvar(2);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r3;
	r3 = (Integer) detstackvar(3);
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_profile__common_5);
	{
	Declare_entry(mercury__io__write_strings_4_0);
	call_localret(ENTRY(mercury__io__write_strings_4_0),
		mercury__mercury_profile__usage_error_3_0_i12,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("Copyright (C) 1995 University of Melbourne\n", 43);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i13,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("Usage: ", 7);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i14,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i15,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(" [<options>] [<files ...>]\n", 27);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i16,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const("Use `", 5);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i17,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_4_0);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__mercury_profile__usage_error_3_0_i18,
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
Define_label(mercury__mercury_profile__usage_error_3_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_profile__usage_error_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = string_const(" --help' for more information.\n", 31);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_4_0);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		STATIC(mercury__mercury_profile__usage_error_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_profile_module2)
	init_entry(mercury__mercury_profile__main_2_4_0);
	init_label(mercury__mercury_profile__main_2_4_0_i1002);
	init_label(mercury__mercury_profile__main_2_4_0_i5);
	init_label(mercury__mercury_profile__main_2_4_0_i6);
	init_label(mercury__mercury_profile__main_2_4_0_i7);
	init_label(mercury__mercury_profile__main_2_4_0_i8);
	init_label(mercury__mercury_profile__main_2_4_0_i12);
	init_label(mercury__mercury_profile__main_2_4_0_i13);
	init_label(mercury__mercury_profile__main_2_4_0_i14);
	init_label(mercury__mercury_profile__main_2_4_0_i15);
	init_label(mercury__mercury_profile__main_2_4_0_i16);
	init_label(mercury__mercury_profile__main_2_4_0_i17);
	init_label(mercury__mercury_profile__main_2_4_0_i18);
	init_label(mercury__mercury_profile__main_2_4_0_i19);
	init_label(mercury__mercury_profile__main_2_4_0_i20);
	init_label(mercury__mercury_profile__main_2_4_0_i21);
	init_label(mercury__mercury_profile__main_2_4_0_i22);
	init_label(mercury__mercury_profile__main_2_4_0_i9);
	init_label(mercury__mercury_profile__main_2_4_0_i24);
	init_label(mercury__mercury_profile__main_2_4_0_i25);
	init_label(mercury__mercury_profile__main_2_4_0_i26);
	init_label(mercury__mercury_profile__main_2_4_0_i27);
	init_label(mercury__mercury_profile__main_2_4_0_i31);
	init_label(mercury__mercury_profile__main_2_4_0_i32);
	init_label(mercury__mercury_profile__main_2_4_0_i33);
	init_label(mercury__mercury_profile__main_2_4_0_i34);
	init_label(mercury__mercury_profile__main_2_4_0_i35);
	init_label(mercury__mercury_profile__main_2_4_0_i36);
	init_label(mercury__mercury_profile__main_2_4_0_i28);
	init_label(mercury__mercury_profile__main_2_4_0_i37);
	init_label(mercury__mercury_profile__main_2_4_0_i38);
	init_label(mercury__mercury_profile__main_2_4_0_i39);
	init_label(mercury__mercury_profile__main_2_4_0_i40);
	init_label(mercury__mercury_profile__main_2_4_0_i41);
	init_label(mercury__mercury_profile__main_2_4_0_i42);
	init_label(mercury__mercury_profile__main_2_4_0_i43);
BEGIN_CODE

/* code for predicate 'main_2'/4 in mode 0 */
Define_static(mercury__mercury_profile__main_2_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__mercury_profile__main_2_4_0_i1002);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__mercury_profile__usage_error_3_0),
		STATIC(mercury__mercury_profile__main_2_4_0));
Define_label(mercury__mercury_profile__main_2_4_0_i1002);
	incr_sp_push_msg(7, "main_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) r3;
	{
	Declare_entry(mercury__io__stderr_stream_3_0);
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__mercury_profile__main_2_4_0_i5,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_profile__main_2_4_0_i6,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	detstackvar(2) = (Integer) r1;
	r1 = ((Integer) 3);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__mercury_profile__main_2_4_0_i7,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = ((Integer) 8);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__mercury_profile__main_2_4_0_i8,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_profile__main_2_4_0_i9);
	r1 = string_const("mprof", 5);
	{
	Declare_entry(mercury__io__progname_base_4_0);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__mercury_profile__main_2_4_0_i12,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__library__version_1_0);
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__mercury_profile__main_2_4_0_i13,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("Mercury Profiler, version ", 26);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_profile__common_5);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_strings_3_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__mercury_profile__main_2_4_0_i14,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("Copyright (C) 1995 University of Melbourne\n", 43);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i15,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("Usage: ", 7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i16,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i17,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const(" [<options>] [<files ...>]\n", 27);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i18,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i18);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("Files:\n", 7);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i19,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i19);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\tFiles that contain the static call graph, need one for every module \n", 70);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i20,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i20);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("\tin the program\n\n", 17);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i21,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i21);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = string_const("Options:\n", 9);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__mercury_profile__main_2_4_0_i22,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i22);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__options__options_help_2_0);
	tailcall(ENTRY(mercury__options__options_help_2_0),
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i9);
	r1 = ((Integer) 0);
	{
	Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__mercury_profile__main_2_4_0_i24,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i24);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	detstackvar(4) = (Integer) r1;
	r3 = (Integer) r2;
	r2 = string_const("% Processing input files...", 27);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i25,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i25);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	{
	Declare_entry(mercury__process_file__main_4_0);
	call_localret(ENTRY(mercury__process_file__main_4_0),
		mercury__mercury_profile__main_2_4_0_i26,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i26);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(" done\n", 6);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i27,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i27);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	if (((Integer) detstackvar(3) != ((Integer) 0)))
		GOTO_LABEL(mercury__mercury_profile__main_2_4_0_i28);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Building call graph...", 24);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i31,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i31);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__call_graph__main_5_0);
	call_localret(ENTRY(mercury__call_graph__main_5_0),
		mercury__mercury_profile__main_2_4_0_i32,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i32);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(" done\n", 6);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i33,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i33);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Propagating counts...", 23);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i34,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i34);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__propagate__counts_5_0);
	call_localret(ENTRY(mercury__propagate__counts_5_0),
		mercury__mercury_profile__main_2_4_0_i35,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i35);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r2;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(" done\n", 6);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i36,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i36);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Generating output...", 22);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(1);
	GOTO_LABEL(mercury__mercury_profile__main_2_4_0_i37);
Define_label(mercury__mercury_profile__main_2_4_0_i28);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = string_const("% Generating output...", 22);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
Define_label(mercury__mercury_profile__main_2_4_0_i37);
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(1) = (Integer) r5;
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i38,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i38);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__generate_output__main_5_0);
	call_localret(ENTRY(mercury__generate_output__main_5_0),
		mercury__mercury_profile__main_2_4_0_i39,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i39);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	detstackvar(1) = (Integer) r1;
	detstackvar(3) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = string_const(" done\n", 6);
	{
	Declare_entry(mercury__options__maybe_write_string_4_0);
	call_localret(ENTRY(mercury__options__maybe_write_string_4_0),
		mercury__mercury_profile__main_2_4_0_i40,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i40);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__set_output_stream_4_0);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__mercury_profile__main_2_4_0_i41,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i41);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r3 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__output__main_4_0);
	call_localret(ENTRY(mercury__output__main_4_0),
		mercury__mercury_profile__main_2_4_0_i42,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i42);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 10);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__mercury_profile__main_2_4_0_i43,
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
Define_label(mercury__mercury_profile__main_2_4_0_i43);
	update_prof_current_proc(LABEL(mercury__mercury_profile__main_2_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__io__told_2_0);
	tailcall(ENTRY(mercury__io__told_2_0),
		STATIC(mercury__mercury_profile__main_2_4_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__mercury_profile_bunch_0(void)
{
	mercury__mercury_profile_module0();
	mercury__mercury_profile_module1();
	mercury__mercury_profile_module2();
}

#endif

void mercury__mercury_profile__init(void); /* suppress gcc warning */
void mercury__mercury_profile__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__mercury_profile_bunch_0();
#endif
}
