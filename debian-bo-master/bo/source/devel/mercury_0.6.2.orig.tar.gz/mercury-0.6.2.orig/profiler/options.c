/*
** Automatically generated from `options.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__options__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__options__short_option_2_0);
Declare_label(mercury__options__short_option_2_0_i3);
Declare_label(mercury__options__short_option_2_0_i4);
Declare_label(mercury__options__short_option_2_0_i5);
Declare_label(mercury__options__short_option_2_0_i6);
Declare_label(mercury__options__short_option_2_0_i7);
Declare_label(mercury__options__short_option_2_0_i8);
Declare_label(mercury__options__short_option_2_0_i9);
Declare_label(mercury__options__short_option_2_0_i10);
Declare_label(mercury__options__short_option_2_0_i1);
Define_extern_entry(mercury__options__long_option_2_0);
Declare_label(mercury__options__long_option_2_0_i3);
Declare_label(mercury__options__long_option_2_0_i1000);
Declare_label(mercury__options__long_option_2_0_i5);
Declare_label(mercury__options__long_option_2_0_i6);
Declare_label(mercury__options__long_option_2_0_i7);
Declare_label(mercury__options__long_option_2_0_i8);
Declare_label(mercury__options__long_option_2_0_i9);
Declare_label(mercury__options__long_option_2_0_i10);
Declare_label(mercury__options__long_option_2_0_i11);
Declare_label(mercury__options__long_option_2_0_i13);
Declare_label(mercury__options__long_option_2_0_i14);
Declare_label(mercury__options__long_option_2_0_i1);
Define_extern_entry(mercury__options__option_defaults_2_0);
Declare_label(mercury__options__option_defaults_2_0_i1);
Declare_label(mercury__options__option_defaults_2_0_i3);
Define_extern_entry(mercury__options__option_default_2_0);
Declare_label(mercury__options__option_default_2_0_i3);
Declare_label(mercury__options__option_default_2_0_i5);
Declare_label(mercury__options__option_default_2_0_i7);
Declare_label(mercury__options__option_default_2_0_i9);
Declare_label(mercury__options__option_default_2_0_i11);
Declare_label(mercury__options__option_default_2_0_i13);
Declare_label(mercury__options__option_default_2_0_i15);
Declare_label(mercury__options__option_default_2_0_i17);
Define_extern_entry(mercury__options__options_help_2_0);
Declare_label(mercury__options__options_help_2_0_i2);
Declare_label(mercury__options__options_help_2_0_i3);
Declare_label(mercury__options__options_help_2_0_i4);
Declare_label(mercury__options__options_help_2_0_i5);
Declare_label(mercury__options__options_help_2_0_i6);
Declare_label(mercury__options__options_help_2_0_i7);
Declare_label(mercury__options__options_help_2_0_i8);
Declare_label(mercury__options__options_help_2_0_i9);
Declare_label(mercury__options__options_help_2_0_i10);
Declare_label(mercury__options__options_help_2_0_i11);
Declare_label(mercury__options__options_help_2_0_i12);
Declare_label(mercury__options__options_help_2_0_i13);
Declare_label(mercury__options__options_help_2_0_i14);
Declare_label(mercury__options__options_help_2_0_i15);
Declare_label(mercury__options__options_help_2_0_i16);
Declare_label(mercury__options__options_help_2_0_i17);
Declare_label(mercury__options__options_help_2_0_i18);
Declare_label(mercury__options__options_help_2_0_i19);
Declare_label(mercury__options__options_help_2_0_i20);
Define_extern_entry(mercury__options__maybe_write_string_4_0);
Declare_label(mercury__options__maybe_write_string_4_0_i1003);
Define_extern_entry(mercury__options__maybe_flush_output_3_0);
Declare_label(mercury__options__maybe_flush_output_3_0_i1003);
Define_extern_entry(mercury____Unify___options__option_0_0);
Declare_label(mercury____Unify___options__option_0_0_i1);
Define_extern_entry(mercury____Index___options__option_0_0);
Define_extern_entry(mercury____Compare___options__option_0_0);
Define_extern_entry(mercury____Unify___options__option_table_0_0);
Define_extern_entry(mercury____Index___options__option_table_0_0);
Define_extern_entry(mercury____Compare___options__option_table_0_0);

extern Word * mercury_data_options__base_type_layout_option_0[];
Word * mercury_data_options__base_type_info_option_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___options__option_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___options__option_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___options__option_0_0),
	(Word *) (Integer) mercury_data_options__base_type_layout_option_0
};

extern Word * mercury_data_options__base_type_layout_option_table_0[];
Word * mercury_data_options__base_type_info_option_table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___options__option_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___options__option_table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___options__option_table_0_0),
	(Word *) (Integer) mercury_data_options__base_type_layout_option_table_0
};

extern Word * mercury_data_options__common_8[];
Word * mercury_data_options__base_type_layout_option_table_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_8),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_8),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_8),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_8)
};

extern Word * mercury_data_options__common_9[];
Word * mercury_data_options__base_type_layout_option_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_options__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_options__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_options__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_options__common_9)
};

Word * mercury_data_options__common_0[] = {
	(Word *) string_const("call-pair-file", 14),
	(Word *) ((Integer) 0),
	(Word *) string_const("count-file", 10),
	(Word *) string_const("very-verbose", 12),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("call-graph", 10),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("library-callgraph", 17),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("use-dynamic", 11),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("help", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("declaration-file", 16),
	(Word *) ((Integer) 0),
	(Word *) string_const("verbose", 7),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0)
};

Word mercury_data_options__common_1[] = {
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2)
};

Word mercury_data_options__common_2[] = {
	((Integer) 1)
};

Word * mercury_data_options__common_3[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("Prof.Counts", 11)
};

Word * mercury_data_options__common_4[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("Prof.CallPair", 13)
};

Word * mercury_data_options__common_5[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("Prof.Decl", 9)
};

Word * mercury_data_options__common_6[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("", 0)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_getopt__base_type_info_option_data_0[];
Word * mercury_data_options__common_7[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_options__base_type_info_option_0,
	(Word *) (Integer) mercury_data_getopt__base_type_info_option_data_0
};

Word * mercury_data_options__common_8[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_options__common_7)
};

Word * mercury_data_options__common_9[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 9),
	(Word *) string_const("verbose", 7),
	(Word *) string_const("very_verbose", 12),
	(Word *) string_const("dynamic_cg", 10),
	(Word *) string_const("call_graph", 10),
	(Word *) string_const("countfile", 9),
	(Word *) string_const("pairfile", 8),
	(Word *) string_const("declfile", 8),
	(Word *) string_const("libraryfile", 11),
	(Word *) string_const("help", 4)
};

BEGIN_MODULE(mercury__options_module0)
	init_entry(mercury__options__short_option_2_0);
	init_label(mercury__options__short_option_2_0_i3);
	init_label(mercury__options__short_option_2_0_i4);
	init_label(mercury__options__short_option_2_0_i5);
	init_label(mercury__options__short_option_2_0_i6);
	init_label(mercury__options__short_option_2_0_i7);
	init_label(mercury__options__short_option_2_0_i8);
	init_label(mercury__options__short_option_2_0_i9);
	init_label(mercury__options__short_option_2_0_i10);
	init_label(mercury__options__short_option_2_0_i1);
BEGIN_CODE

/* code for predicate 'short_option'/2 in mode 0 */
Define_entry(mercury__options__short_option_2_0);
	if (((Integer) r1 != ((Integer) 67)))
		GOTO_LABEL(mercury__options__short_option_2_0_i3);
	r2 = ((Integer) 4);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i3);
	if (((Integer) r1 != ((Integer) 68)))
		GOTO_LABEL(mercury__options__short_option_2_0_i4);
	r2 = ((Integer) 6);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i4);
	if (((Integer) r1 != ((Integer) 76)))
		GOTO_LABEL(mercury__options__short_option_2_0_i5);
	r2 = ((Integer) 7);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i5);
	if (((Integer) r1 != ((Integer) 80)))
		GOTO_LABEL(mercury__options__short_option_2_0_i6);
	r2 = ((Integer) 5);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i6);
	if (((Integer) r1 != ((Integer) 86)))
		GOTO_LABEL(mercury__options__short_option_2_0_i7);
	r2 = ((Integer) 1);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i7);
	if (((Integer) r1 != ((Integer) 99)))
		GOTO_LABEL(mercury__options__short_option_2_0_i8);
	r2 = ((Integer) 3);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i8);
	if (((Integer) r1 != ((Integer) 100)))
		GOTO_LABEL(mercury__options__short_option_2_0_i9);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i9);
	if (((Integer) r1 != ((Integer) 104)))
		GOTO_LABEL(mercury__options__short_option_2_0_i10);
	r2 = ((Integer) 8);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i10);
	if (((Integer) r1 != ((Integer) 118)))
		GOTO_LABEL(mercury__options__short_option_2_0_i1);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__short_option_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__options_module1)
	init_entry(mercury__options__long_option_2_0);
	init_label(mercury__options__long_option_2_0_i3);
	init_label(mercury__options__long_option_2_0_i1000);
	init_label(mercury__options__long_option_2_0_i5);
	init_label(mercury__options__long_option_2_0_i6);
	init_label(mercury__options__long_option_2_0_i7);
	init_label(mercury__options__long_option_2_0_i8);
	init_label(mercury__options__long_option_2_0_i9);
	init_label(mercury__options__long_option_2_0_i10);
	init_label(mercury__options__long_option_2_0_i11);
	init_label(mercury__options__long_option_2_0_i13);
	init_label(mercury__options__long_option_2_0_i14);
	init_label(mercury__options__long_option_2_0_i1);
BEGIN_CODE

/* code for predicate 'long_option'/2 in mode 0 */
Define_entry(mercury__options__long_option_2_0);
	r2 = (hash_string((Integer) r1) & ((Integer) 31));
Define_label(mercury__options__long_option_2_0_i3);
	r3 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_options__common_0))[(Integer) r2];
	if (!((Integer) r3))
		GOTO_LABEL(mercury__options__long_option_2_0_i1000);
	if ((strcmp((char *)(Integer) r3, (char *)(Integer) r1) ==0))
		GOTO_LABEL(mercury__options__long_option_2_0_i5);
Define_label(mercury__options__long_option_2_0_i1000);
	r2 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_options__common_1))[(Integer) r2];
	if (((Integer) r2 >= ((Integer) 0)))
		GOTO_LABEL(mercury__options__long_option_2_0_i3);
	r1 = FALSE;
	proceed();
Define_label(mercury__options__long_option_2_0_i5);
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__options__long_option_2_0_i6) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i7) AND
		LABEL(mercury__options__long_option_2_0_i8) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i9) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i10) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i11) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i10) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i13) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i14) AND
		LABEL(mercury__options__long_option_2_0_i1) AND
		LABEL(mercury__options__long_option_2_0_i1));
Define_label(mercury__options__long_option_2_0_i6);
	r2 = ((Integer) 5);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i7);
	r2 = ((Integer) 4);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i8);
	r2 = ((Integer) 1);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i9);
	r2 = ((Integer) 3);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i10);
	r2 = ((Integer) 8);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i11);
	r2 = ((Integer) 2);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i13);
	r2 = ((Integer) 6);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i14);
	r2 = ((Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__options__long_option_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__options_module2)
	init_entry(mercury__options__option_defaults_2_0);
	init_label(mercury__options__option_defaults_2_0_i1);
	init_label(mercury__options__option_defaults_2_0_i3);
BEGIN_CODE

/* code for predicate 'option_defaults'/2 in mode 0 */
Define_entry(mercury__options__option_defaults_2_0);
	{
	Declare_entry(do_fail);
	mkframe("option_defaults/2", 1, ENTRY(do_fail));
	}
	{
	Declare_entry(mercury__std_util__semidet_succeed_0_0);
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__options__option_defaults_2_0_i1,
		ENTRY(mercury__options__option_defaults_2_0));
	}
Define_label(mercury__options__option_defaults_2_0_i1);
	update_prof_current_proc(LABEL(mercury__options__option_defaults_2_0));
	{
	Declare_entry(do_fail);
	if (!((Integer) r1))
		GOTO(ENTRY(do_fail));
	}
	{
		call_localret(STATIC(mercury__options__option_default_2_0),
		mercury__options__option_defaults_2_0_i3,
		ENTRY(mercury__options__option_defaults_2_0));
	}
Define_label(mercury__options__option_defaults_2_0_i3);
	update_prof_current_proc(LABEL(mercury__options__option_defaults_2_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__options_module3)
	init_entry(mercury__options__option_default_2_0);
	init_label(mercury__options__option_default_2_0_i3);
	init_label(mercury__options__option_default_2_0_i5);
	init_label(mercury__options__option_default_2_0_i7);
	init_label(mercury__options__option_default_2_0_i9);
	init_label(mercury__options__option_default_2_0_i11);
	init_label(mercury__options__option_default_2_0_i13);
	init_label(mercury__options__option_default_2_0_i15);
	init_label(mercury__options__option_default_2_0_i17);
BEGIN_CODE

/* code for predicate 'option_default'/2 in mode 0 */
Define_entry(mercury__options__option_default_2_0);
	mkframe("option_default/2", 1, LABEL(mercury__options__option_default_2_0_i3));
	r1 = ((Integer) 0);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_options__common_2);
	succeed();
Define_label(mercury__options__option_default_2_0_i3);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i5);
	r1 = ((Integer) 1);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_options__common_2);
	succeed();
Define_label(mercury__options__option_default_2_0_i5);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i7);
	r1 = ((Integer) 2);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_options__common_2);
	succeed();
Define_label(mercury__options__option_default_2_0_i7);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i9);
	r1 = ((Integer) 3);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_options__common_2);
	succeed();
Define_label(mercury__options__option_default_2_0_i9);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i11);
	r1 = ((Integer) 4);
	r2 = (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_3);
	succeed();
Define_label(mercury__options__option_default_2_0_i11);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i13);
	r1 = ((Integer) 5);
	r2 = (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_4);
	succeed();
Define_label(mercury__options__option_default_2_0_i13);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i15);
	r1 = ((Integer) 6);
	r2 = (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_5);
	succeed();
Define_label(mercury__options__option_default_2_0_i15);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__options__option_default_2_0_i17);
	r1 = ((Integer) 7);
	r2 = (Integer) mkword(mktag(3), (Integer) mercury_data_options__common_6);
	succeed();
Define_label(mercury__options__option_default_2_0_i17);
	update_prof_current_proc(LABEL(mercury__options__option_default_2_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	r1 = ((Integer) 8);
	r2 = (Integer) mkword(mktag(1), (Integer) mercury_data_options__common_2);
	succeed();
END_MODULE

BEGIN_MODULE(mercury__options_module4)
	init_entry(mercury__options__options_help_2_0);
	init_label(mercury__options__options_help_2_0_i2);
	init_label(mercury__options__options_help_2_0_i3);
	init_label(mercury__options__options_help_2_0_i4);
	init_label(mercury__options__options_help_2_0_i5);
	init_label(mercury__options__options_help_2_0_i6);
	init_label(mercury__options__options_help_2_0_i7);
	init_label(mercury__options__options_help_2_0_i8);
	init_label(mercury__options__options_help_2_0_i9);
	init_label(mercury__options__options_help_2_0_i10);
	init_label(mercury__options__options_help_2_0_i11);
	init_label(mercury__options__options_help_2_0_i12);
	init_label(mercury__options__options_help_2_0_i13);
	init_label(mercury__options__options_help_2_0_i14);
	init_label(mercury__options__options_help_2_0_i15);
	init_label(mercury__options__options_help_2_0_i16);
	init_label(mercury__options__options_help_2_0_i17);
	init_label(mercury__options__options_help_2_0_i18);
	init_label(mercury__options__options_help_2_0_i19);
	init_label(mercury__options__options_help_2_0_i20);
BEGIN_CODE

/* code for predicate 'options_help'/2 in mode 0 */
Define_entry(mercury__options__options_help_2_0);
	r2 = (Integer) r1;
	r1 = string_const("\t-h, --help\n", 12);
	incr_sp_push_msg(1, "options_help");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i2,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i2);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tPrint this usage message.\n", 28);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i3,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i3);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\nProfiler Options:\n", 19);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i4,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i4);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-c, --call-graph\n", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i5,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i5);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tInclude the call graph profile\n", 33);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i6,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i6);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-d, --use-dynamic\n", 19);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i7,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i7);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tBuild the call graph dynamically.\n", 36);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i8,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i8);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-C, --count-file\n", 18);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i9,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i9);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tName of the count file. Usually `Prof.Counts'.\n", 49);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i10,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i10);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-D, --declaration-file\n", 24);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i11,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i11);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tName of the declaration file. Usually `Prof.Decl'.\n", 53);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i12,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i12);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-P, --call-pair-file\n", 22);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i13,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i13);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tName of the call-pair file. Usually `Prof.CallPair'.\n", 55);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i14,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i14);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-L, --library-callgraph\n", 25);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i15,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i15);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tName of the file which contains the callgraph for the library modules.\n", 73);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i16,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i16);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\nVerbosity Options:\n", 20);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i17,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i17);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-v, --verbose\n", 15);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i18,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i18);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tOutput progress messages at each stage.\n", 42);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i19,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i19);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t-V, --very_verbose\n", 20);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__options__options_help_2_0_i20,
		ENTRY(mercury__options__options_help_2_0));
	}
Define_label(mercury__options__options_help_2_0_i20);
	update_prof_current_proc(LABEL(mercury__options__options_help_2_0));
	r2 = (Integer) r1;
	r1 = string_const("\t\tOutput very verbose progress messages.\n", 41);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__options__options_help_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module5)
	init_entry(mercury__options__maybe_write_string_4_0);
	init_label(mercury__options__maybe_write_string_4_0_i1003);
BEGIN_CODE

/* code for predicate 'maybe_write_string'/4 in mode 0 */
Define_entry(mercury__options__maybe_write_string_4_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__options__maybe_write_string_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
Define_label(mercury__options__maybe_write_string_4_0_i1003);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__options__maybe_write_string_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module6)
	init_entry(mercury__options__maybe_flush_output_3_0);
	init_label(mercury__options__maybe_flush_output_3_0_i1003);
BEGIN_CODE

/* code for predicate 'maybe_flush_output'/3 in mode 0 */
Define_entry(mercury__options__maybe_flush_output_3_0);
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury__options__maybe_flush_output_3_0_i1003);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__options__maybe_flush_output_3_0_i1003);
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__io__flush_output_2_0);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		ENTRY(mercury__options__maybe_flush_output_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module7)
	init_entry(mercury____Unify___options__option_0_0);
	init_label(mercury____Unify___options__option_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___options__option_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___options__option_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___options__option_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__options_module8)
	init_entry(mercury____Index___options__option_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___options__option_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___options__option_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module9)
	init_entry(mercury____Compare___options__option_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___options__option_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___options__option_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module10)
	init_entry(mercury____Unify___options__option_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___options__option_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___options__option_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module11)
	init_entry(mercury____Index___options__option_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___options__option_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___options__option_table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__options_module12)
	init_entry(mercury____Compare___options__option_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___options__option_table_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_options__base_type_info_option_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___options__option_table_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__options_bunch_0(void)
{
	mercury__options_module0();
	mercury__options_module1();
	mercury__options_module2();
	mercury__options_module3();
	mercury__options_module4();
	mercury__options_module5();
	mercury__options_module6();
	mercury__options_module7();
	mercury__options_module8();
	mercury__options_module9();
	mercury__options_module10();
	mercury__options_module11();
	mercury__options_module12();
}

#endif

void mercury__options__init(void); /* suppress gcc warning */
void mercury__options__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__options_bunch_0();
#endif
}
