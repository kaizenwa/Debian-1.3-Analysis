/*
** Automatically generated from `term.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__term__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__term__vars_2_0);
Define_extern_entry(mercury__term__vars_2_3_0);
Declare_label(mercury__term__vars_2_3_0_i1003);
Define_extern_entry(mercury__term__vars_list_2_0);
Define_extern_entry(mercury__term__contains_var_2_0);
Declare_label(mercury__term__contains_var_2_0_i1003);
Define_extern_entry(mercury__term__contains_var_2_1);
Declare_label(mercury__term__contains_var_2_1_i2);
Declare_label(mercury__term__contains_var_2_1_i1);
Define_extern_entry(mercury__term__contains_var_list_2_0);
Declare_label(mercury__term__contains_var_list_2_0_i6);
Declare_label(mercury__term__contains_var_list_2_0_i3);
Declare_label(mercury__term__contains_var_list_2_0_i1003);
Define_extern_entry(mercury__term__contains_var_list_2_1);
Declare_label(mercury__term__contains_var_list_2_1_i4);
Declare_label(mercury__term__contains_var_list_2_1_i2);
Define_extern_entry(mercury__term__unify_4_0);
Declare_label(mercury__term__unify_4_0_i6);
Declare_label(mercury__term__unify_4_0_i8);
Declare_label(mercury__term__unify_4_0_i5);
Declare_label(mercury__term__unify_4_0_i12);
Declare_label(mercury__term__unify_4_0_i11);
Declare_label(mercury__term__unify_4_0_i18);
Declare_label(mercury__term__unify_4_0_i20);
Declare_label(mercury__term__unify_4_0_i1003);
Declare_label(mercury__term__unify_4_0_i26);
Declare_label(mercury__term__unify_4_0_i25);
Declare_label(mercury__term__unify_4_0_i32);
Declare_label(mercury__term__unify_4_0_i23);
Declare_label(mercury__term__unify_4_0_i38);
Declare_label(mercury__term__unify_4_0_i42);
Declare_label(mercury__term__unify_4_0_i41);
Declare_label(mercury__term__unify_4_0_i46);
Declare_label(mercury__term__unify_4_0_i50);
Declare_label(mercury__term__unify_4_0_i48);
Declare_label(mercury__term__unify_4_0_i47);
Declare_label(mercury__term__unify_4_0_i54);
Declare_label(mercury__term__unify_4_0_i37);
Declare_label(mercury__term__unify_4_0_i61);
Declare_label(mercury__term__unify_4_0_i63);
Declare_label(mercury__term__unify_4_0_i67);
Declare_label(mercury__term__unify_4_0_i65);
Declare_label(mercury__term__unify_4_0_i64);
Declare_label(mercury__term__unify_4_0_i71);
Declare_label(mercury__term__unify_4_0_i60);
Declare_label(mercury__term__unify_4_0_i77);
Declare_label(mercury__term__unify_4_0_i76);
Declare_label(mercury__term__unify_4_0_i79);
Declare_label(mercury__term__unify_4_0_i1);
Declare_label(mercury__term__unify_4_0_i1001);
Define_extern_entry(mercury__term__substitute_4_0);
Declare_label(mercury__term__substitute_4_0_i6);
Declare_label(mercury__term__substitute_4_0_i5);
Declare_label(mercury__term__substitute_4_0_i3);
Declare_label(mercury__term__substitute_4_0_i9);
Define_extern_entry(mercury__term__substitute_list_4_0);
Declare_label(mercury__term__substitute_list_4_0_i4);
Declare_label(mercury__term__substitute_list_4_0_i5);
Declare_label(mercury__term__substitute_list_4_0_i1002);
Define_extern_entry(mercury__term__substitute_corresponding_4_0);
Declare_label(mercury__term__substitute_corresponding_4_0_i2);
Declare_label(mercury__term__substitute_corresponding_4_0_i5);
Declare_label(mercury__term__substitute_corresponding_4_0_i4);
Define_extern_entry(mercury__term__substitute_corresponding_list_4_0);
Declare_label(mercury__term__substitute_corresponding_list_4_0_i2);
Declare_label(mercury__term__substitute_corresponding_list_4_0_i5);
Declare_label(mercury__term__substitute_corresponding_list_4_0_i4);
Define_extern_entry(mercury__term__apply_rec_substitution_3_0);
Declare_label(mercury__term__apply_rec_substitution_3_0_i6);
Declare_label(mercury__term__apply_rec_substitution_3_0_i5);
Declare_label(mercury__term__apply_rec_substitution_3_0_i3);
Declare_label(mercury__term__apply_rec_substitution_3_0_i10);
Define_extern_entry(mercury__term__apply_rec_substitution_to_list_3_0);
Declare_label(mercury__term__apply_rec_substitution_to_list_3_0_i4);
Declare_label(mercury__term__apply_rec_substitution_to_list_3_0_i5);
Declare_label(mercury__term__apply_rec_substitution_to_list_3_0_i1002);
Define_extern_entry(mercury__term__apply_substitution_3_0);
Declare_label(mercury__term__apply_substitution_3_0_i6);
Declare_label(mercury__term__apply_substitution_3_0_i5);
Declare_label(mercury__term__apply_substitution_3_0_i3);
Declare_label(mercury__term__apply_substitution_3_0_i9);
Define_extern_entry(mercury__term__apply_substitution_to_list_3_0);
Declare_label(mercury__term__apply_substitution_to_list_3_0_i4);
Declare_label(mercury__term__apply_substitution_to_list_3_0_i5);
Declare_label(mercury__term__apply_substitution_to_list_3_0_i1002);
Define_extern_entry(mercury__term__occurs_3_0);
Declare_label(mercury__term__occurs_3_0_i1002);
Declare_label(mercury__term__occurs_3_0_i8);
Declare_label(mercury__term__occurs_3_0_i10);
Declare_label(mercury__term__occurs_3_0_i2);
Declare_label(mercury__term__occurs_3_0_i1);
Define_extern_entry(mercury__term__occurs_list_3_0);
Declare_label(mercury__term__occurs_list_3_0_i5);
Declare_label(mercury__term__occurs_list_3_0_i9);
Declare_label(mercury__term__occurs_list_3_0_i1003);
Define_extern_entry(mercury__term__relabel_variable_4_0);
Declare_label(mercury__term__relabel_variable_4_0_i6);
Declare_label(mercury__term__relabel_variable_4_0_i5);
Declare_label(mercury__term__relabel_variable_4_0_i3);
Declare_label(mercury__term__relabel_variable_4_0_i9);
Define_extern_entry(mercury__term__relabel_variables_4_0);
Declare_label(mercury__term__relabel_variables_4_0_i4);
Declare_label(mercury__term__relabel_variables_4_0_i5);
Declare_label(mercury__term__relabel_variables_4_0_i1002);
Define_extern_entry(mercury__term__apply_variable_renaming_3_0);
Declare_label(mercury__term__apply_variable_renaming_3_0_i6);
Declare_label(mercury__term__apply_variable_renaming_3_0_i1005);
Declare_label(mercury__term__apply_variable_renaming_3_0_i3);
Declare_label(mercury__term__apply_variable_renaming_3_0_i9);
Define_extern_entry(mercury__term__apply_variable_renaming_to_list_3_0);
Declare_label(mercury__term__apply_variable_renaming_to_list_3_0_i4);
Declare_label(mercury__term__apply_variable_renaming_to_list_3_0_i5);
Declare_label(mercury__term__apply_variable_renaming_to_list_3_0_i1002);
Define_extern_entry(mercury__term__is_ground_2_0);
Declare_label(mercury__term__is_ground_2_0_i1001);
Declare_label(mercury__term__is_ground_2_0_i6);
Declare_label(mercury__term__is_ground_2_0_i1);
Define_extern_entry(mercury__term__is_ground_1_0);
Declare_label(mercury__term__is_ground_1_0_i1002);
Define_extern_entry(mercury__term__compare_4_0);
Declare_label(mercury__term__compare_4_0_i2);
Declare_label(mercury__term__compare_4_0_i3);
Declare_label(mercury__term__compare_4_0_i5);
Declare_label(mercury__term__compare_4_0_i6);
Declare_label(mercury__term__compare_4_0_i8);
Declare_label(mercury__term__compare_4_0_i1);
Define_extern_entry(mercury__term__context_line_2_0);
Define_extern_entry(mercury__term__context_file_2_0);
Define_extern_entry(mercury__term__context_init_3_0);
Define_extern_entry(mercury__term__term_list_to_var_list_2_0);
Declare_label(mercury__term__term_list_to_var_list_2_0_i4);
Declare_label(mercury__term__term_list_to_var_list_2_0_i1000);
Define_extern_entry(mercury__term__var_list_to_term_list_2_1);
Declare_label(mercury__term__var_list_to_term_list_2_1_i1001);
Declare_label(mercury__term__var_list_to_term_list_2_1_i5);
Declare_label(mercury__term__var_list_to_term_list_2_1_i1);
Define_extern_entry(mercury__term__var_list_to_term_list_2_0);
Declare_label(mercury__term__var_list_to_term_list_2_0_i3);
Declare_label(mercury__term__var_list_to_term_list_2_0_i4);
Declare_label(mercury__term__var_list_to_term_list_2_0_i1);
Declare_static(mercury__term__vars_2_list_3_0);
Declare_label(mercury__term__vars_2_list_3_0_i4);
Declare_label(mercury__term__vars_2_list_3_0_i1002);
Declare_static(mercury__term__unify_list_4_0);
Declare_label(mercury__term__unify_list_4_0_i1010);
Declare_label(mercury__term__unify_list_4_0_i6);
Declare_label(mercury__term__unify_list_4_0_i8);
Declare_label(mercury__term__unify_list_4_0_i1007);
Declare_label(mercury__term__unify_list_4_0_i1);
Declare_label(mercury__term__unify_list_4_0_i1009);
Declare_static(mercury__term__substitute_corresponding_2_4_0);
Declare_label(mercury__term__substitute_corresponding_2_4_0_i1009);
Declare_label(mercury__term__substitute_corresponding_2_4_0_i6);
Declare_label(mercury__term__substitute_corresponding_2_4_0_i7);
Declare_label(mercury__term__substitute_corresponding_2_4_0_i1006);
Declare_label(mercury__term__substitute_corresponding_2_4_0_i1);
Declare_label(mercury__term__substitute_corresponding_2_4_0_i1008);
Declare_static(mercury__term__is_ground_2_2_0);
Declare_label(mercury__term__is_ground_2_2_0_i4);
Declare_label(mercury__term__is_ground_2_2_0_i1003);
Declare_label(mercury__term__is_ground_2_2_0_i1);
Declare_static(mercury__term__is_ground_2_1_0);
Declare_label(mercury__term__is_ground_2_1_0_i4);
Declare_label(mercury__term__is_ground_2_1_0_i1003);
Declare_label(mercury__term__is_ground_2_1_0_i1);
Define_extern_entry(mercury____Unify___term__substitution_0_0);
Define_extern_entry(mercury____Index___term__substitution_0_0);
Define_extern_entry(mercury____Compare___term__substitution_0_0);

extern Word * mercury_data_term__base_type_layout_substitution_0[];
Word * mercury_data_term__base_type_info_substitution_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___term__substitution_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___term__substitution_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___term__substitution_0_0),
	(Word *) (Integer) mercury_data_term__base_type_layout_substitution_0
};

extern Word * mercury_data_term__common_1[];
Word * mercury_data_term__base_type_layout_substitution_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_term__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_term__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_term__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_term__common_1)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data_mercury_builtin__base_type_info_var_0[];
extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_term__common_0[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_var_0,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_term__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_term__common_0)
};

BEGIN_MODULE(mercury__term_module0)
	init_entry(mercury__term__vars_2_0);
BEGIN_CODE

/* code for predicate 'term__vars'/2 in mode 0 */
Define_entry(mercury__term__vars_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
		tailcall(STATIC(mercury__term__vars_2_3_0),
		ENTRY(mercury__term__vars_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module1)
	init_entry(mercury__term__vars_2_3_0);
	init_label(mercury__term__vars_2_3_0_i1003);
BEGIN_CODE

/* code for predicate 'term__vars_2'/3 in mode 0 */
Define_entry(mercury__term__vars_2_3_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__vars_2_3_0_i1003);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
Define_label(mercury__term__vars_2_3_0_i1003);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__term__vars_2_list_3_0),
		ENTRY(mercury__term__vars_2_3_0));
END_MODULE

BEGIN_MODULE(mercury__term_module2)
	init_entry(mercury__term__vars_list_2_0);
BEGIN_CODE

/* code for predicate 'term__vars_list'/2 in mode 0 */
Define_entry(mercury__term__vars_list_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__term__vars_2_list_3_0),
		ENTRY(mercury__term__vars_list_2_0));
END_MODULE

BEGIN_MODULE(mercury__term_module3)
	init_entry(mercury__term__contains_var_2_0);
	init_label(mercury__term__contains_var_2_0_i1003);
BEGIN_CODE

/* code for predicate 'term__contains_var'/2 in mode 0 */
Define_entry(mercury__term__contains_var_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__contains_var_2_0_i1003);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__term__contains_var_list_2_0),
		ENTRY(mercury__term__contains_var_2_0));
	}
Define_label(mercury__term__contains_var_2_0_i1003);
	r3 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		ENTRY(mercury__term__contains_var_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module4)
	init_entry(mercury__term__contains_var_2_1);
	init_label(mercury__term__contains_var_2_1_i2);
	init_label(mercury__term__contains_var_2_1_i1);
BEGIN_CODE

/* code for predicate 'term__contains_var'/2 in mode 1 */
Define_entry(mercury__term__contains_var_2_1);
	{
	Declare_entry(do_fail);
	mkframe("term__contains_var/2", 1, ENTRY(do_fail));
	}
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__contains_var_2_1_i2);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__term__contains_var_list_2_1),
		mercury__term__contains_var_2_1_i1,
		ENTRY(mercury__term__contains_var_2_1));
	}
Define_label(mercury__term__contains_var_2_1_i2);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
Define_label(mercury__term__contains_var_2_1_i1);
	update_prof_current_proc(LABEL(mercury__term__contains_var_2_1));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__term_module5)
	init_entry(mercury__term__contains_var_list_2_0);
	init_label(mercury__term__contains_var_list_2_0_i6);
	init_label(mercury__term__contains_var_list_2_0_i3);
	init_label(mercury__term__contains_var_list_2_0_i1003);
BEGIN_CODE

/* code for predicate 'term__contains_var_list'/2 in mode 0 */
Define_entry(mercury__term__contains_var_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__contains_var_list_2_0_i1003);
	incr_sp_push_msg(3, "term__contains_var_list");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__contains_var_2_0),
		mercury__term__contains_var_list_2_0_i6,
		ENTRY(mercury__term__contains_var_list_2_0));
	}
Define_label(mercury__term__contains_var_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__term__contains_var_list_2_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__contains_var_list_2_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__term__contains_var_list_2_0,
		ENTRY(mercury__term__contains_var_list_2_0));
Define_label(mercury__term__contains_var_list_2_0_i3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__contains_var_list_2_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module6)
	init_entry(mercury__term__contains_var_list_2_1);
	init_label(mercury__term__contains_var_list_2_1_i4);
	init_label(mercury__term__contains_var_list_2_1_i2);
BEGIN_CODE

/* code for predicate 'term__contains_var_list'/2 in mode 1 */
Define_entry(mercury__term__contains_var_list_2_1);
	{
	Declare_entry(do_redo);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO(ENTRY(do_redo));
	}
	mkframe("term__contains_var_list/2", 1, LABEL(mercury__term__contains_var_list_2_1_i4));
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	framevar(0) = (Integer) r2;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__contains_var_2_1),
		mercury__term__contains_var_list_2_1_i2,
		ENTRY(mercury__term__contains_var_list_2_1));
	}
Define_label(mercury__term__contains_var_list_2_1_i4);
	update_prof_current_proc(LABEL(mercury__term__contains_var_list_2_1));
	r2 = (Integer) framevar(0);
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	r1 = (Integer) r2;
	localcall(mercury__term__contains_var_list_2_1,
		LABEL(mercury__term__contains_var_list_2_1_i2),
		ENTRY(mercury__term__contains_var_list_2_1));
Define_label(mercury__term__contains_var_list_2_1_i2);
	update_prof_current_proc(LABEL(mercury__term__contains_var_list_2_1));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__term_module7)
	init_entry(mercury__term__unify_4_0);
	init_label(mercury__term__unify_4_0_i6);
	init_label(mercury__term__unify_4_0_i8);
	init_label(mercury__term__unify_4_0_i5);
	init_label(mercury__term__unify_4_0_i12);
	init_label(mercury__term__unify_4_0_i11);
	init_label(mercury__term__unify_4_0_i18);
	init_label(mercury__term__unify_4_0_i20);
	init_label(mercury__term__unify_4_0_i1003);
	init_label(mercury__term__unify_4_0_i26);
	init_label(mercury__term__unify_4_0_i25);
	init_label(mercury__term__unify_4_0_i32);
	init_label(mercury__term__unify_4_0_i23);
	init_label(mercury__term__unify_4_0_i38);
	init_label(mercury__term__unify_4_0_i42);
	init_label(mercury__term__unify_4_0_i41);
	init_label(mercury__term__unify_4_0_i46);
	init_label(mercury__term__unify_4_0_i50);
	init_label(mercury__term__unify_4_0_i48);
	init_label(mercury__term__unify_4_0_i47);
	init_label(mercury__term__unify_4_0_i54);
	init_label(mercury__term__unify_4_0_i37);
	init_label(mercury__term__unify_4_0_i61);
	init_label(mercury__term__unify_4_0_i63);
	init_label(mercury__term__unify_4_0_i67);
	init_label(mercury__term__unify_4_0_i65);
	init_label(mercury__term__unify_4_0_i64);
	init_label(mercury__term__unify_4_0_i71);
	init_label(mercury__term__unify_4_0_i60);
	init_label(mercury__term__unify_4_0_i77);
	init_label(mercury__term__unify_4_0_i76);
	init_label(mercury__term__unify_4_0_i79);
	init_label(mercury__term__unify_4_0_i1);
	init_label(mercury__term__unify_4_0_i1001);
BEGIN_CODE

/* code for predicate 'term__unify'/4 in mode 0 */
Define_entry(mercury__term__unify_4_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__unify_4_0_i1003);
	incr_sp_push_msg(6, "term__unify");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__unify_4_0_i5);
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__const_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__const_0_0),
		mercury__term__unify_4_0_i6,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i1);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__term__unify_list_4_0),
		mercury__term__unify_4_0_i8,
		ENTRY(mercury__term__unify_4_0));
Define_label(mercury__term__unify_4_0_i8);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__unify_4_0_i1001);
	r1 = FALSE;
	proceed();
Define_label(mercury__term__unify_4_0_i5);
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) r4;
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__unify_4_0_i12,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i12);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i11);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term__unify_4_0,
		LABEL(mercury__term__unify_4_0_i8),
		ENTRY(mercury__term__unify_4_0));
Define_label(mercury__term__unify_4_0_i11);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__occurs_list_3_0),
		mercury__term__unify_4_0_i18,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i18);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__unify_4_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__term__unify_4_0_i20,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i20);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term__unify_4_0_i1003);
	incr_sp_push_msg(6, "term__unify");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__unify_4_0_i23);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__unify_4_0_i26,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i26);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i25);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term__unify_4_0,
		LABEL(mercury__term__unify_4_0_i8),
		ENTRY(mercury__term__unify_4_0));
Define_label(mercury__term__unify_4_0_i25);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__occurs_list_3_0),
		mercury__term__unify_4_0_i32,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i32);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__unify_4_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__term__unify_4_0_i20,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i23);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(5) = (Integer) r4;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__unify_4_0_i38,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i38);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i37);
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__unify_4_0_i42,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i42);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i41);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term__unify_4_0,
		LABEL(mercury__term__unify_4_0_i8),
		ENTRY(mercury__term__unify_4_0));
Define_label(mercury__term__unify_4_0_i41);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__apply_rec_substitution_3_0),
		mercury__term__unify_4_0_i46,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i46);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__term__unify_4_0_i47);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__term__unify_4_0_i50,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i50);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i48);
	r2 = (Integer) detstackvar(2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term__unify_4_0_i48);
	r1 = (Integer) detstackvar(4);
Define_label(mercury__term__unify_4_0_i47);
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__occurs_3_0),
		mercury__term__unify_4_0_i54,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i54);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__unify_4_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__term__unify_4_0_i20,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i37);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__unify_4_0_i61,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i61);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i60);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__apply_rec_substitution_3_0),
		mercury__term__unify_4_0_i63,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i63);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__term__unify_4_0_i64);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__term__unify_4_0_i67,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i67);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i65);
	r2 = (Integer) detstackvar(2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term__unify_4_0_i65);
	r1 = (Integer) detstackvar(4);
Define_label(mercury__term__unify_4_0_i64);
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__occurs_3_0),
		mercury__term__unify_4_0_i71,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i71);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__unify_4_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__term__unify_4_0_i20,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i60);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__term__unify_4_0_i77,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i77);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_4_0_i76);
	r2 = (Integer) detstackvar(2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term__unify_4_0_i76);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__term__unify_4_0_i79,
		ENTRY(mercury__term__unify_4_0));
	}
Define_label(mercury__term__unify_4_0_i79);
	update_prof_current_proc(LABEL(mercury__term__unify_4_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term__unify_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term__unify_4_0_i1001);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module8)
	init_entry(mercury__term__substitute_4_0);
	init_label(mercury__term__substitute_4_0_i6);
	init_label(mercury__term__substitute_4_0_i5);
	init_label(mercury__term__substitute_4_0_i3);
	init_label(mercury__term__substitute_4_0_i9);
BEGIN_CODE

/* code for predicate 'term__substitute'/4 in mode 0 */
Define_entry(mercury__term__substitute_4_0);
	incr_sp_push_msg(3, "term__substitute");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__substitute_4_0_i3);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__term__substitute_4_0_i6,
		ENTRY(mercury__term__substitute_4_0));
	}
Define_label(mercury__term__substitute_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term__substitute_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__substitute_4_0_i5);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__substitute_4_0_i5);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__substitute_4_0_i3);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__term__substitute_list_4_0),
		mercury__term__substitute_4_0_i9,
		ENTRY(mercury__term__substitute_4_0));
	}
Define_label(mercury__term__substitute_4_0_i9);
	update_prof_current_proc(LABEL(mercury__term__substitute_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module9)
	init_entry(mercury__term__substitute_list_4_0);
	init_label(mercury__term__substitute_list_4_0_i4);
	init_label(mercury__term__substitute_list_4_0_i5);
	init_label(mercury__term__substitute_list_4_0_i1002);
BEGIN_CODE

/* code for predicate 'term__substitute_list'/4 in mode 0 */
Define_entry(mercury__term__substitute_list_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__substitute_list_4_0_i1002);
	incr_sp_push_msg(4, "term__substitute_list");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__substitute_4_0),
		mercury__term__substitute_list_4_0_i4,
		ENTRY(mercury__term__substitute_list_4_0));
	}
Define_label(mercury__term__substitute_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__term__substitute_list_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term__substitute_list_4_0,
		LABEL(mercury__term__substitute_list_4_0_i5),
		ENTRY(mercury__term__substitute_list_4_0));
Define_label(mercury__term__substitute_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term__substitute_list_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term__substitute_list_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module10)
	init_entry(mercury__term__substitute_corresponding_4_0);
	init_label(mercury__term__substitute_corresponding_4_0_i2);
	init_label(mercury__term__substitute_corresponding_4_0_i5);
	init_label(mercury__term__substitute_corresponding_4_0_i4);
BEGIN_CODE

/* code for predicate 'term__substitute_corresponding'/4 in mode 0 */
Define_entry(mercury__term__substitute_corresponding_4_0);
	incr_sp_push_msg(4, "term__substitute_corresponding");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__term__substitute_corresponding_4_0_i2,
		ENTRY(mercury__term__substitute_corresponding_4_0));
	}
Define_label(mercury__term__substitute_corresponding_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term__substitute_corresponding_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__term__substitute_corresponding_2_4_0),
		mercury__term__substitute_corresponding_4_0_i5,
		ENTRY(mercury__term__substitute_corresponding_4_0));
Define_label(mercury__term__substitute_corresponding_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term__substitute_corresponding_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__substitute_corresponding_4_0_i4);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
		tailcall(STATIC(mercury__term__apply_substitution_3_0),
		ENTRY(mercury__term__substitute_corresponding_4_0));
	}
Define_label(mercury__term__substitute_corresponding_4_0_i4);
	r1 = string_const("term__substitute_corresponding: different length lists", 54);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__term__substitute_corresponding_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module11)
	init_entry(mercury__term__substitute_corresponding_list_4_0);
	init_label(mercury__term__substitute_corresponding_list_4_0_i2);
	init_label(mercury__term__substitute_corresponding_list_4_0_i5);
	init_label(mercury__term__substitute_corresponding_list_4_0_i4);
BEGIN_CODE

/* code for predicate 'term__substitute_corresponding_list'/4 in mode 0 */
Define_entry(mercury__term__substitute_corresponding_list_4_0);
	incr_sp_push_msg(4, "term__substitute_corresponding_list");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__term__substitute_corresponding_list_4_0_i2,
		ENTRY(mercury__term__substitute_corresponding_list_4_0));
	}
Define_label(mercury__term__substitute_corresponding_list_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term__substitute_corresponding_list_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__term__substitute_corresponding_2_4_0),
		mercury__term__substitute_corresponding_list_4_0_i5,
		ENTRY(mercury__term__substitute_corresponding_list_4_0));
Define_label(mercury__term__substitute_corresponding_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term__substitute_corresponding_list_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__substitute_corresponding_list_4_0_i4);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
		tailcall(STATIC(mercury__term__apply_substitution_to_list_3_0),
		ENTRY(mercury__term__substitute_corresponding_list_4_0));
	}
Define_label(mercury__term__substitute_corresponding_list_4_0_i4);
	r1 = string_const("term__substitute_corresponding_list: different length lists", 59);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__term__substitute_corresponding_list_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module12)
	init_entry(mercury__term__apply_rec_substitution_3_0);
	init_label(mercury__term__apply_rec_substitution_3_0_i6);
	init_label(mercury__term__apply_rec_substitution_3_0_i5);
	init_label(mercury__term__apply_rec_substitution_3_0_i3);
	init_label(mercury__term__apply_rec_substitution_3_0_i10);
BEGIN_CODE

/* code for predicate 'term__apply_rec_substitution'/3 in mode 0 */
Define_entry(mercury__term__apply_rec_substitution_3_0);
	incr_sp_push_msg(3, "term__apply_rec_substitution");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__apply_rec_substitution_3_0_i3);
	r3 = (Integer) r2;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__apply_rec_substitution_3_0_i6,
		ENTRY(mercury__term__apply_rec_substitution_3_0));
	}
Define_label(mercury__term__apply_rec_substitution_3_0_i6);
	update_prof_current_proc(LABEL(mercury__term__apply_rec_substitution_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__apply_rec_substitution_3_0_i5);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__term__apply_rec_substitution_3_0,
		ENTRY(mercury__term__apply_rec_substitution_3_0));
Define_label(mercury__term__apply_rec_substitution_3_0_i5);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_rec_substitution_3_0_i3);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__term__apply_rec_substitution_to_list_3_0),
		mercury__term__apply_rec_substitution_3_0_i10,
		ENTRY(mercury__term__apply_rec_substitution_3_0));
	}
Define_label(mercury__term__apply_rec_substitution_3_0_i10);
	update_prof_current_proc(LABEL(mercury__term__apply_rec_substitution_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module13)
	init_entry(mercury__term__apply_rec_substitution_to_list_3_0);
	init_label(mercury__term__apply_rec_substitution_to_list_3_0_i4);
	init_label(mercury__term__apply_rec_substitution_to_list_3_0_i5);
	init_label(mercury__term__apply_rec_substitution_to_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'term__apply_rec_substitution_to_list'/3 in mode 0 */
Define_entry(mercury__term__apply_rec_substitution_to_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__apply_rec_substitution_to_list_3_0_i1002);
	incr_sp_push_msg(3, "term__apply_rec_substitution_to_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__apply_rec_substitution_3_0),
		mercury__term__apply_rec_substitution_to_list_3_0_i4,
		ENTRY(mercury__term__apply_rec_substitution_to_list_3_0));
	}
Define_label(mercury__term__apply_rec_substitution_to_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term__apply_rec_substitution_to_list_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__term__apply_rec_substitution_to_list_3_0,
		LABEL(mercury__term__apply_rec_substitution_to_list_3_0_i5),
		ENTRY(mercury__term__apply_rec_substitution_to_list_3_0));
Define_label(mercury__term__apply_rec_substitution_to_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__term__apply_rec_substitution_to_list_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_rec_substitution_to_list_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module14)
	init_entry(mercury__term__apply_substitution_3_0);
	init_label(mercury__term__apply_substitution_3_0_i6);
	init_label(mercury__term__apply_substitution_3_0_i5);
	init_label(mercury__term__apply_substitution_3_0_i3);
	init_label(mercury__term__apply_substitution_3_0_i9);
BEGIN_CODE

/* code for predicate 'term__apply_substitution'/3 in mode 0 */
Define_entry(mercury__term__apply_substitution_3_0);
	incr_sp_push_msg(3, "term__apply_substitution");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__apply_substitution_3_0_i3);
	r3 = (Integer) r2;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__apply_substitution_3_0_i6,
		ENTRY(mercury__term__apply_substitution_3_0));
	}
Define_label(mercury__term__apply_substitution_3_0_i6);
	update_prof_current_proc(LABEL(mercury__term__apply_substitution_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__apply_substitution_3_0_i5);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_substitution_3_0_i5);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_substitution_3_0_i3);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__term__apply_substitution_to_list_3_0),
		mercury__term__apply_substitution_3_0_i9,
		ENTRY(mercury__term__apply_substitution_3_0));
	}
Define_label(mercury__term__apply_substitution_3_0_i9);
	update_prof_current_proc(LABEL(mercury__term__apply_substitution_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module15)
	init_entry(mercury__term__apply_substitution_to_list_3_0);
	init_label(mercury__term__apply_substitution_to_list_3_0_i4);
	init_label(mercury__term__apply_substitution_to_list_3_0_i5);
	init_label(mercury__term__apply_substitution_to_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'term__apply_substitution_to_list'/3 in mode 0 */
Define_entry(mercury__term__apply_substitution_to_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__apply_substitution_to_list_3_0_i1002);
	incr_sp_push_msg(3, "term__apply_substitution_to_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__apply_substitution_3_0),
		mercury__term__apply_substitution_to_list_3_0_i4,
		ENTRY(mercury__term__apply_substitution_to_list_3_0));
	}
Define_label(mercury__term__apply_substitution_to_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term__apply_substitution_to_list_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__term__apply_substitution_to_list_3_0,
		LABEL(mercury__term__apply_substitution_to_list_3_0_i5),
		ENTRY(mercury__term__apply_substitution_to_list_3_0));
Define_label(mercury__term__apply_substitution_to_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__term__apply_substitution_to_list_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_substitution_to_list_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module16)
	init_entry(mercury__term__occurs_3_0);
	init_label(mercury__term__occurs_3_0_i1002);
	init_label(mercury__term__occurs_3_0_i8);
	init_label(mercury__term__occurs_3_0_i10);
	init_label(mercury__term__occurs_3_0_i2);
	init_label(mercury__term__occurs_3_0_i1);
BEGIN_CODE

/* code for predicate 'term__occurs'/3 in mode 0 */
Define_entry(mercury__term__occurs_3_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__occurs_3_0_i1002);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		tailcall(STATIC(mercury__term__occurs_list_3_0),
		ENTRY(mercury__term__occurs_3_0));
	}
Define_label(mercury__term__occurs_3_0_i1002);
	incr_sp_push_msg(4, "term__occurs");
	detstackvar(4) = (Integer) succip;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__term__occurs_3_0_i8,
		ENTRY(mercury__term__occurs_3_0));
	}
Define_label(mercury__term__occurs_3_0_i8);
	update_prof_current_proc(LABEL(mercury__term__occurs_3_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__occurs_3_0_i2);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__occurs_3_0_i10,
		ENTRY(mercury__term__occurs_3_0));
	}
Define_label(mercury__term__occurs_3_0_i10);
	update_prof_current_proc(LABEL(mercury__term__occurs_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__occurs_3_0_i1);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__term__occurs_3_0,
		ENTRY(mercury__term__occurs_3_0));
Define_label(mercury__term__occurs_3_0_i2);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term__occurs_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module17)
	init_entry(mercury__term__occurs_list_3_0);
	init_label(mercury__term__occurs_list_3_0_i5);
	init_label(mercury__term__occurs_list_3_0_i9);
	init_label(mercury__term__occurs_list_3_0_i1003);
BEGIN_CODE

/* code for predicate 'term__occurs_list'/3 in mode 0 */
Define_entry(mercury__term__occurs_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__occurs_list_3_0_i1003);
	incr_sp_push_msg(4, "term__occurs_list");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	{
		call_localret(STATIC(mercury__term__occurs_3_0),
		mercury__term__occurs_list_3_0_i5,
		ENTRY(mercury__term__occurs_list_3_0));
	}
Define_label(mercury__term__occurs_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__term__occurs_list_3_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__term__occurs_list_3_0_i9);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__term__occurs_list_3_0,
		ENTRY(mercury__term__occurs_list_3_0));
Define_label(mercury__term__occurs_list_3_0_i9);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term__occurs_list_3_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module18)
	init_entry(mercury__term__relabel_variable_4_0);
	init_label(mercury__term__relabel_variable_4_0_i6);
	init_label(mercury__term__relabel_variable_4_0_i5);
	init_label(mercury__term__relabel_variable_4_0_i3);
	init_label(mercury__term__relabel_variable_4_0_i9);
BEGIN_CODE

/* code for predicate 'term__relabel_variable'/4 in mode 0 */
Define_entry(mercury__term__relabel_variable_4_0);
	incr_sp_push_msg(3, "term__relabel_variable");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__relabel_variable_4_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) r1;
	detstackvar(1) = (Integer) r3;
	{
	Declare_entry(mercury____Unify___mercury_builtin__var_0_0);
	call_localret(ENTRY(mercury____Unify___mercury_builtin__var_0_0),
		mercury__term__relabel_variable_4_0_i6,
		ENTRY(mercury__term__relabel_variable_4_0));
	}
Define_label(mercury__term__relabel_variable_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term__relabel_variable_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__relabel_variable_4_0_i5);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__relabel_variable_4_0_i5);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__relabel_variable_4_0_i3);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__term__relabel_variables_4_0),
		mercury__term__relabel_variable_4_0_i9,
		ENTRY(mercury__term__relabel_variable_4_0));
	}
Define_label(mercury__term__relabel_variable_4_0_i9);
	update_prof_current_proc(LABEL(mercury__term__relabel_variable_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module19)
	init_entry(mercury__term__relabel_variables_4_0);
	init_label(mercury__term__relabel_variables_4_0_i4);
	init_label(mercury__term__relabel_variables_4_0_i5);
	init_label(mercury__term__relabel_variables_4_0_i1002);
BEGIN_CODE

/* code for predicate 'term__relabel_variables'/4 in mode 0 */
Define_entry(mercury__term__relabel_variables_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__relabel_variables_4_0_i1002);
	incr_sp_push_msg(4, "term__relabel_variables");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__relabel_variable_4_0),
		mercury__term__relabel_variables_4_0_i4,
		ENTRY(mercury__term__relabel_variables_4_0));
	}
Define_label(mercury__term__relabel_variables_4_0_i4);
	update_prof_current_proc(LABEL(mercury__term__relabel_variables_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term__relabel_variables_4_0,
		LABEL(mercury__term__relabel_variables_4_0_i5),
		ENTRY(mercury__term__relabel_variables_4_0));
Define_label(mercury__term__relabel_variables_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term__relabel_variables_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term__relabel_variables_4_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module20)
	init_entry(mercury__term__apply_variable_renaming_3_0);
	init_label(mercury__term__apply_variable_renaming_3_0_i6);
	init_label(mercury__term__apply_variable_renaming_3_0_i1005);
	init_label(mercury__term__apply_variable_renaming_3_0_i3);
	init_label(mercury__term__apply_variable_renaming_3_0_i9);
BEGIN_CODE

/* code for predicate 'term__apply_variable_renaming'/3 in mode 0 */
Define_entry(mercury__term__apply_variable_renaming_3_0);
	incr_sp_push_msg(3, "term__apply_variable_renaming");
	detstackvar(3) = (Integer) succip;
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__apply_variable_renaming_3_0_i3);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r4;
	r3 = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__apply_variable_renaming_3_0_i6,
		ENTRY(mercury__term__apply_variable_renaming_3_0));
	}
Define_label(mercury__term__apply_variable_renaming_3_0_i6);
	update_prof_current_proc(LABEL(mercury__term__apply_variable_renaming_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__apply_variable_renaming_3_0_i1005);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_variable_renaming_3_0_i1005);
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_variable_renaming_3_0_i3);
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	{
		call_localret(STATIC(mercury__term__apply_variable_renaming_to_list_3_0),
		mercury__term__apply_variable_renaming_3_0_i9,
		ENTRY(mercury__term__apply_variable_renaming_3_0));
	}
Define_label(mercury__term__apply_variable_renaming_3_0_i9);
	update_prof_current_proc(LABEL(mercury__term__apply_variable_renaming_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module21)
	init_entry(mercury__term__apply_variable_renaming_to_list_3_0);
	init_label(mercury__term__apply_variable_renaming_to_list_3_0_i4);
	init_label(mercury__term__apply_variable_renaming_to_list_3_0_i5);
	init_label(mercury__term__apply_variable_renaming_to_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'term__apply_variable_renaming_to_list'/3 in mode 0 */
Define_entry(mercury__term__apply_variable_renaming_to_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__apply_variable_renaming_to_list_3_0_i1002);
	incr_sp_push_msg(3, "term__apply_variable_renaming_to_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__apply_variable_renaming_3_0),
		mercury__term__apply_variable_renaming_to_list_3_0_i4,
		ENTRY(mercury__term__apply_variable_renaming_to_list_3_0));
	}
Define_label(mercury__term__apply_variable_renaming_to_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term__apply_variable_renaming_to_list_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	localcall(mercury__term__apply_variable_renaming_to_list_3_0,
		LABEL(mercury__term__apply_variable_renaming_to_list_3_0_i5),
		ENTRY(mercury__term__apply_variable_renaming_to_list_3_0));
Define_label(mercury__term__apply_variable_renaming_to_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__term__apply_variable_renaming_to_list_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__apply_variable_renaming_to_list_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module22)
	init_entry(mercury__term__is_ground_2_0);
	init_label(mercury__term__is_ground_2_0_i1001);
	init_label(mercury__term__is_ground_2_0_i6);
	init_label(mercury__term__is_ground_2_0_i1);
BEGIN_CODE

/* code for predicate 'term__is_ground'/2 in mode 0 */
Define_entry(mercury__term__is_ground_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__is_ground_2_0_i1001);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__term__is_ground_2_2_0),
		ENTRY(mercury__term__is_ground_2_0));
Define_label(mercury__term__is_ground_2_0_i1001);
	incr_sp_push_msg(2, "term__is_ground");
	detstackvar(2) = (Integer) succip;
	r3 = (Integer) r2;
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term__is_ground_2_0_i6,
		ENTRY(mercury__term__is_ground_2_0));
	}
Define_label(mercury__term__is_ground_2_0_i6);
	update_prof_current_proc(LABEL(mercury__term__is_ground_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__is_ground_2_0_i1);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__term__is_ground_2_0,
		ENTRY(mercury__term__is_ground_2_0));
Define_label(mercury__term__is_ground_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module23)
	init_entry(mercury__term__is_ground_1_0);
	init_label(mercury__term__is_ground_1_0_i1002);
BEGIN_CODE

/* code for predicate 'term__is_ground'/1 in mode 0 */
Define_entry(mercury__term__is_ground_1_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term__is_ground_1_0_i1002);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	tailcall(STATIC(mercury__term__is_ground_2_1_0),
		ENTRY(mercury__term__is_ground_1_0));
Define_label(mercury__term__is_ground_1_0_i1002);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module24)
	init_entry(mercury__term__compare_4_0);
	init_label(mercury__term__compare_4_0_i2);
	init_label(mercury__term__compare_4_0_i3);
	init_label(mercury__term__compare_4_0_i5);
	init_label(mercury__term__compare_4_0_i6);
	init_label(mercury__term__compare_4_0_i8);
	init_label(mercury__term__compare_4_0_i1);
BEGIN_CODE

/* code for predicate 'term__compare'/4 in mode 0 */
Define_entry(mercury__term__compare_4_0);
	incr_sp_push_msg(4, "term__compare");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) r3;
	{
		call_localret(STATIC(mercury__term__apply_rec_substitution_3_0),
		mercury__term__compare_4_0_i2,
		ENTRY(mercury__term__compare_4_0));
	}
Define_label(mercury__term__compare_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term__compare_4_0));
	detstackvar(3) = (Integer) r1;
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__is_ground_2_0),
		mercury__term__compare_4_0_i3,
		ENTRY(mercury__term__compare_4_0));
	}
Define_label(mercury__term__compare_4_0_i3);
	update_prof_current_proc(LABEL(mercury__term__compare_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__compare_4_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__apply_rec_substitution_3_0),
		mercury__term__compare_4_0_i5,
		ENTRY(mercury__term__compare_4_0));
	}
Define_label(mercury__term__compare_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term__compare_4_0));
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__term__is_ground_2_0),
		mercury__term__compare_4_0_i6,
		ENTRY(mercury__term__compare_4_0));
	}
Define_label(mercury__term__compare_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term__compare_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__compare_4_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term_0_0);
	call_localret(ENTRY(mercury____Compare___mercury_builtin__term_0_0),
		mercury__term__compare_4_0_i8,
		ENTRY(mercury__term__compare_4_0));
	}
Define_label(mercury__term__compare_4_0_i8);
	update_prof_current_proc(LABEL(mercury__term__compare_4_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term__compare_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module25)
	init_entry(mercury__term__context_line_2_0);
BEGIN_CODE

/* code for predicate 'term__context_line'/2 in mode 0 */
Define_entry(mercury__term__context_line_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module26)
	init_entry(mercury__term__context_file_2_0);
BEGIN_CODE

/* code for predicate 'term__context_file'/2 in mode 0 */
Define_entry(mercury__term__context_file_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module27)
	init_entry(mercury__term__context_init_3_0);
BEGIN_CODE

/* code for predicate 'term__context_init'/3 in mode 0 */
Define_entry(mercury__term__context_init_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module28)
	init_entry(mercury__term__term_list_to_var_list_2_0);
	init_label(mercury__term__term_list_to_var_list_2_0_i4);
	init_label(mercury__term__term_list_to_var_list_2_0_i1000);
BEGIN_CODE

/* code for predicate 'term__term_list_to_var_list'/2 in mode 0 */
Define_entry(mercury__term__term_list_to_var_list_2_0);
	incr_sp_push_msg(1, "term__term_list_to_var_list");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__term__var_list_to_term_list_2_1),
		mercury__term__term_list_to_var_list_2_0_i4,
		ENTRY(mercury__term__term_list_to_var_list_2_0));
	}
Define_label(mercury__term__term_list_to_var_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__term__term_list_to_var_list_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__term_list_to_var_list_2_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__term__term_list_to_var_list_2_0_i1000);
	r1 = string_const("term__term_list_to_var_list", 27);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__term__term_list_to_var_list_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module29)
	init_entry(mercury__term__var_list_to_term_list_2_1);
	init_label(mercury__term__var_list_to_term_list_2_1_i1001);
	init_label(mercury__term__var_list_to_term_list_2_1_i5);
	init_label(mercury__term__var_list_to_term_list_2_1_i1);
BEGIN_CODE

/* code for predicate 'term__var_list_to_term_list'/2 in mode 1 */
Define_entry(mercury__term__var_list_to_term_list_2_1);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__var_list_to_term_list_2_1_i1001);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = TRUE;
	proceed();
Define_label(mercury__term__var_list_to_term_list_2_1_i1001);
	incr_sp_push_msg(2, "term__var_list_to_term_list");
	detstackvar(2) = (Integer) succip;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__term__var_list_to_term_list_2_1_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__term__var_list_to_term_list_2_1,
		LABEL(mercury__term__var_list_to_term_list_2_1_i5),
		ENTRY(mercury__term__var_list_to_term_list_2_1));
Define_label(mercury__term__var_list_to_term_list_2_1_i5);
	update_prof_current_proc(LABEL(mercury__term__var_list_to_term_list_2_1));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__var_list_to_term_list_2_1_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__term__var_list_to_term_list_2_1_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module30)
	init_entry(mercury__term__var_list_to_term_list_2_0);
	init_label(mercury__term__var_list_to_term_list_2_0_i3);
	init_label(mercury__term__var_list_to_term_list_2_0_i4);
	init_label(mercury__term__var_list_to_term_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'term__var_list_to_term_list'/2 in mode 0 */
Define_entry(mercury__term__var_list_to_term_list_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__var_list_to_term_list_2_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__term__var_list_to_term_list_2_0_i3);
	while (1) {
	incr_sp_push_msg(1, "term__var_list_to_term_list");
	tag_incr_hp(detstackvar(1), mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__term__var_list_to_term_list_2_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__term__var_list_to_term_list_2_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module31)
	init_entry(mercury__term__vars_2_list_3_0);
	init_label(mercury__term__vars_2_list_3_0_i4);
	init_label(mercury__term__vars_2_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'term__vars_2_list'/3 in mode 0 */
Define_static(mercury__term__vars_2_list_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__vars_2_list_3_0_i1002);
	incr_sp_push_msg(2, "term__vars_2_list");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	localcall(mercury__term__vars_2_list_3_0,
		LABEL(mercury__term__vars_2_list_3_0_i4),
		STATIC(mercury__term__vars_2_list_3_0));
Define_label(mercury__term__vars_2_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term__vars_2_list_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__term__vars_2_3_0),
		STATIC(mercury__term__vars_2_list_3_0));
	}
Define_label(mercury__term__vars_2_list_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module32)
	init_entry(mercury__term__unify_list_4_0);
	init_label(mercury__term__unify_list_4_0_i1010);
	init_label(mercury__term__unify_list_4_0_i6);
	init_label(mercury__term__unify_list_4_0_i8);
	init_label(mercury__term__unify_list_4_0_i1007);
	init_label(mercury__term__unify_list_4_0_i1);
	init_label(mercury__term__unify_list_4_0_i1009);
BEGIN_CODE

/* code for predicate 'term__unify_list'/4 in mode 0 */
Define_static(mercury__term__unify_list_4_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__unify_list_4_0_i1010);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__unify_list_4_0_i1007);
	r2 = (Integer) r3;
	r1 = TRUE;
	proceed();
Define_label(mercury__term__unify_list_4_0_i1010);
	incr_sp_push_msg(3, "term__unify_list");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__unify_list_4_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__unify_4_0),
		mercury__term__unify_list_4_0_i6,
		STATIC(mercury__term__unify_list_4_0));
	}
Define_label(mercury__term__unify_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term__unify_list_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_list_4_0_i1);
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	localcall(mercury__term__unify_list_4_0,
		LABEL(mercury__term__unify_list_4_0_i8),
		STATIC(mercury__term__unify_list_4_0));
Define_label(mercury__term__unify_list_4_0_i8);
	update_prof_current_proc(LABEL(mercury__term__unify_list_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__unify_list_4_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury__term__unify_list_4_0_i1007);
	r1 = FALSE;
	proceed();
Define_label(mercury__term__unify_list_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__unify_list_4_0_i1009);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module33)
	init_entry(mercury__term__substitute_corresponding_2_4_0);
	init_label(mercury__term__substitute_corresponding_2_4_0_i1009);
	init_label(mercury__term__substitute_corresponding_2_4_0_i6);
	init_label(mercury__term__substitute_corresponding_2_4_0_i7);
	init_label(mercury__term__substitute_corresponding_2_4_0_i1006);
	init_label(mercury__term__substitute_corresponding_2_4_0_i1);
	init_label(mercury__term__substitute_corresponding_2_4_0_i1008);
BEGIN_CODE

/* code for predicate 'term__substitute_corresponding_2'/4 in mode 0 */
Define_static(mercury__term__substitute_corresponding_2_4_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__substitute_corresponding_2_4_0_i1009);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__substitute_corresponding_2_4_0_i1006);
	r2 = (Integer) r3;
	r1 = TRUE;
	proceed();
Define_label(mercury__term__substitute_corresponding_2_4_0_i1009);
	incr_sp_push_msg(3, "term__substitute_corresponding_2");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__substitute_corresponding_2_4_0_i1);
	r4 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r5 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__term__substitute_corresponding_2_4_0_i6,
		STATIC(mercury__term__substitute_corresponding_2_4_0));
	}
Define_label(mercury__term__substitute_corresponding_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term__substitute_corresponding_2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	localcall(mercury__term__substitute_corresponding_2_4_0,
		LABEL(mercury__term__substitute_corresponding_2_4_0_i7),
		STATIC(mercury__term__substitute_corresponding_2_4_0));
Define_label(mercury__term__substitute_corresponding_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__term__substitute_corresponding_2_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__substitute_corresponding_2_4_0_i1008);
	r1 = TRUE;
	proceed();
Define_label(mercury__term__substitute_corresponding_2_4_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury__term__substitute_corresponding_2_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term__substitute_corresponding_2_4_0_i1008);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module34)
	init_entry(mercury__term__is_ground_2_2_0);
	init_label(mercury__term__is_ground_2_2_0_i4);
	init_label(mercury__term__is_ground_2_2_0_i1003);
	init_label(mercury__term__is_ground_2_2_0_i1);
BEGIN_CODE

/* code for predicate 'term__is_ground_2'/2 in mode 0 */
Define_static(mercury__term__is_ground_2_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__is_ground_2_2_0_i1003);
	incr_sp_push_msg(3, "term__is_ground_2");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__is_ground_2_0),
		mercury__term__is_ground_2_2_0_i4,
		STATIC(mercury__term__is_ground_2_2_0));
	}
Define_label(mercury__term__is_ground_2_2_0_i4);
	update_prof_current_proc(LABEL(mercury__term__is_ground_2_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__is_ground_2_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__term__is_ground_2_2_0,
		STATIC(mercury__term__is_ground_2_2_0));
Define_label(mercury__term__is_ground_2_2_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__term__is_ground_2_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module35)
	init_entry(mercury__term__is_ground_2_1_0);
	init_label(mercury__term__is_ground_2_1_0_i4);
	init_label(mercury__term__is_ground_2_1_0_i1003);
	init_label(mercury__term__is_ground_2_1_0_i1);
BEGIN_CODE

/* code for predicate 'term__is_ground_2'/1 in mode 0 */
Define_static(mercury__term__is_ground_2_1_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term__is_ground_2_1_0_i1003);
	incr_sp_push_msg(2, "term__is_ground_2");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	{
		call_localret(STATIC(mercury__term__is_ground_1_0),
		mercury__term__is_ground_2_1_0_i4,
		STATIC(mercury__term__is_ground_2_1_0));
	}
Define_label(mercury__term__is_ground_2_1_0_i4);
	update_prof_current_proc(LABEL(mercury__term__is_ground_2_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term__is_ground_2_1_0_i1);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__term__is_ground_2_1_0,
		STATIC(mercury__term__is_ground_2_1_0));
Define_label(mercury__term__is_ground_2_1_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__term__is_ground_2_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_module36)
	init_entry(mercury____Unify___term__substitution_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term__substitution_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___term__substitution_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module37)
	init_entry(mercury____Index___term__substitution_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term__substitution_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___term__substitution_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_module38)
	init_entry(mercury____Compare___term__substitution_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term__substitution_0_0);
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_var_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___term__substitution_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__term_bunch_0(void)
{
	mercury__term_module0();
	mercury__term_module1();
	mercury__term_module2();
	mercury__term_module3();
	mercury__term_module4();
	mercury__term_module5();
	mercury__term_module6();
	mercury__term_module7();
	mercury__term_module8();
	mercury__term_module9();
	mercury__term_module10();
	mercury__term_module11();
	mercury__term_module12();
	mercury__term_module13();
	mercury__term_module14();
	mercury__term_module15();
	mercury__term_module16();
	mercury__term_module17();
	mercury__term_module18();
	mercury__term_module19();
	mercury__term_module20();
	mercury__term_module21();
	mercury__term_module22();
	mercury__term_module23();
	mercury__term_module24();
	mercury__term_module25();
	mercury__term_module26();
	mercury__term_module27();
	mercury__term_module28();
	mercury__term_module29();
	mercury__term_module30();
	mercury__term_module31();
	mercury__term_module32();
	mercury__term_module33();
	mercury__term_module34();
	mercury__term_module35();
	mercury__term_module36();
	mercury__term_module37();
	mercury__term_module38();
}

#endif

void mercury__term__init(void); /* suppress gcc warning */
void mercury__term__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__term_bunch_0();
#endif
}
