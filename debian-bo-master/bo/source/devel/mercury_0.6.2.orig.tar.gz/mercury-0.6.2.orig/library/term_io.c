/*
** Automatically generated from `term_io.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__term_io__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__term_io__read_term_3_0);
Define_extern_entry(mercury__term_io__write_term_4_0);
Declare_label(mercury__term_io__write_term_4_0_i2);
Define_extern_entry(mercury__term_io__write_term_nl_4_0);
Declare_label(mercury__term_io__write_term_nl_4_0_i2);
Define_extern_entry(mercury__term_io__write_constant_3_0);
Declare_label(mercury__term_io__write_constant_3_0_i1002);
Declare_label(mercury__term_io__write_constant_3_0_i6);
Declare_label(mercury__term_io__write_constant_3_0_i9);
Declare_label(mercury__term_io__write_constant_3_0_i10);
Declare_label(mercury__term_io__write_constant_3_0_i8);
Define_extern_entry(mercury__term_io__write_variable_4_0);
Declare_label(mercury__term_io__write_variable_4_0_i2);
Define_extern_entry(mercury__term_io__quote_string_3_0);
Declare_label(mercury__term_io__quote_string_3_0_i4);
Declare_label(mercury__term_io__quote_string_3_0_i6);
Declare_label(mercury__term_io__quote_string_3_0_i3);
Define_extern_entry(mercury__term_io__quote_atom_3_0);
Declare_label(mercury__term_io__quote_atom_3_0_i4);
Declare_label(mercury__term_io__quote_atom_3_0_i6);
Declare_label(mercury__term_io__quote_atom_3_0_i8);
Declare_label(mercury__term_io__quote_atom_3_0_i3);
Declare_label(mercury__term_io__quote_atom_3_0_i11);
Declare_label(mercury__term_io__quote_atom_3_0_i12);
Define_extern_entry(mercury__term_io__quote_char_3_0);
Declare_label(mercury__term_io__quote_char_3_0_i2);
Declare_label(mercury__term_io__quote_char_3_0_i3);
Define_extern_entry(mercury__term_io__quote_single_char_3_0);
Declare_label(mercury__term_io__quote_single_char_3_0_i1000);
Declare_label(mercury__term_io__quote_single_char_3_0_i6);
Declare_label(mercury__term_io__quote_single_char_3_0_i7);
Declare_label(mercury__term_io__quote_single_char_3_0_i8);
Declare_label(mercury__term_io__quote_single_char_3_0_i9);
Declare_label(mercury__term_io__quote_single_char_3_0_i4);
Declare_label(mercury__term_io__quote_single_char_3_0_i11);
Declare_label(mercury__term_io__quote_single_char_3_0_i2);
Declare_label(mercury__term_io__quote_single_char_3_0_i17);
Declare_label(mercury__term_io__quote_single_char_3_0_i16);
Declare_label(mercury__term_io__quote_single_char_3_0_i13);
Declare_label(mercury__term_io__quote_single_char_3_0_i22);
Declare_label(mercury__term_io__quote_single_char_3_0_i23);
Declare_label(mercury__term_io__quote_single_char_3_0_i24);
Declare_label(mercury__term_io__quote_single_char_3_0_i25);
Declare_static(mercury__term_io__write_variable_2_7_0);
Declare_label(mercury__term_io__write_variable_2_7_0_i4);
Declare_label(mercury__term_io__write_variable_2_7_0_i3);
Declare_label(mercury__term_io__write_variable_2_7_0_i9);
Declare_label(mercury__term_io__write_variable_2_7_0_i11);
Declare_label(mercury__term_io__write_variable_2_7_0_i8);
Declare_label(mercury__term_io__write_variable_2_7_0_i12);
Declare_label(mercury__term_io__write_variable_2_7_0_i13);
Declare_label(mercury__term_io__write_variable_2_7_0_i14);
Declare_label(mercury__term_io__write_variable_2_7_0_i15);
Declare_static(mercury__term_io__write_term_2_7_0);
Declare_label(mercury__term_io__write_term_2_7_0_i1000);
Declare_label(mercury__term_io__write_term_2_7_0_i5);
Declare_label(mercury__term_io__write_term_2_7_0_i13);
Declare_label(mercury__term_io__write_term_2_7_0_i14);
Declare_label(mercury__term_io__write_term_2_7_0_i15);
Declare_label(mercury__term_io__write_term_2_7_0_i16);
Declare_label(mercury__term_io__write_term_2_7_0_i6);
Declare_label(mercury__term_io__write_term_2_7_0_i22);
Declare_label(mercury__term_io__write_term_2_7_0_i17);
Declare_label(mercury__term_io__write_term_2_7_0_i29);
Declare_label(mercury__term_io__write_term_2_7_0_i30);
Declare_label(mercury__term_io__write_term_2_7_0_i23);
Declare_label(mercury__term_io__write_term_2_7_0_i37);
Declare_label(mercury__term_io__write_term_2_7_0_i39);
Declare_label(mercury__term_io__write_term_2_7_0_i40);
Declare_label(mercury__term_io__write_term_2_7_0_i41);
Declare_label(mercury__term_io__write_term_2_7_0_i42);
Declare_label(mercury__term_io__write_term_2_7_0_i33);
Declare_label(mercury__term_io__write_term_2_7_0_i32);
Declare_label(mercury__term_io__write_term_2_7_0_i49);
Declare_label(mercury__term_io__write_term_2_7_0_i51);
Declare_label(mercury__term_io__write_term_2_7_0_i52);
Declare_label(mercury__term_io__write_term_2_7_0_i53);
Declare_label(mercury__term_io__write_term_2_7_0_i54);
Declare_label(mercury__term_io__write_term_2_7_0_i45);
Declare_label(mercury__term_io__write_term_2_7_0_i44);
Declare_label(mercury__term_io__write_term_2_7_0_i62);
Declare_label(mercury__term_io__write_term_2_7_0_i64);
Declare_label(mercury__term_io__write_term_2_7_0_i65);
Declare_label(mercury__term_io__write_term_2_7_0_i66);
Declare_label(mercury__term_io__write_term_2_7_0_i67);
Declare_label(mercury__term_io__write_term_2_7_0_i68);
Declare_label(mercury__term_io__write_term_2_7_0_i69);
Declare_label(mercury__term_io__write_term_2_7_0_i57);
Declare_label(mercury__term_io__write_term_2_7_0_i56);
Declare_label(mercury__term_io__write_term_2_7_0_i77);
Declare_label(mercury__term_io__write_term_2_7_0_i79);
Declare_label(mercury__term_io__write_term_2_7_0_i80);
Declare_label(mercury__term_io__write_term_2_7_0_i81);
Declare_label(mercury__term_io__write_term_2_7_0_i82);
Declare_label(mercury__term_io__write_term_2_7_0_i83);
Declare_label(mercury__term_io__write_term_2_7_0_i84);
Declare_label(mercury__term_io__write_term_2_7_0_i72);
Declare_label(mercury__term_io__write_term_2_7_0_i71);
Declare_label(mercury__term_io__write_term_2_7_0_i86);
Declare_label(mercury__term_io__write_term_2_7_0_i90);
Declare_label(mercury__term_io__write_term_2_7_0_i91);
Declare_label(mercury__term_io__write_term_2_7_0_i92);
Declare_static(mercury__term_io__write_list_tail_7_0);
Declare_label(mercury__term_io__write_list_tail_7_0_i5);
Declare_label(mercury__term_io__write_list_tail_7_0_i3);
Declare_label(mercury__term_io__write_list_tail_7_0_i2);
Declare_label(mercury__term_io__write_list_tail_7_0_i16);
Declare_label(mercury__term_io__write_list_tail_7_0_i17);
Declare_label(mercury__term_io__write_list_tail_7_0_i8);
Declare_label(mercury__term_io__write_list_tail_7_0_i19);
Declare_label(mercury__term_io__write_list_tail_7_0_i25);
Declare_static(mercury__term_io__write_term_args_7_0);
Declare_label(mercury__term_io__write_term_args_7_0_i4);
Declare_label(mercury__term_io__write_term_args_7_0_i5);
Declare_label(mercury__term_io__write_term_args_7_0_i1002);
Define_extern_entry(mercury____Unify___term_io__read_term_0_0);
Declare_label(mercury____Unify___term_io__read_term_0_0_i1013);
Declare_label(mercury____Unify___term_io__read_term_0_0_i6);
Declare_label(mercury____Unify___term_io__read_term_0_0_i9);
Declare_label(mercury____Unify___term_io__read_term_0_0_i1010);
Declare_label(mercury____Unify___term_io__read_term_0_0_i1);
Declare_label(mercury____Unify___term_io__read_term_0_0_i1012);
Define_extern_entry(mercury____Index___term_io__read_term_0_0);
Declare_label(mercury____Index___term_io__read_term_0_0_i4);
Declare_label(mercury____Index___term_io__read_term_0_0_i5);
Define_extern_entry(mercury____Compare___term_io__read_term_0_0);
Declare_label(mercury____Compare___term_io__read_term_0_0_i2);
Declare_label(mercury____Compare___term_io__read_term_0_0_i3);
Declare_label(mercury____Compare___term_io__read_term_0_0_i4);
Declare_label(mercury____Compare___term_io__read_term_0_0_i6);
Declare_label(mercury____Compare___term_io__read_term_0_0_i12);
Declare_label(mercury____Compare___term_io__read_term_0_0_i18);
Declare_label(mercury____Compare___term_io__read_term_0_0_i19);
Declare_label(mercury____Compare___term_io__read_term_0_0_i17);
Declare_label(mercury____Compare___term_io__read_term_0_0_i14);
Declare_label(mercury____Compare___term_io__read_term_0_0_i27);
Declare_label(mercury____Compare___term_io__read_term_0_0_i9);

extern Word * mercury_data_term_io__base_type_layout_read_term_0[];
Word * mercury_data_term_io__base_type_info_read_term_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___term_io__read_term_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___term_io__read_term_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___term_io__read_term_0_0),
	(Word *) (Integer) mercury_data_term_io__base_type_layout_read_term_0
};

extern Word * mercury_data_term_io__common_0[];
extern Word * mercury_data_term_io__common_3[];
extern Word * mercury_data_term_io__common_6[];
Word * mercury_data_term_io__base_type_layout_read_term_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_term_io__common_0),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_term_io__common_3),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_term_io__common_6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_term_io__common_0[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("eof", 3)
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_term_io__common_1[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_term_io__common_2[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_term_io__common_3[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_term_io__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_term_io__common_2),
	(Word *) string_const("error", 5)
};

extern Word * mercury_data_varset__base_type_info_varset_0[];
Word * mercury_data_term_io__common_4[] = {
	(Word *) (Integer) mercury_data_varset__base_type_info_varset_0
};

extern Word * mercury_data_mercury_builtin__base_type_info_term_0[];
Word * mercury_data_term_io__common_5[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_term_io__common_6[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_term_io__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_term_io__common_5),
	(Word *) string_const("term", 4)
};

BEGIN_MODULE(mercury__term_io_module0)
	init_entry(mercury__term_io__read_term_3_0);
BEGIN_CODE

/* code for predicate 'term_io__read_term'/3 in mode 0 */
Define_entry(mercury__term_io__read_term_3_0);
	{
	Declare_entry(mercury__parser__read_term_3_0);
	tailcall(ENTRY(mercury__parser__read_term_3_0),
		ENTRY(mercury__term_io__read_term_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module1)
	init_entry(mercury__term_io__write_term_4_0);
	init_label(mercury__term_io__write_term_4_0_i2);
BEGIN_CODE

/* code for predicate 'term_io__write_term'/4 in mode 0 */
Define_entry(mercury__term_io__write_term_4_0);
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	r4 = (Integer) r3;
	r3 = ((Integer) 0);
	incr_sp_push_msg(1, "term_io__write_term");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__term_io__write_term_2_7_0),
		mercury__term_io__write_term_4_0_i2,
		ENTRY(mercury__term_io__write_term_4_0));
	}
Define_label(mercury__term_io__write_term_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_4_0));
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module2)
	init_entry(mercury__term_io__write_term_nl_4_0);
	init_label(mercury__term_io__write_term_nl_4_0_i2);
BEGIN_CODE

/* code for predicate 'term_io__write_term_nl'/4 in mode 0 */
Define_entry(mercury__term_io__write_term_nl_4_0);
	incr_sp_push_msg(1, "term_io__write_term_nl");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__term_io__write_term_4_0),
		mercury__term_io__write_term_nl_4_0_i2,
		ENTRY(mercury__term_io__write_term_nl_4_0));
	}
Define_label(mercury__term_io__write_term_nl_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_nl_4_0));
	r2 = (Integer) r1;
	r1 = string_const(".\n", 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__term_io__write_term_nl_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module3)
	init_entry(mercury__term_io__write_constant_3_0);
	init_label(mercury__term_io__write_constant_3_0_i1002);
	init_label(mercury__term_io__write_constant_3_0_i6);
	init_label(mercury__term_io__write_constant_3_0_i9);
	init_label(mercury__term_io__write_constant_3_0_i10);
	init_label(mercury__term_io__write_constant_3_0_i8);
BEGIN_CODE

/* code for predicate 'term_io__write_constant'/3 in mode 0 */
Define_entry(mercury__term_io__write_constant_3_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_constant_3_0_i1002);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	{
		tailcall(STATIC(mercury__term_io__quote_atom_3_0),
		ENTRY(mercury__term_io__write_constant_3_0));
	}
Define_label(mercury__term_io__write_constant_3_0_i1002);
	incr_sp_push_msg(2, "term_io__write_constant");
	detstackvar(2) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__term_io__write_constant_3_0_i6);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_int_3_0);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		ENTRY(mercury__term_io__write_constant_3_0));
	}
Define_label(mercury__term_io__write_constant_3_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__term_io__write_constant_3_0_i8);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r1 = ((Integer) 34);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_constant_3_0_i9,
		ENTRY(mercury__term_io__write_constant_3_0));
	}
Define_label(mercury__term_io__write_constant_3_0_i9);
	update_prof_current_proc(LABEL(mercury__term_io__write_constant_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__term_io__quote_string_3_0),
		mercury__term_io__write_constant_3_0_i10,
		ENTRY(mercury__term_io__write_constant_3_0));
	}
Define_label(mercury__term_io__write_constant_3_0_i10);
	update_prof_current_proc(LABEL(mercury__term_io__write_constant_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 34);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_char_3_0);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__term_io__write_constant_3_0));
	}
Define_label(mercury__term_io__write_constant_3_0_i8);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_float_3_0);
	tailcall(ENTRY(mercury__io__write_float_3_0),
		ENTRY(mercury__term_io__write_constant_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module4)
	init_entry(mercury__term_io__write_variable_4_0);
	init_label(mercury__term_io__write_variable_4_0_i2);
BEGIN_CODE

/* code for predicate 'term_io__write_variable'/4 in mode 0 */
Define_entry(mercury__term_io__write_variable_4_0);
	r4 = (Integer) r3;
	r3 = ((Integer) 0);
	incr_sp_push_msg(1, "term_io__write_variable");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__term_io__write_variable_2_7_0),
		mercury__term_io__write_variable_4_0_i2,
		ENTRY(mercury__term_io__write_variable_4_0));
Define_label(mercury__term_io__write_variable_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_4_0));
	r1 = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module5)
	init_entry(mercury__term_io__quote_string_3_0);
	init_label(mercury__term_io__quote_string_3_0_i4);
	init_label(mercury__term_io__quote_string_3_0_i6);
	init_label(mercury__term_io__quote_string_3_0_i3);
BEGIN_CODE

/* code for predicate 'term_io__quote_string'/3 in mode 0 */
Define_entry(mercury__term_io__quote_string_3_0);
	incr_sp_push_msg(3, "term_io__quote_string");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__string__first_char_3_3);
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__term_io__quote_string_3_0_i4,
		ENTRY(mercury__term_io__quote_string_3_0));
	}
Define_label(mercury__term_io__quote_string_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term_io__quote_string_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__quote_string_3_0_i3);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__term_io__quote_single_char_3_0),
		mercury__term_io__quote_string_3_0_i6,
		ENTRY(mercury__term_io__quote_string_3_0));
	}
Define_label(mercury__term_io__quote_string_3_0_i6);
	update_prof_current_proc(LABEL(mercury__term_io__quote_string_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__term_io__quote_string_3_0,
		ENTRY(mercury__term_io__quote_string_3_0));
Define_label(mercury__term_io__quote_string_3_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module6)
	init_entry(mercury__term_io__quote_atom_3_0);
	init_label(mercury__term_io__quote_atom_3_0_i4);
	init_label(mercury__term_io__quote_atom_3_0_i6);
	init_label(mercury__term_io__quote_atom_3_0_i8);
	init_label(mercury__term_io__quote_atom_3_0_i3);
	init_label(mercury__term_io__quote_atom_3_0_i11);
	init_label(mercury__term_io__quote_atom_3_0_i12);
BEGIN_CODE

/* code for predicate 'term_io__quote_atom'/3 in mode 0 */
Define_entry(mercury__term_io__quote_atom_3_0);
	incr_sp_push_msg(4, "term_io__quote_atom");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__string__first_char_3_3);
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__term_io__quote_atom_3_0_i4,
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
Define_label(mercury__term_io__quote_atom_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term_io__quote_atom_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__quote_atom_3_0_i3);
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__char__is_lower_1_0);
	call_localret(ENTRY(mercury__char__is_lower_1_0),
		mercury__term_io__quote_atom_3_0_i6,
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
Define_label(mercury__term_io__quote_atom_3_0_i6);
	update_prof_current_proc(LABEL(mercury__term_io__quote_atom_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__quote_atom_3_0_i3);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__is_alnum_or_underscore_1_0);
	call_localret(ENTRY(mercury__string__is_alnum_or_underscore_1_0),
		mercury__term_io__quote_atom_3_0_i8,
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
Define_label(mercury__term_io__quote_atom_3_0_i8);
	update_prof_current_proc(LABEL(mercury__term_io__quote_atom_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__quote_atom_3_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
Define_label(mercury__term_io__quote_atom_3_0_i3);
	r1 = ((Integer) 39);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__quote_atom_3_0_i11,
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
Define_label(mercury__term_io__quote_atom_3_0_i11);
	update_prof_current_proc(LABEL(mercury__term_io__quote_atom_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__term_io__quote_string_3_0),
		mercury__term_io__quote_atom_3_0_i12,
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
Define_label(mercury__term_io__quote_atom_3_0_i12);
	update_prof_current_proc(LABEL(mercury__term_io__quote_atom_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 39);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__io__write_char_3_0);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__term_io__quote_atom_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module7)
	init_entry(mercury__term_io__quote_char_3_0);
	init_label(mercury__term_io__quote_char_3_0_i2);
	init_label(mercury__term_io__quote_char_3_0_i3);
BEGIN_CODE

/* code for predicate 'term_io__quote_char'/3 in mode 0 */
Define_entry(mercury__term_io__quote_char_3_0);
	incr_sp_push_msg(2, "term_io__quote_char");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = ((Integer) 39);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__quote_char_3_0_i2,
		ENTRY(mercury__term_io__quote_char_3_0));
	}
Define_label(mercury__term_io__quote_char_3_0_i2);
	update_prof_current_proc(LABEL(mercury__term_io__quote_char_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	{
		call_localret(STATIC(mercury__term_io__quote_single_char_3_0),
		mercury__term_io__quote_char_3_0_i3,
		ENTRY(mercury__term_io__quote_char_3_0));
	}
Define_label(mercury__term_io__quote_char_3_0_i3);
	update_prof_current_proc(LABEL(mercury__term_io__quote_char_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 39);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__io__write_char_3_0);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__term_io__quote_char_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module8)
	init_entry(mercury__term_io__quote_single_char_3_0);
	init_label(mercury__term_io__quote_single_char_3_0_i1000);
	init_label(mercury__term_io__quote_single_char_3_0_i6);
	init_label(mercury__term_io__quote_single_char_3_0_i7);
	init_label(mercury__term_io__quote_single_char_3_0_i8);
	init_label(mercury__term_io__quote_single_char_3_0_i9);
	init_label(mercury__term_io__quote_single_char_3_0_i4);
	init_label(mercury__term_io__quote_single_char_3_0_i11);
	init_label(mercury__term_io__quote_single_char_3_0_i2);
	init_label(mercury__term_io__quote_single_char_3_0_i17);
	init_label(mercury__term_io__quote_single_char_3_0_i16);
	init_label(mercury__term_io__quote_single_char_3_0_i13);
	init_label(mercury__term_io__quote_single_char_3_0_i22);
	init_label(mercury__term_io__quote_single_char_3_0_i23);
	init_label(mercury__term_io__quote_single_char_3_0_i24);
	init_label(mercury__term_io__quote_single_char_3_0_i25);
BEGIN_CODE

/* code for predicate 'term_io__quote_single_char'/3 in mode 0 */
Define_entry(mercury__term_io__quote_single_char_3_0);
	if (((Integer) r1 != ((Integer) 8)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i1000);
	r3 = ((Integer) 98);
	incr_sp_push_msg(3, "term_io__quote_single_char");
	detstackvar(3) = (Integer) succip;
	GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i4);
Define_label(mercury__term_io__quote_single_char_3_0_i1000);
	incr_sp_push_msg(3, "term_io__quote_single_char");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r1 != ((Integer) 9)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i6);
	r3 = ((Integer) 116);
	GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i4);
Define_label(mercury__term_io__quote_single_char_3_0_i6);
	if (((Integer) r1 != ((Integer) 10)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i7);
	r3 = ((Integer) 110);
	GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i4);
Define_label(mercury__term_io__quote_single_char_3_0_i7);
	if (((Integer) r1 != ((Integer) 34)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i8);
	r3 = ((Integer) 34);
	GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i4);
Define_label(mercury__term_io__quote_single_char_3_0_i8);
	if (((Integer) r1 != ((Integer) 39)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i9);
	r3 = ((Integer) 39);
	GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i4);
Define_label(mercury__term_io__quote_single_char_3_0_i9);
	if (((Integer) r1 != ((Integer) 92)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i2);
	r3 = ((Integer) 92);
Define_label(mercury__term_io__quote_single_char_3_0_i4);
	detstackvar(1) = (Integer) r3;
	r1 = ((Integer) 92);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__quote_single_char_3_0_i11,
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i11);
	update_prof_current_proc(LABEL(mercury__term_io__quote_single_char_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_char_3_0);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__char__is_alnum_1_0);
	call_localret(ENTRY(mercury__char__is_alnum_1_0),
		mercury__term_io__quote_single_char_3_0_i17,
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i17);
	update_prof_current_proc(LABEL(mercury__term_io__quote_single_char_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_char_3_0);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	if (((Unsigned)(((Integer) r1 - ((Integer) 32))) > ((Integer) 94)))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i13);
	{
	static const Word mercury_const_1[] = {
		((Integer) 4227923967),
		((Integer) 4160749569),
		((Integer) 2013265921)
	};
	if (!(((((Integer) 1) << ((Unsigned)(((Integer) r1 - ((Integer) 32))) % ((Integer) 32))) & (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Unsigned)(((Integer) r1 - ((Integer) 32))) / ((Integer) 32))))))
		GOTO_LABEL(mercury__term_io__quote_single_char_3_0_i13);
	}
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_char_3_0);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i13);
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__char__to_int_2_0);
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__term_io__quote_single_char_3_0_i22,
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i22);
	update_prof_current_proc(LABEL(mercury__term_io__quote_single_char_3_0));
	r2 = ((Integer) 8);
	{
	Declare_entry(mercury__string__int_to_base_string_3_0);
	call_localret(ENTRY(mercury__string__int_to_base_string_3_0),
		mercury__term_io__quote_single_char_3_0_i23,
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i23);
	update_prof_current_proc(LABEL(mercury__term_io__quote_single_char_3_0));
	r2 = ((Integer) 48);
	r3 = ((Integer) 3);
	{
	Declare_entry(mercury__string__pad_left_4_0);
	call_localret(ENTRY(mercury__string__pad_left_4_0),
		mercury__term_io__quote_single_char_3_0_i24,
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i24);
	update_prof_current_proc(LABEL(mercury__term_io__quote_single_char_3_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 92);
	{
	Declare_entry(mercury__string__first_char_3_4);
	call_localret(ENTRY(mercury__string__first_char_3_4),
		mercury__term_io__quote_single_char_3_0_i25,
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
Define_label(mercury__term_io__quote_single_char_3_0_i25);
	update_prof_current_proc(LABEL(mercury__term_io__quote_single_char_3_0));
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__io__write_string_3_0);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__term_io__quote_single_char_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module9)
	init_entry(mercury__term_io__write_variable_2_7_0);
	init_label(mercury__term_io__write_variable_2_7_0_i4);
	init_label(mercury__term_io__write_variable_2_7_0_i3);
	init_label(mercury__term_io__write_variable_2_7_0_i9);
	init_label(mercury__term_io__write_variable_2_7_0_i11);
	init_label(mercury__term_io__write_variable_2_7_0_i8);
	init_label(mercury__term_io__write_variable_2_7_0_i12);
	init_label(mercury__term_io__write_variable_2_7_0_i13);
	init_label(mercury__term_io__write_variable_2_7_0_i14);
	init_label(mercury__term_io__write_variable_2_7_0_i15);
BEGIN_CODE

/* code for predicate 'term_io__write_variable_2'/7 in mode 0 */
Define_static(mercury__term_io__write_variable_2_7_0);
	incr_sp_push_msg(7, "term_io__write_variable_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__varset__search_var_3_0);
	call_localret(ENTRY(mercury__varset__search_var_3_0),
		mercury__term_io__write_variable_2_7_0_i4,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_variable_2_7_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__term_io__write_term_2_7_0),
		STATIC(mercury__term_io__write_variable_2_7_0));
Define_label(mercury__term_io__write_variable_2_7_0_i3);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__varset__search_name_3_0);
	call_localret(ENTRY(mercury__varset__search_name_3_0),
		mercury__term_io__write_variable_2_7_0_i9,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_variable_2_7_0_i8);
	detstackvar(4) = (Integer) detstackvar(2);
	detstackvar(5) = (Integer) detstackvar(3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_variable_2_7_0_i11,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_io__write_variable_2_7_0_i8);
	r1 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__int_to_string_2_0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__term_io__write_variable_2_7_0_i12,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	r2 = (Integer) r1;
	r1 = string_const("_", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__term_io__write_variable_2_7_0_i13,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__varset__name_var_4_0);
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__term_io__write_variable_2_7_0_i14,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = ((Integer) detstackvar(3) + ((Integer) 1));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_variable_2_7_0_i15,
		STATIC(mercury__term_io__write_variable_2_7_0));
	}
Define_label(mercury__term_io__write_variable_2_7_0_i15);
	update_prof_current_proc(LABEL(mercury__term_io__write_variable_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module10)
	init_entry(mercury__term_io__write_term_2_7_0);
	init_label(mercury__term_io__write_term_2_7_0_i1000);
	init_label(mercury__term_io__write_term_2_7_0_i5);
	init_label(mercury__term_io__write_term_2_7_0_i13);
	init_label(mercury__term_io__write_term_2_7_0_i14);
	init_label(mercury__term_io__write_term_2_7_0_i15);
	init_label(mercury__term_io__write_term_2_7_0_i16);
	init_label(mercury__term_io__write_term_2_7_0_i6);
	init_label(mercury__term_io__write_term_2_7_0_i22);
	init_label(mercury__term_io__write_term_2_7_0_i17);
	init_label(mercury__term_io__write_term_2_7_0_i29);
	init_label(mercury__term_io__write_term_2_7_0_i30);
	init_label(mercury__term_io__write_term_2_7_0_i23);
	init_label(mercury__term_io__write_term_2_7_0_i37);
	init_label(mercury__term_io__write_term_2_7_0_i39);
	init_label(mercury__term_io__write_term_2_7_0_i40);
	init_label(mercury__term_io__write_term_2_7_0_i41);
	init_label(mercury__term_io__write_term_2_7_0_i42);
	init_label(mercury__term_io__write_term_2_7_0_i33);
	init_label(mercury__term_io__write_term_2_7_0_i32);
	init_label(mercury__term_io__write_term_2_7_0_i49);
	init_label(mercury__term_io__write_term_2_7_0_i51);
	init_label(mercury__term_io__write_term_2_7_0_i52);
	init_label(mercury__term_io__write_term_2_7_0_i53);
	init_label(mercury__term_io__write_term_2_7_0_i54);
	init_label(mercury__term_io__write_term_2_7_0_i45);
	init_label(mercury__term_io__write_term_2_7_0_i44);
	init_label(mercury__term_io__write_term_2_7_0_i62);
	init_label(mercury__term_io__write_term_2_7_0_i64);
	init_label(mercury__term_io__write_term_2_7_0_i65);
	init_label(mercury__term_io__write_term_2_7_0_i66);
	init_label(mercury__term_io__write_term_2_7_0_i67);
	init_label(mercury__term_io__write_term_2_7_0_i68);
	init_label(mercury__term_io__write_term_2_7_0_i69);
	init_label(mercury__term_io__write_term_2_7_0_i57);
	init_label(mercury__term_io__write_term_2_7_0_i56);
	init_label(mercury__term_io__write_term_2_7_0_i77);
	init_label(mercury__term_io__write_term_2_7_0_i79);
	init_label(mercury__term_io__write_term_2_7_0_i80);
	init_label(mercury__term_io__write_term_2_7_0_i81);
	init_label(mercury__term_io__write_term_2_7_0_i82);
	init_label(mercury__term_io__write_term_2_7_0_i83);
	init_label(mercury__term_io__write_term_2_7_0_i84);
	init_label(mercury__term_io__write_term_2_7_0_i72);
	init_label(mercury__term_io__write_term_2_7_0_i71);
	init_label(mercury__term_io__write_term_2_7_0_i86);
	init_label(mercury__term_io__write_term_2_7_0_i90);
	init_label(mercury__term_io__write_term_2_7_0_i91);
	init_label(mercury__term_io__write_term_2_7_0_i92);
BEGIN_CODE

/* code for predicate 'term_io__write_term_2'/7 in mode 0 */
Define_static(mercury__term_io__write_term_2_7_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	tailcall(STATIC(mercury__term_io__write_variable_2_7_0),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i1000);
	incr_sp_push_msg(10, "term_io__write_term_2");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) r4;
	{
	Declare_entry(mercury__io__get_op_table_3_0);
	call_localret(ENTRY(mercury__io__get_op_table_3_0),
		mercury__term_io__write_term_2_7_0_i5,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i6);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	if ((strcmp((char *)(Integer) r3, (char *)string_const(".", 1)) !=0))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i6);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i6);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i6);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i6);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = ((Integer) 91);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i13,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i14),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__term_io__write_list_tail_7_0),
		mercury__term_io__write_term_2_7_0_i15,
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i15);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 93);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__term_io__write_term_2_7_0_i6);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i17);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	if ((strcmp((char *)(Integer) r3, (char *)string_const("[]", 2)) !=0))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i17);
	if (((Integer) detstackvar(6) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i17);
	r1 = string_const("[]", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_term_2_7_0_i22,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i22);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__term_io__write_term_2_7_0_i17);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i23);
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	if ((strcmp((char *)(Integer) r3, (char *)string_const("{}", 2)) !=0))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i23);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i23);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i23);
	detstackvar(3) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	r1 = string_const("{ ", 2);
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_term_2_7_0_i29,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i29);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i30),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i30);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = string_const(" }", 2);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i23);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i32);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i32);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i32);
	detstackvar(7) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	{
	Declare_entry(mercury__ops__lookup_prefix_op_4_0);
	call_localret(ENTRY(mercury__ops__lookup_prefix_op_4_0),
		mercury__term_io__write_term_2_7_0_i37,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i37);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i33);
	r1 = ((Integer) 40);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i39,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i39);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__term_io__write_constant_3_0),
		mercury__term_io__write_term_2_7_0_i40,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i40);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 32);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i41,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i41);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i42),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i42);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 41);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i33);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__term_io__write_term_2_7_0_i32);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i44);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 1));
	if (((Integer) r3 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i44);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i44);
	detstackvar(7) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	{
	Declare_entry(mercury__ops__lookup_postfix_op_4_0);
	call_localret(ENTRY(mercury__ops__lookup_postfix_op_4_0),
		mercury__term_io__write_term_2_7_0_i49,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i49);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i45);
	r1 = ((Integer) 40);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i51,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i51);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i52),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i52);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 32);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i53,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i53);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__term_io__write_constant_3_0),
		mercury__term_io__write_term_2_7_0_i54,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i54);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 41);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i45);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__term_io__write_term_2_7_0_i44);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i56);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i56);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i56);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i56);
	detstackvar(7) = (Integer) r1;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(8) = (Integer) r2;
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	{
	Declare_entry(mercury__ops__lookup_infix_op_5_0);
	call_localret(ENTRY(mercury__ops__lookup_infix_op_5_0),
		mercury__term_io__write_term_2_7_0_i62,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i62);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i57);
	r1 = ((Integer) 40);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i64,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i64);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i65),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i65);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(9) = (Integer) r2;
	r1 = ((Integer) 32);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i66,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i66);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__term_io__write_constant_3_0),
		mercury__term_io__write_term_2_7_0_i67,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i67);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 32);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i68,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i68);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(9);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i69),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i69);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 41);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i57);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__term_io__write_term_2_7_0_i56);
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i71);
	r3 = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 1));
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i71);
	if (((Integer) field(mktag(1), (Integer) r3, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i71);
	if ((tag((Integer) detstackvar(5)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i71);
	detstackvar(8) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) detstackvar(6), ((Integer) 0));
	detstackvar(7) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) detstackvar(5), ((Integer) 0));
	{
	Declare_entry(mercury__ops__lookup_binary_prefix_op_5_0);
	call_localret(ENTRY(mercury__ops__lookup_binary_prefix_op_5_0),
		mercury__term_io__write_term_2_7_0_i77,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i77);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i72);
	r1 = ((Integer) 40);
	r2 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i79,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i79);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__term_io__write_constant_3_0),
		mercury__term_io__write_term_2_7_0_i80,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i80);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r2 = (Integer) r1;
	r1 = ((Integer) 32);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i81,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i81);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i82),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i82);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 32);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i83,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i83);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i84),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i84);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 41);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i72);
	r2 = (Integer) detstackvar(8);
Define_label(mercury__term_io__write_term_2_7_0_i71);
	r1 = (Integer) detstackvar(5);
	{
		call_localret(STATIC(mercury__term_io__write_constant_3_0),
		mercury__term_io__write_term_2_7_0_i86,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i86);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	if (((Integer) detstackvar(6) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_2_7_0_i22);
	r2 = (Integer) r1;
	r3 = (Integer) detstackvar(6);
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = ((Integer) 40);
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i90,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
Define_label(mercury__term_io__write_term_2_7_0_i90);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	localcall(mercury__term_io__write_term_2_7_0,
		LABEL(mercury__term_io__write_term_2_7_0_i91),
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i91);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__term_io__write_term_args_7_0),
		mercury__term_io__write_term_2_7_0_i92,
		STATIC(mercury__term_io__write_term_2_7_0));
Define_label(mercury__term_io__write_term_2_7_0_i92);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_2_7_0));
	detstackvar(3) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = ((Integer) 41);
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__io__write_char_3_0);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__term_io__write_term_2_7_0_i16,
		STATIC(mercury__term_io__write_term_2_7_0));
	}
END_MODULE

BEGIN_MODULE(mercury__term_io_module11)
	init_entry(mercury__term_io__write_list_tail_7_0);
	init_label(mercury__term_io__write_list_tail_7_0_i5);
	init_label(mercury__term_io__write_list_tail_7_0_i3);
	init_label(mercury__term_io__write_list_tail_7_0_i2);
	init_label(mercury__term_io__write_list_tail_7_0_i16);
	init_label(mercury__term_io__write_list_tail_7_0_i17);
	init_label(mercury__term_io__write_list_tail_7_0_i8);
	init_label(mercury__term_io__write_list_tail_7_0_i19);
	init_label(mercury__term_io__write_list_tail_7_0_i25);
BEGIN_CODE

/* code for predicate 'term_io__write_list_tail'/7 in mode 0 */
Define_static(mercury__term_io__write_list_tail_7_0);
	incr_sp_push_msg(5, "term_io__write_list_tail");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i2);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	r1 = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	{
	Declare_entry(mercury__varset__search_var_3_0);
	call_localret(ENTRY(mercury__varset__search_var_3_0),
		mercury__term_io__write_list_tail_7_0_i5,
		STATIC(mercury__term_io__write_list_tail_7_0));
	}
Define_label(mercury__term_io__write_list_tail_7_0_i5);
	update_prof_current_proc(LABEL(mercury__term_io__write_list_tail_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i3);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__term_io__write_list_tail_7_0,
		STATIC(mercury__term_io__write_list_tail_7_0));
Define_label(mercury__term_io__write_list_tail_7_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
Define_label(mercury__term_io__write_list_tail_7_0_i2);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i8);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i8);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r5, ((Integer) 0)), (char *)string_const(".", 1)) !=0))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i8);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i8);
	if (((Integer) field(mktag(1), (Integer) r5, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i8);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r5, ((Integer) 1)), ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i8);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r5, ((Integer) 1)), ((Integer) 0));
	r1 = string_const(", ", 2);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_list_tail_7_0_i16,
		STATIC(mercury__term_io__write_list_tail_7_0));
	}
Define_label(mercury__term_io__write_list_tail_7_0_i16);
	update_prof_current_proc(LABEL(mercury__term_io__write_list_tail_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__term_io__write_term_2_7_0),
		mercury__term_io__write_list_tail_7_0_i17,
		STATIC(mercury__term_io__write_list_tail_7_0));
Define_label(mercury__term_io__write_list_tail_7_0_i17);
	update_prof_current_proc(LABEL(mercury__term_io__write_list_tail_7_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__term_io__write_list_tail_7_0,
		STATIC(mercury__term_io__write_list_tail_7_0));
Define_label(mercury__term_io__write_list_tail_7_0_i8);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i19);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r5) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i19);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r5, ((Integer) 0)), (char *)string_const("[]", 2)) !=0))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i19);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	if (((Integer) r5 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_list_tail_7_0_i19);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__term_io__write_list_tail_7_0_i19);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = string_const(" | ", 3);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_list_tail_7_0_i25,
		STATIC(mercury__term_io__write_list_tail_7_0));
	}
Define_label(mercury__term_io__write_list_tail_7_0_i25);
	update_prof_current_proc(LABEL(mercury__term_io__write_list_tail_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__term_io__write_term_2_7_0),
		STATIC(mercury__term_io__write_list_tail_7_0));
END_MODULE

BEGIN_MODULE(mercury__term_io_module12)
	init_entry(mercury__term_io__write_term_args_7_0);
	init_label(mercury__term_io__write_term_args_7_0_i4);
	init_label(mercury__term_io__write_term_args_7_0_i5);
	init_label(mercury__term_io__write_term_args_7_0_i1002);
BEGIN_CODE

/* code for predicate 'term_io__write_term_args'/7 in mode 0 */
Define_static(mercury__term_io__write_term_args_7_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__term_io__write_term_args_7_0_i1002);
	incr_sp_push_msg(5, "term_io__write_term_args");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = string_const(", ", 2);
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__io__write_string_3_0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__term_io__write_term_args_7_0_i4,
		STATIC(mercury__term_io__write_term_args_7_0));
	}
Define_label(mercury__term_io__write_term_args_7_0_i4);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_args_7_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__term_io__write_term_2_7_0),
		mercury__term_io__write_term_args_7_0_i5,
		STATIC(mercury__term_io__write_term_args_7_0));
Define_label(mercury__term_io__write_term_args_7_0_i5);
	update_prof_current_proc(LABEL(mercury__term_io__write_term_args_7_0));
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__term_io__write_term_args_7_0,
		STATIC(mercury__term_io__write_term_args_7_0));
Define_label(mercury__term_io__write_term_args_7_0_i1002);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module13)
	init_entry(mercury____Unify___term_io__read_term_0_0);
	init_label(mercury____Unify___term_io__read_term_0_0_i1013);
	init_label(mercury____Unify___term_io__read_term_0_0_i6);
	init_label(mercury____Unify___term_io__read_term_0_0_i9);
	init_label(mercury____Unify___term_io__read_term_0_0_i1010);
	init_label(mercury____Unify___term_io__read_term_0_0_i1);
	init_label(mercury____Unify___term_io__read_term_0_0_i1012);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_io__read_term_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1013);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___term_io__read_term_0_0_i1013);
	incr_sp_push_msg(3, "__Unify__");
	detstackvar(3) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(1), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1012);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___term_io__read_term_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1);
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury____Unify___varset__varset_0_0);
	call_localret(ENTRY(mercury____Unify___varset__varset_0_0),
		mercury____Unify___term_io__read_term_0_0_i9,
		ENTRY(mercury____Unify___term_io__read_term_0_0));
	}
Define_label(mercury____Unify___term_io__read_term_0_0_i9);
	update_prof_current_proc(LABEL(mercury____Unify___term_io__read_term_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___term_io__read_term_0_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury____Unify___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__term_0_0),
		ENTRY(mercury____Unify___term_io__read_term_0_0));
	}
Define_label(mercury____Unify___term_io__read_term_0_0_i1010);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___term_io__read_term_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___term_io__read_term_0_0_i1012);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module14)
	init_entry(mercury____Index___term_io__read_term_0_0);
	init_label(mercury____Index___term_io__read_term_0_0_i4);
	init_label(mercury____Index___term_io__read_term_0_0_i5);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_io__read_term_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___term_io__read_term_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___term_io__read_term_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___term_io__read_term_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___term_io__read_term_0_0_i5);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__term_io_module15)
	init_entry(mercury____Compare___term_io__read_term_0_0);
	init_label(mercury____Compare___term_io__read_term_0_0_i2);
	init_label(mercury____Compare___term_io__read_term_0_0_i3);
	init_label(mercury____Compare___term_io__read_term_0_0_i4);
	init_label(mercury____Compare___term_io__read_term_0_0_i6);
	init_label(mercury____Compare___term_io__read_term_0_0_i12);
	init_label(mercury____Compare___term_io__read_term_0_0_i18);
	init_label(mercury____Compare___term_io__read_term_0_0_i19);
	init_label(mercury____Compare___term_io__read_term_0_0_i17);
	init_label(mercury____Compare___term_io__read_term_0_0_i14);
	init_label(mercury____Compare___term_io__read_term_0_0_i27);
	init_label(mercury____Compare___term_io__read_term_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_io__read_term_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___term_io__read_term_0_0),
		mercury____Compare___term_io__read_term_0_0_i2,
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
Define_label(mercury____Compare___term_io__read_term_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___term_io__read_term_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___term_io__read_term_0_0),
		mercury____Compare___term_io__read_term_0_0_i3,
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
Define_label(mercury____Compare___term_io__read_term_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___term_io__read_term_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___term_io__read_term_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___term_io__read_term_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i12);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___term_io__read_term_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i14);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___term_io__read_term_0_0_i18,
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
Define_label(mercury____Compare___term_io__read_term_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Compare___term_io__read_term_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i17);
Define_label(mercury____Compare___term_io__read_term_0_0_i19);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___term_io__read_term_0_0_i17);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
Define_label(mercury____Compare___term_io__read_term_0_0_i14);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury____Compare___varset__varset_0_0);
	call_localret(ENTRY(mercury____Compare___varset__varset_0_0),
		mercury____Compare___term_io__read_term_0_0_i27,
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
Define_label(mercury____Compare___term_io__read_term_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___term_io__read_term_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_io__read_term_0_0_i19);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Compare___mercury_builtin__term_0_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__term_0_0),
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
Define_label(mercury____Compare___term_io__read_term_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___term_io__read_term_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__term_io_bunch_0(void)
{
	mercury__term_io_module0();
	mercury__term_io_module1();
	mercury__term_io_module2();
	mercury__term_io_module3();
	mercury__term_io_module4();
	mercury__term_io_module5();
	mercury__term_io_module6();
	mercury__term_io_module7();
	mercury__term_io_module8();
	mercury__term_io_module9();
	mercury__term_io_module10();
	mercury__term_io_module11();
	mercury__term_io_module12();
	mercury__term_io_module13();
	mercury__term_io_module14();
	mercury__term_io_module15();
}

#endif

void mercury__term_io__init(void); /* suppress gcc warning */
void mercury__term_io__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__term_io_bunch_0();
#endif
}
