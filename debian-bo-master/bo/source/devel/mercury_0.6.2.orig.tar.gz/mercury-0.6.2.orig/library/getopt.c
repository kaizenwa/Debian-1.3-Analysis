/*
** Automatically generated from `getopt.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__getopt__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0);
Declare_label(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0_i3);
Declare_static(mercury____Compare___getopt_option_ops_1__ua10000_3_0);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i2);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i3);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i4);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i6);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i15);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i14);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i21);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i11);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i31);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i37);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i43);
Declare_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i9);
Declare_static(mercury____Index___getopt_option_ops_1__ua10000_2_0);
Declare_label(mercury____Index___getopt_option_ops_1__ua10000_2_0_i3);
Declare_static(mercury____Unify___getopt_option_ops_1__ua0_2_0);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i5);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i7);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1013);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i12);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i14);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i16);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1010);
Declare_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
Declare_static(mercury__getopt__get_long_options__ua10000_2_0);
Declare_label(mercury__getopt__get_long_options__ua10000_2_0_i3);
Declare_static(mercury__getopt__get_short_options__ua10000_2_0);
Declare_label(mercury__getopt__get_short_options__ua10000_2_0_i3);
Declare_static(mercury__getopt__numeric_argument__ua10000_3_0);
Declare_label(mercury__getopt__numeric_argument__ua10000_3_0_i2);
Declare_static(mercury__getopt__process_special__ua10000_6_0);
Declare_label(mercury__getopt__process_special__ua10000_6_0_i7);
Declare_label(mercury__getopt__process_special__ua10000_6_0_i6);
Declare_label(mercury__getopt__process_special__ua10000_6_0_i9);
Declare_label(mercury__getopt__process_special__ua10000_6_0_i2);
Declare_label(mercury__getopt__process_special__ua10000_6_0_i11);
Declare_static(mercury__getopt__LambdaGoal__1_2_0);
Declare_label(mercury__getopt__LambdaGoal__1_2_0_i1);
Define_extern_entry(mercury__getopt__process_options_4_0);
Declare_label(mercury__getopt__process_options_4_0_i1000);
Declare_label(mercury__getopt__process_options_4_0_i2);
Declare_label(mercury__getopt__process_options_4_0_i4);
Declare_label(mercury__getopt__process_options_4_0_i5);
Define_extern_entry(mercury__getopt__lookup_bool_option_3_0);
Declare_label(mercury__getopt__lookup_bool_option_3_0_i4);
Declare_label(mercury__getopt__lookup_bool_option_3_0_i1000);
Define_extern_entry(mercury__getopt__lookup_int_option_3_0);
Declare_label(mercury__getopt__lookup_int_option_3_0_i4);
Declare_label(mercury__getopt__lookup_int_option_3_0_i1000);
Define_extern_entry(mercury__getopt__lookup_string_option_3_0);
Declare_label(mercury__getopt__lookup_string_option_3_0_i4);
Declare_label(mercury__getopt__lookup_string_option_3_0_i3);
Declare_label(mercury__getopt__lookup_string_option_3_0_i1000);
Declare_static(mercury__getopt__process_arguments_5_0);
Declare_label(mercury__getopt__process_arguments_5_0_i4);
Declare_label(mercury__getopt__process_arguments_5_0_i9);
Declare_label(mercury__getopt__process_arguments_5_0_i11);
Declare_label(mercury__getopt__process_arguments_5_0_i14);
Declare_label(mercury__getopt__process_arguments_5_0_i16);
Declare_label(mercury__getopt__process_arguments_5_0_i17);
Declare_label(mercury__getopt__process_arguments_5_0_i18);
Declare_label(mercury__getopt__process_arguments_5_0_i1030);
Declare_label(mercury__getopt__process_arguments_5_0_i23);
Declare_label(mercury__getopt__process_arguments_5_0_i8);
Declare_label(mercury__getopt__process_arguments_5_0_i27);
Declare_label(mercury__getopt__process_arguments_5_0_i29);
Declare_label(mercury__getopt__process_arguments_5_0_i32);
Declare_label(mercury__getopt__process_arguments_5_0_i34);
Declare_label(mercury__getopt__process_arguments_5_0_i37);
Declare_label(mercury__getopt__process_arguments_5_0_i36);
Declare_label(mercury__getopt__process_arguments_5_0_i39);
Declare_label(mercury__getopt__process_arguments_5_0_i31);
Declare_label(mercury__getopt__process_arguments_5_0_i41);
Declare_label(mercury__getopt__process_arguments_5_0_i44);
Declare_label(mercury__getopt__process_arguments_5_0_i48);
Declare_label(mercury__getopt__process_arguments_5_0_i1039);
Declare_label(mercury__getopt__process_arguments_5_0_i43);
Declare_label(mercury__getopt__process_arguments_5_0_i53);
Declare_label(mercury__getopt__process_arguments_5_0_i26);
Declare_label(mercury__getopt__process_arguments_5_0_i58);
Declare_label(mercury__getopt__process_arguments_5_0_i60);
Declare_label(mercury__getopt__process_arguments_5_0_i67);
Declare_label(mercury__getopt__process_arguments_5_0_i70);
Declare_label(mercury__getopt__process_arguments_5_0_i72);
Declare_label(mercury__getopt__process_arguments_5_0_i1049);
Declare_label(mercury__getopt__process_arguments_5_0_i61);
Declare_label(mercury__getopt__process_arguments_5_0_i81);
Declare_label(mercury__getopt__process_arguments_5_0_i82);
Declare_label(mercury__getopt__process_arguments_5_0_i57);
Declare_label(mercury__getopt__process_arguments_5_0_i88);
Declare_label(mercury__getopt__process_arguments_5_0_i1050);
Declare_static(mercury__getopt__handle_long_option_9_0);
Declare_label(mercury__getopt__handle_long_option_9_0_i4);
Declare_label(mercury__getopt__handle_long_option_9_0_i6);
Declare_label(mercury__getopt__handle_long_option_9_0_i3);
Declare_label(mercury__getopt__handle_long_option_9_0_i10);
Declare_label(mercury__getopt__handle_long_option_9_0_i14);
Declare_label(mercury__getopt__handle_long_option_9_0_i11);
Declare_label(mercury__getopt__handle_long_option_9_0_i15);
Declare_label(mercury__getopt__handle_long_option_9_0_i16);
Declare_static(mercury__getopt__handle_short_options_6_0);
Declare_label(mercury__getopt__handle_short_options_6_0_i1001);
Declare_label(mercury__getopt__handle_short_options_6_0_i4);
Declare_label(mercury__getopt__handle_short_options_6_0_i8);
Declare_label(mercury__getopt__handle_short_options_6_0_i12);
Declare_label(mercury__getopt__handle_short_options_6_0_i16);
Declare_label(mercury__getopt__handle_short_options_6_0_i17);
Declare_label(mercury__getopt__handle_short_options_6_0_i21);
Declare_label(mercury__getopt__handle_short_options_6_0_i15);
Declare_label(mercury__getopt__handle_short_options_6_0_i23);
Declare_label(mercury__getopt__handle_short_options_6_0_i24);
Declare_label(mercury__getopt__handle_short_options_6_0_i25);
Declare_label(mercury__getopt__handle_short_options_6_0_i26);
Declare_label(mercury__getopt__handle_short_options_6_0_i11);
Declare_label(mercury__getopt__handle_short_options_6_0_i31);
Declare_label(mercury__getopt__handle_short_options_6_0_i32);
Declare_label(mercury__getopt__handle_short_options_6_0_i7);
Declare_label(mercury__getopt__handle_short_options_6_0_i34);
Declare_label(mercury__getopt__handle_short_options_6_0_i1000);
Declare_static(mercury__getopt__process_option_7_0);
Declare_label(mercury__getopt__process_option_7_0_i1008);
Declare_label(mercury__getopt__process_option_7_0_i12);
Declare_label(mercury__getopt__process_option_7_0_i25);
Declare_label(mercury__getopt__process_option_7_0_i24);
Declare_label(mercury__getopt__process_option_7_0_i20);
Declare_label(mercury__getopt__process_option_7_0_i19);
Declare_label(mercury__getopt__process_option_7_0_i32);
Declare_label(mercury__getopt__process_option_7_0_i1007);
Declare_label(mercury__getopt__process_option_7_0_i43);
Declare_label(mercury__getopt__process_option_7_0_i40);
Declare_label(mercury__getopt__process_option_7_0_i39);
Declare_label(mercury__getopt__process_option_7_0_i49);
Declare_label(mercury__getopt__process_option_7_0_i46);
Declare_label(mercury__getopt__process_option_7_0_i38);
Declare_label(mercury__getopt__process_option_7_0_i54);
Declare_label(mercury__getopt__process_option_7_0_i53);
Declare_label(mercury__getopt__process_option_7_0_i65);
Declare_label(mercury__getopt__process_option_7_0_i64);
Declare_label(mercury__getopt__process_option_7_0_i60);
Declare_label(mercury__getopt__process_option_7_0_i1000);
Declare_label(mercury__getopt__process_option_7_0_i1001);
Declare_static(mercury__getopt__process_negated_bool_option_5_0);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i4);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i9);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i6);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i1010);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i14);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i1013);
Declare_label(mercury__getopt__process_negated_bool_option_5_0_i17);
Declare_static(mercury__getopt__need_arg_2_0);
Declare_label(mercury__getopt__need_arg_2_0_i5);
Declare_label(mercury__getopt__need_arg_2_0_i6);
Declare_label(mercury__getopt__need_arg_2_0_i7);
Declare_label(mercury__getopt__need_arg_2_0_i4);
Declare_label(mercury__getopt__need_arg_2_0_i8);
Declare_label(mercury__getopt__need_arg_2_0_i10);
Define_extern_entry(mercury____Unify___getopt__option_ops_1_0);
Define_extern_entry(mercury____Index___getopt__option_ops_1_0);
Define_extern_entry(mercury____Compare___getopt__option_ops_1_0);
Define_extern_entry(mercury____Unify___getopt__option_data_0_0);
Declare_label(mercury____Unify___getopt__option_data_0_0_i1027);
Declare_label(mercury____Unify___getopt__option_data_0_0_i7);
Declare_label(mercury____Unify___getopt__option_data_0_0_i9);
Declare_label(mercury____Unify___getopt__option_data_0_0_i1026);
Declare_label(mercury____Unify___getopt__option_data_0_0_i13);
Declare_label(mercury____Unify___getopt__option_data_0_0_i12);
Declare_label(mercury____Unify___getopt__option_data_0_0_i18);
Declare_label(mercury____Unify___getopt__option_data_0_0_i1022);
Declare_label(mercury____Unify___getopt__option_data_0_0_i1);
Declare_label(mercury____Unify___getopt__option_data_0_0_i1024);
Declare_label(mercury____Unify___getopt__option_data_0_0_i1025);
Define_extern_entry(mercury____Index___getopt__option_data_0_0);
Declare_label(mercury____Index___getopt__option_data_0_0_i5);
Declare_label(mercury____Index___getopt__option_data_0_0_i6);
Declare_label(mercury____Index___getopt__option_data_0_0_i7);
Declare_label(mercury____Index___getopt__option_data_0_0_i4);
Declare_label(mercury____Index___getopt__option_data_0_0_i9);
Declare_label(mercury____Index___getopt__option_data_0_0_i8);
Declare_label(mercury____Index___getopt__option_data_0_0_i10);
Define_extern_entry(mercury____Compare___getopt__option_data_0_0);
Declare_label(mercury____Compare___getopt__option_data_0_0_i2);
Declare_label(mercury____Compare___getopt__option_data_0_0_i3);
Declare_label(mercury____Compare___getopt__option_data_0_0_i4);
Declare_label(mercury____Compare___getopt__option_data_0_0_i6);
Declare_label(mercury____Compare___getopt__option_data_0_0_i13);
Declare_label(mercury____Compare___getopt__option_data_0_0_i15);
Declare_label(mercury____Compare___getopt__option_data_0_0_i17);
Declare_label(mercury____Compare___getopt__option_data_0_0_i12);
Declare_label(mercury____Compare___getopt__option_data_0_0_i21);
Declare_label(mercury____Compare___getopt__option_data_0_0_i20);
Declare_label(mercury____Compare___getopt__option_data_0_0_i26);
Declare_label(mercury____Compare___getopt__option_data_0_0_i9);
Declare_label(mercury____Compare___getopt__option_data_0_0_i1000);
Define_extern_entry(mercury____Unify___getopt__special_data_0_0);
Declare_label(mercury____Unify___getopt__special_data_0_0_i4);
Declare_label(mercury____Unify___getopt__special_data_0_0_i6);
Declare_label(mercury____Unify___getopt__special_data_0_0_i8);
Declare_label(mercury____Unify___getopt__special_data_0_0_i2);
Declare_label(mercury____Unify___getopt__special_data_0_0_i1);
Define_extern_entry(mercury____Index___getopt__special_data_0_0);
Declare_label(mercury____Index___getopt__special_data_0_0_i4);
Declare_label(mercury____Index___getopt__special_data_0_0_i5);
Declare_label(mercury____Index___getopt__special_data_0_0_i6);
Define_extern_entry(mercury____Compare___getopt__special_data_0_0);
Declare_label(mercury____Compare___getopt__special_data_0_0_i2);
Declare_label(mercury____Compare___getopt__special_data_0_0_i3);
Declare_label(mercury____Compare___getopt__special_data_0_0_i4);
Declare_label(mercury____Compare___getopt__special_data_0_0_i6);
Declare_label(mercury____Compare___getopt__special_data_0_0_i12);
Declare_label(mercury____Compare___getopt__special_data_0_0_i14);
Declare_label(mercury____Compare___getopt__special_data_0_0_i17);
Declare_label(mercury____Compare___getopt__special_data_0_0_i9);
Declare_label(mercury____Compare___getopt__special_data_0_0_i1000);
Define_extern_entry(mercury____Unify___getopt__option_table_1_0);
Define_extern_entry(mercury____Index___getopt__option_table_1_0);
Define_extern_entry(mercury____Compare___getopt__option_table_1_0);
Define_extern_entry(mercury____Unify___getopt__maybe_option_table_1_0);
Declare_label(mercury____Unify___getopt__maybe_option_table_1_0_i1008);
Declare_label(mercury____Unify___getopt__maybe_option_table_1_0_i1005);
Declare_label(mercury____Unify___getopt__maybe_option_table_1_0_i1);
Declare_label(mercury____Unify___getopt__maybe_option_table_1_0_i1007);
Define_extern_entry(mercury____Index___getopt__maybe_option_table_1_0);
Define_extern_entry(mercury____Compare___getopt__maybe_option_table_1_0);
Declare_label(mercury____Compare___getopt__maybe_option_table_1_0_i2);
Declare_label(mercury____Compare___getopt__maybe_option_table_1_0_i3);
Declare_label(mercury____Compare___getopt__maybe_option_table_1_0_i4);
Declare_label(mercury____Compare___getopt__maybe_option_table_1_0_i6);
Declare_label(mercury____Compare___getopt__maybe_option_table_1_0_i11);
Declare_label(mercury____Compare___getopt__maybe_option_table_1_0_i9);

extern Word * mercury_data_getopt__base_type_layout_maybe_option_table_1[];
Word * mercury_data_getopt__base_type_info_maybe_option_table_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___getopt__maybe_option_table_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___getopt__maybe_option_table_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___getopt__maybe_option_table_1_0),
	(Word *) (Integer) mercury_data_getopt__base_type_layout_maybe_option_table_1
};

extern Word * mercury_data_getopt__base_type_layout_option_data_0[];
Word * mercury_data_getopt__base_type_info_option_data_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___getopt__option_data_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___getopt__option_data_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___getopt__option_data_0_0),
	(Word *) (Integer) mercury_data_getopt__base_type_layout_option_data_0
};

extern Word * mercury_data_getopt__base_type_layout_option_ops_1[];
Word * mercury_data_getopt__base_type_info_option_ops_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___getopt__option_ops_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___getopt__option_ops_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___getopt__option_ops_1_0),
	(Word *) (Integer) mercury_data_getopt__base_type_layout_option_ops_1
};

extern Word * mercury_data_getopt__base_type_layout_option_table_1[];
Word * mercury_data_getopt__base_type_info_option_table_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___getopt__option_table_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___getopt__option_table_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___getopt__option_table_1_0),
	(Word *) (Integer) mercury_data_getopt__base_type_layout_option_table_1
};

extern Word * mercury_data_getopt__base_type_layout_special_data_0[];
Word * mercury_data_getopt__base_type_info_special_data_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___getopt__special_data_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___getopt__special_data_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___getopt__special_data_0_0),
	(Word *) (Integer) mercury_data_getopt__base_type_layout_special_data_0
};

extern Word * mercury_data_getopt__common_8[];
extern Word * mercury_data_getopt__common_10[];
extern Word * mercury_data_getopt__common_12[];
extern Word * mercury_data_getopt__common_14[];
Word * mercury_data_getopt__base_type_layout_special_data_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_8),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_10),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_12),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_14)
};

extern Word * mercury_data_getopt__common_16[];
Word * mercury_data_getopt__base_type_layout_option_table_1[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_getopt__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_getopt__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_getopt__common_16),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_getopt__common_16)
};

extern Word * mercury_data_getopt__common_20[];
extern Word * mercury_data_getopt__common_23[];
Word * mercury_data_getopt__base_type_layout_option_ops_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_20),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_23),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_getopt__common_24[];
extern Word * mercury_data_getopt__common_27[];
Word * mercury_data_getopt__base_type_layout_option_data_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_24),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_10),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_12),
	(Word *) (Integer) mkword(mktag(2), (Integer) mercury_data_getopt__common_27)
};

extern Word * mercury_data_getopt__common_28[];
extern Word * mercury_data_getopt__common_29[];
Word * mercury_data_getopt__base_type_layout_maybe_option_table_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_28),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_29),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_getopt__common_0[] = {
	(Word *) string_const("' is not numeric", 16),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_getopt__common_1[] = {
	(Word *) string_const("' failed", 8),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_getopt__common_2[] = {
	(Word *) string_const("' has no handler", 16),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_getopt__common_3[] = {
	(Word *) string_const("'", 1),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_getopt__common_4[] = {
	(Word *) string_const("' needs an argument", 19),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word mercury_data_getopt__common_5[] = {
	((Integer) 1)
};

Word mercury_data_getopt__common_6[] = {
	((Integer) 0)
};

Word * mercury_data_getopt__common_7[] = {
	(Word *) string_const("' -- only boolean options can be negated", 40),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 0)))
};

Word * mercury_data_getopt__common_8[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("none", 4)
};

extern Word * mercury_data_bool__base_type_info_bool_0[];
Word * mercury_data_getopt__common_9[] = {
	(Word *) (Integer) mercury_data_bool__base_type_info_bool_0
};

Word * mercury_data_getopt__common_10[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_9),
	(Word *) string_const("bool", 4)
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_getopt__common_11[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_getopt__common_12[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_11),
	(Word *) string_const("int", 3)
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_getopt__common_13[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_getopt__common_14[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_13),
	(Word *) string_const("string", 6)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_getopt__common_15[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) ((Integer) 1),
	(Word *) (Integer) mercury_data_getopt__base_type_info_option_data_0
};

Word * mercury_data_getopt__common_16[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_15)
};

extern Word * mercury_data___base_type_info_pred_0[];
extern Word * mercury_data___base_type_info_character_0[];
Word * mercury_data_getopt__common_17[] = {
	(Word *) (Integer) mercury_data___base_type_info_pred_0,
	(Word *) ((Integer) 2),
	(Word *) (Integer) mercury_data___base_type_info_character_0,
	(Word *) ((Integer) 1)
};

Word * mercury_data_getopt__common_18[] = {
	(Word *) (Integer) mercury_data___base_type_info_pred_0,
	(Word *) ((Integer) 2),
	(Word *) (Integer) mercury_data___base_type_info_string_0,
	(Word *) ((Integer) 1)
};

Word * mercury_data_getopt__common_19[] = {
	(Word *) (Integer) mercury_data___base_type_info_pred_0,
	(Word *) ((Integer) 2),
	(Word *) ((Integer) 1),
	(Word *) (Integer) mercury_data_getopt__base_type_info_option_data_0
};

Word * mercury_data_getopt__common_20[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_18),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_19),
	(Word *) string_const("option_ops", 10)
};

Word * mercury_data_getopt__common_21[] = {
	(Word *) (Integer) mercury_data_getopt__base_type_info_maybe_option_table_1,
	(Word *) ((Integer) 1)
};

Word * mercury_data_getopt__common_22[] = {
	(Word *) (Integer) mercury_data___base_type_info_pred_0,
	(Word *) ((Integer) 4),
	(Word *) ((Integer) 1),
	(Word *) (Integer) mercury_data_getopt__base_type_info_special_data_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_15),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_21)
};

Word * mercury_data_getopt__common_23[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_18),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_19),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_22),
	(Word *) string_const("option_ops", 10)
};

Word * mercury_data_getopt__common_24[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 4),
	(Word *) string_const("special", 7),
	(Word *) string_const("bool_special", 12),
	(Word *) string_const("int_special", 11),
	(Word *) string_const("string_special", 14)
};

extern Word * mercury_data_mercury_builtin__base_type_info_list_1[];
Word * mercury_data_getopt__common_25[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_getopt__common_26[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_25),
	(Word *) string_const("accumulating", 12)
};

Word * mercury_data_getopt__common_27[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_14),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_26)
};

Word * mercury_data_getopt__common_28[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_15),
	(Word *) string_const("ok", 2)
};

Word * mercury_data_getopt__common_29[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_getopt__common_13),
	(Word *) string_const("error", 5)
};

BEGIN_MODULE(mercury__getopt_module0)
	init_entry(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0);
	init_label(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index___getopt_maybe_option_table_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module1)
	init_entry(mercury____Compare___getopt_option_ops_1__ua10000_3_0);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i2);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i3);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i4);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i6);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i15);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i14);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i21);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i11);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i31);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i37);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i43);
	init_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i9);
BEGIN_CODE

/* code for predicate '__Compare___getopt_option_ops_1__ua10000'/3 in mode 0 */
Define_static(mercury____Compare___getopt_option_ops_1__ua10000_3_0);
	incr_sp_push_msg(7, "__Compare___getopt_option_ops_1__ua10000");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	call_localret(STATIC(mercury____Index___getopt_option_ops_1__ua10000_2_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i2,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury____Index___getopt_option_ops_1__ua10000_2_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i3,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i6);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i15,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i14);
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i14);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i21,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i9);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i31,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i37,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i37);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___getopt_option_ops_1__ua10000_3_0_i43,
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i43);
	update_prof_current_proc(LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i16);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_compare_pred_3_0);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
Define_label(mercury____Compare___getopt_option_ops_1__ua10000_3_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module2)
	init_entry(mercury____Index___getopt_option_ops_1__ua10000_2_0);
	init_label(mercury____Index___getopt_option_ops_1__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index___getopt_option_ops_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___getopt_option_ops_1__ua10000_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___getopt_option_ops_1__ua10000_2_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___getopt_option_ops_1__ua10000_2_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module3)
	init_entry(mercury____Unify___getopt_option_ops_1__ua0_2_0);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i5);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i7);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1013);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i12);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i14);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i16);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1010);
	init_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify___getopt_option_ops_1__ua0'/2 in mode 0 */
Define_static(mercury____Unify___getopt_option_ops_1__ua0_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1013);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1010);
	incr_sp_push_msg(7, "__Unify___getopt_option_ops_1__ua0");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___getopt_option_ops_1__ua0_2_0_i5,
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___getopt_option_ops_1__ua0_2_0_i7,
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1013);
	incr_sp_push_msg(7, "__Unify___getopt_option_ops_1__ua0");
	detstackvar(7) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___getopt_option_ops_1__ua0_2_0_i12,
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___getopt_option_ops_1__ua0_2_0_i14,
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___getopt_option_ops_1__ua0_2_0_i16,
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__builtin_unify_pred_2_0);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0));
	}
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1010);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt_option_ops_1__ua0_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module4)
	init_entry(mercury__getopt__get_long_options__ua10000_2_0);
	init_label(mercury__getopt__get_long_options__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate 'getopt__get_long_options__ua10000'/2 in mode 0 */
Define_static(mercury__getopt__get_long_options__ua10000_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__get_long_options__ua10000_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__getopt__get_long_options__ua10000_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module5)
	init_entry(mercury__getopt__get_short_options__ua10000_2_0);
	init_label(mercury__getopt__get_short_options__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate 'getopt__get_short_options__ua10000'/2 in mode 0 */
Define_static(mercury__getopt__get_short_options__ua10000_2_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__get_short_options__ua10000_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__getopt__get_short_options__ua10000_2_0_i3);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module6)
	init_entry(mercury__getopt__numeric_argument__ua10000_3_0);
	init_label(mercury__getopt__numeric_argument__ua10000_3_0_i2);
BEGIN_CODE

/* code for predicate 'getopt__numeric_argument__ua10000'/3 in mode 0 */
Define_static(mercury__getopt__numeric_argument__ua10000_3_0);
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("option `", 8);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r3;
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = string_const("' requires a numeric argument; `", 32);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) r3;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r5;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_0);
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	incr_sp_push_msg(1, "getopt__numeric_argument__ua10000");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__numeric_argument__ua10000_3_0_i2,
		STATIC(mercury__getopt__numeric_argument__ua10000_3_0));
	}
Define_label(mercury__getopt__numeric_argument__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__getopt__numeric_argument__ua10000_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module7)
	init_entry(mercury__getopt__process_special__ua10000_6_0);
	init_label(mercury__getopt__process_special__ua10000_6_0_i7);
	init_label(mercury__getopt__process_special__ua10000_6_0_i6);
	init_label(mercury__getopt__process_special__ua10000_6_0_i9);
	init_label(mercury__getopt__process_special__ua10000_6_0_i2);
	init_label(mercury__getopt__process_special__ua10000_6_0_i11);
BEGIN_CODE

/* code for predicate 'getopt__process_special__ua10000'/6 in mode 0 */
Define_static(mercury__getopt__process_special__ua10000_6_0);
	incr_sp_push_msg(2, "getopt__process_special__ua10000");
	detstackvar(2) = (Integer) succip;
	if ((tag((Integer) r4) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__getopt__process_special__ua10000_6_0_i2);
	r6 = (Integer) r5;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r4, ((Integer) 3));
	r4 = (Integer) r2;
	r5 = (Integer) r3;
	r2 = ((Integer) 3);
	r3 = ((Integer) 1);
	{
	Declare_entry(do_call_semidet_closure);
	call_localret(ENTRY(do_call_semidet_closure),
		mercury__getopt__process_special__ua10000_6_0_i7,
		STATIC(mercury__getopt__process_special__ua10000_6_0));
	}
Define_label(mercury__getopt__process_special__ua10000_6_0_i7);
	update_prof_current_proc(LABEL(mercury__getopt__process_special__ua10000_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_special__ua10000_6_0_i6);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__getopt__process_special__ua10000_6_0_i6);
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("the handler of option `", 23);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_special__ua10000_6_0_i9,
		STATIC(mercury__getopt__process_special__ua10000_6_0));
	}
Define_label(mercury__getopt__process_special__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__getopt__process_special__ua10000_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__getopt__process_special__ua10000_6_0_i2);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("option `", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_2);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_special__ua10000_6_0_i11,
		STATIC(mercury__getopt__process_special__ua10000_6_0));
	}
Define_label(mercury__getopt__process_special__ua10000_6_0_i11);
	update_prof_current_proc(LABEL(mercury__getopt__process_special__ua10000_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module8)
	init_entry(mercury__getopt__LambdaGoal__1_2_0);
	init_label(mercury__getopt__LambdaGoal__1_2_0_i1);
BEGIN_CODE

/* code for predicate 'getopt__LambdaGoal__1'/2 in mode 0 */
Define_static(mercury__getopt__LambdaGoal__1_2_0);
	{
	Declare_entry(do_fail);
	mkframe("getopt__LambdaGoal__1/2", 1, ENTRY(do_fail));
	}
	r2 = ((Integer) 0);
	r3 = ((Integer) 2);
	{
	Declare_entry(do_call_nondet_closure);
	call_localret(ENTRY(do_call_nondet_closure),
		mercury__getopt__LambdaGoal__1_2_0_i1,
		STATIC(mercury__getopt__LambdaGoal__1_2_0));
	}
Define_label(mercury__getopt__LambdaGoal__1_2_0_i1);
	update_prof_current_proc(LABEL(mercury__getopt__LambdaGoal__1_2_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	succeed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module9)
	init_entry(mercury__getopt__process_options_4_0);
	init_label(mercury__getopt__process_options_4_0_i1000);
	init_label(mercury__getopt__process_options_4_0_i2);
	init_label(mercury__getopt__process_options_4_0_i4);
	init_label(mercury__getopt__process_options_4_0_i5);
BEGIN_CODE

/* code for predicate 'getopt__process_options'/4 in mode 0 */
Define_entry(mercury__getopt__process_options_4_0);
	if ((tag((Integer) r2) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__process_options_4_0_i1000);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) STATIC(mercury__getopt__LambdaGoal__1_2_0);
	r5 = (Integer) r1;
	r7 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	{
	extern Word * mercury_data_std_util__base_type_info_pair_2[];
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_std_util__base_type_info_pair_2;
	}
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r7;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	incr_sp_push_msg(4, "getopt__process_options");
	detstackvar(4) = (Integer) succip;
	GOTO_LABEL(mercury__getopt__process_options_4_0_i2);
Define_label(mercury__getopt__process_options_4_0_i1000);
	incr_sp_push_msg(4, "getopt__process_options");
	detstackvar(4) = (Integer) succip;
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r5 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = ((Integer) 1);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) STATIC(mercury__getopt__LambdaGoal__1_2_0);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r5, ((Integer) 2));
	r5 = (Integer) r1;
	r7 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	{
	extern Word * mercury_data_std_util__base_type_info_pair_2[];
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_std_util__base_type_info_pair_2;
	}
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r7;
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) mercury_data_getopt__base_type_info_option_data_0;
Define_label(mercury__getopt__process_options_4_0_i2);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	{
	Declare_entry(mercury__std_util__solutions_2_1);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__getopt__process_options_4_0_i4,
		ENTRY(mercury__getopt__process_options_4_0));
	}
Define_label(mercury__getopt__process_options_4_0_i4);
	update_prof_current_proc(LABEL(mercury__getopt__process_options_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury__map__from_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__getopt__process_options_4_0_i5,
		ENTRY(mercury__getopt__process_options_4_0));
	}
Define_label(mercury__getopt__process_options_4_0_i5);
	update_prof_current_proc(LABEL(mercury__getopt__process_options_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__getopt__process_arguments_5_0),
		ENTRY(mercury__getopt__process_options_4_0));
END_MODULE

BEGIN_MODULE(mercury__getopt_module10)
	init_entry(mercury__getopt__lookup_bool_option_3_0);
	init_label(mercury__getopt__lookup_bool_option_3_0_i4);
	init_label(mercury__getopt__lookup_bool_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'getopt__lookup_bool_option'/3 in mode 0 */
Define_entry(mercury__getopt__lookup_bool_option_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	incr_sp_push_msg(1, "getopt__lookup_bool_option");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__getopt__lookup_bool_option_3_0_i4,
		ENTRY(mercury__getopt__lookup_bool_option_3_0));
	}
Define_label(mercury__getopt__lookup_bool_option_3_0_i4);
	update_prof_current_proc(LABEL(mercury__getopt__lookup_bool_option_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__getopt__lookup_bool_option_3_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__getopt__lookup_bool_option_3_0_i1000);
	r1 = string_const("Expected bool option and didn't get one.", 40);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__getopt__lookup_bool_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module11)
	init_entry(mercury__getopt__lookup_int_option_3_0);
	init_label(mercury__getopt__lookup_int_option_3_0_i4);
	init_label(mercury__getopt__lookup_int_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'getopt__lookup_int_option'/3 in mode 0 */
Define_entry(mercury__getopt__lookup_int_option_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	incr_sp_push_msg(1, "getopt__lookup_int_option");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__getopt__lookup_int_option_3_0_i4,
		ENTRY(mercury__getopt__lookup_int_option_3_0));
	}
Define_label(mercury__getopt__lookup_int_option_3_0_i4);
	update_prof_current_proc(LABEL(mercury__getopt__lookup_int_option_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__getopt__lookup_int_option_3_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	proceed();
Define_label(mercury__getopt__lookup_int_option_3_0_i1000);
	r1 = string_const("Expected int option and didn't get one.", 39);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__getopt__lookup_int_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module12)
	init_entry(mercury__getopt__lookup_string_option_3_0);
	init_label(mercury__getopt__lookup_string_option_3_0_i4);
	init_label(mercury__getopt__lookup_string_option_3_0_i3);
	init_label(mercury__getopt__lookup_string_option_3_0_i1000);
BEGIN_CODE

/* code for predicate 'getopt__lookup_string_option'/3 in mode 0 */
Define_entry(mercury__getopt__lookup_string_option_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	incr_sp_push_msg(1, "getopt__lookup_string_option");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__getopt__lookup_string_option_3_0_i4,
		ENTRY(mercury__getopt__lookup_string_option_3_0));
	}
Define_label(mercury__getopt__lookup_string_option_3_0_i4);
	update_prof_current_proc(LABEL(mercury__getopt__lookup_string_option_3_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__getopt__lookup_string_option_3_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury__getopt__lookup_string_option_3_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__getopt__lookup_string_option_3_0_i3);
	r1 = string_const("Expected string option and didn't get one.", 42);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__getopt__lookup_string_option_3_0));
	}
Define_label(mercury__getopt__lookup_string_option_3_0_i1000);
	r1 = string_const("Expected string option and didn't get one.", 42);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__getopt__lookup_string_option_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module13)
	init_entry(mercury__getopt__process_arguments_5_0);
	init_label(mercury__getopt__process_arguments_5_0_i4);
	init_label(mercury__getopt__process_arguments_5_0_i9);
	init_label(mercury__getopt__process_arguments_5_0_i11);
	init_label(mercury__getopt__process_arguments_5_0_i14);
	init_label(mercury__getopt__process_arguments_5_0_i16);
	init_label(mercury__getopt__process_arguments_5_0_i17);
	init_label(mercury__getopt__process_arguments_5_0_i18);
	init_label(mercury__getopt__process_arguments_5_0_i1030);
	init_label(mercury__getopt__process_arguments_5_0_i23);
	init_label(mercury__getopt__process_arguments_5_0_i8);
	init_label(mercury__getopt__process_arguments_5_0_i27);
	init_label(mercury__getopt__process_arguments_5_0_i29);
	init_label(mercury__getopt__process_arguments_5_0_i32);
	init_label(mercury__getopt__process_arguments_5_0_i34);
	init_label(mercury__getopt__process_arguments_5_0_i37);
	init_label(mercury__getopt__process_arguments_5_0_i36);
	init_label(mercury__getopt__process_arguments_5_0_i39);
	init_label(mercury__getopt__process_arguments_5_0_i31);
	init_label(mercury__getopt__process_arguments_5_0_i41);
	init_label(mercury__getopt__process_arguments_5_0_i44);
	init_label(mercury__getopt__process_arguments_5_0_i48);
	init_label(mercury__getopt__process_arguments_5_0_i1039);
	init_label(mercury__getopt__process_arguments_5_0_i43);
	init_label(mercury__getopt__process_arguments_5_0_i53);
	init_label(mercury__getopt__process_arguments_5_0_i26);
	init_label(mercury__getopt__process_arguments_5_0_i58);
	init_label(mercury__getopt__process_arguments_5_0_i60);
	init_label(mercury__getopt__process_arguments_5_0_i67);
	init_label(mercury__getopt__process_arguments_5_0_i70);
	init_label(mercury__getopt__process_arguments_5_0_i72);
	init_label(mercury__getopt__process_arguments_5_0_i1049);
	init_label(mercury__getopt__process_arguments_5_0_i61);
	init_label(mercury__getopt__process_arguments_5_0_i81);
	init_label(mercury__getopt__process_arguments_5_0_i82);
	init_label(mercury__getopt__process_arguments_5_0_i57);
	init_label(mercury__getopt__process_arguments_5_0_i88);
	init_label(mercury__getopt__process_arguments_5_0_i1050);
BEGIN_CODE

/* code for predicate 'getopt__process_arguments'/5 in mode 0 */
Define_static(mercury__getopt__process_arguments_5_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i1050);
	r5 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r6 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	incr_sp_push_msg(11, "getopt__process_arguments");
	detstackvar(11) = (Integer) succip;
	if ((strcmp((char *)(Integer) r6, (char *)string_const("--", 2)) !=0))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i4);
	r1 = (Integer) r5;
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__getopt__process_arguments_5_0_i4);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r5;
	detstackvar(10) = (Integer) r1;
	r1 = string_const("--no-", 5);
	r2 = (Integer) r6;
	{
	Declare_entry(mercury__string__append_3_1);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__getopt__process_arguments_5_0_i9,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i9);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i8);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__getopt__get_long_options__ua10000_2_0),
		mercury__getopt__process_arguments_5_0_i11,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i11);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r4 = (Integer) detstackvar(5);
	r2 = ((Integer) 1);
	r3 = ((Integer) 1);
	{
	Declare_entry(do_call_semidet_closure);
	call_localret(ENTRY(do_call_semidet_closure),
		mercury__getopt__process_arguments_5_0_i14,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i14);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i1030);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r3;
	r1 = string_const("--", 2);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__getopt__process_arguments_5_0_i16,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i16);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__getopt__process_negated_bool_option_5_0),
		mercury__getopt__process_arguments_5_0_i17,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i17);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i18);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__getopt__process_arguments_5_0,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i18);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__getopt__process_arguments_5_0_i1030);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unrecognized option `", 21);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_arguments_5_0_i23,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i23);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__getopt__process_arguments_5_0_i8);
	r1 = string_const("--", 2);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__append_3_1);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__getopt__process_arguments_5_0_i27,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i27);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i26);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__getopt__get_long_options__ua10000_2_0),
		mercury__getopt__process_arguments_5_0_i29,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i29);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = string_const("=", 1);
	{
	Declare_entry(mercury__string__sub_string_search_3_0);
	call_localret(ENTRY(mercury__string__sub_string_search_3_0),
		mercury__getopt__process_arguments_5_0_i32,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i32);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i31);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__string__split_4_0);
	call_localret(ENTRY(mercury__string__split_4_0),
		mercury__getopt__process_arguments_5_0_i34,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i34);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = ((Integer) 61);
	{
	Declare_entry(mercury__string__first_char_3_2);
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__getopt__process_arguments_5_0_i37,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i37);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i36);
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	tag_incr_hp(r6, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r6, ((Integer) 0)) = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__getopt__process_arguments_5_0_i41);
Define_label(mercury__getopt__process_arguments_5_0_i36);
	r1 = string_const("bad split of --longoption=arg", 29);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__getopt__process_arguments_5_0_i39,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i39);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) detstackvar(6);
	r1 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	GOTO_LABEL(mercury__getopt__process_arguments_5_0_i41);
Define_label(mercury__getopt__process_arguments_5_0_i31);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r6 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r1 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
Define_label(mercury__getopt__process_arguments_5_0_i41);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r6;
	detstackvar(10) = (Integer) r8;
	r4 = (Integer) r1;
	r1 = (Integer) r7;
	r2 = ((Integer) 1);
	r3 = ((Integer) 1);
	{
	Declare_entry(do_call_semidet_closure);
	call_localret(ENTRY(do_call_semidet_closure),
		mercury__getopt__process_arguments_5_0_i44,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i44);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i43);
	r4 = (Integer) r2;
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__getopt__process_arguments_5_0_i48,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i48);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i1039);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(7);
	r5 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(4);
	r7 = (Integer) detstackvar(1);
	r8 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	tailcall(STATIC(mercury__getopt__handle_long_option_9_0),
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i1039);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unknown type for option `", 25);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_arguments_5_0_i23,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i43);
	r1 = string_const("unrecognized option `", 21);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__getopt__process_arguments_5_0_i53,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i53);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r2 = string_const("'", 1);
	{
	Declare_entry(mercury__string__append_3_2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__getopt__process_arguments_5_0_i23,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i26);
	r1 = (Integer) detstackvar(3);
	r2 = ((Integer) 45);
	{
	Declare_entry(mercury__string__first_char_3_2);
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__getopt__process_arguments_5_0_i58,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i58);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i57);
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__to_char_list_2_0);
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__getopt__process_arguments_5_0_i60,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i60);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i61);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i61);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 0)) != ((Integer) 45)))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i61);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i61);
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__getopt__get_short_options__ua10000_2_0),
		mercury__getopt__process_arguments_5_0_i67,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i67);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r4 = (Integer) detstackvar(6);
	r2 = ((Integer) 1);
	r3 = ((Integer) 1);
	{
	Declare_entry(do_call_semidet_closure);
	call_localret(ENTRY(do_call_semidet_closure),
		mercury__getopt__process_arguments_5_0_i70,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i70);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i1049);
	r3 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r2;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = ((Integer) 45);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	{
	Declare_entry(mercury__string__from_char_list_2_0);
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__getopt__process_arguments_5_0_i72,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i72);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__getopt__process_negated_bool_option_5_0),
		mercury__getopt__process_arguments_5_0_i17,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i1049);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unrecognized option `-", 22);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(5);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_arguments_5_0_i23,
		STATIC(mercury__getopt__process_arguments_5_0));
	}
Define_label(mercury__getopt__process_arguments_5_0_i61);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__getopt__handle_short_options_6_0),
		mercury__getopt__process_arguments_5_0_i81,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i81);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__process_arguments_5_0_i82);
	r4 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	localtailcall(mercury__getopt__process_arguments_5_0,
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i82);
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__getopt__process_arguments_5_0_i57);
	r1 = (Integer) detstackvar(10);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__getopt__process_arguments_5_0,
		LABEL(mercury__getopt__process_arguments_5_0_i88),
		STATIC(mercury__getopt__process_arguments_5_0));
Define_label(mercury__getopt__process_arguments_5_0_i88);
	update_prof_current_proc(LABEL(mercury__getopt__process_arguments_5_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__getopt__process_arguments_5_0_i1050);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module14)
	init_entry(mercury__getopt__handle_long_option_9_0);
	init_label(mercury__getopt__handle_long_option_9_0_i4);
	init_label(mercury__getopt__handle_long_option_9_0_i6);
	init_label(mercury__getopt__handle_long_option_9_0_i3);
	init_label(mercury__getopt__handle_long_option_9_0_i10);
	init_label(mercury__getopt__handle_long_option_9_0_i14);
	init_label(mercury__getopt__handle_long_option_9_0_i11);
	init_label(mercury__getopt__handle_long_option_9_0_i15);
	init_label(mercury__getopt__handle_long_option_9_0_i16);
BEGIN_CODE

/* code for predicate 'getopt__handle_long_option'/9 in mode 0 */
Define_static(mercury__getopt__handle_long_option_9_0);
	incr_sp_push_msg(10, "getopt__handle_long_option");
	detstackvar(10) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r6;
	detstackvar(7) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r1;
	r1 = (Integer) r4;
	call_localret(STATIC(mercury__getopt__need_arg_2_0),
		mercury__getopt__handle_long_option_9_0_i4,
		STATIC(mercury__getopt__handle_long_option_9_0));
Define_label(mercury__getopt__handle_long_option_9_0_i4);
	update_prof_current_proc(LABEL(mercury__getopt__handle_long_option_9_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i3);
	if (((Integer) detstackvar(4) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i3);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(5);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i6);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	r8 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) tempr1;
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r9 = ((Integer) 1);
	r10 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i10);
	}
Define_label(mercury__getopt__handle_long_option_9_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r8 = (Integer) r4;
	r9 = ((Integer) 0);
	r10 = (Integer) detstackvar(9);
	GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i10);
Define_label(mercury__getopt__handle_long_option_9_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) r4;
	r9 = ((Integer) 1);
	r10 = (Integer) detstackvar(9);
Define_label(mercury__getopt__handle_long_option_9_0_i10);
	if (((Integer) r9 != ((Integer) 0)))
		GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i11);
	detstackvar(6) = (Integer) r4;
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("option `", 8);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__handle_long_option_9_0_i14,
		STATIC(mercury__getopt__handle_long_option_9_0));
	}
Define_label(mercury__getopt__handle_long_option_9_0_i14);
	update_prof_current_proc(LABEL(mercury__getopt__handle_long_option_9_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__getopt__handle_long_option_9_0_i11);
	r4 = (Integer) r2;
	r2 = (Integer) r3;
	detstackvar(7) = (Integer) r5;
	r5 = (Integer) r7;
	r7 = (Integer) r6;
	r6 = (Integer) detstackvar(7);
	r3 = (Integer) r1;
	r1 = (Integer) r10;
	detstackvar(6) = (Integer) r8;
	detstackvar(9) = (Integer) r10;
	call_localret(STATIC(mercury__getopt__process_option_7_0),
		mercury__getopt__handle_long_option_9_0_i15,
		STATIC(mercury__getopt__handle_long_option_9_0));
Define_label(mercury__getopt__handle_long_option_9_0_i15);
	update_prof_current_proc(LABEL(mercury__getopt__handle_long_option_9_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__handle_long_option_9_0_i16);
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(9);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(7);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__getopt__process_arguments_5_0),
		STATIC(mercury__getopt__handle_long_option_9_0));
Define_label(mercury__getopt__handle_long_option_9_0_i16);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(10);
	decr_sp_pop_msg(10);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module15)
	init_entry(mercury__getopt__handle_short_options_6_0);
	init_label(mercury__getopt__handle_short_options_6_0_i1001);
	init_label(mercury__getopt__handle_short_options_6_0_i4);
	init_label(mercury__getopt__handle_short_options_6_0_i8);
	init_label(mercury__getopt__handle_short_options_6_0_i12);
	init_label(mercury__getopt__handle_short_options_6_0_i16);
	init_label(mercury__getopt__handle_short_options_6_0_i17);
	init_label(mercury__getopt__handle_short_options_6_0_i21);
	init_label(mercury__getopt__handle_short_options_6_0_i15);
	init_label(mercury__getopt__handle_short_options_6_0_i23);
	init_label(mercury__getopt__handle_short_options_6_0_i24);
	init_label(mercury__getopt__handle_short_options_6_0_i25);
	init_label(mercury__getopt__handle_short_options_6_0_i26);
	init_label(mercury__getopt__handle_short_options_6_0_i11);
	init_label(mercury__getopt__handle_short_options_6_0_i31);
	init_label(mercury__getopt__handle_short_options_6_0_i32);
	init_label(mercury__getopt__handle_short_options_6_0_i7);
	init_label(mercury__getopt__handle_short_options_6_0_i34);
	init_label(mercury__getopt__handle_short_options_6_0_i1000);
BEGIN_CODE

/* code for predicate 'getopt__handle_short_options'/6 in mode 0 */
Define_static(mercury__getopt__handle_short_options_6_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i1000);
	if ((tag((Integer) r3) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i1001);
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r6 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	incr_sp_push_msg(12, "getopt__handle_short_options");
	detstackvar(12) = (Integer) succip;
	GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i4);
	}
Define_label(mercury__getopt__handle_short_options_6_0_i1001);
	incr_sp_push_msg(12, "getopt__handle_short_options");
	detstackvar(12) = (Integer) succip;
	r7 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r6 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	r5 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i4);
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r5;
	detstackvar(11) = (Integer) r7;
	r4 = (Integer) r1;
	r1 = (Integer) r6;
	r2 = ((Integer) 1);
	r3 = ((Integer) 1);
	{
	Declare_entry(do_call_semidet_closure);
	call_localret(ENTRY(do_call_semidet_closure),
		mercury__getopt__handle_short_options_6_0_i8,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i8);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i7);
	r4 = (Integer) r2;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__getopt__handle_short_options_6_0_i12,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i12);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i11);
	detstackvar(7) = (Integer) r2;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__getopt__need_arg_2_0),
		mercury__getopt__handle_short_options_6_0_i16,
		STATIC(mercury__getopt__handle_short_options_6_0));
Define_label(mercury__getopt__handle_short_options_6_0_i16);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	if ((((Integer) 0) != (Integer) r1))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i15);
	if (((Integer) detstackvar(5) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i17);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i17);
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	r6 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = ((Integer) 45);
	r9 = (Integer) detstackvar(11);
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i23);
	}
Define_label(mercury__getopt__handle_short_options_6_0_i17);
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__string__from_char_list_2_0);
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__getopt__handle_short_options_6_0_i21,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i21);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(2);
	r8 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tag_incr_hp(r7, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r7, ((Integer) 0)) = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = ((Integer) 45);
	r9 = (Integer) detstackvar(11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i23);
	}
Define_label(mercury__getopt__handle_short_options_6_0_i15);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(2);
	r7 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r8 = (Integer) detstackvar(5);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = ((Integer) 45);
	r9 = (Integer) detstackvar(11);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) tempr1;
	}
Define_label(mercury__getopt__handle_short_options_6_0_i23);
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(6) = (Integer) r4;
	detstackvar(7) = (Integer) r5;
	detstackvar(8) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(11) = (Integer) r9;
	{
	Declare_entry(mercury__string__from_char_list_2_0);
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__getopt__handle_short_options_6_0_i24,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i24);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(7);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(1);
	r7 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__getopt__process_option_7_0),
		mercury__getopt__handle_short_options_6_0_i25,
		STATIC(mercury__getopt__handle_short_options_6_0));
Define_label(mercury__getopt__handle_short_options_6_0_i25);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__handle_short_options_6_0_i26);
	r5 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) detstackvar(11);
	r2 = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	localtailcall(mercury__getopt__handle_short_options_6_0,
		STATIC(mercury__getopt__handle_short_options_6_0));
Define_label(mercury__getopt__handle_short_options_6_0_i26);
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__getopt__handle_short_options_6_0_i11);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__string__char_to_string_2_0);
	call_localret(ENTRY(mercury__string__char_to_string_2_0),
		mercury__getopt__handle_short_options_6_0_i31,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i31);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unknown type for option `-", 26);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__handle_short_options_6_0_i32,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i32);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(12);
	decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__getopt__handle_short_options_6_0_i7);
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__string__char_to_string_2_0);
	call_localret(ENTRY(mercury__string__char_to_string_2_0),
		mercury__getopt__handle_short_options_6_0_i34,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i34);
	update_prof_current_proc(LABEL(mercury__getopt__handle_short_options_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unrecognized option `-", 22);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__handle_short_options_6_0_i32,
		STATIC(mercury__getopt__handle_short_options_6_0));
	}
Define_label(mercury__getopt__handle_short_options_6_0_i1000);
	r1 = (Integer) r4;
	tag_incr_hp(r2, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module16)
	init_entry(mercury__getopt__process_option_7_0);
	init_label(mercury__getopt__process_option_7_0_i1008);
	init_label(mercury__getopt__process_option_7_0_i12);
	init_label(mercury__getopt__process_option_7_0_i25);
	init_label(mercury__getopt__process_option_7_0_i24);
	init_label(mercury__getopt__process_option_7_0_i20);
	init_label(mercury__getopt__process_option_7_0_i19);
	init_label(mercury__getopt__process_option_7_0_i32);
	init_label(mercury__getopt__process_option_7_0_i1007);
	init_label(mercury__getopt__process_option_7_0_i43);
	init_label(mercury__getopt__process_option_7_0_i40);
	init_label(mercury__getopt__process_option_7_0_i39);
	init_label(mercury__getopt__process_option_7_0_i49);
	init_label(mercury__getopt__process_option_7_0_i46);
	init_label(mercury__getopt__process_option_7_0_i38);
	init_label(mercury__getopt__process_option_7_0_i54);
	init_label(mercury__getopt__process_option_7_0_i53);
	init_label(mercury__getopt__process_option_7_0_i65);
	init_label(mercury__getopt__process_option_7_0_i64);
	init_label(mercury__getopt__process_option_7_0_i60);
	init_label(mercury__getopt__process_option_7_0_i1000);
	init_label(mercury__getopt__process_option_7_0_i1001);
BEGIN_CODE

/* code for predicate 'getopt__process_option'/7 in mode 0 */
Define_static(mercury__getopt__process_option_7_0);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i1007);
	r8 = unmkbody((Integer) r2);
	if (((Integer) r8 != ((Integer) 0)))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i1008);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i1000);
	r1 = string_const("no special argument expected in getopt__process_option", 54);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i1008);
	incr_sp_push_msg(6, "getopt__process_option");
	detstackvar(6) = (Integer) succip;
	if (((Integer) r8 != ((Integer) 1)))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i12);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i1001);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_5);
	r4 = (Integer) r6;
	r5 = (Integer) r7;
	tailcall(STATIC(mercury__getopt__process_special__ua10000_6_0),
		STATIC(mercury__getopt__process_option_7_0));
Define_label(mercury__getopt__process_option_7_0_i12);
	if (((Integer) r8 != ((Integer) 2)))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i19);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i20);
	r1 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r6;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__string__to_int_2_0);
	call_localret(ENTRY(mercury__string__to_int_2_0),
		mercury__getopt__process_option_7_0_i25,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i25);
	update_prof_current_proc(LABEL(mercury__getopt__process_option_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i24);
	tag_incr_hp(r3, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__getopt__process_special__ua10000_6_0),
		STATIC(mercury__getopt__process_option_7_0));
Define_label(mercury__getopt__process_option_7_0_i24);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__getopt__numeric_argument__ua10000_3_0),
		STATIC(mercury__getopt__process_option_7_0));
Define_label(mercury__getopt__process_option_7_0_i20);
	r1 = string_const("int_special argument expected in getopt__process_option", 55);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i19);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i32);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tag_incr_hp(r3, mktag(3), ((Integer) 1));
	field(mktag(3), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	r4 = (Integer) r6;
	r5 = (Integer) r7;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__getopt__process_special__ua10000_6_0),
		STATIC(mercury__getopt__process_option_7_0));
Define_label(mercury__getopt__process_option_7_0_i32);
	r1 = string_const("string_special argument expected in getopt__process_option", 58);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i1007);
	incr_sp_push_msg(6, "getopt__process_option");
	detstackvar(6) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i38);
	r8 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 0));
	if (((Integer) r8 != ((Integer) 0)))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i39);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i40);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) r7;
	r6 = (Integer) r5;
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 0);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r6, ((Integer) 0));
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__getopt__process_option_7_0_i43,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i43);
	update_prof_current_proc(LABEL(mercury__getopt__process_option_7_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__getopt__process_option_7_0_i40);
	r1 = string_const("string argument expected in getopt__process_option", 50);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i39);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i46);
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r7;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_string_0;
	r2 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__list__append_3_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__getopt__process_option_7_0_i49,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i49);
	update_prof_current_proc(LABEL(mercury__getopt__process_option_7_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(3), ((Integer) 2));
	field(mktag(3), (Integer) r5, ((Integer) 0)) = ((Integer) 1);
	field(mktag(3), (Integer) r5, ((Integer) 1)) = (Integer) r6;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__getopt__process_option_7_0_i43,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i46);
	r1 = string_const("acumulating argument expected in getopt__process_option", 55);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i38);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i53);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i54);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) r7;
	r5 = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__getopt__process_option_7_0_i43,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i54);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) r7;
	r5 = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_6);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__getopt__process_option_7_0_i43,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i53);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i60);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	detstackvar(3) = (Integer) r1;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(4) = (Integer) r7;
	{
	Declare_entry(mercury__string__to_int_2_0);
	call_localret(ENTRY(mercury__string__to_int_2_0),
		mercury__getopt__process_option_7_0_i65,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i65);
	update_prof_current_proc(LABEL(mercury__getopt__process_option_7_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_option_7_0_i64);
	r6 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(2), ((Integer) 1));
	field(mktag(2), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__getopt__process_option_7_0_i43,
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i64);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__getopt__numeric_argument__ua10000_3_0),
		STATIC(mercury__getopt__process_option_7_0));
Define_label(mercury__getopt__process_option_7_0_i60);
	r1 = string_const("integer argument expected in getopt__process_option", 51);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__getopt__process_option_7_0));
	}
Define_label(mercury__getopt__process_option_7_0_i1000);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r4 = (Integer) r6;
	r5 = (Integer) r7;
	tailcall(STATIC(mercury__getopt__process_special__ua10000_6_0),
		STATIC(mercury__getopt__process_option_7_0));
Define_label(mercury__getopt__process_option_7_0_i1001);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_6);
	r4 = (Integer) r6;
	r5 = (Integer) r7;
	tailcall(STATIC(mercury__getopt__process_special__ua10000_6_0),
		STATIC(mercury__getopt__process_option_7_0));
END_MODULE

BEGIN_MODULE(mercury__getopt_module17)
	init_entry(mercury__getopt__process_negated_bool_option_5_0);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i4);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i9);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i6);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i1010);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i14);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i1013);
	init_label(mercury__getopt__process_negated_bool_option_5_0_i17);
BEGIN_CODE

/* code for predicate 'process_negated_bool_option'/5 in mode 0 */
Define_static(mercury__getopt__process_negated_bool_option_5_0);
	incr_sp_push_msg(6, "process_negated_bool_option");
	detstackvar(6) = (Integer) succip;
	detstackvar(3) = (Integer) r4;
	r4 = (Integer) r3;
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) r5;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__getopt__process_negated_bool_option_5_0_i4,
		STATIC(mercury__getopt__process_negated_bool_option_5_0));
	}
Define_label(mercury__getopt__process_negated_bool_option_5_0_i4);
	update_prof_current_proc(LABEL(mercury__getopt__process_negated_bool_option_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__getopt__process_negated_bool_option_5_0_i1013);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__getopt__process_negated_bool_option_5_0_i6);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_5);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__getopt__process_negated_bool_option_5_0_i9,
		STATIC(mercury__getopt__process_negated_bool_option_5_0));
	}
Define_label(mercury__getopt__process_negated_bool_option_5_0_i9);
	update_prof_current_proc(LABEL(mercury__getopt__process_negated_bool_option_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__getopt__process_negated_bool_option_5_0_i6);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury__getopt__process_negated_bool_option_5_0_i1010);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_5);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__getopt__process_special__ua10000_6_0),
		STATIC(mercury__getopt__process_negated_bool_option_5_0));
Define_label(mercury__getopt__process_negated_bool_option_5_0_i1010);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("cannot negate option `", 22);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_7);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_negated_bool_option_5_0_i14,
		STATIC(mercury__getopt__process_negated_bool_option_5_0));
	}
Define_label(mercury__getopt__process_negated_bool_option_5_0_i14);
	update_prof_current_proc(LABEL(mercury__getopt__process_negated_bool_option_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__getopt__process_negated_bool_option_5_0_i1013);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = string_const("unknown type for option `", 25);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(1), (Integer) mercury_data_getopt__common_3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	{
	Declare_entry(mercury__string__append_list_2_0);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__getopt__process_negated_bool_option_5_0_i17,
		STATIC(mercury__getopt__process_negated_bool_option_5_0));
	}
Define_label(mercury__getopt__process_negated_bool_option_5_0_i17);
	update_prof_current_proc(LABEL(mercury__getopt__process_negated_bool_option_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 1));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module18)
	init_entry(mercury__getopt__need_arg_2_0);
	init_label(mercury__getopt__need_arg_2_0_i5);
	init_label(mercury__getopt__need_arg_2_0_i6);
	init_label(mercury__getopt__need_arg_2_0_i7);
	init_label(mercury__getopt__need_arg_2_0_i4);
	init_label(mercury__getopt__need_arg_2_0_i8);
	init_label(mercury__getopt__need_arg_2_0_i10);
BEGIN_CODE

/* code for predicate 'getopt__need_arg'/2 in mode 0 */
Define_static(mercury__getopt__need_arg_2_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i4);
	r2 = unmkbody((Integer) r1);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__getopt__need_arg_2_0_i5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i6);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__getopt__need_arg_2_0_i6);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__getopt__need_arg_2_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__getopt__need_arg_2_0_i4);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i8);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i7);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__getopt__need_arg_2_0_i8);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__getopt__need_arg_2_0_i10);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__getopt__need_arg_2_0_i10);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module19)
	init_entry(mercury____Unify___getopt__option_ops_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___getopt__option_ops_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Unify___getopt_option_ops_1__ua0_2_0),
		ENTRY(mercury____Unify___getopt__option_ops_1_0));
END_MODULE

BEGIN_MODULE(mercury__getopt_module20)
	init_entry(mercury____Index___getopt__option_ops_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___getopt__option_ops_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury____Index___getopt_option_ops_1__ua10000_2_0),
		ENTRY(mercury____Index___getopt__option_ops_1_0));
END_MODULE

BEGIN_MODULE(mercury__getopt_module21)
	init_entry(mercury____Compare___getopt__option_ops_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___getopt__option_ops_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Compare___getopt_option_ops_1__ua10000_3_0),
		ENTRY(mercury____Compare___getopt__option_ops_1_0));
END_MODULE

BEGIN_MODULE(mercury__getopt_module22)
	init_entry(mercury____Unify___getopt__option_data_0_0);
	init_label(mercury____Unify___getopt__option_data_0_0_i1027);
	init_label(mercury____Unify___getopt__option_data_0_0_i7);
	init_label(mercury____Unify___getopt__option_data_0_0_i9);
	init_label(mercury____Unify___getopt__option_data_0_0_i1026);
	init_label(mercury____Unify___getopt__option_data_0_0_i13);
	init_label(mercury____Unify___getopt__option_data_0_0_i12);
	init_label(mercury____Unify___getopt__option_data_0_0_i18);
	init_label(mercury____Unify___getopt__option_data_0_0_i1022);
	init_label(mercury____Unify___getopt__option_data_0_0_i1);
	init_label(mercury____Unify___getopt__option_data_0_0_i1024);
	init_label(mercury____Unify___getopt__option_data_0_0_i1025);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___getopt__option_data_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1026);
	r3 = unmkbody((Integer) r1);
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1027);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1022);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i1027);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i7);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1024);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i7);
	if (((Integer) r3 != ((Integer) 2)))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1024);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1024);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i1026);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if (((Integer) r3 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i12);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r3 != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i13);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 1)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 1))) !=0))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1025);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i13);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1025);
	r3 = (Integer) field(mktag(3), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury____Unify___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Unify___mercury_builtin__list_1_0),
		ENTRY(mercury____Unify___getopt__option_data_0_0));
	}
Define_label(mercury____Unify___getopt__option_data_0_0_i12);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i18);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1025);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i18);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__option_data_0_0_i1025);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i1022);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i1024);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__option_data_0_0_i1025);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module23)
	init_entry(mercury____Index___getopt__option_data_0_0);
	init_label(mercury____Index___getopt__option_data_0_0_i5);
	init_label(mercury____Index___getopt__option_data_0_0_i6);
	init_label(mercury____Index___getopt__option_data_0_0_i7);
	init_label(mercury____Index___getopt__option_data_0_0_i4);
	init_label(mercury____Index___getopt__option_data_0_0_i9);
	init_label(mercury____Index___getopt__option_data_0_0_i8);
	init_label(mercury____Index___getopt__option_data_0_0_i10);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___getopt__option_data_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i4);
	r2 = unmkbody((Integer) r1);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i5);
	r1 = ((Integer) 4);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i5);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i6);
	r1 = ((Integer) 5);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i6);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i7);
	r1 = ((Integer) 6);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i7);
	r1 = ((Integer) 7);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i8);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i9);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i9);
	r1 = ((Integer) 3);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i8);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___getopt__option_data_0_0_i10);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___getopt__option_data_0_0_i10);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module24)
	init_entry(mercury____Compare___getopt__option_data_0_0);
	init_label(mercury____Compare___getopt__option_data_0_0_i2);
	init_label(mercury____Compare___getopt__option_data_0_0_i3);
	init_label(mercury____Compare___getopt__option_data_0_0_i4);
	init_label(mercury____Compare___getopt__option_data_0_0_i6);
	init_label(mercury____Compare___getopt__option_data_0_0_i13);
	init_label(mercury____Compare___getopt__option_data_0_0_i15);
	init_label(mercury____Compare___getopt__option_data_0_0_i17);
	init_label(mercury____Compare___getopt__option_data_0_0_i12);
	init_label(mercury____Compare___getopt__option_data_0_0_i21);
	init_label(mercury____Compare___getopt__option_data_0_0_i20);
	init_label(mercury____Compare___getopt__option_data_0_0_i26);
	init_label(mercury____Compare___getopt__option_data_0_0_i9);
	init_label(mercury____Compare___getopt__option_data_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___getopt__option_data_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___getopt__option_data_0_0),
		mercury____Compare___getopt__option_data_0_0_i2,
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___getopt__option_data_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___getopt__option_data_0_0),
		mercury____Compare___getopt__option_data_0_0_i3,
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___getopt__option_data_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__option_data_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__option_data_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i12);
	r2 = unmkbody((Integer) r1);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i13);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__option_data_0_0_i13);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i15);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 1)))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__option_data_0_0_i15);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i17);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 2)))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__option_data_0_0_i17);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 3)))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__option_data_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i20);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i21);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (((Integer) field(mktag(3), (Integer) r3, ((Integer) 0)) != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i21);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if (((Integer) field(mktag(3), (Integer) tempr1, ((Integer) 0)) != ((Integer) 1)))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i1000);
	r2 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(3), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_string_0;
	{
	Declare_entry(mercury____Compare___mercury_builtin__list_1_0);
	tailcall(ENTRY(mercury____Compare___mercury_builtin__list_1_0),
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i20);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i26);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i26);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___getopt__option_data_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
Define_label(mercury____Compare___getopt__option_data_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___getopt__option_data_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module25)
	init_entry(mercury____Unify___getopt__special_data_0_0);
	init_label(mercury____Unify___getopt__special_data_0_0_i4);
	init_label(mercury____Unify___getopt__special_data_0_0_i6);
	init_label(mercury____Unify___getopt__special_data_0_0_i8);
	init_label(mercury____Unify___getopt__special_data_0_0_i2);
	init_label(mercury____Unify___getopt__special_data_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___getopt__special_data_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i4);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt__special_data_0_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__special_data_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__special_data_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(3), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(3), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___getopt__special_data_0_0_i1);
Define_label(mercury____Unify___getopt__special_data_0_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__special_data_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module26)
	init_entry(mercury____Index___getopt__special_data_0_0);
	init_label(mercury____Index___getopt__special_data_0_0_i4);
	init_label(mercury____Index___getopt__special_data_0_0_i5);
	init_label(mercury____Index___getopt__special_data_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___getopt__special_data_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___getopt__special_data_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___getopt__special_data_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___getopt__special_data_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___getopt__special_data_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___getopt__special_data_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___getopt__special_data_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module27)
	init_entry(mercury____Compare___getopt__special_data_0_0);
	init_label(mercury____Compare___getopt__special_data_0_0_i2);
	init_label(mercury____Compare___getopt__special_data_0_0_i3);
	init_label(mercury____Compare___getopt__special_data_0_0_i4);
	init_label(mercury____Compare___getopt__special_data_0_0_i6);
	init_label(mercury____Compare___getopt__special_data_0_0_i12);
	init_label(mercury____Compare___getopt__special_data_0_0_i14);
	init_label(mercury____Compare___getopt__special_data_0_0_i17);
	init_label(mercury____Compare___getopt__special_data_0_0_i9);
	init_label(mercury____Compare___getopt__special_data_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___getopt__special_data_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___getopt__special_data_0_0),
		mercury____Compare___getopt__special_data_0_0_i2,
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
Define_label(mercury____Compare___getopt__special_data_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___getopt__special_data_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___getopt__special_data_0_0),
		mercury____Compare___getopt__special_data_0_0_i3,
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
Define_label(mercury____Compare___getopt__special_data_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___getopt__special_data_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__special_data_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__special_data_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i12);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___getopt__special_data_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i14);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
Define_label(mercury____Compare___getopt__special_data_0_0_i14);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i17);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
Define_label(mercury____Compare___getopt__special_data_0_0_i17);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___getopt__special_data_0_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
Define_label(mercury____Compare___getopt__special_data_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
Define_label(mercury____Compare___getopt__special_data_0_0_i1000);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___getopt__special_data_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module28)
	init_entry(mercury____Unify___getopt__option_table_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___getopt__option_table_1_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___getopt__option_table_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module29)
	init_entry(mercury____Index___getopt__option_table_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___getopt__option_table_1_0);
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Index___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___getopt__option_table_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module30)
	init_entry(mercury____Compare___getopt__option_table_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___getopt__option_table_1_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___getopt__option_table_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__getopt_module31)
	init_entry(mercury____Unify___getopt__maybe_option_table_1_0);
	init_label(mercury____Unify___getopt__maybe_option_table_1_0_i1008);
	init_label(mercury____Unify___getopt__maybe_option_table_1_0_i1005);
	init_label(mercury____Unify___getopt__maybe_option_table_1_0_i1);
	init_label(mercury____Unify___getopt__maybe_option_table_1_0_i1007);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___getopt__maybe_option_table_1_0);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__maybe_option_table_1_0_i1008);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___getopt__maybe_option_table_1_0_i1005);
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___getopt__maybe_option_table_1_0));
	}
Define_label(mercury____Unify___getopt__maybe_option_table_1_0_i1008);
	incr_sp_push_msg(1, "__Unify__");
	detstackvar(1) = (Integer) succip;
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___getopt__maybe_option_table_1_0_i1);
	decr_sp_pop_msg(1);
	if ((strcmp((char *)(Integer) field(mktag(1), (Integer) r2, ((Integer) 0)), (char *)(Integer) field(mktag(1), (Integer) r3, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___getopt__maybe_option_table_1_0_i1007);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___getopt__maybe_option_table_1_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___getopt__maybe_option_table_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury____Unify___getopt__maybe_option_table_1_0_i1007);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__getopt_module32)
	init_entry(mercury____Index___getopt__maybe_option_table_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___getopt__maybe_option_table_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0),
		ENTRY(mercury____Index___getopt__maybe_option_table_1_0));
END_MODULE

BEGIN_MODULE(mercury__getopt_module33)
	init_entry(mercury____Compare___getopt__maybe_option_table_1_0);
	init_label(mercury____Compare___getopt__maybe_option_table_1_0_i2);
	init_label(mercury____Compare___getopt__maybe_option_table_1_0_i3);
	init_label(mercury____Compare___getopt__maybe_option_table_1_0_i4);
	init_label(mercury____Compare___getopt__maybe_option_table_1_0_i6);
	init_label(mercury____Compare___getopt__maybe_option_table_1_0_i11);
	init_label(mercury____Compare___getopt__maybe_option_table_1_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___getopt__maybe_option_table_1_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0),
		mercury____Compare___getopt__maybe_option_table_1_0_i2,
		ENTRY(mercury____Compare___getopt__maybe_option_table_1_0));
Define_label(mercury____Compare___getopt__maybe_option_table_1_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___getopt__maybe_option_table_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury____Index___getopt_maybe_option_table_1__ua10000_2_0),
		mercury____Compare___getopt__maybe_option_table_1_0_i3,
		ENTRY(mercury____Compare___getopt__maybe_option_table_1_0));
Define_label(mercury____Compare___getopt__maybe_option_table_1_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___getopt__maybe_option_table_1_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt__maybe_option_table_1_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___getopt__maybe_option_table_1_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___getopt__maybe_option_table_1_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___getopt__maybe_option_table_1_0_i6);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(1);
	if ((tag((Integer) tempr1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___getopt__maybe_option_table_1_0_i11);
	tempr2 = (Integer) detstackvar(2);
	if ((tag((Integer) tempr2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___getopt__maybe_option_table_1_0_i9);
	r4 = (Integer) field(mktag(0), (Integer) tempr2, ((Integer) 0));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) mercury_data_getopt__base_type_info_option_data_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___getopt__maybe_option_table_1_0));
	}
	}
Define_label(mercury____Compare___getopt__maybe_option_table_1_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___getopt__maybe_option_table_1_0_i9);
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__builtin_compare_string_3_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___getopt__maybe_option_table_1_0));
	}
Define_label(mercury____Compare___getopt__maybe_option_table_1_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___getopt__maybe_option_table_1_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__getopt_bunch_0(void)
{
	mercury__getopt_module0();
	mercury__getopt_module1();
	mercury__getopt_module2();
	mercury__getopt_module3();
	mercury__getopt_module4();
	mercury__getopt_module5();
	mercury__getopt_module6();
	mercury__getopt_module7();
	mercury__getopt_module8();
	mercury__getopt_module9();
	mercury__getopt_module10();
	mercury__getopt_module11();
	mercury__getopt_module12();
	mercury__getopt_module13();
	mercury__getopt_module14();
	mercury__getopt_module15();
	mercury__getopt_module16();
	mercury__getopt_module17();
	mercury__getopt_module18();
	mercury__getopt_module19();
	mercury__getopt_module20();
	mercury__getopt_module21();
	mercury__getopt_module22();
	mercury__getopt_module23();
	mercury__getopt_module24();
	mercury__getopt_module25();
	mercury__getopt_module26();
	mercury__getopt_module27();
	mercury__getopt_module28();
	mercury__getopt_module29();
	mercury__getopt_module30();
	mercury__getopt_module31();
	mercury__getopt_module32();
	mercury__getopt_module33();
}

#endif

void mercury__getopt__init(void); /* suppress gcc warning */
void mercury__getopt__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__getopt_bunch_0();
#endif
}
