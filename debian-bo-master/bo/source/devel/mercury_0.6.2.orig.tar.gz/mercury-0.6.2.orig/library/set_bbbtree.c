/*
** Automatically generated from `set_bbbtree.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__set_bbbtree__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0);
Declare_label(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0_i3);
Declare_static(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0);
Declare_label(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i4);
Declare_label(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i1002);
Declare_static(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0);
Declare_label(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i4);
Declare_label(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i1002);
Declare_static(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i4);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i7);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i6);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i2);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i12);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i9);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i22);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i19);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i31);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i28);
Declare_static(mercury__set_bbbtree__to_sorted_list__ua10001_2_0);
Declare_static(mercury__set_bbbtree__to_sorted_list__ua10000_2_0);
Declare_static(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i4);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i5);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i8);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i1003);
Declare_static(mercury__set_bbbtree__remove_largest__ua0_3_0);
Declare_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1007);
Declare_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i5);
Declare_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1004);
Declare_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1);
Declare_static(mercury__set_bbbtree__remove_least__ua0_3_0);
Declare_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1007);
Declare_label(mercury__set_bbbtree__remove_least__ua0_3_0_i5);
Declare_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1004);
Declare_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1);
Declare_static(mercury__set_bbbtree__singleton_set__ua10003_2_0);
Declare_static(mercury__set_bbbtree__singleton_set__ua10000_2_0);
Declare_static(mercury__set_bbbtree__singleton_set__ua1_2_0);
Declare_label(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
Declare_static(mercury__set_bbbtree__largest__ua0_2_0);
Declare_label(mercury__set_bbbtree__largest__ua0_2_0_i1007);
Declare_label(mercury__set_bbbtree__largest__ua0_2_0_i5);
Declare_label(mercury__set_bbbtree__largest__ua0_2_0_i1004);
Declare_label(mercury__set_bbbtree__largest__ua0_2_0_i1006);
Declare_static(mercury__set_bbbtree__least__ua0_2_0);
Declare_label(mercury__set_bbbtree__least__ua0_2_0_i1007);
Declare_label(mercury__set_bbbtree__least__ua0_2_0_i5);
Declare_label(mercury__set_bbbtree__least__ua0_2_0_i1004);
Declare_label(mercury__set_bbbtree__least__ua0_2_0_i1006);
Declare_static(mercury__set_bbbtree__size__ua10000_2_0);
Declare_label(mercury__set_bbbtree__size__ua10000_2_0_i3);
Declare_static(mercury__set_bbbtree__empty__ua0_1_0);
Declare_label(mercury__set_bbbtree__empty__ua0_1_0_i1);
Declare_static(mercury__set_bbbtree__init__ua10000_1_0);
Define_extern_entry(mercury__set_bbbtree__init_1_0);
Define_extern_entry(mercury__set_bbbtree__empty_1_0);
Define_extern_entry(mercury__set_bbbtree__size_2_0);
Define_extern_entry(mercury__set_bbbtree__member_2_0);
Declare_label(mercury__set_bbbtree__member_2_0_i3);
Declare_label(mercury__set_bbbtree__member_2_0_i5);
Declare_label(mercury__set_bbbtree__member_2_0_i8);
Declare_label(mercury__set_bbbtree__member_2_0_i1004);
Define_extern_entry(mercury__set_bbbtree__member_2_1);
Declare_label(mercury__set_bbbtree__member_2_1_i5);
Declare_label(mercury__set_bbbtree__member_2_1_i4);
Declare_label(mercury__set_bbbtree__member_2_1_i8);
Declare_label(mercury__set_bbbtree__member_2_1_i7);
Declare_label(mercury__set_bbbtree__member_2_1_i2);
Declare_label(mercury__set_bbbtree__member_2_1_i9);
Define_extern_entry(mercury__set_bbbtree__is_member_3_0);
Declare_label(mercury__set_bbbtree__is_member_3_0_i4);
Declare_label(mercury__set_bbbtree__is_member_3_0_i1000);
Define_extern_entry(mercury__set_bbbtree__least_2_0);
Declare_label(mercury__set_bbbtree__least_2_0_i2);
Declare_label(mercury__set_bbbtree__least_2_0_i1000);
Define_extern_entry(mercury__set_bbbtree__least_2_1);
Declare_label(mercury__set_bbbtree__least_2_1_i1007);
Declare_label(mercury__set_bbbtree__least_2_1_i7);
Declare_label(mercury__set_bbbtree__least_2_1_i1004);
Declare_label(mercury__set_bbbtree__least_2_1_i1);
Define_extern_entry(mercury__set_bbbtree__largest_2_0);
Declare_label(mercury__set_bbbtree__largest_2_0_i2);
Declare_label(mercury__set_bbbtree__largest_2_0_i1000);
Define_extern_entry(mercury__set_bbbtree__largest_2_1);
Declare_label(mercury__set_bbbtree__largest_2_1_i1007);
Declare_label(mercury__set_bbbtree__largest_2_1_i7);
Declare_label(mercury__set_bbbtree__largest_2_1_i1004);
Declare_label(mercury__set_bbbtree__largest_2_1_i1);
Define_extern_entry(mercury__set_bbbtree__singleton_set_2_1);
Declare_label(mercury__set_bbbtree__singleton_set_2_1_i2);
Declare_label(mercury__set_bbbtree__singleton_set_2_1_i1000);
Define_extern_entry(mercury__set_bbbtree__singleton_set_2_2);
Declare_label(mercury__set_bbbtree__singleton_set_2_2_i1005);
Define_extern_entry(mercury__set_bbbtree__singleton_set_2_0);
Define_extern_entry(mercury__set_bbbtree__singleton_set_2_3);
Define_extern_entry(mercury__set_bbbtree__equal_2_0);
Declare_label(mercury__set_bbbtree__equal_2_0_i2);
Declare_label(mercury__set_bbbtree__equal_2_0_i1);
Define_extern_entry(mercury__set_bbbtree__insert_3_0);
Declare_label(mercury__set_bbbtree__insert_3_0_i2);
Define_extern_entry(mercury__set_bbbtree__insert_3_1);
Declare_label(mercury__set_bbbtree__insert_3_1_i2);
Define_extern_entry(mercury__set_bbbtree__insert_list_3_0);
Define_extern_entry(mercury__set_bbbtree__delete_3_0);
Declare_label(mercury__set_bbbtree__delete_3_0_i4);
Declare_label(mercury__set_bbbtree__delete_3_0_i3);
Define_extern_entry(mercury__set_bbbtree__delete_3_1);
Declare_label(mercury__set_bbbtree__delete_3_1_i4);
Declare_label(mercury__set_bbbtree__delete_3_1_i3);
Define_extern_entry(mercury__set_bbbtree__delete_list_3_0);
Declare_label(mercury__set_bbbtree__delete_list_3_0_i4);
Declare_label(mercury__set_bbbtree__delete_list_3_0_i1002);
Define_extern_entry(mercury__set_bbbtree__remove_3_0);
Declare_label(mercury__set_bbbtree__remove_3_0_i3);
Declare_label(mercury__set_bbbtree__remove_3_0_i6);
Declare_label(mercury__set_bbbtree__remove_3_0_i5);
Declare_label(mercury__set_bbbtree__remove_3_0_i8);
Declare_label(mercury__set_bbbtree__remove_3_0_i7);
Declare_label(mercury__set_bbbtree__remove_3_0_i10);
Declare_label(mercury__set_bbbtree__remove_3_0_i1007);
Declare_label(mercury__set_bbbtree__remove_3_0_i1);
Define_extern_entry(mercury__set_bbbtree__remove_list_3_0);
Declare_label(mercury__set_bbbtree__remove_list_3_0_i4);
Declare_label(mercury__set_bbbtree__remove_list_3_0_i6);
Declare_label(mercury__set_bbbtree__remove_list_3_0_i1003);
Declare_label(mercury__set_bbbtree__remove_list_3_0_i1);
Declare_label(mercury__set_bbbtree__remove_list_3_0_i1005);
Define_extern_entry(mercury__set_bbbtree__remove_least_3_0);
Declare_label(mercury__set_bbbtree__remove_least_3_0_i2);
Declare_label(mercury__set_bbbtree__remove_least_3_0_i1000);
Define_extern_entry(mercury__set_bbbtree__remove_largest_3_0);
Declare_label(mercury__set_bbbtree__remove_largest_3_0_i2);
Declare_label(mercury__set_bbbtree__remove_largest_3_0_i1000);
Define_extern_entry(mercury__set_bbbtree__list_to_set_2_0);
Declare_label(mercury__set_bbbtree__list_to_set_2_0_i2);
Define_extern_entry(mercury__set_bbbtree__sorted_list_to_set_2_0);
Declare_label(mercury__set_bbbtree__sorted_list_to_set_2_0_i2);
Define_extern_entry(mercury__set_bbbtree__sorted_list_to_set_len_3_0);
Define_extern_entry(mercury__set_bbbtree__to_sorted_list_2_0);
Define_extern_entry(mercury__set_bbbtree__to_sorted_list_2_1);
Define_extern_entry(mercury__set_bbbtree__union_3_0);
Define_extern_entry(mercury__set_bbbtree__power_union_2_0);
Define_extern_entry(mercury__set_bbbtree__intersect_3_0);
Define_extern_entry(mercury__set_bbbtree__power_intersect_2_0);
Declare_label(mercury__set_bbbtree__power_intersect_2_0_i4);
Declare_label(mercury__set_bbbtree__power_intersect_2_0_i1002);
Define_extern_entry(mercury__set_bbbtree__difference_3_0);
Define_extern_entry(mercury__set_bbbtree__subset_2_0);
Declare_label(mercury__set_bbbtree__subset_2_0_i2);
Define_extern_entry(mercury__set_bbbtree__superset_2_0);
Declare_static(mercury__set_bbbtree__insert_r_4_0);
Declare_label(mercury__set_bbbtree__insert_r_4_0_i4);
Declare_label(mercury__set_bbbtree__insert_r_4_0_i6);
Declare_label(mercury__set_bbbtree__insert_r_4_0_i8);
Declare_label(mercury__set_bbbtree__insert_r_4_0_i7);
Declare_label(mercury__set_bbbtree__insert_r_4_0_i10);
Declare_label(mercury__set_bbbtree__insert_r_4_0_i1004);
Declare_static(mercury__set_bbbtree__insert_list_r_4_0);
Declare_label(mercury__set_bbbtree__insert_list_r_4_0_i4);
Declare_label(mercury__set_bbbtree__insert_list_r_4_0_i1002);
Declare_static(mercury__set_bbbtree__union_r_4_0);
Declare_label(mercury__set_bbbtree__union_r_4_0_i4);
Declare_label(mercury__set_bbbtree__union_r_4_0_i5);
Declare_label(mercury__set_bbbtree__union_r_4_0_i6);
Declare_label(mercury__set_bbbtree__union_r_4_0_i7);
Declare_label(mercury__set_bbbtree__union_r_4_0_i1002);
Declare_static(mercury__set_bbbtree__power_union_r_3_0);
Declare_label(mercury__set_bbbtree__power_union_r_3_0_i4);
Declare_label(mercury__set_bbbtree__power_union_r_3_0_i5);
Declare_label(mercury__set_bbbtree__power_union_r_3_0_i6);
Declare_label(mercury__set_bbbtree__power_union_r_3_0_i1002);
Declare_static(mercury__set_bbbtree__intersect_r_4_0);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i4);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i5);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i6);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i7);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i10);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i9);
Declare_label(mercury__set_bbbtree__intersect_r_4_0_i1003);
Declare_static(mercury__set_bbbtree__power_intersect_r2_4_0);
Declare_label(mercury__set_bbbtree__power_intersect_r2_4_0_i6);
Declare_label(mercury__set_bbbtree__power_intersect_r2_4_0_i7);
Declare_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1005);
Declare_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1008);
Declare_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1007);
Declare_static(mercury__set_bbbtree__difference_r_4_0);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i4);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i5);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i6);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i7);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i10);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i9);
Declare_label(mercury__set_bbbtree__difference_r_4_0_i1003);
Declare_static(mercury__set_bbbtree__build_node_4_1);
Declare_label(mercury__set_bbbtree__build_node_4_1_i2);
Declare_label(mercury__set_bbbtree__build_node_4_1_i3);
Declare_static(mercury__set_bbbtree__balance_5_0);
Declare_label(mercury__set_bbbtree__balance_5_0_i2);
Declare_label(mercury__set_bbbtree__balance_5_0_i3);
Declare_label(mercury__set_bbbtree__balance_5_0_i4);
Declare_label(mercury__set_bbbtree__balance_5_0_i12);
Declare_label(mercury__set_bbbtree__balance_5_0_i13);
Declare_label(mercury__set_bbbtree__balance_5_0_i18);
Declare_label(mercury__set_bbbtree__balance_5_0_i17);
Declare_label(mercury__set_bbbtree__balance_5_0_i14);
Declare_label(mercury__set_bbbtree__balance_5_0_i25);
Declare_label(mercury__set_bbbtree__balance_5_0_i26);
Declare_label(mercury__set_bbbtree__balance_5_0_i24);
Declare_label(mercury__set_bbbtree__balance_5_0_i22);
Declare_label(mercury__set_bbbtree__balance_5_0_i9);
Declare_label(mercury__set_bbbtree__balance_5_0_i7);
Declare_label(mercury__set_bbbtree__balance_5_0_i38);
Declare_label(mercury__set_bbbtree__balance_5_0_i39);
Declare_label(mercury__set_bbbtree__balance_5_0_i44);
Declare_label(mercury__set_bbbtree__balance_5_0_i43);
Declare_label(mercury__set_bbbtree__balance_5_0_i40);
Declare_label(mercury__set_bbbtree__balance_5_0_i51);
Declare_label(mercury__set_bbbtree__balance_5_0_i52);
Declare_label(mercury__set_bbbtree__balance_5_0_i50);
Declare_label(mercury__set_bbbtree__balance_5_0_i48);
Declare_label(mercury__set_bbbtree__balance_5_0_i35);
Declare_label(mercury__set_bbbtree__balance_5_0_i33);
Declare_static(mercury__set_bbbtree__concat3_3_0);
Declare_label(mercury__set_bbbtree__concat3_3_0_i2);
Declare_label(mercury__set_bbbtree__concat3_3_0_i3);
Declare_label(mercury__set_bbbtree__concat3_3_0_i6);
Declare_label(mercury__set_bbbtree__concat3_3_0_i7);
Declare_label(mercury__set_bbbtree__concat3_3_0_i14);
Declare_label(mercury__set_bbbtree__concat3_3_0_i13);
Declare_label(mercury__set_bbbtree__concat3_3_0_i10);
Declare_label(mercury__set_bbbtree__concat3_3_0_i21);
Declare_label(mercury__set_bbbtree__concat3_3_0_i20);
Declare_static(mercury__set_bbbtree__concat4_5_0);
Declare_label(mercury__set_bbbtree__concat4_5_0_i8);
Declare_label(mercury__set_bbbtree__concat4_5_0_i6);
Declare_label(mercury__set_bbbtree__concat4_5_0_i12);
Declare_label(mercury__set_bbbtree__concat4_5_0_i10);
Declare_label(mercury__set_bbbtree__concat4_5_0_i1008);
Declare_label(mercury__set_bbbtree__concat4_5_0_i1009);
Declare_static(mercury__set_bbbtree__split_lt_4_0);
Declare_label(mercury__set_bbbtree__split_lt_4_0_i4);
Declare_label(mercury__set_bbbtree__split_lt_4_0_i6);
Declare_label(mercury__set_bbbtree__split_lt_4_0_i7);
Declare_label(mercury__set_bbbtree__split_lt_4_0_i9);
Declare_label(mercury__set_bbbtree__split_lt_4_0_i1004);
Declare_static(mercury__set_bbbtree__split_gt_4_0);
Declare_label(mercury__set_bbbtree__split_gt_4_0_i4);
Declare_label(mercury__set_bbbtree__split_gt_4_0_i6);
Declare_label(mercury__set_bbbtree__split_gt_4_0_i8);
Declare_label(mercury__set_bbbtree__split_gt_4_0_i7);
Declare_label(mercury__set_bbbtree__split_gt_4_0_i1004);
Define_extern_entry(mercury____Unify___set_bbbtree__set_bbbtree_1_0);
Declare_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1011);
Declare_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i6);
Declare_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i8);
Declare_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1008);
Declare_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
Define_extern_entry(mercury____Index___set_bbbtree__set_bbbtree_1_0);
Define_extern_entry(mercury____Compare___set_bbbtree__set_bbbtree_1_0);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i2);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i3);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i4);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i6);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i11);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i16);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i17);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i15);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i22);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i28);
Declare_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i9);

extern Word * mercury_data_set_bbbtree__base_type_layout_set_bbbtree_1[];
Word * mercury_data_set_bbbtree__base_type_info_set_bbbtree_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___set_bbbtree__set_bbbtree_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___set_bbbtree__set_bbbtree_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0),
	(Word *) (Integer) mercury_data_set_bbbtree__base_type_layout_set_bbbtree_1
};

extern Word * mercury_data_set_bbbtree__common_0[];
extern Word * mercury_data_set_bbbtree__common_3[];
Word * mercury_data_set_bbbtree__base_type_layout_set_bbbtree_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_set_bbbtree__common_0),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_set_bbbtree__common_3),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_set_bbbtree__common_0[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("empty", 5)
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_set_bbbtree__common_1[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_set_bbbtree__common_2[] = {
	(Word *) (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1,
	(Word *) ((Integer) 1)
};

Word * mercury_data_set_bbbtree__common_3[] = {
	(Word *) ((Integer) 4),
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_set_bbbtree__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_set_bbbtree__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_set_bbbtree__common_2),
	(Word *) string_const("tree", 4)
};

BEGIN_MODULE(mercury__set_bbbtree_module0)
	init_entry(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0);
	init_label(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index___set_bbbtree_set_bbbtree_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module1)
	init_entry(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0);
	init_label(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i4);
	init_label(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__to_sorted_list2__ua10001'/3 in mode 0 */
Define_static(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i1002);
	incr_sp_push_msg(3, "set_bbbtree__to_sorted_list2__ua10001");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	localcall(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0,
		LABEL(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i4),
		STATIC(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0));
Define_label(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0,
		STATIC(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0));
Define_label(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module2)
	init_entry(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0);
	init_label(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i4);
	init_label(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__to_sorted_list2__ua10000'/3 in mode 0 */
Define_static(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i1002);
	incr_sp_push_msg(3, "set_bbbtree__to_sorted_list2__ua10000");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	localcall(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0,
		LABEL(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i4),
		STATIC(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0));
Define_label(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0,
		STATIC(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0));
Define_label(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module3)
	init_entry(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i4);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i7);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i6);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i2);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i12);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i9);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i22);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i19);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i31);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i28);
BEGIN_CODE

/* code for predicate 'set_bbbtree__sorted_list_to_set_len2__ua10000'/4 in mode 0 */
Define_static(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0);
	incr_sp_push_msg(4, "set_bbbtree__sorted_list_to_set_len2__ua10000");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r2 <= ((Integer) 3)))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i2);
	detstackvar(1) = (Integer) r2;
	r3 = ((Integer) r2 / ((Integer) 2));
	detstackvar(2) = (((Integer) r2 - (Integer) r3) - ((Integer) 1));
	r2 = (Integer) r3;
	localcall(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0,
		LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i4),
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i6);
	r3 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r2 = (Integer) r3;
	localcall(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0,
		LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i7),
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i6);
	r1 = string_const("set_bbbtree__sorted_list_to_set_len2.1", 38);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i2);
	if (((Integer) r2 != ((Integer) 3)))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i9);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i12);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i12);
	if (((Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r1, ((Integer) 1)), ((Integer) 1)) == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i12);
	r3 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 1)), ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 1)), ((Integer) 0));
	field(mktag(1), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i12);
	r1 = string_const("set_bbbtree__sorted_list_to_set_len2.2", 38);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i9);
	if (((Integer) r2 != ((Integer) 2)))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i19);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i22);
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i22);
	r3 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) field(mktag(1), (Integer) r3, ((Integer) 1)), ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) tempr1;
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i22);
	r1 = string_const("set_bbbtree__sorted_list_to_set_len2.3", 38);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i19);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i28);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i31);
	r3 = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r4 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r4;
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i31);
	r1 = string_const("set_bbbtree__sorted_list_to_set_len2.4", 38);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0));
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0_i28);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module4)
	init_entry(mercury__set_bbbtree__to_sorted_list__ua10001_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__to_sorted_list__ua10001'/2 in mode 0 */
Define_static(mercury__set_bbbtree__to_sorted_list__ua10001_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__set_bbbtree__to_sorted_list2__ua10001_3_0),
		STATIC(mercury__set_bbbtree__to_sorted_list__ua10001_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module5)
	init_entry(mercury__set_bbbtree__to_sorted_list__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__to_sorted_list__ua10000'/2 in mode 0 */
Define_static(mercury__set_bbbtree__to_sorted_list__ua10000_2_0);
	r2 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__set_bbbtree__to_sorted_list2__ua10000_3_0),
		STATIC(mercury__set_bbbtree__to_sorted_list__ua10000_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module6)
	init_entry(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i4);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i5);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i8);
	init_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i1003);
BEGIN_CODE

/* code for predicate 'set_bbbtree__sorted_list_to_set_len__ua10000'/3 in mode 0 */
Define_static(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i1003);
	incr_sp_push_msg(2, "set_bbbtree__sorted_list_to_set_len__ua10000");
	detstackvar(2) = (Integer) succip;
	call_localret(STATIC(mercury__set_bbbtree__sorted_list_to_set_len2__ua10000_4_0),
		mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i4,
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0));
Define_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0));
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i5);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i5);
	detstackvar(1) = (Integer) r2;
	r1 = string_const("set_bbbtree__sorted_list_to_set_r", 33);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i8,
		STATIC(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0));
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i8);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0));
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module7)
	init_entry(mercury__set_bbbtree__remove_largest__ua0_3_0);
	init_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1007);
	init_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i5);
	init_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1004);
	init_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__remove_largest__ua0'/3 in mode 0 */
Define_static(mercury__set_bbbtree__remove_largest__ua0_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__remove_largest__ua0_3_0_i1004);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 3)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__remove_largest__ua0_3_0_i1007);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1007);
	incr_sp_push_msg(4, "set_bbbtree__remove_largest__ua0");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	localcall(mercury__set_bbbtree__remove_largest__ua0_3_0,
		LABEL(mercury__set_bbbtree__remove_largest__ua0_3_0_i5),
		STATIC(mercury__set_bbbtree__remove_largest__ua0_3_0));
Define_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_largest__ua0_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_largest__ua0_3_0_i1);
	r1 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = ((Integer) detstackvar(2) - ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 2)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r3, ((Integer) 3)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__remove_largest__ua0_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module8)
	init_entry(mercury__set_bbbtree__remove_least__ua0_3_0);
	init_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1007);
	init_label(mercury__set_bbbtree__remove_least__ua0_3_0_i5);
	init_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1004);
	init_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__remove_least__ua0'/3 in mode 0 */
Define_static(mercury__set_bbbtree__remove_least__ua0_3_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__remove_least__ua0_3_0_i1004);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__remove_least__ua0_3_0_i1007);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1007);
	incr_sp_push_msg(4, "set_bbbtree__remove_least__ua0");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	localcall(mercury__set_bbbtree__remove_least__ua0_3_0,
		LABEL(mercury__set_bbbtree__remove_least__ua0_3_0_i5),
		STATIC(mercury__set_bbbtree__remove_least__ua0_3_0));
Define_label(mercury__set_bbbtree__remove_least__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_least__ua0_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_least__ua0_3_0_i1);
	r1 = (Integer) r3;
	tag_incr_hp(r3, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r3, ((Integer) 1)) = ((Integer) detstackvar(2) - ((Integer) 1));
	field(mktag(1), (Integer) r3, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(3);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__remove_least__ua0_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module9)
	init_entry(mercury__set_bbbtree__singleton_set__ua10003_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set__ua10003'/2 in mode 0 */
Define_static(mercury__set_bbbtree__singleton_set__ua10003_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module10)
	init_entry(mercury__set_bbbtree__singleton_set__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set__ua10000'/2 in mode 0 */
Define_static(mercury__set_bbbtree__singleton_set__ua10000_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module11)
	init_entry(mercury__set_bbbtree__singleton_set__ua1_2_0);
	init_label(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set__ua1'/2 in mode 0 */
Define_static(mercury__set_bbbtree__singleton_set__ua1_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 3)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__singleton_set__ua1_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module12)
	init_entry(mercury__set_bbbtree__largest__ua0_2_0);
	init_label(mercury__set_bbbtree__largest__ua0_2_0_i1007);
	init_label(mercury__set_bbbtree__largest__ua0_2_0_i5);
	init_label(mercury__set_bbbtree__largest__ua0_2_0_i1004);
	init_label(mercury__set_bbbtree__largest__ua0_2_0_i1006);
BEGIN_CODE

/* code for predicate 'set_bbbtree__largest__ua0'/2 in mode 0 */
Define_static(mercury__set_bbbtree__largest__ua0_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__largest__ua0_2_0_i1004);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 3)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__largest__ua0_2_0_i1007);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__largest__ua0_2_0_i1007);
	incr_sp_push_msg(1, "set_bbbtree__largest__ua0");
	detstackvar(1) = (Integer) succip;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 3));
	localcall(mercury__set_bbbtree__largest__ua0_2_0,
		LABEL(mercury__set_bbbtree__largest__ua0_2_0_i5),
		STATIC(mercury__set_bbbtree__largest__ua0_2_0));
Define_label(mercury__set_bbbtree__largest__ua0_2_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__largest__ua0_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__largest__ua0_2_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__largest__ua0_2_0_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__largest__ua0_2_0_i1006);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module13)
	init_entry(mercury__set_bbbtree__least__ua0_2_0);
	init_label(mercury__set_bbbtree__least__ua0_2_0_i1007);
	init_label(mercury__set_bbbtree__least__ua0_2_0_i5);
	init_label(mercury__set_bbbtree__least__ua0_2_0_i1004);
	init_label(mercury__set_bbbtree__least__ua0_2_0_i1006);
BEGIN_CODE

/* code for predicate 'set_bbbtree__least__ua0'/2 in mode 0 */
Define_static(mercury__set_bbbtree__least__ua0_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__least__ua0_2_0_i1004);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__least__ua0_2_0_i1007);
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__least__ua0_2_0_i1007);
	incr_sp_push_msg(1, "set_bbbtree__least__ua0");
	detstackvar(1) = (Integer) succip;
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 2));
	localcall(mercury__set_bbbtree__least__ua0_2_0,
		LABEL(mercury__set_bbbtree__least__ua0_2_0_i5),
		STATIC(mercury__set_bbbtree__least__ua0_2_0));
Define_label(mercury__set_bbbtree__least__ua0_2_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__least__ua0_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__least__ua0_2_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__least__ua0_2_0_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__least__ua0_2_0_i1006);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module14)
	init_entry(mercury__set_bbbtree__size__ua10000_2_0);
	init_label(mercury__set_bbbtree__size__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate 'set_bbbtree__size__ua10000'/2 in mode 0 */
Define_static(mercury__set_bbbtree__size__ua10000_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__size__ua10000_2_0_i3);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	proceed();
Define_label(mercury__set_bbbtree__size__ua10000_2_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module15)
	init_entry(mercury__set_bbbtree__empty__ua0_1_0);
	init_label(mercury__set_bbbtree__empty__ua0_1_0_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__empty__ua0'/1 in mode 0 */
Define_static(mercury__set_bbbtree__empty__ua0_1_0);
	if (((Integer) r1 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__empty__ua0_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__empty__ua0_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module16)
	init_entry(mercury__set_bbbtree__init__ua10000_1_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__init__ua10000'/1 in mode 0 */
Define_static(mercury__set_bbbtree__init__ua10000_1_0);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module17)
	init_entry(mercury__set_bbbtree__init_1_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__init'/1 in mode 0 */
Define_entry(mercury__set_bbbtree__init_1_0);
	tailcall(STATIC(mercury__set_bbbtree__init__ua10000_1_0),
		ENTRY(mercury__set_bbbtree__init_1_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module18)
	init_entry(mercury__set_bbbtree__empty_1_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__empty'/1 in mode 0 */
Define_entry(mercury__set_bbbtree__empty_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__set_bbbtree__empty__ua0_1_0),
		ENTRY(mercury__set_bbbtree__empty_1_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module19)
	init_entry(mercury__set_bbbtree__size_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__size'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__size_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		ENTRY(mercury__set_bbbtree__size_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module20)
	init_entry(mercury__set_bbbtree__member_2_0);
	init_label(mercury__set_bbbtree__member_2_0_i3);
	init_label(mercury__set_bbbtree__member_2_0_i5);
	init_label(mercury__set_bbbtree__member_2_0_i8);
	init_label(mercury__set_bbbtree__member_2_0_i1004);
BEGIN_CODE

/* code for predicate 'set_bbbtree__member'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__member_2_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__member_2_0_i1004);
	incr_sp_push_msg(6, "set_bbbtree__member");
	detstackvar(6) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(2) = (Integer) r3;
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury__set_bbbtree__member_2_0_i3,
		ENTRY(mercury__set_bbbtree__member_2_0));
	}
Define_label(mercury__set_bbbtree__member_2_0_i3);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__member_2_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__member_2_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury__set_bbbtree__member_2_0));
	}
Define_label(mercury__set_bbbtree__member_2_0_i5);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__member_2_0_i8);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__set_bbbtree__member_2_0,
		ENTRY(mercury__set_bbbtree__member_2_0));
Define_label(mercury__set_bbbtree__member_2_0_i8);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__set_bbbtree__member_2_0,
		ENTRY(mercury__set_bbbtree__member_2_0));
Define_label(mercury__set_bbbtree__member_2_0_i1004);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module21)
	init_entry(mercury__set_bbbtree__member_2_1);
	init_label(mercury__set_bbbtree__member_2_1_i5);
	init_label(mercury__set_bbbtree__member_2_1_i4);
	init_label(mercury__set_bbbtree__member_2_1_i8);
	init_label(mercury__set_bbbtree__member_2_1_i7);
	init_label(mercury__set_bbbtree__member_2_1_i2);
	init_label(mercury__set_bbbtree__member_2_1_i9);
BEGIN_CODE

/* code for predicate 'set_bbbtree__member'/2 in mode 1 */
Define_entry(mercury__set_bbbtree__member_2_1);
	{
	Declare_entry(do_redo);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO(ENTRY(do_redo));
	}
	mkframe("set_bbbtree__member/2", 5, LABEL(mercury__set_bbbtree__member_2_1_i4));
	framevar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	framevar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	framevar(4) = (Integer) r1;
	localcall(mercury__set_bbbtree__member_2_1,
		LABEL(mercury__set_bbbtree__member_2_1_i5),
		ENTRY(mercury__set_bbbtree__member_2_1));
Define_label(mercury__set_bbbtree__member_2_1_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__member_2_1));
	r2 = (Integer) r1;
	r3 = (Integer) framevar(1);
	r4 = ((Integer) 1);
	r1 = (Integer) framevar(4);
	GOTO_LABEL(mercury__set_bbbtree__member_2_1_i2);
Define_label(mercury__set_bbbtree__member_2_1_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__member_2_1));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__set_bbbtree__member_2_1_i7);
	r1 = (Integer) framevar(4);
	r2 = (Integer) framevar(2);
	localcall(mercury__set_bbbtree__member_2_1,
		LABEL(mercury__set_bbbtree__member_2_1_i8),
		ENTRY(mercury__set_bbbtree__member_2_1));
Define_label(mercury__set_bbbtree__member_2_1_i8);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__member_2_1));
	r2 = (Integer) r1;
	r3 = (Integer) framevar(1);
	r4 = ((Integer) 2);
	r1 = (Integer) framevar(4);
	GOTO_LABEL(mercury__set_bbbtree__member_2_1_i2);
Define_label(mercury__set_bbbtree__member_2_1_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__member_2_1));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	r3 = (Integer) framevar(1);
	r1 = (Integer) framevar(4);
	r2 = (Integer) r3;
	r4 = ((Integer) 0);
Define_label(mercury__set_bbbtree__member_2_1_i2);
	framevar(0) = (Integer) r2;
	framevar(3) = (Integer) r4;
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury__set_bbbtree__member_2_1_i9,
		ENTRY(mercury__set_bbbtree__member_2_1));
	}
Define_label(mercury__set_bbbtree__member_2_1_i9);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__member_2_1));
	{
	Declare_entry(do_redo);
	if (((Integer) framevar(3) != (Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(0);
	succeed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module22)
	init_entry(mercury__set_bbbtree__is_member_3_0);
	init_label(mercury__set_bbbtree__is_member_3_0_i4);
	init_label(mercury__set_bbbtree__is_member_3_0_i1000);
BEGIN_CODE

/* code for predicate 'set_bbbtree__is_member'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__is_member_3_0);
	incr_sp_push_msg(1, "set_bbbtree__is_member");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__set_bbbtree__member_2_0),
		mercury__set_bbbtree__is_member_3_0_i4,
		ENTRY(mercury__set_bbbtree__is_member_3_0));
	}
Define_label(mercury__set_bbbtree__is_member_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__is_member_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__is_member_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__set_bbbtree__is_member_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module23)
	init_entry(mercury__set_bbbtree__least_2_0);
	init_label(mercury__set_bbbtree__least_2_0_i2);
	init_label(mercury__set_bbbtree__least_2_0_i1000);
BEGIN_CODE

/* code for predicate 'set_bbbtree__least'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__least_2_0);
	incr_sp_push_msg(2, "set_bbbtree__least");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__set_bbbtree__least__ua0_2_0),
		mercury__set_bbbtree__least_2_0_i2,
		ENTRY(mercury__set_bbbtree__least_2_0));
Define_label(mercury__set_bbbtree__least_2_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__least_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__least_2_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__least_2_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module24)
	init_entry(mercury__set_bbbtree__least_2_1);
	init_label(mercury__set_bbbtree__least_2_1_i1007);
	init_label(mercury__set_bbbtree__least_2_1_i7);
	init_label(mercury__set_bbbtree__least_2_1_i1004);
	init_label(mercury__set_bbbtree__least_2_1_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__least'/2 in mode 1 */
Define_entry(mercury__set_bbbtree__least_2_1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__least_2_1_i1004);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__least_2_1_i1007);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury__set_bbbtree__least_2_1));
	}
	}
Define_label(mercury__set_bbbtree__least_2_1_i1007);
	incr_sp_push_msg(3, "set_bbbtree__least");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	call_localret(STATIC(mercury__set_bbbtree__least__ua0_2_0),
		mercury__set_bbbtree__least_2_1_i7,
		ENTRY(mercury__set_bbbtree__least_2_1));
Define_label(mercury__set_bbbtree__least_2_1_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__least_2_1));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__least_2_1_i1);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury__set_bbbtree__least_2_1));
	}
Define_label(mercury__set_bbbtree__least_2_1_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__least_2_1_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module25)
	init_entry(mercury__set_bbbtree__largest_2_0);
	init_label(mercury__set_bbbtree__largest_2_0_i2);
	init_label(mercury__set_bbbtree__largest_2_0_i1000);
BEGIN_CODE

/* code for predicate 'set_bbbtree__largest'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__largest_2_0);
	incr_sp_push_msg(2, "set_bbbtree__largest");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__set_bbbtree__largest__ua0_2_0),
		mercury__set_bbbtree__largest_2_0_i2,
		ENTRY(mercury__set_bbbtree__largest_2_0));
Define_label(mercury__set_bbbtree__largest_2_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__largest_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__largest_2_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__largest_2_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module26)
	init_entry(mercury__set_bbbtree__largest_2_1);
	init_label(mercury__set_bbbtree__largest_2_1_i1007);
	init_label(mercury__set_bbbtree__largest_2_1_i7);
	init_label(mercury__set_bbbtree__largest_2_1_i1004);
	init_label(mercury__set_bbbtree__largest_2_1_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__largest'/2 in mode 1 */
Define_entry(mercury__set_bbbtree__largest_2_1);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__largest_2_1_i1004);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 3)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__largest_2_1_i1007);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury__set_bbbtree__largest_2_1));
	}
	}
Define_label(mercury__set_bbbtree__largest_2_1_i1007);
	incr_sp_push_msg(3, "set_bbbtree__largest");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	call_localret(STATIC(mercury__set_bbbtree__largest__ua0_2_0),
		mercury__set_bbbtree__largest_2_1_i7,
		ENTRY(mercury__set_bbbtree__largest_2_1));
Define_label(mercury__set_bbbtree__largest_2_1_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__largest_2_1));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__largest_2_1_i1);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury__set_bbbtree__largest_2_1));
	}
Define_label(mercury__set_bbbtree__largest_2_1_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__largest_2_1_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module27)
	init_entry(mercury__set_bbbtree__singleton_set_2_1);
	init_label(mercury__set_bbbtree__singleton_set_2_1_i2);
	init_label(mercury__set_bbbtree__singleton_set_2_1_i1000);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set'/2 in mode 1 */
Define_entry(mercury__set_bbbtree__singleton_set_2_1);
	incr_sp_push_msg(2, "set_bbbtree__singleton_set");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__set_bbbtree__singleton_set__ua1_2_0),
		mercury__set_bbbtree__singleton_set_2_1_i2,
		ENTRY(mercury__set_bbbtree__singleton_set_2_1));
Define_label(mercury__set_bbbtree__singleton_set_2_1_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__singleton_set_2_1));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set_2_1_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__singleton_set_2_1_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module28)
	init_entry(mercury__set_bbbtree__singleton_set_2_2);
	init_label(mercury__set_bbbtree__singleton_set_2_2_i1005);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set'/2 in mode 2 */
Define_entry(mercury__set_bbbtree__singleton_set_2_2);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set_2_2_i1005);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 1)) != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set_2_2_i1005);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 2)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set_2_2_i1005);
	if (((Integer) field(mktag(1), (Integer) r2, ((Integer) 3)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__singleton_set_2_2_i1005);
	{
	Word tempr1, tempr2, tempr3, tempr4;
	tempr4 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) field(mktag(1), (Integer) tempr4, ((Integer) 0));
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury__set_bbbtree__singleton_set_2_2));
	}
	}
Define_label(mercury__set_bbbtree__singleton_set_2_2_i1005);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module29)
	init_entry(mercury__set_bbbtree__singleton_set_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__singleton_set_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__set_bbbtree__singleton_set__ua10000_2_0),
		ENTRY(mercury__set_bbbtree__singleton_set_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module30)
	init_entry(mercury__set_bbbtree__singleton_set_2_3);
BEGIN_CODE

/* code for predicate 'set_bbbtree__singleton_set'/2 in mode 3 */
Define_entry(mercury__set_bbbtree__singleton_set_2_3);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__set_bbbtree__singleton_set__ua10003_2_0),
		ENTRY(mercury__set_bbbtree__singleton_set_2_3));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module31)
	init_entry(mercury__set_bbbtree__equal_2_0);
	init_label(mercury__set_bbbtree__equal_2_0_i2);
	init_label(mercury__set_bbbtree__equal_2_0_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__equal'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__equal_2_0);
	incr_sp_push_msg(4, "set_bbbtree__equal");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r1;
	{
		call_localret(STATIC(mercury__set_bbbtree__subset_2_0),
		mercury__set_bbbtree__equal_2_0_i2,
		ENTRY(mercury__set_bbbtree__equal_2_0));
	}
Define_label(mercury__set_bbbtree__equal_2_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__equal_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__equal_2_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
		tailcall(STATIC(mercury__set_bbbtree__subset_2_0),
		ENTRY(mercury__set_bbbtree__equal_2_0));
	}
Define_label(mercury__set_bbbtree__equal_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module32)
	init_entry(mercury__set_bbbtree__insert_3_0);
	init_label(mercury__set_bbbtree__insert_3_0_i2);
BEGIN_CODE

/* code for predicate 'set_bbbtree__insert'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__insert_3_0);
	incr_sp_push_msg(2, "set_bbbtree__insert");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r4 = ((Integer) 5);
	call_localret(STATIC(mercury__set_bbbtree__insert_r_4_0),
		mercury__set_bbbtree__insert_3_0_i2,
		ENTRY(mercury__set_bbbtree__insert_3_0));
Define_label(mercury__set_bbbtree__insert_3_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__insert_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__set_bbbtree__insert_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module33)
	init_entry(mercury__set_bbbtree__insert_3_1);
	init_label(mercury__set_bbbtree__insert_3_1_i2);
BEGIN_CODE

/* code for predicate 'set_bbbtree__insert'/3 in mode 1 */
Define_entry(mercury__set_bbbtree__insert_3_1);
	incr_sp_push_msg(2, "set_bbbtree__insert");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r4 = ((Integer) 5);
	call_localret(STATIC(mercury__set_bbbtree__insert_r_4_0),
		mercury__set_bbbtree__insert_3_1_i2,
		ENTRY(mercury__set_bbbtree__insert_3_1));
Define_label(mercury__set_bbbtree__insert_3_1_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__insert_3_1));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__set_bbbtree__insert_3_1));
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module34)
	init_entry(mercury__set_bbbtree__insert_list_3_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__insert_list'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__insert_list_3_0);
	r4 = ((Integer) 5);
	tailcall(STATIC(mercury__set_bbbtree__insert_list_r_4_0),
		ENTRY(mercury__set_bbbtree__insert_list_3_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module35)
	init_entry(mercury__set_bbbtree__delete_3_0);
	init_label(mercury__set_bbbtree__delete_3_0_i4);
	init_label(mercury__set_bbbtree__delete_3_0_i3);
BEGIN_CODE

/* code for predicate 'set_bbbtree__delete'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__delete_3_0);
	incr_sp_push_msg(3, "set_bbbtree__delete");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	{
		call_localret(STATIC(mercury__set_bbbtree__remove_3_0),
		mercury__set_bbbtree__delete_3_0_i4,
		ENTRY(mercury__set_bbbtree__delete_3_0));
	}
Define_label(mercury__set_bbbtree__delete_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__delete_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__delete_3_0_i3);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__set_bbbtree__delete_3_0));
	}
Define_label(mercury__set_bbbtree__delete_3_0_i3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__set_bbbtree__delete_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module36)
	init_entry(mercury__set_bbbtree__delete_3_1);
	init_label(mercury__set_bbbtree__delete_3_1_i4);
	init_label(mercury__set_bbbtree__delete_3_1_i3);
BEGIN_CODE

/* code for predicate 'set_bbbtree__delete'/3 in mode 1 */
Define_entry(mercury__set_bbbtree__delete_3_1);
	incr_sp_push_msg(3, "set_bbbtree__delete");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	{
		call_localret(STATIC(mercury__set_bbbtree__remove_3_0),
		mercury__set_bbbtree__delete_3_1_i4,
		ENTRY(mercury__set_bbbtree__delete_3_1));
	}
Define_label(mercury__set_bbbtree__delete_3_1_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__delete_3_1));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__delete_3_1_i3);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__set_bbbtree__delete_3_1));
	}
Define_label(mercury__set_bbbtree__delete_3_1_i3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		ENTRY(mercury__set_bbbtree__delete_3_1));
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module37)
	init_entry(mercury__set_bbbtree__delete_list_3_0);
	init_label(mercury__set_bbbtree__delete_list_3_0_i4);
	init_label(mercury__set_bbbtree__delete_list_3_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__delete_list'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__delete_list_3_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__delete_list_3_0_i1002);
	incr_sp_push_msg(3, "set_bbbtree__delete_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		call_localret(STATIC(mercury__set_bbbtree__delete_3_1),
		mercury__set_bbbtree__delete_list_3_0_i4,
		ENTRY(mercury__set_bbbtree__delete_list_3_0));
	}
Define_label(mercury__set_bbbtree__delete_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__delete_list_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__set_bbbtree__delete_list_3_0,
		ENTRY(mercury__set_bbbtree__delete_list_3_0));
Define_label(mercury__set_bbbtree__delete_list_3_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module38)
	init_entry(mercury__set_bbbtree__remove_3_0);
	init_label(mercury__set_bbbtree__remove_3_0_i3);
	init_label(mercury__set_bbbtree__remove_3_0_i6);
	init_label(mercury__set_bbbtree__remove_3_0_i5);
	init_label(mercury__set_bbbtree__remove_3_0_i8);
	init_label(mercury__set_bbbtree__remove_3_0_i7);
	init_label(mercury__set_bbbtree__remove_3_0_i10);
	init_label(mercury__set_bbbtree__remove_3_0_i1007);
	init_label(mercury__set_bbbtree__remove_3_0_i1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__remove'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__remove_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__remove_3_0_i1007);
	incr_sp_push_msg(7, "set_bbbtree__remove");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury__set_bbbtree__remove_3_0_i3,
		ENTRY(mercury__set_bbbtree__remove_3_0));
	}
	}
Define_label(mercury__set_bbbtree__remove_3_0_i3);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__remove_3_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__set_bbbtree__concat3_3_0),
		mercury__set_bbbtree__remove_3_0_i6,
		ENTRY(mercury__set_bbbtree__remove_3_0));
Define_label(mercury__set_bbbtree__remove_3_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_3_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__set_bbbtree__remove_3_0_i5);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__remove_3_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	localcall(mercury__set_bbbtree__remove_3_0,
		LABEL(mercury__set_bbbtree__remove_3_0_i8),
		ENTRY(mercury__set_bbbtree__remove_3_0));
Define_label(mercury__set_bbbtree__remove_3_0_i8);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_3_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = ((Integer) detstackvar(3) - ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) r1;
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__set_bbbtree__remove_3_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	localcall(mercury__set_bbbtree__remove_3_0,
		LABEL(mercury__set_bbbtree__remove_3_0_i10),
		ENTRY(mercury__set_bbbtree__remove_3_0));
Define_label(mercury__set_bbbtree__remove_3_0_i10);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_3_0_i1);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = ((Integer) detstackvar(3) - ((Integer) 1));
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__set_bbbtree__remove_3_0_i1007);
	r1 = FALSE;
	proceed();
Define_label(mercury__set_bbbtree__remove_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module39)
	init_entry(mercury__set_bbbtree__remove_list_3_0);
	init_label(mercury__set_bbbtree__remove_list_3_0_i4);
	init_label(mercury__set_bbbtree__remove_list_3_0_i6);
	init_label(mercury__set_bbbtree__remove_list_3_0_i1003);
	init_label(mercury__set_bbbtree__remove_list_3_0_i1);
	init_label(mercury__set_bbbtree__remove_list_3_0_i1005);
BEGIN_CODE

/* code for predicate 'set_bbbtree__remove_list'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__remove_list_3_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__remove_list_3_0_i1003);
	incr_sp_push_msg(3, "set_bbbtree__remove_list");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		call_localret(STATIC(mercury__set_bbbtree__remove_3_0),
		mercury__set_bbbtree__remove_list_3_0_i4,
		ENTRY(mercury__set_bbbtree__remove_list_3_0));
	}
Define_label(mercury__set_bbbtree__remove_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_list_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_list_3_0_i1);
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	localcall(mercury__set_bbbtree__remove_list_3_0,
		LABEL(mercury__set_bbbtree__remove_list_3_0_i6),
		ENTRY(mercury__set_bbbtree__remove_list_3_0));
Define_label(mercury__set_bbbtree__remove_list_3_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_list_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_list_3_0_i1005);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__remove_list_3_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__remove_list_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__set_bbbtree__remove_list_3_0_i1005);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module40)
	init_entry(mercury__set_bbbtree__remove_least_3_0);
	init_label(mercury__set_bbbtree__remove_least_3_0_i2);
	init_label(mercury__set_bbbtree__remove_least_3_0_i1000);
BEGIN_CODE

/* code for predicate 'set_bbbtree__remove_least'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__remove_least_3_0);
	incr_sp_push_msg(2, "set_bbbtree__remove_least");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__set_bbbtree__remove_least__ua0_3_0),
		mercury__set_bbbtree__remove_least_3_0_i2,
		ENTRY(mercury__set_bbbtree__remove_least_3_0));
Define_label(mercury__set_bbbtree__remove_least_3_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_least_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_least_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__remove_least_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module41)
	init_entry(mercury__set_bbbtree__remove_largest_3_0);
	init_label(mercury__set_bbbtree__remove_largest_3_0_i2);
	init_label(mercury__set_bbbtree__remove_largest_3_0_i1000);
BEGIN_CODE

/* code for predicate 'set_bbbtree__remove_largest'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__remove_largest_3_0);
	incr_sp_push_msg(2, "set_bbbtree__remove_largest");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__set_bbbtree__remove_largest__ua0_3_0),
		mercury__set_bbbtree__remove_largest_3_0_i2,
		ENTRY(mercury__set_bbbtree__remove_largest_3_0));
Define_label(mercury__set_bbbtree__remove_largest_3_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__remove_largest_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__remove_largest_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__set_bbbtree__remove_largest_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module42)
	init_entry(mercury__set_bbbtree__list_to_set_2_0);
	init_label(mercury__set_bbbtree__list_to_set_2_0_i2);
BEGIN_CODE

/* code for predicate 'set_bbbtree__list_to_set'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__list_to_set_2_0);
	incr_sp_push_msg(3, "set_bbbtree__list_to_set");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	call_localret(STATIC(mercury__set_bbbtree__init__ua10000_1_0),
		mercury__set_bbbtree__list_to_set_2_0_i2,
		ENTRY(mercury__set_bbbtree__list_to_set_2_0));
Define_label(mercury__set_bbbtree__list_to_set_2_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__list_to_set_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	r4 = ((Integer) 5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__set_bbbtree__insert_list_r_4_0),
		ENTRY(mercury__set_bbbtree__list_to_set_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module43)
	init_entry(mercury__set_bbbtree__sorted_list_to_set_2_0);
	init_label(mercury__set_bbbtree__sorted_list_to_set_2_0_i2);
BEGIN_CODE

/* code for predicate 'set_bbbtree__sorted_list_to_set'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__sorted_list_to_set_2_0);
	incr_sp_push_msg(2, "set_bbbtree__sorted_list_to_set");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__set_bbbtree__sorted_list_to_set_2_0_i2,
		ENTRY(mercury__set_bbbtree__sorted_list_to_set_2_0));
	}
Define_label(mercury__set_bbbtree__sorted_list_to_set_2_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__sorted_list_to_set_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0),
		ENTRY(mercury__set_bbbtree__sorted_list_to_set_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module44)
	init_entry(mercury__set_bbbtree__sorted_list_to_set_len_3_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__sorted_list_to_set_len'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__sorted_list_to_set_len_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__set_bbbtree__sorted_list_to_set_len__ua10000_3_0),
		ENTRY(mercury__set_bbbtree__sorted_list_to_set_len_3_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module45)
	init_entry(mercury__set_bbbtree__to_sorted_list_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__to_sorted_list'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__to_sorted_list_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__set_bbbtree__to_sorted_list__ua10000_2_0),
		ENTRY(mercury__set_bbbtree__to_sorted_list_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module46)
	init_entry(mercury__set_bbbtree__to_sorted_list_2_1);
BEGIN_CODE

/* code for predicate 'set_bbbtree__to_sorted_list'/2 in mode 1 */
Define_entry(mercury__set_bbbtree__to_sorted_list_2_1);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__set_bbbtree__to_sorted_list__ua10001_2_0),
		ENTRY(mercury__set_bbbtree__to_sorted_list_2_1));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module47)
	init_entry(mercury__set_bbbtree__union_3_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__union'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__union_3_0);
	r4 = ((Integer) 5);
	tailcall(STATIC(mercury__set_bbbtree__union_r_4_0),
		ENTRY(mercury__set_bbbtree__union_3_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module48)
	init_entry(mercury__set_bbbtree__power_union_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__power_union'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__power_union_2_0);
	r3 = ((Integer) 5);
	tailcall(STATIC(mercury__set_bbbtree__power_union_r_3_0),
		ENTRY(mercury__set_bbbtree__power_union_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module49)
	init_entry(mercury__set_bbbtree__intersect_3_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__intersect'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__intersect_3_0);
	r4 = ((Integer) 5);
	tailcall(STATIC(mercury__set_bbbtree__intersect_r_4_0),
		ENTRY(mercury__set_bbbtree__intersect_3_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module50)
	init_entry(mercury__set_bbbtree__power_intersect_2_0);
	init_label(mercury__set_bbbtree__power_intersect_2_0_i4);
	init_label(mercury__set_bbbtree__power_intersect_2_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__power_intersect'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__power_intersect_2_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__power_intersect_2_0_i1002);
	incr_sp_push_msg(3, "set_bbbtree__power_intersect");
	detstackvar(3) = (Integer) succip;
	r3 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	r4 = ((Integer) 5);
	detstackvar(1) = (Integer) r1;
	call_localret(STATIC(mercury__set_bbbtree__power_intersect_r2_4_0),
		mercury__set_bbbtree__power_intersect_2_0_i4,
		ENTRY(mercury__set_bbbtree__power_intersect_2_0));
Define_label(mercury__set_bbbtree__power_intersect_2_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__power_intersect_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = ((Integer) 5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__set_bbbtree__power_intersect_r2_4_0),
		ENTRY(mercury__set_bbbtree__power_intersect_2_0));
Define_label(mercury__set_bbbtree__power_intersect_2_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module51)
	init_entry(mercury__set_bbbtree__difference_3_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__difference'/3 in mode 0 */
Define_entry(mercury__set_bbbtree__difference_3_0);
	r4 = ((Integer) 5);
	tailcall(STATIC(mercury__set_bbbtree__difference_r_4_0),
		ENTRY(mercury__set_bbbtree__difference_3_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module52)
	init_entry(mercury__set_bbbtree__subset_2_0);
	init_label(mercury__set_bbbtree__subset_2_0_i2);
BEGIN_CODE

/* code for predicate 'set_bbbtree__subset'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__subset_2_0);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	incr_sp_push_msg(1, "set_bbbtree__subset");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__set_bbbtree__difference_3_0),
		mercury__set_bbbtree__subset_2_0_i2,
		ENTRY(mercury__set_bbbtree__subset_2_0));
	}
	}
Define_label(mercury__set_bbbtree__subset_2_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__subset_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__set_bbbtree__empty__ua0_1_0),
		ENTRY(mercury__set_bbbtree__subset_2_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module53)
	init_entry(mercury__set_bbbtree__superset_2_0);
BEGIN_CODE

/* code for predicate 'set_bbbtree__superset'/2 in mode 0 */
Define_entry(mercury__set_bbbtree__superset_2_0);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	{
		tailcall(STATIC(mercury__set_bbbtree__subset_2_0),
		ENTRY(mercury__set_bbbtree__superset_2_0));
	}
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module54)
	init_entry(mercury__set_bbbtree__insert_r_4_0);
	init_label(mercury__set_bbbtree__insert_r_4_0_i4);
	init_label(mercury__set_bbbtree__insert_r_4_0_i6);
	init_label(mercury__set_bbbtree__insert_r_4_0_i8);
	init_label(mercury__set_bbbtree__insert_r_4_0_i7);
	init_label(mercury__set_bbbtree__insert_r_4_0_i10);
	init_label(mercury__set_bbbtree__insert_r_4_0_i1004);
BEGIN_CODE

/* code for predicate 'set_bbbtree__insert_r'/4 in mode 0 */
Define_static(mercury__set_bbbtree__insert_r_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__insert_r_4_0_i1004);
	incr_sp_push_msg(8, "set_bbbtree__insert_r");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(3) = (Integer) r4;
	detstackvar(7) = (Integer) r1;
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury__set_bbbtree__insert_r_4_0_i4,
		STATIC(mercury__set_bbbtree__insert_r_4_0));
	}
	}
Define_label(mercury__set_bbbtree__insert_r_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__insert_r_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__insert_r_4_0_i6);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__set_bbbtree__insert_r_4_0_i6);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__insert_r_4_0_i7);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__set_bbbtree__insert_r_4_0,
		LABEL(mercury__set_bbbtree__insert_r_4_0_i8),
		STATIC(mercury__set_bbbtree__insert_r_4_0));
Define_label(mercury__set_bbbtree__insert_r_4_0_i8);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__insert_r_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__set_bbbtree__balance_5_0),
		STATIC(mercury__set_bbbtree__insert_r_4_0));
Define_label(mercury__set_bbbtree__insert_r_4_0_i7);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__set_bbbtree__insert_r_4_0,
		LABEL(mercury__set_bbbtree__insert_r_4_0_i10),
		STATIC(mercury__set_bbbtree__insert_r_4_0));
Define_label(mercury__set_bbbtree__insert_r_4_0_i10);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__insert_r_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__set_bbbtree__balance_5_0),
		STATIC(mercury__set_bbbtree__insert_r_4_0));
Define_label(mercury__set_bbbtree__insert_r_4_0_i1004);
	tag_incr_hp(r1, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r1, ((Integer) 3)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 2)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = ((Integer) 1);
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module55)
	init_entry(mercury__set_bbbtree__insert_list_r_4_0);
	init_label(mercury__set_bbbtree__insert_list_r_4_0_i4);
	init_label(mercury__set_bbbtree__insert_list_r_4_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__insert_list_r'/4 in mode 0 */
Define_static(mercury__set_bbbtree__insert_list_r_4_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__insert_list_r_4_0_i1002);
	incr_sp_push_msg(4, "set_bbbtree__insert_list_r");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	call_localret(STATIC(mercury__set_bbbtree__insert_r_4_0),
		mercury__set_bbbtree__insert_list_r_4_0_i4,
		STATIC(mercury__set_bbbtree__insert_list_r_4_0));
Define_label(mercury__set_bbbtree__insert_list_r_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__insert_list_r_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__set_bbbtree__insert_list_r_4_0,
		STATIC(mercury__set_bbbtree__insert_list_r_4_0));
Define_label(mercury__set_bbbtree__insert_list_r_4_0_i1002);
	r1 = (Integer) r2;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module56)
	init_entry(mercury__set_bbbtree__union_r_4_0);
	init_label(mercury__set_bbbtree__union_r_4_0_i4);
	init_label(mercury__set_bbbtree__union_r_4_0_i5);
	init_label(mercury__set_bbbtree__union_r_4_0_i6);
	init_label(mercury__set_bbbtree__union_r_4_0_i7);
	init_label(mercury__set_bbbtree__union_r_4_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__union_r'/4 in mode 0 */
Define_static(mercury__set_bbbtree__union_r_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__union_r_4_0_i1002);
	incr_sp_push_msg(7, "set_bbbtree__union_r");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r1;
	call_localret(STATIC(mercury__set_bbbtree__split_lt_4_0),
		mercury__set_bbbtree__union_r_4_0_i4,
		STATIC(mercury__set_bbbtree__union_r_4_0));
	}
Define_label(mercury__set_bbbtree__union_r_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__union_r_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__set_bbbtree__split_gt_4_0),
		mercury__set_bbbtree__union_r_4_0_i5,
		STATIC(mercury__set_bbbtree__union_r_4_0));
Define_label(mercury__set_bbbtree__union_r_4_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__union_r_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__union_r_4_0,
		LABEL(mercury__set_bbbtree__union_r_4_0_i6),
		STATIC(mercury__set_bbbtree__union_r_4_0));
Define_label(mercury__set_bbbtree__union_r_4_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__union_r_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__union_r_4_0,
		LABEL(mercury__set_bbbtree__union_r_4_0_i7),
		STATIC(mercury__set_bbbtree__union_r_4_0));
Define_label(mercury__set_bbbtree__union_r_4_0_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__union_r_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__concat4_5_0),
		STATIC(mercury__set_bbbtree__union_r_4_0));
Define_label(mercury__set_bbbtree__union_r_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module57)
	init_entry(mercury__set_bbbtree__power_union_r_3_0);
	init_label(mercury__set_bbbtree__power_union_r_3_0_i4);
	init_label(mercury__set_bbbtree__power_union_r_3_0_i5);
	init_label(mercury__set_bbbtree__power_union_r_3_0_i6);
	init_label(mercury__set_bbbtree__power_union_r_3_0_i1002);
BEGIN_CODE

/* code for predicate 'set_bbbtree__power_union_r'/3 in mode 0 */
Define_static(mercury__set_bbbtree__power_union_r_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__power_union_r_3_0_i1002);
	incr_sp_push_msg(5, "set_bbbtree__power_union_r");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	localcall(mercury__set_bbbtree__power_union_r_3_0,
		LABEL(mercury__set_bbbtree__power_union_r_3_0_i4),
		STATIC(mercury__set_bbbtree__power_union_r_3_0));
Define_label(mercury__set_bbbtree__power_union_r_3_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__power_union_r_3_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	localcall(mercury__set_bbbtree__power_union_r_3_0,
		LABEL(mercury__set_bbbtree__power_union_r_3_0_i5),
		STATIC(mercury__set_bbbtree__power_union_r_3_0));
Define_label(mercury__set_bbbtree__power_union_r_3_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__power_union_r_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__set_bbbtree__union_r_4_0),
		mercury__set_bbbtree__power_union_r_3_0_i6,
		STATIC(mercury__set_bbbtree__power_union_r_3_0));
Define_label(mercury__set_bbbtree__power_union_r_3_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__power_union_r_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__set_bbbtree__union_r_4_0),
		STATIC(mercury__set_bbbtree__power_union_r_3_0));
Define_label(mercury__set_bbbtree__power_union_r_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module58)
	init_entry(mercury__set_bbbtree__intersect_r_4_0);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i4);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i5);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i6);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i7);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i10);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i9);
	init_label(mercury__set_bbbtree__intersect_r_4_0_i1003);
BEGIN_CODE

/* code for predicate 'set_bbbtree__intersect_r'/4 in mode 0 */
Define_static(mercury__set_bbbtree__intersect_r_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__intersect_r_4_0_i1003);
	incr_sp_push_msg(8, "set_bbbtree__intersect_r");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(2) = (Integer) r4;
	detstackvar(7) = (Integer) r1;
	call_localret(STATIC(mercury__set_bbbtree__split_lt_4_0),
		mercury__set_bbbtree__intersect_r_4_0_i4,
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
	}
Define_label(mercury__set_bbbtree__intersect_r_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__intersect_r_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__set_bbbtree__split_gt_4_0),
		mercury__set_bbbtree__intersect_r_4_0_i5,
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
Define_label(mercury__set_bbbtree__intersect_r_4_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__intersect_r_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__intersect_r_4_0,
		LABEL(mercury__set_bbbtree__intersect_r_4_0_i6),
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
Define_label(mercury__set_bbbtree__intersect_r_4_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__intersect_r_4_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__intersect_r_4_0,
		LABEL(mercury__set_bbbtree__intersect_r_4_0_i7),
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
Define_label(mercury__set_bbbtree__intersect_r_4_0_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__intersect_r_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__set_bbbtree__member_2_0),
		mercury__set_bbbtree__intersect_r_4_0_i10,
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
	}
Define_label(mercury__set_bbbtree__intersect_r_4_0_i10);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__intersect_r_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__intersect_r_4_0_i9);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__set_bbbtree__concat4_5_0),
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
Define_label(mercury__set_bbbtree__intersect_r_4_0_i9);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__set_bbbtree__concat3_3_0),
		STATIC(mercury__set_bbbtree__intersect_r_4_0));
Define_label(mercury__set_bbbtree__intersect_r_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module59)
	init_entry(mercury__set_bbbtree__power_intersect_r2_4_0);
	init_label(mercury__set_bbbtree__power_intersect_r2_4_0_i6);
	init_label(mercury__set_bbbtree__power_intersect_r2_4_0_i7);
	init_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1005);
	init_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1008);
	init_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1007);
BEGIN_CODE

/* code for predicate 'set_bbbtree__power_intersect_r2'/4 in mode 0 */
Define_static(mercury__set_bbbtree__power_intersect_r2_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__power_intersect_r2_4_0_i1008);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__power_intersect_r2_4_0_i1005);
	incr_sp_push_msg(5, "set_bbbtree__power_intersect_r2");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	call_localret(STATIC(mercury__set_bbbtree__intersect_r_4_0),
		mercury__set_bbbtree__power_intersect_r2_4_0_i6,
		STATIC(mercury__set_bbbtree__power_intersect_r2_4_0));
Define_label(mercury__set_bbbtree__power_intersect_r2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__power_intersect_r2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	localcall(mercury__set_bbbtree__power_intersect_r2_4_0,
		LABEL(mercury__set_bbbtree__power_intersect_r2_4_0_i7),
		STATIC(mercury__set_bbbtree__power_intersect_r2_4_0));
Define_label(mercury__set_bbbtree__power_intersect_r2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__power_intersect_r2_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__set_bbbtree__power_intersect_r2_4_0,
		STATIC(mercury__set_bbbtree__power_intersect_r2_4_0));
Define_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1005);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1008);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__power_intersect_r2_4_0_i1007);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
Define_label(mercury__set_bbbtree__power_intersect_r2_4_0_i1007);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module60)
	init_entry(mercury__set_bbbtree__difference_r_4_0);
	init_label(mercury__set_bbbtree__difference_r_4_0_i4);
	init_label(mercury__set_bbbtree__difference_r_4_0_i5);
	init_label(mercury__set_bbbtree__difference_r_4_0_i6);
	init_label(mercury__set_bbbtree__difference_r_4_0_i7);
	init_label(mercury__set_bbbtree__difference_r_4_0_i10);
	init_label(mercury__set_bbbtree__difference_r_4_0_i9);
	init_label(mercury__set_bbbtree__difference_r_4_0_i1003);
BEGIN_CODE

/* code for predicate 'set_bbbtree__difference_r'/4 in mode 0 */
Define_static(mercury__set_bbbtree__difference_r_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__difference_r_4_0_i1003);
	incr_sp_push_msg(8, "set_bbbtree__difference_r");
	detstackvar(8) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(2) = (Integer) r4;
	detstackvar(7) = (Integer) r1;
	call_localret(STATIC(mercury__set_bbbtree__split_lt_4_0),
		mercury__set_bbbtree__difference_r_4_0_i4,
		STATIC(mercury__set_bbbtree__difference_r_4_0));
	}
Define_label(mercury__set_bbbtree__difference_r_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__difference_r_4_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__set_bbbtree__split_gt_4_0),
		mercury__set_bbbtree__difference_r_4_0_i5,
		STATIC(mercury__set_bbbtree__difference_r_4_0));
Define_label(mercury__set_bbbtree__difference_r_4_0_i5);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__difference_r_4_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__difference_r_4_0,
		LABEL(mercury__set_bbbtree__difference_r_4_0_i6),
		STATIC(mercury__set_bbbtree__difference_r_4_0));
Define_label(mercury__set_bbbtree__difference_r_4_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__difference_r_4_0));
	r3 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__difference_r_4_0,
		LABEL(mercury__set_bbbtree__difference_r_4_0_i7),
		STATIC(mercury__set_bbbtree__difference_r_4_0));
Define_label(mercury__set_bbbtree__difference_r_4_0_i7);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__difference_r_4_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__set_bbbtree__member_2_0),
		mercury__set_bbbtree__difference_r_4_0_i10,
		STATIC(mercury__set_bbbtree__difference_r_4_0));
	}
Define_label(mercury__set_bbbtree__difference_r_4_0_i10);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__difference_r_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__difference_r_4_0_i9);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__set_bbbtree__concat3_3_0),
		STATIC(mercury__set_bbbtree__difference_r_4_0));
Define_label(mercury__set_bbbtree__difference_r_4_0_i9);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__set_bbbtree__concat4_5_0),
		STATIC(mercury__set_bbbtree__difference_r_4_0));
Define_label(mercury__set_bbbtree__difference_r_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module61)
	init_entry(mercury__set_bbbtree__build_node_4_1);
	init_label(mercury__set_bbbtree__build_node_4_1_i2);
	init_label(mercury__set_bbbtree__build_node_4_1_i3);
BEGIN_CODE

/* code for predicate 'set_bbbtree__build_node'/4 in mode 1 */
Define_static(mercury__set_bbbtree__build_node_4_1);
	incr_sp_push_msg(6, "set_bbbtree__build_node");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__build_node_4_1_i2,
		STATIC(mercury__set_bbbtree__build_node_4_1));
Define_label(mercury__set_bbbtree__build_node_4_1_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__build_node_4_1));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__build_node_4_1_i3,
		STATIC(mercury__set_bbbtree__build_node_4_1));
Define_label(mercury__set_bbbtree__build_node_4_1_i3);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__build_node_4_1));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set_bbbtree__base_type_info_set_bbbtree_1;
	tag_incr_hp(r2, mktag(1), ((Integer) 4));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = ((((Integer) 1) + (Integer) detstackvar(4)) + (Integer) r3);
	field(mktag(1), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__copy_2_1);
	tailcall(ENTRY(mercury__copy_2_1),
		STATIC(mercury__set_bbbtree__build_node_4_1));
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module62)
	init_entry(mercury__set_bbbtree__balance_5_0);
	init_label(mercury__set_bbbtree__balance_5_0_i2);
	init_label(mercury__set_bbbtree__balance_5_0_i3);
	init_label(mercury__set_bbbtree__balance_5_0_i4);
	init_label(mercury__set_bbbtree__balance_5_0_i12);
	init_label(mercury__set_bbbtree__balance_5_0_i13);
	init_label(mercury__set_bbbtree__balance_5_0_i18);
	init_label(mercury__set_bbbtree__balance_5_0_i17);
	init_label(mercury__set_bbbtree__balance_5_0_i14);
	init_label(mercury__set_bbbtree__balance_5_0_i25);
	init_label(mercury__set_bbbtree__balance_5_0_i26);
	init_label(mercury__set_bbbtree__balance_5_0_i24);
	init_label(mercury__set_bbbtree__balance_5_0_i22);
	init_label(mercury__set_bbbtree__balance_5_0_i9);
	init_label(mercury__set_bbbtree__balance_5_0_i7);
	init_label(mercury__set_bbbtree__balance_5_0_i38);
	init_label(mercury__set_bbbtree__balance_5_0_i39);
	init_label(mercury__set_bbbtree__balance_5_0_i44);
	init_label(mercury__set_bbbtree__balance_5_0_i43);
	init_label(mercury__set_bbbtree__balance_5_0_i40);
	init_label(mercury__set_bbbtree__balance_5_0_i51);
	init_label(mercury__set_bbbtree__balance_5_0_i52);
	init_label(mercury__set_bbbtree__balance_5_0_i50);
	init_label(mercury__set_bbbtree__balance_5_0_i48);
	init_label(mercury__set_bbbtree__balance_5_0_i35);
	init_label(mercury__set_bbbtree__balance_5_0_i33);
BEGIN_CODE

/* code for predicate 'set_bbbtree__balance'/5 in mode 0 */
Define_static(mercury__set_bbbtree__balance_5_0);
	incr_sp_push_msg(7, "set_bbbtree__balance");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__balance_5_0_i2,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__balance_5_0_i3,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i3);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r2 = ((Integer) detstackvar(5) + (Integer) r1);
	if (((Integer) r2 >= ((Integer) 2)))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i4);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i4);
	r2 = ((Integer) detstackvar(4) * (Integer) detstackvar(5));
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i7);
	r2 = (Integer) detstackvar(3);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i9);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__balance_5_0_i12,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i12);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(3), ((Integer) 3));
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__balance_5_0_i13,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i13);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	if (((Integer) detstackvar(4) >= (Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i14);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(3);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i17);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__set_bbbtree__build_node_4_1),
		mercury__set_bbbtree__balance_5_0_i18,
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i18);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i17);
	r1 = string_const("set_bbbtree__single_rot_l", 25);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i14);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(3);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i22);
	tempr2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	if (((Integer) tempr2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i24);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 3));
	r4 = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__set_bbbtree__build_node_4_1),
		mercury__set_bbbtree__balance_5_0_i25,
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i25);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__set_bbbtree__build_node_4_1),
		mercury__set_bbbtree__balance_5_0_i26,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i26);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i24);
	r1 = string_const("set_bbbtree__double_rot_l.2", 27);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i22);
	r1 = string_const("set_bbbtree__double_rot_l.1", 27);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i9);
	r1 = string_const("set_bbbtree__balance.1", 22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i7);
	if (((Integer) detstackvar(5) <= ((Integer) detstackvar(4) * (Integer) r1)))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i33);
	r2 = (Integer) detstackvar(2);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i35);
	r1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__balance_5_0_i38,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i38);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(2), ((Integer) 3));
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__balance_5_0_i39,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i39);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	if (((Integer) r1 >= (Integer) detstackvar(4)))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i40);
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i43);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	r1 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__set_bbbtree__build_node_4_1),
		mercury__set_bbbtree__balance_5_0_i44,
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i44);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i43);
	r1 = string_const("set_bbbtree__single_rot_r", 25);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i40);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i48);
	tempr2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	if (((Integer) tempr2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__balance_5_0_i50);
	r2 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	r4 = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	r1 = (Integer) detstackvar(6);
	call_localret(STATIC(mercury__set_bbbtree__build_node_4_1),
		mercury__set_bbbtree__balance_5_0_i51,
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i51);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__set_bbbtree__build_node_4_1),
		mercury__set_bbbtree__balance_5_0_i52,
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i52);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__balance_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__balance_5_0));
Define_label(mercury__set_bbbtree__balance_5_0_i50);
	r1 = string_const("set_bbbtree__double_rot_r.2", 27);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i48);
	r1 = string_const("set_bbbtree__double_rot_r.1", 27);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i35);
	r1 = string_const("set_bbbtree__balance.2", 22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__balance_5_0));
	}
Define_label(mercury__set_bbbtree__balance_5_0_i33);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__balance_5_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module63)
	init_entry(mercury__set_bbbtree__concat3_3_0);
	init_label(mercury__set_bbbtree__concat3_3_0_i2);
	init_label(mercury__set_bbbtree__concat3_3_0_i3);
	init_label(mercury__set_bbbtree__concat3_3_0_i6);
	init_label(mercury__set_bbbtree__concat3_3_0_i7);
	init_label(mercury__set_bbbtree__concat3_3_0_i14);
	init_label(mercury__set_bbbtree__concat3_3_0_i13);
	init_label(mercury__set_bbbtree__concat3_3_0_i10);
	init_label(mercury__set_bbbtree__concat3_3_0_i21);
	init_label(mercury__set_bbbtree__concat3_3_0_i20);
BEGIN_CODE

/* code for predicate 'set_bbbtree__concat3'/3 in mode 0 */
Define_static(mercury__set_bbbtree__concat3_3_0);
	incr_sp_push_msg(5, "set_bbbtree__concat3");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__concat3_3_0_i2,
		STATIC(mercury__set_bbbtree__concat3_3_0));
Define_label(mercury__set_bbbtree__concat3_3_0_i2);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__concat3_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__concat3_3_0_i3);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__set_bbbtree__concat3_3_0_i3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__set_bbbtree__size__ua10000_2_0),
		mercury__set_bbbtree__concat3_3_0_i6,
		STATIC(mercury__set_bbbtree__concat3_3_0));
Define_label(mercury__set_bbbtree__concat3_3_0_i6);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__concat3_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__concat3_3_0_i7);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__set_bbbtree__concat3_3_0_i7);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__concat3_3_0_i10);
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__set_bbbtree__remove_largest__ua0_3_0),
		mercury__set_bbbtree__concat3_3_0_i14,
		STATIC(mercury__set_bbbtree__concat3_3_0));
Define_label(mercury__set_bbbtree__concat3_3_0_i14);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__concat3_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__concat3_3_0_i13);
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__concat3_3_0));
Define_label(mercury__set_bbbtree__concat3_3_0_i13);
	r1 = string_const("set_bbbtree__concat3.1", 22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__concat3_3_0));
	}
Define_label(mercury__set_bbbtree__concat3_3_0_i10);
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__set_bbbtree__remove_least__ua0_3_0),
		mercury__set_bbbtree__concat3_3_0_i21,
		STATIC(mercury__set_bbbtree__concat3_3_0));
Define_label(mercury__set_bbbtree__concat3_3_0_i21);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__concat3_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__set_bbbtree__concat3_3_0_i20);
	r1 = (Integer) detstackvar(4);
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__concat3_3_0));
Define_label(mercury__set_bbbtree__concat3_3_0_i20);
	r1 = string_const("set_bbbtree__concat3.2", 22);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__set_bbbtree__concat3_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module64)
	init_entry(mercury__set_bbbtree__concat4_5_0);
	init_label(mercury__set_bbbtree__concat4_5_0_i8);
	init_label(mercury__set_bbbtree__concat4_5_0_i6);
	init_label(mercury__set_bbbtree__concat4_5_0_i12);
	init_label(mercury__set_bbbtree__concat4_5_0_i10);
	init_label(mercury__set_bbbtree__concat4_5_0_i1008);
	init_label(mercury__set_bbbtree__concat4_5_0_i1009);
BEGIN_CODE

/* code for predicate 'set_bbbtree__concat4'/5 in mode 0 */
Define_static(mercury__set_bbbtree__concat4_5_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__concat4_5_0_i1009);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__concat4_5_0_i1008);
	r6 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r7 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	r8 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	r9 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r10 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r11 = ((Integer) r5 * (Integer) r9);
	incr_sp_push_msg(5, "set_bbbtree__concat4");
	detstackvar(5) = (Integer) succip;
	if (((Integer) r11 >= (Integer) r6))
		GOTO_LABEL(mercury__set_bbbtree__concat4_5_0_i6);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	detstackvar(4) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	localcall(mercury__set_bbbtree__concat4_5_0,
		LABEL(mercury__set_bbbtree__concat4_5_0_i8),
		STATIC(mercury__set_bbbtree__concat4_5_0));
Define_label(mercury__set_bbbtree__concat4_5_0_i8);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__concat4_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__set_bbbtree__balance_5_0),
		STATIC(mercury__set_bbbtree__concat4_5_0));
Define_label(mercury__set_bbbtree__concat4_5_0_i6);
	r11 = ((Integer) r5 * (Integer) r6);
	if (((Integer) r11 >= (Integer) r9))
		GOTO_LABEL(mercury__set_bbbtree__concat4_5_0_i10);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r10;
	detstackvar(3) = (Integer) r8;
	detstackvar(4) = (Integer) r1;
	r2 = (Integer) r7;
	localcall(mercury__set_bbbtree__concat4_5_0,
		LABEL(mercury__set_bbbtree__concat4_5_0_i12),
		STATIC(mercury__set_bbbtree__concat4_5_0));
Define_label(mercury__set_bbbtree__concat4_5_0_i12);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__concat4_5_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__set_bbbtree__balance_5_0),
		STATIC(mercury__set_bbbtree__concat4_5_0));
Define_label(mercury__set_bbbtree__concat4_5_0_i10);
	{
	Word tempr1;
	tempr1 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) r4;
	r4 = (Integer) tempr1;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__set_bbbtree__build_node_4_1),
		STATIC(mercury__set_bbbtree__concat4_5_0));
	}
Define_label(mercury__set_bbbtree__concat4_5_0_i1008);
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	tailcall(STATIC(mercury__set_bbbtree__insert_r_4_0),
		STATIC(mercury__set_bbbtree__concat4_5_0));
Define_label(mercury__set_bbbtree__concat4_5_0_i1009);
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) r5;
	tailcall(STATIC(mercury__set_bbbtree__insert_r_4_0),
		STATIC(mercury__set_bbbtree__concat4_5_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module65)
	init_entry(mercury__set_bbbtree__split_lt_4_0);
	init_label(mercury__set_bbbtree__split_lt_4_0_i4);
	init_label(mercury__set_bbbtree__split_lt_4_0_i6);
	init_label(mercury__set_bbbtree__split_lt_4_0_i7);
	init_label(mercury__set_bbbtree__split_lt_4_0_i9);
	init_label(mercury__set_bbbtree__split_lt_4_0_i1004);
BEGIN_CODE

/* code for predicate 'set_bbbtree__split_lt'/4 in mode 0 */
Define_static(mercury__set_bbbtree__split_lt_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__split_lt_4_0_i1004);
	incr_sp_push_msg(7, "set_bbbtree__split_lt");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury__set_bbbtree__split_lt_4_0_i4,
		STATIC(mercury__set_bbbtree__split_lt_4_0));
	}
	}
Define_label(mercury__set_bbbtree__split_lt_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__split_lt_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__split_lt_4_0_i6);
	r1 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__set_bbbtree__split_lt_4_0_i6);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__split_lt_4_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__set_bbbtree__split_lt_4_0,
		STATIC(mercury__set_bbbtree__split_lt_4_0));
Define_label(mercury__set_bbbtree__split_lt_4_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__split_lt_4_0,
		LABEL(mercury__set_bbbtree__split_lt_4_0_i9),
		STATIC(mercury__set_bbbtree__split_lt_4_0));
Define_label(mercury__set_bbbtree__split_lt_4_0_i9);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__split_lt_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__concat4_5_0),
		STATIC(mercury__set_bbbtree__split_lt_4_0));
Define_label(mercury__set_bbbtree__split_lt_4_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module66)
	init_entry(mercury__set_bbbtree__split_gt_4_0);
	init_label(mercury__set_bbbtree__split_gt_4_0_i4);
	init_label(mercury__set_bbbtree__split_gt_4_0_i6);
	init_label(mercury__set_bbbtree__split_gt_4_0_i8);
	init_label(mercury__set_bbbtree__split_gt_4_0_i7);
	init_label(mercury__set_bbbtree__split_gt_4_0_i1004);
BEGIN_CODE

/* code for predicate 'set_bbbtree__split_gt'/4 in mode 0 */
Define_static(mercury__set_bbbtree__split_gt_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__set_bbbtree__split_gt_4_0_i1004);
	incr_sp_push_msg(7, "set_bbbtree__split_gt");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(1) = (Integer) r3;
	detstackvar(3) = (Integer) tempr1;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury__set_bbbtree__split_gt_4_0_i4,
		STATIC(mercury__set_bbbtree__split_gt_4_0));
	}
	}
Define_label(mercury__set_bbbtree__split_gt_4_0_i4);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__split_gt_4_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__set_bbbtree__split_gt_4_0_i6);
	r1 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__set_bbbtree__split_gt_4_0_i6);
	if (((Integer) r1 != ((Integer) 1)))
		GOTO_LABEL(mercury__set_bbbtree__split_gt_4_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	localcall(mercury__set_bbbtree__split_gt_4_0,
		LABEL(mercury__set_bbbtree__split_gt_4_0_i8),
		STATIC(mercury__set_bbbtree__split_gt_4_0));
Define_label(mercury__set_bbbtree__split_gt_4_0_i8);
	update_prof_current_proc(LABEL(mercury__set_bbbtree__split_gt_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__set_bbbtree__concat4_5_0),
		STATIC(mercury__set_bbbtree__split_gt_4_0));
Define_label(mercury__set_bbbtree__split_gt_4_0_i7);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__set_bbbtree__split_gt_4_0,
		STATIC(mercury__set_bbbtree__split_gt_4_0));
Define_label(mercury__set_bbbtree__split_gt_4_0_i1004);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module67)
	init_entry(mercury____Unify___set_bbbtree__set_bbbtree_1_0);
	init_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1011);
	init_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i6);
	init_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i8);
	init_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1008);
	init_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___set_bbbtree__set_bbbtree_1_0);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1011);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1008);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1011);
	incr_sp_push_msg(8, "__Unify__");
	detstackvar(8) = (Integer) succip;
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 3));
	detstackvar(7) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__unify_2_0);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___set_bbbtree__set_bbbtree_1_0_i6,
		ENTRY(mercury____Unify___set_bbbtree__set_bbbtree_1_0));
	}
Define_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
	if (((Integer) detstackvar(1) != (Integer) detstackvar(4)))
		GOTO_LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	localcall(mercury____Unify___set_bbbtree__set_bbbtree_1_0,
		LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i8),
		ENTRY(mercury____Unify___set_bbbtree__set_bbbtree_1_0));
Define_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury____Unify___set_bbbtree__set_bbbtree_1_0,
		ENTRY(mercury____Unify___set_bbbtree__set_bbbtree_1_0));
Define_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1008);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___set_bbbtree__set_bbbtree_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module68)
	init_entry(mercury____Index___set_bbbtree__set_bbbtree_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___set_bbbtree__set_bbbtree_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0),
		ENTRY(mercury____Index___set_bbbtree__set_bbbtree_1_0));
END_MODULE

BEGIN_MODULE(mercury__set_bbbtree_module69)
	init_entry(mercury____Compare___set_bbbtree__set_bbbtree_1_0);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i2);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i3);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i4);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i6);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i11);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i16);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i17);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i15);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i22);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i28);
	init_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___set_bbbtree__set_bbbtree_1_0);
	incr_sp_push_msg(8, "__Compare__");
	detstackvar(8) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0),
		mercury____Compare___set_bbbtree__set_bbbtree_1_0_i2,
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury____Index___set_bbbtree_set_bbbtree_1__ua10000_2_0),
		mercury____Compare___set_bbbtree__set_bbbtree_1_0_i3,
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i11);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i9);
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 3));
	tempr2 = (Integer) detstackvar(1);
	r2 = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 3));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 1));
	r1 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___set_bbbtree__set_bbbtree_1_0_i16,
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	}
	}
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i15);
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i17);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i15);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___set_bbbtree__set_bbbtree_1_0_i22,
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	}
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i17);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	localcall(mercury____Compare___set_bbbtree__set_bbbtree_1_0,
		LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i28),
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i28);
	update_prof_current_proc(LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i17);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	localtailcall(mercury____Compare___set_bbbtree__set_bbbtree_1_0,
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
Define_label(mercury____Compare___set_bbbtree__set_bbbtree_1_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___set_bbbtree__set_bbbtree_1_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__set_bbbtree_bunch_0(void)
{
	mercury__set_bbbtree_module0();
	mercury__set_bbbtree_module1();
	mercury__set_bbbtree_module2();
	mercury__set_bbbtree_module3();
	mercury__set_bbbtree_module4();
	mercury__set_bbbtree_module5();
	mercury__set_bbbtree_module6();
	mercury__set_bbbtree_module7();
	mercury__set_bbbtree_module8();
	mercury__set_bbbtree_module9();
	mercury__set_bbbtree_module10();
	mercury__set_bbbtree_module11();
	mercury__set_bbbtree_module12();
	mercury__set_bbbtree_module13();
	mercury__set_bbbtree_module14();
	mercury__set_bbbtree_module15();
	mercury__set_bbbtree_module16();
	mercury__set_bbbtree_module17();
	mercury__set_bbbtree_module18();
	mercury__set_bbbtree_module19();
	mercury__set_bbbtree_module20();
	mercury__set_bbbtree_module21();
	mercury__set_bbbtree_module22();
	mercury__set_bbbtree_module23();
	mercury__set_bbbtree_module24();
	mercury__set_bbbtree_module25();
	mercury__set_bbbtree_module26();
	mercury__set_bbbtree_module27();
	mercury__set_bbbtree_module28();
	mercury__set_bbbtree_module29();
	mercury__set_bbbtree_module30();
	mercury__set_bbbtree_module31();
	mercury__set_bbbtree_module32();
	mercury__set_bbbtree_module33();
	mercury__set_bbbtree_module34();
	mercury__set_bbbtree_module35();
	mercury__set_bbbtree_module36();
	mercury__set_bbbtree_module37();
	mercury__set_bbbtree_module38();
	mercury__set_bbbtree_module39();
	mercury__set_bbbtree_module40();
}

static void mercury__set_bbbtree_bunch_1(void)
{
	mercury__set_bbbtree_module41();
	mercury__set_bbbtree_module42();
	mercury__set_bbbtree_module43();
	mercury__set_bbbtree_module44();
	mercury__set_bbbtree_module45();
	mercury__set_bbbtree_module46();
	mercury__set_bbbtree_module47();
	mercury__set_bbbtree_module48();
	mercury__set_bbbtree_module49();
	mercury__set_bbbtree_module50();
	mercury__set_bbbtree_module51();
	mercury__set_bbbtree_module52();
	mercury__set_bbbtree_module53();
	mercury__set_bbbtree_module54();
	mercury__set_bbbtree_module55();
	mercury__set_bbbtree_module56();
	mercury__set_bbbtree_module57();
	mercury__set_bbbtree_module58();
	mercury__set_bbbtree_module59();
	mercury__set_bbbtree_module60();
	mercury__set_bbbtree_module61();
	mercury__set_bbbtree_module62();
	mercury__set_bbbtree_module63();
	mercury__set_bbbtree_module64();
	mercury__set_bbbtree_module65();
	mercury__set_bbbtree_module66();
	mercury__set_bbbtree_module67();
	mercury__set_bbbtree_module68();
	mercury__set_bbbtree_module69();
}

#endif

void mercury__set_bbbtree__init(void); /* suppress gcc warning */
void mercury__set_bbbtree__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__set_bbbtree_bunch_0();
	mercury__set_bbbtree_bunch_1();
#endif
}
