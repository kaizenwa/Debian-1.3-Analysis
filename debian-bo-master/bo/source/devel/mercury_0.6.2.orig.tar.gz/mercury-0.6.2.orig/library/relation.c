/*
** Automatically generated from `relation.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__relation__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___relation_relation_1__ua10000_2_0);
Declare_static(mercury__relation__rtc_3__ua10000_8_0);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i2);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i3);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i5);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i6);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i7);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i8);
Declare_label(mercury__relation__rtc_3__ua10000_8_0_i9);
Declare_static(mercury__relation__rtc_2__ua10000_11_0);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i6);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i8);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i5);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i9);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i10);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i11);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i12);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i14);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i15);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i16);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i17);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i18);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i19);
Declare_label(mercury__relation__rtc_2__ua10000_11_0_i1004);
Declare_static(mercury__relation__rtc__ua10000_10_0);
Declare_label(mercury__relation__rtc__ua10000_10_0_i2);
Declare_label(mercury__relation__rtc__ua10000_10_0_i3);
Declare_label(mercury__relation__rtc__ua10000_10_0_i4);
Declare_label(mercury__relation__rtc__ua10000_10_0_i5);
Declare_label(mercury__relation__rtc__ua10000_10_0_i6);
Declare_label(mercury__relation__rtc__ua10000_10_0_i7);
Declare_label(mercury__relation__rtc__ua10000_10_0_i10);
Declare_label(mercury__relation__rtc__ua10000_10_0_i12);
Declare_label(mercury__relation__rtc__ua10000_10_0_i9);
Declare_static(mercury__relation__rtc_2__ua10000_6_0);
Declare_label(mercury__relation__rtc_2__ua10000_6_0_i6);
Declare_label(mercury__relation__rtc_2__ua10000_6_0_i8);
Declare_label(mercury__relation__rtc_2__ua10000_6_0_i9);
Declare_label(mercury__relation__rtc_2__ua10000_6_0_i5);
Declare_label(mercury__relation__rtc_2__ua10000_6_0_i1003);
Declare_static(mercury__relation__detect_fake_reflexives__ua10000_4_0);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i4);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i5);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i6);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i7);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i10);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i9);
Declare_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i1003);
Declare_static(mercury__relation__c_dfs_2__ua10000_6_0);
Declare_label(mercury__relation__c_dfs_2__ua10000_6_0_i2);
Declare_label(mercury__relation__c_dfs_2__ua10000_6_0_i3);
Declare_label(mercury__relation__c_dfs_2__ua10000_6_0_i4);
Declare_label(mercury__relation__c_dfs_2__ua10000_6_0_i5);
Declare_static(mercury__relation__c_dfs__ua10000_6_0);
Declare_label(mercury__relation__c_dfs__ua10000_6_0_i6);
Declare_label(mercury__relation__c_dfs__ua10000_6_0_i5);
Declare_label(mercury__relation__c_dfs__ua10000_6_0_i8);
Declare_label(mercury__relation__c_dfs__ua10000_6_0_i1003);
Declare_static(mercury__relation__check_tsort__ua0_3_0);
Declare_label(mercury__relation__check_tsort__ua0_3_0_i4);
Declare_label(mercury__relation__check_tsort__ua0_3_0_i5);
Declare_label(mercury__relation__check_tsort__ua0_3_0_i6);
Declare_label(mercury__relation__check_tsort__ua0_3_0_i7);
Declare_label(mercury__relation__check_tsort__ua0_3_0_i1003);
Declare_label(mercury__relation__check_tsort__ua0_3_0_i1);
Declare_static(mercury__relation__make_reduced_graph__ua10000_4_0);
Declare_label(mercury__relation__make_reduced_graph__ua10000_4_0_i4);
Declare_label(mercury__relation__make_reduced_graph__ua10000_4_0_i5);
Declare_label(mercury__relation__make_reduced_graph__ua10000_4_0_i6);
Declare_label(mercury__relation__make_reduced_graph__ua10000_4_0_i8);
Declare_label(mercury__relation__make_reduced_graph__ua10000_4_0_i1003);
Declare_static(mercury__relation__cliques_2__ua10000_5_0);
Declare_label(mercury__relation__cliques_2__ua10000_5_0_i4);
Declare_label(mercury__relation__cliques_2__ua10000_5_0_i5);
Declare_label(mercury__relation__cliques_2__ua10000_5_0_i6);
Declare_label(mercury__relation__cliques_2__ua10000_5_0_i7);
Declare_label(mercury__relation__cliques_2__ua10000_5_0_i1002);
Declare_static(mercury__relation__reachable_from__ua10000_4_0);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i4);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i8);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i7);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i11);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i12);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i13);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i14);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i15);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i16);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i17);
Declare_label(mercury__relation__reachable_from__ua10000_4_0_i3);
Declare_static(mercury__relation__components_2__ua10000_4_0);
Declare_label(mercury__relation__components_2__ua10000_4_0_i4);
Declare_label(mercury__relation__components_2__ua10000_4_0_i5);
Declare_label(mercury__relation__components_2__ua10000_4_0_i6);
Declare_label(mercury__relation__components_2__ua10000_4_0_i7);
Declare_label(mercury__relation__components_2__ua10000_4_0_i8);
Declare_label(mercury__relation__components_2__ua10000_4_0_i9);
Declare_label(mercury__relation__components_2__ua10000_4_0_i10);
Declare_label(mercury__relation__components_2__ua10000_4_0_i1002);
Declare_static(mercury__relation__is_dag_3__ua0_5_0);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i5);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i7);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i8);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i9);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i10);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i11);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i13);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i15);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i1006);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i1);
Declare_label(mercury__relation__is_dag_3__ua0_5_0_i1008);
Declare_static(mercury__relation__is_dag_2__ua0_4_0);
Declare_label(mercury__relation__is_dag_2__ua0_4_0_i6);
Declare_label(mercury__relation__is_dag_2__ua0_4_0_i5);
Declare_label(mercury__relation__is_dag_2__ua0_4_0_i8);
Declare_label(mercury__relation__is_dag_2__ua0_4_0_i1004);
Declare_label(mercury__relation__is_dag_2__ua0_4_0_i1);
Declare_static(mercury__relation__dfs_3__ua10000_6_0);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i6);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i5);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i9);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i10);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i11);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i12);
Declare_label(mercury__relation__dfs_3__ua10000_6_0_i1003);
Declare_static(mercury__relation__dfs_2__ua10000_5_0);
Declare_label(mercury__relation__dfs_2__ua10000_5_0_i4);
Declare_label(mercury__relation__dfs_2__ua10000_5_0_i1002);
Declare_static(mercury__relation__sc__ua10000_2_0);
Declare_label(mercury__relation__sc__ua10000_2_0_i2);
Declare_label(mercury__relation__sc__ua10000_2_0_i3);
Declare_static(mercury__relation__dfsrev__ua10000_5_0);
Declare_static(mercury__relation__dfs__ua10000_5_0);
Declare_label(mercury__relation__dfs__ua10000_5_0_i2);
Declare_label(mercury__relation__dfs__ua10000_5_0_i3);
Declare_static(mercury__relation__dfsrev__ua10000_3_0);
Declare_label(mercury__relation__dfsrev__ua10000_3_0_i2);
Declare_label(mercury__relation__dfsrev__ua10000_3_0_i3);
Declare_static(mercury__relation__dfs__ua10000_3_0);
Declare_label(mercury__relation__dfs__ua10000_3_0_i2);
Declare_static(mercury__relation__inverse__ua10000_2_0);
Declare_static(mercury__relation__to_assoc_list__ua10000_2_0);
Declare_label(mercury__relation__to_assoc_list__ua10000_2_0_i2);
Declare_static(mercury__relation__lookup_to__ua10000_3_0);
Declare_label(mercury__relation__lookup_to__ua10000_3_0_i4);
Declare_label(mercury__relation__lookup_to__ua10000_3_0_i1000);
Declare_static(mercury__relation__lookup_from__ua10000_3_0);
Declare_label(mercury__relation__lookup_from__ua10000_3_0_i4);
Declare_label(mercury__relation__lookup_from__ua10000_3_0_i1000);
Declare_static(mercury__relation__reverse_lookup__ua40000_3_0);
Declare_label(mercury__relation__reverse_lookup__ua40000_3_0_i1);
Declare_label(mercury__relation__reverse_lookup__ua40000_3_0_i3);
Declare_static(mercury__relation__reverse_lookup__ua1_3_0);
Declare_label(mercury__relation__reverse_lookup__ua1_3_0_i2);
Declare_label(mercury__relation__reverse_lookup__ua1_3_0_i1);
Declare_static(mercury__relation__lookup__ua40000_3_0);
Declare_label(mercury__relation__lookup__ua40000_3_0_i1);
Declare_label(mercury__relation__lookup__ua40000_3_0_i3);
Declare_static(mercury__relation__lookup__ua1_3_0);
Declare_label(mercury__relation__lookup__ua1_3_0_i2);
Declare_label(mercury__relation__lookup__ua1_3_0_i1);
Declare_static(mercury__relation__remove_assoc_list__ua10000_3_0);
Declare_label(mercury__relation__remove_assoc_list__ua10000_3_0_i4);
Declare_label(mercury__relation__remove_assoc_list__ua10000_3_0_i1002);
Declare_static(mercury__relation__remove__ua10000_4_0);
Declare_label(mercury__relation__remove__ua10000_4_0_i4);
Declare_label(mercury__relation__remove__ua10000_4_0_i6);
Declare_label(mercury__relation__remove__ua10000_4_0_i7);
Declare_label(mercury__relation__remove__ua10000_4_0_i3);
Declare_label(mercury__relation__remove__ua10000_4_0_i8);
Declare_label(mercury__relation__remove__ua10000_4_0_i11);
Declare_label(mercury__relation__remove__ua10000_4_0_i13);
Declare_label(mercury__relation__remove__ua10000_4_0_i14);
Declare_label(mercury__relation__remove__ua10000_4_0_i1005);
Declare_static(mercury__relation__add_assoc_list__ua10000_3_0);
Declare_label(mercury__relation__add_assoc_list__ua10000_3_0_i4);
Declare_label(mercury__relation__add_assoc_list__ua10000_3_0_i1002);
Declare_static(mercury__relation__add__ua10000_4_0);
Declare_label(mercury__relation__add__ua10000_4_0_i4);
Declare_label(mercury__relation__add__ua10000_4_0_i6);
Declare_label(mercury__relation__add__ua10000_4_0_i7);
Declare_label(mercury__relation__add__ua10000_4_0_i3);
Declare_label(mercury__relation__add__ua10000_4_0_i8);
Declare_label(mercury__relation__add__ua10000_4_0_i9);
Declare_label(mercury__relation__add__ua10000_4_0_i10);
Declare_label(mercury__relation__add__ua10000_4_0_i11);
Declare_label(mercury__relation__add__ua10000_4_0_i14);
Declare_label(mercury__relation__add__ua10000_4_0_i16);
Declare_label(mercury__relation__add__ua10000_4_0_i17);
Declare_label(mercury__relation__add__ua10000_4_0_i13);
Declare_label(mercury__relation__add__ua10000_4_0_i18);
Declare_label(mercury__relation__add__ua10000_4_0_i19);
Declare_label(mercury__relation__add__ua10000_4_0_i20);
Define_extern_entry(mercury__relation__init_1_0);
Declare_label(mercury__relation__init_1_0_i2);
Declare_label(mercury__relation__init_1_0_i3);
Declare_label(mercury__relation__init_1_0_i4);
Define_extern_entry(mercury__relation__add_element_4_0);
Declare_label(mercury__relation__add_element_4_0_i4);
Declare_label(mercury__relation__add_element_4_0_i3);
Declare_label(mercury__relation__add_element_4_0_i6);
Define_extern_entry(mercury__relation__search_element_3_0);
Declare_label(mercury__relation__search_element_3_0_i2);
Declare_label(mercury__relation__search_element_3_0_i1000);
Define_extern_entry(mercury__relation__lookup_element_3_0);
Declare_label(mercury__relation__lookup_element_3_0_i4);
Declare_label(mercury__relation__lookup_element_3_0_i1000);
Define_extern_entry(mercury__relation__search_key_3_0);
Declare_label(mercury__relation__search_key_3_0_i2);
Declare_label(mercury__relation__search_key_3_0_i1000);
Define_extern_entry(mercury__relation__lookup_key_3_0);
Declare_label(mercury__relation__lookup_key_3_0_i4);
Declare_label(mercury__relation__lookup_key_3_0_i1000);
Define_extern_entry(mercury__relation__add_4_0);
Define_extern_entry(mercury__relation__add_assoc_list_3_0);
Define_extern_entry(mercury__relation__remove_4_0);
Define_extern_entry(mercury__relation__remove_assoc_list_3_0);
Define_extern_entry(mercury__relation__lookup_3_1);
Define_extern_entry(mercury__relation__lookup_3_0);
Declare_label(mercury__relation__lookup_3_0_i1);
Define_extern_entry(mercury__relation__reverse_lookup_3_1);
Define_extern_entry(mercury__relation__reverse_lookup_3_0);
Declare_label(mercury__relation__reverse_lookup_3_0_i1);
Define_extern_entry(mercury__relation__lookup_from_3_0);
Define_extern_entry(mercury__relation__lookup_to_3_0);
Define_extern_entry(mercury__relation__to_assoc_list_2_0);
Define_extern_entry(mercury__relation__domain_2_0);
Declare_label(mercury__relation__domain_2_0_i2);
Define_extern_entry(mercury__relation__inverse_2_0);
Define_extern_entry(mercury__relation__dfs_3_0);
Define_extern_entry(mercury__relation__dfsrev_3_0);
Define_extern_entry(mercury__relation__dfs_2_0);
Declare_label(mercury__relation__dfs_2_0_i2);
Define_extern_entry(mercury__relation__dfsrev_2_0);
Declare_label(mercury__relation__dfsrev_2_0_i2);
Declare_label(mercury__relation__dfsrev_2_0_i3);
Define_extern_entry(mercury__relation__dfs_5_0);
Define_extern_entry(mercury__relation__dfsrev_5_0);
Define_extern_entry(mercury__relation__is_dag_1_0);
Declare_label(mercury__relation__is_dag_1_0_i2);
Declare_label(mercury__relation__is_dag_1_0_i3);
Declare_label(mercury__relation__is_dag_1_0_i4);
Define_extern_entry(mercury__relation__components_2_0);
Declare_label(mercury__relation__components_2_0_i2);
Declare_label(mercury__relation__components_2_0_i3);
Define_extern_entry(mercury__relation__cliques_2_0);
Declare_label(mercury__relation__cliques_2_0_i2);
Declare_label(mercury__relation__cliques_2_0_i3);
Declare_label(mercury__relation__cliques_2_0_i4);
Declare_label(mercury__relation__cliques_2_0_i5);
Define_extern_entry(mercury__relation__reduced_2_0);
Declare_label(mercury__relation__reduced_2_0_i2);
Declare_label(mercury__relation__reduced_2_0_i3);
Declare_label(mercury__relation__reduced_2_0_i4);
Declare_label(mercury__relation__reduced_2_0_i5);
Declare_label(mercury__relation__reduced_2_0_i6);
Declare_label(mercury__relation__reduced_2_0_i7);
Define_extern_entry(mercury__relation__tsort_2_0);
Declare_label(mercury__relation__tsort_2_0_i2);
Declare_label(mercury__relation__tsort_2_0_i3);
Declare_label(mercury__relation__tsort_2_0_i4);
Declare_label(mercury__relation__tsort_2_0_i5);
Declare_label(mercury__relation__tsort_2_0_i7);
Declare_label(mercury__relation__tsort_2_0_i1);
Define_extern_entry(mercury__relation__atsort_2_0);
Declare_label(mercury__relation__atsort_2_0_i2);
Declare_label(mercury__relation__atsort_2_0_i3);
Declare_label(mercury__relation__atsort_2_0_i4);
Declare_label(mercury__relation__atsort_2_0_i5);
Define_extern_entry(mercury__relation__sc_2_0);
Define_extern_entry(mercury__relation__tc_2_0);
Declare_label(mercury__relation__tc_2_0_i2);
Declare_label(mercury__relation__tc_2_0_i3);
Declare_label(mercury__relation__tc_2_0_i4);
Declare_label(mercury__relation__tc_2_0_i5);
Define_extern_entry(mercury__relation__rtc_2_0);
Declare_label(mercury__relation__rtc_2_0_i2);
Declare_label(mercury__relation__rtc_2_0_i3);
Declare_label(mercury__relation__rtc_2_0_i4);
Declare_label(mercury__relation__rtc_2_0_i5);
Declare_label(mercury__relation__rtc_2_0_i6);
Declare_static(mercury__relation__to_assoc_list_2_3_0);
Declare_label(mercury__relation__to_assoc_list_2_3_0_i4);
Declare_label(mercury__relation__to_assoc_list_2_3_0_i5);
Declare_label(mercury__relation__to_assoc_list_2_3_0_i6);
Declare_label(mercury__relation__to_assoc_list_2_3_0_i7);
Declare_label(mercury__relation__to_assoc_list_2_3_0_i1002);
Declare_static(mercury__relation__append_to_3_0);
Declare_label(mercury__relation__append_to_3_0_i3);
Declare_label(mercury__relation__append_to_3_0_i4);
Declare_label(mercury__relation__append_to_3_0_i1);
Declare_static(mercury__relation__domain_sorted_list_2_0);
Declare_static(mercury__relation__make_clique_map_6_0);
Declare_label(mercury__relation__make_clique_map_6_0_i4);
Declare_label(mercury__relation__make_clique_map_6_0_i5);
Declare_label(mercury__relation__make_clique_map_6_0_i6);
Declare_label(mercury__relation__make_clique_map_6_0_i7);
Declare_label(mercury__relation__make_clique_map_6_0_i8);
Declare_label(mercury__relation__make_clique_map_6_0_i1003);
Declare_static(mercury__relation__make_clique_map_2_4_0);
Declare_label(mercury__relation__make_clique_map_2_4_0_i4);
Declare_label(mercury__relation__make_clique_map_2_4_0_i1002);
Declare_static(mercury__relation__atsort_2_5_0);
Declare_label(mercury__relation__atsort_2_5_0_i6);
Declare_label(mercury__relation__atsort_2_5_0_i5);
Declare_label(mercury__relation__atsort_2_5_0_i9);
Declare_label(mercury__relation__atsort_2_5_0_i10);
Declare_label(mercury__relation__atsort_2_5_0_i11);
Declare_label(mercury__relation__atsort_2_5_0_i1005);
Declare_static(mercury__relation__rtc__init_map_3_0);
Declare_label(mercury__relation__rtc__init_map_3_0_i4);
Declare_label(mercury__relation__rtc__init_map_3_0_i1002);
Define_extern_entry(mercury____Unify___relation__relation_1_0);
Declare_label(mercury____Unify___relation__relation_1_0_i2);
Declare_label(mercury____Unify___relation__relation_1_0_i4);
Declare_label(mercury____Unify___relation__relation_1_0_i1004);
Declare_label(mercury____Unify___relation__relation_1_0_i1);
Define_extern_entry(mercury____Index___relation__relation_1_0);
Define_extern_entry(mercury____Compare___relation__relation_1_0);
Declare_label(mercury____Compare___relation__relation_1_0_i4);
Declare_label(mercury____Compare___relation__relation_1_0_i5);
Declare_label(mercury____Compare___relation__relation_1_0_i3);
Declare_label(mercury____Compare___relation__relation_1_0_i10);
Declare_label(mercury____Compare___relation__relation_1_0_i16);
Define_extern_entry(mercury____Unify___relation__relation_key_0_0);
Declare_label(mercury____Unify___relation__relation_key_0_0_i1);
Define_extern_entry(mercury____Index___relation__relation_key_0_0);
Define_extern_entry(mercury____Compare___relation__relation_key_0_0);

extern Word * mercury_data_relation__base_type_layout_relation_1[];
Word * mercury_data_relation__base_type_info_relation_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___relation__relation_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___relation__relation_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___relation__relation_1_0),
	(Word *) (Integer) mercury_data_relation__base_type_layout_relation_1
};

extern Word * mercury_data_relation__base_type_layout_relation_key_0[];
Word * mercury_data_relation__base_type_info_relation_key_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___relation__relation_key_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___relation__relation_key_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___relation__relation_key_0_0),
	(Word *) (Integer) mercury_data_relation__base_type_layout_relation_key_0
};

extern Word * mercury_data_relation__common_3[];
Word * mercury_data_relation__base_type_layout_relation_key_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_relation__common_3),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_relation__common_3),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_relation__common_3),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_relation__common_3)
};

extern Word * mercury_data_relation__common_6[];
Word * mercury_data_relation__base_type_layout_relation_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_relation__common_6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_set__base_type_info_set_1[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_relation__common_0[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_std_util__base_type_info_pair_2[];
Word * mercury_data_relation__common_1[] = {
	(Word *) (Integer) mercury_data_std_util__base_type_info_pair_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_relation__common_2[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_relation__common_3[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_2)
};

extern Word * mercury_data_bimap__base_type_info_bimap_2[];
Word * mercury_data_relation__common_4[] = {
	(Word *) (Integer) mercury_data_bimap__base_type_info_bimap_2,
	(Word *) ((Integer) 1),
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_relation__common_5[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0)
};

Word * mercury_data_relation__common_6[] = {
	(Word *) ((Integer) 4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_4),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_5),
	(Word *) string_const("relation", 8)
};

BEGIN_MODULE(mercury__relation_module0)
	init_entry(mercury____Index___relation_relation_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___relation_relation_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___relation_relation_1__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module1)
	init_entry(mercury__relation__rtc_3__ua10000_8_0);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i2);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i3);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i5);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i6);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i7);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i8);
	init_label(mercury__relation__rtc_3__ua10000_8_0_i9);
BEGIN_CODE

/* code for predicate 'rtc_3__ua10000'/8 in mode 0 */
Define_static(mercury__relation__rtc_3__ua10000_8_0);
	incr_sp_push_msg(7, "rtc_3__ua10000");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r5;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) r4;
	{
	Declare_entry(mercury__stack__pop_det_3_0);
	call_localret(ENTRY(mercury__stack__pop_det_3_0),
		mercury__relation__rtc_3__ua10000_8_0_i2,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
	}
Define_label(mercury__relation__rtc_3__ua10000_8_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__rtc_3__ua10000_8_0));
	if (((Integer) detstackvar(2) != (Integer) r1))
		GOTO_LABEL(mercury__relation__rtc_3__ua10000_8_0_i3);
	r1 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__relation__rtc_3__ua10000_8_0_i3);
	detstackvar(5) = (Integer) r1;
	detstackvar(6) = (Integer) r2;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__rtc_3__ua10000_8_0_i5,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
Define_label(mercury__relation__rtc_3__ua10000_8_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__rtc_3__ua10000_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__rtc_3__ua10000_8_0_i6,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
	}
Define_label(mercury__relation__rtc_3__ua10000_8_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__rtc_3__ua10000_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__relation__append_to_3_0),
		mercury__relation__rtc_3__ua10000_8_0_i7,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
Define_label(mercury__relation__rtc_3__ua10000_8_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__rtc_3__ua10000_8_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__relation__add_assoc_list__ua10000_3_0),
		mercury__relation__rtc_3__ua10000_8_0_i8,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
Define_label(mercury__relation__rtc_3__ua10000_8_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__rtc_3__ua10000_8_0));
	r3 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(5);
	r5 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__relation__rtc_3__ua10000_8_0_i9,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
	}
Define_label(mercury__relation__rtc_3__ua10000_8_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__rtc_3__ua10000_8_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__relation__rtc_3__ua10000_8_0,
		STATIC(mercury__relation__rtc_3__ua10000_8_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module2)
	init_entry(mercury__relation__rtc_2__ua10000_11_0);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i6);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i8);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i5);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i9);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i10);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i11);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i12);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i14);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i15);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i16);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i17);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i18);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i19);
	init_label(mercury__relation__rtc_2__ua10000_11_0_i1004);
BEGIN_CODE

/* code for predicate 'rtc_2__ua10000'/11 in mode 0 */
Define_static(mercury__relation__rtc_2__ua10000_11_0);
	if (((Integer) r5 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__rtc_2__ua10000_11_0_i1004);
	incr_sp_push_msg(14, "rtc_2__ua10000");
	detstackvar(14) = (Integer) succip;
	detstackvar(4) = (Integer) r4;
	detstackvar(3) = (Integer) r3;
	r4 = (Integer) field(mktag(1), (Integer) r5, ((Integer) 0));
	detstackvar(8) = (Integer) r4;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(9) = (Integer) field(mktag(1), (Integer) r5, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r7;
	r5 = ((Integer) 0);
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = (Integer) r8;
	{
	Declare_entry(mercury__map__lookup_3_0);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__relation__rtc_2__ua10000_11_0_i6,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
	}
Define_label(mercury__relation__rtc_2__ua10000_11_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__rtc_2__ua10000_11_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(8);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(5);
	r6 = (Integer) detstackvar(6);
	r7 = (Integer) detstackvar(7);
	call_localret(STATIC(mercury__relation__rtc__ua10000_10_0),
		mercury__relation__rtc_2__ua10000_11_0_i8,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
Define_label(mercury__relation__rtc_2__ua10000_11_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) r1;
	r11 = (Integer) r3;
	r3 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	GOTO_LABEL(mercury__relation__rtc_2__ua10000_11_0_i9);
Define_label(mercury__relation__rtc_2__ua10000_11_0_i5);
	r5 = (Integer) detstackvar(1);
	r6 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	r8 = (Integer) detstackvar(8);
	r9 = (Integer) detstackvar(9);
	r10 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(6);
	r11 = (Integer) detstackvar(7);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
Define_label(mercury__relation__rtc_2__ua10000_11_0_i9);
	detstackvar(1) = (Integer) r5;
	detstackvar(2) = (Integer) r6;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r7;
	detstackvar(8) = (Integer) r8;
	detstackvar(9) = (Integer) r9;
	detstackvar(10) = (Integer) r10;
	detstackvar(11) = (Integer) r3;
	detstackvar(12) = (Integer) r11;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__relation__rtc_2__ua10000_11_0_i10,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
	}
Define_label(mercury__relation__rtc_2__ua10000_11_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	detstackvar(13) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(8);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__relation__rtc_2__ua10000_11_0_i11,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
	}
Define_label(mercury__relation__rtc_2__ua10000_11_0_i11);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	if (((Integer) detstackvar(13) > (Integer) r1))
		GOTO_LABEL(mercury__relation__rtc_2__ua10000_11_0_i12);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r1 = (Integer) detstackvar(12);
	r9 = (Integer) detstackvar(11);
	GOTO_LABEL(mercury__relation__rtc_2__ua10000_11_0_i15);
Define_label(mercury__relation__rtc_2__ua10000_11_0_i12);
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(11);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__relation__rtc_2__ua10000_11_0_i14,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
	}
Define_label(mercury__relation__rtc_2__ua10000_11_0_i14);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	r6 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(8);
	r7 = (Integer) detstackvar(9);
	r8 = (Integer) detstackvar(10);
	r9 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
Define_label(mercury__relation__rtc_2__ua10000_11_0_i15);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) r6;
	detstackvar(9) = (Integer) r7;
	detstackvar(10) = (Integer) r8;
	detstackvar(12) = (Integer) r1;
	detstackvar(11) = (Integer) r9;
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__rtc_2__ua10000_11_0_i16,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
Define_label(mercury__relation__rtc_2__ua10000_11_0_i16);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__rtc_2__ua10000_11_0_i17,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
	}
Define_label(mercury__relation__rtc_2__ua10000_11_0_i17);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__append_to_3_0),
		mercury__relation__rtc_2__ua10000_11_0_i18,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
Define_label(mercury__relation__rtc_2__ua10000_11_0_i18);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(12);
	call_localret(STATIC(mercury__relation__add_assoc_list__ua10000_3_0),
		mercury__relation__rtc_2__ua10000_11_0_i19,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
Define_label(mercury__relation__rtc_2__ua10000_11_0_i19);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_11_0));
	r8 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(9);
	r6 = (Integer) detstackvar(10);
	r7 = (Integer) detstackvar(11);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(14);
	decr_sp_pop_msg(14);
	localtailcall(mercury__relation__rtc_2__ua10000_11_0,
		STATIC(mercury__relation__rtc_2__ua10000_11_0));
Define_label(mercury__relation__rtc_2__ua10000_11_0_i1004);
	r1 = (Integer) r6;
	r2 = (Integer) r7;
	r3 = (Integer) r8;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module3)
	init_entry(mercury__relation__rtc__ua10000_10_0);
	init_label(mercury__relation__rtc__ua10000_10_0_i2);
	init_label(mercury__relation__rtc__ua10000_10_0_i3);
	init_label(mercury__relation__rtc__ua10000_10_0_i4);
	init_label(mercury__relation__rtc__ua10000_10_0_i5);
	init_label(mercury__relation__rtc__ua10000_10_0_i6);
	init_label(mercury__relation__rtc__ua10000_10_0_i7);
	init_label(mercury__relation__rtc__ua10000_10_0_i10);
	init_label(mercury__relation__rtc__ua10000_10_0_i12);
	init_label(mercury__relation__rtc__ua10000_10_0_i9);
BEGIN_CODE

/* code for predicate 'rtc__ua10000'/10 in mode 0 */
Define_static(mercury__relation__rtc__ua10000_10_0);
	incr_sp_push_msg(9, "rtc__ua10000");
	detstackvar(9) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	detstackvar(4) = (Integer) r4;
	detstackvar(5) = (Integer) r6;
	detstackvar(6) = (Integer) r7;
	detstackvar(7) = ((Integer) r4 + ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) r5;
	{
	Declare_entry(mercury__stack__push_3_0);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__relation__rtc__ua10000_10_0_i2,
		STATIC(mercury__relation__rtc__ua10000_10_0));
	}
Define_label(mercury__relation__rtc__ua10000_10_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	r3 = (Integer) detstackvar(5);
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__relation__rtc__ua10000_10_0_i3,
		STATIC(mercury__relation__rtc__ua10000_10_0));
	}
Define_label(mercury__relation__rtc__ua10000_10_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	r2 = (Integer) detstackvar(6);
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) r2;
	call_localret(STATIC(mercury__relation__add__ua10000_4_0),
		mercury__relation__rtc__ua10000_10_0_i4,
		STATIC(mercury__relation__rtc__ua10000_10_0));
Define_label(mercury__relation__rtc__ua10000_10_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	detstackvar(8) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__rtc__ua10000_10_0_i5,
		STATIC(mercury__relation__rtc__ua10000_10_0));
Define_label(mercury__relation__rtc__ua10000_10_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__rtc__ua10000_10_0_i6,
		STATIC(mercury__relation__rtc__ua10000_10_0));
	}
Define_label(mercury__relation__rtc__ua10000_10_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	r6 = (Integer) detstackvar(5);
	r7 = (Integer) detstackvar(6);
	r8 = (Integer) detstackvar(8);
	call_localret(STATIC(mercury__relation__rtc_2__ua10000_11_0),
		mercury__relation__rtc__ua10000_10_0_i7,
		STATIC(mercury__relation__rtc__ua10000_10_0));
Define_label(mercury__relation__rtc__ua10000_10_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	r5 = (Integer) detstackvar(4);
	detstackvar(5) = (Integer) r3;
	r3 = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__map__lookup_3_0);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__relation__rtc__ua10000_10_0_i10,
		STATIC(mercury__relation__rtc__ua10000_10_0));
	}
Define_label(mercury__relation__rtc__ua10000_10_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__rtc__ua10000_10_0_i9);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__relation__rtc_3__ua10000_8_0),
		mercury__relation__rtc__ua10000_10_0_i12,
		STATIC(mercury__relation__rtc__ua10000_10_0));
Define_label(mercury__relation__rtc__ua10000_10_0_i12);
	update_prof_current_proc(LABEL(mercury__relation__rtc__ua10000_10_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) tempr1;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__relation__rtc__ua10000_10_0_i9);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(9);
	decr_sp_pop_msg(9);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module4)
	init_entry(mercury__relation__rtc_2__ua10000_6_0);
	init_label(mercury__relation__rtc_2__ua10000_6_0_i6);
	init_label(mercury__relation__rtc_2__ua10000_6_0_i8);
	init_label(mercury__relation__rtc_2__ua10000_6_0_i9);
	init_label(mercury__relation__rtc_2__ua10000_6_0_i5);
	init_label(mercury__relation__rtc_2__ua10000_6_0_i1003);
BEGIN_CODE

/* code for predicate 'relation__rtc_2__ua10000'/6 in mode 0 */
Define_static(mercury__relation__rtc_2__ua10000_6_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__rtc_2__ua10000_6_0_i1003);
	incr_sp_push_msg(7, "relation__rtc_2__ua10000");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(6) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) r4;
	detstackvar(5) = (Integer) tempr1;
	r3 = (Integer) r4;
	r4 = (Integer) tempr1;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(4) = (Integer) r5;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r5 = ((Integer) 0);
	{
	Declare_entry(mercury__map__lookup_3_0);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__relation__rtc_2__ua10000_6_0_i6,
		STATIC(mercury__relation__rtc_2__ua10000_6_0));
	}
	}
Define_label(mercury__relation__rtc_2__ua10000_6_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__rtc_2__ua10000_6_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__stack__init_1_0);
	call_localret(ENTRY(mercury__stack__init_1_0),
		mercury__relation__rtc_2__ua10000_6_0_i8,
		STATIC(mercury__relation__rtc_2__ua10000_6_0));
	}
Define_label(mercury__relation__rtc_2__ua10000_6_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	r4 = ((Integer) 1);
	r6 = (Integer) detstackvar(3);
	r7 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__relation__rtc__ua10000_10_0),
		mercury__relation__rtc_2__ua10000_6_0_i9,
		STATIC(mercury__relation__rtc_2__ua10000_6_0));
Define_label(mercury__relation__rtc_2__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2__ua10000_6_0));
	r4 = (Integer) r2;
	r5 = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__relation__rtc_2__ua10000_6_0,
		STATIC(mercury__relation__rtc_2__ua10000_6_0));
Define_label(mercury__relation__rtc_2__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__relation__rtc_2__ua10000_6_0,
		STATIC(mercury__relation__rtc_2__ua10000_6_0));
Define_label(mercury__relation__rtc_2__ua10000_6_0_i1003);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module5)
	init_entry(mercury__relation__detect_fake_reflexives__ua10000_4_0);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i4);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i5);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i6);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i7);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i10);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i9);
	init_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i1003);
BEGIN_CODE

/* code for predicate 'relation__detect_fake_reflexives__ua10000'/4 in mode 0 */
Define_static(mercury__relation__detect_fake_reflexives__ua10000_4_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0_i1003);
	incr_sp_push_msg(4, "relation__detect_fake_reflexives__ua10000");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	localcall(mercury__relation__detect_fake_reflexives__ua10000_4_0,
		LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0_i4),
		STATIC(mercury__relation__detect_fake_reflexives__ua10000_4_0));
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__detect_fake_reflexives__ua10000_4_0_i5,
		STATIC(mercury__relation__detect_fake_reflexives__ua10000_4_0));
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__lookup_to__ua10000_3_0),
		mercury__relation__detect_fake_reflexives__ua10000_4_0_i6,
		STATIC(mercury__relation__detect_fake_reflexives__ua10000_4_0));
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__relation__detect_fake_reflexives__ua10000_4_0_i7,
		STATIC(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	}
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__empty_1_0);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__relation__detect_fake_reflexives__ua10000_4_0_i10,
		STATIC(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	}
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__detect_fake_reflexives__ua10000_4_0_i9);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i9);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__relation__detect_fake_reflexives__ua10000_4_0_i1003);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module6)
	init_entry(mercury__relation__c_dfs_2__ua10000_6_0);
	init_label(mercury__relation__c_dfs_2__ua10000_6_0_i2);
	init_label(mercury__relation__c_dfs_2__ua10000_6_0_i3);
	init_label(mercury__relation__c_dfs_2__ua10000_6_0_i4);
	init_label(mercury__relation__c_dfs_2__ua10000_6_0_i5);
BEGIN_CODE

/* code for predicate 'relation__c_dfs_2__ua10000'/6 in mode 0 */
Define_static(mercury__relation__c_dfs_2__ua10000_6_0);
	incr_sp_push_msg(5, "relation__c_dfs_2__ua10000");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) r3;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__c_dfs_2__ua10000_6_0_i2,
		STATIC(mercury__relation__c_dfs_2__ua10000_6_0));
	}
Define_label(mercury__relation__c_dfs_2__ua10000_6_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__c_dfs_2__ua10000_6_0));
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__c_dfs_2__ua10000_6_0_i3,
		STATIC(mercury__relation__c_dfs_2__ua10000_6_0));
Define_label(mercury__relation__c_dfs_2__ua10000_6_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__c_dfs_2__ua10000_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__c_dfs_2__ua10000_6_0_i4,
		STATIC(mercury__relation__c_dfs_2__ua10000_6_0));
	}
Define_label(mercury__relation__c_dfs_2__ua10000_6_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__c_dfs_2__ua10000_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__c_dfs__ua10000_6_0),
		mercury__relation__c_dfs_2__ua10000_6_0_i5,
		STATIC(mercury__relation__c_dfs_2__ua10000_6_0));
Define_label(mercury__relation__c_dfs_2__ua10000_6_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__c_dfs_2__ua10000_6_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module7)
	init_entry(mercury__relation__c_dfs__ua10000_6_0);
	init_label(mercury__relation__c_dfs__ua10000_6_0_i6);
	init_label(mercury__relation__c_dfs__ua10000_6_0_i5);
	init_label(mercury__relation__c_dfs__ua10000_6_0_i8);
	init_label(mercury__relation__c_dfs__ua10000_6_0_i1003);
BEGIN_CODE

/* code for predicate 'relation__c_dfs__ua10000'/6 in mode 0 */
Define_static(mercury__relation__c_dfs__ua10000_6_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__c_dfs__ua10000_6_0_i1003);
	incr_sp_push_msg(6, "relation__c_dfs__ua10000");
	detstackvar(6) = (Integer) succip;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__relation__c_dfs__ua10000_6_0_i6,
		STATIC(mercury__relation__c_dfs__ua10000_6_0));
	}
Define_label(mercury__relation__c_dfs__ua10000_6_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__c_dfs__ua10000_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__c_dfs__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__c_dfs__ua10000_6_0,
		STATIC(mercury__relation__c_dfs__ua10000_6_0));
Define_label(mercury__relation__c_dfs__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__c_dfs_2__ua10000_6_0),
		mercury__relation__c_dfs__ua10000_6_0_i8,
		STATIC(mercury__relation__c_dfs__ua10000_6_0));
Define_label(mercury__relation__c_dfs__ua10000_6_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__c_dfs__ua10000_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__c_dfs__ua10000_6_0,
		STATIC(mercury__relation__c_dfs__ua10000_6_0));
Define_label(mercury__relation__c_dfs__ua10000_6_0_i1003);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module8)
	init_entry(mercury__relation__check_tsort__ua0_3_0);
	init_label(mercury__relation__check_tsort__ua0_3_0_i4);
	init_label(mercury__relation__check_tsort__ua0_3_0_i5);
	init_label(mercury__relation__check_tsort__ua0_3_0_i6);
	init_label(mercury__relation__check_tsort__ua0_3_0_i7);
	init_label(mercury__relation__check_tsort__ua0_3_0_i1003);
	init_label(mercury__relation__check_tsort__ua0_3_0_i1);
BEGIN_CODE

/* code for predicate 'relation__check_tsort__ua0'/3 in mode 0 */
Define_static(mercury__relation__check_tsort__ua0_3_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__check_tsort__ua0_3_0_i1003);
	incr_sp_push_msg(4, "relation__check_tsort__ua0");
	detstackvar(4) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(1) = (Integer) r1;
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__check_tsort__ua0_3_0_i4,
		STATIC(mercury__relation__check_tsort__ua0_3_0));
	}
Define_label(mercury__relation__check_tsort__ua0_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__check_tsort__ua0_3_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__check_tsort__ua0_3_0_i5,
		STATIC(mercury__relation__check_tsort__ua0_3_0));
Define_label(mercury__relation__check_tsort__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__check_tsort__ua0_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__intersect_3_0);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__relation__check_tsort__ua0_3_0_i6,
		STATIC(mercury__relation__check_tsort__ua0_3_0));
	}
Define_label(mercury__relation__check_tsort__ua0_3_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__check_tsort__ua0_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__empty_1_0);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__relation__check_tsort__ua0_3_0_i7,
		STATIC(mercury__relation__check_tsort__ua0_3_0));
	}
Define_label(mercury__relation__check_tsort__ua0_3_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__check_tsort__ua0_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__check_tsort__ua0_3_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__relation__check_tsort__ua0_3_0,
		STATIC(mercury__relation__check_tsort__ua0_3_0));
Define_label(mercury__relation__check_tsort__ua0_3_0_i1003);
	r1 = TRUE;
	proceed();
Define_label(mercury__relation__check_tsort__ua0_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module9)
	init_entry(mercury__relation__make_reduced_graph__ua10000_4_0);
	init_label(mercury__relation__make_reduced_graph__ua10000_4_0_i4);
	init_label(mercury__relation__make_reduced_graph__ua10000_4_0_i5);
	init_label(mercury__relation__make_reduced_graph__ua10000_4_0_i6);
	init_label(mercury__relation__make_reduced_graph__ua10000_4_0_i8);
	init_label(mercury__relation__make_reduced_graph__ua10000_4_0_i1003);
BEGIN_CODE

/* code for predicate 'relation__make_reduced_graph__ua10000'/4 in mode 0 */
Define_static(mercury__relation__make_reduced_graph__ua10000_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__make_reduced_graph__ua10000_4_0_i1003);
	incr_sp_push_msg(5, "relation__make_reduced_graph__ua10000");
	detstackvar(5) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r4 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__relation__make_reduced_graph__ua10000_4_0_i4,
		STATIC(mercury__relation__make_reduced_graph__ua10000_4_0));
	}
	}
Define_label(mercury__relation__make_reduced_graph__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__make_reduced_graph__ua10000_4_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__relation__make_reduced_graph__ua10000_4_0_i5,
		STATIC(mercury__relation__make_reduced_graph__ua10000_4_0));
	}
Define_label(mercury__relation__make_reduced_graph__ua10000_4_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__make_reduced_graph__ua10000_4_0));
	if (((Integer) detstackvar(3) != (Integer) r1))
		GOTO_LABEL(mercury__relation__make_reduced_graph__ua10000_4_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__relation__make_reduced_graph__ua10000_4_0,
		STATIC(mercury__relation__make_reduced_graph__ua10000_4_0));
Define_label(mercury__relation__make_reduced_graph__ua10000_4_0_i6);
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__add__ua10000_4_0),
		mercury__relation__make_reduced_graph__ua10000_4_0_i8,
		STATIC(mercury__relation__make_reduced_graph__ua10000_4_0));
Define_label(mercury__relation__make_reduced_graph__ua10000_4_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__make_reduced_graph__ua10000_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__relation__make_reduced_graph__ua10000_4_0,
		STATIC(mercury__relation__make_reduced_graph__ua10000_4_0));
Define_label(mercury__relation__make_reduced_graph__ua10000_4_0_i1003);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module10)
	init_entry(mercury__relation__cliques_2__ua10000_5_0);
	init_label(mercury__relation__cliques_2__ua10000_5_0_i4);
	init_label(mercury__relation__cliques_2__ua10000_5_0_i5);
	init_label(mercury__relation__cliques_2__ua10000_5_0_i6);
	init_label(mercury__relation__cliques_2__ua10000_5_0_i7);
	init_label(mercury__relation__cliques_2__ua10000_5_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__cliques_2__ua10000'/5 in mode 0 */
Define_static(mercury__relation__cliques_2__ua10000_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__cliques_2__ua10000_5_0_i1002);
	incr_sp_push_msg(6, "relation__cliques_2__ua10000");
	detstackvar(6) = (Integer) succip;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) r4;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	detstackvar(1) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__relation__dfs_3__ua10000_6_0),
		mercury__relation__cliques_2__ua10000_5_0_i4,
		STATIC(mercury__relation__cliques_2__ua10000_5_0));
	}
Define_label(mercury__relation__cliques_2__ua10000_5_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2__ua10000_5_0));
	detstackvar(4) = (Integer) r1;
	detstackvar(5) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__relation__cliques_2__ua10000_5_0_i5,
		STATIC(mercury__relation__cliques_2__ua10000_5_0));
	}
Define_label(mercury__relation__cliques_2__ua10000_5_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2__ua10000_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__cliques_2__ua10000_5_0_i6,
		STATIC(mercury__relation__cliques_2__ua10000_5_0));
	}
Define_label(mercury__relation__cliques_2__ua10000_5_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2__ua10000_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__list__delete_elems_3_0);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__relation__cliques_2__ua10000_5_0_i7,
		STATIC(mercury__relation__cliques_2__ua10000_5_0));
	}
Define_label(mercury__relation__cliques_2__ua10000_5_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2__ua10000_5_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__cliques_2__ua10000_5_0,
		STATIC(mercury__relation__cliques_2__ua10000_5_0));
Define_label(mercury__relation__cliques_2__ua10000_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module11)
	init_entry(mercury__relation__reachable_from__ua10000_4_0);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i4);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i8);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i7);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i11);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i12);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i13);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i14);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i15);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i16);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i17);
	init_label(mercury__relation__reachable_from__ua10000_4_0_i3);
BEGIN_CODE

/* code for predicate 'relation__reachable_from__ua10000'/4 in mode 0 */
Define_static(mercury__relation__reachable_from__ua10000_4_0);
	incr_sp_push_msg(6, "relation__reachable_from__ua10000");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) r3;
	{
	Declare_entry(mercury__queue__get_3_0);
	call_localret(ENTRY(mercury__queue__get_3_0),
		mercury__relation__reachable_from__ua10000_4_0_i4,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__reachable_from__ua10000_4_0_i3);
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__member_2_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__relation__reachable_from__ua10000_4_0_i8,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__reachable_from__ua10000_4_0_i7);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__reachable_from__ua10000_4_0,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
Define_label(mercury__relation__reachable_from__ua10000_4_0_i7);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__reachable_from__ua10000_4_0_i11,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
Define_label(mercury__relation__reachable_from__ua10000_4_0_i11);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__relation__lookup_to__ua10000_3_0),
		mercury__relation__reachable_from__ua10000_4_0_i12,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
Define_label(mercury__relation__reachable_from__ua10000_4_0_i12);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__union_3_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__relation__reachable_from__ua10000_4_0_i13,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i13);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__relation__reachable_from__ua10000_4_0_i14,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i14);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__reachable_from__ua10000_4_0_i15,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i15);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__queue__put_list_3_0);
	call_localret(ENTRY(mercury__queue__put_list_3_0),
		mercury__relation__reachable_from__ua10000_4_0_i16,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i16);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__reachable_from__ua10000_4_0_i17,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
	}
Define_label(mercury__relation__reachable_from__ua10000_4_0_i17);
	update_prof_current_proc(LABEL(mercury__relation__reachable_from__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__reachable_from__ua10000_4_0,
		STATIC(mercury__relation__reachable_from__ua10000_4_0));
Define_label(mercury__relation__reachable_from__ua10000_4_0_i3);
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module12)
	init_entry(mercury__relation__components_2__ua10000_4_0);
	init_label(mercury__relation__components_2__ua10000_4_0_i4);
	init_label(mercury__relation__components_2__ua10000_4_0_i5);
	init_label(mercury__relation__components_2__ua10000_4_0_i6);
	init_label(mercury__relation__components_2__ua10000_4_0_i7);
	init_label(mercury__relation__components_2__ua10000_4_0_i8);
	init_label(mercury__relation__components_2__ua10000_4_0_i9);
	init_label(mercury__relation__components_2__ua10000_4_0_i10);
	init_label(mercury__relation__components_2__ua10000_4_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__components_2__ua10000'/4 in mode 0 */
Define_static(mercury__relation__components_2__ua10000_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__components_2__ua10000_4_0_i1002);
	incr_sp_push_msg(5, "relation__components_2__ua10000");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__relation__components_2__ua10000_4_0_i4,
		STATIC(mercury__relation__components_2__ua10000_4_0));
	}
Define_label(mercury__relation__components_2__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	{
	Declare_entry(mercury__queue__list_to_queue_2_0);
	call_localret(ENTRY(mercury__queue__list_to_queue_2_0),
		mercury__relation__components_2__ua10000_4_0_i5,
		STATIC(mercury__relation__components_2__ua10000_4_0));
	}
Define_label(mercury__relation__components_2__ua10000_4_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__reachable_from__ua10000_4_0),
		mercury__relation__components_2__ua10000_4_0_i6,
		STATIC(mercury__relation__components_2__ua10000_4_0));
Define_label(mercury__relation__components_2__ua10000_4_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__components_2__ua10000_4_0_i7,
		STATIC(mercury__relation__components_2__ua10000_4_0));
	}
Define_label(mercury__relation__components_2__ua10000_4_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__relation__components_2__ua10000_4_0_i8,
		STATIC(mercury__relation__components_2__ua10000_4_0));
	}
Define_label(mercury__relation__components_2__ua10000_4_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__difference_3_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__relation__components_2__ua10000_4_0_i9,
		STATIC(mercury__relation__components_2__ua10000_4_0));
	}
Define_label(mercury__relation__components_2__ua10000_4_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__components_2__ua10000_4_0_i10,
		STATIC(mercury__relation__components_2__ua10000_4_0));
	}
Define_label(mercury__relation__components_2__ua10000_4_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__components_2__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury__relation__components_2__ua10000_4_0,
		STATIC(mercury__relation__components_2__ua10000_4_0));
Define_label(mercury__relation__components_2__ua10000_4_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module13)
	init_entry(mercury__relation__is_dag_3__ua0_5_0);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i5);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i7);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i8);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i9);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i10);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i11);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i13);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i15);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i1006);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i1);
	init_label(mercury__relation__is_dag_3__ua0_5_0_i1008);
BEGIN_CODE

/* code for predicate 'relation__is_dag_3__ua0'/5 in mode 0 */
Define_static(mercury__relation__is_dag_3__ua0_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__is_dag_3__ua0_5_0_i1006);
	incr_sp_push_msg(7, "relation__is_dag_3__ua0");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__set_bbbtree__member_2_0);
	call_localret(ENTRY(mercury__set_bbbtree__member_2_0),
		mercury__relation__is_dag_3__ua0_5_0_i5,
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
	}
Define_label(mercury__relation__is_dag_3__ua0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__relation__is_dag_3__ua0_5_0_i1);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__is_dag_3__ua0_5_0_i7,
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
Define_label(mercury__relation__is_dag_3__ua0_5_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__is_dag_3__ua0_5_0_i8,
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
	}
Define_label(mercury__relation__is_dag_3__ua0_5_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set_bbbtree__insert_3_1);
	call_localret(ENTRY(mercury__set_bbbtree__insert_3_1),
		mercury__relation__is_dag_3__ua0_5_0_i9,
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
	}
Define_label(mercury__relation__is_dag_3__ua0_5_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	r2 = (Integer) detstackvar(3);
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set_bbbtree__insert_3_1);
	call_localret(ENTRY(mercury__set_bbbtree__insert_3_1),
		mercury__relation__is_dag_3__ua0_5_0_i10,
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
	}
Define_label(mercury__relation__is_dag_3__ua0_5_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	localcall(mercury__relation__is_dag_3__ua0_5_0,
		LABEL(mercury__relation__is_dag_3__ua0_5_0_i11),
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
Define_label(mercury__relation__is_dag_3__ua0_5_0_i11);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__is_dag_3__ua0_5_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___set_bbbtree__set_bbbtree_1_0);
	call_localret(ENTRY(mercury____Unify___set_bbbtree__set_bbbtree_1_0),
		mercury__relation__is_dag_3__ua0_5_0_i13,
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
	}
Define_label(mercury__relation__is_dag_3__ua0_5_0_i13);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__is_dag_3__ua0_5_0_i1);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__relation__is_dag_3__ua0_5_0,
		LABEL(mercury__relation__is_dag_3__ua0_5_0_i15),
		STATIC(mercury__relation__is_dag_3__ua0_5_0));
Define_label(mercury__relation__is_dag_3__ua0_5_0_i15);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_3__ua0_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__is_dag_3__ua0_5_0_i1008);
	r1 = TRUE;
	proceed();
Define_label(mercury__relation__is_dag_3__ua0_5_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury__relation__is_dag_3__ua0_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__relation__is_dag_3__ua0_5_0_i1008);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module14)
	init_entry(mercury__relation__is_dag_2__ua0_4_0);
	init_label(mercury__relation__is_dag_2__ua0_4_0_i6);
	init_label(mercury__relation__is_dag_2__ua0_4_0_i5);
	init_label(mercury__relation__is_dag_2__ua0_4_0_i8);
	init_label(mercury__relation__is_dag_2__ua0_4_0_i1004);
	init_label(mercury__relation__is_dag_2__ua0_4_0_i1);
BEGIN_CODE

/* code for predicate 'relation__is_dag_2__ua0'/4 in mode 0 */
Define_static(mercury__relation__is_dag_2__ua0_4_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__is_dag_2__ua0_4_0_i1004);
	incr_sp_push_msg(6, "relation__is_dag_2__ua0");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r4;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__set_bbbtree__member_2_0);
	call_localret(ENTRY(mercury__set_bbbtree__member_2_0),
		mercury__relation__is_dag_2__ua0_4_0_i6,
		STATIC(mercury__relation__is_dag_2__ua0_4_0));
	}
Define_label(mercury__relation__is_dag_2__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_2__ua0_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__is_dag_2__ua0_4_0_i5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__is_dag_2__ua0_4_0,
		STATIC(mercury__relation__is_dag_2__ua0_4_0));
Define_label(mercury__relation__is_dag_2__ua0_4_0_i5);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__is_dag_3__ua0_5_0),
		mercury__relation__is_dag_2__ua0_4_0_i8,
		STATIC(mercury__relation__is_dag_2__ua0_4_0));
Define_label(mercury__relation__is_dag_2__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_2__ua0_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__is_dag_2__ua0_4_0_i1);
	r4 = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__is_dag_2__ua0_4_0,
		STATIC(mercury__relation__is_dag_2__ua0_4_0));
Define_label(mercury__relation__is_dag_2__ua0_4_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__relation__is_dag_2__ua0_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module15)
	init_entry(mercury__relation__dfs_3__ua10000_6_0);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i6);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i5);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i9);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i10);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i11);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i12);
	init_label(mercury__relation__dfs_3__ua10000_6_0_i1003);
BEGIN_CODE

/* code for predicate 'relation__dfs_3__ua10000'/6 in mode 0 */
Define_static(mercury__relation__dfs_3__ua10000_6_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__dfs_3__ua10000_6_0_i1003);
	incr_sp_push_msg(6, "relation__dfs_3__ua10000");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(2) = (Integer) r3;
	detstackvar(3) = (Integer) r4;
	{
	Declare_entry(mercury__set_bbbtree__member_2_0);
	call_localret(ENTRY(mercury__set_bbbtree__member_2_0),
		mercury__relation__dfs_3__ua10000_6_0_i6,
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
	}
Define_label(mercury__relation__dfs_3__ua10000_6_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__dfs_3__ua10000_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__dfs_3__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__dfs_3__ua10000_6_0,
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
Define_label(mercury__relation__dfs_3__ua10000_6_0_i5);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		mercury__relation__dfs_3__ua10000_6_0_i9,
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
Define_label(mercury__relation__dfs_3__ua10000_6_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__dfs_3__ua10000_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__dfs_3__ua10000_6_0_i10,
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
	}
Define_label(mercury__relation__dfs_3__ua10000_6_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__dfs_3__ua10000_6_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__set_bbbtree__insert_3_1);
	call_localret(ENTRY(mercury__set_bbbtree__insert_3_1),
		mercury__relation__dfs_3__ua10000_6_0_i11,
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
	}
Define_label(mercury__relation__dfs_3__ua10000_6_0_i11);
	update_prof_current_proc(LABEL(mercury__relation__dfs_3__ua10000_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	localcall(mercury__relation__dfs_3__ua10000_6_0,
		LABEL(mercury__relation__dfs_3__ua10000_6_0_i12),
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
Define_label(mercury__relation__dfs_3__ua10000_6_0_i12);
	update_prof_current_proc(LABEL(mercury__relation__dfs_3__ua10000_6_0));
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	r3 = (Integer) r1;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) r2;
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	localtailcall(mercury__relation__dfs_3__ua10000_6_0,
		STATIC(mercury__relation__dfs_3__ua10000_6_0));
Define_label(mercury__relation__dfs_3__ua10000_6_0_i1003);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module16)
	init_entry(mercury__relation__dfs_2__ua10000_5_0);
	init_label(mercury__relation__dfs_2__ua10000_5_0_i4);
	init_label(mercury__relation__dfs_2__ua10000_5_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__dfs_2__ua10000'/5 in mode 0 */
Define_static(mercury__relation__dfs_2__ua10000_5_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__dfs_2__ua10000_5_0_i1002);
	incr_sp_push_msg(3, "relation__dfs_2__ua10000");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r1, ((Integer) 1));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r2;
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__relation__dfs_3__ua10000_6_0),
		mercury__relation__dfs_2__ua10000_5_0_i4,
		STATIC(mercury__relation__dfs_2__ua10000_5_0));
	}
Define_label(mercury__relation__dfs_2__ua10000_5_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__dfs_2__ua10000_5_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__relation__dfs_2__ua10000_5_0,
		STATIC(mercury__relation__dfs_2__ua10000_5_0));
Define_label(mercury__relation__dfs_2__ua10000_5_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module17)
	init_entry(mercury__relation__sc__ua10000_2_0);
	init_label(mercury__relation__sc__ua10000_2_0_i2);
	init_label(mercury__relation__sc__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate 'relation__sc__ua10000'/2 in mode 0 */
Define_static(mercury__relation__sc__ua10000_2_0);
	incr_sp_push_msg(2, "relation__sc__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	call_localret(STATIC(mercury__relation__inverse__ua10000_2_0),
		mercury__relation__sc__ua10000_2_0_i2,
		STATIC(mercury__relation__sc__ua10000_2_0));
Define_label(mercury__relation__sc__ua10000_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__sc__ua10000_2_0));
	call_localret(STATIC(mercury__relation__to_assoc_list__ua10000_2_0),
		mercury__relation__sc__ua10000_2_0_i3,
		STATIC(mercury__relation__sc__ua10000_2_0));
Define_label(mercury__relation__sc__ua10000_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__sc__ua10000_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__relation__add_assoc_list__ua10000_3_0),
		STATIC(mercury__relation__sc__ua10000_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module18)
	init_entry(mercury__relation__dfsrev__ua10000_5_0);
BEGIN_CODE

/* code for predicate 'relation__dfsrev__ua10000'/5 in mode 0 */
Define_static(mercury__relation__dfsrev__ua10000_5_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) tempr1, ((Integer) 0)) = (Integer) r2;
	r2 = (Integer) r1;
	r1 = (Integer) tempr1;
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) tempr1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	tailcall(STATIC(mercury__relation__dfs_3__ua10000_6_0),
		STATIC(mercury__relation__dfsrev__ua10000_5_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module19)
	init_entry(mercury__relation__dfs__ua10000_5_0);
	init_label(mercury__relation__dfs__ua10000_5_0_i2);
	init_label(mercury__relation__dfs__ua10000_5_0_i3);
BEGIN_CODE

/* code for predicate 'relation__dfs__ua10000'/5 in mode 0 */
Define_static(mercury__relation__dfs__ua10000_5_0);
	incr_sp_push_msg(2, "relation__dfs__ua10000");
	detstackvar(2) = (Integer) succip;
	call_localret(STATIC(mercury__relation__dfsrev__ua10000_5_0),
		mercury__relation__dfs__ua10000_5_0_i2,
		STATIC(mercury__relation__dfs__ua10000_5_0));
Define_label(mercury__relation__dfs__ua10000_5_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__dfs__ua10000_5_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__list__reverse_2_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__relation__dfs__ua10000_5_0_i3,
		STATIC(mercury__relation__dfs__ua10000_5_0));
	}
Define_label(mercury__relation__dfs__ua10000_5_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__dfs__ua10000_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module20)
	init_entry(mercury__relation__dfsrev__ua10000_3_0);
	init_label(mercury__relation__dfsrev__ua10000_3_0_i2);
	init_label(mercury__relation__dfsrev__ua10000_3_0_i3);
BEGIN_CODE

/* code for predicate 'relation__dfsrev__ua10000'/3 in mode 0 */
Define_static(mercury__relation__dfsrev__ua10000_3_0);
	incr_sp_push_msg(3, "relation__dfsrev__ua10000");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set_bbbtree__init_1_0);
	call_localret(ENTRY(mercury__set_bbbtree__init_1_0),
		mercury__relation__dfsrev__ua10000_3_0_i2,
		STATIC(mercury__relation__dfsrev__ua10000_3_0));
	}
Define_label(mercury__relation__dfsrev__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__dfsrev__ua10000_3_0));
	r3 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__relation__dfs_3__ua10000_6_0),
		mercury__relation__dfsrev__ua10000_3_0_i3,
		STATIC(mercury__relation__dfsrev__ua10000_3_0));
Define_label(mercury__relation__dfsrev__ua10000_3_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__dfsrev__ua10000_3_0));
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module21)
	init_entry(mercury__relation__dfs__ua10000_3_0);
	init_label(mercury__relation__dfs__ua10000_3_0_i2);
BEGIN_CODE

/* code for predicate 'relation__dfs__ua10000'/3 in mode 0 */
Define_static(mercury__relation__dfs__ua10000_3_0);
	incr_sp_push_msg(1, "relation__dfs__ua10000");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__relation__dfsrev__ua10000_3_0),
		mercury__relation__dfs__ua10000_3_0_i2,
		STATIC(mercury__relation__dfs__ua10000_3_0));
Define_label(mercury__relation__dfs__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__dfs__ua10000_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__relation__dfs__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module22)
	init_entry(mercury__relation__inverse__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'relation__inverse__ua10000'/2 in mode 0 */
Define_static(mercury__relation__inverse__ua10000_2_0);
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module23)
	init_entry(mercury__relation__to_assoc_list__ua10000_2_0);
	init_label(mercury__relation__to_assoc_list__ua10000_2_0_i2);
BEGIN_CODE

/* code for predicate 'relation__to_assoc_list__ua10000'/2 in mode 0 */
Define_static(mercury__relation__to_assoc_list__ua10000_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	incr_sp_push_msg(2, "relation__to_assoc_list__ua10000");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__relation__to_assoc_list__ua10000_2_0_i2,
		STATIC(mercury__relation__to_assoc_list__ua10000_2_0));
	}
Define_label(mercury__relation__to_assoc_list__ua10000_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__to_assoc_list__ua10000_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__relation__to_assoc_list_2_3_0),
		STATIC(mercury__relation__to_assoc_list__ua10000_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module24)
	init_entry(mercury__relation__lookup_to__ua10000_3_0);
	init_label(mercury__relation__lookup_to__ua10000_3_0_i4);
	init_label(mercury__relation__lookup_to__ua10000_3_0_i1000);
BEGIN_CODE

/* code for predicate 'relation__lookup_to__ua10000'/3 in mode 0 */
Define_static(mercury__relation__lookup_to__ua10000_3_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	incr_sp_push_msg(1, "relation__lookup_to__ua10000");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__lookup_to__ua10000_3_0_i4,
		STATIC(mercury__relation__lookup_to__ua10000_3_0));
	}
Define_label(mercury__relation__lookup_to__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__lookup_to__ua10000_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__lookup_to__ua10000_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__relation__lookup_to__ua10000_3_0_i1000);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__init_1_0);
	tailcall(ENTRY(mercury__set__init_1_0),
		STATIC(mercury__relation__lookup_to__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module25)
	init_entry(mercury__relation__lookup_from__ua10000_3_0);
	init_label(mercury__relation__lookup_from__ua10000_3_0_i4);
	init_label(mercury__relation__lookup_from__ua10000_3_0_i1000);
BEGIN_CODE

/* code for predicate 'relation__lookup_from__ua10000'/3 in mode 0 */
Define_static(mercury__relation__lookup_from__ua10000_3_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	incr_sp_push_msg(1, "relation__lookup_from__ua10000");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__lookup_from__ua10000_3_0_i4,
		STATIC(mercury__relation__lookup_from__ua10000_3_0));
	}
Define_label(mercury__relation__lookup_from__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__lookup_from__ua10000_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__lookup_from__ua10000_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__relation__lookup_from__ua10000_3_0_i1000);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__init_1_0);
	tailcall(ENTRY(mercury__set__init_1_0),
		STATIC(mercury__relation__lookup_from__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module26)
	init_entry(mercury__relation__reverse_lookup__ua40000_3_0);
	init_label(mercury__relation__reverse_lookup__ua40000_3_0_i1);
	init_label(mercury__relation__reverse_lookup__ua40000_3_0_i3);
BEGIN_CODE

/* code for predicate 'relation__reverse_lookup__ua40000'/3 in mode 0 */
Define_static(mercury__relation__reverse_lookup__ua40000_3_0);
	{
	Declare_entry(do_fail);
	mkframe("relation__reverse_lookup__ua40000/3", 1, ENTRY(do_fail));
	}
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__reverse_lookup__ua40000_3_0_i1,
		STATIC(mercury__relation__reverse_lookup__ua40000_3_0));
	}
Define_label(mercury__relation__reverse_lookup__ua40000_3_0_i1);
	update_prof_current_proc(LABEL(mercury__relation__reverse_lookup__ua40000_3_0));
	{
	Declare_entry(do_fail);
	if (!((Integer) r1))
		GOTO(ENTRY(do_fail));
	}
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__member_2_1);
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__relation__reverse_lookup__ua40000_3_0_i3,
		STATIC(mercury__relation__reverse_lookup__ua40000_3_0));
	}
Define_label(mercury__relation__reverse_lookup__ua40000_3_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__reverse_lookup__ua40000_3_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__relation_module27)
	init_entry(mercury__relation__reverse_lookup__ua1_3_0);
	init_label(mercury__relation__reverse_lookup__ua1_3_0_i2);
	init_label(mercury__relation__reverse_lookup__ua1_3_0_i1);
BEGIN_CODE

/* code for predicate 'relation__reverse_lookup__ua1'/3 in mode 0 */
Define_static(mercury__relation__reverse_lookup__ua1_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	incr_sp_push_msg(2, "relation__reverse_lookup__ua1");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__reverse_lookup__ua1_3_0_i2,
		STATIC(mercury__relation__reverse_lookup__ua1_3_0));
	}
Define_label(mercury__relation__reverse_lookup__ua1_3_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__reverse_lookup__ua1_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__reverse_lookup__ua1_3_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__member_2_0);
	tailcall(ENTRY(mercury__set__member_2_0),
		STATIC(mercury__relation__reverse_lookup__ua1_3_0));
	}
Define_label(mercury__relation__reverse_lookup__ua1_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module28)
	init_entry(mercury__relation__lookup__ua40000_3_0);
	init_label(mercury__relation__lookup__ua40000_3_0_i1);
	init_label(mercury__relation__lookup__ua40000_3_0_i3);
BEGIN_CODE

/* code for predicate 'relation__lookup__ua40000'/3 in mode 0 */
Define_static(mercury__relation__lookup__ua40000_3_0);
	{
	Declare_entry(do_fail);
	mkframe("relation__lookup__ua40000/3", 1, ENTRY(do_fail));
	}
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__lookup__ua40000_3_0_i1,
		STATIC(mercury__relation__lookup__ua40000_3_0));
	}
Define_label(mercury__relation__lookup__ua40000_3_0_i1);
	update_prof_current_proc(LABEL(mercury__relation__lookup__ua40000_3_0));
	{
	Declare_entry(do_fail);
	if (!((Integer) r1))
		GOTO(ENTRY(do_fail));
	}
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__member_2_1);
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__relation__lookup__ua40000_3_0_i3,
		STATIC(mercury__relation__lookup__ua40000_3_0));
	}
Define_label(mercury__relation__lookup__ua40000_3_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__lookup__ua40000_3_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__relation_module29)
	init_entry(mercury__relation__lookup__ua1_3_0);
	init_label(mercury__relation__lookup__ua1_3_0_i2);
	init_label(mercury__relation__lookup__ua1_3_0_i1);
BEGIN_CODE

/* code for predicate 'relation__lookup__ua1'/3 in mode 0 */
Define_static(mercury__relation__lookup__ua1_3_0);
	incr_sp_push_msg(2, "relation__lookup__ua1");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__lookup__ua1_3_0_i2,
		STATIC(mercury__relation__lookup__ua1_3_0));
	}
Define_label(mercury__relation__lookup__ua1_3_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__lookup__ua1_3_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__lookup__ua1_3_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__member_2_0);
	tailcall(ENTRY(mercury__set__member_2_0),
		STATIC(mercury__relation__lookup__ua1_3_0));
	}
Define_label(mercury__relation__lookup__ua1_3_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module30)
	init_entry(mercury__relation__remove_assoc_list__ua10000_3_0);
	init_label(mercury__relation__remove_assoc_list__ua10000_3_0_i4);
	init_label(mercury__relation__remove_assoc_list__ua10000_3_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__remove_assoc_list__ua10000'/3 in mode 0 */
Define_static(mercury__relation__remove_assoc_list__ua10000_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__remove_assoc_list__ua10000_3_0_i1002);
	incr_sp_push_msg(2, "relation__remove_assoc_list__ua10000");
	detstackvar(2) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	call_localret(STATIC(mercury__relation__remove__ua10000_4_0),
		mercury__relation__remove_assoc_list__ua10000_3_0_i4,
		STATIC(mercury__relation__remove_assoc_list__ua10000_3_0));
	}
Define_label(mercury__relation__remove_assoc_list__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__remove_assoc_list__ua10000_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__relation__remove_assoc_list__ua10000_3_0,
		STATIC(mercury__relation__remove_assoc_list__ua10000_3_0));
Define_label(mercury__relation__remove_assoc_list__ua10000_3_0_i1002);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module31)
	init_entry(mercury__relation__remove__ua10000_4_0);
	init_label(mercury__relation__remove__ua10000_4_0_i4);
	init_label(mercury__relation__remove__ua10000_4_0_i6);
	init_label(mercury__relation__remove__ua10000_4_0_i7);
	init_label(mercury__relation__remove__ua10000_4_0_i3);
	init_label(mercury__relation__remove__ua10000_4_0_i8);
	init_label(mercury__relation__remove__ua10000_4_0_i11);
	init_label(mercury__relation__remove__ua10000_4_0_i13);
	init_label(mercury__relation__remove__ua10000_4_0_i14);
	init_label(mercury__relation__remove__ua10000_4_0_i1005);
BEGIN_CODE

/* code for predicate 'relation__remove__ua10000'/4 in mode 0 */
Define_static(mercury__relation__remove__ua10000_4_0);
	incr_sp_push_msg(8, "relation__remove__ua10000");
	detstackvar(8) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) r3;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__remove__ua10000_4_0_i4,
		STATIC(mercury__relation__remove__ua10000_4_0));
	}
Define_label(mercury__relation__remove__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__remove__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__remove__ua10000_4_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__delete_3_0);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__relation__remove__ua10000_4_0_i6,
		STATIC(mercury__relation__remove__ua10000_4_0));
	}
Define_label(mercury__relation__remove__ua10000_4_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__remove__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__relation__remove__ua10000_4_0_i7,
		STATIC(mercury__relation__remove__ua10000_4_0));
	}
Define_label(mercury__relation__remove__ua10000_4_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__remove__ua10000_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__relation__remove__ua10000_4_0_i8);
Define_label(mercury__relation__remove__ua10000_4_0_i3);
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(6);
	r6 = (Integer) detstackvar(5);
Define_label(mercury__relation__remove__ua10000_4_0_i8);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r6;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__remove__ua10000_4_0_i11,
		STATIC(mercury__relation__remove__ua10000_4_0));
	}
Define_label(mercury__relation__remove__ua10000_4_0_i11);
	update_prof_current_proc(LABEL(mercury__relation__remove__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__remove__ua10000_4_0_i1005);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__delete_3_0);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__relation__remove__ua10000_4_0_i13,
		STATIC(mercury__relation__remove__ua10000_4_0));
	}
Define_label(mercury__relation__remove__ua10000_4_0_i13);
	update_prof_current_proc(LABEL(mercury__relation__remove__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__relation__remove__ua10000_4_0_i14,
		STATIC(mercury__relation__remove__ua10000_4_0));
	}
Define_label(mercury__relation__remove__ua10000_4_0_i14);
	update_prof_current_proc(LABEL(mercury__relation__remove__ua10000_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__relation__remove__ua10000_4_0_i1005);
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module32)
	init_entry(mercury__relation__add_assoc_list__ua10000_3_0);
	init_label(mercury__relation__add_assoc_list__ua10000_3_0_i4);
	init_label(mercury__relation__add_assoc_list__ua10000_3_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__add_assoc_list__ua10000'/3 in mode 0 */
Define_static(mercury__relation__add_assoc_list__ua10000_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__add_assoc_list__ua10000_3_0_i1002);
	incr_sp_push_msg(2, "relation__add_assoc_list__ua10000");
	detstackvar(2) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	call_localret(STATIC(mercury__relation__add__ua10000_4_0),
		mercury__relation__add_assoc_list__ua10000_3_0_i4,
		STATIC(mercury__relation__add_assoc_list__ua10000_3_0));
	}
Define_label(mercury__relation__add_assoc_list__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__add_assoc_list__ua10000_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__relation__add_assoc_list__ua10000_3_0,
		STATIC(mercury__relation__add_assoc_list__ua10000_3_0));
Define_label(mercury__relation__add_assoc_list__ua10000_3_0_i1002);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module33)
	init_entry(mercury__relation__add__ua10000_4_0);
	init_label(mercury__relation__add__ua10000_4_0_i4);
	init_label(mercury__relation__add__ua10000_4_0_i6);
	init_label(mercury__relation__add__ua10000_4_0_i7);
	init_label(mercury__relation__add__ua10000_4_0_i3);
	init_label(mercury__relation__add__ua10000_4_0_i8);
	init_label(mercury__relation__add__ua10000_4_0_i9);
	init_label(mercury__relation__add__ua10000_4_0_i10);
	init_label(mercury__relation__add__ua10000_4_0_i11);
	init_label(mercury__relation__add__ua10000_4_0_i14);
	init_label(mercury__relation__add__ua10000_4_0_i16);
	init_label(mercury__relation__add__ua10000_4_0_i17);
	init_label(mercury__relation__add__ua10000_4_0_i13);
	init_label(mercury__relation__add__ua10000_4_0_i18);
	init_label(mercury__relation__add__ua10000_4_0_i19);
	init_label(mercury__relation__add__ua10000_4_0_i20);
BEGIN_CODE

/* code for predicate 'relation__add__ua10000'/4 in mode 0 */
Define_static(mercury__relation__add__ua10000_4_0);
	incr_sp_push_msg(8, "relation__add__ua10000");
	detstackvar(8) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(5) = (Integer) r3;
	r4 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 3));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__add__ua10000_4_0_i4,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__add__ua10000_4_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__add__ua10000_4_0_i6,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__relation__add__ua10000_4_0_i7,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
	GOTO_LABEL(mercury__relation__add__ua10000_4_0_i11);
Define_label(mercury__relation__add__ua10000_4_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__relation__add__ua10000_4_0_i8,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__add__ua10000_4_0_i9,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__relation__add__ua10000_4_0_i10,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(4);
Define_label(mercury__relation__add__ua10000_4_0_i11);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r2;
	detstackvar(4) = (Integer) r5;
	detstackvar(6) = (Integer) r3;
	detstackvar(7) = (Integer) r6;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__search_3_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__relation__add__ua10000_4_0_i14,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i14);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__add__ua10000_4_0_i13);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__add__ua10000_4_0_i16,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i16);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_update_4_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__relation__add__ua10000_4_0_i17,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i17);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__relation__add__ua10000_4_0_i13);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__relation__add__ua10000_4_0_i18,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i18);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__set__insert_3_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__relation__add__ua10000_4_0_i19,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i19);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(6);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__relation__add__ua10000_4_0_i20,
		STATIC(mercury__relation__add__ua10000_4_0));
	}
Define_label(mercury__relation__add__ua10000_4_0_i20);
	update_prof_current_proc(LABEL(mercury__relation__add__ua10000_4_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(7);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module34)
	init_entry(mercury__relation__init_1_0);
	init_label(mercury__relation__init_1_0_i2);
	init_label(mercury__relation__init_1_0_i3);
	init_label(mercury__relation__init_1_0_i4);
BEGIN_CODE

/* code for predicate 'relation__init'/1 in mode 0 */
Define_entry(mercury__relation__init_1_0);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(3, "relation__init");
	detstackvar(3) = (Integer) succip;
	{
	Declare_entry(mercury__bimap__init_1_0);
	call_localret(ENTRY(mercury__bimap__init_1_0),
		mercury__relation__init_1_0_i2,
		ENTRY(mercury__relation__init_1_0));
	}
Define_label(mercury__relation__init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__init_1_0));
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__relation__init_1_0_i3,
		ENTRY(mercury__relation__init_1_0));
	}
Define_label(mercury__relation__init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__init_1_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__relation__init_1_0_i4,
		ENTRY(mercury__relation__init_1_0));
	}
Define_label(mercury__relation__init_1_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__init_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module35)
	init_entry(mercury__relation__add_element_4_0);
	init_label(mercury__relation__add_element_4_0_i4);
	init_label(mercury__relation__add_element_4_0_i3);
	init_label(mercury__relation__add_element_4_0_i6);
BEGIN_CODE

/* code for predicate 'relation__add_element'/4 in mode 0 */
Define_entry(mercury__relation__add_element_4_0);
	r4 = (Integer) r3;
	incr_sp_push_msg(7, "relation__add_element");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(3) = (Integer) r3;
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__bimap__search_3_0);
	call_localret(ENTRY(mercury__bimap__search_3_0),
		mercury__relation__add_element_4_0_i4,
		ENTRY(mercury__relation__add_element_4_0));
	}
Define_label(mercury__relation__add_element_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__add_element_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__add_element_4_0_i3);
	r1 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__relation__add_element_4_0_i3);
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) detstackvar(2);
	detstackvar(1) = (Integer) r5;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(3);
	detstackvar(2) = ((Integer) r5 + ((Integer) 1));
	{
	Declare_entry(mercury__bimap__set_4_0);
	call_localret(ENTRY(mercury__bimap__set_4_0),
		mercury__relation__add_element_4_0_i6,
		ENTRY(mercury__relation__add_element_4_0));
	}
Define_label(mercury__relation__add_element_4_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__add_element_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module36)
	init_entry(mercury__relation__search_element_3_0);
	init_label(mercury__relation__search_element_3_0_i2);
	init_label(mercury__relation__search_element_3_0_i1000);
BEGIN_CODE

/* code for predicate 'relation__search_element'/3 in mode 0 */
Define_entry(mercury__relation__search_element_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(1, "relation__search_element");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__bimap__search_3_0);
	call_localret(ENTRY(mercury__bimap__search_3_0),
		mercury__relation__search_element_3_0_i2,
		ENTRY(mercury__relation__search_element_3_0));
	}
Define_label(mercury__relation__search_element_3_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__search_element_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__search_element_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__relation__search_element_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module37)
	init_entry(mercury__relation__lookup_element_3_0);
	init_label(mercury__relation__lookup_element_3_0_i4);
	init_label(mercury__relation__lookup_element_3_0_i1000);
BEGIN_CODE

/* code for predicate 'relation__lookup_element'/3 in mode 0 */
Define_entry(mercury__relation__lookup_element_3_0);
	incr_sp_push_msg(1, "relation__lookup_element");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__relation__search_element_3_0),
		mercury__relation__lookup_element_3_0_i4,
		ENTRY(mercury__relation__lookup_element_3_0));
	}
Define_label(mercury__relation__lookup_element_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__lookup_element_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__lookup_element_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__relation__lookup_element_3_0_i1000);
	r1 = string_const("relation__lookup_element", 24);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__relation__lookup_element_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module38)
	init_entry(mercury__relation__search_key_3_0);
	init_label(mercury__relation__search_key_3_0_i2);
	init_label(mercury__relation__search_key_3_0_i1000);
BEGIN_CODE

/* code for predicate 'relation__search_key'/3 in mode 0 */
Define_entry(mercury__relation__search_key_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(1, "relation__search_key");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__bimap__search_3_1);
	call_localret(ENTRY(mercury__bimap__search_3_1),
		mercury__relation__search_key_3_0_i2,
		ENTRY(mercury__relation__search_key_3_0));
	}
Define_label(mercury__relation__search_key_3_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__search_key_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__search_key_3_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__relation__search_key_3_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module39)
	init_entry(mercury__relation__lookup_key_3_0);
	init_label(mercury__relation__lookup_key_3_0_i4);
	init_label(mercury__relation__lookup_key_3_0_i1000);
BEGIN_CODE

/* code for predicate 'relation__lookup_key'/3 in mode 0 */
Define_entry(mercury__relation__lookup_key_3_0);
	incr_sp_push_msg(1, "relation__lookup_key");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__relation__search_key_3_0),
		mercury__relation__lookup_key_3_0_i4,
		ENTRY(mercury__relation__lookup_key_3_0));
	}
Define_label(mercury__relation__lookup_key_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__lookup_key_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__lookup_key_3_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__relation__lookup_key_3_0_i1000);
	r1 = string_const("relation__lookup_key", 20);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__relation__lookup_key_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module40)
	init_entry(mercury__relation__add_4_0);
BEGIN_CODE

/* code for predicate 'relation__add'/4 in mode 0 */
Define_entry(mercury__relation__add_4_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__relation__add__ua10000_4_0),
		ENTRY(mercury__relation__add_4_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module41)
	init_entry(mercury__relation__add_assoc_list_3_0);
BEGIN_CODE

/* code for predicate 'relation__add_assoc_list'/3 in mode 0 */
Define_entry(mercury__relation__add_assoc_list_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__relation__add_assoc_list__ua10000_3_0),
		ENTRY(mercury__relation__add_assoc_list_3_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module42)
	init_entry(mercury__relation__remove_4_0);
BEGIN_CODE

/* code for predicate 'relation__remove'/4 in mode 0 */
Define_entry(mercury__relation__remove_4_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__relation__remove__ua10000_4_0),
		ENTRY(mercury__relation__remove_4_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module43)
	init_entry(mercury__relation__remove_assoc_list_3_0);
BEGIN_CODE

/* code for predicate 'relation__remove_assoc_list'/3 in mode 0 */
Define_entry(mercury__relation__remove_assoc_list_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__relation__remove_assoc_list__ua10000_3_0),
		ENTRY(mercury__relation__remove_assoc_list_3_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module44)
	init_entry(mercury__relation__lookup_3_1);
BEGIN_CODE

/* code for predicate 'relation__lookup'/3 in mode 1 */
Define_entry(mercury__relation__lookup_3_1);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__relation__lookup__ua1_3_0),
		ENTRY(mercury__relation__lookup_3_1));
END_MODULE

BEGIN_MODULE(mercury__relation_module45)
	init_entry(mercury__relation__lookup_3_0);
	init_label(mercury__relation__lookup_3_0_i1);
BEGIN_CODE

/* code for predicate 'relation__lookup'/3 in mode 0 */
Define_entry(mercury__relation__lookup_3_0);
	{
	Declare_entry(do_fail);
	mkframe("relation__lookup/3", 1, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__relation__lookup__ua40000_3_0),
		mercury__relation__lookup_3_0_i1,
		ENTRY(mercury__relation__lookup_3_0));
Define_label(mercury__relation__lookup_3_0_i1);
	update_prof_current_proc(LABEL(mercury__relation__lookup_3_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__relation_module46)
	init_entry(mercury__relation__reverse_lookup_3_1);
BEGIN_CODE

/* code for predicate 'relation__reverse_lookup'/3 in mode 1 */
Define_entry(mercury__relation__reverse_lookup_3_1);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__relation__reverse_lookup__ua1_3_0),
		ENTRY(mercury__relation__reverse_lookup_3_1));
END_MODULE

BEGIN_MODULE(mercury__relation_module47)
	init_entry(mercury__relation__reverse_lookup_3_0);
	init_label(mercury__relation__reverse_lookup_3_0_i1);
BEGIN_CODE

/* code for predicate 'relation__reverse_lookup'/3 in mode 0 */
Define_entry(mercury__relation__reverse_lookup_3_0);
	{
	Declare_entry(do_fail);
	mkframe("relation__reverse_lookup/3", 1, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	call_localret(STATIC(mercury__relation__reverse_lookup__ua40000_3_0),
		mercury__relation__reverse_lookup_3_0_i1,
		ENTRY(mercury__relation__reverse_lookup_3_0));
Define_label(mercury__relation__reverse_lookup_3_0_i1);
	update_prof_current_proc(LABEL(mercury__relation__reverse_lookup_3_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__relation_module48)
	init_entry(mercury__relation__lookup_from_3_0);
BEGIN_CODE

/* code for predicate 'relation__lookup_from'/3 in mode 0 */
Define_entry(mercury__relation__lookup_from_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__relation__lookup_from__ua10000_3_0),
		ENTRY(mercury__relation__lookup_from_3_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module49)
	init_entry(mercury__relation__lookup_to_3_0);
BEGIN_CODE

/* code for predicate 'relation__lookup_to'/3 in mode 0 */
Define_entry(mercury__relation__lookup_to_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__relation__lookup_to__ua10000_3_0),
		ENTRY(mercury__relation__lookup_to_3_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module50)
	init_entry(mercury__relation__to_assoc_list_2_0);
BEGIN_CODE

/* code for predicate 'relation__to_assoc_list'/2 in mode 0 */
Define_entry(mercury__relation__to_assoc_list_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__relation__to_assoc_list__ua10000_2_0),
		ENTRY(mercury__relation__to_assoc_list_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module51)
	init_entry(mercury__relation__domain_2_0);
	init_label(mercury__relation__domain_2_0_i2);
BEGIN_CODE

/* code for predicate 'relation__domain'/2 in mode 0 */
Define_entry(mercury__relation__domain_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(2, "relation__domain");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
	Declare_entry(mercury__bimap__ordinates_2_0);
	call_localret(ENTRY(mercury__bimap__ordinates_2_0),
		mercury__relation__domain_2_0_i2,
		ENTRY(mercury__relation__domain_2_0));
	}
Define_label(mercury__relation__domain_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__domain_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__sorted_list_to_set_2_0);
	tailcall(ENTRY(mercury__set__sorted_list_to_set_2_0),
		ENTRY(mercury__relation__domain_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module52)
	init_entry(mercury__relation__inverse_2_0);
BEGIN_CODE

/* code for predicate 'relation__inverse'/2 in mode 0 */
Define_entry(mercury__relation__inverse_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__relation__inverse__ua10000_2_0),
		ENTRY(mercury__relation__inverse_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module53)
	init_entry(mercury__relation__dfs_3_0);
BEGIN_CODE

/* code for predicate 'relation__dfs'/3 in mode 0 */
Define_entry(mercury__relation__dfs_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__relation__dfs__ua10000_3_0),
		ENTRY(mercury__relation__dfs_3_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module54)
	init_entry(mercury__relation__dfsrev_3_0);
BEGIN_CODE

/* code for predicate 'relation__dfsrev'/3 in mode 0 */
Define_entry(mercury__relation__dfsrev_3_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__relation__dfsrev__ua10000_3_0),
		ENTRY(mercury__relation__dfsrev_3_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module55)
	init_entry(mercury__relation__dfs_2_0);
	init_label(mercury__relation__dfs_2_0_i2);
BEGIN_CODE

/* code for predicate 'relation__dfs'/2 in mode 0 */
Define_entry(mercury__relation__dfs_2_0);
	incr_sp_push_msg(1, "relation__dfs");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__relation__dfsrev_2_0),
		mercury__relation__dfs_2_0_i2,
		ENTRY(mercury__relation__dfs_2_0));
	}
Define_label(mercury__relation__dfs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__dfs_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		ENTRY(mercury__relation__dfs_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module56)
	init_entry(mercury__relation__dfsrev_2_0);
	init_label(mercury__relation__dfsrev_2_0_i2);
	init_label(mercury__relation__dfsrev_2_0_i3);
BEGIN_CODE

/* code for predicate 'relation__dfsrev'/2 in mode 0 */
Define_entry(mercury__relation__dfsrev_2_0);
	incr_sp_push_msg(3, "relation__dfsrev");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__relation__domain_sorted_list_2_0),
		mercury__relation__dfsrev_2_0_i2,
		ENTRY(mercury__relation__dfsrev_2_0));
Define_label(mercury__relation__dfsrev_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__dfsrev_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set_bbbtree__init_1_0);
	call_localret(ENTRY(mercury__set_bbbtree__init_1_0),
		mercury__relation__dfsrev_2_0_i3,
		ENTRY(mercury__relation__dfsrev_2_0));
	}
Define_label(mercury__relation__dfsrev_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__dfsrev_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__relation__dfs_2__ua10000_5_0),
		ENTRY(mercury__relation__dfsrev_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module57)
	init_entry(mercury__relation__dfs_5_0);
BEGIN_CODE

/* code for predicate 'relation__dfs'/5 in mode 0 */
Define_entry(mercury__relation__dfs_5_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__relation__dfs__ua10000_5_0),
		ENTRY(mercury__relation__dfs_5_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module58)
	init_entry(mercury__relation__dfsrev_5_0);
BEGIN_CODE

/* code for predicate 'relation__dfsrev'/5 in mode 0 */
Define_entry(mercury__relation__dfsrev_5_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__relation__dfsrev__ua10000_5_0),
		ENTRY(mercury__relation__dfsrev_5_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module59)
	init_entry(mercury__relation__is_dag_1_0);
	init_label(mercury__relation__is_dag_1_0_i2);
	init_label(mercury__relation__is_dag_1_0_i3);
	init_label(mercury__relation__is_dag_1_0_i4);
BEGIN_CODE

/* code for predicate 'relation__is_dag'/1 in mode 0 */
Define_entry(mercury__relation__is_dag_1_0);
	incr_sp_push_msg(4, "relation__is_dag");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__relation__domain_sorted_list_2_0),
		mercury__relation__is_dag_1_0_i2,
		ENTRY(mercury__relation__is_dag_1_0));
Define_label(mercury__relation__is_dag_1_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_1_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set_bbbtree__init_1_0);
	call_localret(ENTRY(mercury__set_bbbtree__init_1_0),
		mercury__relation__is_dag_1_0_i3,
		ENTRY(mercury__relation__is_dag_1_0));
	}
Define_label(mercury__relation__is_dag_1_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set_bbbtree__init_1_0);
	call_localret(ENTRY(mercury__set_bbbtree__init_1_0),
		mercury__relation__is_dag_1_0_i4,
		ENTRY(mercury__relation__is_dag_1_0));
	}
Define_label(mercury__relation__is_dag_1_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__is_dag_1_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__relation__is_dag_2__ua0_4_0),
		ENTRY(mercury__relation__is_dag_1_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module60)
	init_entry(mercury__relation__components_2_0);
	init_label(mercury__relation__components_2_0_i2);
	init_label(mercury__relation__components_2_0_i3);
BEGIN_CODE

/* code for predicate 'relation__components'/2 in mode 0 */
Define_entry(mercury__relation__components_2_0);
	incr_sp_push_msg(3, "relation__components");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	call_localret(STATIC(mercury__relation__domain_sorted_list_2_0),
		mercury__relation__components_2_0_i2,
		ENTRY(mercury__relation__components_2_0));
Define_label(mercury__relation__components_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__components_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__relation__components_2_0_i3,
		ENTRY(mercury__relation__components_2_0));
	}
Define_label(mercury__relation__components_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__components_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__relation__components_2__ua10000_4_0),
		ENTRY(mercury__relation__components_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module61)
	init_entry(mercury__relation__cliques_2_0);
	init_label(mercury__relation__cliques_2_0_i2);
	init_label(mercury__relation__cliques_2_0_i3);
	init_label(mercury__relation__cliques_2_0_i4);
	init_label(mercury__relation__cliques_2_0_i5);
BEGIN_CODE

/* code for predicate 'relation__cliques'/2 in mode 0 */
Define_entry(mercury__relation__cliques_2_0);
	incr_sp_push_msg(4, "relation__cliques");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
		call_localret(STATIC(mercury__relation__dfsrev_2_0),
		mercury__relation__cliques_2_0_i2,
		ENTRY(mercury__relation__cliques_2_0));
	}
Define_label(mercury__relation__cliques_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__relation__inverse__ua10000_2_0),
		mercury__relation__cliques_2_0_i3,
		ENTRY(mercury__relation__cliques_2_0));
Define_label(mercury__relation__cliques_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__relation__cliques_2_0_i4,
		ENTRY(mercury__relation__cliques_2_0));
	}
Define_label(mercury__relation__cliques_2_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set_bbbtree__init_1_0);
	call_localret(ENTRY(mercury__set_bbbtree__init_1_0),
		mercury__relation__cliques_2_0_i5,
		ENTRY(mercury__relation__cliques_2_0));
	}
Define_label(mercury__relation__cliques_2_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__cliques_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__relation__cliques_2__ua10000_5_0),
		ENTRY(mercury__relation__cliques_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module62)
	init_entry(mercury__relation__reduced_2_0);
	init_label(mercury__relation__reduced_2_0_i2);
	init_label(mercury__relation__reduced_2_0_i3);
	init_label(mercury__relation__reduced_2_0_i4);
	init_label(mercury__relation__reduced_2_0_i5);
	init_label(mercury__relation__reduced_2_0_i6);
	init_label(mercury__relation__reduced_2_0_i7);
BEGIN_CODE

/* code for predicate 'relation__reduced'/2 in mode 0 */
Define_entry(mercury__relation__reduced_2_0);
	incr_sp_push_msg(5, "relation__reduced");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	{
		call_localret(STATIC(mercury__relation__cliques_2_0),
		mercury__relation__reduced_2_0_i2,
		ENTRY(mercury__relation__reduced_2_0));
	}
Define_label(mercury__relation__reduced_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__reduced_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__reduced_2_0_i3,
		ENTRY(mercury__relation__reduced_2_0));
	}
Define_label(mercury__relation__reduced_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__reduced_2_0));
	detstackvar(2) = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
		call_localret(STATIC(mercury__relation__init_1_0),
		mercury__relation__reduced_2_0_i4,
		ENTRY(mercury__relation__reduced_2_0));
	}
Define_label(mercury__relation__reduced_2_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__reduced_2_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__relation__reduced_2_0_i5,
		ENTRY(mercury__relation__reduced_2_0));
	}
Define_label(mercury__relation__reduced_2_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__reduced_2_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	call_localret(STATIC(mercury__relation__make_clique_map_6_0),
		mercury__relation__reduced_2_0_i6,
		ENTRY(mercury__relation__reduced_2_0));
Define_label(mercury__relation__reduced_2_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__reduced_2_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	r1 = (Integer) r3;
	call_localret(STATIC(mercury__relation__to_assoc_list__ua10000_2_0),
		mercury__relation__reduced_2_0_i7,
		ENTRY(mercury__relation__reduced_2_0));
Define_label(mercury__relation__reduced_2_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__reduced_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__relation__make_reduced_graph__ua10000_4_0),
		ENTRY(mercury__relation__reduced_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module63)
	init_entry(mercury__relation__tsort_2_0);
	init_label(mercury__relation__tsort_2_0_i2);
	init_label(mercury__relation__tsort_2_0_i3);
	init_label(mercury__relation__tsort_2_0_i4);
	init_label(mercury__relation__tsort_2_0_i5);
	init_label(mercury__relation__tsort_2_0_i7);
	init_label(mercury__relation__tsort_2_0_i1);
BEGIN_CODE

/* code for predicate 'relation__tsort'/2 in mode 0 */
Define_entry(mercury__relation__tsort_2_0);
	incr_sp_push_msg(4, "relation__tsort");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	call_localret(STATIC(mercury__relation__domain_sorted_list_2_0),
		mercury__relation__tsort_2_0_i2,
		ENTRY(mercury__relation__tsort_2_0));
Define_label(mercury__relation__tsort_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__tsort_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__init_1_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__relation__tsort_2_0_i3,
		ENTRY(mercury__relation__tsort_2_0));
	}
Define_label(mercury__relation__tsort_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__tsort_2_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__relation__c_dfs__ua10000_6_0),
		mercury__relation__tsort_2_0_i4,
		ENTRY(mercury__relation__tsort_2_0));
Define_label(mercury__relation__tsort_2_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__tsort_2_0));
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r3;
	r1 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__relation__check_tsort__ua0_3_0),
		mercury__relation__tsort_2_0_i5,
		ENTRY(mercury__relation__tsort_2_0));
Define_label(mercury__relation__tsort_2_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__tsort_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__tsort_2_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) ENTRY(mercury__relation__lookup_key_3_0);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__list__map_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__relation__tsort_2_0_i7,
		ENTRY(mercury__relation__tsort_2_0));
	}
Define_label(mercury__relation__tsort_2_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__tsort_2_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__relation__tsort_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module64)
	init_entry(mercury__relation__atsort_2_0);
	init_label(mercury__relation__atsort_2_0_i2);
	init_label(mercury__relation__atsort_2_0_i3);
	init_label(mercury__relation__atsort_2_0_i4);
	init_label(mercury__relation__atsort_2_0_i5);
BEGIN_CODE

/* code for predicate 'relation__atsort'/2 in mode 0 */
Define_entry(mercury__relation__atsort_2_0);
	incr_sp_push_msg(4, "relation__atsort");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r1;
	{
		call_localret(STATIC(mercury__relation__dfsrev_2_0),
		mercury__relation__atsort_2_0_i2,
		ENTRY(mercury__relation__atsort_2_0));
	}
Define_label(mercury__relation__atsort_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__relation__inverse__ua10000_2_0),
		mercury__relation__atsort_2_0_i3,
		ENTRY(mercury__relation__atsort_2_0));
Define_label(mercury__relation__atsort_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set_bbbtree__init_1_0);
	call_localret(ENTRY(mercury__set_bbbtree__init_1_0),
		mercury__relation__atsort_2_0_i4,
		ENTRY(mercury__relation__atsort_2_0));
	}
Define_label(mercury__relation__atsort_2_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r5 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__relation__atsort_2_5_0),
		mercury__relation__atsort_2_0_i5,
		ENTRY(mercury__relation__atsort_2_0));
Define_label(mercury__relation__atsort_2_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__list__reverse_2_0);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		ENTRY(mercury__relation__atsort_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module65)
	init_entry(mercury__relation__sc_2_0);
BEGIN_CODE

/* code for predicate 'relation__sc'/2 in mode 0 */
Define_entry(mercury__relation__sc_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__relation__sc__ua10000_2_0),
		ENTRY(mercury__relation__sc_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module66)
	init_entry(mercury__relation__tc_2_0);
	init_label(mercury__relation__tc_2_0_i2);
	init_label(mercury__relation__tc_2_0_i3);
	init_label(mercury__relation__tc_2_0_i4);
	init_label(mercury__relation__tc_2_0_i5);
BEGIN_CODE

/* code for predicate 'relation__tc'/2 in mode 0 */
Define_entry(mercury__relation__tc_2_0);
	incr_sp_push_msg(3, "relation__tc");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r1;
	{
		call_localret(STATIC(mercury__relation__rtc_2_0),
		mercury__relation__tc_2_0_i2,
		ENTRY(mercury__relation__tc_2_0));
	}
Define_label(mercury__relation__tc_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__tc_2_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) detstackvar(1);
	call_localret(STATIC(mercury__relation__domain_sorted_list_2_0),
		mercury__relation__tc_2_0_i3,
		ENTRY(mercury__relation__tc_2_0));
Define_label(mercury__relation__tc_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__tc_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__relation__detect_fake_reflexives__ua10000_4_0),
		mercury__relation__tc_2_0_i4,
		ENTRY(mercury__relation__tc_2_0));
Define_label(mercury__relation__tc_2_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__tc_2_0));
	r3 = (Integer) r1;
	r4 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__relation__tc_2_0_i5,
		ENTRY(mercury__relation__tc_2_0));
	}
Define_label(mercury__relation__tc_2_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__tc_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__relation__remove_assoc_list__ua10000_3_0),
		ENTRY(mercury__relation__tc_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module67)
	init_entry(mercury__relation__rtc_2_0);
	init_label(mercury__relation__rtc_2_0_i2);
	init_label(mercury__relation__rtc_2_0_i3);
	init_label(mercury__relation__rtc_2_0_i4);
	init_label(mercury__relation__rtc_2_0_i5);
	init_label(mercury__relation__rtc_2_0_i6);
BEGIN_CODE

/* code for predicate 'relation__rtc'/2 in mode 0 */
Define_entry(mercury__relation__rtc_2_0);
	incr_sp_push_msg(5, "relation__rtc");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(4) = (Integer) r1;
	call_localret(STATIC(mercury__relation__domain_sorted_list_2_0),
		mercury__relation__rtc_2_0_i2,
		ENTRY(mercury__relation__rtc_2_0));
Define_label(mercury__relation__rtc_2_0_i2);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2_0));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__relation__rtc_2_0_i3,
		ENTRY(mercury__relation__rtc_2_0));
	}
Define_label(mercury__relation__rtc_2_0_i3);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__relation__rtc_2_0_i4,
		ENTRY(mercury__relation__rtc_2_0));
	}
Define_label(mercury__relation__rtc_2_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2_0));
	r2 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__relation__rtc__init_map_3_0),
		mercury__relation__rtc_2_0_i5,
		ENTRY(mercury__relation__rtc_2_0));
Define_label(mercury__relation__rtc_2_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2_0));
	r2 = (Integer) detstackvar(4);
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	{
		call_localret(STATIC(mercury__relation__init_1_0),
		mercury__relation__rtc_2_0_i6,
		ENTRY(mercury__relation__rtc_2_0));
	}
Define_label(mercury__relation__rtc_2_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__rtc_2_0));
	r5 = (Integer) r1;
	r1 = (((Integer) detstackvar(3) + ((Integer) 2)) * ((Integer) 2));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__relation__rtc_2__ua10000_6_0),
		ENTRY(mercury__relation__rtc_2_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module68)
	init_entry(mercury__relation__to_assoc_list_2_3_0);
	init_label(mercury__relation__to_assoc_list_2_3_0_i4);
	init_label(mercury__relation__to_assoc_list_2_3_0_i5);
	init_label(mercury__relation__to_assoc_list_2_3_0_i6);
	init_label(mercury__relation__to_assoc_list_2_3_0_i7);
	init_label(mercury__relation__to_assoc_list_2_3_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__to_assoc_list_2'/3 in mode 0 */
Define_static(mercury__relation__to_assoc_list_2_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__to_assoc_list_2_3_0_i1002);
	incr_sp_push_msg(3, "relation__to_assoc_list_2");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	localcall(mercury__relation__to_assoc_list_2_3_0,
		LABEL(mercury__relation__to_assoc_list_2_3_0_i4),
		STATIC(mercury__relation__to_assoc_list_2_3_0));
Define_label(mercury__relation__to_assoc_list_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__to_assoc_list_2_3_0));
	r3 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r4 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__relation__to_assoc_list_2_3_0_i5,
		STATIC(mercury__relation__to_assoc_list_2_3_0));
	}
Define_label(mercury__relation__to_assoc_list_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__to_assoc_list_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__to_assoc_list_2_3_0_i6,
		STATIC(mercury__relation__to_assoc_list_2_3_0));
	}
Define_label(mercury__relation__to_assoc_list_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__to_assoc_list_2_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury__relation__append_to_3_0),
		mercury__relation__to_assoc_list_2_3_0_i7,
		STATIC(mercury__relation__to_assoc_list_2_3_0));
Define_label(mercury__relation__to_assoc_list_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__to_assoc_list_2_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_1);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__list__append_3_1);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__relation__to_assoc_list_2_3_0));
	}
Define_label(mercury__relation__to_assoc_list_2_3_0_i1002);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module69)
	init_entry(mercury__relation__append_to_3_0);
	init_label(mercury__relation__append_to_3_0_i3);
	init_label(mercury__relation__append_to_3_0_i4);
	init_label(mercury__relation__append_to_3_0_i1);
BEGIN_CODE

/* code for predicate 'relation__append_to'/3 in mode 0 */
Define_static(mercury__relation__append_to_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__append_to_3_0_i1);
	r3 = (Integer) sp;
Define_label(mercury__relation__append_to_3_0_i3);
	while (1) {
	incr_sp_push_msg(1, "relation__append_to");
	tag_incr_hp(detstackvar(1), mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 0)) = (Integer) r1;
	field(mktag(0), (Integer) detstackvar(1), ((Integer) 1)) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		continue;
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	break; } /* end while */
Define_label(mercury__relation__append_to_3_0_i4);
	while (1) {
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	decr_sp_pop_msg(1);
	if (((Integer) sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__relation__append_to_3_0_i1);
	r1 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module70)
	init_entry(mercury__relation__domain_sorted_list_2_0);
BEGIN_CODE

/* code for predicate 'relation__domain_sorted_list'/2 in mode 0 */
Define_static(mercury__relation__domain_sorted_list_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__bimap__coordinates_2_0);
	tailcall(ENTRY(mercury__bimap__coordinates_2_0),
		STATIC(mercury__relation__domain_sorted_list_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module71)
	init_entry(mercury__relation__make_clique_map_6_0);
	init_label(mercury__relation__make_clique_map_6_0_i4);
	init_label(mercury__relation__make_clique_map_6_0_i5);
	init_label(mercury__relation__make_clique_map_6_0_i6);
	init_label(mercury__relation__make_clique_map_6_0_i7);
	init_label(mercury__relation__make_clique_map_6_0_i8);
	init_label(mercury__relation__make_clique_map_6_0_i1003);
BEGIN_CODE

/* code for predicate 'relation__make_clique_map'/6 in mode 0 */
Define_static(mercury__relation__make_clique_map_6_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__make_clique_map_6_0_i1003);
	incr_sp_push_msg(7, "relation__make_clique_map");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(6) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__relation__make_clique_map_6_0_i4,
		STATIC(mercury__relation__make_clique_map_6_0));
	}
Define_label(mercury__relation__make_clique_map_6_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__make_clique_map_6_0));
	tag_incr_hp(r3, mktag(0), ((Integer) 4));
	r4 = (Integer) r1;
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) detstackvar(6);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) ENTRY(mercury__relation__lookup_key_3_0);
	field(mktag(0), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	{
	Declare_entry(mercury__list__map_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__relation__make_clique_map_6_0_i5,
		STATIC(mercury__relation__make_clique_map_6_0));
	}
Define_label(mercury__relation__make_clique_map_6_0_i5);
	update_prof_current_proc(LABEL(mercury__relation__make_clique_map_6_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__relation__make_clique_map_6_0_i6,
		STATIC(mercury__relation__make_clique_map_6_0));
	}
Define_label(mercury__relation__make_clique_map_6_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__make_clique_map_6_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(6);
	r3 = (Integer) r2;
	r2 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury__relation__add_element_4_0),
		mercury__relation__make_clique_map_6_0_i7,
		STATIC(mercury__relation__make_clique_map_6_0));
	}
Define_label(mercury__relation__make_clique_map_6_0_i7);
	update_prof_current_proc(LABEL(mercury__relation__make_clique_map_6_0));
	{
	Word tempr1;
	tempr1 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) tempr1;
	r3 = (Integer) detstackvar(5);
	call_localret(STATIC(mercury__relation__make_clique_map_2_4_0),
		mercury__relation__make_clique_map_6_0_i8,
		STATIC(mercury__relation__make_clique_map_6_0));
	}
Define_label(mercury__relation__make_clique_map_6_0_i8);
	update_prof_current_proc(LABEL(mercury__relation__make_clique_map_6_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(4);
	r5 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__relation__make_clique_map_6_0,
		STATIC(mercury__relation__make_clique_map_6_0));
Define_label(mercury__relation__make_clique_map_6_0_i1003);
	r1 = (Integer) r4;
	r2 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module72)
	init_entry(mercury__relation__make_clique_map_2_4_0);
	init_label(mercury__relation__make_clique_map_2_4_0_i4);
	init_label(mercury__relation__make_clique_map_2_4_0_i1002);
BEGIN_CODE

/* code for predicate 'relation__make_clique_map_2'/4 in mode 0 */
Define_static(mercury__relation__make_clique_map_2_4_0);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__make_clique_map_2_4_0_i1002);
	incr_sp_push_msg(3, "relation__make_clique_map_2");
	detstackvar(3) = (Integer) succip;
	r4 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	r3 = (Integer) r1;
	r5 = (Integer) r2;
	detstackvar(1) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__relation__make_clique_map_2_4_0_i4,
		STATIC(mercury__relation__make_clique_map_2_4_0));
	}
Define_label(mercury__relation__make_clique_map_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__make_clique_map_2_4_0));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__relation__make_clique_map_2_4_0,
		STATIC(mercury__relation__make_clique_map_2_4_0));
Define_label(mercury__relation__make_clique_map_2_4_0_i1002);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module73)
	init_entry(mercury__relation__atsort_2_5_0);
	init_label(mercury__relation__atsort_2_5_0_i6);
	init_label(mercury__relation__atsort_2_5_0_i5);
	init_label(mercury__relation__atsort_2_5_0_i9);
	init_label(mercury__relation__atsort_2_5_0_i10);
	init_label(mercury__relation__atsort_2_5_0_i11);
	init_label(mercury__relation__atsort_2_5_0_i1005);
BEGIN_CODE

/* code for predicate 'relation__atsort_2'/5 in mode 0 */
Define_static(mercury__relation__atsort_2_5_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__atsort_2_5_0_i1005);
	incr_sp_push_msg(7, "relation__atsort_2");
	detstackvar(7) = (Integer) succip;
	detstackvar(1) = (Integer) r3;
	detstackvar(5) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(6) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) r4;
	detstackvar(2) = (Integer) r4;
	detstackvar(3) = (Integer) r5;
	{
	Declare_entry(mercury__set_bbbtree__member_2_0);
	call_localret(ENTRY(mercury__set_bbbtree__member_2_0),
		mercury__relation__atsort_2_5_0_i6,
		STATIC(mercury__relation__atsort_2_5_0));
	}
Define_label(mercury__relation__atsort_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__relation__atsort_2_5_0_i5);
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r5 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__relation__atsort_2_5_0,
		STATIC(mercury__relation__atsort_2_5_0));
Define_label(mercury__relation__atsort_2_5_0_i5);
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__relation__dfs_3__ua10000_6_0),
		mercury__relation__atsort_2_5_0_i9,
		STATIC(mercury__relation__atsort_2_5_0));
Define_label(mercury__relation__atsort_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_5_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) r2;
	r2 = (Integer) detstackvar(6);
	tag_incr_hp(r3, mktag(0), ((Integer) 4));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = ((Integer) 2);
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) ENTRY(mercury__relation__lookup_key_3_0);
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) r2;
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__list__map_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__relation__atsort_2_5_0_i10,
		STATIC(mercury__relation__atsort_2_5_0));
	}
Define_label(mercury__relation__atsort_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_5_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__relation__atsort_2_5_0_i11,
		STATIC(mercury__relation__atsort_2_5_0));
	}
Define_label(mercury__relation__atsort_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__relation__atsort_2_5_0));
	r6 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	r2 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	tag_incr_hp(r5, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r5, ((Integer) 0)) = (Integer) r6;
	field(mktag(1), (Integer) r5, ((Integer) 1)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__relation__atsort_2_5_0,
		STATIC(mercury__relation__atsort_2_5_0));
Define_label(mercury__relation__atsort_2_5_0_i1005);
	r1 = (Integer) r5;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module74)
	init_entry(mercury__relation__rtc__init_map_3_0);
	init_label(mercury__relation__rtc__init_map_3_0_i4);
	init_label(mercury__relation__rtc__init_map_3_0_i1002);
BEGIN_CODE

/* code for predicate 'rtc__init_map'/3 in mode 0 */
Define_static(mercury__relation__rtc__init_map_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__relation__rtc__init_map_3_0_i1002);
	incr_sp_push_msg(2, "rtc__init_map");
	detstackvar(2) = (Integer) succip;
	r3 = (Integer) r1;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r5 = ((Integer) 0);
	{
	Declare_entry(mercury__map__det_insert_4_0);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__relation__rtc__init_map_3_0_i4,
		STATIC(mercury__relation__rtc__init_map_3_0));
	}
Define_label(mercury__relation__rtc__init_map_3_0_i4);
	update_prof_current_proc(LABEL(mercury__relation__rtc__init_map_3_0));
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	localtailcall(mercury__relation__rtc__init_map_3_0,
		STATIC(mercury__relation__rtc__init_map_3_0));
Define_label(mercury__relation__rtc__init_map_3_0_i1002);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module75)
	init_entry(mercury____Unify___relation__relation_1_0);
	init_label(mercury____Unify___relation__relation_1_0_i2);
	init_label(mercury____Unify___relation__relation_1_0_i4);
	init_label(mercury____Unify___relation__relation_1_0_i1004);
	init_label(mercury____Unify___relation__relation_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___relation__relation_1_0);
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r3, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___relation__relation_1_0_i1004);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___bimap__bimap_2_0);
	call_localret(ENTRY(mercury____Unify___bimap__bimap_2_0),
		mercury____Unify___relation__relation_1_0_i2,
		ENTRY(mercury____Unify___relation__relation_1_0));
	}
Define_label(mercury____Unify___relation__relation_1_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___relation__relation_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___relation__relation_1_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___relation__relation_1_0_i4,
		ENTRY(mercury____Unify___relation__relation_1_0));
	}
Define_label(mercury____Unify___relation__relation_1_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___relation__relation_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___relation__relation_1_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___relation__relation_1_0));
	}
Define_label(mercury____Unify___relation__relation_1_0_i1004);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___relation__relation_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module76)
	init_entry(mercury____Index___relation__relation_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___relation__relation_1_0);
	tailcall(STATIC(mercury____Index___relation_relation_1__ua10000_2_0),
		ENTRY(mercury____Index___relation__relation_1_0));
END_MODULE

BEGIN_MODULE(mercury__relation_module77)
	init_entry(mercury____Compare___relation__relation_1_0);
	init_label(mercury____Compare___relation__relation_1_0_i4);
	init_label(mercury____Compare___relation__relation_1_0_i5);
	init_label(mercury____Compare___relation__relation_1_0_i3);
	init_label(mercury____Compare___relation__relation_1_0_i10);
	init_label(mercury____Compare___relation__relation_1_0_i16);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___relation__relation_1_0);
	incr_sp_push_msg(8, "__Compare__");
	detstackvar(8) = (Integer) succip;
	detstackvar(7) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___relation__relation_1_0_i4,
		ENTRY(mercury____Compare___relation__relation_1_0));
	}
Define_label(mercury____Compare___relation__relation_1_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___relation__relation_1_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___relation__relation_1_0_i3);
Define_label(mercury____Compare___relation__relation_1_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	proceed();
Define_label(mercury____Compare___relation__relation_1_0_i3);
	r1 = (Integer) detstackvar(7);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury____Compare___bimap__bimap_2_0);
	call_localret(ENTRY(mercury____Compare___bimap__bimap_2_0),
		mercury____Compare___relation__relation_1_0_i10,
		ENTRY(mercury____Compare___relation__relation_1_0));
	}
Define_label(mercury____Compare___relation__relation_1_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___relation__relation_1_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___relation__relation_1_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___relation__relation_1_0_i16,
		ENTRY(mercury____Compare___relation__relation_1_0));
	}
Define_label(mercury____Compare___relation__relation_1_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___relation__relation_1_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___relation__relation_1_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_relation__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(8);
	decr_sp_pop_msg(8);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___relation__relation_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module78)
	init_entry(mercury____Unify___relation__relation_key_0_0);
	init_label(mercury____Unify___relation__relation_key_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___relation__relation_key_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___relation__relation_key_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___relation__relation_key_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__relation_module79)
	init_entry(mercury____Index___relation__relation_key_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___relation__relation_key_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___relation__relation_key_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__relation_module80)
	init_entry(mercury____Compare___relation__relation_key_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___relation__relation_key_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___relation__relation_key_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__relation_bunch_0(void)
{
	mercury__relation_module0();
	mercury__relation_module1();
	mercury__relation_module2();
	mercury__relation_module3();
	mercury__relation_module4();
	mercury__relation_module5();
	mercury__relation_module6();
	mercury__relation_module7();
	mercury__relation_module8();
	mercury__relation_module9();
	mercury__relation_module10();
	mercury__relation_module11();
	mercury__relation_module12();
	mercury__relation_module13();
	mercury__relation_module14();
	mercury__relation_module15();
	mercury__relation_module16();
	mercury__relation_module17();
	mercury__relation_module18();
	mercury__relation_module19();
	mercury__relation_module20();
	mercury__relation_module21();
	mercury__relation_module22();
	mercury__relation_module23();
	mercury__relation_module24();
	mercury__relation_module25();
	mercury__relation_module26();
	mercury__relation_module27();
	mercury__relation_module28();
	mercury__relation_module29();
	mercury__relation_module30();
	mercury__relation_module31();
	mercury__relation_module32();
	mercury__relation_module33();
	mercury__relation_module34();
	mercury__relation_module35();
	mercury__relation_module36();
	mercury__relation_module37();
	mercury__relation_module38();
	mercury__relation_module39();
	mercury__relation_module40();
}

static void mercury__relation_bunch_1(void)
{
	mercury__relation_module41();
	mercury__relation_module42();
	mercury__relation_module43();
	mercury__relation_module44();
	mercury__relation_module45();
	mercury__relation_module46();
	mercury__relation_module47();
	mercury__relation_module48();
	mercury__relation_module49();
	mercury__relation_module50();
	mercury__relation_module51();
	mercury__relation_module52();
	mercury__relation_module53();
	mercury__relation_module54();
	mercury__relation_module55();
	mercury__relation_module56();
	mercury__relation_module57();
	mercury__relation_module58();
	mercury__relation_module59();
	mercury__relation_module60();
	mercury__relation_module61();
	mercury__relation_module62();
	mercury__relation_module63();
	mercury__relation_module64();
	mercury__relation_module65();
	mercury__relation_module66();
	mercury__relation_module67();
	mercury__relation_module68();
	mercury__relation_module69();
	mercury__relation_module70();
	mercury__relation_module71();
	mercury__relation_module72();
	mercury__relation_module73();
	mercury__relation_module74();
	mercury__relation_module75();
	mercury__relation_module76();
	mercury__relation_module77();
	mercury__relation_module78();
	mercury__relation_module79();
	mercury__relation_module80();
}

#endif

void mercury__relation__init(void); /* suppress gcc warning */
void mercury__relation__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__relation_bunch_0();
	mercury__relation_bunch_1();
#endif
}
