/*
** Automatically generated from `ops.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__ops__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury__ops__lookup_op__ua0_2_0);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i5);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i1002);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i7);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i1026);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i11);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i1030);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i53);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i1034);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i3);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i2);
Declare_label(mercury__ops__lookup_op__ua0_2_0_i1042);
Declare_static(mercury__ops__lookup_postfix_op__ua0_4_0);
Declare_label(mercury__ops__lookup_postfix_op__ua0_4_0_i2);
Declare_label(mercury__ops__lookup_postfix_op__ua0_4_0_i4);
Declare_label(mercury__ops__lookup_postfix_op__ua0_4_0_i5);
Declare_label(mercury__ops__lookup_postfix_op__ua0_4_0_i1);
Declare_static(mercury__ops__lookup_binary_prefix_op__ua0_5_0);
Declare_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i2);
Declare_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i4);
Declare_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i5);
Declare_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i1);
Declare_static(mercury__ops__lookup_prefix_op__ua0_4_0);
Declare_label(mercury__ops__lookup_prefix_op__ua0_4_0_i2);
Declare_label(mercury__ops__lookup_prefix_op__ua0_4_0_i4);
Declare_label(mercury__ops__lookup_prefix_op__ua0_4_0_i5);
Declare_label(mercury__ops__lookup_prefix_op__ua0_4_0_i1);
Declare_static(mercury__ops__lookup_infix_op__ua0_5_0);
Declare_label(mercury__ops__lookup_infix_op__ua0_5_0_i2);
Declare_label(mercury__ops__lookup_infix_op__ua0_5_0_i4);
Declare_label(mercury__ops__lookup_infix_op__ua0_5_0_i5);
Declare_label(mercury__ops__lookup_infix_op__ua0_5_0_i1);
Define_extern_entry(mercury__ops__init_op_table_1_0);
Define_extern_entry(mercury__ops__lookup_infix_op_5_0);
Declare_label(mercury__ops__lookup_infix_op_5_0_i2);
Declare_label(mercury__ops__lookup_infix_op_5_0_i1000);
Define_extern_entry(mercury__ops__lookup_prefix_op_4_0);
Declare_label(mercury__ops__lookup_prefix_op_4_0_i2);
Declare_label(mercury__ops__lookup_prefix_op_4_0_i1000);
Define_extern_entry(mercury__ops__lookup_binary_prefix_op_5_0);
Declare_label(mercury__ops__lookup_binary_prefix_op_5_0_i2);
Declare_label(mercury__ops__lookup_binary_prefix_op_5_0_i1000);
Define_extern_entry(mercury__ops__lookup_postfix_op_4_0);
Declare_label(mercury__ops__lookup_postfix_op_4_0_i2);
Declare_label(mercury__ops__lookup_postfix_op_4_0_i1000);
Define_extern_entry(mercury__ops__lookup_op_2_0);
Define_extern_entry(mercury__ops__op_specifier_to_class_2_0);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i3);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i4);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i5);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i6);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i7);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i8);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i9);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i10);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i11);
Declare_label(mercury__ops__op_specifier_to_class_2_0_i12);
Declare_static(mercury__ops__op_table_4_0);
Declare_label(mercury__ops__op_table_4_0_i3);
Declare_label(mercury__ops__op_table_4_0_i1000);
Declare_label(mercury__ops__op_table_4_0_i5);
Declare_label(mercury__ops__op_table_4_0_i6);
Declare_label(mercury__ops__op_table_4_0_i8);
Declare_label(mercury__ops__op_table_4_0_i9);
Declare_label(mercury__ops__op_table_4_0_i11);
Declare_label(mercury__ops__op_table_4_0_i13);
Declare_label(mercury__ops__op_table_4_0_i15);
Declare_label(mercury__ops__op_table_4_0_i19);
Declare_label(mercury__ops__op_table_4_0_i25);
Declare_label(mercury__ops__op_table_4_0_i27);
Declare_label(mercury__ops__op_table_4_0_i33);
Declare_label(mercury__ops__op_table_4_0_i35);
Declare_label(mercury__ops__op_table_4_0_i39);
Declare_label(mercury__ops__op_table_4_0_i48);
Declare_label(mercury__ops__op_table_4_0_i52);
Declare_label(mercury__ops__op_table_4_0_i54);
Declare_label(mercury__ops__op_table_4_0_i58);
Declare_label(mercury__ops__op_table_4_0_i62);
Declare_label(mercury__ops__op_table_4_0_i66);
Declare_label(mercury__ops__op_table_4_0_i78);
Declare_label(mercury__ops__op_table_4_0_i80);
Declare_label(mercury__ops__op_table_4_0_i82);
Declare_label(mercury__ops__op_table_4_0_i83);
Declare_label(mercury__ops__op_table_4_0_i85);
Declare_label(mercury__ops__op_table_4_0_i89);
Declare_label(mercury__ops__op_table_4_0_i105);
Declare_label(mercury__ops__op_table_4_0_i115);
Declare_label(mercury__ops__op_table_4_0_i119);
Declare_label(mercury__ops__op_table_4_0_i131);
Declare_label(mercury__ops__op_table_4_0_i147);
Declare_label(mercury__ops__op_table_4_0_i159);
Declare_label(mercury__ops__op_table_4_0_i1);
Define_extern_entry(mercury____Unify___ops__specifier_0_0);
Declare_label(mercury____Unify___ops__specifier_0_0_i1);
Define_extern_entry(mercury____Index___ops__specifier_0_0);
Define_extern_entry(mercury____Compare___ops__specifier_0_0);
Define_extern_entry(mercury____Unify___ops__assoc_0_0);
Declare_label(mercury____Unify___ops__assoc_0_0_i1);
Define_extern_entry(mercury____Index___ops__assoc_0_0);
Define_extern_entry(mercury____Compare___ops__assoc_0_0);
Define_extern_entry(mercury____Unify___ops__class_0_0);
Declare_label(mercury____Unify___ops__class_0_0_i4);
Declare_label(mercury____Unify___ops__class_0_0_i6);
Declare_label(mercury____Unify___ops__class_0_0_i8);
Declare_label(mercury____Unify___ops__class_0_0_i1);
Define_extern_entry(mercury____Index___ops__class_0_0);
Declare_label(mercury____Index___ops__class_0_0_i4);
Declare_label(mercury____Index___ops__class_0_0_i5);
Declare_label(mercury____Index___ops__class_0_0_i6);
Define_extern_entry(mercury____Compare___ops__class_0_0);
Declare_label(mercury____Compare___ops__class_0_0_i2);
Declare_label(mercury____Compare___ops__class_0_0_i3);
Declare_label(mercury____Compare___ops__class_0_0_i4);
Declare_label(mercury____Compare___ops__class_0_0_i6);
Declare_label(mercury____Compare___ops__class_0_0_i16);
Declare_label(mercury____Compare___ops__class_0_0_i17);
Declare_label(mercury____Compare___ops__class_0_0_i15);
Declare_label(mercury____Compare___ops__class_0_0_i12);
Declare_label(mercury____Compare___ops__class_0_0_i22);
Declare_label(mercury____Compare___ops__class_0_0_i29);
Declare_label(mercury____Compare___ops__class_0_0_i25);
Declare_label(mercury____Compare___ops__class_0_0_i9);
Declare_label(mercury____Compare___ops__class_0_0_i1001);
Define_extern_entry(mercury____Unify___ops__table_0_0);
Declare_label(mercury____Unify___ops__table_0_0_i1);
Define_extern_entry(mercury____Index___ops__table_0_0);
Define_extern_entry(mercury____Compare___ops__table_0_0);
Define_extern_entry(mercury____Unify___ops__priority_0_0);
Declare_label(mercury____Unify___ops__priority_0_0_i1);
Define_extern_entry(mercury____Index___ops__priority_0_0);
Define_extern_entry(mercury____Compare___ops__priority_0_0);

extern Word * mercury_data_ops__base_type_layout_ops__assoc_0[];
Word * mercury_data_ops__base_type_info_ops__assoc_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___ops__assoc_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___ops__assoc_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___ops__assoc_0_0),
	(Word *) (Integer) mercury_data_ops__base_type_layout_ops__assoc_0
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_ops__base_type_layout_ops__category_0[];
Word * mercury_data_ops__base_type_info_ops__category_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_ops__base_type_layout_ops__category_0
};

extern Word * mercury_data_ops__base_type_layout_ops__class_0[];
Word * mercury_data_ops__base_type_info_ops__class_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___ops__class_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___ops__class_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___ops__class_0_0),
	(Word *) (Integer) mercury_data_ops__base_type_layout_ops__class_0
};

extern Word * mercury_data_ops__base_type_layout_ops__priority_0[];
Word * mercury_data_ops__base_type_info_ops__priority_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___ops__priority_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___ops__priority_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___ops__priority_0_0),
	(Word *) (Integer) mercury_data_ops__base_type_layout_ops__priority_0
};

extern Word * mercury_data_ops__base_type_layout_ops__specifier_0[];
Word * mercury_data_ops__base_type_info_ops__specifier_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___ops__specifier_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___ops__specifier_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___ops__specifier_0_0),
	(Word *) (Integer) mercury_data_ops__base_type_layout_ops__specifier_0
};

extern Word * mercury_data_ops__base_type_layout_ops__table_0[];
Word * mercury_data_ops__base_type_info_ops__table_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___ops__table_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___ops__table_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___ops__table_0_0),
	(Word *) (Integer) mercury_data_ops__base_type_layout_ops__table_0
};

extern Word * mercury_data_ops__common_7[];
Word * mercury_data_ops__base_type_layout_ops__table_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_7)
};

extern Word * mercury_data_ops__common_8[];
Word * mercury_data_ops__base_type_layout_ops__specifier_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_8),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_8)
};

extern Word * mercury_data_ops__common_10[];
Word * mercury_data_ops__base_type_layout_ops__priority_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_ops__common_10),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_ops__common_10),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_ops__common_10),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_ops__common_10)
};

extern Word * mercury_data_ops__common_12[];
extern Word * mercury_data_ops__common_13[];
extern Word * mercury_data_ops__common_14[];
extern Word * mercury_data_ops__common_15[];
Word * mercury_data_ops__base_type_layout_ops__class_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_ops__common_12),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_ops__common_13),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_ops__common_14),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_ops__common_15)
};

extern Word * mercury_data_ops__common_16[];
Word * mercury_data_ops__base_type_layout_ops__category_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_16),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_16),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_16),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_16)
};

extern Word * mercury_data_ops__common_17[];
Word * mercury_data_ops__base_type_layout_ops__assoc_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_17),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_17)
};

Word * mercury_data_ops__common_0[] = {
	(Word *) ((Integer) 0),
	(Word *) string_const("+", 1),
	(Word *) string_const(",", 1),
	(Word *) string_const("import_cons", 11),
	(Word *) string_const("**", 2),
	(Word *) string_const("mod", 3),
	(Word *) string_const("export_module", 13),
	(Word *) string_const("<=>", 3),
	(Word *) string_const("end_module", 10),
	(Word *) string_const("=>", 2),
	(Word *) string_const("and", 3),
	(Word *) string_const("//", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("import_type", 11),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("export_sym", 10),
	(Word *) string_const("--->", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("func", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("mode", 4),
	(Word *) string_const("where", 5),
	(Word *) ((Integer) 0),
	(Word *) string_const("import_pred", 11),
	(Word *) string_const("*", 1),
	(Word *) string_const("-", 1),
	(Word *) string_const("if", 2),
	(Word *) string_const("/", 1),
	(Word *) string_const(".", 1),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("then", 4),
	(Word *) ((Integer) 0),
	(Word *) string_const("import_module", 13),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("is", 2),
	(Word *) string_const("import_adt", 10),
	(Word *) string_const(";", 1),
	(Word *) string_const(":", 1),
	(Word *) string_const("=", 1),
	(Word *) string_const("<", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const(">", 1),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("::", 2),
	(Word *) ((Integer) 0),
	(Word *) string_const("inst", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("use_adt", 7),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("when", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const(":-", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("^", 1),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("import_op", 9),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("~", 1),
	(Word *) ((Integer) 0),
	(Word *) string_const("export_cons", 11),
	(Word *) string_const("<<", 2),
	(Word *) string_const("<=", 2),
	(Word *) ((Integer) 0),
	(Word *) string_const("use_cons", 8),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("use_module", 10),
	(Word *) ((Integer) 0),
	(Word *) string_const("pragma", 6),
	(Word *) string_const("import_sym", 10),
	(Word *) ((Integer) 0),
	(Word *) string_const("/\\", 2),
	(Word *) ((Integer) 0),
	(Word *) string_const("export_pred", 11),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("not", 3),
	(Word *) string_const("use_pred", 8),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("type", 4),
	(Word *) string_const("-->", 3),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("export_adt", 10),
	(Word *) string_const("lambda", 6),
	(Word *) string_const("==", 2),
	(Word *) string_const("=<", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("pred", 4),
	(Word *) string_const("export_type", 11),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("use_type", 8),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("->", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("module", 6),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const(">=", 2),
	(Word *) string_const(">>", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("use_op", 6),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("rule", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("export_op", 9),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("some", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("else", 4),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("all", 3),
	(Word *) string_const("\\=", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\/", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("\\+", 2),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("use_sym", 7),
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 0),
	(Word *) string_const("or", 2)
};

Word mercury_data_ops__common_1[] = {
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) 1),
	((Integer) -1),
	((Integer) -1),
	((Integer) 2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) 3),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) 4),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) 5),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 6),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 7),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) 8),
	((Integer) 9),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) 10),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) 11),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1),
	((Integer) -2),
	((Integer) -2),
	((Integer) -1)
};

Word mercury_data_ops__common_2[] = {
	((Integer) 0)
};

Word mercury_data_ops__common_3[] = {
	((Integer) 1)
};

Word mercury_data_ops__common_4[] = {
	((Integer) 0),
	((Integer) 0)
};

Word mercury_data_ops__common_5[] = {
	((Integer) 1),
	((Integer) 0)
};

Word mercury_data_ops__common_6[] = {
	((Integer) 0),
	((Integer) 1)
};

Word * mercury_data_ops__common_7[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 1),
	(Word *) string_const("ops__table", 10)
};

Word * mercury_data_ops__common_8[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 10),
	(Word *) string_const("fx", 2),
	(Word *) string_const("fy", 2),
	(Word *) string_const("xf", 2),
	(Word *) string_const("yf", 2),
	(Word *) string_const("xfx", 3),
	(Word *) string_const("yfx", 3),
	(Word *) string_const("xfy", 3),
	(Word *) string_const("fxx", 3),
	(Word *) string_const("fxy", 3),
	(Word *) string_const("fyx", 3)
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_ops__common_9[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_ops__common_10[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_9)
};

Word * mercury_data_ops__common_11[] = {
	(Word *) (Integer) mercury_data_ops__base_type_info_ops__assoc_0
};

Word * mercury_data_ops__common_12[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_11),
	(Word *) string_const("infix", 5)
};

Word * mercury_data_ops__common_13[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_11),
	(Word *) string_const("prefix", 6)
};

Word * mercury_data_ops__common_14[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_11),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_11),
	(Word *) string_const("binary_prefix", 13)
};

Word * mercury_data_ops__common_15[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_11),
	(Word *) string_const("postfix", 7)
};

Word * mercury_data_ops__common_16[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("before", 6),
	(Word *) string_const("after", 5)
};

Word * mercury_data_ops__common_17[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2),
	(Word *) string_const("x", 1),
	(Word *) string_const("y", 1)
};

BEGIN_MODULE(mercury__ops_module0)
	init_entry(mercury__ops__lookup_op__ua0_2_0);
	init_label(mercury__ops__lookup_op__ua0_2_0_i5);
	init_label(mercury__ops__lookup_op__ua0_2_0_i1002);
	init_label(mercury__ops__lookup_op__ua0_2_0_i7);
	init_label(mercury__ops__lookup_op__ua0_2_0_i1026);
	init_label(mercury__ops__lookup_op__ua0_2_0_i11);
	init_label(mercury__ops__lookup_op__ua0_2_0_i1030);
	init_label(mercury__ops__lookup_op__ua0_2_0_i53);
	init_label(mercury__ops__lookup_op__ua0_2_0_i1034);
	init_label(mercury__ops__lookup_op__ua0_2_0_i3);
	init_label(mercury__ops__lookup_op__ua0_2_0_i2);
	init_label(mercury__ops__lookup_op__ua0_2_0_i1042);
BEGIN_CODE

/* code for predicate 'ops__lookup_op__ua0'/2 in mode 0 */
Define_static(mercury__ops__lookup_op__ua0_2_0);
	incr_sp_push_msg(3, "ops__lookup_op__ua0");
	detstackvar(1) = (Integer) curfr;
	detstackvar(2) = (Integer) maxfr;
	detstackvar(3) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__ops__lookup_op__ua0_2_0_i3);
	r2 = (hash_string((Integer) r1) & ((Integer) 255));
Define_label(mercury__ops__lookup_op__ua0_2_0_i5);
	r3 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_0))[(Integer) r2];
	if (!((Integer) r3))
		GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i1002);
	if ((strcmp((char *)(Integer) r3, (char *)(Integer) r1) ==0))
		GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i7);
Define_label(mercury__ops__lookup_op__ua0_2_0_i1002);
	r2 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_1))[(Integer) r2];
	if (((Integer) r2 >= ((Integer) 0)))
		GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i5);
	GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i1042);
Define_label(mercury__ops__lookup_op__ua0_2_0_i7);
	COMPUTED_GOTO((Integer) r2,
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1026) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1026) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1030) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1042) AND
		LABEL(mercury__ops__lookup_op__ua0_2_0_i1034));
Define_label(mercury__ops__lookup_op__ua0_2_0_i1026);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__ops__lookup_op__ua0_2_0_i11);
	GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i1034);
Define_label(mercury__ops__lookup_op__ua0_2_0_i11);
	update_prof_current_proc(LABEL(mercury__ops__lookup_op__ua0_2_0));
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__ops__lookup_op__ua0_2_0_i2);
	GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i1034);
Define_label(mercury__ops__lookup_op__ua0_2_0_i1030);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__ops__lookup_op__ua0_2_0_i53);
	GOTO_LABEL(mercury__ops__lookup_op__ua0_2_0_i1034);
Define_label(mercury__ops__lookup_op__ua0_2_0_i53);
	update_prof_current_proc(LABEL(mercury__ops__lookup_op__ua0_2_0));
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__ops__lookup_op__ua0_2_0_i2);
Define_label(mercury__ops__lookup_op__ua0_2_0_i1034);
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(2);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(3);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(1);
	decr_sp_pop_msg(3);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__lookup_op__ua0_2_0_i3);
	update_prof_current_proc(LABEL(mercury__ops__lookup_op__ua0_2_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(1);
Define_label(mercury__ops__lookup_op__ua0_2_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_op__ua0_2_0));
Define_label(mercury__ops__lookup_op__ua0_2_0_i1042);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module1)
	init_entry(mercury__ops__lookup_postfix_op__ua0_4_0);
	init_label(mercury__ops__lookup_postfix_op__ua0_4_0_i2);
	init_label(mercury__ops__lookup_postfix_op__ua0_4_0_i4);
	init_label(mercury__ops__lookup_postfix_op__ua0_4_0_i5);
	init_label(mercury__ops__lookup_postfix_op__ua0_4_0_i1);
BEGIN_CODE

/* code for predicate 'ops__lookup_postfix_op__ua0'/4 in mode 0 */
Define_static(mercury__ops__lookup_postfix_op__ua0_4_0);
	r2 = ((Integer) 1);
	incr_sp_push_msg(3, "ops__lookup_postfix_op__ua0");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__ops__op_table_4_0),
		mercury__ops__lookup_postfix_op__ua0_4_0_i2,
		STATIC(mercury__ops__lookup_postfix_op__ua0_4_0));
Define_label(mercury__ops__lookup_postfix_op__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_postfix_op__ua0_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_postfix_op__ua0_4_0_i1);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__f_cut_0_0);
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__ops__lookup_postfix_op__ua0_4_0_i4,
		STATIC(mercury__ops__lookup_postfix_op__ua0_4_0));
	}
Define_label(mercury__ops__lookup_postfix_op__ua0_4_0_i4);
	update_prof_current_proc(LABEL(mercury__ops__lookup_postfix_op__ua0_4_0));
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__ops__op_specifier_to_class_2_0),
		mercury__ops__lookup_postfix_op__ua0_4_0_i5,
		STATIC(mercury__ops__lookup_postfix_op__ua0_4_0));
	}
Define_label(mercury__ops__lookup_postfix_op__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ops__lookup_postfix_op__ua0_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__ops__lookup_postfix_op__ua0_4_0_i1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ops__lookup_postfix_op__ua0_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module2)
	init_entry(mercury__ops__lookup_binary_prefix_op__ua0_5_0);
	init_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i2);
	init_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i4);
	init_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i5);
	init_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i1);
BEGIN_CODE

/* code for predicate 'ops__lookup_binary_prefix_op__ua0'/5 in mode 0 */
Define_static(mercury__ops__lookup_binary_prefix_op__ua0_5_0);
	r2 = ((Integer) 0);
	incr_sp_push_msg(3, "ops__lookup_binary_prefix_op__ua0");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__ops__op_table_4_0),
		mercury__ops__lookup_binary_prefix_op__ua0_5_0_i2,
		STATIC(mercury__ops__lookup_binary_prefix_op__ua0_5_0));
Define_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_binary_prefix_op__ua0_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i1);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__f_cut_0_0);
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__ops__lookup_binary_prefix_op__ua0_5_0_i4,
		STATIC(mercury__ops__lookup_binary_prefix_op__ua0_5_0));
	}
Define_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__ops__lookup_binary_prefix_op__ua0_5_0));
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__ops__op_specifier_to_class_2_0),
		mercury__ops__lookup_binary_prefix_op__ua0_5_0_i5,
		STATIC(mercury__ops__lookup_binary_prefix_op__ua0_5_0));
	}
Define_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__ops__lookup_binary_prefix_op__ua0_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ops__lookup_binary_prefix_op__ua0_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module3)
	init_entry(mercury__ops__lookup_prefix_op__ua0_4_0);
	init_label(mercury__ops__lookup_prefix_op__ua0_4_0_i2);
	init_label(mercury__ops__lookup_prefix_op__ua0_4_0_i4);
	init_label(mercury__ops__lookup_prefix_op__ua0_4_0_i5);
	init_label(mercury__ops__lookup_prefix_op__ua0_4_0_i1);
BEGIN_CODE

/* code for predicate 'ops__lookup_prefix_op__ua0'/4 in mode 0 */
Define_static(mercury__ops__lookup_prefix_op__ua0_4_0);
	r2 = ((Integer) 0);
	incr_sp_push_msg(3, "ops__lookup_prefix_op__ua0");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__ops__op_table_4_0),
		mercury__ops__lookup_prefix_op__ua0_4_0_i2,
		STATIC(mercury__ops__lookup_prefix_op__ua0_4_0));
Define_label(mercury__ops__lookup_prefix_op__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_prefix_op__ua0_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_prefix_op__ua0_4_0_i1);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__f_cut_0_0);
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__ops__lookup_prefix_op__ua0_4_0_i4,
		STATIC(mercury__ops__lookup_prefix_op__ua0_4_0));
	}
Define_label(mercury__ops__lookup_prefix_op__ua0_4_0_i4);
	update_prof_current_proc(LABEL(mercury__ops__lookup_prefix_op__ua0_4_0));
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__ops__op_specifier_to_class_2_0),
		mercury__ops__lookup_prefix_op__ua0_4_0_i5,
		STATIC(mercury__ops__lookup_prefix_op__ua0_4_0));
	}
Define_label(mercury__ops__lookup_prefix_op__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ops__lookup_prefix_op__ua0_4_0));
	if ((tag((Integer) r1) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__ops__lookup_prefix_op__ua0_4_0_i1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ops__lookup_prefix_op__ua0_4_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module4)
	init_entry(mercury__ops__lookup_infix_op__ua0_5_0);
	init_label(mercury__ops__lookup_infix_op__ua0_5_0_i2);
	init_label(mercury__ops__lookup_infix_op__ua0_5_0_i4);
	init_label(mercury__ops__lookup_infix_op__ua0_5_0_i5);
	init_label(mercury__ops__lookup_infix_op__ua0_5_0_i1);
BEGIN_CODE

/* code for predicate 'ops__lookup_infix_op__ua0'/5 in mode 0 */
Define_static(mercury__ops__lookup_infix_op__ua0_5_0);
	r2 = ((Integer) 1);
	incr_sp_push_msg(3, "ops__lookup_infix_op__ua0");
	detstackvar(3) = (Integer) succip;
	call_localret(STATIC(mercury__ops__op_table_4_0),
		mercury__ops__lookup_infix_op__ua0_5_0_i2,
		STATIC(mercury__ops__lookup_infix_op__ua0_5_0));
Define_label(mercury__ops__lookup_infix_op__ua0_5_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_infix_op__ua0_5_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_infix_op__ua0_5_0_i1);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	{
	Declare_entry(mercury__f_cut_0_0);
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__ops__lookup_infix_op__ua0_5_0_i4,
		STATIC(mercury__ops__lookup_infix_op__ua0_5_0));
	}
Define_label(mercury__ops__lookup_infix_op__ua0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__ops__lookup_infix_op__ua0_5_0));
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury__ops__op_specifier_to_class_2_0),
		mercury__ops__lookup_infix_op__ua0_5_0_i5,
		STATIC(mercury__ops__lookup_infix_op__ua0_5_0));
	}
Define_label(mercury__ops__lookup_infix_op__ua0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__ops__lookup_infix_op__ua0_5_0));
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__ops__lookup_infix_op__ua0_5_0_i1);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r4 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ops__lookup_infix_op__ua0_5_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module5)
	init_entry(mercury__ops__init_op_table_1_0);
BEGIN_CODE

/* code for predicate 'ops__init_op_table'/1 in mode 0 */
Define_entry(mercury__ops__init_op_table_1_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module6)
	init_entry(mercury__ops__lookup_infix_op_5_0);
	init_label(mercury__ops__lookup_infix_op_5_0_i2);
	init_label(mercury__ops__lookup_infix_op_5_0_i1000);
BEGIN_CODE

/* code for predicate 'ops__lookup_infix_op'/5 in mode 0 */
Define_entry(mercury__ops__lookup_infix_op_5_0);
	incr_sp_push_msg(2, "ops__lookup_infix_op");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__ops__lookup_infix_op__ua0_5_0),
		mercury__ops__lookup_infix_op_5_0_i2,
		ENTRY(mercury__ops__lookup_infix_op_5_0));
Define_label(mercury__ops__lookup_infix_op_5_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_infix_op_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_infix_op_5_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__lookup_infix_op_5_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module7)
	init_entry(mercury__ops__lookup_prefix_op_4_0);
	init_label(mercury__ops__lookup_prefix_op_4_0_i2);
	init_label(mercury__ops__lookup_prefix_op_4_0_i1000);
BEGIN_CODE

/* code for predicate 'ops__lookup_prefix_op'/4 in mode 0 */
Define_entry(mercury__ops__lookup_prefix_op_4_0);
	incr_sp_push_msg(2, "ops__lookup_prefix_op");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__ops__lookup_prefix_op__ua0_4_0),
		mercury__ops__lookup_prefix_op_4_0_i2,
		ENTRY(mercury__ops__lookup_prefix_op_4_0));
Define_label(mercury__ops__lookup_prefix_op_4_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_prefix_op_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_prefix_op_4_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__lookup_prefix_op_4_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module8)
	init_entry(mercury__ops__lookup_binary_prefix_op_5_0);
	init_label(mercury__ops__lookup_binary_prefix_op_5_0_i2);
	init_label(mercury__ops__lookup_binary_prefix_op_5_0_i1000);
BEGIN_CODE

/* code for predicate 'ops__lookup_binary_prefix_op'/5 in mode 0 */
Define_entry(mercury__ops__lookup_binary_prefix_op_5_0);
	incr_sp_push_msg(2, "ops__lookup_binary_prefix_op");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__ops__lookup_binary_prefix_op__ua0_5_0),
		mercury__ops__lookup_binary_prefix_op_5_0_i2,
		ENTRY(mercury__ops__lookup_binary_prefix_op_5_0));
Define_label(mercury__ops__lookup_binary_prefix_op_5_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_binary_prefix_op_5_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_binary_prefix_op_5_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__lookup_binary_prefix_op_5_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module9)
	init_entry(mercury__ops__lookup_postfix_op_4_0);
	init_label(mercury__ops__lookup_postfix_op_4_0_i2);
	init_label(mercury__ops__lookup_postfix_op_4_0_i1000);
BEGIN_CODE

/* code for predicate 'ops__lookup_postfix_op'/4 in mode 0 */
Define_entry(mercury__ops__lookup_postfix_op_4_0);
	incr_sp_push_msg(2, "ops__lookup_postfix_op");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury__ops__lookup_postfix_op__ua0_4_0),
		mercury__ops__lookup_postfix_op_4_0_i2,
		ENTRY(mercury__ops__lookup_postfix_op_4_0));
Define_label(mercury__ops__lookup_postfix_op_4_0_i2);
	update_prof_current_proc(LABEL(mercury__ops__lookup_postfix_op_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__ops__lookup_postfix_op_4_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__lookup_postfix_op_4_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module10)
	init_entry(mercury__ops__lookup_op_2_0);
BEGIN_CODE

/* code for predicate 'ops__lookup_op'/2 in mode 0 */
Define_entry(mercury__ops__lookup_op_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__ops__lookup_op__ua0_2_0),
		ENTRY(mercury__ops__lookup_op_2_0));
END_MODULE

BEGIN_MODULE(mercury__ops_module11)
	init_entry(mercury__ops__op_specifier_to_class_2_0);
	init_label(mercury__ops__op_specifier_to_class_2_0_i3);
	init_label(mercury__ops__op_specifier_to_class_2_0_i4);
	init_label(mercury__ops__op_specifier_to_class_2_0_i5);
	init_label(mercury__ops__op_specifier_to_class_2_0_i6);
	init_label(mercury__ops__op_specifier_to_class_2_0_i7);
	init_label(mercury__ops__op_specifier_to_class_2_0_i8);
	init_label(mercury__ops__op_specifier_to_class_2_0_i9);
	init_label(mercury__ops__op_specifier_to_class_2_0_i10);
	init_label(mercury__ops__op_specifier_to_class_2_0_i11);
	init_label(mercury__ops__op_specifier_to_class_2_0_i12);
BEGIN_CODE

/* code for predicate 'ops__op_specifier_to_class'/2 in mode 0 */
Define_entry(mercury__ops__op_specifier_to_class_2_0);
	COMPUTED_GOTO((Integer) r1,
		LABEL(mercury__ops__op_specifier_to_class_2_0_i3) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i4) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i5) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i6) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i7) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i8) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i9) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i10) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i11) AND
		LABEL(mercury__ops__op_specifier_to_class_2_0_i12));
Define_label(mercury__ops__op_specifier_to_class_2_0_i3);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_ops__common_2);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i4);
	r1 = (Integer) mkword(mktag(1), (Integer) mercury_data_ops__common_3);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i5);
	r1 = (Integer) mkword(mktag(3), (Integer) mercury_data_ops__common_2);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i6);
	r1 = (Integer) mkword(mktag(3), (Integer) mercury_data_ops__common_3);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i7);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_4);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i8);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_5);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i9);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_6);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i10);
	r1 = (Integer) mkword(mktag(2), (Integer) mercury_data_ops__common_4);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i11);
	r1 = (Integer) mkword(mktag(2), (Integer) mercury_data_ops__common_6);
	proceed();
Define_label(mercury__ops__op_specifier_to_class_2_0_i12);
	r1 = (Integer) mkword(mktag(2), (Integer) mercury_data_ops__common_5);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module12)
	init_entry(mercury__ops__op_table_4_0);
	init_label(mercury__ops__op_table_4_0_i3);
	init_label(mercury__ops__op_table_4_0_i1000);
	init_label(mercury__ops__op_table_4_0_i5);
	init_label(mercury__ops__op_table_4_0_i6);
	init_label(mercury__ops__op_table_4_0_i8);
	init_label(mercury__ops__op_table_4_0_i9);
	init_label(mercury__ops__op_table_4_0_i11);
	init_label(mercury__ops__op_table_4_0_i13);
	init_label(mercury__ops__op_table_4_0_i15);
	init_label(mercury__ops__op_table_4_0_i19);
	init_label(mercury__ops__op_table_4_0_i25);
	init_label(mercury__ops__op_table_4_0_i27);
	init_label(mercury__ops__op_table_4_0_i33);
	init_label(mercury__ops__op_table_4_0_i35);
	init_label(mercury__ops__op_table_4_0_i39);
	init_label(mercury__ops__op_table_4_0_i48);
	init_label(mercury__ops__op_table_4_0_i52);
	init_label(mercury__ops__op_table_4_0_i54);
	init_label(mercury__ops__op_table_4_0_i58);
	init_label(mercury__ops__op_table_4_0_i62);
	init_label(mercury__ops__op_table_4_0_i66);
	init_label(mercury__ops__op_table_4_0_i78);
	init_label(mercury__ops__op_table_4_0_i80);
	init_label(mercury__ops__op_table_4_0_i82);
	init_label(mercury__ops__op_table_4_0_i83);
	init_label(mercury__ops__op_table_4_0_i85);
	init_label(mercury__ops__op_table_4_0_i89);
	init_label(mercury__ops__op_table_4_0_i105);
	init_label(mercury__ops__op_table_4_0_i115);
	init_label(mercury__ops__op_table_4_0_i119);
	init_label(mercury__ops__op_table_4_0_i131);
	init_label(mercury__ops__op_table_4_0_i147);
	init_label(mercury__ops__op_table_4_0_i159);
	init_label(mercury__ops__op_table_4_0_i1);
BEGIN_CODE

/* code for predicate 'ops__op_table'/4 in mode 0 */
Define_static(mercury__ops__op_table_4_0);
	r3 = (hash_string((Integer) r1) & ((Integer) 255));
Define_label(mercury__ops__op_table_4_0_i3);
	{
	Word tempr1;
	tempr1 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_0))[(Integer) r3];
	if (!((Integer) tempr1))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1000);
	if ((strcmp((char *)(Integer) tempr1, (char *)(Integer) r1) ==0))
		GOTO_LABEL(mercury__ops__op_table_4_0_i5);
	}
Define_label(mercury__ops__op_table_4_0_i1000);
	r3 = ((Integer *)(Integer) mkword(mktag(0), (Integer) mercury_data_ops__common_1))[(Integer) r3];
	if (((Integer) r3 >= ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i3);
	r1 = FALSE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i5);
	COMPUTED_GOTO((Integer) r3,
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i6) AND
		LABEL(mercury__ops__op_table_4_0_i9) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i13) AND
		LABEL(mercury__ops__op_table_4_0_i15) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i19) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i19) AND
		LABEL(mercury__ops__op_table_4_0_i25) AND
		LABEL(mercury__ops__op_table_4_0_i27) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i33) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i35) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i39) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i27) AND
		LABEL(mercury__ops__op_table_4_0_i6) AND
		LABEL(mercury__ops__op_table_4_0_i48) AND
		LABEL(mercury__ops__op_table_4_0_i27) AND
		LABEL(mercury__ops__op_table_4_0_i52) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i54) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i58) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i62) AND
		LABEL(mercury__ops__op_table_4_0_i52) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i39) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i78) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i80) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i83) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i85) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i89) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i27) AND
		LABEL(mercury__ops__op_table_4_0_i19) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i105) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i89) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i35) AND
		LABEL(mercury__ops__op_table_4_0_i115) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i119) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i35) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i131) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i27) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i119) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i147) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i119) AND
		LABEL(mercury__ops__op_table_4_0_i66) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i105) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i89) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i11) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i1) AND
		LABEL(mercury__ops__op_table_4_0_i159));
Define_label(mercury__ops__op_table_4_0_i6);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i8);
	r2 = ((Integer) 5);
	r3 = ((Integer) 500);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i8);
	r2 = ((Integer) 0);
	r3 = ((Integer) 500);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i9);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i11);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 0);
	r3 = ((Integer) 1199);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i13);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 300);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i15);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 300);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i19);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 920);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i25);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 720);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i27);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 5);
	r3 = ((Integer) 400);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i33);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 1179);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i35);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 0);
	r3 = ((Integer) 1180);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i39);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 1175);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i48);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 0);
	r3 = ((Integer) 1160);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i52);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 600);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i54);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 1150);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i58);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 701);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i62);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 1100);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i66);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 700);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i78);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 900);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i80);
	if (((Integer) r2 == ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i82);
	r2 = ((Integer) 4);
	r3 = ((Integer) 1200);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i82);
	r2 = ((Integer) 0);
	r3 = ((Integer) 1200);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i83);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 0);
	r3 = ((Integer) 500);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i85);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 200);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i89);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 1);
	r3 = ((Integer) 900);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i105);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 5);
	r3 = ((Integer) 500);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i115);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 4);
	r3 = ((Integer) 1200);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i119);
	if (((Integer) r2 != ((Integer) 0)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 8);
	r3 = ((Integer) 950);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i131);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 1050);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i147);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 1170);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i159);
	if (((Integer) r2 != ((Integer) 1)))
		GOTO_LABEL(mercury__ops__op_table_4_0_i1);
	r2 = ((Integer) 6);
	r3 = ((Integer) 740);
	r1 = TRUE;
	proceed();
Define_label(mercury__ops__op_table_4_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module13)
	init_entry(mercury____Unify___ops__specifier_0_0);
	init_label(mercury____Unify___ops__specifier_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___ops__specifier_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___ops__specifier_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__specifier_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module14)
	init_entry(mercury____Index___ops__specifier_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___ops__specifier_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___ops__specifier_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module15)
	init_entry(mercury____Compare___ops__specifier_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___ops__specifier_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__specifier_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module16)
	init_entry(mercury____Unify___ops__assoc_0_0);
	init_label(mercury____Unify___ops__assoc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___ops__assoc_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___ops__assoc_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__assoc_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module17)
	init_entry(mercury____Index___ops__assoc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___ops__assoc_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___ops__assoc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module18)
	init_entry(mercury____Compare___ops__assoc_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___ops__assoc_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__assoc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module19)
	init_entry(mercury____Unify___ops__class_0_0);
	init_label(mercury____Unify___ops__class_0_0_i4);
	init_label(mercury____Unify___ops__class_0_0_i6);
	init_label(mercury____Unify___ops__class_0_0_i8);
	init_label(mercury____Unify___ops__class_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___ops__class_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i4);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__class_0_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__class_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	if (((Integer) field(mktag(2), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(2), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__class_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	if (((Integer) field(mktag(3), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(3), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___ops__class_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__class_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module20)
	init_entry(mercury____Index___ops__class_0_0);
	init_label(mercury____Index___ops__class_0_0_i4);
	init_label(mercury____Index___ops__class_0_0_i5);
	init_label(mercury____Index___ops__class_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___ops__class_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___ops__class_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___ops__class_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___ops__class_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___ops__class_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___ops__class_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___ops__class_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module21)
	init_entry(mercury____Compare___ops__class_0_0);
	init_label(mercury____Compare___ops__class_0_0_i2);
	init_label(mercury____Compare___ops__class_0_0_i3);
	init_label(mercury____Compare___ops__class_0_0_i4);
	init_label(mercury____Compare___ops__class_0_0_i6);
	init_label(mercury____Compare___ops__class_0_0_i16);
	init_label(mercury____Compare___ops__class_0_0_i17);
	init_label(mercury____Compare___ops__class_0_0_i15);
	init_label(mercury____Compare___ops__class_0_0_i12);
	init_label(mercury____Compare___ops__class_0_0_i22);
	init_label(mercury____Compare___ops__class_0_0_i29);
	init_label(mercury____Compare___ops__class_0_0_i25);
	init_label(mercury____Compare___ops__class_0_0_i9);
	init_label(mercury____Compare___ops__class_0_0_i1001);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___ops__class_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___ops__class_0_0),
		mercury____Compare___ops__class_0_0_i2,
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___ops__class_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___ops__class_0_0),
		mercury____Compare___ops__class_0_0_i3,
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___ops__class_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___ops__class_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___ops__class_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i12);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___ops__class_0_0_i16,
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___ops__class_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i15);
Define_label(mercury____Compare___ops__class_0_0_i17);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___ops__class_0_0_i15);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i22);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i1001);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i22);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i25);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i9);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(2), (Integer) r1, ((Integer) 1));
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(2), (Integer) r3, ((Integer) 1));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___ops__class_0_0_i29,
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i29);
	update_prof_current_proc(LABEL(mercury____Compare___ops__class_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i17);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i25);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___ops__class_0_0_i1001);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___ops__class_0_0));
	}
Define_label(mercury____Compare___ops__class_0_0_i1001);
	{
	Declare_entry(mercury__compare_error_0_0);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___ops__class_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module22)
	init_entry(mercury____Unify___ops__table_0_0);
	init_label(mercury____Unify___ops__table_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___ops__table_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___ops__table_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__table_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module23)
	init_entry(mercury____Index___ops__table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___ops__table_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___ops__table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module24)
	init_entry(mercury____Compare___ops__table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___ops__table_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__table_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module25)
	init_entry(mercury____Unify___ops__priority_0_0);
	init_label(mercury____Unify___ops__priority_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___ops__priority_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___ops__priority_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___ops__priority_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__ops_module26)
	init_entry(mercury____Index___ops__priority_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___ops__priority_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___ops__priority_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__ops_module27)
	init_entry(mercury____Compare___ops__priority_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___ops__priority_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___ops__priority_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__ops_bunch_0(void)
{
	mercury__ops_module0();
	mercury__ops_module1();
	mercury__ops_module2();
	mercury__ops_module3();
	mercury__ops_module4();
	mercury__ops_module5();
	mercury__ops_module6();
	mercury__ops_module7();
	mercury__ops_module8();
	mercury__ops_module9();
	mercury__ops_module10();
	mercury__ops_module11();
	mercury__ops_module12();
	mercury__ops_module13();
	mercury__ops_module14();
	mercury__ops_module15();
	mercury__ops_module16();
	mercury__ops_module17();
	mercury__ops_module18();
	mercury__ops_module19();
	mercury__ops_module20();
	mercury__ops_module21();
	mercury__ops_module22();
	mercury__ops_module23();
	mercury__ops_module24();
	mercury__ops_module25();
	mercury__ops_module26();
	mercury__ops_module27();
}

#endif

void mercury__ops__init(void); /* suppress gcc warning */
void mercury__ops__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__ops_bunch_0();
#endif
}
