/*
** Automatically generated from `group.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__group__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Index___group_group_1__ua10000_2_0);
Define_extern_entry(mercury__group__init_1_0);
Declare_label(mercury__group__init_1_0_i2);
Declare_label(mercury__group__init_1_0_i3);
Define_extern_entry(mercury__group__insert_3_0);
Declare_label(mercury__group__insert_3_0_i2);
Declare_label(mercury__group__insert_3_0_i3);
Declare_label(mercury__group__insert_3_0_i4);
Define_extern_entry(mercury__group__group_3_0);
Declare_label(mercury__group__group_3_0_i2);
Define_extern_entry(mercury__group__to_set_2_0);
Declare_label(mercury__group__to_set_2_0_i2);
Define_extern_entry(mercury__group__sets_and_keys_2_0);
Declare_label(mercury__group__sets_and_keys_2_0_i2);
Define_extern_entry(mercury__group__group_key_3_0);
Define_extern_entry(mercury__group__key_group_3_0);
Define_extern_entry(mercury__group__remove_group_4_0);
Declare_label(mercury__group__remove_group_4_0_i4);
Declare_label(mercury__group__remove_group_4_0_i3);
Declare_label(mercury__group__remove_group_4_0_i6);
Declare_label(mercury__group__remove_group_4_0_i7);
Declare_label(mercury__group__remove_group_4_0_i8);
Declare_label(mercury__group__remove_group_4_0_i9);
Define_extern_entry(mercury__group__same_group_3_0);
Declare_label(mercury__group__same_group_3_0_i2);
Define_extern_entry(mercury__group__largest_group_key_2_0);
Declare_label(mercury__group__largest_group_key_2_0_i2);
Define_extern_entry(mercury__group__group_keys_2_0);
Declare_static(mercury__group__insert_elements_4_0);
Declare_label(mercury__group__insert_elements_4_0_i4);
Declare_label(mercury__group__insert_elements_4_0_i1002);
Declare_static(mercury__group__remove_elements_3_0);
Declare_label(mercury__group__remove_elements_3_0_i4);
Declare_label(mercury__group__remove_elements_3_0_i1002);
Declare_static(mercury__group__largest_group_key_2_4_0);
Declare_label(mercury__group__largest_group_key_2_4_0_i4);
Declare_label(mercury__group__largest_group_key_2_4_0_i5);
Declare_label(mercury__group__largest_group_key_2_4_0_i6);
Declare_label(mercury__group__largest_group_key_2_4_0_i7);
Declare_label(mercury__group__largest_group_key_2_4_0_i1003);
Define_extern_entry(mercury____Unify___group__group_1_0);
Declare_label(mercury____Unify___group__group_1_0_i2);
Declare_label(mercury____Unify___group__group_1_0_i1003);
Declare_label(mercury____Unify___group__group_1_0_i1);
Define_extern_entry(mercury____Index___group__group_1_0);
Define_extern_entry(mercury____Compare___group__group_1_0);
Declare_label(mercury____Compare___group__group_1_0_i4);
Declare_label(mercury____Compare___group__group_1_0_i5);
Declare_label(mercury____Compare___group__group_1_0_i3);
Declare_label(mercury____Compare___group__group_1_0_i10);
Define_extern_entry(mercury____Unify___group__key_0_0);
Declare_label(mercury____Unify___group__key_0_0_i1);
Define_extern_entry(mercury____Index___group__key_0_0);
Define_extern_entry(mercury____Compare___group__key_0_0);

extern Word * mercury_data_group__base_type_layout_group_1[];
Word * mercury_data_group__base_type_info_group_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___group__group_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___group__group_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___group__group_1_0),
	(Word *) (Integer) mercury_data_group__base_type_layout_group_1
};

extern Word * mercury_data_group__base_type_layout_group__key_0[];
Word * mercury_data_group__base_type_info_group__key_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___group__key_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___group__key_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___group__key_0_0),
	(Word *) (Integer) mercury_data_group__base_type_layout_group__key_0
};

extern Word * mercury_data_group__common_1[];
Word * mercury_data_group__base_type_layout_group__key_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_group__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_group__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_group__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_group__common_1)
};

extern Word * mercury_data_group__common_5[];
Word * mercury_data_group__base_type_layout_group_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_group__common_5),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_group__common_0[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_group__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_group__common_0)
};

extern Word * mercury_data_set__base_type_info_set_1[];
Word * mercury_data_group__common_2[] = {
	(Word *) (Integer) mercury_data_set__base_type_info_set_1,
	(Word *) ((Integer) 1)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
Word * mercury_data_group__common_3[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_group__common_2)
};

Word * mercury_data_group__common_4[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) ((Integer) 1),
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_group__common_5[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_group__common_0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_group__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_group__common_4),
	(Word *) string_const("group", 5)
};

BEGIN_MODULE(mercury__group_module0)
	init_entry(mercury____Index___group_group_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___group_group_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___group_group_1__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module1)
	init_entry(mercury__group__init_1_0);
	init_label(mercury__group__init_1_0_i2);
	init_label(mercury__group__init_1_0_i3);
BEGIN_CODE

/* code for predicate 'group__init'/1 in mode 0 */
Define_entry(mercury__group__init_1_0);
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	incr_sp_push_msg(2, "group__init");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__group__init_1_0_i2,
		ENTRY(mercury__group__init_1_0));
	}
Define_label(mercury__group__init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__group__init_1_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__group__init_1_0_i3,
		ENTRY(mercury__group__init_1_0));
	}
Define_label(mercury__group__init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__group__init_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module2)
	init_entry(mercury__group__insert_3_0);
	init_label(mercury__group__insert_3_0_i2);
	init_label(mercury__group__insert_3_0_i3);
	init_label(mercury__group__insert_3_0_i4);
BEGIN_CODE

/* code for predicate 'group__insert'/3 in mode 0 */
Define_entry(mercury__group__insert_3_0);
	r4 = ((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) + ((Integer) 1));
	r5 = (Integer) r3;
	incr_sp_push_msg(6, "group__insert");
	detstackvar(6) = (Integer) succip;
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	detstackvar(5) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__group__insert_3_0_i2,
		ENTRY(mercury__group__insert_3_0));
	}
Define_label(mercury__group__insert_3_0_i2);
	update_prof_current_proc(LABEL(mercury__group__insert_3_0));
	r2 = (Integer) detstackvar(2);
	detstackvar(2) = (Integer) r1;
	detstackvar(4) = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 2));
	r1 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__group__insert_3_0_i3,
		ENTRY(mercury__group__insert_3_0));
	}
Define_label(mercury__group__insert_3_0_i3);
	update_prof_current_proc(LABEL(mercury__group__insert_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__group__insert_elements_4_0),
		mercury__group__insert_3_0_i4,
		ENTRY(mercury__group__insert_3_0));
Define_label(mercury__group__insert_3_0_i4);
	update_prof_current_proc(LABEL(mercury__group__insert_3_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module3)
	init_entry(mercury__group__group_3_0);
	init_label(mercury__group__group_3_0_i2);
BEGIN_CODE

/* code for predicate 'group__group'/3 in mode 0 */
Define_entry(mercury__group__group_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	incr_sp_push_msg(3, "group__group");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__group__group_3_0_i2,
		ENTRY(mercury__group__group_3_0));
	}
Define_label(mercury__group__group_3_0_i2);
	update_prof_current_proc(LABEL(mercury__group__group_3_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	r4 = (Integer) r1;
	r3 = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 1));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__group__group_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module4)
	init_entry(mercury__group__to_set_2_0);
	init_label(mercury__group__to_set_2_0_i2);
BEGIN_CODE

/* code for predicate 'group__to_set'/2 in mode 0 */
Define_entry(mercury__group__to_set_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	incr_sp_push_msg(2, "group__to_set");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__values_2_0);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__group__to_set_2_0_i2,
		ENTRY(mercury__group__to_set_2_0));
	}
Define_label(mercury__group__to_set_2_0_i2);
	update_prof_current_proc(LABEL(mercury__group__to_set_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		ENTRY(mercury__group__to_set_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module5)
	init_entry(mercury__group__sets_and_keys_2_0);
	init_label(mercury__group__sets_and_keys_2_0_i2);
BEGIN_CODE

/* code for predicate 'group__sets_and_keys'/2 in mode 0 */
Define_entry(mercury__group__sets_and_keys_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	incr_sp_push_msg(2, "group__sets_and_keys");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__group__sets_and_keys_2_0_i2,
		ENTRY(mercury__group__sets_and_keys_2_0));
	}
Define_label(mercury__group__sets_and_keys_2_0_i2);
	update_prof_current_proc(LABEL(mercury__group__sets_and_keys_2_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
	Declare_entry(mercury__assoc_list__reverse_members_2_0);
	tailcall(ENTRY(mercury__assoc_list__reverse_members_2_0),
		ENTRY(mercury__group__sets_and_keys_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module6)
	init_entry(mercury__group__group_key_3_0);
BEGIN_CODE

/* code for predicate 'group__group_key'/3 in mode 0 */
Define_entry(mercury__group__group_key_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__group__group_key_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module7)
	init_entry(mercury__group__key_group_3_0);
BEGIN_CODE

/* code for predicate 'group__key_group'/3 in mode 0 */
Define_entry(mercury__group__key_group_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		ENTRY(mercury__group__key_group_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module8)
	init_entry(mercury__group__remove_group_4_0);
	init_label(mercury__group__remove_group_4_0_i4);
	init_label(mercury__group__remove_group_4_0_i3);
	init_label(mercury__group__remove_group_4_0_i6);
	init_label(mercury__group__remove_group_4_0_i7);
	init_label(mercury__group__remove_group_4_0_i8);
	init_label(mercury__group__remove_group_4_0_i9);
BEGIN_CODE

/* code for predicate 'group__remove_group'/4 in mode 0 */
Define_entry(mercury__group__remove_group_4_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	incr_sp_push_msg(6, "group__remove_group");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	detstackvar(5) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__remove_4_0);
	call_localret(ENTRY(mercury__map__remove_4_0),
		mercury__group__remove_group_4_0_i4,
		ENTRY(mercury__group__remove_group_4_0));
	}
Define_label(mercury__group__remove_group_4_0_i4);
	update_prof_current_proc(LABEL(mercury__group__remove_group_4_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__group__remove_group_4_0_i3);
	r4 = (Integer) r3;
	r3 = (Integer) detstackvar(1);
	r5 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r1 = (Integer) detstackvar(5);
	GOTO_LABEL(mercury__group__remove_group_4_0_i7);
Define_label(mercury__group__remove_group_4_0_i3);
	r1 = string_const("map__remove unexpectedly failed.", 32);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__group__remove_group_4_0_i6,
		ENTRY(mercury__group__remove_group_4_0));
	}
Define_label(mercury__group__remove_group_4_0_i6);
	update_prof_current_proc(LABEL(mercury__group__remove_group_4_0));
	r3 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(4);
	r1 = (Integer) detstackvar(5);
Define_label(mercury__group__remove_group_4_0_i7);
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r2;
	detstackvar(3) = (Integer) r4;
	detstackvar(4) = (Integer) r5;
	detstackvar(5) = (Integer) r1;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__group__remove_group_4_0_i8,
		ENTRY(mercury__group__remove_group_4_0));
	}
Define_label(mercury__group__remove_group_4_0_i8);
	update_prof_current_proc(LABEL(mercury__group__remove_group_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(4);
	call_localret(STATIC(mercury__group__remove_elements_3_0),
		mercury__group__remove_group_4_0_i9,
		ENTRY(mercury__group__remove_group_4_0));
Define_label(mercury__group__remove_group_4_0_i9);
	update_prof_current_proc(LABEL(mercury__group__remove_group_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) detstackvar(1), ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(3);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module9)
	init_entry(mercury__group__same_group_3_0);
	init_label(mercury__group__same_group_3_0_i2);
BEGIN_CODE

/* code for predicate 'group__same_group'/3 in mode 0 */
Define_entry(mercury__group__same_group_3_0);
	incr_sp_push_msg(4, "group__same_group");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(2) = (Integer) r3;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__group__same_group_3_0_i2,
		ENTRY(mercury__group__same_group_3_0));
	}
Define_label(mercury__group__same_group_3_0_i2);
	update_prof_current_proc(LABEL(mercury__group__same_group_3_0));
	r5 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury__map__lookup_3_0);
	tailcall(ENTRY(mercury__map__lookup_3_0),
		ENTRY(mercury__group__same_group_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module10)
	init_entry(mercury__group__largest_group_key_2_0);
	init_label(mercury__group__largest_group_key_2_0_i2);
BEGIN_CODE

/* code for predicate 'group__largest_group_key'/2 in mode 0 */
Define_entry(mercury__group__largest_group_key_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	incr_sp_push_msg(2, "group__largest_group_key");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__to_assoc_list_2_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__group__largest_group_key_2_0_i2,
		ENTRY(mercury__group__largest_group_key_2_0));
	}
Define_label(mercury__group__largest_group_key_2_0_i2);
	update_prof_current_proc(LABEL(mercury__group__largest_group_key_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	r3 = ((Integer) 0);
	r4 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__group__largest_group_key_2_4_0),
		ENTRY(mercury__group__largest_group_key_2_0));
END_MODULE

BEGIN_MODULE(mercury__group_module11)
	init_entry(mercury__group__group_keys_2_0);
BEGIN_CODE

/* code for predicate 'group__group_keys'/2 in mode 0 */
Define_entry(mercury__group__group_keys_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury__map__keys_2_0);
	tailcall(ENTRY(mercury__map__keys_2_0),
		ENTRY(mercury__group__group_keys_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module12)
	init_entry(mercury__group__insert_elements_4_0);
	init_label(mercury__group__insert_elements_4_0_i4);
	init_label(mercury__group__insert_elements_4_0_i1002);
BEGIN_CODE

/* code for predicate 'group__insert_elements'/4 in mode 0 */
Define_static(mercury__group__insert_elements_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__group__insert_elements_4_0_i1002);
	incr_sp_push_msg(4, "group__insert_elements");
	detstackvar(4) = (Integer) succip;
	r5 = (Integer) r3;
	detstackvar(1) = (Integer) r3;
	r3 = (Integer) r4;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(3) = (Integer) r1;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__group__insert_elements_4_0_i4,
		STATIC(mercury__group__insert_elements_4_0));
	}
Define_label(mercury__group__insert_elements_4_0_i4);
	update_prof_current_proc(LABEL(mercury__group__insert_elements_4_0));
	r4 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury__group__insert_elements_4_0,
		STATIC(mercury__group__insert_elements_4_0));
Define_label(mercury__group__insert_elements_4_0_i1002);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module13)
	init_entry(mercury__group__remove_elements_3_0);
	init_label(mercury__group__remove_elements_3_0_i4);
	init_label(mercury__group__remove_elements_3_0_i1002);
BEGIN_CODE

/* code for predicate 'group__remove_elements'/3 in mode 0 */
Define_static(mercury__group__remove_elements_3_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__group__remove_elements_3_0_i1002);
	incr_sp_push_msg(3, "group__remove_elements");
	detstackvar(3) = (Integer) succip;
	r4 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r2 = (Integer) mercury_data___base_type_info_int_0;
	detstackvar(2) = (Integer) r1;
	{
	Declare_entry(mercury__map__delete_3_1);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__group__remove_elements_3_0_i4,
		STATIC(mercury__group__remove_elements_3_0));
	}
Define_label(mercury__group__remove_elements_3_0_i4);
	update_prof_current_proc(LABEL(mercury__group__remove_elements_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	localtailcall(mercury__group__remove_elements_3_0,
		STATIC(mercury__group__remove_elements_3_0));
Define_label(mercury__group__remove_elements_3_0_i1002);
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module14)
	init_entry(mercury__group__largest_group_key_2_4_0);
	init_label(mercury__group__largest_group_key_2_4_0_i4);
	init_label(mercury__group__largest_group_key_2_4_0_i5);
	init_label(mercury__group__largest_group_key_2_4_0_i6);
	init_label(mercury__group__largest_group_key_2_4_0_i7);
	init_label(mercury__group__largest_group_key_2_4_0_i1003);
BEGIN_CODE

/* code for predicate 'group__largest_group_key_2'/4 in mode 0 */
Define_static(mercury__group__largest_group_key_2_4_0);
	if (((Integer) r2 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__group__largest_group_key_2_4_0_i1003);
	incr_sp_push_msg(7, "group__largest_group_key_2");
	detstackvar(7) = (Integer) succip;
	{
	Word tempr1;
	tempr1 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	detstackvar(4) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	r2 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) r3;
	detstackvar(2) = (Integer) r4;
	detstackvar(6) = (Integer) r1;
	{
	Declare_entry(mercury__set__to_sorted_list_2_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__group__largest_group_key_2_4_0_i4,
		STATIC(mercury__group__largest_group_key_2_4_0));
	}
	}
Define_label(mercury__group__largest_group_key_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__group__largest_group_key_2_4_0));
	r2 = (Integer) r1;
	r1 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury__list__length_2_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__group__largest_group_key_2_4_0_i5,
		STATIC(mercury__group__largest_group_key_2_4_0));
	}
Define_label(mercury__group__largest_group_key_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__group__largest_group_key_2_4_0));
	detstackvar(5) = (Integer) r1;
	r2 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury__group__largest_group_key_2_4_0_i6,
		STATIC(mercury__group__largest_group_key_2_4_0));
	}
Define_label(mercury__group__largest_group_key_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__group__largest_group_key_2_4_0));
	if (((Integer) r1 != ((Integer) 2)))
		GOTO_LABEL(mercury__group__largest_group_key_2_4_0_i7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(3);
	r1 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__group__largest_group_key_2_4_0,
		STATIC(mercury__group__largest_group_key_2_4_0));
Define_label(mercury__group__largest_group_key_2_4_0_i7);
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(6);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	localtailcall(mercury__group__largest_group_key_2_4_0,
		STATIC(mercury__group__largest_group_key_2_4_0));
Define_label(mercury__group__largest_group_key_2_4_0_i1003);
	r1 = (Integer) r4;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module15)
	init_entry(mercury____Unify___group__group_1_0);
	init_label(mercury____Unify___group__group_1_0_i2);
	init_label(mercury____Unify___group__group_1_0_i1003);
	init_label(mercury____Unify___group__group_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___group__group_1_0);
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r3, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___group__group_1_0_i1003);
	incr_sp_push_msg(4, "__Unify__");
	detstackvar(4) = (Integer) succip;
	r4 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	detstackvar(3) = (Integer) r1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___group__group_1_0_i2,
		ENTRY(mercury____Unify___group__group_1_0));
	}
Define_label(mercury____Unify___group__group_1_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___group__group_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___group__group_1_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___group__group_1_0));
	}
Define_label(mercury____Unify___group__group_1_0_i1003);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___group__group_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module16)
	init_entry(mercury____Index___group__group_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___group__group_1_0);
	tailcall(STATIC(mercury____Index___group_group_1__ua10000_2_0),
		ENTRY(mercury____Index___group__group_1_0));
END_MODULE

BEGIN_MODULE(mercury__group_module17)
	init_entry(mercury____Compare___group__group_1_0);
	init_label(mercury____Compare___group__group_1_0_i4);
	init_label(mercury____Compare___group__group_1_0_i5);
	init_label(mercury____Compare___group__group_1_0_i3);
	init_label(mercury____Compare___group__group_1_0_i10);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___group__group_1_0);
	incr_sp_push_msg(6, "__Compare__");
	detstackvar(6) = (Integer) succip;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___group__group_1_0_i4,
		ENTRY(mercury____Compare___group__group_1_0));
	}
Define_label(mercury____Compare___group__group_1_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___group__group_1_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___group__group_1_0_i3);
Define_label(mercury____Compare___group__group_1_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury____Compare___group__group_1_0_i3);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	tag_incr_hp(r2, mktag(0), ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_set__base_type_info_set_1;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___group__group_1_0_i10,
		ENTRY(mercury____Compare___group__group_1_0));
	}
Define_label(mercury____Compare___group__group_1_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___group__group_1_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___group__group_1_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___group__group_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module18)
	init_entry(mercury____Unify___group__key_0_0);
	init_label(mercury____Unify___group__key_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___group__key_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___group__key_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___group__key_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__group_module19)
	init_entry(mercury____Index___group__key_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___group__key_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___group__key_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__group_module20)
	init_entry(mercury____Compare___group__key_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___group__key_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___group__key_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__group_bunch_0(void)
{
	mercury__group_module0();
	mercury__group_module1();
	mercury__group_module2();
	mercury__group_module3();
	mercury__group_module4();
	mercury__group_module5();
	mercury__group_module6();
	mercury__group_module7();
	mercury__group_module8();
	mercury__group_module9();
	mercury__group_module10();
	mercury__group_module11();
	mercury__group_module12();
	mercury__group_module13();
	mercury__group_module14();
	mercury__group_module15();
	mercury__group_module16();
	mercury__group_module17();
	mercury__group_module18();
	mercury__group_module19();
	mercury__group_module20();
}

#endif

void mercury__group__init(void); /* suppress gcc warning */
void mercury__group__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__group_bunch_0();
#endif
}
