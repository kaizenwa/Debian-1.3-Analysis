/*
** Automatically generated from `char.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__char__init
ENDINIT
*/

#include "imp.h"

Define_extern_entry(mercury__char__to_int_2_1);
Declare_label(mercury__char__to_int_2_1_i3);
Declare_label(mercury__char__to_int_2_1_i5);
Declare_label(mercury__char__to_int_2_1_i7);
Declare_label(mercury__char__to_int_2_1_i9);
Declare_label(mercury__char__to_int_2_1_i11);
Declare_label(mercury__char__to_int_2_1_i13);
Declare_label(mercury__char__to_int_2_1_i15);
Declare_label(mercury__char__to_int_2_1_i17);
Declare_label(mercury__char__to_int_2_1_i19);
Declare_label(mercury__char__to_int_2_1_i21);
Declare_label(mercury__char__to_int_2_1_i23);
Declare_label(mercury__char__to_int_2_1_i25);
Declare_label(mercury__char__to_int_2_1_i27);
Declare_label(mercury__char__to_int_2_1_i29);
Declare_label(mercury__char__to_int_2_1_i31);
Declare_label(mercury__char__to_int_2_1_i33);
Declare_label(mercury__char__to_int_2_1_i35);
Declare_label(mercury__char__to_int_2_1_i37);
Declare_label(mercury__char__to_int_2_1_i39);
Declare_label(mercury__char__to_int_2_1_i41);
Declare_label(mercury__char__to_int_2_1_i43);
Declare_label(mercury__char__to_int_2_1_i45);
Declare_label(mercury__char__to_int_2_1_i47);
Declare_label(mercury__char__to_int_2_1_i49);
Declare_label(mercury__char__to_int_2_1_i51);
Declare_label(mercury__char__to_int_2_1_i53);
Declare_label(mercury__char__to_int_2_1_i55);
Declare_label(mercury__char__to_int_2_1_i57);
Declare_label(mercury__char__to_int_2_1_i59);
Declare_label(mercury__char__to_int_2_1_i61);
Declare_label(mercury__char__to_int_2_1_i63);
Declare_label(mercury__char__to_int_2_1_i65);
Declare_label(mercury__char__to_int_2_1_i67);
Declare_label(mercury__char__to_int_2_1_i69);
Declare_label(mercury__char__to_int_2_1_i71);
Declare_label(mercury__char__to_int_2_1_i73);
Declare_label(mercury__char__to_int_2_1_i75);
Declare_label(mercury__char__to_int_2_1_i77);
Declare_label(mercury__char__to_int_2_1_i79);
Declare_label(mercury__char__to_int_2_1_i81);
Declare_label(mercury__char__to_int_2_1_i83);
Declare_label(mercury__char__to_int_2_1_i85);
Declare_label(mercury__char__to_int_2_1_i87);
Declare_label(mercury__char__to_int_2_1_i89);
Declare_label(mercury__char__to_int_2_1_i91);
Declare_label(mercury__char__to_int_2_1_i93);
Declare_label(mercury__char__to_int_2_1_i95);
Declare_label(mercury__char__to_int_2_1_i97);
Declare_label(mercury__char__to_int_2_1_i99);
Declare_label(mercury__char__to_int_2_1_i101);
Declare_label(mercury__char__to_int_2_1_i103);
Declare_label(mercury__char__to_int_2_1_i105);
Declare_label(mercury__char__to_int_2_1_i107);
Declare_label(mercury__char__to_int_2_1_i109);
Declare_label(mercury__char__to_int_2_1_i111);
Declare_label(mercury__char__to_int_2_1_i113);
Declare_label(mercury__char__to_int_2_1_i115);
Declare_label(mercury__char__to_int_2_1_i117);
Declare_label(mercury__char__to_int_2_1_i119);
Declare_label(mercury__char__to_int_2_1_i121);
Declare_label(mercury__char__to_int_2_1_i123);
Declare_label(mercury__char__to_int_2_1_i125);
Declare_label(mercury__char__to_int_2_1_i127);
Declare_label(mercury__char__to_int_2_1_i129);
Declare_label(mercury__char__to_int_2_1_i131);
Declare_label(mercury__char__to_int_2_1_i133);
Declare_label(mercury__char__to_int_2_1_i135);
Declare_label(mercury__char__to_int_2_1_i137);
Declare_label(mercury__char__to_int_2_1_i139);
Declare_label(mercury__char__to_int_2_1_i141);
Declare_label(mercury__char__to_int_2_1_i143);
Declare_label(mercury__char__to_int_2_1_i145);
Declare_label(mercury__char__to_int_2_1_i147);
Declare_label(mercury__char__to_int_2_1_i149);
Declare_label(mercury__char__to_int_2_1_i151);
Declare_label(mercury__char__to_int_2_1_i153);
Declare_label(mercury__char__to_int_2_1_i155);
Declare_label(mercury__char__to_int_2_1_i157);
Declare_label(mercury__char__to_int_2_1_i159);
Declare_label(mercury__char__to_int_2_1_i161);
Declare_label(mercury__char__to_int_2_1_i163);
Declare_label(mercury__char__to_int_2_1_i165);
Declare_label(mercury__char__to_int_2_1_i167);
Declare_label(mercury__char__to_int_2_1_i169);
Declare_label(mercury__char__to_int_2_1_i171);
Declare_label(mercury__char__to_int_2_1_i173);
Declare_label(mercury__char__to_int_2_1_i175);
Declare_label(mercury__char__to_int_2_1_i177);
Declare_label(mercury__char__to_int_2_1_i179);
Declare_label(mercury__char__to_int_2_1_i181);
Declare_label(mercury__char__to_int_2_1_i183);
Declare_label(mercury__char__to_int_2_1_i185);
Declare_label(mercury__char__to_int_2_1_i187);
Declare_label(mercury__char__to_int_2_1_i189);
Declare_label(mercury__char__to_int_2_1_i191);
Declare_label(mercury__char__to_int_2_1_i193);
Declare_label(mercury__char__to_int_2_1_i195);
Declare_label(mercury__char__to_int_2_1_i197);
Declare_label(mercury__char__to_int_2_1_i199);
Declare_label(mercury__char__to_int_2_1_i201);
Declare_label(mercury__char__to_int_2_1_i203);
Declare_label(mercury__char__to_int_2_1_i205);
Declare_label(mercury__char__to_int_2_1_i207);
Declare_label(mercury__char__to_int_2_1_i209);
Declare_label(mercury__char__to_int_2_1_i211);
Declare_label(mercury__char__to_int_2_1_i213);
Declare_label(mercury__char__to_int_2_1_i215);
Declare_label(mercury__char__to_int_2_1_i217);
Declare_label(mercury__char__to_int_2_1_i219);
Declare_label(mercury__char__to_int_2_1_i221);
Declare_label(mercury__char__to_int_2_1_i223);
Declare_label(mercury__char__to_int_2_1_i225);
Declare_label(mercury__char__to_int_2_1_i227);
Declare_label(mercury__char__to_int_2_1_i229);
Declare_label(mercury__char__to_int_2_1_i231);
Declare_label(mercury__char__to_int_2_1_i233);
Declare_label(mercury__char__to_int_2_1_i235);
Declare_label(mercury__char__to_int_2_1_i237);
Declare_label(mercury__char__to_int_2_1_i239);
Declare_label(mercury__char__to_int_2_1_i241);
Declare_label(mercury__char__to_int_2_1_i243);
Declare_label(mercury__char__to_int_2_1_i245);
Declare_label(mercury__char__to_int_2_1_i247);
Declare_label(mercury__char__to_int_2_1_i249);
Declare_label(mercury__char__to_int_2_1_i251);
Declare_label(mercury__char__to_int_2_1_i253);
Declare_label(mercury__char__to_int_2_1_i255);
Declare_label(mercury__char__to_int_2_1_i2);
Declare_label(mercury__char__to_int_2_1_i1);
Define_extern_entry(mercury__char__to_int_2_2);
Declare_label(mercury__char__to_int_2_2_i1);
Define_extern_entry(mercury__char__to_int_2_0);
Define_extern_entry(mercury__char__to_upper_2_0);
Declare_label(mercury__char__to_upper_2_0_i4);
Declare_label(mercury__char__to_upper_2_0_i3);
Define_extern_entry(mercury__char__to_lower_2_0);
Declare_label(mercury__char__to_lower_2_0_i4);
Declare_label(mercury__char__to_lower_2_0_i3);
Define_extern_entry(mercury__char__lower_upper_2_0);
Declare_label(mercury__char__lower_upper_2_0_i1);
Define_extern_entry(mercury__char__lower_upper_2_1);
Declare_label(mercury__char__lower_upper_2_1_i1);
Define_extern_entry(mercury__char__is_whitespace_1_0);
Declare_label(mercury__char__is_whitespace_1_0_i2);
Declare_label(mercury__char__is_whitespace_1_0_i1);
Define_extern_entry(mercury__char__is_upper_1_0);
Define_extern_entry(mercury__char__is_lower_1_0);
Define_extern_entry(mercury__char__is_alpha_1_0);
Declare_label(mercury__char__is_alpha_1_0_i4);
Declare_label(mercury__char__is_alpha_1_0_i8);
Define_extern_entry(mercury__char__is_alnum_1_0);
Declare_label(mercury__char__is_alnum_1_0_i4);
Declare_label(mercury__char__is_alnum_1_0_i8);
Define_extern_entry(mercury__char__is_alpha_or_underscore_1_0);
Declare_label(mercury__char__is_alpha_or_underscore_1_0_i1002);
Define_extern_entry(mercury__char__is_alnum_or_underscore_1_0);
Declare_label(mercury__char__is_alnum_or_underscore_1_0_i1);
Define_extern_entry(mercury__char__is_digit_1_0);
Declare_label(mercury__char__is_digit_1_0_i1);
Define_extern_entry(mercury__char__is_binary_digit_1_0);
Declare_label(mercury__char__is_binary_digit_1_0_i2);
Declare_label(mercury__char__is_binary_digit_1_0_i1);
Define_extern_entry(mercury__char__is_octal_digit_1_0);
Declare_label(mercury__char__is_octal_digit_1_0_i1);
Define_extern_entry(mercury__char__is_hex_digit_1_0);
Declare_label(mercury__char__is_hex_digit_1_0_i1);
Define_extern_entry(mercury____Unify___char__char_0_0);
Declare_label(mercury____Unify___char__char_0_0_i1);
Define_extern_entry(mercury____Index___char__char_0_0);
Define_extern_entry(mercury____Compare___char__char_0_0);

extern Word * mercury_data_char__base_type_layout_char_0[];
Word * mercury_data_char__base_type_info_char_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___char__char_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___char__char_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___char__char_0_0),
	(Word *) (Integer) mercury_data_char__base_type_layout_char_0
};

extern Word * mercury_data_char__common_1[];
Word * mercury_data_char__base_type_layout_char_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_char__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_char__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_char__common_1),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_char__common_1)
};

extern Word * mercury_data___base_type_info_character_0[];
Word * mercury_data_char__common_0[] = {
	(Word *) (Integer) mercury_data___base_type_info_character_0
};

Word * mercury_data_char__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_char__common_0)
};

BEGIN_MODULE(mercury__char_module0)
	init_entry(mercury__char__to_int_2_1);
	init_label(mercury__char__to_int_2_1_i3);
	init_label(mercury__char__to_int_2_1_i5);
	init_label(mercury__char__to_int_2_1_i7);
	init_label(mercury__char__to_int_2_1_i9);
	init_label(mercury__char__to_int_2_1_i11);
	init_label(mercury__char__to_int_2_1_i13);
	init_label(mercury__char__to_int_2_1_i15);
	init_label(mercury__char__to_int_2_1_i17);
	init_label(mercury__char__to_int_2_1_i19);
	init_label(mercury__char__to_int_2_1_i21);
	init_label(mercury__char__to_int_2_1_i23);
	init_label(mercury__char__to_int_2_1_i25);
	init_label(mercury__char__to_int_2_1_i27);
	init_label(mercury__char__to_int_2_1_i29);
	init_label(mercury__char__to_int_2_1_i31);
	init_label(mercury__char__to_int_2_1_i33);
	init_label(mercury__char__to_int_2_1_i35);
	init_label(mercury__char__to_int_2_1_i37);
	init_label(mercury__char__to_int_2_1_i39);
	init_label(mercury__char__to_int_2_1_i41);
	init_label(mercury__char__to_int_2_1_i43);
	init_label(mercury__char__to_int_2_1_i45);
	init_label(mercury__char__to_int_2_1_i47);
	init_label(mercury__char__to_int_2_1_i49);
	init_label(mercury__char__to_int_2_1_i51);
	init_label(mercury__char__to_int_2_1_i53);
	init_label(mercury__char__to_int_2_1_i55);
	init_label(mercury__char__to_int_2_1_i57);
	init_label(mercury__char__to_int_2_1_i59);
	init_label(mercury__char__to_int_2_1_i61);
	init_label(mercury__char__to_int_2_1_i63);
	init_label(mercury__char__to_int_2_1_i65);
	init_label(mercury__char__to_int_2_1_i67);
	init_label(mercury__char__to_int_2_1_i69);
	init_label(mercury__char__to_int_2_1_i71);
	init_label(mercury__char__to_int_2_1_i73);
	init_label(mercury__char__to_int_2_1_i75);
	init_label(mercury__char__to_int_2_1_i77);
	init_label(mercury__char__to_int_2_1_i79);
	init_label(mercury__char__to_int_2_1_i81);
	init_label(mercury__char__to_int_2_1_i83);
	init_label(mercury__char__to_int_2_1_i85);
	init_label(mercury__char__to_int_2_1_i87);
	init_label(mercury__char__to_int_2_1_i89);
	init_label(mercury__char__to_int_2_1_i91);
	init_label(mercury__char__to_int_2_1_i93);
	init_label(mercury__char__to_int_2_1_i95);
	init_label(mercury__char__to_int_2_1_i97);
	init_label(mercury__char__to_int_2_1_i99);
	init_label(mercury__char__to_int_2_1_i101);
	init_label(mercury__char__to_int_2_1_i103);
	init_label(mercury__char__to_int_2_1_i105);
	init_label(mercury__char__to_int_2_1_i107);
	init_label(mercury__char__to_int_2_1_i109);
	init_label(mercury__char__to_int_2_1_i111);
	init_label(mercury__char__to_int_2_1_i113);
	init_label(mercury__char__to_int_2_1_i115);
	init_label(mercury__char__to_int_2_1_i117);
	init_label(mercury__char__to_int_2_1_i119);
	init_label(mercury__char__to_int_2_1_i121);
	init_label(mercury__char__to_int_2_1_i123);
	init_label(mercury__char__to_int_2_1_i125);
	init_label(mercury__char__to_int_2_1_i127);
	init_label(mercury__char__to_int_2_1_i129);
	init_label(mercury__char__to_int_2_1_i131);
	init_label(mercury__char__to_int_2_1_i133);
	init_label(mercury__char__to_int_2_1_i135);
	init_label(mercury__char__to_int_2_1_i137);
	init_label(mercury__char__to_int_2_1_i139);
	init_label(mercury__char__to_int_2_1_i141);
	init_label(mercury__char__to_int_2_1_i143);
	init_label(mercury__char__to_int_2_1_i145);
	init_label(mercury__char__to_int_2_1_i147);
	init_label(mercury__char__to_int_2_1_i149);
	init_label(mercury__char__to_int_2_1_i151);
	init_label(mercury__char__to_int_2_1_i153);
	init_label(mercury__char__to_int_2_1_i155);
	init_label(mercury__char__to_int_2_1_i157);
	init_label(mercury__char__to_int_2_1_i159);
	init_label(mercury__char__to_int_2_1_i161);
	init_label(mercury__char__to_int_2_1_i163);
	init_label(mercury__char__to_int_2_1_i165);
	init_label(mercury__char__to_int_2_1_i167);
	init_label(mercury__char__to_int_2_1_i169);
	init_label(mercury__char__to_int_2_1_i171);
	init_label(mercury__char__to_int_2_1_i173);
	init_label(mercury__char__to_int_2_1_i175);
	init_label(mercury__char__to_int_2_1_i177);
	init_label(mercury__char__to_int_2_1_i179);
	init_label(mercury__char__to_int_2_1_i181);
	init_label(mercury__char__to_int_2_1_i183);
	init_label(mercury__char__to_int_2_1_i185);
	init_label(mercury__char__to_int_2_1_i187);
	init_label(mercury__char__to_int_2_1_i189);
	init_label(mercury__char__to_int_2_1_i191);
	init_label(mercury__char__to_int_2_1_i193);
	init_label(mercury__char__to_int_2_1_i195);
	init_label(mercury__char__to_int_2_1_i197);
	init_label(mercury__char__to_int_2_1_i199);
	init_label(mercury__char__to_int_2_1_i201);
	init_label(mercury__char__to_int_2_1_i203);
	init_label(mercury__char__to_int_2_1_i205);
	init_label(mercury__char__to_int_2_1_i207);
	init_label(mercury__char__to_int_2_1_i209);
	init_label(mercury__char__to_int_2_1_i211);
	init_label(mercury__char__to_int_2_1_i213);
	init_label(mercury__char__to_int_2_1_i215);
	init_label(mercury__char__to_int_2_1_i217);
	init_label(mercury__char__to_int_2_1_i219);
	init_label(mercury__char__to_int_2_1_i221);
	init_label(mercury__char__to_int_2_1_i223);
	init_label(mercury__char__to_int_2_1_i225);
	init_label(mercury__char__to_int_2_1_i227);
	init_label(mercury__char__to_int_2_1_i229);
	init_label(mercury__char__to_int_2_1_i231);
	init_label(mercury__char__to_int_2_1_i233);
	init_label(mercury__char__to_int_2_1_i235);
	init_label(mercury__char__to_int_2_1_i237);
	init_label(mercury__char__to_int_2_1_i239);
	init_label(mercury__char__to_int_2_1_i241);
	init_label(mercury__char__to_int_2_1_i243);
	init_label(mercury__char__to_int_2_1_i245);
	init_label(mercury__char__to_int_2_1_i247);
	init_label(mercury__char__to_int_2_1_i249);
	init_label(mercury__char__to_int_2_1_i251);
	init_label(mercury__char__to_int_2_1_i253);
	init_label(mercury__char__to_int_2_1_i255);
	init_label(mercury__char__to_int_2_1_i2);
	init_label(mercury__char__to_int_2_1_i1);
BEGIN_CODE

/* code for predicate 'char__to_int'/2 in mode 1 */
Define_entry(mercury__char__to_int_2_1);
	COMPUTED_GOTO(((Integer) r1 - ((Integer) 1)),
		LABEL(mercury__char__to_int_2_1_i3) AND
		LABEL(mercury__char__to_int_2_1_i5) AND
		LABEL(mercury__char__to_int_2_1_i7) AND
		LABEL(mercury__char__to_int_2_1_i9) AND
		LABEL(mercury__char__to_int_2_1_i11) AND
		LABEL(mercury__char__to_int_2_1_i13) AND
		LABEL(mercury__char__to_int_2_1_i15) AND
		LABEL(mercury__char__to_int_2_1_i17) AND
		LABEL(mercury__char__to_int_2_1_i19) AND
		LABEL(mercury__char__to_int_2_1_i21) AND
		LABEL(mercury__char__to_int_2_1_i23) AND
		LABEL(mercury__char__to_int_2_1_i25) AND
		LABEL(mercury__char__to_int_2_1_i27) AND
		LABEL(mercury__char__to_int_2_1_i29) AND
		LABEL(mercury__char__to_int_2_1_i31) AND
		LABEL(mercury__char__to_int_2_1_i33) AND
		LABEL(mercury__char__to_int_2_1_i35) AND
		LABEL(mercury__char__to_int_2_1_i37) AND
		LABEL(mercury__char__to_int_2_1_i39) AND
		LABEL(mercury__char__to_int_2_1_i41) AND
		LABEL(mercury__char__to_int_2_1_i43) AND
		LABEL(mercury__char__to_int_2_1_i45) AND
		LABEL(mercury__char__to_int_2_1_i47) AND
		LABEL(mercury__char__to_int_2_1_i49) AND
		LABEL(mercury__char__to_int_2_1_i51) AND
		LABEL(mercury__char__to_int_2_1_i53) AND
		LABEL(mercury__char__to_int_2_1_i55) AND
		LABEL(mercury__char__to_int_2_1_i57) AND
		LABEL(mercury__char__to_int_2_1_i59) AND
		LABEL(mercury__char__to_int_2_1_i61) AND
		LABEL(mercury__char__to_int_2_1_i63) AND
		LABEL(mercury__char__to_int_2_1_i65) AND
		LABEL(mercury__char__to_int_2_1_i67) AND
		LABEL(mercury__char__to_int_2_1_i69) AND
		LABEL(mercury__char__to_int_2_1_i71) AND
		LABEL(mercury__char__to_int_2_1_i73) AND
		LABEL(mercury__char__to_int_2_1_i75) AND
		LABEL(mercury__char__to_int_2_1_i77) AND
		LABEL(mercury__char__to_int_2_1_i79) AND
		LABEL(mercury__char__to_int_2_1_i81) AND
		LABEL(mercury__char__to_int_2_1_i83) AND
		LABEL(mercury__char__to_int_2_1_i85) AND
		LABEL(mercury__char__to_int_2_1_i87) AND
		LABEL(mercury__char__to_int_2_1_i89) AND
		LABEL(mercury__char__to_int_2_1_i91) AND
		LABEL(mercury__char__to_int_2_1_i93) AND
		LABEL(mercury__char__to_int_2_1_i95) AND
		LABEL(mercury__char__to_int_2_1_i97) AND
		LABEL(mercury__char__to_int_2_1_i99) AND
		LABEL(mercury__char__to_int_2_1_i101) AND
		LABEL(mercury__char__to_int_2_1_i103) AND
		LABEL(mercury__char__to_int_2_1_i105) AND
		LABEL(mercury__char__to_int_2_1_i107) AND
		LABEL(mercury__char__to_int_2_1_i109) AND
		LABEL(mercury__char__to_int_2_1_i111) AND
		LABEL(mercury__char__to_int_2_1_i113) AND
		LABEL(mercury__char__to_int_2_1_i115) AND
		LABEL(mercury__char__to_int_2_1_i117) AND
		LABEL(mercury__char__to_int_2_1_i119) AND
		LABEL(mercury__char__to_int_2_1_i121) AND
		LABEL(mercury__char__to_int_2_1_i123) AND
		LABEL(mercury__char__to_int_2_1_i125) AND
		LABEL(mercury__char__to_int_2_1_i127) AND
		LABEL(mercury__char__to_int_2_1_i129) AND
		LABEL(mercury__char__to_int_2_1_i131) AND
		LABEL(mercury__char__to_int_2_1_i133) AND
		LABEL(mercury__char__to_int_2_1_i135) AND
		LABEL(mercury__char__to_int_2_1_i137) AND
		LABEL(mercury__char__to_int_2_1_i139) AND
		LABEL(mercury__char__to_int_2_1_i141) AND
		LABEL(mercury__char__to_int_2_1_i143) AND
		LABEL(mercury__char__to_int_2_1_i145) AND
		LABEL(mercury__char__to_int_2_1_i147) AND
		LABEL(mercury__char__to_int_2_1_i149) AND
		LABEL(mercury__char__to_int_2_1_i151) AND
		LABEL(mercury__char__to_int_2_1_i153) AND
		LABEL(mercury__char__to_int_2_1_i155) AND
		LABEL(mercury__char__to_int_2_1_i157) AND
		LABEL(mercury__char__to_int_2_1_i159) AND
		LABEL(mercury__char__to_int_2_1_i161) AND
		LABEL(mercury__char__to_int_2_1_i163) AND
		LABEL(mercury__char__to_int_2_1_i165) AND
		LABEL(mercury__char__to_int_2_1_i167) AND
		LABEL(mercury__char__to_int_2_1_i169) AND
		LABEL(mercury__char__to_int_2_1_i171) AND
		LABEL(mercury__char__to_int_2_1_i173) AND
		LABEL(mercury__char__to_int_2_1_i175) AND
		LABEL(mercury__char__to_int_2_1_i177) AND
		LABEL(mercury__char__to_int_2_1_i179) AND
		LABEL(mercury__char__to_int_2_1_i181) AND
		LABEL(mercury__char__to_int_2_1_i183) AND
		LABEL(mercury__char__to_int_2_1_i185) AND
		LABEL(mercury__char__to_int_2_1_i187) AND
		LABEL(mercury__char__to_int_2_1_i189) AND
		LABEL(mercury__char__to_int_2_1_i191) AND
		LABEL(mercury__char__to_int_2_1_i193) AND
		LABEL(mercury__char__to_int_2_1_i195) AND
		LABEL(mercury__char__to_int_2_1_i197) AND
		LABEL(mercury__char__to_int_2_1_i199) AND
		LABEL(mercury__char__to_int_2_1_i201) AND
		LABEL(mercury__char__to_int_2_1_i203) AND
		LABEL(mercury__char__to_int_2_1_i205) AND
		LABEL(mercury__char__to_int_2_1_i207) AND
		LABEL(mercury__char__to_int_2_1_i209) AND
		LABEL(mercury__char__to_int_2_1_i211) AND
		LABEL(mercury__char__to_int_2_1_i213) AND
		LABEL(mercury__char__to_int_2_1_i215) AND
		LABEL(mercury__char__to_int_2_1_i217) AND
		LABEL(mercury__char__to_int_2_1_i219) AND
		LABEL(mercury__char__to_int_2_1_i221) AND
		LABEL(mercury__char__to_int_2_1_i223) AND
		LABEL(mercury__char__to_int_2_1_i225) AND
		LABEL(mercury__char__to_int_2_1_i227) AND
		LABEL(mercury__char__to_int_2_1_i229) AND
		LABEL(mercury__char__to_int_2_1_i231) AND
		LABEL(mercury__char__to_int_2_1_i233) AND
		LABEL(mercury__char__to_int_2_1_i235) AND
		LABEL(mercury__char__to_int_2_1_i237) AND
		LABEL(mercury__char__to_int_2_1_i239) AND
		LABEL(mercury__char__to_int_2_1_i241) AND
		LABEL(mercury__char__to_int_2_1_i243) AND
		LABEL(mercury__char__to_int_2_1_i245) AND
		LABEL(mercury__char__to_int_2_1_i247) AND
		LABEL(mercury__char__to_int_2_1_i249) AND
		LABEL(mercury__char__to_int_2_1_i251) AND
		LABEL(mercury__char__to_int_2_1_i253) AND
		LABEL(mercury__char__to_int_2_1_i255));
Define_label(mercury__char__to_int_2_1_i3);
	if (((Integer) r2 == ((Integer) 1)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i5);
	if (((Integer) r2 == ((Integer) 2)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i7);
	if (((Integer) r2 == ((Integer) 3)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i9);
	if (((Integer) r2 == ((Integer) 4)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i11);
	if (((Integer) r2 == ((Integer) 5)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i13);
	if (((Integer) r2 == ((Integer) 6)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i15);
	if (((Integer) r2 == ((Integer) 7)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i17);
	if (((Integer) r2 == ((Integer) 8)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i19);
	if (((Integer) r2 == ((Integer) 9)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i21);
	if (((Integer) r2 == ((Integer) 10)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i23);
	if (((Integer) r2 == ((Integer) 11)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i25);
	if (((Integer) r2 == ((Integer) 12)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i27);
	if (((Integer) r2 == ((Integer) 13)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i29);
	if (((Integer) r2 == ((Integer) 14)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i31);
	if (((Integer) r2 == ((Integer) 15)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i33);
	if (((Integer) r2 == ((Integer) 16)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i35);
	if (((Integer) r2 == ((Integer) 17)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i37);
	if (((Integer) r2 == ((Integer) 18)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i39);
	if (((Integer) r2 == ((Integer) 19)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i41);
	if (((Integer) r2 == ((Integer) 20)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i43);
	if (((Integer) r2 == ((Integer) 21)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i45);
	if (((Integer) r2 == ((Integer) 22)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i47);
	if (((Integer) r2 == ((Integer) 23)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i49);
	if (((Integer) r2 == ((Integer) 24)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i51);
	if (((Integer) r2 == ((Integer) 25)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i53);
	if (((Integer) r2 == ((Integer) 26)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i55);
	if (((Integer) r2 == ((Integer) 27)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i57);
	if (((Integer) r2 == ((Integer) 28)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i59);
	if (((Integer) r2 == ((Integer) 29)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i61);
	if (((Integer) r2 == ((Integer) 30)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i63);
	if (((Integer) r2 == ((Integer) 31)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i65);
	if (((Integer) r2 == ((Integer) 32)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i67);
	if (((Integer) r2 == ((Integer) 33)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i69);
	if (((Integer) r2 == ((Integer) 34)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i71);
	if (((Integer) r2 == ((Integer) 35)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i73);
	if (((Integer) r2 == ((Integer) 36)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i75);
	if (((Integer) r2 == ((Integer) 37)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i77);
	if (((Integer) r2 == ((Integer) 38)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i79);
	if (((Integer) r2 == ((Integer) 39)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i81);
	if (((Integer) r2 == ((Integer) 40)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i83);
	if (((Integer) r2 == ((Integer) 41)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i85);
	if (((Integer) r2 == ((Integer) 42)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i87);
	if (((Integer) r2 == ((Integer) 43)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i89);
	if (((Integer) r2 == ((Integer) 44)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i91);
	if (((Integer) r2 == ((Integer) 45)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i93);
	if (((Integer) r2 == ((Integer) 46)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i95);
	if (((Integer) r2 == ((Integer) 47)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i97);
	if (((Integer) r2 == ((Integer) 48)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i99);
	if (((Integer) r2 == ((Integer) 49)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i101);
	if (((Integer) r2 == ((Integer) 50)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i103);
	if (((Integer) r2 == ((Integer) 51)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i105);
	if (((Integer) r2 == ((Integer) 52)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i107);
	if (((Integer) r2 == ((Integer) 53)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i109);
	if (((Integer) r2 == ((Integer) 54)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i111);
	if (((Integer) r2 == ((Integer) 55)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i113);
	if (((Integer) r2 == ((Integer) 56)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i115);
	if (((Integer) r2 == ((Integer) 57)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i117);
	if (((Integer) r2 == ((Integer) 58)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i119);
	if (((Integer) r2 == ((Integer) 59)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i121);
	if (((Integer) r2 == ((Integer) 60)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i123);
	if (((Integer) r2 == ((Integer) 61)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i125);
	if (((Integer) r2 == ((Integer) 62)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i127);
	if (((Integer) r2 == ((Integer) 63)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i129);
	if (((Integer) r2 == ((Integer) 64)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i131);
	if (((Integer) r2 == ((Integer) 65)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i133);
	if (((Integer) r2 == ((Integer) 66)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i135);
	if (((Integer) r2 == ((Integer) 67)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i137);
	if (((Integer) r2 == ((Integer) 68)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i139);
	if (((Integer) r2 == ((Integer) 69)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i141);
	if (((Integer) r2 == ((Integer) 70)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i143);
	if (((Integer) r2 == ((Integer) 71)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i145);
	if (((Integer) r2 == ((Integer) 72)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i147);
	if (((Integer) r2 == ((Integer) 73)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i149);
	if (((Integer) r2 == ((Integer) 74)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i151);
	if (((Integer) r2 == ((Integer) 75)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i153);
	if (((Integer) r2 == ((Integer) 76)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i155);
	if (((Integer) r2 == ((Integer) 77)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i157);
	if (((Integer) r2 == ((Integer) 78)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i159);
	if (((Integer) r2 == ((Integer) 79)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i161);
	if (((Integer) r2 == ((Integer) 80)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i163);
	if (((Integer) r2 == ((Integer) 81)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i165);
	if (((Integer) r2 == ((Integer) 82)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i167);
	if (((Integer) r2 == ((Integer) 83)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i169);
	if (((Integer) r2 == ((Integer) 84)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i171);
	if (((Integer) r2 == ((Integer) 85)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i173);
	if (((Integer) r2 == ((Integer) 86)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i175);
	if (((Integer) r2 == ((Integer) 87)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i177);
	if (((Integer) r2 == ((Integer) 88)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i179);
	if (((Integer) r2 == ((Integer) 89)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i181);
	if (((Integer) r2 == ((Integer) 90)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i183);
	if (((Integer) r2 == ((Integer) 91)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i185);
	if (((Integer) r2 == ((Integer) 92)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i187);
	if (((Integer) r2 == ((Integer) 93)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i189);
	if (((Integer) r2 == ((Integer) 94)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i191);
	if (((Integer) r2 == ((Integer) 95)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i193);
	if (((Integer) r2 == ((Integer) 96)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i195);
	if (((Integer) r2 == ((Integer) 97)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i197);
	if (((Integer) r2 == ((Integer) 98)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i199);
	if (((Integer) r2 == ((Integer) 99)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i201);
	if (((Integer) r2 == ((Integer) 100)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i203);
	if (((Integer) r2 == ((Integer) 101)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i205);
	if (((Integer) r2 == ((Integer) 102)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i207);
	if (((Integer) r2 == ((Integer) 103)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i209);
	if (((Integer) r2 == ((Integer) 104)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i211);
	if (((Integer) r2 == ((Integer) 105)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i213);
	if (((Integer) r2 == ((Integer) 106)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i215);
	if (((Integer) r2 == ((Integer) 107)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i217);
	if (((Integer) r2 == ((Integer) 108)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i219);
	if (((Integer) r2 == ((Integer) 109)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i221);
	if (((Integer) r2 == ((Integer) 110)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i223);
	if (((Integer) r2 == ((Integer) 111)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i225);
	if (((Integer) r2 == ((Integer) 112)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i227);
	if (((Integer) r2 == ((Integer) 113)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i229);
	if (((Integer) r2 == ((Integer) 114)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i231);
	if (((Integer) r2 == ((Integer) 115)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i233);
	if (((Integer) r2 == ((Integer) 116)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i235);
	if (((Integer) r2 == ((Integer) 117)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i237);
	if (((Integer) r2 == ((Integer) 118)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i239);
	if (((Integer) r2 == ((Integer) 119)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i241);
	if (((Integer) r2 == ((Integer) 120)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i243);
	if (((Integer) r2 == ((Integer) 121)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i245);
	if (((Integer) r2 == ((Integer) 122)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i247);
	if (((Integer) r2 == ((Integer) 123)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i249);
	if (((Integer) r2 == ((Integer) 124)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i251);
	if (((Integer) r2 == ((Integer) 125)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i253);
	if (((Integer) r2 == ((Integer) 126)))
		GOTO_LABEL(mercury__char__to_int_2_1_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__char__to_int_2_1_i255);
	if (((Integer) r2 != ((Integer) 127)))
		GOTO_LABEL(mercury__char__to_int_2_1_i1);
Define_label(mercury__char__to_int_2_1_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__char__to_int_2_1_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module1)
	init_entry(mercury__char__to_int_2_2);
	init_label(mercury__char__to_int_2_2_i1);
BEGIN_CODE

/* code for predicate 'char__to_int'/2 in mode 2 */
Define_entry(mercury__char__to_int_2_2);
	if (((Unsigned)(((Integer) r1 - ((Integer) 1))) > ((Integer) 126)))
		GOTO_LABEL(mercury__char__to_int_2_2_i1);
	{
	static const Word mercury_const_1[] = {
		((Integer) 1),
		((Integer) 2),
		((Integer) 3),
		((Integer) 4),
		((Integer) 5),
		((Integer) 6),
		((Integer) 7),
		((Integer) 8),
		((Integer) 9),
		((Integer) 10),
		((Integer) 11),
		((Integer) 12),
		((Integer) 13),
		((Integer) 14),
		((Integer) 15),
		((Integer) 16),
		((Integer) 17),
		((Integer) 18),
		((Integer) 19),
		((Integer) 20),
		((Integer) 21),
		((Integer) 22),
		((Integer) 23),
		((Integer) 24),
		((Integer) 25),
		((Integer) 26),
		((Integer) 27),
		((Integer) 28),
		((Integer) 29),
		((Integer) 30),
		((Integer) 31),
		((Integer) 32),
		((Integer) 33),
		((Integer) 34),
		((Integer) 35),
		((Integer) 36),
		((Integer) 37),
		((Integer) 38),
		((Integer) 39),
		((Integer) 40),
		((Integer) 41),
		((Integer) 42),
		((Integer) 43),
		((Integer) 44),
		((Integer) 45),
		((Integer) 46),
		((Integer) 47),
		((Integer) 48),
		((Integer) 49),
		((Integer) 50),
		((Integer) 51),
		((Integer) 52),
		((Integer) 53),
		((Integer) 54),
		((Integer) 55),
		((Integer) 56),
		((Integer) 57),
		((Integer) 58),
		((Integer) 59),
		((Integer) 60),
		((Integer) 61),
		((Integer) 62),
		((Integer) 63),
		((Integer) 64),
		((Integer) 65),
		((Integer) 66),
		((Integer) 67),
		((Integer) 68),
		((Integer) 69),
		((Integer) 70),
		((Integer) 71),
		((Integer) 72),
		((Integer) 73),
		((Integer) 74),
		((Integer) 75),
		((Integer) 76),
		((Integer) 77),
		((Integer) 78),
		((Integer) 79),
		((Integer) 80),
		((Integer) 81),
		((Integer) 82),
		((Integer) 83),
		((Integer) 84),
		((Integer) 85),
		((Integer) 86),
		((Integer) 87),
		((Integer) 88),
		((Integer) 89),
		((Integer) 90),
		((Integer) 91),
		((Integer) 92),
		((Integer) 93),
		((Integer) 94),
		((Integer) 95),
		((Integer) 96),
		((Integer) 97),
		((Integer) 98),
		((Integer) 99),
		((Integer) 100),
		((Integer) 101),
		((Integer) 102),
		((Integer) 103),
		((Integer) 104),
		((Integer) 105),
		((Integer) 106),
		((Integer) 107),
		((Integer) 108),
		((Integer) 109),
		((Integer) 110),
		((Integer) 111),
		((Integer) 112),
		((Integer) 113),
		((Integer) 114),
		((Integer) 115),
		((Integer) 116),
		((Integer) 117),
		((Integer) 118),
		((Integer) 119),
		((Integer) 120),
		((Integer) 121),
		((Integer) 122),
		((Integer) 123),
		((Integer) 124),
		((Integer) 125),
		((Integer) 126),
		((Integer) 127)
	};
	r2 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Integer) r1 - ((Integer) 1)));
	}
	r1 = TRUE;
	proceed();
Define_label(mercury__char__to_int_2_2_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module2)
	init_entry(mercury__char__to_int_2_0);
BEGIN_CODE

/* code for predicate 'char__to_int'/2 in mode 0 */
Define_entry(mercury__char__to_int_2_0);
	{
	static const Word mercury_const_1[] = {
		((Integer) 1),
		((Integer) 2),
		((Integer) 3),
		((Integer) 4),
		((Integer) 5),
		((Integer) 6),
		((Integer) 7),
		((Integer) 8),
		((Integer) 9),
		((Integer) 10),
		((Integer) 11),
		((Integer) 12),
		((Integer) 13),
		((Integer) 14),
		((Integer) 15),
		((Integer) 16),
		((Integer) 17),
		((Integer) 18),
		((Integer) 19),
		((Integer) 20),
		((Integer) 21),
		((Integer) 22),
		((Integer) 23),
		((Integer) 24),
		((Integer) 25),
		((Integer) 26),
		((Integer) 27),
		((Integer) 28),
		((Integer) 29),
		((Integer) 30),
		((Integer) 31),
		((Integer) 32),
		((Integer) 33),
		((Integer) 34),
		((Integer) 35),
		((Integer) 36),
		((Integer) 37),
		((Integer) 38),
		((Integer) 39),
		((Integer) 40),
		((Integer) 41),
		((Integer) 42),
		((Integer) 43),
		((Integer) 44),
		((Integer) 45),
		((Integer) 46),
		((Integer) 47),
		((Integer) 48),
		((Integer) 49),
		((Integer) 50),
		((Integer) 51),
		((Integer) 52),
		((Integer) 53),
		((Integer) 54),
		((Integer) 55),
		((Integer) 56),
		((Integer) 57),
		((Integer) 58),
		((Integer) 59),
		((Integer) 60),
		((Integer) 61),
		((Integer) 62),
		((Integer) 63),
		((Integer) 64),
		((Integer) 65),
		((Integer) 66),
		((Integer) 67),
		((Integer) 68),
		((Integer) 69),
		((Integer) 70),
		((Integer) 71),
		((Integer) 72),
		((Integer) 73),
		((Integer) 74),
		((Integer) 75),
		((Integer) 76),
		((Integer) 77),
		((Integer) 78),
		((Integer) 79),
		((Integer) 80),
		((Integer) 81),
		((Integer) 82),
		((Integer) 83),
		((Integer) 84),
		((Integer) 85),
		((Integer) 86),
		((Integer) 87),
		((Integer) 88),
		((Integer) 89),
		((Integer) 90),
		((Integer) 91),
		((Integer) 92),
		((Integer) 93),
		((Integer) 94),
		((Integer) 95),
		((Integer) 96),
		((Integer) 97),
		((Integer) 98),
		((Integer) 99),
		((Integer) 100),
		((Integer) 101),
		((Integer) 102),
		((Integer) 103),
		((Integer) 104),
		((Integer) 105),
		((Integer) 106),
		((Integer) 107),
		((Integer) 108),
		((Integer) 109),
		((Integer) 110),
		((Integer) 111),
		((Integer) 112),
		((Integer) 113),
		((Integer) 114),
		((Integer) 115),
		((Integer) 116),
		((Integer) 117),
		((Integer) 118),
		((Integer) 119),
		((Integer) 120),
		((Integer) 121),
		((Integer) 122),
		((Integer) 123),
		((Integer) 124),
		((Integer) 125),
		((Integer) 126),
		((Integer) 127)
	};
	r1 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Integer) r1 - ((Integer) 1)));
	}
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module3)
	init_entry(mercury__char__to_upper_2_0);
	init_label(mercury__char__to_upper_2_0_i4);
	init_label(mercury__char__to_upper_2_0_i3);
BEGIN_CODE

/* code for predicate 'char__to_upper'/2 in mode 0 */
Define_entry(mercury__char__to_upper_2_0);
	incr_sp_push_msg(2, "char__to_upper");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__char__lower_upper_2_0),
		mercury__char__to_upper_2_0_i4,
		ENTRY(mercury__char__to_upper_2_0));
	}
Define_label(mercury__char__to_upper_2_0_i4);
	update_prof_current_proc(LABEL(mercury__char__to_upper_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__char__to_upper_2_0_i3);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__char__to_upper_2_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module4)
	init_entry(mercury__char__to_lower_2_0);
	init_label(mercury__char__to_lower_2_0_i4);
	init_label(mercury__char__to_lower_2_0_i3);
BEGIN_CODE

/* code for predicate 'char__to_lower'/2 in mode 0 */
Define_entry(mercury__char__to_lower_2_0);
	incr_sp_push_msg(2, "char__to_lower");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__char__lower_upper_2_1),
		mercury__char__to_lower_2_0_i4,
		ENTRY(mercury__char__to_lower_2_0));
	}
Define_label(mercury__char__to_lower_2_0_i4);
	update_prof_current_proc(LABEL(mercury__char__to_lower_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__char__to_lower_2_0_i3);
	r1 = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__char__to_lower_2_0_i3);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module5)
	init_entry(mercury__char__lower_upper_2_0);
	init_label(mercury__char__lower_upper_2_0_i1);
BEGIN_CODE

/* code for predicate 'char__lower_upper'/2 in mode 0 */
Define_entry(mercury__char__lower_upper_2_0);
	if (((Unsigned)(((Integer) r1 - ((Integer) 97))) > ((Integer) 25)))
		GOTO_LABEL(mercury__char__lower_upper_2_0_i1);
	{
	static const Word mercury_const_1[] = {
		((Integer) 65),
		((Integer) 66),
		((Integer) 67),
		((Integer) 68),
		((Integer) 69),
		((Integer) 70),
		((Integer) 71),
		((Integer) 72),
		((Integer) 73),
		((Integer) 74),
		((Integer) 75),
		((Integer) 76),
		((Integer) 77),
		((Integer) 78),
		((Integer) 79),
		((Integer) 80),
		((Integer) 81),
		((Integer) 82),
		((Integer) 83),
		((Integer) 84),
		((Integer) 85),
		((Integer) 86),
		((Integer) 87),
		((Integer) 88),
		((Integer) 89),
		((Integer) 90)
	};
	r2 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Integer) r1 - ((Integer) 97)));
	}
	r1 = TRUE;
	proceed();
Define_label(mercury__char__lower_upper_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module6)
	init_entry(mercury__char__lower_upper_2_1);
	init_label(mercury__char__lower_upper_2_1_i1);
BEGIN_CODE

/* code for predicate 'char__lower_upper'/2 in mode 1 */
Define_entry(mercury__char__lower_upper_2_1);
	if (((Unsigned)(((Integer) r1 - ((Integer) 65))) > ((Integer) 25)))
		GOTO_LABEL(mercury__char__lower_upper_2_1_i1);
	{
	static const Word mercury_const_1[] = {
		((Integer) 97),
		((Integer) 98),
		((Integer) 99),
		((Integer) 100),
		((Integer) 101),
		((Integer) 102),
		((Integer) 103),
		((Integer) 104),
		((Integer) 105),
		((Integer) 106),
		((Integer) 107),
		((Integer) 108),
		((Integer) 109),
		((Integer) 110),
		((Integer) 111),
		((Integer) 112),
		((Integer) 113),
		((Integer) 114),
		((Integer) 115),
		((Integer) 116),
		((Integer) 117),
		((Integer) 118),
		((Integer) 119),
		((Integer) 120),
		((Integer) 121),
		((Integer) 122)
	};
	r2 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Integer) r1 - ((Integer) 65)));
	}
	r1 = TRUE;
	proceed();
Define_label(mercury__char__lower_upper_2_1_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module7)
	init_entry(mercury__char__is_whitespace_1_0);
	init_label(mercury__char__is_whitespace_1_0_i2);
	init_label(mercury__char__is_whitespace_1_0_i1);
BEGIN_CODE

/* code for predicate 'char__is_whitespace'/1 in mode 0 */
Define_entry(mercury__char__is_whitespace_1_0);
	if (((Integer) r1 == ((Integer) 9)))
		GOTO_LABEL(mercury__char__is_whitespace_1_0_i2);
	if (((Integer) r1 == ((Integer) 10)))
		GOTO_LABEL(mercury__char__is_whitespace_1_0_i2);
	if (((Integer) r1 == ((Integer) 11)))
		GOTO_LABEL(mercury__char__is_whitespace_1_0_i2);
	if (((Integer) r1 == ((Integer) 12)))
		GOTO_LABEL(mercury__char__is_whitespace_1_0_i2);
	if (((Integer) r1 == ((Integer) 13)))
		GOTO_LABEL(mercury__char__is_whitespace_1_0_i2);
	if (((Integer) r1 != ((Integer) 32)))
		GOTO_LABEL(mercury__char__is_whitespace_1_0_i1);
Define_label(mercury__char__is_whitespace_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__char__is_whitespace_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module8)
	init_entry(mercury__char__is_upper_1_0);
BEGIN_CODE

/* code for predicate 'char__is_upper'/1 in mode 0 */
Define_entry(mercury__char__is_upper_1_0);
	{
		tailcall(STATIC(mercury__char__lower_upper_2_1),
		ENTRY(mercury__char__is_upper_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__char_module9)
	init_entry(mercury__char__is_lower_1_0);
BEGIN_CODE

/* code for predicate 'char__is_lower'/1 in mode 0 */
Define_entry(mercury__char__is_lower_1_0);
	{
		tailcall(STATIC(mercury__char__lower_upper_2_0),
		ENTRY(mercury__char__is_lower_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__char_module10)
	init_entry(mercury__char__is_alpha_1_0);
	init_label(mercury__char__is_alpha_1_0_i4);
	init_label(mercury__char__is_alpha_1_0_i8);
BEGIN_CODE

/* code for predicate 'char__is_alpha'/1 in mode 0 */
Define_entry(mercury__char__is_alpha_1_0);
	incr_sp_push_msg(2, "char__is_alpha");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__char__is_lower_1_0),
		mercury__char__is_alpha_1_0_i4,
		ENTRY(mercury__char__is_alpha_1_0));
	}
Define_label(mercury__char__is_alpha_1_0_i4);
	update_prof_current_proc(LABEL(mercury__char__is_alpha_1_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__char__is_alpha_1_0_i8);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__char__is_upper_1_0),
		ENTRY(mercury__char__is_alpha_1_0));
	}
Define_label(mercury__char__is_alpha_1_0_i8);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module11)
	init_entry(mercury__char__is_alnum_1_0);
	init_label(mercury__char__is_alnum_1_0_i4);
	init_label(mercury__char__is_alnum_1_0_i8);
BEGIN_CODE

/* code for predicate 'char__is_alnum'/1 in mode 0 */
Define_entry(mercury__char__is_alnum_1_0);
	incr_sp_push_msg(2, "char__is_alnum");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__char__is_alpha_1_0),
		mercury__char__is_alnum_1_0_i4,
		ENTRY(mercury__char__is_alnum_1_0));
	}
Define_label(mercury__char__is_alnum_1_0_i4);
	update_prof_current_proc(LABEL(mercury__char__is_alnum_1_0));
	if ((Integer) r1)
		GOTO_LABEL(mercury__char__is_alnum_1_0_i8);
	r1 = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	{
		tailcall(STATIC(mercury__char__is_digit_1_0),
		ENTRY(mercury__char__is_alnum_1_0));
	}
Define_label(mercury__char__is_alnum_1_0_i8);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module12)
	init_entry(mercury__char__is_alpha_or_underscore_1_0);
	init_label(mercury__char__is_alpha_or_underscore_1_0_i1002);
BEGIN_CODE

/* code for predicate 'char__is_alpha_or_underscore'/1 in mode 0 */
Define_entry(mercury__char__is_alpha_or_underscore_1_0);
	if (((Integer) r1 == ((Integer) 95)))
		GOTO_LABEL(mercury__char__is_alpha_or_underscore_1_0_i1002);
	{
		tailcall(STATIC(mercury__char__is_alpha_1_0),
		ENTRY(mercury__char__is_alpha_or_underscore_1_0));
	}
Define_label(mercury__char__is_alpha_or_underscore_1_0_i1002);
	r1 = TRUE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module13)
	init_entry(mercury__char__is_alnum_or_underscore_1_0);
	init_label(mercury__char__is_alnum_or_underscore_1_0_i1);
BEGIN_CODE

/* code for predicate 'char__is_alnum_or_underscore'/1 in mode 0 */
Define_entry(mercury__char__is_alnum_or_underscore_1_0);
	{
	static const Word mercury_const_1[] = {
		((Integer) 0),
		((Integer) 67043328),
		((Integer) 2281701374),
		((Integer) 134217726)
	};
	if (!(((((Integer) 1) << ((Unsigned)((Integer) r1) % ((Integer) 32))) & (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Unsigned)((Integer) r1) / ((Integer) 32))))))
		GOTO_LABEL(mercury__char__is_alnum_or_underscore_1_0_i1);
	}
	r1 = TRUE;
	proceed();
Define_label(mercury__char__is_alnum_or_underscore_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module14)
	init_entry(mercury__char__is_digit_1_0);
	init_label(mercury__char__is_digit_1_0_i1);
BEGIN_CODE

/* code for predicate 'char__is_digit'/1 in mode 0 */
Define_entry(mercury__char__is_digit_1_0);
	if (((Unsigned)(((Integer) r1 - ((Integer) 48))) > ((Integer) 9)))
		GOTO_LABEL(mercury__char__is_digit_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__char__is_digit_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module15)
	init_entry(mercury__char__is_binary_digit_1_0);
	init_label(mercury__char__is_binary_digit_1_0_i2);
	init_label(mercury__char__is_binary_digit_1_0_i1);
BEGIN_CODE

/* code for predicate 'char__is_binary_digit'/1 in mode 0 */
Define_entry(mercury__char__is_binary_digit_1_0);
	if (((Integer) r1 == ((Integer) 48)))
		GOTO_LABEL(mercury__char__is_binary_digit_1_0_i2);
	if (((Integer) r1 != ((Integer) 49)))
		GOTO_LABEL(mercury__char__is_binary_digit_1_0_i1);
Define_label(mercury__char__is_binary_digit_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__char__is_binary_digit_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module16)
	init_entry(mercury__char__is_octal_digit_1_0);
	init_label(mercury__char__is_octal_digit_1_0_i1);
BEGIN_CODE

/* code for predicate 'char__is_octal_digit'/1 in mode 0 */
Define_entry(mercury__char__is_octal_digit_1_0);
	if (((Unsigned)(((Integer) r1 - ((Integer) 48))) > ((Integer) 7)))
		GOTO_LABEL(mercury__char__is_octal_digit_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__char__is_octal_digit_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module17)
	init_entry(mercury__char__is_hex_digit_1_0);
	init_label(mercury__char__is_hex_digit_1_0_i1);
BEGIN_CODE

/* code for predicate 'char__is_hex_digit'/1 in mode 0 */
Define_entry(mercury__char__is_hex_digit_1_0);
	r2 = (Unsigned)(((Integer) r1 - ((Integer) 48)));
	if (((Integer) r2 > ((Integer) 54)))
		GOTO_LABEL(mercury__char__is_hex_digit_1_0_i1);
	{
	static const Word mercury_const_1[] = {
		((Integer) 8258559),
		((Integer) 8257536)
	};
	r3 = (Integer) field(mktag(0), mkword(mktag(0), mercury_const_1), ((Integer) r2 / ((Integer) 32)));
	}
	if (!(((((Integer) 1) << ((Integer) r2 % ((Integer) 32))) & (Integer) r3)))
		GOTO_LABEL(mercury__char__is_hex_digit_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__char__is_hex_digit_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module18)
	init_entry(mercury____Unify___char__char_0_0);
	init_label(mercury____Unify___char__char_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___char__char_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___char__char_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___char__char_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__char_module19)
	init_entry(mercury____Index___char__char_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___char__char_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___char__char_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__char_module20)
	init_entry(mercury____Compare___char__char_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___char__char_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___char__char_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__char_bunch_0(void)
{
	mercury__char_module0();
	mercury__char_module1();
	mercury__char_module2();
	mercury__char_module3();
	mercury__char_module4();
	mercury__char_module5();
	mercury__char_module6();
	mercury__char_module7();
	mercury__char_module8();
	mercury__char_module9();
	mercury__char_module10();
	mercury__char_module11();
	mercury__char_module12();
	mercury__char_module13();
	mercury__char_module14();
	mercury__char_module15();
	mercury__char_module16();
	mercury__char_module17();
	mercury__char_module18();
	mercury__char_module19();
	mercury__char_module20();
}

#endif

void mercury__char__init(void); /* suppress gcc warning */
void mercury__char__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__char_bunch_0();
#endif
}
